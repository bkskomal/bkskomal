// Org insights aggregator. Powers /dashboard/insights and the matching API.
//
// Designed to be cheap: at most a handful of grouped/aggregated queries per
// org, regardless of question or response count. We cap any per-row joins
// (sources, etc.) at the call site — the values rendered in the dashboard
// only need scalars and small histograms.
//
// Trend math: for the "vs previous 30d" arrows we compute the same metric on
// the immediately prior 30-day window (day -60..-30) and emit the delta as a
// percentage. Null when the prior window is empty (first month of usage).

import { prisma } from "@/lib/prisma";
import { ResponseStatus } from "@prisma/client";

export interface OrgInsights {
  range: { from: string; to: string; days: number };
  cards: {
    questionsAnswered: number;
    avgConfidence: number | null;
    avgConfidenceTrendPct: number | null; // signed % vs previous 30d, null if no prior data
    avgTimeToAnswerMs: number | null;
    rfpsInFlight: number;
    bulkJobsRun: number;
    rateLimitBlocks7d: number;
    /**
     * Grounded answers (last 30d): % of completed responses with
     * groundingScore >= 0.8. `null` when no graded responses exist.
     * Threshold matches the "high trust" tier on the response-detail badge
     * (everything above 0.9 is green; we use 0.8 here to give a slightly
     * more forgiving "trustable" cutoff aggregated across the org).
     */
    groundedAnswersPct: number | null;
    /**
     * Average documents per RFP package (primary + attachments). A value of
     * 1 means every RFP is single-document; >1 indicates orgs are using the
     * multi-document package feature (security questionnaires, addenda, …).
     * `null` when the org has no primary RFPs.
     */
    avgDocsPerRfp: number | null;
    /**
     * Win rate over the last 90 days: WON / (WON + LOST), expressed as a
     * percentage. Computed on RFPs whose `outcomeAt` lands in the window —
     * RFPs still PENDING (or set WITHDRAWN/NO_BID) are excluded so the
     * denominator is "decided deals". `null` when there are no decided RFPs
     * in the window so the UI can render "—" rather than a misleading 0%.
     */
    winRatePct90d: number | null;
    /**
     * Companion counts to `winRatePct90d`. Useful when the percentage is
     * eye-catching but based on a tiny sample (e.g. 100% on n=1).
     */
    wonCount90d: number;
    lostCount90d: number;
    /**
     * Pricing matrices completed in the last 30 days. Defined as: distinct
     * PRICING_MATRIX attachments whose `pricingMatrix` JSON contains at
     * least one cell with a `generated` value, where the most recent
     * generation falls in the 30-day window.
     *
     * Heuristic: we scan attachments whose row was updated in the last 30d
     * — `updatedAt` bumps every time the pricingMatrix JSON is rewritten,
     * which happens on every cell PATCH or generate iteration. This avoids
     * a full JSON-introspection query on Postgres while still capturing
     * "recent activity on a matrix" which is the user-facing concept.
     */
    pricingMatricesCompleted30d: number;
    /**
     * Semantic-cache hits served in the last 30 days. We sum `hits` across
     * cached answers whose `lastUsedAt` falls in the window — each `hits`
     * increment was driven by a real lookup, so the sum is the number of
     * fresh generations the cache saved. We pick the DB-side number over
     * reading from the metrics registry because Prom counters reset on
     * every process restart whereas CachedAnswer.hits is durable.
     */
    cacheHits30d: number;
    /** Distinct cached answers that served at least one hit in the 30d window. */
    cacheEntries30d: number;
    /**
     * Distinct editors currently active on this org's responses, defined as
     * users with a `ResponseEditSession.lastHeartbeat` within the last 5
     * minutes. Surfaces "is the team actively working right now?" — pairs
     * naturally with the throughput-by-day chart to distinguish "we ship
     * answers in bursts" from "we have a steady drumbeat of edits".
     *
     * 0 is a meaningful value (no one is editing) so we don't return null
     * here even when there have been no sessions ever.
     */
    activeEditorsCount: number;
    /**
     * Stale knowledge-base documents (Tier B2). Count of Documents in the
     * org where `staleReason` is non-null — i.e. the staleness rule flagged
     * them on the last ingest or refresh. Unlike most cards here this is an
     * all-time snapshot rather than a 30d window: a SOC2 audit older than
     * 365 days stays stale whether it was uploaded last week or last year,
     * and the card is meant to nudge admins toward a refresh.
     */
    staleSourcesCount: number;
    /**
     * Average rubric `totalScore` (0..1) across RFPs in the org whose rubric
     * was scored in the last 30 days. `null` when no RFPs have scored
     * rubrics in the window so the UI can render "—" rather than 0.
     *
     * This is the "are we tracking well against buyer criteria" signal — a
     * sustained low value means our generated responses repeatedly miss
     * something the buyers explicitly said they'd evaluate on.
     */
    avgRubricScore30d: number | null;
    /**
     * LoRA / fine-tune adapter flag (Tier C3). True iff the org has a non-
     * empty `OrgAiConfig.loraAdapterUrl` configured — i.e. generations are
     * currently routed through a fine-tune the user trained externally.
     * Surfaced as a yes/no flag (not a count) so the dashboard can render
     * a "Using fine-tuned model" badge with the base-model tooltip.
     *
     * AutoRFP does not host the training pipeline — this flag just reports
     * whether the user is consuming an external fine-tune.
     */
    adapterEnabled: boolean;
    /**
     * Predictive win scoring (Tier C — moonshot). Count of RFPs uploaded
     * in the last 30 days whose latest WinPrediction landed on the
     * corresponding recommendation tier. Override-aware: when an admin
     * has pinned `overrideAction`, we count the override (the team's
     * *actual* call) instead of the model's underlying recommendation.
     *
     * Read the two side by side: a healthy pipeline shows a meaningful
     * `predictedGoCount30d`; a creeping `predictedNoBidCount30d` is the
     * model telling you you're being routed bad-fit RFPs.
     */
    predictedGoCount30d: number;
    predictedNoBidCount30d: number;
    /**
     * Document parser pipeline (Phase D). Mean `Document.parseQuality`
     * across documents ingested in the last 30 days. `null` when no docs
     * have a score yet so the UI can render "—" rather than 0.
     *
     * A sustained drop in this signal is the canary for "the parser is
     * struggling with a new doc format / vendor template" — pair it with
     * the `document_parse_quality` Prom histogram for live monitoring.
     */
    avgParseQuality30d: number | null;
    /**
     * Vector backend (Phase V). Reports which store the org's retrieval is
     * actually backed by — always present, defaults to "postgres". Surfaced
     * on the dashboard so admins can see at a glance which orgs they've
     * cut over to the dedicated vector DB.
     */
    vectorBackendInUse: "postgres" | "milvus";
    /**
     * Approximate vector count from the Milvus cluster. `null` when the org
     * is on Postgres (the count would just duplicate the existing chunks
     * card) or when Milvus is configured but the probe failed (network
     * error, collection not yet initialised). One round-trip per insights
     * call — cheap because Milvus' getCollectionStatistics is a metadata
     * read.
     */
    milvusVectorCount: number | null;
    /**
     * Multimodal images indexed in the last 30 days. Counts ImageEmbedding
     * rows whose `createdAt` falls inside the window — i.e. fresh CLIP
     * vectors landed during recent ingest activity. Pair with
     * `imageStorageMb` for the "are we eating disk to support multimodal
     * search?" question on the dashboard.
     */
    imagesIndexed30d: number;
    /**
     * Approximate on-disk footprint of all images for this org, expressed
     * in megabytes. We estimate via `width * height * 4` (RGBA) rather than
     * statting every file — that estimate is within ~30% of true PNG/JPEG
     * size and avoids a full disk scan in the insights hot path. Falls
     * back to 0 when no images have width/height populated.
     */
    imageStorageMb: number;
  };
  charts: {
    confidenceHistogram: { bucket: string; count: number }[]; // 10 buckets 0..1
    throughputByDay: { date: string; count: number }[]; // last 30 days, ISO yyyy-mm-dd
    /**
     * RFP-outcome distribution across all RFPs in the org. Stable ordering
     * (PENDING / WON / LOST / WITHDRAWN / NO_BID) so the UI can render a
     * stacked bar without re-sorting.
     */
    outcomeDistribution: {
      outcome: "PENDING" | "WON" | "LOST" | "WITHDRAWN" | "NO_BID";
      count: number;
    }[];
  };
}

/** Grounding cutoff used for the "Grounded answers" insights card. */
export const GROUNDED_ANSWER_THRESHOLD = 0.8;

const DAY_MS = 24 * 60 * 60 * 1000;

export async function computeOrgInsights(orgId: string): Promise<OrgInsights> {
  const now = new Date();
  const from30 = new Date(now.getTime() - 30 * DAY_MS);
  const from60 = new Date(now.getTime() - 60 * DAY_MS);
  const from7 = new Date(now.getTime() - 7 * DAY_MS);

  // Pull all completed responses in last 60 days for the org. We need these
  // for: questionsAnswered (last 30d), confidence avg + histogram, throughput
  // by day, and the prior-window comparison. One DB round-trip with a small
  // projection. For very large orgs this could grow; we cap by date and only
  // select scalar columns.
  const responses = await prisma.response.findMany({
    where: {
      status: ResponseStatus.COMPLETED,
      createdAt: { gte: from60 },
      question: { rfp: { project: { organizationId: orgId } } },
    },
    select: {
      id: true,
      confidence: true,
      groundingScore: true,
      createdAt: true,
      questionId: true,
      question: { select: { createdAt: true } },
    },
    orderBy: { createdAt: "asc" },
  });

  const last30 = responses.filter((r) => r.createdAt >= from30);
  const prev30 = responses.filter((r) => r.createdAt < from30);

  const questionsAnswered = last30.length;

  const confidenceVals30 = last30
    .map((r) => r.confidence)
    .filter((c): c is number => typeof c === "number");
  const avgConfidence = confidenceVals30.length
    ? confidenceVals30.reduce((a, b) => a + b, 0) / confidenceVals30.length
    : null;

  const confidenceValsPrev = prev30
    .map((r) => r.confidence)
    .filter((c): c is number => typeof c === "number");
  const avgConfidencePrev = confidenceValsPrev.length
    ? confidenceValsPrev.reduce((a, b) => a + b, 0) / confidenceValsPrev.length
    : null;

  const avgConfidenceTrendPct =
    avgConfidence != null && avgConfidencePrev != null && avgConfidencePrev > 0
      ? ((avgConfidence - avgConfidencePrev) / avgConfidencePrev) * 100
      : null;

  // Time to answer: question.createdAt -> first COMPLETED response.createdAt.
  // We have one row per response; collapse to first-completed-per-question.
  const firstCompleted = new Map<string, { qCreatedAt: Date; rCreatedAt: Date }>();
  for (const r of last30) {
    const existing = firstCompleted.get(r.questionId);
    if (!existing || r.createdAt < existing.rCreatedAt) {
      firstCompleted.set(r.questionId, { qCreatedAt: r.question.createdAt, rCreatedAt: r.createdAt });
    }
  }
  const ttaMs = [...firstCompleted.values()].map(
    (e) => e.rCreatedAt.getTime() - e.qCreatedAt.getTime(),
  );
  const avgTimeToAnswerMs = ttaMs.length ? ttaMs.reduce((a, b) => a + b, 0) / ttaMs.length : null;

  // Confidence histogram (10 buckets). Buckets are [0,0.1), [0.1,0.2), ..., [0.9,1.0].
  const buckets = new Array(10).fill(0);
  for (const c of confidenceVals30) {
    const idx = Math.min(9, Math.max(0, Math.floor(c * 10)));
    buckets[idx]++;
  }
  const confidenceHistogram = buckets.map((count, i) => ({
    bucket: `${(i / 10).toFixed(1)}-${((i + 1) / 10).toFixed(1)}`,
    count,
  }));

  // Throughput by day — fill missing days with zeros so the chart has a stable
  // x-axis.
  const throughputMap = new Map<string, number>();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now.getTime() - i * DAY_MS);
    throughputMap.set(toIsoDay(d), 0);
  }
  for (const r of last30) {
    const k = toIsoDay(r.createdAt);
    throughputMap.set(k, (throughputMap.get(k) ?? 0) + 1);
  }
  const throughputByDay = [...throughputMap.entries()].map(([date, count]) => ({ date, count }));

  // Pipelines in flight (RUNNING / WAITING_FOR_INPUT / PAUSED).
  const rfpsInFlight = await prisma.pipelineRun.count({
    where: {
      status: { in: ["RUNNING", "WAITING_FOR_INPUT", "PAUSED"] },
      rfp: { project: { organizationId: orgId } },
    },
  });

  // Bulk-generation jobs run (any status, last 30d).
  const bulkJobsRun = await prisma.bulkGeneration.count({
    where: {
      startedAt: { gte: from30 },
      rfp: { project: { organizationId: orgId } },
    },
  });

  // Rate-limit blocks (last 7d). We don't have AuditLog entries for 429s in
  // this codebase, so count any AuditLog row with the event identifier
  // 'rate_limited' (forward-compatible if/when audit hook is added) plus zero
  // — operators reading this dashboard can also point at the
  // rate_limit_hits_total Prometheus counter. If neither source has any rows,
  // the card just shows 0.
  const rateLimitBlocks7d = await prisma.auditLog.count({
    where: {
      organizationId: orgId,
      createdAt: { gte: from7 },
      event: "rate_limited",
    },
  });

  // Grounded answers (last 30d). Only consider responses that were actually
  // graded (groundingScore is not null) — including ungraded ones in the
  // denominator would penalize orgs that haven't backfilled. Returns null
  // when no responses have been graded at all so the UI can render "—"
  // rather than a misleading 0%.
  const groundedScores = last30
    .map((r) => r.groundingScore)
    .filter((s): s is number => typeof s === "number");
  const groundedAnswersPct = groundedScores.length
    ? (groundedScores.filter((s) => s >= GROUNDED_ANSWER_THRESHOLD).length /
        groundedScores.length) *
      100
    : null;

  // Average documents per RFP (primary + attachments). Pull all primary RFPs
  // for the org with their attachment counts; mean of (1 + attachments). One
  // grouped query, scalar projection. Null when the org has no RFPs.
  const primaryRfps = await prisma.rFP.findMany({
    where: {
      parentRfpId: null,
      project: { organizationId: orgId },
    },
    select: { _count: { select: { attachments: true } } },
  });
  const avgDocsPerRfp = primaryRfps.length
    ? primaryRfps.reduce((acc, r) => acc + 1 + r._count.attachments, 0) / primaryRfps.length
    : null;

  // --- Win/loss feedback loop ---
  // Win rate is computed on the last 90 days of *decided* outcomes. We
  // intentionally use a 90-day window (not 30d like most other cards) because
  // RFP cycles are slow — many orgs decide < 5 deals in a 30d window so the
  // signal would be too noisy to plot week-over-week.
  const from90 = new Date(now.getTime() - 90 * DAY_MS);
  const decidedOutcomes = await prisma.rFP.groupBy({
    by: ["outcome"],
    where: {
      project: { organizationId: orgId },
      outcomeAt: { gte: from90 },
      outcome: { in: ["WON", "LOST"] },
    },
    _count: { _all: true },
  });
  let wonCount90d = 0;
  let lostCount90d = 0;
  for (const row of decidedOutcomes) {
    if (row.outcome === "WON") wonCount90d = row._count._all;
    else if (row.outcome === "LOST") lostCount90d = row._count._all;
  }
  const decided90d = wonCount90d + lostCount90d;
  const winRatePct90d = decided90d > 0 ? (wonCount90d / decided90d) * 100 : null;

  // Outcome distribution across the org's entire RFP corpus (all-time).
  // Used to render the stacked-bar visualisation under the win-rate card.
  // Independent of the 90d window because the chart shows "where do my deals
  // live now" rather than a recency-bound metric.
  const distRows = await prisma.rFP.groupBy({
    by: ["outcome"],
    where: { project: { organizationId: orgId } },
    _count: { _all: true },
  });
  const distMap = new Map<string, number>();
  for (const row of distRows) distMap.set(row.outcome, row._count._all);
  const outcomeDistribution: OrgInsights["charts"]["outcomeDistribution"] = (
    ["PENDING", "WON", "LOST", "WITHDRAWN", "NO_BID"] as const
  ).map((outcome) => ({ outcome, count: distMap.get(outcome) ?? 0 }));

  // --- Pricing matrices completed (last 30d) ---
  // Cheap heuristic: count PRICING_MATRIX attachments in this org that have
  // a non-null pricingMatrix JSON and were touched in the window. We can't
  // efficiently introspect "any cell has generated set" via Prisma without
  // a Postgres-specific JSON predicate, so we treat "updated AND has JSON"
  // as the proxy. False positives are rare in practice (the JSON column
  // only gets written by the matrix endpoints) and the card is meant as a
  // qualitative health signal, not a billing input.
  const recentMatrixAttachments = await prisma.rFP.findMany({
    where: {
      docRole: "PRICING_MATRIX",
      updatedAt: { gte: from30 },
      pricingMatrix: { not: null as never },
      project: { organizationId: orgId },
    },
    select: { id: true, pricingMatrix: true },
  });
  let pricingMatricesCompleted30d = 0;
  for (const row of recentMatrixAttachments) {
    if (matrixHasGeneratedCell(row.pricingMatrix)) {
      pricingMatricesCompleted30d++;
    }
  }

  // --- Semantic answer cache (Phase 3C) ---
  // Sum the `hits` counter across rows that served at least one hit in the
  // last 30 days. We can't slice by "hit happened in this window" precisely
  // (we don't keep an audit row per hit) but `lastUsedAt >= from30` is a
  // close-enough proxy: if a row last served before the window then any
  // hits it carries were necessarily older. A row that hasn't been hit at
  // all (hits = 0) is excluded so the card doesn't inflate from
  // never-served entries.
  const cacheRows = await prisma.cachedAnswer.findMany({
    where: {
      organizationId: orgId,
      lastUsedAt: { gte: from30 },
      hits: { gt: 0 },
    },
    select: { hits: true },
  });
  const cacheHits30d = cacheRows.reduce((acc, r) => acc + r.hits, 0);
  const cacheEntries30d = cacheRows.length;

  // --- Active editors right now (Tier B4) ---
  // Count distinct editorIds whose heartbeat landed in the last 5 minutes
  // on a response belonging to this org. 5min is comfortably longer than
  // HEARTBEAT_TTL_MS (~60s) but short enough that the number tracks the
  // "in the editor right this minute" intuition. We grab the rows and
  // dedupe in JS to stay portable across DBs — `distinct` on a join in
  // Prisma is awkward enough that the round-trip cost (a handful of
  // rows in steady state) isn't worth the SQL complexity.
  const editorWindow = new Date(now.getTime() - 5 * 60 * 1000);
  const activeSessions = await prisma.responseEditSession.findMany({
    where: {
      editorId: { not: null },
      lastHeartbeat: { gte: editorWindow },
      response: {
        question: { rfp: { project: { organizationId: orgId } } },
      },
    },
    select: { editorId: true },
  });
  const activeEditorsCount = new Set(
    activeSessions.map((s) => s.editorId).filter((id): id is string => !!id),
  ).size;

  // --- Stale sources (Tier B2) ---
  // Cheap indexed count of Documents in this org with a non-null staleReason
  // (the schema uses staleReason as the tri-state stale flag — see
  // lib/sources/staleness.ts). Snapshot of "right now", not a windowed
  // metric — the card is meant to nudge an admin to run the refresh route.
  const staleSourcesCount = await prisma.document.count({
    where: {
      staleReason: { not: null },
      index: { organizationId: orgId },
    },
  });

  // --- Auto-extracted rubric scoring ---
  // Average rubric totalScore across RFPs in this org whose rubric was scored
  // in the last 30 days. Only rows with `scoredAt >= from30` count — a stale
  // score from 6 weeks ago should not skew the "are we tracking buyer
  // criteria right now" signal. Null when no rubrics were scored in the
  // window so the UI can render "—".
  const scoredRubrics = await prisma.evaluationRubric.findMany({
    where: {
      scoredAt: { gte: from30 },
      totalScore: { not: null },
      rfp: { project: { organizationId: orgId } },
    },
    select: { totalScore: true },
  });
  const avgRubricScore30d = scoredRubrics.length
    ? scoredRubrics.reduce((acc, r) => acc + (r.totalScore ?? 0), 0) / scoredRubrics.length
    : null;

  // --- LoRA / fine-tune adapter flag (Tier C3) ---
  // Cheap single-row read; we only need to know whether the field is set
  // (the URL itself is rendered by the dedicated settings panel, not on the
  // insights dashboard). Treat blank/whitespace as not-configured to match
  // the resolver's semantics.
  const adapterRow = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: { loraAdapterUrl: true },
  });
  const adapterEnabled = Boolean(adapterRow?.loraAdapterUrl?.trim());

  // --- Predictive win scoring (Tier C — moonshot) ---
  // Count this org's RFPs uploaded in the last 30 days, grouped by the
  // *effective* recommendation (override beats model). We pull all
  // candidate rows in one query and bucket in JS — the count is small
  // and the override-precedence rule is awkward to express in a Prisma
  // groupBy expression.
  const recentPredictions = await prisma.winPrediction.findMany({
    where: {
      rfp: {
        createdAt: { gte: from30 },
        project: { organizationId: orgId },
      },
    },
    select: { recommendation: true, overrideAction: true },
  });
  let predictedGoCount30d = 0;
  let predictedNoBidCount30d = 0;
  for (const p of recentPredictions) {
    const effective = p.overrideAction ?? p.recommendation;
    if (effective === "go") predictedGoCount30d++;
    else if (effective === "no_bid") predictedNoBidCount30d++;
  }

  // --- Document parser pipeline (Phase D) ---
  // Mean parseQuality on Documents created in the last 30 days. Documents
  // without a score (parseQuality is null) are excluded from the average so
  // a backfill in progress doesn't drag the headline down. Null result when
  // no docs in the window have a score — the UI renders "—".
  const recentParsedDocs = await prisma.document.findMany({
    where: {
      createdAt: { gte: from30 },
      parseQuality: { not: null },
      index: { organizationId: orgId },
    },
    select: { parseQuality: true },
  });
  const avgParseQuality30d = recentParsedDocs.length
    ? recentParsedDocs.reduce((acc, r) => acc + (r.parseQuality ?? 0), 0) /
      recentParsedDocs.length
    : null;

  // --- Vector backend (Phase V) ---
  // Cheap snapshot read — the row was already pulled above for the LoRA
  // adapter check, but `vectorBackend` wasn't in that projection so we hit
  // it again. The Milvus count is an optional probe: we only attempt it
  // when the org has a configured cluster, and we silently degrade to null
  // on connection failure so a flaky vector cluster doesn't break the
  // whole insights endpoint.
  const vectorRow = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: { vectorBackend: true, milvusUri: true },
  });
  const vectorBackendInUse: "postgres" | "milvus" =
    vectorRow?.vectorBackend === "MILVUS" ? "milvus" : "postgres";
  let milvusVectorCount: number | null = null;
  if (vectorBackendInUse === "milvus" && vectorRow?.milvusUri) {
    try {
      const { createMilvusForOrg } = await import("@/lib/ai/vector/milvus");
      const store = await createMilvusForOrg(orgId);
      const probe = await store.health(orgId);
      if (probe.ok && typeof probe.vectorCount === "number") {
        milvusVectorCount = probe.vectorCount;
      }
    } catch {
      // Silently swallow — insights must never throw on a flaky external dep.
    }
  }

  // --- Multimodal image embeddings (Phase IM) ---
  // Two cheap queries: a count of recent rows + a width*height*4 sum across
  // every image the org owns. Both are scoped to ImageEmbedding directly via
  // organizationId so the index on (organizationId, indexId) does the work.
  const [imagesIndexed30d, imageDimRows] = await Promise.all([
    prisma.imageEmbedding.count({
      where: { organizationId: orgId, createdAt: { gte: from30 } },
    }),
    prisma.imageEmbedding.findMany({
      where: { organizationId: orgId },
      select: { width: true, height: true },
    }),
  ]);
  // RGBA estimate. We deliberately don't stat() every file — that would be
  // O(N) disk seeks on a hot path. The estimate is a "rough order of
  // magnitude" signal: PNG bytes are typically ~30% of width*height*4 and
  // JPEG much less, so this card reads as a slightly-pessimistic upper
  // bound which is what we want for a "should I worry about disk" prompt.
  const imageBytesEstimate = imageDimRows.reduce((acc, r) => {
    const w = r.width ?? 0;
    const h = r.height ?? 0;
    return acc + w * h * 4;
  }, 0);
  const imageStorageMb = Math.round((imageBytesEstimate / (1024 * 1024)) * 10) / 10;

  return {
    range: { from: from30.toISOString(), to: now.toISOString(), days: 30 },
    cards: {
      questionsAnswered,
      avgConfidence,
      avgConfidenceTrendPct,
      avgTimeToAnswerMs,
      rfpsInFlight,
      bulkJobsRun,
      rateLimitBlocks7d,
      groundedAnswersPct,
      avgDocsPerRfp,
      winRatePct90d,
      wonCount90d,
      lostCount90d,
      pricingMatricesCompleted30d,
      cacheHits30d,
      cacheEntries30d,
      activeEditorsCount,
      staleSourcesCount,
      avgRubricScore30d,
      adapterEnabled,
      predictedGoCount30d,
      predictedNoBidCount30d,
      avgParseQuality30d,
      vectorBackendInUse,
      milvusVectorCount,
      imagesIndexed30d,
      imageStorageMb,
    },
    charts: { confidenceHistogram, throughputByDay, outcomeDistribution },
  };
}

/**
 * True when at least one cell in the pricingMatrix JSON has `generated`
 * populated. We do the introspection in JS rather than via a JSON predicate
 * to keep the Prisma query portable across databases.
 */
function matrixHasGeneratedCell(value: unknown): boolean {
  if (!value || typeof value !== "object") return false;
  const rows = (value as { rows?: unknown }).rows;
  if (!Array.isArray(rows)) return false;
  for (const row of rows) {
    if (!row || typeof row !== "object") continue;
    const cells = (row as { cells?: unknown }).cells;
    if (!Array.isArray(cells)) continue;
    for (const cell of cells) {
      if (!cell || typeof cell !== "object") continue;
      const generated = (cell as { generated?: unknown }).generated;
      if (typeof generated === "string" && generated.length > 0) return true;
    }
  }
  return false;
}

function toIsoDay(d: Date): string {
  // YYYY-MM-DD in UTC. Stable bucket boundaries across server restarts.
  return d.toISOString().slice(0, 10);
}
