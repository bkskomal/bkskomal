// URL → Knowledge-base ingestion glue.
//
// Wraps scrapeUrl + scrapedToHtml so the caller (API route, CLI, n8n hook)
// can hand us a URL and we'll:
//   1. Scrape it (text + images + metadata).
//   2. If it's a binary file (PDF/DOCX/XLSX/PPTX/image), save the binary
//      directly and create a Document row pointing at it — the standard
//      ingestion pipeline takes it from there.
//   3. Otherwise wrap the scraped article in self-contained HTML (`scrapedToHtml`)
//      and save THAT — html-parser → image-fetch → chunker → embed all run
//      identically to a hand-uploaded .html file.
//
// All scraped URLs share `sourceUrl` on the Document row so we can:
//   - Dedupe re-scrapes (same canonical URL → re-index existing doc).
//   - Surface the original URL in the viewer.
//   - Distinguish scraped vs uploaded docs in the KB UI.

import { prisma } from "@/lib/prisma";
import { saveUpload } from "@/lib/storage";
import { ingestDocument } from "@/lib/indexing";
import { resolveAiConfig } from "@/lib/ai/config";
import { rendererForConfig } from "./headless";
import {
  scrapeUrl,
  scrapeSite,
  scrapedToHtml,
  type CrawlOptions,
  type ScrapeOptions,
} from "./url-scraper";

/**
 * Merge per-org scraping config into the explicit options the caller passed.
 * Explicit caller options always win (so tests + per-request overrides keep
 * working); org config fills in anything left undefined.
 *
 * Phase B.2: when the org configured PLAYWRIGHT or BROWSERLESS, we inject
 * the matching renderer AND set `forceJsRender` so every page goes through
 * the headless engine — the admin paid for it, honor their intent. STATIC
 * orgs (the default) pass through unchanged.
 */
async function applyOrgScrapingConfig(
  indexId: string,
  scrapeOpts: ScrapeOptions | undefined,
): Promise<ScrapeOptions> {
  const out: ScrapeOptions = { ...(scrapeOpts ?? {}) };
  const index = await prisma.knowledgeIndex.findUnique({
    where: { id: indexId },
    select: { organizationId: true },
  });
  if (!index) return out;
  const cfg = (await resolveAiConfig(index.organizationId)).scraping;

  // Caller-explicit options win; only fill what's missing.
  if (out.respectRobots === undefined) out.respectRobots = cfg.respectRobots;
  if (out.timeoutMs === undefined) out.timeoutMs = cfg.timeoutMs;
  if (out.maxImages === undefined) out.maxImages = cfg.maxImages;

  // Headless wiring (Phase B.2). Caller-supplied jsRenderer always wins —
  // tests inject mocks here. rendererForConfig returns null for STATIC or
  // misconfigured non-STATIC (logged), in which case the static path runs.
  if (out.jsRenderer === undefined) {
    const renderer = rendererForConfig(
      {
        engine: cfg.engine,
        headlessUrl: cfg.headlessUrl,
        headlessToken: cfg.headlessToken,
        timeoutMs: out.timeoutMs ?? cfg.timeoutMs,
        signal: out.signal,
      },
      index.organizationId,
    );
    if (renderer) {
      out.jsRenderer = renderer;
      // Admin picked a headless engine → render every page, not just the
      // ones that pass the SPA heuristic.
      if (out.forceJsRender === undefined) out.forceJsRender = true;
    }
  }
  return out;
}

export interface IngestUrlInput {
  indexId: string;
  url: string;
  /** Forwarded to scrapeUrl — testing seam + per-request overrides. */
  scrapeOpts?: ScrapeOptions;
}

export interface IngestUrlResult {
  documentId: string;
  /** True when an existing document was reused (re-scrape of the same URL). */
  reused: boolean;
  /** Final URL after redirects (the canonical the row was keyed on). */
  finalUrl: string;
  /** True when the URL was a binary file (PDF/DOCX/etc.). */
  binary: boolean;
  /** Stats for UI / logs. */
  imageCount: number;
  warnings: { code: string; message: string }[];
  scrapeMs: number;
}

export async function ingestUrl(input: IngestUrlInput): Promise<IngestUrlResult> {
  const { indexId, url, scrapeOpts } = input;

  const mergedOpts = await applyOrgScrapingConfig(indexId, scrapeOpts);
  const scraped = await scrapeUrl(url, mergedOpts);
  const finalUrl = scraped.finalUrl;

  // Dedupe by sourceUrl within the index. If an existing doc points at the
  // same URL we re-use that row and re-run ingest (so the embeddings refresh).
  const existing = await prisma.document.findFirst({
    where: {
      indexId,
      OR: [
        { sourceUrl: finalUrl },
        { sourceUrl: scraped.requestedUrl },
      ],
    },
    select: { id: true },
  });

  if (scraped.binary) {
    // Binary passthrough: save bytes; pipeline picks the format-specific parser.
    const { storagePath } = await saveUpload(
      `index/${indexId}`,
      scraped.binary.suggestedFileName,
      scraped.binary.buffer,
    );

    let documentId: string;
    if (existing) {
      const updated = await prisma.document.update({
        where: { id: existing.id },
        data: {
          name: scraped.title || scraped.binary.suggestedFileName,
          fileName: scraped.binary.suggestedFileName,
          fileSize: scraped.binary.buffer.byteLength,
          mimeType: scraped.binary.mimeType,
          storagePath,
          status: "PENDING",
          errorMessage: null,
          sourceUrl: finalUrl,
        },
        select: { id: true },
      });
      documentId = updated.id;
    } else {
      const created = await prisma.document.create({
        data: {
          indexId,
          name: scraped.title || scraped.binary.suggestedFileName,
          fileName: scraped.binary.suggestedFileName,
          fileSize: scraped.binary.buffer.byteLength,
          mimeType: scraped.binary.mimeType,
          storagePath,
          sourceUrl: finalUrl,
        },
        select: { id: true },
      });
      documentId = created.id;
    }

    ingestDocument(documentId).catch((err) =>
      console.error("[ingest:url-binary]", err),
    );

    return {
      documentId,
      reused: !!existing,
      finalUrl,
      binary: true,
      imageCount: 0,
      warnings: scraped.warnings,
      scrapeMs: scraped.scrapeMs,
    };
  }

  // Article path: wrap into self-contained HTML and save.
  // Forward the user's scrapeImages choice into the renderer. Defaults to
  // including images when undefined (back-compat with existing callers).
  const html = scrapedToHtml(scraped, { scrapeImages: scrapeOpts?.scrapeImages });
  const buffer = Buffer.from(html, "utf8");
  const fileName = suggestedHtmlName(finalUrl, scraped.title);
  const { storagePath } = await saveUpload(`index/${indexId}`, fileName, buffer);

  let documentId: string;
  if (existing) {
    const updated = await prisma.document.update({
      where: { id: existing.id },
      data: {
        name: scraped.title || fileName,
        fileName,
        fileSize: buffer.byteLength,
        mimeType: "text/html",
        storagePath,
        status: "PENDING",
        errorMessage: null,
        sourceUrl: finalUrl,
      },
      select: { id: true },
    });
    documentId = updated.id;
  } else {
    const created = await prisma.document.create({
      data: {
        indexId,
        name: scraped.title || fileName,
        fileName,
        fileSize: buffer.byteLength,
        mimeType: "text/html",
        storagePath,
        sourceUrl: finalUrl,
      },
      select: { id: true },
    });
    documentId = created.id;
  }

  ingestDocument(documentId).catch((err) => console.error("[ingest:url]", err));

  return {
    documentId,
    reused: !!existing,
    finalUrl,
    binary: false,
    imageCount: scraped.images.length,
    warnings: scraped.warnings,
    scrapeMs: scraped.scrapeMs,
  };
}

// ---------------------------------------------------------------------------
// Site crawl ingest — BFS from a seed URL, ingest each scraped page as its
// own Document. Cost-bounded by `maxPages`. Uses the same scrapedToHtml +
// saveUpload + ingestDocument pipeline as the single-URL path so chunks +
// image embeddings end up in Milvus identically.
// ---------------------------------------------------------------------------

export interface IngestSiteInput {
  indexId: string;
  seedUrl: string;
  crawlOpts?: CrawlOptions;
  /**
   * Fires after each page is fully processed (scrape + save + ingest hand-off).
   * The streaming SSE route uses this to push incremental progress events to
   * the UI. Non-fatal — exceptions here are swallowed so a bad listener can't
   * break the crawl loop.
   */
  onPageIngested?: (page: IngestSiteResult["pages"][number]) => void | Promise<void>;
}

export interface IngestSiteResult {
  pagesVisited: number;
  pagesIngested: number;
  pagesFailed: number;
  seedFinalUrl: string;
  pages: Array<{
    url: string;
    ok: boolean;
    documentId?: string;
    reused?: boolean;
    error?: string;
    imageCount?: number;
  }>;
}

export async function ingestSite(input: IngestSiteInput): Promise<IngestSiteResult> {
  const { indexId, seedUrl, crawlOpts, onPageIngested } = input;
  const ingestedPages: IngestSiteResult["pages"] = [];

  async function emitIngested(page: IngestSiteResult["pages"][number]) {
    ingestedPages.push(page);
    if (onPageIngested) {
      try {
        await onPageIngested(page);
      } catch {
        // listener exceptions never break the crawl
      }
    }
  }

  // Use the crawl's per-page callback to ingest each page as soon as it's
  // scraped — this means progress is incremental and a slow ingest doesn't
  // block the next fetch.
  const onPage: CrawlOptions["onPage"] = async (page) => {
    if (!page.ok || !page.doc) {
      await emitIngested({ url: page.url, ok: false, error: page.error });
      return;
    }
    try {
      // We can't call ingestUrl() directly because that re-scrapes — instead
      // mirror its save-and-record logic with the ScrapedDocument we already
      // have in hand.
      const scraped = page.doc;
      const finalUrl = scraped.finalUrl;

      const existing = await prisma.document.findFirst({
        where: {
          indexId,
          OR: [{ sourceUrl: finalUrl }, { sourceUrl: scraped.requestedUrl }],
        },
        select: { id: true },
      });

      if (scraped.binary) {
        const { storagePath } = await saveUpload(
          `index/${indexId}`,
          scraped.binary.suggestedFileName,
          scraped.binary.buffer,
        );
        const data = {
          name: scraped.title || scraped.binary.suggestedFileName,
          fileName: scraped.binary.suggestedFileName,
          fileSize: scraped.binary.buffer.byteLength,
          mimeType: scraped.binary.mimeType,
          storagePath,
          sourceUrl: finalUrl,
        };
        const row = existing
          ? await prisma.document.update({
              where: { id: existing.id },
              data: { ...data, status: "PENDING", errorMessage: null },
              select: { id: true },
            })
          : await prisma.document.create({
              data: { indexId, ...data },
              select: { id: true },
            });
        ingestDocument(row.id).catch((err) => console.error("[ingest:site-binary]", err));
        await emitIngested({
          url: page.url,
          ok: true,
          documentId: row.id,
          reused: !!existing,
          imageCount: 0,
        });
        return;
      }

      const html = scrapedToHtml(scraped, { scrapeImages: crawlOpts?.scrapeImages });
      const buffer = Buffer.from(html, "utf8");
      const fileName = suggestedHtmlName(finalUrl, scraped.title);
      const { storagePath } = await saveUpload(`index/${indexId}`, fileName, buffer);

      const data = {
        name: scraped.title || fileName,
        fileName,
        fileSize: buffer.byteLength,
        mimeType: "text/html",
        storagePath,
        sourceUrl: finalUrl,
      };
      const row = existing
        ? await prisma.document.update({
            where: { id: existing.id },
            data: { ...data, status: "PENDING", errorMessage: null },
            select: { id: true },
          })
        : await prisma.document.create({
            data: { indexId, ...data },
            select: { id: true },
          });
      ingestDocument(row.id).catch((err) => console.error("[ingest:site]", err));
      await emitIngested({
        url: page.url,
        ok: true,
        documentId: row.id,
        reused: !!existing,
        imageCount: scraped.images.length,
      });
    } catch (err) {
      await emitIngested({
        url: page.url,
        ok: false,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  };

  // Merge per-org scraping config into the crawl options (caller wins).
  const mergedCrawlOpts = await applyOrgScrapingConfig(indexId, crawlOpts);
  const crawled = await scrapeSite(seedUrl, { ...mergedCrawlOpts, onPage });

  return {
    pagesVisited: crawled.length,
    pagesIngested: ingestedPages.filter((p) => p.ok).length,
    pagesFailed: ingestedPages.filter((p) => !p.ok).length,
    seedFinalUrl: crawled[0]?.doc?.finalUrl ?? seedUrl,
    pages: ingestedPages,
  };
}

function suggestedHtmlName(url: string, title?: string): string {
  if (title) {
    const slug = title
      .toLowerCase()
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/\s+/g, "-")
      .slice(0, 80);
    if (slug) return `${slug}.html`;
  }
  try {
    const u = new URL(url);
    const last = u.pathname.split("/").filter(Boolean).pop();
    if (last) {
      const stem = last.replace(/\.[a-z0-9]+$/i, "");
      if (stem) return `${u.host}-${stem}.html`;
      return `${u.host}.html`;
    }
    return `${u.host}.html`;
  } catch {
    return "scraped-page.html";
  }
}
