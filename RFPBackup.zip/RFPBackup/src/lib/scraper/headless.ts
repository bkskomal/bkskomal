// Headless rendering for JS-driven pages (Phase B.2).
//
// Two engines, both exposed as the same `jsRenderer` contract that
// `url-scraper.ts` already understands — `(url) => {html, finalUrl}`:
//
//   • Browserless — POSTs the URL to a remote service (browserless.io or a
//     self-hosted instance) and gets HTML back. Stateless, no install. Token
//     stored encrypted in OrgAiConfig.scraperHeadlessTokenEncrypted.
//
//   • Playwright — launches a local headless Chromium via `playwright`. Has
//     a one-time `npx playwright install chromium` step (~300 MB) that we
//     surface via a clear error if it's missing. Lazy import so the dep is
//     optional — clusters that only ever use STATIC or BROWSERLESS don't pay
//     the install cost.
//
// Both renderers are bounded: per-page timeout, max response bytes, and the
// caller's AbortSignal flows through so the UI Stop button cancels mid-render.

import { log } from "@/lib/logger";

export interface RenderedPage {
  /** Final URL after redirects (matches scrapeUrl's `finalUrl`). */
  finalUrl: string;
  /** Fully-rendered HTML — post-hydration when JS executed. */
  html: string;
}

export type JsRenderer = (url: string) => Promise<RenderedPage>;

// ----- Browserless ---------------------------------------------------------

interface BrowserlessOpts {
  /** Base URL of the Browserless service. e.g. https://chrome.browserless.io */
  endpoint: string;
  /** API token. Sent as ?token=… query string per Browserless convention. */
  token: string | null;
  /** Per-page render timeout in ms (defaults to 30s). */
  timeoutMs?: number;
  /**
   * Caller AbortSignal. Browserless requests are bounded server-side too;
   * this lets the client tear down on stop.
   */
  signal?: AbortSignal;
}

/**
 * Build a Browserless renderer. Returns a `jsRenderer` you can pass into
 * `scrapeUrl`. Each call POSTs to `${endpoint}/content?token=…` with
 * `{url, waitFor: "load"}` and reads the rendered HTML back.
 */
export function browserlessRenderer(opts: BrowserlessOpts): JsRenderer {
  const timeoutMs = opts.timeoutMs ?? 30_000;
  const base = opts.endpoint.replace(/\/$/, "");
  return async (url: string): Promise<RenderedPage> => {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const onExternal = () => ctrl.abort();
    if (opts.signal) {
      if (opts.signal.aborted) ctrl.abort();
      else opts.signal.addEventListener("abort", onExternal, { once: true });
    }
    try {
      const target = opts.token
        ? `${base}/content?token=${encodeURIComponent(opts.token)}`
        : `${base}/content`;
      const res = await fetch(target, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ url, waitFor: "load", gotoOptions: { waitUntil: "networkidle2", timeout: timeoutMs } }),
        signal: ctrl.signal,
      });
      if (!res.ok) {
        const detail = await res.text().catch(() => "");
        throw new Error(`Browserless HTTP ${res.status}: ${detail.slice(0, 240)}`);
      }
      const html = await res.text();
      // Browserless's /content endpoint doesn't echo the final URL — we
      // preserve the requested URL as final (redirects happen inside the
      // headless browser; the HTML reflects the redirect target).
      return { finalUrl: url, html };
    } finally {
      clearTimeout(timer);
      opts.signal?.removeEventListener("abort", onExternal);
    }
  };
}

// ----- Playwright (local headless) -----------------------------------------

interface PlaywrightOpts {
  timeoutMs?: number;
  signal?: AbortSignal;
}

interface PlaywrightModule {
  chromium: {
    launch: (opts: Record<string, unknown>) => Promise<PlaywrightBrowser>;
  };
}
interface PlaywrightBrowser {
  newContext: (opts?: Record<string, unknown>) => Promise<PlaywrightContext>;
  close: () => Promise<void>;
}
interface PlaywrightContext {
  newPage: () => Promise<PlaywrightPage>;
  close: () => Promise<void>;
}
interface PlaywrightPage {
  goto: (url: string, opts?: { waitUntil?: string; timeout?: number }) => Promise<unknown>;
  content: () => Promise<string>;
  url: () => string;
  close: () => Promise<void>;
}

// Singleton browser. Launching is ~500 ms — keep one warm so the second URL
// in a crawl doesn't pay the cold-start cost.
let _browserPromise: Promise<PlaywrightBrowser> | null = null;

async function getBrowser(): Promise<PlaywrightBrowser> {
  if (_browserPromise) return _browserPromise;
  _browserPromise = (async () => {
    let pw: PlaywrightModule;
    try {
      // playwright is an optional peer dependency — clusters that only use
      // STATIC or BROWSERLESS shouldn't be forced to install it. The dynamic
      // import + try/catch is the install-check.
      // @ts-expect-error optional peer dep; resolved lazily at runtime
      pw = (await import("playwright")) as unknown as PlaywrightModule;
    } catch (e) {
      _browserPromise = null;
      throw new Error(
        "Playwright is not installed. Run `pnpm add playwright` and then " +
          "`pnpm exec playwright install chromium` to enable the local " +
          "headless engine. Original error: " +
          (e instanceof Error ? e.message : String(e)),
      );
    }
    try {
      return await pw.chromium.launch({ headless: true });
    } catch (e) {
      _browserPromise = null;
      throw e;
    }
  })();
  return _browserPromise;
}

/**
 * Build a Playwright renderer. Lazy-loads `playwright` on first call and
 * keeps one Chromium instance warm. If Playwright isn't installed, the first
 * render call throws a clear install-this message — ingest.ts catches it
 * and falls back to static.
 */
export function playwrightRenderer(opts: PlaywrightOpts = {}): JsRenderer {
  const timeoutMs = opts.timeoutMs ?? 30_000;
  return async (url: string): Promise<RenderedPage> => {
    const browser = await getBrowser();
    const context = await browser.newContext({
      userAgent:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 AutoRFP/1.0",
    });
    const page = await context.newPage();
    try {
      await page.goto(url, { waitUntil: "networkidle", timeout: timeoutMs });
      const html = await page.content();
      const finalUrl = page.url() || url;
      return { html, finalUrl };
    } finally {
      try {
        await page.close();
      } catch {
        // ignore
      }
      try {
        await context.close();
      } catch {
        // ignore
      }
      // Honor abort: if the caller cancelled, tear the browser down so the
      // next call gets a clean process (Chromium can leak if killed mid-load).
      if (opts.signal?.aborted) {
        try {
          await browser.close();
        } catch {
          // ignore
        }
        _browserPromise = null;
      }
    }
  };
}

// ----- Engine dispatcher ----------------------------------------------------

export interface EngineConfig {
  /** "STATIC" | "PLAYWRIGHT" | "BROWSERLESS" */
  engine: "STATIC" | "PLAYWRIGHT" | "BROWSERLESS";
  headlessUrl: string | null;
  headlessToken: string | null;
  timeoutMs: number;
  /** Caller's AbortSignal — flows into the renderer call. */
  signal?: AbortSignal;
}

/**
 * Build the right renderer for an engine config, or return `null` to mean
 * "use the static path" (engine === STATIC, OR engine selected but missing
 * required fields with a logged warning).
 */
export function rendererForConfig(cfg: EngineConfig, orgId: string | null): JsRenderer | null {
  if (cfg.engine === "STATIC") return null;
  if (cfg.engine === "BROWSERLESS") {
    if (!cfg.headlessUrl) {
      log().warn(
        { orgId, engine: cfg.engine },
        "scraperEngine=BROWSERLESS but scraperHeadlessUrl is not set; falling back to STATIC",
      );
      return null;
    }
    return browserlessRenderer({
      endpoint: cfg.headlessUrl,
      token: cfg.headlessToken,
      timeoutMs: cfg.timeoutMs,
      signal: cfg.signal,
    });
  }
  if (cfg.engine === "PLAYWRIGHT") {
    return playwrightRenderer({ timeoutMs: cfg.timeoutMs, signal: cfg.signal });
  }
  // Unknown engine — defensive default.
  log().warn(
    { orgId, engine: cfg.engine },
    `unknown scraperEngine; falling back to STATIC`,
  );
  return null;
}

/** Test seam — drops the cached Playwright browser so unit tests can re-mock. */
export function _resetHeadlessForTests(): void {
  _browserPromise = null;
}
