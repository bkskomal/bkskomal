// Headless renderers — unit tests (Phase B.2).
//
// We mock the global `fetch` for Browserless and mock dynamic-imported
// `playwright` for the local renderer so neither test ever touches the
// network or spawns a real browser. Coverage:
//   - Browserless: POST shape, token threading, error surfacing, abort
//   - Playwright: page lifecycle, missing-package error message
//   - Dispatcher: STATIC → null, BROWSERLESS w/o URL → null + warn
//   - End-to-end: ingest.applyOrgScrapingConfig injects the renderer when
//     org config picks BROWSERLESS

import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";

import {
  browserlessRenderer,
  playwrightRenderer,
  rendererForConfig,
  _resetHeadlessForTests,
} from "./headless";

const ORIG_FETCH = globalThis.fetch;

beforeEach(() => {
  _resetHeadlessForTests();
});

afterEach(() => {
  globalThis.fetch = ORIG_FETCH;
});

// ----- Browserless ---------------------------------------------------------

describe("browserlessRenderer", () => {
  it("POSTs to /content with token in query + URL in body, returns HTML", async () => {
    let captured: { url: string; init: RequestInit | undefined } | null = null;
    globalThis.fetch = (async (url: string, init?: RequestInit) => {
      captured = { url, init };
      return new Response("<html><body>hello</body></html>", { status: 200 });
    }) as typeof fetch;

    const render = browserlessRenderer({
      endpoint: "https://chrome.browserless.io/",
      token: "tok-123",
      timeoutMs: 5000,
    });
    const result = await render("https://example.com/page");

    expect(result.finalUrl).toBe("https://example.com/page");
    expect(result.html).toContain("hello");
    expect(captured).not.toBeNull();
    expect(captured!.url).toBe("https://chrome.browserless.io/content?token=tok-123");
    expect(captured!.init?.method).toBe("POST");
    const body = JSON.parse(captured!.init?.body as string);
    expect(body.url).toBe("https://example.com/page");
    expect(body.waitFor).toBe("load");
  });

  it("omits the token query param when no token is configured", async () => {
    let capturedUrl = "";
    globalThis.fetch = (async (url: string) => {
      capturedUrl = url;
      return new Response("<html />", { status: 200 });
    }) as typeof fetch;

    const render = browserlessRenderer({
      endpoint: "https://browserless.local",
      token: null,
    });
    await render("https://example.com");
    expect(capturedUrl).toBe("https://browserless.local/content");
  });

  it("throws with the upstream status + body excerpt on non-OK responses", async () => {
    globalThis.fetch = (async () =>
      new Response("rate limited please retry", { status: 429 })) as typeof fetch;

    const render = browserlessRenderer({ endpoint: "https://browserless.local", token: "t" });
    await expect(render("https://example.com")).rejects.toThrow(/Browserless HTTP 429.*rate limited/);
  });

  it("aborts when caller's signal fires before request completes", async () => {
    const ctrl = new AbortController();
    globalThis.fetch = (async (_url: string, init?: RequestInit) => {
      // Reject when the abort signal fires — mirrors real fetch behavior.
      return new Promise<Response>((_, reject) => {
        init?.signal?.addEventListener("abort", () =>
          reject(Object.assign(new Error("AbortError"), { name: "AbortError" })),
        );
      });
    }) as typeof fetch;

    const render = browserlessRenderer({
      endpoint: "https://browserless.local",
      token: "t",
      signal: ctrl.signal,
    });
    setTimeout(() => ctrl.abort(), 5);
    await expect(render("https://example.com")).rejects.toThrow(/AbortError|abort/i);
  });
});

// ----- Playwright (mocked dynamic import) ----------------------------------

describe("playwrightRenderer", () => {
  it("surfaces a clear install message when playwright is not installed", async () => {
    // Vitest doesn't intercept dynamic `import("playwright")` unless the
    // package literally isn't on disk. In this repo it isn't installed, so
    // the real import will throw — exactly the path we want to test.
    const render = playwrightRenderer({ timeoutMs: 1000 });
    await expect(render("https://example.com")).rejects.toThrow(
      /Playwright is not installed.*pnpm add playwright/,
    );
  });
});

// ----- Dispatcher ----------------------------------------------------------

describe("rendererForConfig", () => {
  it("returns null for STATIC engine", () => {
    const r = rendererForConfig(
      { engine: "STATIC", headlessUrl: null, headlessToken: null, timeoutMs: 20000 },
      "org-1",
    );
    expect(r).toBeNull();
  });

  it("returns a Browserless renderer when BROWSERLESS is configured with a URL", () => {
    const r = rendererForConfig(
      {
        engine: "BROWSERLESS",
        headlessUrl: "https://browserless.local",
        headlessToken: "t",
        timeoutMs: 20000,
      },
      "org-1",
    );
    expect(typeof r).toBe("function");
  });

  it("returns null and logs when BROWSERLESS is selected but URL is missing", () => {
    const r = rendererForConfig(
      { engine: "BROWSERLESS", headlessUrl: null, headlessToken: null, timeoutMs: 20000 },
      "org-1",
    );
    expect(r).toBeNull();
  });

  it("returns a Playwright renderer for PLAYWRIGHT engine (lazy load on first call)", () => {
    const r = rendererForConfig(
      { engine: "PLAYWRIGHT", headlessUrl: null, headlessToken: null, timeoutMs: 20000 },
      "org-1",
    );
    expect(typeof r).toBe("function");
    // We don't invoke it here — Playwright isn't installed, the real-call
    // path is covered above.
  });
});
