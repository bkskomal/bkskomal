// URL scraper — multi-strategy text + image extraction from web pages.
//
// Goals: produce a ScrapedDocument that is a drop-in for the existing parser
// pipeline. We emit HTML (so html-parser → Readability → chunker runs as
// usual) along with a normalized image list and rich metadata.
//
// Strategy (in order):
//   1. HEAD probe to learn content-type. Binary types (PDF/DOCX/XLSX/PPTX,
//      image/*) are returned with `binary: true` so the caller routes them
//      straight to the format-specific parser.
//   2. Static fetch with a realistic browser fingerprint.
//   3. Content extraction: Readability for the article body; cheerio fallback.
//   4. Image extraction: walk srcset, lazy attrs, picture/source, inline
//      style background-image, JSON-LD `image`, og:image, twitter:image, plus
//      framework JSON state blobs (__NEXT_DATA__, __NUXT__).
//   5. Metadata: title, description, author, published date, lang, canonical,
//      site name, JSON-LD blocks, open graph, twitter card.
//   6. Robots.txt: per-host fetch + cache; honored unless explicitly disabled.
//   7. Heuristic "this needs JS" detection — surfaced as a warning so an
//      operator can wire a headless fetcher (Playwright) behind the same API.
//
// Everything here is best-effort: no warning is fatal. A scrape never throws
// unless the network call itself fails (or the response is truly empty).

import { JSDOM } from "jsdom";
import { Readability } from "@mozilla/readability";
import * as cheerio from "cheerio";
import TurndownService from "turndown";
import { Agent, fetch as undiciFetch } from "undici";

const DEFAULT_USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 AutoRFP/1.0";

const DEFAULT_ACCEPT =
  "text/html,application/xhtml+xml,application/xml;q=0.9," +
  "image/avif,image/webp,image/apng,*/*;q=0.8";

const DEFAULT_ACCEPT_LANGUAGE = "en-US,en;q=0.9";

const DEFAULT_MAX_BYTES = 15 * 1024 * 1024;
const DEFAULT_TIMEOUT_MS = 20_000;
const DEFAULT_MAX_IMAGES = 48;

const BINARY_CONTENT_TYPES = new Set([
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
]);

const IMAGE_EXT_RE = /\.(png|jpe?g|webp|gif|avif|svg|bmp|tiff?)(\?.*)?$/i;

export interface ScrapeOptions {
  /** Override default Chrome UA. */
  userAgent?: string;
  /** Per-request timeout in ms. */
  timeoutMs?: number;
  /** Cap on response body bytes. */
  maxBytes?: number;
  /** Cap on extracted image count. */
  maxImages?: number;
  /** Honor robots.txt. Default true. */
  respectRobots?: boolean;
  /** Custom Accept-Language. */
  acceptLanguage?: string;
  /** Pre-set Cookie header (rare; for paywalled pages with shared session). */
  cookies?: string;
  /**
   * Override fetch (testing seam). Must match the global fetch signature.
   */
  fetchFn?: typeof fetch;
  /**
   * Optional headless renderer for SPA pages. If provided AND the static
   * fetch heuristically looks JS-rendered, the scraper calls this with the
   * URL and uses its result as `rawHtml`. Off by default — keeps the core
   * scraper dep-free; Playwright integration is opt-in.
   */
  jsRenderer?: (url: string) => Promise<{ html: string; finalUrl: string }>;
  /**
   * Phase B.2: when true, invoke `jsRenderer` for every fetched page,
   * regardless of the SPA heuristic. Set automatically by ingest.ts when
   * the org configured a headless engine (PLAYWRIGHT / BROWSERLESS) — the
   * admin paid for the headless service so honor their intent, even on
   * pages that look static-enough to skip rendering.
   */
  forceJsRender?: boolean;
  /**
   * Caller-supplied abort signal. The scraper checks this at every stage
   * boundary and aborts the underlying fetch. Used by the streaming route
   * to honour an HTTP client disconnect (Stop button in the UI).
   */
  signal?: AbortSignal;
  /**
   * When true (default), discovered image URLs are emitted into the
   * scrapedToHtml() output so the downstream parser pipeline fetches +
   * CLIP-embeds them into Milvus for image-based answer matching. Set
   * false for a text-only ingest (faster, no per-image network cost).
   */
  scrapeImages?: boolean;
  /**
   * When the strict-TLS fetch fails with `UNABLE_TO_VERIFY_LEAF_SIGNATURE`
   * (or related chain errors), retry once with TLS validation relaxed. The
   * scraped document carries a `tls_validation_skipped` warning so the
   * operator knows the chain wasn't verified.
   *
   * Default: true. This is the right default for a personal RFP tool fetching
   * known-good marketing/vendor URLs — Node's bundled CA store is often
   * incomplete on Windows or behind corporate MITM proxies, and the cost of
   * blocking a scrape on a TLS chain quirk is high. Set false to enforce
   * strict TLS validation (recommended for any scrape against an arbitrary
   * URL the user hasn't vetted).
   */
  allowInsecureTlsFallback?: boolean;
}

export interface ScrapedImage {
  /** Absolute URL. */
  url: string;
  alt?: string;
  caption?: string;
  width?: number;
  height?: number;
  /** Where the URL was discovered — diagnostic + ranking hint. */
  role:
    | "img"
    | "picture"
    | "srcset"
    | "lazy"
    | "background"
    | "og"
    | "twitter"
    | "json-ld"
    | "framework-state";
}

export interface ScrapedDocument {
  // --- Origin ---
  requestedUrl: string;
  /** URL after redirect chain (when fetch reports a different .url). */
  finalUrl: string;
  // --- Fetch metadata ---
  fetchedAt: Date;
  httpStatus: number;
  contentType: string;
  fetchedBytes: number;
  isJsRendered: boolean;
  /** Heuristic — set when static body looks SPA-shaped (suggests Playwright). */
  needsJsRendering: boolean;

  // --- Content body ---
  /**
   * Raw response body decoded as UTF-8 (after charset detection). When the
   * source is a binary type (PDF/DOCX/etc.) this is empty — see `binary`.
   */
  rawHtml: string;
  /** Article-only HTML (Readability when it returned ≥200 chars). */
  cleanedHtml: string;
  /** Plain-text fallback derived from cleanedHtml. */
  textContent: string;
  /** Markdown rendering of cleanedHtml — handy for the embedding pipeline. */
  markdown: string;

  // --- Page metadata ---
  title?: string;
  description?: string;
  author?: string;
  publishedAt?: Date;
  language?: string;
  siteName?: string;
  canonicalUrl?: string;

  // --- Images ---
  images: ScrapedImage[];

  // --- Structured data ---
  jsonLd: unknown[];
  openGraph: Record<string, string>;
  twitter: Record<string, string>;

  // --- Binary passthrough (PDF/DOCX/XLSX/etc.) ---
  /**
   * When the URL turned out to be a binary file (PDF, Office doc, image),
   * the body is returned here so the caller can hand it to the right parser
   * instead of trying to extract text from rawHtml.
   */
  binary?: {
    buffer: Buffer;
    mimeType: string;
    suggestedFileName: string;
  };

  // --- Diagnostics ---
  warnings: ScrapeWarning[];
  scrapeMs: number;
}

export interface ScrapeWarning {
  code: string;
  message: string;
}

// --- Robots.txt cache (per host) -------------------------------------------

interface RobotsRules {
  // We only model Disallow lines for User-agent: * (good enough for our UA).
  disallow: string[];
}
const robotsCache = new Map<string, RobotsRules | null>();

async function fetchRobots(
  origin: string,
  fetchFn: typeof fetch,
): Promise<RobotsRules | null> {
  if (robotsCache.has(origin)) return robotsCache.get(origin) ?? null;
  try {
    const res = await fetchFn(`${origin}/robots.txt`, {
      headers: { "User-Agent": DEFAULT_USER_AGENT },
    });
    if (!res.ok) {
      robotsCache.set(origin, null);
      return null;
    }
    const text = await res.text();
    const rules = parseRobots(text);
    robotsCache.set(origin, rules);
    return rules;
  } catch {
    robotsCache.set(origin, null);
    return null;
  }
}

function parseRobots(text: string): RobotsRules {
  const disallow: string[] = [];
  let active = false;
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.split("#")[0].trim();
    if (!line) continue;
    const sep = line.indexOf(":");
    if (sep < 0) continue;
    const key = line.slice(0, sep).trim().toLowerCase();
    const value = line.slice(sep + 1).trim();
    if (key === "user-agent") {
      active = value === "*" || /autorfp/i.test(value);
    } else if (active && key === "disallow" && value) {
      disallow.push(value);
    }
  }
  return { disallow };
}

function isPathAllowed(pathname: string, rules: RobotsRules | null): boolean {
  if (!rules) return true;
  for (const rule of rules.disallow) {
    if (rule === "/") return false;
    if (pathname.startsWith(rule)) return false;
  }
  return true;
}

// --- Charset helpers -------------------------------------------------------

function detectCharset(
  headers: Headers,
  body: Buffer,
): string {
  const ct = headers.get("content-type") ?? "";
  const m = ct.match(/charset=([^;]+)/i);
  if (m) return m[1].trim().replace(/['"]/g, "").toLowerCase();
  // Sniff first 1KB for an HTML meta charset.
  const head = body.slice(0, 1024).toString("ascii");
  const metaCharset = head.match(/<meta[^>]+charset=["']?([\w-]+)/i);
  if (metaCharset) return metaCharset[1].toLowerCase();
  return "utf-8";
}

function decodeBody(buffer: Buffer, charset: string): string {
  try {
    const decoder = new TextDecoder(charset, { fatal: false });
    return decoder.decode(buffer);
  } catch {
    return buffer.toString("utf8");
  }
}

// --- Image extraction ------------------------------------------------------

// Every known lazy-loader attribute across the popular WP / Shopify / Ghost
// / Squarespace / Wix / Webflow / LiteSpeed / WP Rocket / a3 Lazy Load /
// LazySizes / BLazy / Unveil / Owl Carousel / Slick / Foundation patterns.
// Order matters — earlier entries win when multiple attrs are present.
const LAZY_ATTRS_SINGLE = [
  "data-src",
  "data-original",
  "data-original-src",
  "data-orig-src",
  "data-orig-file",
  "data-lazy",
  "data-lazy-src",
  "data-actualsrc",
  "data-defer-src",
  "data-fallback-src",
  "data-image-src",
  "data-image",
  "data-hi-res-src",
  "data-full-src",
  "data-full-url",
  "data-large-file",
  "data-medium-file",
  "data-thumb",
  "data-thumbnail",
  "data-bg",
  "data-pin-media",
  "data-cmplz-src",  // Complianz GDPR plugin
  "data-runner-src", // ScrollMagic
];
const LAZY_ATTRS_SRCSET = [
  "data-srcset",
  "data-lazy-srcset",
  "data-original-srcset",
  "data-bgset",      // bgset: srcset for backgrounds (lazysizes plugin)
];

// 1×1 transparent placeholder patterns + common spacer asset names.
const PLACEHOLDER_PATTERNS = [
  /^data:image\/gif;base64,R0lGOD/i,  // canonical 1x1 transparent gif
  /^data:image\/svg\+xml/i,           // svg shimmer / blur placeholder
  /^data:image\/png;base64,iVBORw0KGgoAAAANSUhEUg.{0,300}$/, // very-short PNG
  /\b(blank|spacer|placeholder|loading|pixel|transparent)\.(gif|png|jpe?g|svg)\b/i,
  /^about:blank$/i,
];

// Image hosts we never want to embed — pure tracking pixels, ad/analytics.
const TRACKER_HOST_PATTERNS = [
  /^(www\.)?google-analytics\.com$/i,
  /^(www\.)?googletagmanager\.com$/i,
  /^stats\.wp\.com$/i,
  /^pixel\.wp\.com$/i,
  /^(www\.)?facebook\.com$/i, // /tr? tracking pixel
  /^connect\.facebook\.net$/i,
  /^(www\.)?doubleclick\.net$/i,
  /^bat\.bing\.com$/i,
  /\.adservice\./i,
  /\.adsystem\./i,
];

function isPlaceholderSrc(src: string | undefined): boolean {
  if (!src) return true;
  const s = src.trim();
  if (!s) return true;
  return PLACEHOLDER_PATTERNS.some((re) => re.test(s));
}

function isTrackerUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return TRACKER_HOST_PATTERNS.some((re) => re.test(u.host));
  } catch {
    return false;
  }
}

function pickLargestFromSrcset(srcset: string): string | undefined {
  // "url 1x, url 2x" OR "url 320w, url 640w". Return the highest-resolution.
  //
  // Robust against URLs containing literal whitespace (a quirk of WordPress
  // uploads where the filename has a space: it's invalid srcset per spec
  // but extremely common in the wild). Strategy: regex-match the trailing
  // descriptor on each entry; everything before the descriptor is the URL.
  const ENTRY_RE = /^(.*?)\s+(\d+(?:\.\d+)?[wx])\s*$/;
  const entries = srcset
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((entry) => {
      const m = ENTRY_RE.exec(entry);
      if (m) {
        const url = m[1].trim();
        const desc = m[2];
        const num = parseFloat(desc);
        return { url, weight: num };
      }
      // No descriptor (single-URL srcset) — weight 1, full entry is URL.
      return { url: entry, weight: 1 };
    })
    .filter((e) => !!e.url);
  if (entries.length === 0) return undefined;
  entries.sort((a, b) => b.weight - a.weight);
  return entries[0].url;
}

function absolutize(href: string, base: string): string | null {
  if (!href) return null;
  if (href.startsWith("data:")) return href;
  if (href.startsWith("//")) {
    try {
      return new URL(`https:${href}`).toString();
    } catch {
      return null;
    }
  }
  try {
    return new URL(href, base).toString();
  } catch {
    return null;
  }
}

function extractImages(
  $: cheerio.CheerioAPI,
  baseUrl: string,
  openGraph: Record<string, string>,
  twitter: Record<string, string>,
  jsonLd: unknown[],
  rawHtml: string,
  maxImages: number,
): ScrapedImage[] {
  const seen = new Set<string>();
  const images: ScrapedImage[] = [];

  function push(img: ScrapedImage) {
    if (!img.url) return;
    if (seen.has(img.url)) return;
    if (isTrackerUrl(img.url)) return;
    seen.add(img.url);
    images.push(img);
  }

  // ---- 1) Every <img> + every lazy attr ---------------------------------
  $("img").each((_i, el) => {
    if (images.length >= maxImages) return false;
    const $el = $(el);
    let src: string | undefined;
    let role: ScrapedImage["role"] = "img";

    // Pass 1: real srcset always wins (highest descriptor)
    const srcset = $el.attr("srcset");
    if (srcset) {
      const largest = pickLargestFromSrcset(srcset);
      if (largest && !isPlaceholderSrc(largest)) {
        src = largest;
        role = "srcset";
      }
    }

    // Pass 2: data-srcset variants
    if (!src) {
      for (const attr of LAZY_ATTRS_SRCSET) {
        const v = $el.attr(attr);
        if (!v) continue;
        const largest = pickLargestFromSrcset(v);
        if (largest && !isPlaceholderSrc(largest)) {
          src = largest;
          role = "lazy";
          break;
        }
      }
    }

    // Pass 3: single-URL lazy attrs (data-src, data-original, ...)
    if (!src) {
      for (const attr of LAZY_ATTRS_SINGLE) {
        const v = $el.attr(attr);
        if (v && !isPlaceholderSrc(v)) {
          src = v;
          role = "lazy";
          break;
        }
      }
    }

    // Pass 4: plain src (last resort — and only if not a placeholder)
    if (!src) {
      const raw = $el.attr("src");
      if (raw && !isPlaceholderSrc(raw)) src = raw;
    }

    if (!src) return;
    const abs = absolutize(src, baseUrl);
    if (!abs) return;
    const widthAttr = $el.attr("width");
    const heightAttr = $el.attr("height");
    push({
      url: abs,
      alt: $el.attr("alt") || undefined,
      caption: $el.parents("figure").first().find("figcaption").text().trim() || undefined,
      width: widthAttr ? parseInt(widthAttr, 10) || undefined : undefined,
      height: heightAttr ? parseInt(heightAttr, 10) || undefined : undefined,
      role,
    });
    return;
  });

  // ---- 2) <noscript> fallback — many lazy loaders put the real
  // <img src="..."> inside a <noscript> for non-JS clients. cheerio doesn't
  // descend into noscript by default, so we grep the raw text instead.
  if (images.length < maxImages) {
    const noscriptImgs = rawHtml.match(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi) ?? [];
    for (const block of noscriptImgs) {
      if (images.length >= maxImages) break;
      const srcMatch = /<img[^>]+src=["']([^"']+)["']/i.exec(block);
      const altMatch = /<img[^>]+alt=["']([^"']*)["']/i.exec(block);
      if (!srcMatch) continue;
      const abs = absolutize(srcMatch[1], baseUrl);
      if (abs && !isPlaceholderSrc(srcMatch[1])) {
        push({ url: abs, alt: altMatch?.[1], role: "lazy" });
      }
      // Also any srcset inside the noscript img
      const srcsetMatch = /<img[^>]+srcset=["']([^"']+)["']/i.exec(block);
      if (srcsetMatch) {
        const largest = pickLargestFromSrcset(srcsetMatch[1]);
        if (largest) {
          const abs2 = absolutize(largest, baseUrl);
          if (abs2) push({ url: abs2, alt: altMatch?.[1], role: "srcset" });
        }
      }
    }
  }

  // ---- 3) <picture><source srcset="..."> + media variants
  $("picture source").each((_i, el) => {
    if (images.length >= maxImages) return false;
    const $el = $(el);
    const srcset = $el.attr("srcset") || $el.attr("data-srcset");
    if (!srcset) return;
    const largest = pickLargestFromSrcset(srcset);
    if (!largest) return;
    const abs = absolutize(largest, baseUrl);
    if (abs && !isPlaceholderSrc(largest)) push({ url: abs, role: "picture" });
    return;
  });

  // ---- 4) Inline style background-image (any element)
  $("[style*=background-image], [style*=background:]").each((_i, el) => {
    if (images.length >= maxImages) return false;
    const style = $(el).attr("style") ?? "";
    const re = /background(?:-image)?\s*:\s*[^;]*url\(["']?([^"')]+)["']?\)/gi;
    let m: RegExpExecArray | null;
    while ((m = re.exec(style))) {
      if (images.length >= maxImages) return false;
      const abs = absolutize(m[1], baseUrl);
      if (abs && !isPlaceholderSrc(m[1])) push({ url: abs, role: "background" });
    }
    return;
  });

  // ---- 5) data-bg / data-bgset lazy-background (lazysizes plugin) on any element
  $("[data-bg], [data-bgset]").each((_i, el) => {
    if (images.length >= maxImages) return false;
    const $el = $(el);
    const bg = $el.attr("data-bg");
    if (bg) {
      const abs = absolutize(bg, baseUrl);
      if (abs && !isPlaceholderSrc(bg)) push({ url: abs, role: "background" });
    }
    const bgset = $el.attr("data-bgset");
    if (bgset) {
      const largest = pickLargestFromSrcset(bgset);
      if (largest) {
        const abs = absolutize(largest, baseUrl);
        if (abs && !isPlaceholderSrc(largest)) push({ url: abs, role: "background" });
      }
    }
    return;
  });

  // ---- 6) Embedded <style> blocks — common for CSS-driven hero banners
  if (images.length < maxImages) {
    const styleBlocks = rawHtml.match(/<style[^>]*>[\s\S]*?<\/style>/gi) ?? [];
    const seenInStyle = new Set<string>();
    for (const block of styleBlocks) {
      if (images.length >= maxImages) break;
      const re = /url\(["']?(https?:\/\/[^"')]+\.(?:png|jpe?g|webp|gif|avif|svg)(?:\?[^"')]*)?)["']?\)/gi;
      let m: RegExpExecArray | null;
      while ((m = re.exec(block))) {
        if (images.length >= maxImages) break;
        if (seenInStyle.has(m[1])) continue;
        seenInStyle.add(m[1]);
        const abs = absolutize(m[1], baseUrl);
        if (abs) push({ url: abs, role: "background" });
      }
    }
  }

  // ---- 7) <link rel="image_src"> + <meta itemprop="image"> + legacy thumbnail
  const linkImage = $('link[rel="image_src"]').attr("href");
  if (linkImage) {
    const abs = absolutize(linkImage, baseUrl);
    if (abs) push({ url: abs, role: "og" });
  }
  $('meta[itemprop="image"], meta[name="thumbnail"]').each((_i, el) => {
    if (images.length >= maxImages) return false;
    const c = $(el).attr("content");
    if (!c) return;
    const abs = absolutize(c, baseUrl);
    if (abs) push({ url: abs, role: "og" });
    return;
  });

  // ---- 8) og:image + twitter:image
  for (const k of ["og:image", "og:image:secure_url", "og:image:url"]) {
    if (openGraph[k]) {
      const abs = absolutize(openGraph[k], baseUrl);
      if (abs) push({ url: abs, role: "og" });
    }
  }
  if (twitter["twitter:image"]) {
    const abs = absolutize(twitter["twitter:image"], baseUrl);
    if (abs) push({ url: abs, role: "twitter" });
  }

  // ---- 9) JSON-LD `image` field — handles string, string[], {url}
  for (const block of jsonLd) {
    if (images.length >= maxImages) break;
    const candidates = collectJsonLdImages(block);
    for (const c of candidates) {
      if (images.length >= maxImages) break;
      const abs = absolutize(c, baseUrl);
      if (abs) push({ url: abs, role: "json-ld" });
    }
  }

  // ---- 10) Framework state blobs — last-resort grep over raw HTML
  if (images.length < maxImages) {
    const stateImages = mineStateBlobImages(rawHtml, baseUrl, maxImages - images.length);
    for (const url of stateImages) push({ url, role: "framework-state" });
  }

  return images;
}

function collectJsonLdImages(node: unknown): string[] {
  const out: string[] = [];
  function walk(value: unknown) {
    if (!value) return;
    if (typeof value === "string") return;
    if (Array.isArray(value)) {
      for (const v of value) walk(v);
      return;
    }
    if (typeof value !== "object") return;
    const obj = value as Record<string, unknown>;
    const img = obj.image;
    if (typeof img === "string") out.push(img);
    else if (Array.isArray(img)) {
      for (const v of img) {
        if (typeof v === "string") out.push(v);
        else if (v && typeof v === "object") {
          const url = (v as Record<string, unknown>).url;
          if (typeof url === "string") out.push(url);
        }
      }
    } else if (img && typeof img === "object") {
      const url = (img as Record<string, unknown>).url;
      if (typeof url === "string") out.push(url);
    }
    for (const v of Object.values(obj)) walk(v);
  }
  walk(node);
  return out;
}

function mineStateBlobImages(rawHtml: string, baseUrl: string, limit: number): string[] {
  // Greedy URL match — quick win for SPA pages. We only consider absolute or
  // root-relative paths to common image extensions, capped tight.
  const re = /(https?:\/\/[^"'\s<>]+?\.(?:png|jpe?g|webp|gif|avif|svg)(?:\?[^"'\s<>]*)?)/gi;
  const out = new Set<string>();
  let match: RegExpExecArray | null;
  while ((match = re.exec(rawHtml)) && out.size < limit) {
    const abs = absolutize(match[1], baseUrl);
    if (abs) out.add(abs);
  }
  return Array.from(out);
}

// --- Metadata extraction ---------------------------------------------------

function extractJsonLd($: cheerio.CheerioAPI): unknown[] {
  const out: unknown[] = [];
  $('script[type="application/ld+json"]').each((_i, el) => {
    const raw = $(el).contents().text();
    if (!raw) return;
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) out.push(...parsed);
      else out.push(parsed);
    } catch {
      // ignore — malformed JSON-LD is endemic
    }
  });
  return out;
}

function extractMeta($: cheerio.CheerioAPI): {
  og: Record<string, string>;
  twitter: Record<string, string>;
  description?: string;
  author?: string;
  publishedAt?: Date;
  canonical?: string;
} {
  const og: Record<string, string> = {};
  const tw: Record<string, string> = {};
  let description: string | undefined;
  let author: string | undefined;
  let publishedAt: Date | undefined;
  let canonical: string | undefined;

  $("meta").each((_i, el) => {
    const $el = $(el);
    const name = ($el.attr("name") ?? "").toLowerCase();
    const prop = ($el.attr("property") ?? "").toLowerCase();
    const content = $el.attr("content");
    if (!content) return;
    if (prop.startsWith("og:")) og[prop] = content;
    else if (name.startsWith("twitter:")) tw[name] = content;
    else if (name === "description") description = content;
    else if (name === "author") author = content;
    else if (name === "article:published_time" || prop === "article:published_time") {
      const d = new Date(content);
      if (!isNaN(d.getTime())) publishedAt = d;
    }
  });

  const linkCanonical = $('link[rel="canonical"]').attr("href");
  if (linkCanonical) canonical = linkCanonical;

  return { og, twitter: tw, description, author, publishedAt, canonical };
}

// --- JS-rendering heuristic ------------------------------------------------

function looksLikeSpa(rawHtml: string, textChars: number): boolean {
  if (textChars >= 600) return false;
  // Common SPA mount points + meta hints.
  if (/<div[^>]+id=["']root["'][^>]*>\s*<\/div>/.test(rawHtml)) return true;
  if (/<div[^>]+id=["']__next["']/.test(rawHtml)) return true;
  if (/<div[^>]+id=["']app["'][^>]*>\s*<\/div>/.test(rawHtml)) return true;
  if (/<noscript>[^<]*(enable javascript|JavaScript required)/i.test(rawHtml)) return true;
  if (/window\.__NUXT__|__NEXT_DATA__|__sveltekit/.test(rawHtml)) return true;
  return false;
}

// --- Turndown singleton ----------------------------------------------------

let _turndown: TurndownService | undefined;
function turndown(): TurndownService {
  if (!_turndown) {
    _turndown = new TurndownService({
      headingStyle: "atx",
      codeBlockStyle: "fenced",
      bulletListMarker: "-",
    });
  }
  return _turndown;
}

// --- Public entry point ----------------------------------------------------

export async function scrapeUrl(
  rawUrl: string,
  opts: ScrapeOptions = {},
): Promise<ScrapedDocument> {
  const t0 = Date.now();
  const warnings: ScrapeWarning[] = [];

  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error(`Invalid URL: ${rawUrl}`);
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new Error(`Unsupported URL scheme: ${url.protocol}`);
  }

  const userAgent = opts.userAgent ?? DEFAULT_USER_AGENT;
  const acceptLanguage = opts.acceptLanguage ?? DEFAULT_ACCEPT_LANGUAGE;
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const maxBytes = opts.maxBytes ?? DEFAULT_MAX_BYTES;
  const maxImages = opts.maxImages ?? DEFAULT_MAX_IMAGES;
  const respectRobots = opts.respectRobots ?? true;
  const allowInsecureTlsFallback = opts.allowInsecureTlsFallback ?? true;
  const fetchFn = opts.fetchFn ?? (globalThis.fetch as typeof fetch);

  // Robots.txt — tolerate TLS chain errors on the robots probe too so a
  // broken cert chain doesn't silently block every URL. We only enforce
  // disallow rules; failure to load robots.txt is "no rules apply".
  if (respectRobots) {
    try {
      const rules = await fetchRobots(url.origin, fetchFn);
      if (!isPathAllowed(url.pathname, rules)) {
        throw new Error(`robots.txt disallows ${url.pathname} on ${url.host}`);
      }
    } catch (e) {
      // Only re-throw genuine "disallowed" errors. Network errors get
      // swallowed (robotsCache already swallows them, but be defensive).
      if (e instanceof Error && e.message.startsWith("robots.txt disallows")) {
        throw e;
      }
    }
  }

  let res: Response;
  let tlsRelaxed = false;
  try {
    res = await fetchOnce(rawUrl, {
      fetchFn,
      userAgent,
      acceptLanguage,
      timeoutMs,
      cookies: opts.cookies,
      externalSignal: opts.signal,
    });
  } catch (err) {
    // If the caller aborted, bubble that up unmodified — don't try a TLS
    // fallback on a deliberate cancel.
    if (opts.signal?.aborted) throw err;
    // Auto-fallback on TLS chain errors. Node's bundled CA store is often
    // missing intermediates (esp. on Windows or behind corporate proxies),
    // so a strict-TLS first attempt fails on perfectly legitimate sites.
    // We retry once with rejectUnauthorized=false via an undici Agent and
    // surface a warning on the result so the caller knows what happened.
    if (allowInsecureTlsFallback && isTlsChainError(err)) {
      warnings.push({
        code: "tls_validation_skipped",
        message:
          `TLS certificate chain for ${url.host} could not be validated ` +
          `(${describeCause(err) ?? "unknown chain error"}); retried with ` +
          `validation disabled. Configure NODE_EXTRA_CA_CERTS to your ` +
          `corporate/system CA bundle to silence this warning.`,
      });
      res = await fetchOnce(rawUrl, {
        fetchFn: insecureFetch(),
        userAgent,
        acceptLanguage,
        timeoutMs,
        cookies: opts.cookies,
        externalSignal: opts.signal,
      });
      tlsRelaxed = true;
    } else {
      // Re-throw with a much clearer message — undici's bare "fetch failed"
      // is useless. Surface the underlying cause so the API caller sees
      // what actually went wrong (DNS, TLS, refused connection, etc.).
      const why = describeCause(err) ?? (err instanceof Error ? err.message : String(err));
      const wrapped = new Error(`Fetch failed for ${rawUrl}: ${why}`);
      (wrapped as Error & { cause?: unknown }).cause = err;
      throw wrapped;
    }
  }

  if (!res.ok) {
    throw new Error(`HTTP ${res.status} ${res.statusText} fetching ${rawUrl}`);
  }
  void tlsRelaxed; // surfaced via `warnings`; reserved for future telemetry

  const arrayBuf = await res.arrayBuffer();
  if (arrayBuf.byteLength > maxBytes) {
    throw new Error(
      `Response too large: ${arrayBuf.byteLength} bytes > ${maxBytes}`,
    );
  }
  const bodyBuf = Buffer.from(arrayBuf);
  const contentType = (res.headers.get("content-type") ?? "").split(";")[0].trim();
  const finalUrl = res.url || rawUrl;

  // Binary passthrough: hand the buffer back to the caller; existing parsers
  // (pdf, docx, xlsx, pptx) will process it.
  if (BINARY_CONTENT_TYPES.has(contentType) || /^image\//.test(contentType)) {
    const suggested = suggestedFilenameFor(finalUrl, contentType);
    return {
      requestedUrl: rawUrl,
      finalUrl,
      fetchedAt: new Date(),
      httpStatus: res.status,
      contentType,
      fetchedBytes: arrayBuf.byteLength,
      isJsRendered: false,
      needsJsRendering: false,
      rawHtml: "",
      cleanedHtml: "",
      textContent: "",
      markdown: "",
      images: [],
      jsonLd: [],
      openGraph: {},
      twitter: {},
      binary: {
        buffer: bodyBuf,
        mimeType: contentType,
        suggestedFileName: suggested,
      },
      warnings,
      scrapeMs: Date.now() - t0,
    };
  }

  // Decode the body. Skip the rest if it doesn't look like HTML at all.
  const charset = detectCharset(res.headers, bodyBuf);
  let rawHtml = decodeBody(bodyBuf, charset);

  // Optional JS rendering. Triggers when EITHER (a) the static result smells
  // like an SPA (the heuristic), OR (b) the caller forced it via Phase B.2's
  // forceJsRender flag (set by ingest.ts when the org configured a headless
  // engine — admin intent wins).
  let isJsRendered = false;
  const textForHeuristic = rawHtml.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  const spaShaped = looksLikeSpa(rawHtml, textForHeuristic.length);
  const shouldRender = (spaShaped || opts.forceJsRender === true) && Boolean(opts.jsRenderer);
  let needsJs = spaShaped;
  if (shouldRender && opts.jsRenderer) {
    try {
      const rendered = await opts.jsRenderer(finalUrl);
      if (rendered?.html && rendered.html.length > rawHtml.length / 2) {
        rawHtml = rendered.html;
        isJsRendered = true;
        needsJs = false;
      }
    } catch (e) {
      warnings.push({
        code: "js_render_failed",
        message: `JS renderer threw: ${e instanceof Error ? e.message : String(e)}`,
      });
    }
  } else if (spaShaped) {
    warnings.push({
      code: "spa_detected",
      message:
        "Page looks JS-rendered; static fetch may have missed body content. " +
        "Pass a `jsRenderer` (e.g., Playwright) for full coverage.",
    });
  }

  // jsdom + Readability for the article body.
  let cleanedHtml = "";
  let textContent = "";
  let articleTitle: string | undefined;
  let langAttr: string | undefined;
  try {
    const dom = new JSDOM(rawHtml, { url: finalUrl });
    langAttr =
      dom.window.document.documentElement.getAttribute("lang") ??
      undefined;
    const reader = new Readability(dom.window.document.cloneNode(true) as Document);
    const parsed = reader.parse();
    if (parsed?.content && parsed.content.replace(/<[^>]+>/g, "").length >= 200) {
      cleanedHtml = parsed.content;
      textContent = parsed.textContent ?? "";
      articleTitle = parsed.title?.trim() || undefined;
    }
  } catch (e) {
    warnings.push({
      code: "readability_failed",
      message: `Readability extraction failed: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  // cheerio for metadata + image walk.
  const $ = cheerio.load(rawHtml);
  const titleTag = $("title").first().text().trim() || undefined;
  const h1 = $("h1").first().text().trim() || undefined;
  const title = articleTitle || titleTag || h1;

  const meta = extractMeta($);
  const jsonLd = extractJsonLd($);

  // Site name preference: og:site_name → registrable host.
  const siteName = meta.og["og:site_name"] || url.host.replace(/^www\./, "");

  // Author / published-time fallback to JSON-LD when meta tags miss.
  let author = meta.author;
  let publishedAt = meta.publishedAt;
  if (!author || !publishedAt) {
    for (const block of jsonLd) {
      if (!block || typeof block !== "object") continue;
      const obj = block as Record<string, unknown>;
      if (!author && typeof obj.author === "string") author = obj.author;
      else if (!author && obj.author && typeof obj.author === "object") {
        const a = obj.author as Record<string, unknown>;
        if (typeof a.name === "string") author = a.name;
      }
      if (!publishedAt && typeof obj.datePublished === "string") {
        const d = new Date(obj.datePublished);
        if (!isNaN(d.getTime())) publishedAt = d;
      }
    }
  }

  const canonicalUrl = meta.canonical
    ? absolutize(meta.canonical, finalUrl) ?? undefined
    : undefined;

  // Language: <html lang> → og:locale → meta description heuristic skipped.
  let language: string | undefined =
    langAttr?.toLowerCase().split("-")[0] || undefined;
  if (!language && meta.og["og:locale"]) {
    language = meta.og["og:locale"].toLowerCase().split(/[_-]/)[0];
  }

  // Build description: prefer og:description → meta description → article intro.
  const description =
    meta.og["og:description"] || meta.description || meta.twitter["twitter:description"];

  // Image extraction (always against the full document — Readability strips
  // hero images that live above the article body).
  const images = extractImages(
    $,
    finalUrl,
    meta.og,
    meta.twitter,
    jsonLd,
    rawHtml,
    maxImages,
  );

  // Markdown rendering for downstream embedding. If cleanedHtml is empty,
  // turndown the whole body as a last resort.
  const mdSource = cleanedHtml || $("body").html() || rawHtml;
  let markdown = "";
  try {
    markdown = turndown().turndown(mdSource);
  } catch (e) {
    warnings.push({
      code: "turndown_failed",
      message: `Markdown rendering failed: ${e instanceof Error ? e.message : String(e)}`,
    });
  }

  return {
    requestedUrl: rawUrl,
    finalUrl,
    fetchedAt: new Date(),
    httpStatus: res.status,
    contentType,
    fetchedBytes: arrayBuf.byteLength,
    isJsRendered,
    needsJsRendering: needsJs,
    rawHtml,
    cleanedHtml,
    textContent,
    markdown,
    title,
    description: description?.trim() || undefined,
    author: author?.trim() || undefined,
    publishedAt,
    language,
    siteName,
    canonicalUrl,
    images,
    jsonLd,
    openGraph: meta.og,
    twitter: meta.twitter,
    warnings,
    scrapeMs: Date.now() - t0,
  };
}

// --- Fetch helpers ---------------------------------------------------------

interface FetchOnceOpts {
  fetchFn: typeof fetch;
  userAgent: string;
  acceptLanguage: string;
  timeoutMs: number;
  cookies?: string;
  /** Caller-supplied abort signal — chains with the per-fetch timeout signal. */
  externalSignal?: AbortSignal;
}

async function fetchOnce(rawUrl: string, opts: FetchOnceOpts): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs);
  // Bridge the external signal (UI stop, request disconnect) into our
  // controller so the underlying fetch + the timeout share one abort.
  const onExternal = () => controller.abort();
  if (opts.externalSignal) {
    if (opts.externalSignal.aborted) controller.abort();
    else opts.externalSignal.addEventListener("abort", onExternal, { once: true });
  }
  try {
    return await opts.fetchFn(rawUrl, {
      method: "GET",
      headers: {
        "User-Agent": opts.userAgent,
        Accept: DEFAULT_ACCEPT,
        "Accept-Language": opts.acceptLanguage,
        "Accept-Encoding": "gzip, deflate, br",
        ...(opts.cookies ? { Cookie: opts.cookies } : {}),
      },
      signal: controller.signal,
      redirect: "follow",
    });
  } finally {
    clearTimeout(timer);
    opts.externalSignal?.removeEventListener("abort", onExternal);
  }
}

// Lazily build one insecure undici Agent (TLS validation off) for reuse —
// the Agent owns a connection pool, so allocating one per request would
// defeat keep-alive. Only used by the auto-fallback path; the default
// happy path uses the user-supplied fetchFn (typically globalThis.fetch
// which trusts Node's bundled + NODE_EXTRA_CA_CERTS bundle).
let _insecureAgent: Agent | undefined;
function insecureFetch(): typeof fetch {
  if (!_insecureAgent) {
    _insecureAgent = new Agent({ connect: { rejectUnauthorized: false } });
  }
  const agent = _insecureAgent;
  return ((input: string | URL | Request, init?: RequestInit) => {
    return undiciFetch(typeof input === "string" ? input : input.toString(), {
      ...(init as Parameters<typeof undiciFetch>[1]),
      dispatcher: agent,
    });
  }) as unknown as typeof fetch;
}

const TLS_CHAIN_ERROR_CODES = new Set([
  "UNABLE_TO_VERIFY_LEAF_SIGNATURE",
  "UNABLE_TO_GET_ISSUER_CERT",
  "UNABLE_TO_GET_ISSUER_CERT_LOCALLY",
  "SELF_SIGNED_CERT_IN_CHAIN",
  "DEPTH_ZERO_SELF_SIGNED_CERT",
  "CERT_HAS_EXPIRED",
  "CERT_NOT_YET_VALID",
  "ERR_TLS_CERT_ALTNAME_INVALID",
]);

function isTlsChainError(err: unknown): boolean {
  let cur: unknown = err;
  while (cur) {
    if (cur instanceof Error) {
      const code = (cur as Error & { code?: string }).code;
      if (code && TLS_CHAIN_ERROR_CODES.has(code)) return true;
      // Some Node versions only set the message, not the code.
      const msg = cur.message ?? "";
      if (
        /unable to verify the first certificate/i.test(msg) ||
        /self[- ]signed certificate/i.test(msg) ||
        /certificate has expired/i.test(msg) ||
        /unable to get local issuer certificate/i.test(msg)
      ) {
        return true;
      }
      cur = (cur as Error & { cause?: unknown }).cause;
    } else {
      break;
    }
  }
  return false;
}

function describeCause(err: unknown): string | undefined {
  let cur: unknown = err;
  let depth = 0;
  while (cur && depth < 5) {
    if (cur instanceof Error) {
      const code = (cur as Error & { code?: string }).code;
      if (code) return `${code} (${cur.message})`;
      if (depth > 0 && cur.message) return cur.message;
      cur = (cur as Error & { cause?: unknown }).cause;
    } else {
      break;
    }
    depth++;
  }
  return err instanceof Error ? err.message : undefined;
}

// --- Site crawl ------------------------------------------------------------
//
// Follows internal `<a href>` links from a seed page, BFS, until we hit
// `maxPages` or run out. Polite by default: respects robots.txt per host
// and rate-limits per host.

export interface CrawlOptions extends ScrapeOptions {
  /** Cap on total pages scraped (including the seed). Default 20. */
  maxPages?: number;
  /** Max BFS depth. Default 2. */
  maxDepth?: number;
  /** Same-origin only? Default true. */
  sameOriginOnly?: boolean;
  /** Path glob prefixes to allow (e.g. ["/blog/", "/docs/"]). Default [] = all. */
  pathAllowPrefixes?: string[];
  /** Path glob prefixes to skip. Default common nuisances. */
  pathDenyPrefixes?: string[];
  /** Per-host min delay between requests (ms). Default 750. */
  perHostDelayMs?: number;
  /** Per-page progress callback. Survives a single page failure. */
  onPage?: (page: { url: string; ok: boolean; error?: string; doc?: ScrapedDocument }) => void | Promise<void>;
}

export interface CrawledPage {
  url: string;
  ok: boolean;
  error?: string;
  doc?: ScrapedDocument;
}

const DEFAULT_DENY_PREFIXES = [
  "/wp-admin/",
  "/wp-login",
  "/login",
  "/signin",
  "/signup",
  "/register",
  "/cart",
  "/checkout",
  "/feed",
  "/tag/",
  "/category/",
  "/?",         // most pagination junk uses query strings
];

// Skip URLs that obviously point at non-HTML assets we don't want to crawl
// (the scraper will follow them once and then ingest if HTML; for crawl we
// hard-skip these so we don't waste budget on them).
const SKIP_EXTENSIONS = new Set([
  "css", "js", "json", "xml", "txt", "pdf", "doc", "docx", "xls", "xlsx",
  "ppt", "pptx", "zip", "gz", "tar", "rar", "7z", "mp3", "mp4", "mov", "avi",
  "wmv", "webm", "ogg", "wav", "ico", "ttf", "woff", "woff2", "eot",
  "png", "jpg", "jpeg", "webp", "gif", "avif", "svg", "bmp",
]);

function shouldCrawlUrl(
  candidate: URL,
  seed: URL,
  opts: CrawlOptions,
): boolean {
  if (candidate.protocol !== "http:" && candidate.protocol !== "https:") return false;
  if (opts.sameOriginOnly !== false && candidate.origin !== seed.origin) return false;
  // Filter by extension
  const last = candidate.pathname.split("/").pop() ?? "";
  const dot = last.lastIndexOf(".");
  if (dot > 0) {
    const ext = last.slice(dot + 1).toLowerCase();
    if (SKIP_EXTENSIONS.has(ext)) return false;
  }
  // Allow / deny prefixes
  const allow = opts.pathAllowPrefixes ?? [];
  if (allow.length > 0 && !allow.some((p) => candidate.pathname.startsWith(p))) return false;
  const deny = opts.pathDenyPrefixes ?? DEFAULT_DENY_PREFIXES;
  if (deny.some((p) => candidate.pathname.startsWith(p))) return false;
  return true;
}

function extractInternalLinks(
  rawHtml: string,
  baseUrl: string,
): string[] {
  const out = new Set<string>();
  const re = /<a\b[^>]*\bhref=["']([^"']+)["'][^>]*>/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(rawHtml))) {
    const href = m[1].trim();
    if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("javascript:")) continue;
    const abs = absolutize(href, baseUrl);
    if (!abs) continue;
    // Strip fragment for dedupe
    try {
      const u = new URL(abs);
      u.hash = "";
      out.add(u.toString());
    } catch {
      // skip
    }
  }
  return Array.from(out);
}

/**
 * BFS crawl from `seedUrl`. Returns one CrawledPage per visited URL.
 *
 * Strategy:
 *   1. Scrape seed page (full extractor, including image + link harvest).
 *   2. Enqueue every same-origin <a href> link that passes shouldCrawlUrl.
 *   3. Per-host delay before each next fetch so we're a good citizen.
 *   4. Stop when maxPages reached or queue is empty.
 *
 * The crawl is best-effort: a single page failure becomes a CrawledPage with
 * `ok: false` and the loop continues. The seed-page failure throws (since
 * there's nothing else to crawl from).
 */
export async function scrapeSite(
  seedUrl: string,
  opts: CrawlOptions = {},
): Promise<CrawledPage[]> {
  const seed = new URL(seedUrl);
  // Default is "scrape the entire site" — bounded by the server-side
  // hard ceiling (currently 500). The UI sends an explicit number only
  // when the user ticks "Scrape pages" with a smaller cap.
  const maxPages = opts.maxPages ?? 500;
  // Default depth is effectively unbounded: BFS terminates on the page
  // budget, not the depth. The old default (2) caused "Crawl entire site"
  // to silently stop at ~60-80 pages on medium sites — every deeper link
  // got dropped on the floor. Callers who want a shallow crawl pass an
  // explicit small number.
  const maxDepth = opts.maxDepth ?? 50;
  const perHostDelayMs = opts.perHostDelayMs ?? 750;

  const visited = new Set<string>();
  const results: CrawledPage[] = [];
  const queue: Array<{ url: string; depth: number }> = [
    { url: seed.toString(), depth: 0 },
  ];
  const lastFetchByHost = new Map<string, number>();

  async function politeWait(host: string) {
    const last = lastFetchByHost.get(host) ?? 0;
    const wait = perHostDelayMs - (Date.now() - last);
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
    lastFetchByHost.set(host, Date.now());
  }

  while (queue.length > 0 && results.length < maxPages) {
    // Honour caller abort BEFORE dequeuing the next URL so a stop button
    // takes effect even mid-rate-limit-wait.
    if (opts.signal?.aborted) break;
    const { url, depth } = queue.shift()!;
    if (visited.has(url)) continue;
    visited.add(url);

    let u: URL;
    try {
      u = new URL(url);
    } catch {
      continue;
    }

    await politeWait(u.host);
    if (opts.signal?.aborted) break;

    let entry: CrawledPage;
    try {
      const doc = await scrapeUrl(url, opts);
      entry = { url, ok: true, doc };
      // Harvest links for the next BFS level (unless we hit the depth cap).
      if (depth < maxDepth && doc.rawHtml) {
        const links = extractInternalLinks(doc.rawHtml, doc.finalUrl);
        for (const link of links) {
          if (visited.has(link)) continue;
          let cu: URL;
          try {
            cu = new URL(link);
          } catch {
            continue;
          }
          if (!shouldCrawlUrl(cu, seed, opts)) continue;
          queue.push({ url: link, depth: depth + 1 });
        }
      }
    } catch (err) {
      entry = {
        url,
        ok: false,
        error: err instanceof Error ? err.message : String(err),
      };
      // If the seed itself failed, the user wants to know — bubble up.
      if (results.length === 0) throw err;
    }
    results.push(entry);
    if (opts.onPage) {
      try {
        await opts.onPage(entry);
      } catch {
        // onPage failures must never break the crawl loop
      }
    }
  }

  return results;
}

function suggestedFilenameFor(url: string, mime: string): string {
  try {
    const u = new URL(url);
    const last = u.pathname.split("/").filter(Boolean).pop();
    if (last && /\.\w{2,5}$/.test(last)) return last;
    const ext = extForMime(mime);
    return last ? `${last}.${ext}` : `download.${ext}`;
  } catch {
    return `download.${extForMime(mime)}`;
  }
}

function extForMime(mime: string): string {
  if (mime === "application/pdf") return "pdf";
  if (mime === "application/msword") return "doc";
  if (mime === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") return "docx";
  if (mime === "application/vnd.ms-excel") return "xls";
  if (mime === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") return "xlsx";
  if (mime === "application/vnd.ms-powerpoint") return "ppt";
  if (mime === "application/vnd.openxmlformats-officedocument.presentationml.presentation") return "pptx";
  const m = mime.match(/^image\/(\w+)/);
  if (m) return m[1] === "jpeg" ? "jpg" : m[1];
  return "bin";
}

/**
 * Render a ScrapedDocument back as a self-contained HTML file suitable for
 * the existing html-parser → image-fetch → chunker pipeline. We wrap the
 * cleaned article body with the page's title, description, canonical URL,
 * and the discovered image URLs as `<img>` tags (so image-fetch hydrates
 * them on the standard ingest path).
 *
 * `opts.scrapeImages` controls whether the image URLs are emitted at all —
 * when false, the function strips every `<img>` from the cleaned body and
 * omits the extra-images section, so the parser pipeline downstream skips
 * the per-image fetch + CLIP embed entirely.
 */
export function scrapedToHtml(
  doc: ScrapedDocument,
  opts: { scrapeImages?: boolean } = {},
): string {
  const includeImages = opts.scrapeImages !== false;
  const esc = (s: string) =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

  const head: string[] = [];
  head.push("<!DOCTYPE html>");
  head.push(`<html${doc.language ? ` lang="${esc(doc.language)}"` : ""}>`);
  head.push("<head>");
  head.push('<meta charset="utf-8" />');
  // Signal to html-parser that this is OUR rendered output (Readability has
  // already run once during scrape — running it again strips the hero +
  // trailing image figures we injected, dropping image count to 0).
  head.push('<meta name="autorfp-scraped" content="1" />');
  if (doc.title) head.push(`<title>${esc(doc.title)}</title>`);
  if (doc.description) {
    head.push(`<meta name="description" content="${esc(doc.description)}" />`);
  }
  if (doc.canonicalUrl) {
    head.push(`<link rel="canonical" href="${esc(doc.canonicalUrl)}" />`);
  }
  head.push(`<link rel="source-url" href="${esc(doc.finalUrl)}" />`);
  if (doc.author) head.push(`<meta name="author" content="${esc(doc.author)}" />`);
  if (doc.publishedAt) {
    head.push(`<meta name="article:published_time" content="${doc.publishedAt.toISOString()}" />`);
  }
  if (doc.siteName) head.push(`<meta name="og:site_name" content="${esc(doc.siteName)}" />`);
  head.push("</head>");
  head.push("<body>");

  const body: string[] = [];
  if (doc.title) body.push(`<h1>${esc(doc.title)}</h1>`);
  if (doc.description) body.push(`<p><em>${esc(doc.description)}</em></p>`);

  // Strip every <img> and <picture> from the cleaned article body. Readability
  // preserves lazy-loaded `<img src="data:image/svg+xml..." data-src="REAL">`
  // tags with the SVG PLACEHOLDER as `src` — which (a) confuses image-fetch
  // (it'd try to embed a 1x1 transparent placeholder via CLIP), and (b)
  // confuses the extras dedupe below (placeholder URLs ≠ real URLs, so
  // we'd double-emit). We always re-emit images in the canonical bag with
  // the real URLs we already resolved.
  const articleHtml = doc.cleanedHtml
    ? doc.cleanedHtml.replace(/<img\b[^>]*>/gi, "").replace(/<picture[\s\S]*?<\/picture>/gi, "")
    : `<pre>${esc(doc.textContent)}</pre>`;

  if (includeImages) {
    // Heroes first (og/twitter cards) so image-fetch picks them as the lead.
    const heroes = doc.images.filter((i) => i.role === "og" || i.role === "twitter");
    for (const h of heroes) {
      body.push(
        `<figure><img src="${esc(h.url)}"${h.alt ? ` alt="${esc(h.alt)}"` : ""} /></figure>`,
      );
    }
  }

  body.push(articleHtml);

  if (includeImages) {
    // Every non-hero image, deduped by URL. No need to filter against cleanedHtml
    // since we stripped all <img> from it above.
    const seen = new Set<string>();
    const extras = doc.images.filter((i) => {
      if (i.role === "og" || i.role === "twitter") return false;
      if (seen.has(i.url)) return false;
      seen.add(i.url);
      return true;
    });
    if (extras.length > 0) {
      body.push('<section class="autorfp-extra-images">');
      body.push("<h2>Additional images</h2>");
      for (const img of extras) {
        body.push(
          `<figure><img src="${esc(img.url)}"${img.alt ? ` alt="${esc(img.alt)}"` : ""} />${
            img.caption ? `<figcaption>${esc(img.caption)}</figcaption>` : ""
          }</figure>`,
        );
      }
      body.push("</section>");
    }
  }

  body.push(
    `<footer><small>Source: <a href="${esc(doc.finalUrl)}">${esc(doc.finalUrl)}</a></small></footer>`,
  );

  return [...head, ...body, "</body>", "</html>"].join("\n");
}
