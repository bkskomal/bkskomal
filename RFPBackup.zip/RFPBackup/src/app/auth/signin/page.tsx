import Link from "next/link";
import { redirect } from "next/navigation";
import { ShieldCheck } from "lucide-react";
import { signIn, enabledOAuthProviders } from "@/lib/auth";
import { findSamlRouteForEmail } from "@/lib/saml/config";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function SignInPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string; error?: string }>;
}) {
  return (
    <div className="grid min-h-screen place-items-center bg-background p-6">
      <div className="absolute inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-gradient-to-br from-primary/20 via-fuchsia-500/10 to-transparent blur-3xl" />
      </div>
      <div className="w-full max-w-md">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/oati-logo.png" alt="OATI" className="h-11 w-11 rounded-lg object-cover" />
          <span className="text-xl font-bold tracking-tight">
            OATI <span className="font-normal text-muted-foreground">AutoRFP</span>
          </span>
        </Link>
        <div className="rounded-2xl border bg-card p-8 shadow-xl">
          <h1 className="text-2xl font-semibold tracking-tight">Welcome back</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            We&apos;ll email you a magic sign-in link.
          </p>
          <SignInForm searchParamsPromise={searchParams} />
        </div>
      </div>
    </div>
  );
}

async function SignInForm({
  searchParamsPromise,
}: {
  searchParamsPromise: Promise<{ callbackUrl?: string; error?: string }>;
}) {
  const sp = await searchParamsPromise;
  const oauth = enabledOAuthProviders();
  const callbackUrl = sp.callbackUrl ?? "/dashboard";
  return (
    <div className="mt-6 space-y-4">
      <form
        action={async (formData) => {
          "use server";
          const email = String(formData.get("sso_email") ?? "").trim().toLowerCase();
          if (!email || !email.includes("@")) {
            redirect("/auth/signin?error=SSO_NoEmail");
          }
          const hit = await findSamlRouteForEmail(email);
          if (hit) {
            redirect(`/api/auth/saml/${encodeURIComponent(hit.orgSlug)}/login`);
          }
          // No SAML config for that domain — drop back to the regular form.
          redirect("/auth/signin?error=SSO_NotConfigured");
        }}
        className="space-y-3 rounded-lg border bg-card/70 p-4"
      >
        <div className="flex items-center gap-2 text-sm font-medium">
          <ShieldCheck className="h-4 w-4 text-primary" />
          Sign in with SSO
        </div>
        <p className="text-xs text-muted-foreground">
          For enterprise customers with a SAML IdP configured.
        </p>
        <div className="space-y-2">
          <Label htmlFor="sso_email" className="sr-only">
            Work email
          </Label>
          <Input
            id="sso_email"
            name="sso_email"
            type="email"
            placeholder="you@company.com"
          />
        </div>
        <Button type="submit" variant="outline" className="w-full" size="lg">
          Continue with SSO
        </Button>
      </form>
      {oauth.length > 0 ? (
        <>
          <div className="space-y-2">
            {oauth.map((p) => (
              <form
                key={p.id}
                action={async () => {
                  "use server";
                  await signIn(p.id, { redirectTo: callbackUrl });
                }}
              >
                <Button type="submit" variant="outline" className="w-full" size="lg">
                  Continue with {p.label}
                </Button>
              </form>
            ))}
          </div>
          <div className="relative my-2">
            <div className="absolute inset-0 flex items-center">
              <span className="w-full border-t" />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-2 text-muted-foreground">
                or continue with email
              </span>
            </div>
          </div>
        </>
      ) : null}
      <form
        action={async (formData) => {
          "use server";
          await signIn("nodemailer", {
            email: String(formData.get("email") ?? ""),
            redirectTo: callbackUrl,
          });
        }}
        className="space-y-4"
      >
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" placeholder="you@company.com" required />
        </div>
        {sp.error ? (
          <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {sp.error === "EmailSignin"
              ? "Couldn’t send sign-in email. Check SMTP settings."
              : sp.error === "SSO_NoEmail"
                ? "Enter your work email to continue with SSO."
                : sp.error === "SSO_NotConfigured"
                  ? "SSO isn’t configured for that domain. Try a magic link or OAuth below."
                  : "Sign-in failed. Try again."}
          </p>
        ) : null}
        <Button type="submit" variant="gradient" className="w-full" size="lg">
          Send magic link
        </Button>
        {process.env.NODE_ENV === "development" || process.env.ENABLE_DEV_AUTH === "1" ? (
          <Link
            href="/auth/dev"
            className="block text-center text-xs text-amber-600 dark:text-amber-400 hover:underline"
          >
            Dev shortcut: skip email →
          </Link>
        ) : null}
        <p className="text-center text-xs text-muted-foreground">
          By continuing you agree to OATI AutoRFP&apos;s terms.
        </p>
      </form>
    </div>
  );
}
