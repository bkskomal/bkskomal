// Dev sign-in shortcut. Skips the magic-link email entirely so you can click
// around the app without configuring SMTP. Enabled when:
//   - NODE_ENV === "development", OR
//   - ENABLE_DEV_AUTH === "1" (explicit opt-in for local prod-mode testing)
//
// Visit /auth/dev to use it. Never set ENABLE_DEV_AUTH=1 on a public host.

import { redirect } from "next/navigation";
import Link from "next/link";
import { AlertTriangle } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Force runtime evaluation. Without this, Next pre-renders the env-var check
// at build time — so ENABLE_DEV_AUTH set on `pnpm start` is ignored and the
// page permanently redirects to /auth/signin.
export const dynamic = "force-dynamic";

function devAuthEnabled(): boolean {
  return process.env.NODE_ENV === "development" || process.env.ENABLE_DEV_AUTH === "1";
}

export default async function DevSignInPage() {
  if (!devAuthEnabled()) {
    redirect("/auth/signin");
  }

  async function devSignIn(formData: FormData) {
    "use server";
    if (!devAuthEnabled()) {
      throw new Error("Dev sign-in disabled");
    }

    const { auth } = await import("@/lib/auth");
    const { cookies } = await import("next/headers");
    const { randomBytes } = await import("node:crypto");

    const email = String(formData.get("email") ?? "").trim().toLowerCase();
    const name = String(formData.get("name") ?? "").trim() || email.split("@")[0];
    if (!email || !email.includes("@")) throw new Error("Valid email required");

    // Upsert the user (NextAuth's PrismaAdapter expects this shape).
    const user = await prisma.user.upsert({
      where: { email },
      update: { name, emailVerified: new Date() },
      create: { email, name, emailVerified: new Date() },
    });

    // Create a database session matching NextAuth's session strategy.
    const sessionToken = randomBytes(32).toString("hex");
    const expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days
    await prisma.session.create({
      data: { sessionToken, userId: user.id, expires },
    });

    // Set the auth.js session cookie. Auth.js v5 cookie name in dev:
    // "authjs.session-token" (no __Secure- prefix unless https).
    const c = await cookies();
    c.set("authjs.session-token", sessionToken, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      expires,
    });

    redirect("/dashboard");
  }

  return (
    <div className="grid min-h-screen place-items-center bg-background p-6">
      <div className="absolute inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-gradient-to-br from-amber-500/20 via-fuchsia-500/10 to-transparent blur-3xl" />
      </div>
      <div className="w-full max-w-md">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/oati-logo.png" alt="OATI" className="h-11 w-11 rounded-lg object-cover" />
          <span className="text-xl font-bold tracking-tight">
            OATI <span className="font-normal text-muted-foreground">AutoRFP</span>
          </span>
        </Link>
        <div className="rounded-2xl border bg-card p-8 shadow-xl">
          <div className="mb-4 flex items-start gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-300">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <div>
              <strong>Dev shortcut.</strong> This route bypasses email verification and only
              works when <code>NODE_ENV=development</code>. Don&apos;t deploy to production.
            </div>
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Dev sign-in</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Skip the magic link. Pick any email — a user will be created if needed.
          </p>
          <form action={devSignIn} className="mt-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                defaultValue="dev@autorfp.local"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Display name (optional)</Label>
              <Input id="name" name="name" type="text" defaultValue="Dev User" />
            </div>
            <Button type="submit" variant="gradient" className="w-full" size="lg">
              Sign in
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
