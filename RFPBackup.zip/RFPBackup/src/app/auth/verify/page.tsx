import Link from "next/link";
import { Mail } from "lucide-react";

export default function VerifyPage() {
  return (
    <div className="grid min-h-screen place-items-center bg-background p-6">
      <div className="w-full max-w-md rounded-2xl border bg-card p-8 text-center shadow-xl">
        <div className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-primary/10">
          <Mail className="h-6 w-6 text-primary" />
        </div>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight">Check your email</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          A sign-in link has been sent to your email address. Click it to continue. The link
          expires in 24 hours.
        </p>
        <Link
          href="/auth/signin"
          className="mt-6 inline-block text-sm text-primary underline-offset-4 hover:underline"
        >
          ← Use a different email
        </Link>
      </div>
    </div>
  );
}
