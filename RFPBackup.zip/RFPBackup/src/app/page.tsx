import Link from "next/link";
import { ArrowRight, Sparkles, FileText, Users, Search, MessageSquare, Wrench } from "lucide-react";
import { Button } from "@/components/ui/button";

const FEATURES = [
  { icon: FileText, title: "Auto question extraction", body: "Drop in a Word, PDF, Excel, or PowerPoint RFP — every question is structured automatically." },
  { icon: Search, title: "Knowledge-grounded answers", body: "Responses are grounded in your own knowledge base with inline source citations on every claim." },
  { icon: MessageSquare, title: "Streaming multi-step reasoning", body: "Watch the model analyze, search, draft, and cite — live. No black boxes." },
  { icon: Wrench, title: "Tool-using agents", body: "The model can call tools — knowledge search, calculations, custom org tools — while it answers." },
  { icon: Sparkles, title: "Golden answers + feedback loop", body: "Pin perfect answers as references and rate every response. Quality compounds over time." },
  { icon: Users, title: "Multi-tenant, role-based", body: "Organizations, projects, owner / admin / member roles, and per-org knowledge bases." },
];

export default function LandingPage() {
  return (
    <div className="relative min-h-screen overflow-hidden bg-background">
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-gradient-to-br from-primary/30 via-fuchsia-500/20 to-transparent blur-3xl" />
        <div className="absolute right-0 top-1/3 h-[400px] w-[400px] rounded-full bg-sky-500/10 blur-3xl" />
      </div>

      <header className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/oati-logo.png" alt="OATI" className="h-9 w-9 rounded-lg object-cover" />
          <span className="text-lg font-bold tracking-tight">
            OATI <span className="font-normal text-muted-foreground">AutoRFP</span>
          </span>
        </Link>
        <nav className="flex items-center gap-2">
          <Button asChild variant="ghost">
            <Link href="/auth/signin">Sign in</Link>
          </Button>
          <Button asChild variant="gradient">
            <Link href="/auth/signin">Get started</Link>
          </Button>
        </nav>
      </header>

      <main className="container">
        <section className="py-24 text-center">
          <div className="mx-auto inline-flex items-center gap-2 rounded-full border bg-background/60 px-3 py-1 text-xs font-medium backdrop-blur">
            <Sparkles className="h-3 w-3 text-primary" />
            AI proposals, grounded in your knowledge base
          </div>
          <h1 className="mt-6 text-5xl font-bold leading-tight tracking-tight sm:text-7xl">
            Respond to RFPs <br />
            <span className="text-gradient">80% faster.</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
            Upload an RFP, get a structured list of every question, and generate cited responses
            from your own knowledge base — running on your own self-hosted models. No data leaves
            your infrastructure.
          </p>
          <div className="mt-8 flex justify-center gap-3">
            <Button asChild size="lg" variant="gradient">
              <Link href="/auth/signin">
                Start for free <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="#features">See features</Link>
            </Button>
          </div>
        </section>

        <section id="features" className="grid gap-4 pb-24 md:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="group relative overflow-hidden rounded-2xl border bg-card p-6 transition-all hover:shadow-lg hover:-translate-y-0.5"
            >
              <div className="absolute inset-x-0 -top-px h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/10 text-primary">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </section>
      </main>

      <footer className="border-t py-8 text-center text-sm text-muted-foreground">
        OATI AutoRFP · Self-hosted, open AI · Built with Next.js 15
      </footer>
    </div>
  );
}
