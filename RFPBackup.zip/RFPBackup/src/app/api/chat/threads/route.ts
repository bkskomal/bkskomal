import { NextRequest } from "next/server";
import { z } from "zod";
import { ChatScope } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership, requireUser } from "@/lib/authz";
import { ForbiddenError, ValidationError } from "@/lib/errors";

const createSchema = z
  .object({
    organizationId: z.string(),
    scope: z.nativeEnum(ChatScope),
    projectId: z.string().nullish(),
    rfpId: z.string().nullish(),
    indexId: z.string().nullish(),
    title: z.string().max(120).optional(),
  })
  .refine(
    (v) => {
      if (v.scope === "PROJECT") return !!v.projectId;
      if (v.scope === "RFP") return !!v.rfpId;
      if (v.scope === "INDEX") return !!v.indexId;
      return true;
    },
    { message: "Scope requires the matching reference id (projectId / rfpId / indexId)" },
  );

export const GET = withApiHandler(async (req) => {
  const user = await requireUser();
  const url = new URL(req.url);
  const orgId = url.searchParams.get("organizationId");
  const rfpId = url.searchParams.get("rfpId") ?? undefined;
  const projectId = url.searchParams.get("projectId") ?? undefined;
  const indexId = url.searchParams.get("indexId") ?? undefined;
  if (!orgId) throw new ValidationError("organizationId is required");

  await requireMembership(orgId);

  const threads = await prisma.chatThread.findMany({
    where: {
      organizationId: orgId,
      ...(rfpId ? { rfpId } : {}),
      ...(projectId ? { projectId } : {}),
      ...(indexId ? { indexId } : {}),
    },
    orderBy: { updatedAt: "desc" },
    take: 50,
    include: { _count: { select: { messages: true } } },
  });
  return Response.json({ threads });
});

export const POST = withApiHandler(async (req) => {
  const user = await requireUser();
  const body = createSchema.parse(await req.json());
  await requireMembership(body.organizationId);

  // Cross-check the scope reference belongs to the org.
  if (body.projectId) {
    const p = await prisma.project.findUnique({ where: { id: body.projectId } });
    if (!p || p.organizationId !== body.organizationId) throw new ForbiddenError("Project scope mismatch");
  }
  if (body.rfpId) {
    const r = await prisma.rFP.findUnique({ where: { id: body.rfpId }, include: { project: true } });
    if (!r || r.project.organizationId !== body.organizationId) throw new ForbiddenError("RFP scope mismatch");
  }
  if (body.indexId) {
    const i = await prisma.knowledgeIndex.findUnique({ where: { id: body.indexId } });
    if (!i || i.organizationId !== body.organizationId) throw new ForbiddenError("Index scope mismatch");
  }

  const thread = await prisma.chatThread.create({
    data: {
      organizationId: body.organizationId,
      scope: body.scope,
      projectId: body.projectId ?? null,
      rfpId: body.rfpId ?? null,
      indexId: body.indexId ?? null,
      title: body.title ?? "New chat",
      createdById: user.id,
    },
  });
  return Response.json({ thread }, { status: 201 });
});
