import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";

async function loadThread(threadId: string, userId: string) {
  const thread = await prisma.chatThread.findUnique({
    where: { id: threadId },
    include: {
      messages: { orderBy: { createdAt: "asc" } },
      project: { select: { id: true, name: true } },
      rfp: { select: { id: true, title: true } },
      index: { select: { id: true, name: true } },
    },
  });
  if (!thread) throw new NotFoundError("Thread not found");
  const member = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId, organizationId: thread.organizationId } },
  });
  if (!member) throw new ForbiddenError("Not a member of this organization");
  return thread;
}

export const GET = withApiHandler<{ threadId: string }>(async (_req, { params }) => {
  const { threadId } = await params;
  const user = await requireUser();
  const thread = await loadThread(threadId, user.id);
  return Response.json({ thread });
});

export const DELETE = withApiHandler<{ threadId: string }>(async (_req, { params }) => {
  const { threadId } = await params;
  const user = await requireUser();
  const thread = await loadThread(threadId, user.id);
  await prisma.chatThread.delete({ where: { id: thread.id } });
  return Response.json({ ok: true });
});
