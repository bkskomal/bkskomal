import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { runChatTurn, generateThreadTitle, type ChatStep } from "@/lib/ai/chat";
import { runAgenticChatTurn } from "@/lib/ai/agents/agentic-chat";
import { runExternalChatTurn } from "@/lib/ai/external-chat";
import { resolveAiConfig } from "@/lib/ai/config";
import { rateLimit, RATE_LIMITS, RateLimitError } from "@/lib/rate-limit";

const bodySchema = z.object({
  content: z.string().min(1).max(8000),
  enableTools: z.boolean().optional(),
  // Phase C: opt-in research-agent mode. When true, the chat route dispatches
  // to runAgenticChatTurn (LangGraph plan→search→draft→critique→revise loop)
  // instead of the single-shot runChatTurn. Mutually exclusive with tools.
  enableAgentic: z.boolean().optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ threadId: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return new Response("Unauthorized", { status: 401 });
  const userId = session.user.id;

  const { threadId } = await params;
  const body = bodySchema.parse(await req.json());

  const thread = await prisma.chatThread.findUnique({
    where: { id: threadId },
    include: { _count: { select: { messages: true } } },
  });
  if (!thread) return new Response("Not found", { status: 404 });

  const member = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId, organizationId: thread.organizationId } },
  });
  if (!member) return new Response("Forbidden", { status: 403 });

  try {
    await rateLimit(RATE_LIMITS.chat, {
      userId,
      orgId: thread.organizationId,
      route: "chat/messages",
    });
  } catch (e) {
    if (e instanceof RateLimitError) {
      return new Response(
        JSON.stringify({ error: e.message, code: e.code, retryAfterSeconds: e.retryAfterSeconds }),
        {
          status: 429,
          headers: {
            "Content-Type": "application/json",
            "Retry-After": String(e.retryAfterSeconds),
          },
        },
      );
    }
    throw e;
  }

  // If this is the first user message, kick off a title generation in the background.
  const isFirstMessage = thread._count.messages === 0;

  const stream = new ReadableStream({
    async start(controller) {
      const enc = new TextEncoder();
      const send = (event: string, data: unknown) => {
        controller.enqueue(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      send("start", { threadId });

      try {
        // Phase E: external chat provider wins over Internal/Agent paths
        // when the org configured one. Tools + Agent toggles are ignored —
        // the remote service owns its own retrieval and loop.
        const chatCfg = (await resolveAiConfig(thread.organizationId)).chatProvider;
        const userRow = await prisma.user.findUnique({
          where: { id: userId },
          select: { id: true, name: true, email: true },
        });
        const result = chatCfg.kind === "OATI_USER_PROMPT" && chatCfg.endpoint
          ? await runExternalChatTurn({
              threadId,
              userMessage: body.content,
              organizationId: thread.organizationId,
              scope: thread.scope,
              user: userRow ?? { id: userId, name: null, email: null },
              onStep: (step: ChatStep) => send("step", step),
            })
          // Phase C: dispatch to the agentic path when the user toggled it on.
          // Otherwise the standard single-shot runChatTurn (current behavior).
          : body.enableAgentic
          ? await runAgenticChatTurn({
              threadId,
              userMessage: body.content,
              organizationId: thread.organizationId,
              scope: thread.scope,
              scopedIndexId: thread.indexId,
              onStep: (step: ChatStep) => send("step", step),
            })
          : await runChatTurn({
              threadId,
              userMessage: body.content,
              ctx: {
                organizationId: thread.organizationId,
                projectId: thread.projectId ?? undefined,
                rfpId: thread.rfpId ?? undefined,
                defaultIndexId: thread.indexId ?? null,
                userId,
              },
              scope: thread.scope,
              scopedIndexId: thread.indexId,
              rfpId: thread.rfpId,
              projectId: thread.projectId,
              enableTools: body.enableTools,
              onStep: (step: ChatStep) => send("step", step),
            });

        send("done", {
          assistantMessageId: result.assistantMessageId,
          content: result.content,
          metadata: result.metadata,
        });

        if (isFirstMessage) {
          const title = await generateThreadTitle(body.content, thread.organizationId);
          await prisma.chatThread.update({ where: { id: threadId }, data: { title } });
          send("title", { title });
        }
      } catch (e) {
        const message = e instanceof Error ? e.message : String(e);
        send("error", { message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
