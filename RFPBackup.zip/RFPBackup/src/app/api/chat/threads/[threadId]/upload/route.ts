// Chat attachment upload — accept a single file from the chat UI, ingest it
// into a per-org "Chat Uploads" KB index (auto-created on first use), and
// return the new Document so the chat can mention it (and the LLM can call
// `start_rfp_process` referencing the documentId later).

import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError, ValidationError } from "@/lib/errors";
import { detectMime } from "@/lib/parsers";
import { saveUpload } from "@/lib/storage";
import { ingestDocument } from "@/lib/indexing";

export const POST = withApiHandler<{ threadId: string }>(async (req, { params }) => {
  const { threadId } = await params;
  const user = await requireUser();

  // Auth: caller must be a member of the thread's org.
  const thread = await prisma.chatThread.findUnique({
    where: { id: threadId },
    select: { id: true, organizationId: true, indexId: true },
  });
  if (!thread) throw new NotFoundError("Thread not found");
  const member = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: thread.organizationId } },
  });
  if (!member) throw new ForbiddenError("Not a member of this organization");

  const form = await (req as NextRequest).formData();
  const file = form.get("file");
  if (!(file instanceof File)) throw new ValidationError("Missing file");
  const mime = detectMime(file.name);
  if (!mime) throw new ValidationError(`Unsupported file type: ${file.name}`);

  // Pick the target index. If the chat is scoped to a specific KB, use that;
  // otherwise route into a per-org "Chat Uploads" index, auto-created on
  // first use. This keeps drag-and-drop in chat from polluting every KB.
  let targetIndexId = thread.indexId;
  if (!targetIndexId) {
    const existing = await prisma.knowledgeIndex.findFirst({
      where: { organizationId: thread.organizationId, name: "Chat Uploads" },
      select: { id: true },
    });
    if (existing) {
      targetIndexId = existing.id;
    } else {
      const created = await prisma.knowledgeIndex.create({
        data: {
          organizationId: thread.organizationId,
          name: "Chat Uploads",
          description: "Files dropped into the chat assistant. Auto-created.",
        },
        select: { id: true },
      });
      targetIndexId = created.id;
    }
  }

  const buf = Buffer.from(await file.arrayBuffer());
  const { storagePath } = await saveUpload(`index/${targetIndexId}`, file.name, buf);

  const doc = await prisma.document.create({
    data: {
      indexId: targetIndexId,
      name: file.name,
      fileName: file.name,
      fileSize: file.size,
      mimeType: mime,
      storagePath,
    },
    select: { id: true, name: true, fileName: true, fileSize: true, mimeType: true, status: true },
  });

  // Kick off chunking + embedding in the background. The chat can ask
  // questions about the file once status flips to INDEXED.
  ingestDocument(doc.id).catch((err) => console.error("[chat-upload ingest]", err));

  return Response.json(
    {
      document: doc,
      indexId: targetIndexId,
      note:
        "File received and indexing started. The chat assistant can now reference this document " +
        "by id. Ask `Start an RFP process from this document` to convert it to an RFP.",
    },
    { status: 201 },
  );
});
