import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";

export const POST = withApiHandler(async () => {
  const user = await requireUser();
  const r = await prisma.notification.updateMany({
    where: { userId: user.id, read: false },
    data: { read: true },
  });
  return Response.json({ updated: r.count });
});
