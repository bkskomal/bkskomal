import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";

const bodySchema = z.object({ read: z.boolean().default(true) }).optional();

export const POST = withApiHandler<{ id: string }>(async (req, { params }) => {
  const { id } = await params;
  const user = await requireUser();
  const n = await prisma.notification.findUnique({ where: { id } });
  if (!n) throw new NotFoundError("Notification not found");
  if (n.userId !== user.id) throw new ForbiddenError("Not yours");
  const parsed = bodySchema.parse(await req.json().catch(() => ({})));
  const read = parsed?.read ?? true;
  const updated = await prisma.notification.update({ where: { id }, data: { read } });
  return Response.json({ notification: updated });
});
