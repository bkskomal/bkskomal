import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";

export const GET = withApiHandler(async (req) => {
  const user = await requireUser();
  const url = new URL(req.url);
  const unreadOnly = url.searchParams.get("unread") === "1";
  const take = Math.min(Number(url.searchParams.get("take") ?? 30), 100);

  const [items, unreadCount] = await Promise.all([
    prisma.notification.findMany({
      where: { userId: user.id, ...(unreadOnly ? { read: false } : {}) },
      orderBy: { createdAt: "desc" },
      take,
      include: { actor: { select: { id: true, name: true, email: true } } },
    }),
    prisma.notification.count({ where: { userId: user.id, read: false } }),
  ]);

  return Response.json({ items, unreadCount });
});
