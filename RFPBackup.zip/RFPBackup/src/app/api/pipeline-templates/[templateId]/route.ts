import { z } from "zod";
import { PipelineStepKind, PipelineStepMode, Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership, requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { STEP_CATALOG } from "@/lib/pipeline/catalog";

async function loadAndAuthorize(templateId: string, userId: string, role: Role = Role.MEMBER) {
  const tpl = await prisma.pipelineTemplate.findUnique({ where: { id: templateId } });
  if (!tpl) throw new NotFoundError("Template not found");
  const member = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId, organizationId: tpl.organizationId } },
  });
  if (!member) throw new ForbiddenError("Not a member");
  const rank = { OWNER: 3, ADMIN: 2, MEMBER: 1 } as const;
  if (rank[member.role] < rank[role]) throw new ForbiddenError("Insufficient role");
  return tpl;
}

const stepSchema = z.object({
  kind: z.nativeEnum(PipelineStepKind),
  label: z.string().min(1).max(120),
  description: z.string().max(500).optional(),
  mode: z.nativeEnum(PipelineStepMode),
  config: z.record(z.string(), z.unknown()).optional(),
});

const patchSchema = z.object({
  name: z.string().min(2).max(100).optional(),
  description: z.string().max(500).nullable().optional(),
  steps: z.array(stepSchema).min(1).max(40).optional(),
  isDefault: z.boolean().optional(),
});

export const GET = withApiHandler<{ templateId: string }>(async (_req, { params }) => {
  const { templateId } = await params;
  const user = await requireUser();
  const tpl = await loadAndAuthorize(templateId, user.id);
  return Response.json({ template: tpl });
});

export const PATCH = withApiHandler<{ templateId: string }>(async (req, { params }) => {
  const { templateId } = await params;
  const user = await requireUser();
  const tpl = await loadAndAuthorize(templateId, user.id, Role.ADMIN);
  const body = patchSchema.parse(await req.json());

  if (body.steps) {
    for (const s of body.steps) {
      const meta = STEP_CATALOG[s.kind];
      if (!meta.allowedModes.includes(s.mode)) {
        throw new Error(`Step "${s.kind}" doesn't allow mode "${s.mode}"`);
      }
    }
  }

  const updated = await prisma.$transaction(async (tx) => {
    if (body.isDefault === true) {
      await tx.pipelineTemplate.updateMany({
        where: { organizationId: tpl.organizationId, isDefault: true, id: { not: templateId } },
        data: { isDefault: false },
      });
    }
    return tx.pipelineTemplate.update({
      where: { id: templateId },
      data: {
        ...(body.name !== undefined ? { name: body.name } : {}),
        ...(body.description !== undefined ? { description: body.description } : {}),
        ...(body.steps !== undefined ? { steps: body.steps as never } : {}),
        ...(body.isDefault !== undefined ? { isDefault: body.isDefault } : {}),
      },
    });
  });

  return Response.json({ template: updated });
});

export const DELETE = withApiHandler<{ templateId: string }>(async (_req, { params }) => {
  const { templateId } = await params;
  const user = await requireUser();
  await loadAndAuthorize(templateId, user.id, Role.ADMIN);
  // Block deleting templates currently in use by an active run.
  const inUse = await prisma.pipelineRun.count({
    where: { templateId, status: { in: ["PENDING", "RUNNING", "WAITING_FOR_INPUT"] } },
  });
  if (inUse > 0) {
    return Response.json(
      { error: `Template is in use by ${inUse} active run(s). Wait for them to finish or cancel them first.` },
      { status: 409 },
    );
  }
  await prisma.pipelineTemplate.delete({ where: { id: templateId } });
  return Response.json({ ok: true });
});
