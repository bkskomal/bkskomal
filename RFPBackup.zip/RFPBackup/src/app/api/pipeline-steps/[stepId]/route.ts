// Step-action endpoints: complete | decide | skip | retry. Each verifies the
// caller is a member of the RFP's organization, then calls the engine.

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError, ValidationError } from "@/lib/errors";
import { decideStep, markStepComplete, retryStep, skipStep } from "@/lib/pipeline/engine";

async function loadAndAuthorize(stepId: string, userId: string) {
  const step = await prisma.pipelineStepRun.findUnique({
    where: { id: stepId },
    include: { run: { include: { rfp: { include: { project: true } } } } },
  });
  if (!step) throw new NotFoundError("Step not found");
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId,
        organizationId: step.run.rfp.project.organizationId,
      },
    },
  });
  if (!member) throw new ForbiddenError("Not a member");
  return step;
}

const bodySchema = z.object({
  action: z.enum(["complete", "decide", "skip", "retry"]),
  note: z.string().optional(),
  config: z.record(z.string(), z.unknown()).optional(),
});

export const POST = withApiHandler<{ stepId: string }>(async (req, { params }) => {
  const { stepId } = await params;
  const user = await requireUser();
  await loadAndAuthorize(stepId, user.id);
  const body = bodySchema.parse(await req.json());

  switch (body.action) {
    case "complete":
      await markStepComplete(stepId, body.note);
      break;
    case "skip":
      await skipStep(stepId);
      break;
    case "retry":
      await retryStep(stepId);
      break;
    case "decide":
      if (!body.config) throw new ValidationError("decide requires a config object");
      await decideStep(stepId, body.config);
      break;
  }
  return Response.json({ ok: true });
});
