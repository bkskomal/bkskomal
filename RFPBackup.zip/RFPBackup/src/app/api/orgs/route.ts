import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireUser } from "@/lib/authz";
import { slugify } from "@/lib/utils";
import { Role, AiProvider } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";

export async function GET() {
  try {
    const user = await requireUser();
    const orgs = await prisma.organization.findMany({
      where: { memberships: { some: { userId: user.id } } },
      include: {
        memberships: { where: { userId: user.id }, select: { role: true } },
        _count: { select: { projects: true, indexes: true, memberships: true } },
      },
      orderBy: { createdAt: "asc" },
    });
    return Response.json({
      orgs: orgs.map((o) => ({
        id: o.id,
        name: o.name,
        slug: o.slug,
        role: o.memberships[0]?.role,
        projectCount: o._count.projects,
        indexCount: o._count.indexes,
        memberCount: o._count.memberships,
      })),
    });
  } catch (e) {
    return jsonError(e);
  }
}

const createSchema = z.object({ name: z.string().min(2).max(80) });

/**
 * True when the deployment has a real cloud LLM API key in env (anything
 * other than the local-dev placeholders). When false, freshly-created orgs
 * get a default Ollama OrgAiConfig so the local-first path "just works".
 */
function hasCloudApiKey(): boolean {
  const k = (process.env.LLM_API_KEY ?? "").trim().toLowerCase();
  if (!k) return false;
  // Common placeholder values used when running against a local server that
  // ignores the key — treat as "no real key set".
  const placeholders = new Set(["ollama", "test", "local", "lm-studio", "anonymous"]);
  if (placeholders.has(k)) return false;
  return true;
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const { name } = createSchema.parse(await req.json());
    let slug = slugify(name);
    let suffix = 0;
    while (await prisma.organization.findUnique({ where: { slug } })) {
      suffix++;
      slug = `${slugify(name)}-${suffix}`;
    }
    const org = await prisma.organization.create({
      data: {
        name,
        slug,
        memberships: { create: { userId: user.id, role: Role.OWNER } },
        indexes: {
          create: { name: "Default Knowledge Base", description: "Auto-created on org setup." },
        },
      },
    });

    // Bootstrap a sensible AI config if the deployment has no real cloud key
    // configured. We treat the placeholder strings ("ollama", "test") and an
    // empty value as "no real key", and seed the org with the local-first
    // Ollama defaults. Any explicit cloud key in env is left to drive
    // resolution via the env fallback path in resolveAiConfig.
    if (!hasCloudApiKey()) {
      try {
        await prisma.orgAiConfig.upsert({
          where: { organizationId: org.id },
          update: {},
          create: {
            organizationId: org.id,
            llmProvider: AiProvider.OLLAMA,
            llmBaseUrl: "http://localhost:11434/v1",
            llmModel: "llama3.2",
            embeddingProvider: AiProvider.OLLAMA,
            embeddingBaseUrl: "http://localhost:11434/v1",
            embeddingModel: "nomic-embed-text",
            embeddingDimensions: 768,
          },
        });
      } catch {
        // Non-fatal — the org is still usable; user can configure AI in Settings.
      }
    }

    void audit({
      event: "ORG_CREATED",
      actorId: user.id,
      organizationId: org.id,
      targetType: "organization",
      targetId: org.id,
      metadata: { name: org.name, slug: org.slug },
      ...auditContextFromRequest(req),
    });

    return Response.json({ org }, { status: 201 });
  } catch (e) {
    return jsonError(e);
  }
}
