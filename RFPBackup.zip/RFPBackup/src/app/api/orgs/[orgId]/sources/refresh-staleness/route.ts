// POST /api/orgs/[orgId]/sources/refresh-staleness
//
// Admin-only. Re-evaluates every Document in the org against the current
// staleness rule (default threshold + category overrides). Idempotent — the
// helper only PATCHes rows whose `staleReason` actually flips so callers
// can spam this button without amplifying DB load.
//
// Audited as SOURCE_STALENESS_REFRESHED so admins have a forensic trail for
// "who triggered the rescan" — useful when the staleReason banner on a
// document suddenly appears/disappears mid-RFP cycle.

import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { refreshStalenessForOrg } from "@/lib/sources/staleness";
import { audit, auditContextFromRequest } from "@/lib/audit";

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  const result = await refreshStalenessForOrg(orgId);

  void audit({
    event: "SOURCE_STALENESS_REFRESHED",
    actorId: user.id,
    organizationId: orgId,
    metadata: { scanned: result.scanned, flagged: result.flagged },
    ...auditContextFromRequest(req),
  });

  return Response.json(result);
});
