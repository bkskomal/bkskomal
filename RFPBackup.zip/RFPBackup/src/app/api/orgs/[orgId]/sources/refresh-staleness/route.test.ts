import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Mocks. Mock auth + prisma directly (the repo-wide pattern) so the route's
// `requireMembership` runs against a fake DB. The refresh helper itself is
// also mocked so we can assert the route plumbs counts back unchanged.
// ---------------------------------------------------------------------------

const { authMock, prismaMock, refreshMock, auditMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  refreshMock: vi.fn(),
  auditMock: vi.fn(),
  prismaMock: {
    membership: {
      findUnique: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/sources/staleness", () => ({
  refreshStalenessForOrg: (...args: unknown[]) => refreshMock(...args),
}));

vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});

import { POST } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const session = { user: { id: USER_ID } };

beforeEach(() => {
  vi.clearAllMocks();
});

function buildRequest() {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/sources/refresh-staleness`, {
    method: "POST",
  });
}

const params = () => ({ params: Promise.resolve({ orgId: ORG_ID }) });

describe("POST /api/orgs/[orgId]/sources/refresh-staleness", () => {
  it("returns scanned + flagged counts and audits the action", async () => {
    authMock.mockResolvedValueOnce(session);
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      id: "m1",
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "ADMIN",
    });
    refreshMock.mockResolvedValueOnce({ scanned: 42, flagged: 7 });

    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toEqual({ scanned: 42, flagged: 7 });

    expect(refreshMock).toHaveBeenCalledWith(ORG_ID);
    expect(auditMock).toHaveBeenCalledTimes(1);
    expect(auditMock.mock.calls[0][0]).toMatchObject({
      event: "SOURCE_STALENESS_REFRESHED",
      actorId: USER_ID,
      organizationId: ORG_ID,
      metadata: { scanned: 42, flagged: 7 },
    });
  });

  it("rejects MEMBER callers with 403 and does not run the refresh", async () => {
    authMock.mockResolvedValueOnce(session);
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      id: "m1",
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });

    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(403);
    expect(refreshMock).not.toHaveBeenCalled();
    expect(auditMock).not.toHaveBeenCalled();
  });

  it("rejects unauthenticated callers with 401", async () => {
    authMock.mockResolvedValueOnce(null);

    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(401);
    expect(refreshMock).not.toHaveBeenCalled();
  });
});
