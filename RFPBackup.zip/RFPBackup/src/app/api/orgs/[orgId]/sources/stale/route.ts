// GET /api/orgs/[orgId]/sources/stale
//
// Paginated list of Documents in this org whose `staleReason` is non-null
// (the schema uses staleReason as the tri-state stale flag — see
// lib/sources/staleness.ts). 100 rows per page, ordered oldest sourceDate
// first so reviewers see the most-decayed evidence at the top.
//
// `?cursor=<lastId>` pages forward; the response carries `nextCursor` (null
// when there is no further page). Membership is required; staleness data
// isn't sensitive enough to gate to ADMIN.

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";

const PAGE_SIZE = 100;

const querySchema = z.object({
  cursor: z.string().min(1).max(64).optional(),
});

export const GET = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId);

  const url = new URL(req.url);
  const { cursor } = querySchema.parse({
    cursor: url.searchParams.get("cursor") ?? undefined,
  });

  const docs = await prisma.document.findMany({
    where: {
      staleReason: { not: null },
      index: { organizationId: orgId },
    },
    orderBy: [{ sourceDate: "asc" }, { id: "asc" }],
    take: PAGE_SIZE + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    select: {
      id: true,
      indexId: true,
      name: true,
      fileName: true,
      sourceDate: true,
      staleReason: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  const hasMore = docs.length > PAGE_SIZE;
  const page = hasMore ? docs.slice(0, PAGE_SIZE) : docs;
  const nextCursor = hasMore ? page[page.length - 1].id : null;

  return Response.json({
    documents: page.map((d) => ({
      id: d.id,
      indexId: d.indexId,
      name: d.name,
      fileName: d.fileName,
      sourceDate: d.sourceDate?.toISOString() ?? null,
      staleReason: d.staleReason,
      createdAt: d.createdAt.toISOString(),
      updatedAt: d.updatedAt.toISOString(),
    })),
    nextCursor,
  });
});
