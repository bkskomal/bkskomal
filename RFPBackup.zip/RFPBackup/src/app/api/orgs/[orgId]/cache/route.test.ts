import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Mocks. Hoisted helpers match the repo-wide pattern (see outcome route test).
// ---------------------------------------------------------------------------

const { authMock, prismaMock, auditMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  prismaMock: {
    membership: {
      findUnique: vi.fn(),
    },
    cachedAnswer: {
      findMany: vi.fn(),
      aggregate: vi.fn(),
      deleteMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});

import { DELETE, GET } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const session = { user: { id: USER_ID } };

const params = () => ({ params: Promise.resolve({ orgId: ORG_ID }) });

function buildGetRequest() {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/cache`, { method: "GET" });
}

function buildDeleteRequest(body: unknown) {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/cache`, {
    method: "DELETE",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "ADMIN",
  });
  prismaMock.cachedAnswer.findMany.mockResolvedValue([]);
  prismaMock.cachedAnswer.aggregate.mockResolvedValue({
    _count: { _all: 3 },
    _sum: { hits: 12 },
  });
  prismaMock.cachedAnswer.deleteMany.mockResolvedValue({ count: 0 });
  auditMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// GET — list + stats.
// ---------------------------------------------------------------------------

describe("GET /api/orgs/:orgId/cache", () => {
  it("returns entries and stats for ADMIN callers", async () => {
    prismaMock.cachedAnswer.findMany.mockResolvedValueOnce([
      {
        id: "row-1",
        questionHash: "h",
        indexId: null,
        question: "Q",
        answer: "A",
        sourcesSnapshot: [],
        confidence: 0.9,
        groundingScore: 0.8,
        hits: 5,
        createdAt: new Date(),
        lastUsedAt: new Date(),
      },
    ]);
    const res = await GET(buildGetRequest(), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.entries).toHaveLength(1);
    expect(body.entries[0].id).toBe("row-1");
    expect(body.stats).toEqual({
      totalEntries: 3,
      totalHits: 12,
      estimatedCallsSaved: 12,
    });
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await GET(buildGetRequest(), params());
    expect(res.status).toBe(403);
    expect(prismaMock.cachedAnswer.findMany).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// DELETE — bulk purge.
// ---------------------------------------------------------------------------

describe("DELETE /api/orgs/:orgId/cache", () => {
  it("purges entries older than N days and audits CACHE_PURGED", async () => {
    prismaMock.cachedAnswer.deleteMany.mockResolvedValueOnce({ count: 7 });
    const res = await DELETE(buildDeleteRequest({ olderThanDays: 90 }), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.deleted).toBe(7);

    expect(prismaMock.cachedAnswer.deleteMany).toHaveBeenCalledTimes(1);
    const whereArg = prismaMock.cachedAnswer.deleteMany.mock.calls[0][0].where;
    expect(whereArg.organizationId).toBe(ORG_ID);
    expect(whereArg.lastUsedAt.lt).toBeInstanceOf(Date);

    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    const auditPayload = auditMock.mock.calls[0][0];
    expect(auditPayload.event).toBe("CACHE_PURGED");
    expect(auditPayload.organizationId).toBe(ORG_ID);
    expect(auditPayload.actorId).toBe(USER_ID);
    expect(auditPayload.metadata.deleted).toBe(7);
    expect(auditPayload.metadata.olderThanDays).toBe(90);
  });

  it("purges specific ids when provided", async () => {
    prismaMock.cachedAnswer.deleteMany.mockResolvedValueOnce({ count: 2 });
    const res = await DELETE(
      buildDeleteRequest({ ids: ["row-a", "row-b"] }),
      params(),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.deleted).toBe(2);
    const whereArg = prismaMock.cachedAnswer.deleteMany.mock.calls[0][0].where;
    expect(whereArg.organizationId).toBe(ORG_ID);
    expect(whereArg.id).toEqual({ in: ["row-a", "row-b"] });
  });

  it("returns 400 when neither olderThanDays nor ids is provided", async () => {
    const res = await DELETE(buildDeleteRequest({}), params());
    expect(res.status).toBe(400);
    expect(prismaMock.cachedAnswer.deleteMany).not.toHaveBeenCalled();
  });

  it("returns 403 when the caller is not an admin", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await DELETE(buildDeleteRequest({ olderThanDays: 30 }), params());
    expect(res.status).toBe(403);
    expect(prismaMock.cachedAnswer.deleteMany).not.toHaveBeenCalled();
    expect(auditMock).not.toHaveBeenCalled();
  });
});
