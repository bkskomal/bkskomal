// Admin-only listing and bulk purge for the semantic answer cache.
//
//   GET    — paginated list of cached answers, newest-used first. Embeddings
//            are stripped from the response (they're large and useless to
//            the UI). Cursor pagination by id.
//   DELETE — bulk purge. Accepts either:
//              { olderThanDays: number }  — delete entries idle for >N days
//              { ids: string[] }          — delete specific entries
//            Returns the number of rows deleted. Audited as CACHE_PURGED.
//
// Both endpoints require ADMIN membership: a cache entry can include the
// full answer body, which may carry confidential RFP content even when the
// caller isn't a member of the original project.

import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { cachePurgesTotal } from "@/lib/metrics";

const PAGE_SIZE = 50;

const querySchema = z.object({
  cursor: z.string().min(1).max(64).optional(),
});

export const GET = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);

  const url = new URL(req.url);
  const { cursor } = querySchema.parse({
    cursor: url.searchParams.get("cursor") ?? undefined,
  });

  const rows = await prisma.cachedAnswer.findMany({
    where: { organizationId: orgId },
    orderBy: { lastUsedAt: "desc" },
    take: PAGE_SIZE + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
    // Strip questionEmbedding — embeddings are ~3KB each and useless to the
    // UI, so let Prisma omit them from the SELECT to save bandwidth.
    select: {
      id: true,
      questionHash: true,
      indexId: true,
      question: true,
      answer: true,
      sourcesSnapshot: true,
      confidence: true,
      groundingScore: true,
      hits: true,
      createdAt: true,
      lastUsedAt: true,
    },
  });

  // Aggregate stats for the dashboard card. Cheap on the cached_answer table
  // (only indexed-by-org rows are visited).
  const [totals] = await Promise.all([
    prisma.cachedAnswer.aggregate({
      where: { organizationId: orgId },
      _count: { _all: true },
      _sum: { hits: true },
    }),
  ]);

  const hasMore = rows.length > PAGE_SIZE;
  const page = hasMore ? rows.slice(0, PAGE_SIZE) : rows;
  const nextCursor = hasMore ? page[page.length - 1].id : null;

  return Response.json({
    entries: page,
    nextCursor,
    stats: {
      totalEntries: totals._count._all,
      totalHits: totals._sum.hits ?? 0,
      // "Calls saved" is the same as totalHits — every hit avoided one
      // fresh LLM generation. Exposed under a friendlier name for the UI
      // so the copy doesn't have to compute it.
      estimatedCallsSaved: totals._sum.hits ?? 0,
    },
  });
});

const deleteSchema = z
  .object({
    olderThanDays: z.number().int().min(0).max(3650).optional(),
    ids: z.array(z.string().min(1)).max(500).optional(),
  })
  .refine((b) => b.olderThanDays != null || (b.ids && b.ids.length > 0), {
    message: "Provide olderThanDays or a non-empty ids array",
  });

export const DELETE = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  const body = deleteSchema.parse(await safeJson(req as NextRequest));

  let deleted = 0;
  if (body.ids && body.ids.length > 0) {
    // Scope by orgId to prevent cross-org id targeting.
    const result = await prisma.cachedAnswer.deleteMany({
      where: { organizationId: orgId, id: { in: body.ids } },
    });
    deleted += result.count;
  }
  if (body.olderThanDays != null) {
    // purgeStaleCache is org-agnostic. We re-implement the org-scoped variant
    // inline so admins can't accidentally clear another tenant's cache.
    const cutoff = new Date(Date.now() - body.olderThanDays * 24 * 60 * 60 * 1000);
    const result = await prisma.cachedAnswer.deleteMany({
      where: { organizationId: orgId, lastUsedAt: { lt: cutoff } },
    });
    deleted += result.count;
  }

  cachePurgesTotal.inc();

  void audit({
    event: "CACHE_PURGED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "CachedAnswer",
    metadata: {
      deleted,
      olderThanDays: body.olderThanDays ?? null,
      idsCount: body.ids?.length ?? 0,
    },
    ...auditContextFromRequest(req as NextRequest),
  });

  return Response.json({ deleted });
});

// Tiny helper so DELETE works whether the client sent a body or not. A bare
// `await req.json()` throws SyntaxError on an empty body which would 500.
async function safeJson(req: NextRequest): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    return {};
  }
}

// purgeStaleCache is exported from `@/lib/ai/semantic-cache` — import it from
// there directly. Next.js route files only allow HTTP method exports.
