// Per-entry invalidation for the semantic answer cache.
//
//   DELETE — drop a single cached answer by id. Admin-only. Audited as
//            CACHE_INVALIDATED. Idempotent — deleting an entry that
//            doesn't exist returns 200 with deleted: 0.
//
// Tenant isolation: the entry's `organizationId` is checked against the
// path's orgId before delete, so a stale URL from a previous org session
// can't be used to nuke another tenant's cache.

import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { cachePurgesTotal } from "@/lib/metrics";

export const DELETE = withApiHandler<{ orgId: string; cacheId: string }>(
  async (req, { params }) => {
    const { orgId, cacheId } = await params;
    const { user } = await requireMembership(orgId, Role.ADMIN);

    // deleteMany (not delete) so a missing row returns count: 0 rather than
    // throwing P2025. We bind organizationId in the where clause so the
    // route never deletes another tenant's row even if the caller guesses
    // an id from a different org.
    const result = await prisma.cachedAnswer.deleteMany({
      where: { id: cacheId, organizationId: orgId },
    });

    if (result.count > 0) {
      cachePurgesTotal.inc();
      void audit({
        event: "CACHE_INVALIDATED",
        actorId: user.id,
        organizationId: orgId,
        targetType: "CachedAnswer",
        targetId: cacheId,
        ...auditContextFromRequest(req as NextRequest),
      });
    }

    return Response.json({ deleted: result.count });
  },
);
