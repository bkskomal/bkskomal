// POST /api/orgs/[orgId]/vector/migrate
//
// Admin-only Postgres → Milvus backfill trigger from the settings UI.
// Mirrors `scripts/migrate-to-milvus.mjs` — both paths import the same
// `backfillToMilvus` helper, so behaviour stays in sync.
//
// Body: `{ indexId?: string, dryRun?: boolean }`. When `dryRun` is true we
// scan and report counts but make no Milvus writes. On a clean run (errors
// = 0, written > 0, dryRun = false) the helper stamps `vectorMigratedAt`
// on OrgAiConfig — that's what powers the "Migrated <date>" badge.
//
// The route is wrapped by withApiHandler and audited as VECTOR_BACKEND_MIGRATED.
// We do NOT background the job: the request stays open until the backfill
// finishes. Large orgs should run the CLI instead — the route is targeted
// at the typical small/medium org doing a one-shot cutover from the UI.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { backfillToMilvus } from "@/lib/ai/vector/backfill";

const bodySchema = z
  .object({
    indexId: z.string().min(1).max(64).optional(),
    dryRun: z.boolean().optional(),
    batch: z.number().int().min(10).max(1000).optional(),
  })
  .default({});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  const text = await req.text();
  const parsed = bodySchema.parse(text ? JSON.parse(text) : {});

  const result = await backfillToMilvus({
    orgId,
    indexId: parsed.indexId,
    dryRun: parsed.dryRun,
    batch: parsed.batch,
  });

  void audit({
    event: "VECTOR_BACKEND_MIGRATED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: orgId,
    metadata: {
      indexId: parsed.indexId ?? null,
      dryRun: Boolean(parsed.dryRun),
      scanned: result.scanned,
      written: result.written,
      errors: result.errors,
      durationMs: result.durationMs,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({
    ok: result.errors === 0,
    ...result,
  });
});
