// Tests for the Milvus connection-test route.
//
// We mock the MilvusVectorStore so the test path neither touches the real SDK
// nor opens a real gRPC channel — only the response envelope and the audit
// payload matter here.

import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

const { authMock, prismaMock, auditMock, healthMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  healthMock: vi.fn(),
  prismaMock: {
    membership: { findUnique: vi.fn() },
    orgAiConfig: { findUnique: vi.fn() },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return { ...actual, audit: (...args: unknown[]) => auditMock(...args) };
});

// Mock the milvus module — the route lazy-imports it so we capture the
// constructor + health spy here. Use a regular `function` so `new
// MilvusVectorStore(...)` succeeds (arrows can't be `new`-called).
vi.mock("@/lib/ai/vector/milvus", () => ({
  MilvusVectorStore: vi.fn(function MilvusVectorStoreMock() {
    return { health: (...args: unknown[]) => healthMock(...args) };
  }),
}));

import { POST } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const session = { user: { id: USER_ID } };
const params = () => ({ params: Promise.resolve({ orgId: ORG_ID }) });

function buildReq(body: unknown) {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/vector/test`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "ADMIN",
  });
  prismaMock.orgAiConfig.findUnique.mockResolvedValue({ embeddingDimensions: 384 });
  auditMock.mockResolvedValue(undefined);
});

describe("POST /api/orgs/:orgId/vector/test", () => {
  it("returns ok=true with ms when health probe succeeds", async () => {
    healthMock.mockResolvedValueOnce({ ok: true, ms: 42, detail: "all good", vectorCount: 0 });
    const res = await POST(
      buildReq({ uri: "https://milvus.test", token: "tok", isolation: "partition" }),
      params(),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.ms).toBe(42);
    expect(body.error).toBeNull();

    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    const payload = auditMock.mock.calls[0][0];
    expect(payload.event).toBe("VECTOR_BACKEND_TESTED");
    expect(payload.metadata.ok).toBe(true);
    expect(payload.metadata.uri).toBe("https://milvus.test");
    // Token must NOT leak into the audit log.
    expect(JSON.stringify(payload.metadata)).not.toContain("tok");
  });

  it("returns ok=false (still HTTP 200) when health probe fails", async () => {
    healthMock.mockResolvedValueOnce({ ok: false, ms: 250, detail: "ECONNREFUSED" });
    const res = await POST(
      buildReq({ uri: "https://milvus.test" }),
      params(),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(false);
    expect(body.error).toBe("ECONNREFUSED");
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await POST(buildReq({ uri: "https://m.test" }), params());
    expect(res.status).toBe(403);
    expect(healthMock).not.toHaveBeenCalled();
  });

  it("400s when uri is missing", async () => {
    const res = await POST(buildReq({ token: "x" }), params());
    expect(res.status).toBe(400);
  });
});
