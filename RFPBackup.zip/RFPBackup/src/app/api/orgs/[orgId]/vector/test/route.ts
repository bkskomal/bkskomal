// POST /api/orgs/[orgId]/vector/test
//
// Admin-only one-shot connection test for a prospective Milvus URI/token.
// Builds an ephemeral MilvusVectorStore (no Prisma round-trip — the caller
// supplies the URI/token directly so they can validate before saving) and
// calls health(). Returns a small envelope:
//
//   { ok, ms, detail?, error? }
//
// Always returns HTTP 200 — the call itself succeeded; the boolean tells the
// caller whether the cluster handshake worked. Audited as
// VECTOR_BACKEND_TESTED with `{ uri, ms, ok }`. The token is never logged.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { env } from "@/lib/env";
import { prisma } from "@/lib/prisma";

const bodySchema = z.object({
  uri: z.string().min(1).max(500),
  token: z.string().max(2000).optional(),
  collection: z.string().min(1).max(255).optional(),
  isolation: z.enum(["partition", "collection"]).optional(),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  // Provider-test rate limit applies — Milvus calls hit an external network.
  await rateLimit(RATE_LIMITS.providerTest, {
    userId: user.id,
    orgId,
    route: "vector/test",
  });

  const body = bodySchema.parse(await req.json());

  // Pull the org's embeddingDimensions so the schema we'd create matches the
  // actual embeddings the indexing pipeline will eventually upsert.
  const cfg = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: { embeddingDimensions: true },
  });
  const dim = cfg?.embeddingDimensions ?? env.EMBEDDING_DIMENSIONS ?? 384;

  // Lazy import — only orgs hitting this route pay the SDK load cost.
  const { MilvusVectorStore } = await import("@/lib/ai/vector/milvus");
  const store = new MilvusVectorStore({
    uri: body.uri.trim(),
    token: body.token?.trim() || undefined,
    collection: body.collection?.trim() || "autorfp_chunks",
    isolation: body.isolation ?? "partition",
    embeddingDim: dim,
  });

  const health = await store.health(orgId);

  void audit({
    event: "VECTOR_BACKEND_TESTED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: orgId,
    metadata: {
      uri: body.uri.trim(),
      ms: health.ms,
      ok: health.ok,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json(
    {
      ok: health.ok,
      ms: health.ms,
      detail: health.detail ?? null,
      error: health.ok ? null : health.detail ?? "Connection failed",
      vectorCount: health.vectorCount ?? null,
    },
    { status: 200 },
  );
});
