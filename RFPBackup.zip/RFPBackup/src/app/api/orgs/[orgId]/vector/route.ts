// Org vector backend configuration (Phase V).
//
// Admin-only GET / PUT / DELETE for the OrgAiConfig fields that drive the
// vector store resolver:
//
//   vectorBackend          POSTGRES (default) | MILVUS
//   milvusUri              gRPC URI (e.g. https://<id>.zillizcloud.com)
//   milvusTokenEncrypted   API key / username:password (encrypted at rest)
//   milvusCollection       Collection name (defaults to "autorfp_chunks")
//   milvusIsolation        "partition" (default) | "collection"
//   vectorDualWrite        Boolean — writes go to BOTH backends during cutover
//   vectorMigratedAt       Timestamp of the last verified backfill run
//
// GET returns a render-safe summary: the URI is a connection string, not a
// secret, so we render it verbatim. The token is NEVER returned in plaintext —
// only a short prefix-based fingerprint useful for "yes, you saved a token".
//
// PUT validates the body via Zod, encrypts the token before persistence, and
// audits VECTOR_BACKEND_CONFIGURED. Any field omitted from the body is left
// unchanged (so the UI can save just the dual-write toggle without resending
// the URI).
//
// DELETE wipes Milvus-related fields and reverts the org to POSTGRES. Audited
// as VECTOR_BACKEND_RESET — useful if a misconfigured cluster needs a quick
// rollback.

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role, VectorBackend } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { decrypt, encrypt, maskSecret } from "@/lib/crypto";

interface VectorConfigPayload {
  vectorBackend: "POSTGRES" | "MILVUS";
  milvusUri: string | null;
  milvusTokenSet: boolean;
  /** Short fingerprint of the saved token (first/last 4 chars). Render-safe. */
  milvusTokenMasked: string | null;
  milvusCollection: string | null;
  milvusIsolation: "partition" | "collection";
  vectorDualWrite: boolean;
  vectorMigratedAt: string | null;
}

export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);

  const cfg = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: {
      vectorBackend: true,
      milvusUri: true,
      milvusTokenEncrypted: true,
      milvusCollection: true,
      milvusIsolation: true,
      vectorDualWrite: true,
      vectorMigratedAt: true,
    },
  });

  const tokenPlain = cfg?.milvusTokenEncrypted ? decrypt(cfg.milvusTokenEncrypted) : null;
  const out: VectorConfigPayload = {
    vectorBackend: (cfg?.vectorBackend ?? VectorBackend.POSTGRES) as
      | "POSTGRES"
      | "MILVUS",
    milvusUri: cfg?.milvusUri ?? null,
    milvusTokenSet: Boolean(cfg?.milvusTokenEncrypted),
    milvusTokenMasked: tokenPlain ? maskSecret(tokenPlain) : null,
    milvusCollection: cfg?.milvusCollection ?? null,
    milvusIsolation: (cfg?.milvusIsolation === "collection" ? "collection" : "partition") as
      | "partition"
      | "collection",
    vectorDualWrite: cfg?.vectorDualWrite ?? false,
    vectorMigratedAt: cfg?.vectorMigratedAt?.toISOString() ?? null,
  };
  return Response.json(out);
});

const putSchema = z.object({
  vectorBackend: z.enum(["POSTGRES", "MILVUS"]).optional(),
  milvusUri: z.string().min(1).max(500).nullable().optional(),
  /** Plaintext token. Encrypted before write. Pass null OR empty string to clear
   *  (local Milvus has no auth). Omit to leave the existing value alone. */
  milvusToken: z.string().max(2000).nullable().optional(),
  milvusCollection: z.string().min(1).max(255).nullable().optional(),
  milvusIsolation: z.enum(["partition", "collection"]).optional(),
  vectorDualWrite: z.boolean().optional(),
});

export const PUT = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  const body = putSchema.parse(await req.json());

  const data: Record<string, unknown> = {};
  if (body.vectorBackend !== undefined) data.vectorBackend = body.vectorBackend;
  if (body.milvusUri !== undefined) data.milvusUri = body.milvusUri?.trim() || null;
  if (body.milvusToken !== undefined) {
    // Encrypt the token before persistence. `null` clears the field.
    data.milvusTokenEncrypted = body.milvusToken ? encrypt(body.milvusToken) : null;
  }
  if (body.milvusCollection !== undefined) {
    data.milvusCollection = body.milvusCollection?.trim() || null;
  }
  if (body.milvusIsolation !== undefined) data.milvusIsolation = body.milvusIsolation;
  if (body.vectorDualWrite !== undefined) data.vectorDualWrite = body.vectorDualWrite;

  await prisma.orgAiConfig.upsert({
    where: { organizationId: orgId },
    update: data,
    create: { organizationId: orgId, ...data },
  });

  void audit({
    event: "VECTOR_BACKEND_CONFIGURED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: orgId,
    metadata: {
      vectorBackend: body.vectorBackend ?? null,
      milvusUri: body.milvusUri ?? undefined,
      milvusTokenChanged: body.milvusToken !== undefined,
      milvusTokenCleared: body.milvusToken === null,
      milvusCollection: body.milvusCollection ?? undefined,
      milvusIsolation: body.milvusIsolation ?? undefined,
      vectorDualWrite: body.vectorDualWrite ?? undefined,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true });
});

export const DELETE = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  await prisma.orgAiConfig.upsert({
    where: { organizationId: orgId },
    update: {
      vectorBackend: VectorBackend.POSTGRES,
      milvusUri: null,
      milvusTokenEncrypted: null,
      milvusCollection: null,
      milvusIsolation: "partition",
      vectorDualWrite: false,
      vectorMigratedAt: null,
    },
    create: {
      organizationId: orgId,
      vectorBackend: VectorBackend.POSTGRES,
    },
  });

  void audit({
    event: "VECTOR_BACKEND_RESET",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: orgId,
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true });
});
