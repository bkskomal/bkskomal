// Tests for the org vector backend config route (GET / PUT / DELETE).

import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

const { authMock, prismaMock, auditMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  prismaMock: {
    membership: { findUnique: vi.fn() },
    orgAiConfig: {
      findUnique: vi.fn(),
      upsert: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return { ...actual, audit: (...args: unknown[]) => auditMock(...args) };
});

import { GET, PUT, DELETE } from "./route";
import { decrypt } from "@/lib/crypto";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const session = { user: { id: USER_ID } };
const params = () => ({ params: Promise.resolve({ orgId: ORG_ID }) });

function buildReq(method: string, body?: unknown) {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/vector`, {
    method,
    headers: body ? { "content-type": "application/json" } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "ADMIN",
  });
  prismaMock.orgAiConfig.findUnique.mockResolvedValue(null);
  prismaMock.orgAiConfig.upsert.mockResolvedValue({});
  auditMock.mockResolvedValue(undefined);
});

describe("GET /api/orgs/:orgId/vector", () => {
  it("returns defaults when no config row exists", async () => {
    const res = await GET(buildReq("GET"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.vectorBackend).toBe("POSTGRES");
    expect(body.milvusUri).toBeNull();
    expect(body.milvusTokenSet).toBe(false);
    expect(body.milvusIsolation).toBe("partition");
    expect(body.vectorDualWrite).toBe(false);
  });

  it("never returns the plaintext token — only a masked summary", async () => {
    const { encrypt } = await import("@/lib/crypto");
    const enc = encrypt("super-secret-token-value");
    prismaMock.orgAiConfig.findUnique.mockResolvedValueOnce({
      vectorBackend: "MILVUS",
      milvusUri: "https://milvus.test",
      milvusTokenEncrypted: enc,
      milvusCollection: "autorfp_chunks",
      milvusIsolation: "partition",
      vectorDualWrite: true,
      vectorMigratedAt: null,
    });
    const res = await GET(buildReq("GET"), params());
    const body = await res.json();
    expect(body.milvusTokenSet).toBe(true);
    expect(body.milvusTokenMasked).toBeTruthy();
    expect(body.milvusTokenMasked).not.toBe("super-secret-token-value");
    expect(JSON.stringify(body)).not.toContain("super-secret-token-value");
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await GET(buildReq("GET"), params());
    expect(res.status).toBe(403);
  });
});

describe("PUT /api/orgs/:orgId/vector", () => {
  it("encrypts the token before persistence and audits", async () => {
    const res = await PUT(
      buildReq("PUT", {
        vectorBackend: "MILVUS",
        milvusUri: "https://milvus.test:443",
        milvusToken: "user:pass",
        milvusCollection: "autorfp_chunks",
        milvusIsolation: "partition",
        vectorDualWrite: true,
      }),
      params(),
    );
    expect(res.status).toBe(200);

    expect(prismaMock.orgAiConfig.upsert).toHaveBeenCalledTimes(1);
    const arg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    const stored = arg.update.milvusTokenEncrypted as string;
    // The persisted value MUST be ciphertext, not the plaintext.
    expect(stored).not.toBe("user:pass");
    expect(stored.startsWith("v2:")).toBe(true);
    expect(decrypt(stored)).toBe("user:pass");

    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    const payload = auditMock.mock.calls[0][0];
    expect(payload.event).toBe("VECTOR_BACKEND_CONFIGURED");
    expect(payload.metadata.milvusTokenChanged).toBe(true);
    // The audit payload must NOT carry the plaintext token.
    expect(JSON.stringify(payload.metadata)).not.toContain("user:pass");
  });

  it("leaves the token alone when omitted from the body", async () => {
    await PUT(
      buildReq("PUT", { vectorBackend: "MILVUS", milvusUri: "https://m.test" }),
      params(),
    );
    const arg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    expect(Object.prototype.hasOwnProperty.call(arg.update, "milvusTokenEncrypted")).toBe(false);
  });

  it("clears the token when explicit null is sent", async () => {
    await PUT(buildReq("PUT", { milvusToken: null }), params());
    const arg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    expect(arg.update.milvusTokenEncrypted).toBeNull();
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await PUT(buildReq("PUT", { vectorBackend: "MILVUS" }), params());
    expect(res.status).toBe(403);
    expect(prismaMock.orgAiConfig.upsert).not.toHaveBeenCalled();
  });
});

describe("DELETE /api/orgs/:orgId/vector", () => {
  it("reverts to POSTGRES defaults and clears Milvus fields", async () => {
    const res = await DELETE(buildReq("DELETE"), params());
    expect(res.status).toBe(200);
    const arg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    expect(arg.update.vectorBackend).toBe("POSTGRES");
    expect(arg.update.milvusUri).toBeNull();
    expect(arg.update.milvusTokenEncrypted).toBeNull();
    expect(arg.update.vectorDualWrite).toBe(false);
    expect(arg.update.vectorMigratedAt).toBeNull();

    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    expect(auditMock.mock.calls[0][0].event).toBe("VECTOR_BACKEND_RESET");
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await DELETE(buildReq("DELETE"), params());
    expect(res.status).toBe(403);
    expect(prismaMock.orgAiConfig.upsert).not.toHaveBeenCalled();
  });
});
