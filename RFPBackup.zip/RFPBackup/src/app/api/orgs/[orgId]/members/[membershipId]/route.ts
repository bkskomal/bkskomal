import { NextRequest } from "next/server";
import { z } from "zod";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";

const patchSchema = z.object({ role: z.nativeEnum(Role) });

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ orgId: string; membershipId: string }> },
) {
  try {
    const { orgId, membershipId } = await params;
    const { user } = await requireMembership(orgId, Role.ADMIN);
    const { role } = patchSchema.parse(await req.json());

    if (role !== Role.OWNER) {
      const ownerCount = await prisma.membership.count({
        where: { organizationId: orgId, role: Role.OWNER, NOT: { id: membershipId } },
      });
      if (ownerCount === 0) {
        return Response.json({ error: "An organization needs at least one owner" }, { status: 400 });
      }
    }

    const prior = await prisma.membership.findUnique({ where: { id: membershipId } });
    const updated = await prisma.membership.update({ where: { id: membershipId }, data: { role } });

    void audit({
      event: "MEMBER_ROLE_CHANGED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "membership",
      targetId: membershipId,
      metadata: {
        userId: updated.userId,
        fromRole: prior?.role ?? null,
        toRole: role,
      },
      ...auditContextFromRequest(req),
    });

    return Response.json({ membership: updated });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ orgId: string; membershipId: string }> },
) {
  try {
    const { orgId, membershipId } = await params;
    const { user } = await requireMembership(orgId, Role.ADMIN);

    const target = await prisma.membership.findUnique({ where: { id: membershipId } });
    if (!target) return Response.json({ error: "Not found" }, { status: 404 });

    if (target.role === Role.OWNER) {
      const ownerCount = await prisma.membership.count({
        where: { organizationId: orgId, role: Role.OWNER },
      });
      if (ownerCount <= 1) {
        return Response.json({ error: "Cannot remove the last owner" }, { status: 400 });
      }
    }
    await prisma.membership.delete({ where: { id: membershipId } });

    void audit({
      event: "MEMBER_REMOVED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "membership",
      targetId: membershipId,
      metadata: { userId: target.userId, role: target.role },
      ...auditContextFromRequest(req),
    });

    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
