import { NextRequest } from "next/server";
import { z } from "zod";
import { randomBytes } from "node:crypto";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";

const inviteSchema = z.object({
  email: z.string().email(),
  role: z.nativeEnum(Role).default(Role.MEMBER),
});

export async function GET(_req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const [members, invites] = await Promise.all([
      prisma.membership.findMany({
        where: { organizationId: orgId },
        include: { user: { select: { email: true, name: true, image: true } } },
        orderBy: { createdAt: "asc" },
      }),
      prisma.invite.findMany({
        where: { organizationId: orgId, acceptedAt: null },
        orderBy: { createdAt: "desc" },
      }),
    ]);
    return Response.json({ members, invites });
  } catch (e) {
    return jsonError(e);
  }
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    const { user } = await requireMembership(orgId, Role.ADMIN);
    const { email, role } = inviteSchema.parse(await req.json());

    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing) {
      const dup = await prisma.membership.findUnique({
        where: { userId_organizationId: { userId: existing.id, organizationId: orgId } },
      });
      if (dup) return Response.json({ error: "User already a member" }, { status: 400 });
      const membership = await prisma.membership.create({
        data: { organizationId: orgId, userId: existing.id, role },
      });
      void audit({
        event: "MEMBER_INVITED",
        actorId: user.id,
        organizationId: orgId,
        targetType: "membership",
        targetId: membership.id,
        metadata: { email, role, attached: true, userId: existing.id },
        ...auditContextFromRequest(req),
      });
      return Response.json({ membership, attached: true }, { status: 201 });
    }

    const invite = await prisma.invite.create({
      data: {
        email,
        role,
        organizationId: orgId,
        invitedById: user.id,
        token: randomBytes(24).toString("hex"),
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });
    void audit({
      event: "MEMBER_INVITED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "invite",
      targetId: invite.id,
      metadata: { email, role, attached: false },
      ...auditContextFromRequest(req),
    });
    return Response.json({ invite }, { status: 201 });
  } catch (e) {
    return jsonError(e);
  }
}
