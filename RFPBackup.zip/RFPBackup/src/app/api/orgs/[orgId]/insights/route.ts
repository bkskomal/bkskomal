// Insights API — read-only aggregates for the in-app dashboard.
//
// Returns the same payload the server-component dashboard renders, so the
// dashboard can stay server-rendered while clients (charts that opt into
// dynamic refresh, etc.) can pull updates without re-fetching the whole
// page tree. Keep query count bounded — no N+1 over questions.

import { NextRequest } from "next/server";
import { jsonError, requireMembership } from "@/lib/authz";
import { computeOrgInsights } from "@/lib/insights";

export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ orgId: string }> },
) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const insights = await computeOrgInsights(orgId);
    return Response.json(insights);
  } catch (e) {
    return jsonError(e);
  }
}
