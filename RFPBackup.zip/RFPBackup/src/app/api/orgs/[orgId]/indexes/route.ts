import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const indexes = await prisma.knowledgeIndex.findMany({
      where: { organizationId: orgId },
      include: { _count: { select: { documents: true } } },
      orderBy: { createdAt: "desc" },
    });
    return Response.json({ indexes });
  } catch (e) {
    return jsonError(e);
  }
}

const createSchema = z.object({
  name: z.string().min(2).max(80),
  description: z.string().max(500).optional(),
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const body = createSchema.parse(await req.json());
    const index = await prisma.knowledgeIndex.create({
      data: { ...body, organizationId: orgId },
    });
    return Response.json({ index }, { status: 201 });
  } catch (e) {
    return jsonError(e);
  }
}
