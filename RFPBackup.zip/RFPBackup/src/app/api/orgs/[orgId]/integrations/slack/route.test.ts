import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

const { authMock, prismaMock, auditMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  prismaMock: {
    membership: {
      findUnique: vi.fn(),
    },
    slackIntegration: {
      findUnique: vi.fn(),
      upsert: vi.fn(),
      deleteMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});

import { GET, PUT, DELETE } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const session = { user: { id: USER_ID } };
const params = () => ({ params: Promise.resolve({ orgId: ORG_ID }) });

function buildReq(method: "GET" | "PUT" | "DELETE", body?: unknown) {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/integrations/slack`, {
    method,
    headers: { "content-type": "application/json" },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "ADMIN",
  });
  prismaMock.slackIntegration.findUnique.mockResolvedValue(null);
  prismaMock.slackIntegration.upsert.mockResolvedValue({ id: "si-1" });
  prismaMock.slackIntegration.deleteMany.mockResolvedValue({ count: 1 });
  auditMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// PUT — happy path: encrypt + upsert + audit.
// ---------------------------------------------------------------------------

describe("PUT /api/orgs/:orgId/integrations/slack", () => {
  it("encrypts the bot token and upserts the integration", async () => {
    const res = await PUT(
      buildReq("PUT", {
        botToken: "xoxb-test-token",
        teamName: "Acme",
        defaultChannelId: "C123",
        eventPreferences: {
          rfp_uploaded: true,
          response_generated: true,
          mention: false,
          outcome_set: true,
        },
      }),
      params(),
    );
    expect(res.status).toBe(200);
    expect(prismaMock.slackIntegration.upsert).toHaveBeenCalledTimes(1);
    const call = prismaMock.slackIntegration.upsert.mock.calls[0][0];
    expect(call.where).toEqual({ organizationId: ORG_ID });
    // Encrypted envelope starts with the v2 prefix.
    expect(call.update.botTokenEncrypted).toMatch(/^v2:/);
    expect(call.update.botTokenEncrypted).not.toBe("xoxb-test-token");
    expect(call.update.teamName).toBe("Acme");
    expect(call.update.defaultChannelId).toBe("C123");
    expect(call.update.eventPreferences).toMatchObject({
      mention: false,
      rfp_uploaded: true,
    });
  });

  it("audits SLACK_INTEGRATION_CONFIGURED", async () => {
    await PUT(buildReq("PUT", { teamName: "Acme" }), params());
    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    const payload = auditMock.mock.calls[0][0];
    expect(payload.event).toBe("SLACK_INTEGRATION_CONFIGURED");
    expect(payload.organizationId).toBe(ORG_ID);
  });

  it("leaves the existing bot token alone on KEEP sentinel", async () => {
    await PUT(buildReq("PUT", { botToken: "__KEEP__", teamName: "Acme" }), params());
    const call = prismaMock.slackIntegration.upsert.mock.calls[0][0];
    expect(call.update.botTokenEncrypted).toBeUndefined();
  });

  it("clears the bot token when explicit null is sent", async () => {
    await PUT(buildReq("PUT", { botToken: null }), params());
    const call = prismaMock.slackIntegration.upsert.mock.calls[0][0];
    expect(call.update.botTokenEncrypted).toBeNull();
  });

  it("returns 403 for non-admins", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await PUT(buildReq("PUT", { botToken: "xoxb-test" }), params());
    expect(res.status).toBe(403);
    expect(prismaMock.slackIntegration.upsert).not.toHaveBeenCalled();
    expect(auditMock).not.toHaveBeenCalled();
  });

  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await PUT(buildReq("PUT", { botToken: "xoxb-test" }), params());
    expect(res.status).toBe(401);
    expect(prismaMock.slackIntegration.upsert).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// DELETE — removes + audits.
// ---------------------------------------------------------------------------

describe("DELETE /api/orgs/:orgId/integrations/slack", () => {
  it("removes the integration row and audits", async () => {
    const res = await DELETE(buildReq("DELETE"), params());
    expect(res.status).toBe(200);
    expect(prismaMock.slackIntegration.deleteMany).toHaveBeenCalledWith({
      where: { organizationId: ORG_ID },
    });
    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    expect(auditMock.mock.calls[0][0].event).toBe("SLACK_INTEGRATION_REMOVED");
  });

  it("skips audit when nothing was actually removed", async () => {
    prismaMock.slackIntegration.deleteMany.mockResolvedValueOnce({ count: 0 });
    const res = await DELETE(buildReq("DELETE"), params());
    expect(res.status).toBe(200);
    await new Promise((r) => setImmediate(r));
    expect(auditMock).not.toHaveBeenCalled();
  });

  it("returns 403 for non-admins", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await DELETE(buildReq("DELETE"), params());
    expect(res.status).toBe(403);
    expect(prismaMock.slackIntegration.deleteMany).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// GET — returns row in UI-safe shape.
// ---------------------------------------------------------------------------

describe("GET /api/orgs/:orgId/integrations/slack", () => {
  it("returns null when no integration exists", async () => {
    const res = await GET(buildReq("GET"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.integration).toBeNull();
  });

  it("returns an integration shape without the plaintext token", async () => {
    prismaMock.slackIntegration.findUnique.mockResolvedValueOnce({
      id: "si-1",
      organizationId: ORG_ID,
      enabled: true,
      botTokenEncrypted: "v2:dummy",
      teamId: "T1",
      teamName: "Acme",
      defaultChannelId: "C1",
      defaultChannelName: "general",
      webhookUrl: null,
      eventPreferences: { rfp_uploaded: true },
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    const res = await GET(buildReq("GET"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.integration).toBeTruthy();
    expect(body.integration.hasBotToken).toBe(true);
    // Plaintext token must never appear in the JSON. We don't know exactly
    // what the prefix is (decrypt failed in this mocked test), but it must
    // not contain the encrypted blob either.
    expect(JSON.stringify(body.integration)).not.toContain("v2:dummy");
    expect(body.integration.teamName).toBe("Acme");
  });

  it("returns 403 for non-admins", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await GET(buildReq("GET"), params());
    expect(res.status).toBe(403);
  });
});
