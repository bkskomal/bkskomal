// Slack integration test send (Tier B1).
//
// Admin-only. POST sends a one-line "Test message from AutoRFP" using the
// org's configured Slack integration. Channel can be overridden via body.
// Returns the same {ok, error?} shape as sendSlackMessage so the UI can
// surface API-specific errors (e.g. "channel_not_found", "not_in_channel").

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { sendSlackMessage } from "@/lib/integrations/slack";

const bodySchema = z.object({
  channelId: z.string().optional(),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);
  const body = bodySchema.parse(await req.json().catch(() => ({})));

  const result = await sendSlackMessage(orgId, {
    text: "Test message from AutoRFP",
    blocks: [
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: ":white_check_mark: *Test message from AutoRFP* — your Slack integration is working.",
        },
      },
    ],
    channel: body.channelId,
    // No eventKind — test sends bypass per-event preferences. The whole point
    // is to verify transport, not to honour the user's mute settings.
  });

  return Response.json({
    ok: result.ok,
    skipped: result.skipped ?? false,
    error: result.error,
  });
});
