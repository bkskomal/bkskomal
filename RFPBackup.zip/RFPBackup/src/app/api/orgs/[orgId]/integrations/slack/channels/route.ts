// Slack channels list (Tier B1).
//
// Admin-only. GET returns the channels the bot can see, for the settings
// page channel picker. Returns an empty array when no bot token is
// configured (webhook-only setups can't enumerate channels).

import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { listSlackChannels } from "@/lib/integrations/slack";

export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);
  const channels = await listSlackChannels(orgId);
  return Response.json({ channels });
});
