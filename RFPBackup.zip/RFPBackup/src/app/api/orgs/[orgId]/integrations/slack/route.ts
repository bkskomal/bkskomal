// Slack integration config route (Tier B1).
//
// GET   — admin-only. Returns the integration row in a UI-safe shape. The
//         bot token is never returned in plaintext; instead we expose a
//         masked prefix so the UI can show "configured" without ever
//         re-rendering the secret.
// PUT   — admin-only. Upserts the integration. Bot token is encrypted at
//         rest via lib/crypto.ts (same versioned envelope as the LLM keys).
//         Sentinel "__KEEP__" leaves the existing token alone — used when
//         the admin saves the form after editing non-secret fields.
// DELETE— admin-only. Drops the row entirely.
//
// All three audit. Audit events are append-only (`SLACK_INTEGRATION_*`,
// declared in lib/audit.ts).

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { encrypt, decrypt, currentKeyId } from "@/lib/crypto";

const KEEP_EXISTING_SECRET = "__KEEP__";

const EVENT_PREFS_SCHEMA = z.object({
  rfp_uploaded: z.boolean().optional(),
  response_generated: z.boolean().optional(),
  mention: z.boolean().optional(),
  outcome_set: z.boolean().optional(),
});

const putSchema = z.object({
  botToken: z.string().nullable().optional(),
  teamName: z.string().nullable().optional(),
  teamId: z.string().nullable().optional(),
  defaultChannelId: z.string().nullable().optional(),
  defaultChannelName: z.string().nullable().optional(),
  webhookUrl: z.string().url().nullable().optional().or(z.literal("")),
  enabled: z.boolean().optional(),
  eventPreferences: EVENT_PREFS_SCHEMA.optional(),
});

/** Show only the bot token's prefix (xoxb-...) — never the secret. The
 *  prefix is enough for the UI to render a "set" indicator and to verify
 *  the user pasted the right *kind* of token. */
function tokenPrefix(token: string | null): string {
  if (!token) return "";
  const seg = token.split("-").slice(0, 2).join("-");
  return seg ? `${seg}-•••` : "•••";
}

export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);
  const row = await prisma.slackIntegration.findUnique({
    where: { organizationId: orgId },
  });
  if (!row) {
    return Response.json({ integration: null });
  }
  const decryptedToken = row.botTokenEncrypted ? decrypt(row.botTokenEncrypted) : null;
  return Response.json({
    integration: {
      id: row.id,
      enabled: row.enabled,
      teamId: row.teamId,
      teamName: row.teamName,
      defaultChannelId: row.defaultChannelId,
      defaultChannelName: row.defaultChannelName,
      webhookUrl: row.webhookUrl,
      botTokenPrefix: tokenPrefix(decryptedToken),
      hasBotToken: Boolean(row.botTokenEncrypted),
      eventPreferences:
        (row.eventPreferences as Record<string, boolean> | null) ?? {
          rfp_uploaded: true,
          response_generated: true,
          mention: true,
          outcome_set: true,
        },
      createdAt: row.createdAt.toISOString(),
      updatedAt: row.updatedAt.toISOString(),
    },
  });
});

export const PUT = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  const body = putSchema.parse(await req.json());

  // Map incoming fields to Prisma payload. Undefined → leave alone;
  // explicit null/empty → clear the column. The bot token has its own
  // KEEP_EXISTING_SECRET sentinel so we can save form edits without
  // re-rendering the secret in HTML.
  const data: Record<string, unknown> = {};
  if (body.teamId !== undefined) data.teamId = body.teamId;
  if (body.teamName !== undefined) data.teamName = body.teamName;
  if (body.defaultChannelId !== undefined) data.defaultChannelId = body.defaultChannelId;
  if (body.defaultChannelName !== undefined) data.defaultChannelName = body.defaultChannelName;
  if (body.webhookUrl !== undefined) {
    data.webhookUrl = body.webhookUrl === "" ? null : body.webhookUrl;
  }
  if (body.enabled !== undefined) data.enabled = body.enabled;
  if (body.eventPreferences !== undefined) {
    data.eventPreferences = body.eventPreferences as unknown as never;
  }

  let tokenTouched = false;
  if (body.botToken !== undefined && body.botToken !== KEEP_EXISTING_SECRET) {
    if (body.botToken === null || body.botToken === "") {
      data.botTokenEncrypted = null;
    } else {
      data.botTokenEncrypted = encrypt(body.botToken);
    }
    tokenTouched = true;
  }

  await prisma.slackIntegration.upsert({
    where: { organizationId: orgId },
    update: data,
    create: {
      organizationId: orgId,
      // Defaults: enabled, all events on. Spread the incoming fields on top.
      enabled: true,
      eventPreferences: {
        rfp_uploaded: true,
        response_generated: true,
        mention: true,
        outcome_set: true,
      } as unknown as never,
      ...data,
    },
  });

  void audit({
    event: "SLACK_INTEGRATION_CONFIGURED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "SlackIntegration",
    targetId: orgId,
    metadata: {
      fields: Object.keys(data),
      tokenTouched,
      keyId: tokenTouched ? currentKeyId() : undefined,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true });
});

export const DELETE = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  const result = await prisma.slackIntegration.deleteMany({
    where: { organizationId: orgId },
  });
  if (result.count > 0) {
    void audit({
      event: "SLACK_INTEGRATION_REMOVED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "SlackIntegration",
      targetId: orgId,
      ...auditContextFromRequest(req),
    });
  }
  return Response.json({ ok: true, removed: result.count });
});
