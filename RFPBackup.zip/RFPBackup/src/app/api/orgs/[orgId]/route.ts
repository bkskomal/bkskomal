import { NextRequest } from "next/server";
import { z } from "zod";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const org = await prisma.organization.findUnique({
      where: { id: orgId },
      include: {
        memberships: { include: { user: true }, orderBy: { createdAt: "asc" } },
        projects: { orderBy: { createdAt: "desc" } },
        indexes: {
          include: { _count: { select: { documents: true } } },
          orderBy: { createdAt: "desc" },
        },
      },
    });
    return Response.json({ org });
  } catch (e) {
    return jsonError(e);
  }
}

const patchSchema = z.object({ name: z.string().min(2).max(80) });

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId, Role.ADMIN);
    const body = patchSchema.parse(await req.json());
    const org = await prisma.organization.update({ where: { id: orgId }, data: body });
    return Response.json({ org });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId, Role.OWNER);
    await prisma.organization.delete({ where: { id: orgId } });
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
