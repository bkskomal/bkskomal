// Phase D — "Test connection" endpoint for the RAG Provider settings card.
// Sends a trivial query to the candidate endpoint with the supplied creds
// (no DB write) and reports {ok, message, sampleCount} so admins can verify
// the contract before saving.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { pingExternalRag } from "@/lib/ai/external-rag";

const bodySchema = z.object({
  endpoint: z.string().url(),
  apiKey: z.string().nullable().optional(),
  extraHeaders: z.record(z.string(), z.string()).optional(),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);

  const body = bodySchema.parse(await req.json());
  const result = await pingExternalRag({
    query: "ping",
    topK: 1,
    indexId: null,
    orgId,
    endpoint: body.endpoint,
    apiKey: body.apiKey ?? null,
    extraHeaders: body.extraHeaders ?? {},
  });
  return Response.json(result);
});
