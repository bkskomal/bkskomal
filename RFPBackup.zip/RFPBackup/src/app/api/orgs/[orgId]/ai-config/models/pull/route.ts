// Stream Ollama model-pull progress to the browser as Server-Sent Events.
//
// The browser POSTs `{ baseUrl, name }`, this route opens a streaming pull
// against the Ollama daemon, and forwards each progress chunk as an SSE
// `data:` line. The connection closes when the pull completes (success
// emits `event: done`; failure emits `event: error`).
//
// Admin-only and audited as a `MODEL_PULLED` event when the pull succeeds.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { streamPullProgress } from "@/lib/ai/ollama";

const bodySchema = z.object({
  baseUrl: z.string().min(1),
  name: z.string().min(1),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  await rateLimit(RATE_LIMITS.providerTest, {
    userId: user.id,
    orgId,
    route: "ai-config/models/pull",
  });

  const body = bodySchema.parse(await req.json());
  const { baseUrl, name } = body;

  const audCtx = auditContextFromRequest(req);

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const encoder = new TextEncoder();
      const send = (event: string, data: unknown) => {
        const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
        controller.enqueue(encoder.encode(payload));
      };

      try {
        send("start", { name });
        for await (const chunk of streamPullProgress(baseUrl, name)) {
          send("progress", chunk);
        }
        send("done", { name });
        void audit({
          event: "MODEL_PULLED",
          actorId: user.id,
          organizationId: orgId,
          targetType: "OllamaModel",
          targetId: name,
          metadata: { baseUrl, model: name },
          ...audCtx,
        });
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        send("error", { error: msg });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      // Disable proxy buffering so the browser sees chunks in real time.
      "x-accel-buffering": "no",
    },
  });
});
