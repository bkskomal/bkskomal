// Fetch the live model list from a provider's /v1/models endpoint. Used by
// the Settings UI to populate the model dropdown after the user picks a
// provider + base URL + key.
//
// Two surfaces:
//   POST  — body { target, baseUrl, apiKey }. Used by the existing detailed
//           form (LLM and embedding sections each fetch their own list with
//           the saved or unsaved key, and the in-process embedder is special-
//           cased to a curated list).
//   GET   — query string `baseUrl` and optional `provider`. Used by the new
//           provider-cards picker. When `provider=ollama` we use the native
//           `/api/tags` endpoint via `listOllamaModels()` so the response
//           includes size and modified-at; for everything else we fall back
//           to the OpenAI-compatible `/v1/models` endpoint.

import { z } from "zod";
import OpenAI from "openai";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { decrypt } from "@/lib/crypto";
import { prisma } from "@/lib/prisma";
import { resolveAiConfig } from "@/lib/ai/config";
import { Role } from "@prisma/client";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { listOllamaModels } from "@/lib/ai/ollama";
import { detectProviderFromUrl } from "@/lib/ai/providers";

const KEEP_EXISTING_SECRET = "__KEEP__";

const bodySchema = z.object({
  target: z.enum(["llm", "embedding"]),
  baseUrl: z.string().min(1),
  apiKey: z.string(),
});

// Known good models for the in-process local embedder. Adding more here
// surfaces them in the Settings dropdown.
const LOCAL_MODELS = [
  "Xenova/all-MiniLM-L6-v2",
  "Xenova/all-mpnet-base-v2",
  "Xenova/multilingual-e5-small",
];

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  await rateLimit(RATE_LIMITS.providerTest, {
    userId: user.id,
    orgId,
    route: "ai-config/models",
  });
  const body = bodySchema.parse(await req.json());

  let apiKey = body.apiKey;
  if (apiKey === KEEP_EXISTING_SECRET) {
    const stored = await prisma.orgAiConfig.findUnique({
      where: { organizationId: orgId },
    });
    if (body.target === "llm") {
      apiKey = decrypt(stored?.llmApiKeyEncrypted) ?? (await resolveAiConfig(orgId)).llm.apiKey;
    } else {
      apiKey = decrypt(stored?.embeddingApiKeyEncrypted) ?? (await resolveAiConfig(orgId)).embedding.apiKey;
    }
  }

  // Local in-process embedder doesn't have a /v1/models endpoint — return a
  // curated list instead.
  if (body.baseUrl.startsWith("local://")) {
    return Response.json({ ok: true, models: LOCAL_MODELS });
  }

  // For Ollama, prefer the native /api/tags endpoint — it returns size and
  // modified-at metadata that the OpenAI-compatible /v1/models endpoint
  // strips out. The Settings form only needs names today, but we route
  // through the same helper so behaviour stays consistent with the new picker.
  if (detectProviderFromUrl(body.baseUrl) === "ollama") {
    try {
      const models = await listOllamaModels(body.baseUrl);
      return Response.json({ ok: true, models: models.map((m) => m.name) });
    } catch (e) {
      return Response.json(
        { ok: false, error: e instanceof Error ? e.message : String(e), models: [] },
        { status: 200 },
      );
    }
  }

  try {
    const client = new OpenAI({ baseURL: body.baseUrl, apiKey: apiKey || "test" });
    const resp = await client.models.list();
    const models = (resp.data ?? [])
      .map((m) => m.id)
      .sort((a, b) => a.localeCompare(b));
    return Response.json({ ok: true, models });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : String(e), models: [] },
      { status: 200 },
    );
  }
});

// GET — used by the provider-cards picker. Doesn't accept an API key (the
// caller has none yet at picker time) so this only works for providers that
// either don't need a key (Ollama, LM Studio, vLLM, LocalAI) or accept any
// dummy string. Authenticated members of the org can call it; rate-limited
// like its POST sibling.
export const GET = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId);
  await rateLimit(RATE_LIMITS.providerTest, {
    userId: user.id,
    orgId,
    route: "ai-config/models",
  });

  const url = new URL(req.url);
  const baseUrl = url.searchParams.get("baseUrl");
  const provider = url.searchParams.get("provider");
  if (!baseUrl) {
    return Response.json({ ok: false, error: "baseUrl is required", models: [] }, { status: 400 });
  }

  if (baseUrl.startsWith("local://")) {
    return Response.json({ ok: true, models: LOCAL_MODELS });
  }

  const detected = provider ?? detectProviderFromUrl(baseUrl);
  if (detected === "ollama") {
    try {
      const models = await listOllamaModels(baseUrl);
      return Response.json({
        ok: true,
        models: models.map((m) => ({
          name: m.name,
          sizeBytes: m.sizeBytes,
          modifiedAt: m.modifiedAt,
        })),
      });
    } catch (e) {
      return Response.json(
        { ok: false, error: e instanceof Error ? e.message : String(e), models: [] },
        { status: 200 },
      );
    }
  }

  try {
    const client = new OpenAI({ baseURL: baseUrl, apiKey: "anonymous" });
    const resp = await client.models.list();
    const models = (resp.data ?? [])
      .map((m) => m.id)
      .sort((a, b) => a.localeCompare(b));
    return Response.json({ ok: true, models });
  } catch (e) {
    return Response.json(
      { ok: false, error: e instanceof Error ? e.message : String(e), models: [] },
      { status: 200 },
    );
  }
});
