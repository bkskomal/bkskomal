// Phase E — "Test connection" endpoint for the Chat Provider settings card.
// Sends a trivial "ping" through the candidate endpoint with the supplied
// creds + metadata defaults and reports {ok, message} so admins can verify
// the contract before saving.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { pingExternalChat } from "@/lib/ai/external-chat";

const bodySchema = z.object({
  endpoint: z.string().url(),
  apiKey: z.string().nullable().optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);

  const body = bodySchema.parse(await req.json());
  const result = await pingExternalChat({
    endpoint: body.endpoint,
    apiKey: body.apiKey ?? null,
    metadata: (body.metadata ?? {}) as Parameters<typeof pingExternalChat>[0]["metadata"],
  });
  return Response.json(result);
});
