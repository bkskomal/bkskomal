// API-key rotation endpoint. Lets an org admin replace the stored LLM and/or
// embedding API keys without going through the full ai-config PUT (which
// touches a lot of fields). The flow:
//
//   1. Validate admin membership.
//   2. Take a rate-limit token (keyRotation rule) — this endpoint changes
//      secrets so we keep the budget tight per-user.
//   3. Decrypt the existing row to make sure we can read it under the current
//      master key. If decrypt() returns null the row is wedged (likely written
//      under a now-discarded AUTH_SECRET with no KEY_ROTATION_SECRET); we
//      proceed anyway since the new ciphertext will simply overwrite it.
//   4. Re-encrypt the new key(s) and write back.
//   5. Audit the event with which keys were touched (never the values).
//
// Returns { ok: true, rotatedAt: <ISO> }. The shared ai-config PUT handler
// still works for normal edits — this route exists so a security-focused UI
// flow has a dedicated endpoint that's clearly auditable as "key rotation".

import { z } from "zod";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { currentKeyId, decrypt, encrypt } from "@/lib/crypto";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

const bodySchema = z
  .object({
    apiKey: z.string().min(1).optional(),
    embeddingApiKey: z.string().min(1).optional(),
  })
  .refine((v) => v.apiKey !== undefined || v.embeddingApiKey !== undefined, {
    message: "Provide at least one of apiKey or embeddingApiKey",
  });

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  // Tight budget — rotating a key is a low-frequency operation; abuse here
  // probably means someone is brute-forcing the admin session. Prefer a
  // dedicated `keyRotation` rule if RATE_LIMITS exposes one (owned by the
  // rate-limit module); otherwise fall back to the providerTest budget which
  // has similar shape (10/min, user scope).
  const rules = RATE_LIMITS as typeof RATE_LIMITS & { keyRotation?: typeof RATE_LIMITS.providerTest };
  const keyRotationRule = rules.keyRotation ?? RATE_LIMITS.providerTest;
  await rateLimit(keyRotationRule, {
    userId: user.id,
    orgId,
    route: "ai-config/rotate",
  });

  const body = bodySchema.parse(await req.json());

  // We deliberately allow rotating against an empty row — the upsert below
  // will create the row if it doesn't exist. Read the existing one only to
  // sanity-check that we can still decrypt the previous ciphertext under the
  // current key (or the rotation key, if KEY_ROTATION_SECRET is set).
  const existing = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
  });

  const rotated: string[] = [];
  const data: Record<string, unknown> = {};

  if (body.apiKey !== undefined) {
    data.llmApiKeyEncrypted = encrypt(body.apiKey);
    rotated.push("llm");
  }
  if (body.embeddingApiKey !== undefined) {
    data.embeddingApiKeyEncrypted = encrypt(body.embeddingApiKey);
    rotated.push("embedding");
  }

  await prisma.orgAiConfig.upsert({
    where: { organizationId: orgId },
    update: data,
    create: { organizationId: orgId, ...data },
  });

  const rotatedAt = new Date().toISOString();

  // Fire-and-forget audit. Note: we record *which* keys rotated and the
  // key-format id of the new ciphertext, never the keys themselves. The
  // `prevReadable` flag lets the auditor spot rows that were unreadable at
  // rotation time (i.e. would have been wedged without this rotation).
  void audit({
    event: "API_KEY_ROTATED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: existing?.id ?? orgId,
    metadata: {
      rotated,
      keyId: currentKeyId(),
      prevLlmReadable: body.apiKey !== undefined
        ? decrypt(existing?.llmApiKeyEncrypted) !== null
        : undefined,
      prevEmbeddingReadable: body.embeddingApiKey !== undefined
        ? decrypt(existing?.embeddingApiKeyEncrypted) !== null
        : undefined,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true, rotatedAt, rotated });
});
