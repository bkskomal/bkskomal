// Test the AI configuration without persisting it. The form sends the values
// the user is currently looking at; we build a one-off OpenAI client with
// those, ping the endpoint, and report whether it works.
//
// Two modes: "llm" makes a 1-token chat completion; "embedding" makes a
// trivial embedding call.

import { z } from "zod";
import OpenAI from "openai";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { resolveAiConfig } from "@/lib/ai/config";
import { decrypt } from "@/lib/crypto";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";
import { embedLocal, isLocalEmbeddingUrl } from "@/lib/ai/embeddings-local";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

const KEEP_EXISTING_SECRET = "__KEEP__";

const bodySchema = z.object({
  target: z.enum(["llm", "embedding"]),
  // Accept any URL-like string (incl. our `local://` sentinel).
  baseUrl: z.string().min(1),
  /** "__KEEP__" means use the currently-saved key. */
  apiKey: z.string(),
  model: z.string(),
  httpReferer: z.string().optional(),
  appTitle: z.string().optional(),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  await rateLimit(RATE_LIMITS.providerTest, {
    userId: user.id,
    orgId,
    route: "ai-config/test",
  });
  const body = bodySchema.parse(await req.json());

  // Resolve the saved key if the user kept the existing one.
  let apiKey = body.apiKey;
  if (apiKey === KEEP_EXISTING_SECRET) {
    const stored = await prisma.orgAiConfig.findUnique({
      where: { organizationId: orgId },
    });
    if (body.target === "llm") {
      apiKey =
        decrypt(stored?.llmApiKeyEncrypted) ?? (await resolveAiConfig(orgId)).llm.apiKey;
    } else {
      apiKey =
        decrypt(stored?.embeddingApiKeyEncrypted) ?? (await resolveAiConfig(orgId)).embedding.apiKey;
    }
  }

  const headers: Record<string, string> = {};
  if (body.httpReferer) headers["HTTP-Referer"] = body.httpReferer;
  if (body.appTitle) headers["X-Title"] = body.appTitle;

  const started = Date.now();

  // Local in-process embeddings — bypass the OpenAI client entirely.
  if (body.target === "embedding" && isLocalEmbeddingUrl(body.baseUrl)) {
    try {
      const vec = await embedLocal("AutoRFP connection test", body.model);
      return Response.json({
        ok: true,
        target: "embedding",
        model: body.model,
        elapsedMs: Date.now() - started,
        dimensions: vec.length,
      });
    } catch (e) {
      return Response.json({
        ok: false,
        target: "embedding",
        error: e instanceof Error ? e.message : String(e),
        elapsedMs: Date.now() - started,
      });
    }
  }

  const client = new OpenAI({
    baseURL: body.baseUrl,
    apiKey: apiKey || "test",
    defaultHeaders: Object.keys(headers).length ? headers : undefined,
  });

  try {
    if (body.target === "llm") {
      const resp = await client.chat.completions.create({
        model: body.model,
        max_tokens: 5,
        temperature: 0,
        messages: [{ role: "user", content: "Reply with: OK" }],
      });
      const elapsed = Date.now() - started;
      return Response.json({
        ok: true,
        target: "llm",
        model: body.model,
        elapsedMs: elapsed,
        sample: resp.choices[0]?.message?.content?.slice(0, 100) ?? "",
        usage: resp.usage ?? null,
      });
    }
    const resp = await client.embeddings.create({
      model: body.model,
      input: "AutoRFP connection test",
    });
    const elapsed = Date.now() - started;
    const dims = resp.data[0]?.embedding?.length ?? 0;
    return Response.json({
      ok: true,
      target: "embedding",
      model: body.model,
      elapsedMs: elapsed,
      dimensions: dims,
    });
  } catch (e) {
    return Response.json(
      {
        ok: false,
        target: body.target,
        error: explainError(e),
        elapsedMs: Date.now() - started,
      },
      { status: 200 }, // 200 — connection-test failure isn't a server error
    );
  }
});

/**
 * The OpenAI SDK wraps fetch errors as a generic "Connection error." — strip
 * that and surface the underlying Node fetch / undici cause + code so the user
 * can act on it. Maps the most common ones to actionable messages.
 */
function explainError(e: unknown): string {
  const err = e as any;
  const code = err?.cause?.code ?? err?.code;
  const causeMsg = err?.cause?.message;
  const message = err?.message ?? String(e);
  const detail = causeMsg && causeMsg !== message ? causeMsg : null;

  if (
    code === "UNABLE_TO_VERIFY_LEAF_SIGNATURE" ||
    code === "SELF_SIGNED_CERT_IN_CHAIN" ||
    code === "DEPTH_ZERO_SELF_SIGNED_CERT" ||
    code === "CERT_HAS_EXPIRED"
  ) {
    return `TLS verification failed (${code}). You're likely behind a corporate proxy with a custom CA. Fix: set NODE_EXTRA_CA_CERTS=/path/to/ca-bundle.pem before starting the dev server, or (dev only) NODE_TLS_REJECT_UNAUTHORIZED=0.`;
  }
  if (code === "ENOTFOUND") {
    return `DNS lookup failed (${detail ?? "ENOTFOUND"}). Check the endpoint URL.`;
  }
  if (code === "ECONNREFUSED") {
    return `Connection refused (${detail ?? "ECONNREFUSED"}). Is the server running on the URL you entered?`;
  }
  if (code === "ETIMEDOUT" || code === "UND_ERR_CONNECT_TIMEOUT") {
    return `Connection timed out. The endpoint isn't reachable from this server.`;
  }
  if (err?.status === 401) return `401 Unauthorized — the API key is invalid or expired.`;
  if (err?.status === 404) {
    return `404 Not Found — the model "${err?.error?.message ?? "(unknown)"}" doesn't exist on this endpoint.`;
  }
  if (err?.status === 429) return `429 Rate limit — the provider is throttling you.`;
  if (typeof err?.status === "number" && err.status >= 500) {
    return `Provider returned ${err.status}: ${detail ?? message}`;
  }

  return detail ? `${message} (${detail})` : message;
}
