import { z } from "zod";
import { AiProvider } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { resolveAiConfig } from "@/lib/ai/config";
import { currentKeyId, encrypt, maskSecret } from "@/lib/crypto";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";

/**
 * Sentinel value the UI sends back when the user kept the existing (masked)
 * secret. Lets us avoid re-saving an already-encrypted value or storing the
 * mask.
 */
const KEEP_EXISTING_SECRET = "__KEEP__";

export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId);
  const resolved = await resolveAiConfig(orgId);

  // Routing fields aren't in `ResolvedAiConfig` (they're not per-request
  // values), so read them directly. Cheap — already-cached connection.
  const routingRow = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: { routingEnabled: true, llmModelSimple: true, llmModelComplex: true },
  });

  return Response.json({
    config: {
      llm: {
        provider: resolved.llm.provider,
        baseUrl: resolved.llm.baseUrl,
        apiKeyMasked: maskSecret(resolved.llm.apiKey),
        hasApiKey: Boolean(resolved.llm.apiKey),
        model: resolved.llm.model,
        httpReferer: resolved.llm.httpReferer ?? "",
        appTitle: resolved.llm.appTitle ?? "",
      },
      embedding: {
        provider: resolved.embedding.provider,
        baseUrl: resolved.embedding.baseUrl,
        apiKeyMasked: maskSecret(resolved.embedding.apiKey),
        hasApiKey: Boolean(resolved.embedding.apiKey),
        model: resolved.embedding.model,
        dimensions: resolved.embedding.dimensions,
      },
      llamaparse: {
        enabled: resolved.llamaparse.enabled,
        apiKeyMasked: maskSecret(resolved.llamaparse.apiKey ?? ""),
        hasApiKey: Boolean(resolved.llamaparse.apiKey),
        resultType: resolved.llamaparse.resultType,
      },
      // Model routing (Phase 3B). The standard model lives on `llm.model` —
      // we only return the per-tier overrides + the master toggle here.
      routing: {
        enabled: routingRow?.routingEnabled ?? false,
        modelSimple: routingRow?.llmModelSimple ?? "",
        modelComplex: routingRow?.llmModelComplex ?? "",
      },
      // Phase A: RAG / retrieval layer. Fully resolved (defaults baked in).
      retrieval: resolved.retrieval,
      // Phase A.2: question extraction. `batchSizeBytes` is the resolved value
      // in bytes; the UI displays + edits it as KB.
      extraction: {
        model: resolved.extraction.model,
        promptOverride: resolved.extraction.promptOverride,
        eligibilityEnabled: resolved.extraction.eligibilityEnabled,
        batchSizeKb: Math.round(resolved.extraction.batchSizeBytes / 1024),
        concurrency: resolved.extraction.concurrency,
      },
      // Phase A.3: web scraping. Headless token is write-only — mask + flag.
      scraping: {
        engine: resolved.scraping.engine,
        headlessUrl: resolved.scraping.headlessUrl,
        headlessTokenMasked: maskSecret(resolved.scraping.headlessToken ?? ""),
        hasHeadlessToken: Boolean(resolved.scraping.headlessToken),
        respectRobots: resolved.scraping.respectRobots,
        timeoutMs: resolved.scraping.timeoutMs,
        maxImages: resolved.scraping.maxImages,
      },
      // Phase D: RAG provider. apiKey is write-only — mask + flag.
      ragProvider: {
        kind: resolved.ragProvider.kind,
        endpoint: resolved.ragProvider.endpoint,
        apiKeyMasked: maskSecret(resolved.ragProvider.apiKey ?? ""),
        hasApiKey: Boolean(resolved.ragProvider.apiKey),
        extraHeaders: resolved.ragProvider.extraHeaders,
      },
      // Phase E: chat provider. Same secret-handling pattern.
      chatProvider: {
        kind: resolved.chatProvider.kind,
        endpoint: resolved.chatProvider.endpoint,
        apiKeyMasked: maskSecret(resolved.chatProvider.apiKey ?? ""),
        hasApiKey: Boolean(resolved.chatProvider.apiKey),
        metadata: resolved.chatProvider.metadata,
      },
      // Phase A.4: answer generation.
      generation: {
        pinnedModel: resolved.generation.pinnedModel,
        groundingEnabled: resolved.generation.groundingEnabled,
        groundingModel: resolved.generation.groundingModel,
        cacheEnabled: resolved.generation.cacheEnabled,
        cacheSimilarityThreshold: resolved.generation.cacheSimilarityThreshold,
      },
      source: resolved.source,
    },
  });
});

const putSchema = z.object({
  llm: z
    .object({
      provider: z.nativeEnum(AiProvider).nullable().optional(),
      baseUrl: z.string().url().nullable().optional(),
      apiKey: z.string().nullable().optional(),
      model: z.string().nullable().optional(),
      httpReferer: z.string().nullable().optional(),
      appTitle: z.string().nullable().optional(),
    })
    .optional(),
  // Model routing (Phase 3B). Optional — when absent we leave existing
  // routing fields alone. `null` for the model overrides clears the per-tier
  // override (falls back to llmModel at request time).
  routing: z
    .object({
      enabled: z.boolean().optional(),
      modelSimple: z.string().nullable().optional(),
      modelComplex: z.string().nullable().optional(),
    })
    .optional(),
  embedding: z
    .object({
      provider: z.nativeEnum(AiProvider).nullable().optional(),
      baseUrl: z.string().url().nullable().optional(),
      apiKey: z.string().nullable().optional(),
      model: z.string().nullable().optional(),
      dimensions: z.number().int().min(1).max(8192).nullable().optional(),
    })
    .optional(),
  llamaparse: z
    .object({
      enabled: z.boolean().optional(),
      apiKey: z.string().nullable().optional(),
      resultType: z.enum(["text", "markdown"]).nullable().optional(),
    })
    .optional(),
  // Phase A: RAG / retrieval layer. All fields optional; null clears the
  // override (falls back to defaults at resolve time).
  retrieval: z
    .object({
      strategy: z.enum(["HYBRID", "DENSE_ONLY", "SPARSE_ONLY"]).nullable().optional(),
      rerankerKind: z.enum(["NONE", "LLM", "CROSS_ENCODER"]).nullable().optional(),
      rerankerModel: z.string().nullable().optional(),
      rerankerTopK: z.number().int().min(1).max(200).nullable().optional(),
      topK: z.number().int().min(1).max(50).nullable().optional(),
      rrfK: z.number().int().min(1).max(1000).nullable().optional(),
      denseWeight: z.number().min(0).max(1).nullable().optional(),
      contextualEnabled: z.boolean().nullable().optional(),
    })
    .optional(),
  // Phase A.2: question extraction. `batchSizeKb` here matches the UI unit;
  // resolver converts to bytes.
  extraction: z
    .object({
      model: z.string().nullable().optional(),
      promptOverride: z.string().nullable().optional(),
      eligibilityEnabled: z.boolean().nullable().optional(),
      batchSizeKb: z.number().int().min(1).max(128).nullable().optional(),
      concurrency: z.number().int().min(1).max(16).nullable().optional(),
    })
    .optional(),
  // Phase A.3: scraping. headlessToken uses the KEEP_EXISTING_SECRET sentinel
  // so masked-token round-trips don't accidentally re-save the mask.
  scraping: z
    .object({
      engine: z.enum(["STATIC", "PLAYWRIGHT", "BROWSERLESS"]).nullable().optional(),
      headlessUrl: z.string().nullable().optional(),
      headlessToken: z.string().nullable().optional(),
      respectRobots: z.boolean().nullable().optional(),
      timeoutMs: z.number().int().min(1000).max(120_000).nullable().optional(),
      maxImages: z.number().int().min(0).max(500).nullable().optional(),
    })
    .optional(),
  // Phase D: RAG provider. apiKey uses KEEP_EXISTING_SECRET sentinel.
  ragProvider: z
    .object({
      kind: z.enum(["INTERNAL", "EXTERNAL_HTTP"]).nullable().optional(),
      endpoint: z.string().nullable().optional(),
      apiKey: z.string().nullable().optional(),
      extraHeaders: z.record(z.string(), z.string()).nullable().optional(),
    })
    .optional(),
  // Phase E: chat provider. Same secret pattern; metadata is a permissive
  // record so admins can add OATI-specific fields without schema churn.
  chatProvider: z
    .object({
      kind: z.enum(["INTERNAL", "OATI_USER_PROMPT"]).nullable().optional(),
      endpoint: z.string().nullable().optional(),
      apiKey: z.string().nullable().optional(),
      metadata: z
        .object({
          user_id: z.number().int().nullable().optional(),
          organization_id: z.number().int().nullable().optional(),
          user_name: z.string().nullable().optional(),
          user_timezone: z.string().nullable().optional(),
          client: z.string().nullable().optional(),
          product: z.string().nullable().optional(),
          data_source: z.array(z.string()).nullable().optional(),
          source: z.string().nullable().optional(),
          enable_query_analyzer: z.boolean().nullable().optional(),
          enable_follow_up: z.boolean().nullable().optional(),
          enable_abbreviation: z.boolean().nullable().optional(),
          json_stream: z.boolean().nullable().optional(),
        })
        .nullable()
        .optional(),
    })
    .optional(),
  // Phase A.4: answer generation. Empty strings clear pinned/grounding model.
  generation: z
    .object({
      pinnedModel: z.string().nullable().optional(),
      groundingEnabled: z.boolean().nullable().optional(),
      groundingModel: z.string().nullable().optional(),
      cacheEnabled: z.boolean().nullable().optional(),
      cacheSimilarityThreshold: z.number().min(0.5).max(1).nullable().optional(),
    })
    .optional(),
});

function maybeEncrypt(value: string | null | undefined): string | null | undefined {
  if (value === undefined) return undefined;
  if (value === null) return null;
  if (value === KEEP_EXISTING_SECRET) return undefined;
  if (value === "") return null;
  return encrypt(value);
}

export const PUT = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  // Only ADMIN/OWNER can change AI config — affects spend.
  const { user } = await requireMembership(orgId, Role.ADMIN);

  const body = putSchema.parse(await req.json());

  // Build a Prisma update payload. `undefined` means "leave alone";
  // explicit `null` means "clear this override and fall back to env".
  const data: Record<string, unknown> = {};
  if (body.llm) {
    if (body.llm.provider !== undefined) data.llmProvider = body.llm.provider;
    if (body.llm.baseUrl !== undefined) data.llmBaseUrl = body.llm.baseUrl;
    const enc = maybeEncrypt(body.llm.apiKey);
    if (enc !== undefined) data.llmApiKeyEncrypted = enc;
    if (body.llm.model !== undefined) data.llmModel = body.llm.model;
    if (body.llm.httpReferer !== undefined) data.llmHttpReferer = body.llm.httpReferer;
    if (body.llm.appTitle !== undefined) data.llmAppTitle = body.llm.appTitle;
  }
  if (body.embedding) {
    if (body.embedding.provider !== undefined) data.embeddingProvider = body.embedding.provider;
    if (body.embedding.baseUrl !== undefined) data.embeddingBaseUrl = body.embedding.baseUrl;
    const enc = maybeEncrypt(body.embedding.apiKey);
    if (enc !== undefined) data.embeddingApiKeyEncrypted = enc;
    if (body.embedding.model !== undefined) data.embeddingModel = body.embedding.model;
    if (body.embedding.dimensions !== undefined) data.embeddingDimensions = body.embedding.dimensions;
  }
  if (body.llamaparse) {
    if (body.llamaparse.enabled !== undefined) data.llamaParseEnabled = body.llamaparse.enabled;
    const enc = maybeEncrypt(body.llamaparse.apiKey);
    if (enc !== undefined) data.llamaParseApiKeyEncrypted = enc;
    if (body.llamaparse.resultType !== undefined) data.llamaParseResultType = body.llamaparse.resultType;
  }
  if (body.routing) {
    // Phase 3B model routing. Same merge semantics as the rest of the form:
    // undefined → leave alone, null → clear override (fall back to llmModel
    // at request time).
    if (body.routing.enabled !== undefined) data.routingEnabled = body.routing.enabled;
    if (body.routing.modelSimple !== undefined) data.llmModelSimple = body.routing.modelSimple;
    if (body.routing.modelComplex !== undefined) data.llmModelComplex = body.routing.modelComplex;
  }
  if (body.retrieval) {
    // Phase A. null = clear (fall back to default), undefined = leave alone.
    if (body.retrieval.strategy !== undefined) data.retrievalStrategy = body.retrieval.strategy;
    if (body.retrieval.rerankerKind !== undefined) data.rerankerKind = body.retrieval.rerankerKind;
    if (body.retrieval.rerankerModel !== undefined) data.rerankerModel = body.retrieval.rerankerModel;
    if (body.retrieval.rerankerTopK !== undefined) data.rerankerTopK = body.retrieval.rerankerTopK;
    if (body.retrieval.topK !== undefined) data.retrievalTopK = body.retrieval.topK;
    if (body.retrieval.rrfK !== undefined) data.rrfK = body.retrieval.rrfK;
    if (body.retrieval.denseWeight !== undefined) data.hybridDenseWeight = body.retrieval.denseWeight;
    if (body.retrieval.contextualEnabled !== undefined) data.contextualRetrievalEnabled = body.retrieval.contextualEnabled;
  }
  if (body.extraction) {
    // Phase A.2. Empty string for promptOverride means "use built-in" — store
    // as null so the resolver falls back; same goes for empty model.
    if (body.extraction.model !== undefined) {
      data.extractionModel = body.extraction.model === "" ? null : body.extraction.model;
    }
    if (body.extraction.promptOverride !== undefined) {
      data.extractionPromptOverride =
        body.extraction.promptOverride === "" ? null : body.extraction.promptOverride;
    }
    if (body.extraction.eligibilityEnabled !== undefined) {
      data.extractionEligibilityEnabled = body.extraction.eligibilityEnabled;
    }
    if (body.extraction.batchSizeKb !== undefined) {
      data.extractionBatchKb = body.extraction.batchSizeKb;
    }
    if (body.extraction.concurrency !== undefined) {
      data.extractionConcurrency = body.extraction.concurrency;
    }
  }
  if (body.scraping) {
    // Phase A.3. Same null=clear / undefined=leave-alone / KEEP_EXISTING_SECRET
    // semantics as other secret-bearing fields.
    if (body.scraping.engine !== undefined) data.scraperEngine = body.scraping.engine;
    if (body.scraping.headlessUrl !== undefined) {
      data.scraperHeadlessUrl = body.scraping.headlessUrl === "" ? null : body.scraping.headlessUrl;
    }
    const encTok = maybeEncrypt(body.scraping.headlessToken);
    if (encTok !== undefined) data.scraperHeadlessTokenEncrypted = encTok;
    if (body.scraping.respectRobots !== undefined) data.scraperRespectRobots = body.scraping.respectRobots;
    if (body.scraping.timeoutMs !== undefined) data.scraperTimeoutMs = body.scraping.timeoutMs;
    if (body.scraping.maxImages !== undefined) data.scraperMaxImages = body.scraping.maxImages;
  }
  if (body.ragProvider) {
    // Phase D. Same null=clear semantics.
    if (body.ragProvider.kind !== undefined) data.ragProvider = body.ragProvider.kind;
    if (body.ragProvider.endpoint !== undefined) {
      data.ragEndpoint = body.ragProvider.endpoint === "" ? null : body.ragProvider.endpoint;
    }
    const encRagKey = maybeEncrypt(body.ragProvider.apiKey);
    if (encRagKey !== undefined) data.ragApiKeyEncrypted = encRagKey;
    if (body.ragProvider.extraHeaders !== undefined) {
      data.ragExtraHeaders = body.ragProvider.extraHeaders as never;
    }
  }
  if (body.chatProvider) {
    // Phase E. Strip metadata of `null` values so the JSON column doesn't
    // accumulate dead keys; admin sees their actual defaults on re-load.
    if (body.chatProvider.kind !== undefined) data.chatProvider = body.chatProvider.kind;
    if (body.chatProvider.endpoint !== undefined) {
      data.chatEndpoint = body.chatProvider.endpoint === "" ? null : body.chatProvider.endpoint;
    }
    const encChatKey = maybeEncrypt(body.chatProvider.apiKey);
    if (encChatKey !== undefined) data.chatApiKeyEncrypted = encChatKey;
    if (body.chatProvider.metadata !== undefined) {
      const md = body.chatProvider.metadata ?? {};
      const cleaned: Record<string, unknown> = {};
      for (const [k, v] of Object.entries(md)) if (v !== null && v !== undefined) cleaned[k] = v;
      data.chatProviderMetadata = cleaned as never;
    }
  }
  if (body.generation) {
    // Phase A.4. Empty string → null (clear pin); same null=clear semantics.
    if (body.generation.pinnedModel !== undefined) {
      data.generationModel = body.generation.pinnedModel === "" ? null : body.generation.pinnedModel;
    }
    if (body.generation.groundingEnabled !== undefined) data.groundingEnabled = body.generation.groundingEnabled;
    if (body.generation.groundingModel !== undefined) {
      data.groundingModel = body.generation.groundingModel === "" ? null : body.generation.groundingModel;
    }
    if (body.generation.cacheEnabled !== undefined) data.cacheEnabled = body.generation.cacheEnabled;
    if (body.generation.cacheSimilarityThreshold !== undefined) {
      data.cacheSimilarityThreshold = body.generation.cacheSimilarityThreshold;
    }
  }

  await prisma.orgAiConfig.upsert({
    where: { organizationId: orgId },
    update: data,
    create: { organizationId: orgId, ...data },
  });

  // Record any secret-field changes as audit events. We rely on the
  // maybeEncrypt() pattern above: `data.*ApiKeyEncrypted` is only set when
  // the user supplied a new value (or explicit null). `KEEP_EXISTING_SECRET`
  // is filtered out before we get here, so these checks accurately reflect
  // "the admin touched this key in this request".
  const keysChanged: string[] = [];
  if ("llmApiKeyEncrypted" in data) keysChanged.push("llm");
  if ("embeddingApiKeyEncrypted" in data) keysChanged.push("embedding");
  if ("llamaParseApiKeyEncrypted" in data) keysChanged.push("llamaparse");
  if ("scraperHeadlessTokenEncrypted" in data) keysChanged.push("scraperHeadless");
  if ("ragApiKeyEncrypted" in data) keysChanged.push("ragProvider");
  if ("chatApiKeyEncrypted" in data) keysChanged.push("chatProvider");
  if (keysChanged.length > 0) {
    void audit({
      event: "API_KEY_SET",
      actorId: user.id,
      organizationId: orgId,
      targetType: "OrgAiConfig",
      targetId: orgId,
      metadata: { keys: keysChanged, keyId: currentKeyId() },
      ...auditContextFromRequest(req),
    });
  }

  const resolved = await resolveAiConfig(orgId);
  return Response.json({ ok: true, source: resolved.source });
});

export const DELETE = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);
  await prisma.orgAiConfig.deleteMany({ where: { organizationId: orgId } });
  return Response.json({ ok: true });
});
