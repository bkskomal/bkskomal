import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";
import { embedGoldenAnswer } from "@/lib/ai/golden-search";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const items = await prisma.goldenAnswer.findMany({
      where: { organizationId: orgId },
      orderBy: { updatedAt: "desc" },
    });
    return Response.json({ items });
  } catch (e) {
    return jsonError(e);
  }
}

const createSchema = z.object({
  question: z.string().min(3),
  answer: z.string().min(3),
  tags: z.array(z.string()).optional().default([]),
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const body = createSchema.parse(await req.json());
    const item = await prisma.goldenAnswer.create({
      data: { ...body, organizationId: orgId },
    });
    // Fire-and-forget BGE embedding — never blocks the write. If the embedder
    // is down, the row is still created; the embedding fills in on next save.
    void embedGoldenAnswer(item.id);
    return Response.json({ item }, { status: 201 });
  } catch (e) {
    return jsonError(e);
  }
}
