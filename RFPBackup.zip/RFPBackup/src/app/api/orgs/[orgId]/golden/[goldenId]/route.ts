import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";
import { embedGoldenAnswer } from "@/lib/ai/golden-search";

const patchSchema = z.object({
  question: z.string().min(3).optional(),
  answer: z.string().min(3).optional(),
  tags: z.array(z.string()).optional(),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ orgId: string; goldenId: string }> },
) {
  try {
    const { orgId, goldenId } = await params;
    await requireMembership(orgId);
    const body = patchSchema.parse(await req.json());
    const item = await prisma.goldenAnswer.update({ where: { id: goldenId }, data: body });
    // Re-embed when the question text changed. embedGoldenAnswer is
    // idempotent — it no-ops when the embedding is already current.
    if (body.question != null) void embedGoldenAnswer(item.id);
    return Response.json({ item });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ orgId: string; goldenId: string }> },
) {
  try {
    const { orgId, goldenId } = await params;
    await requireMembership(orgId);
    await prisma.goldenAnswer.delete({ where: { id: goldenId } });
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
