// SAML connection-test endpoint. Cheap sanity-checks that won't catch every
// IdP misconfiguration but should catch the common ones:
//   * Certificate parses (must look like a PEM or bare base64 cert)
//   * SSO URL is reachable (HEAD probe, 5s timeout)
// Doesn't actually round-trip an assertion — that requires a real user
// browser session. The Test button in the admin UI is for "did I paste this
// right" not "is the whole flow working end-to-end."

import { NextRequest } from "next/server";
import { Role } from "@prisma/client";
import { jsonError, requireMembership } from "@/lib/authz";
import { prisma } from "@/lib/prisma";

async function probeUrl(url: string): Promise<{ ok: boolean; status?: number; error?: string }> {
  try {
    const ac = new AbortController();
    const to = setTimeout(() => ac.abort(), 5000);
    try {
      const res = await fetch(url, { method: "HEAD", signal: ac.signal, redirect: "manual" });
      return { ok: res.status < 500, status: res.status };
    } finally {
      clearTimeout(to);
    }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
}

function certLooksValid(cert: string): boolean {
  const trimmed = cert.trim();
  if (!trimmed) return false;
  if (trimmed.includes("-----BEGIN CERTIFICATE-----")) {
    // Should also have the matching footer.
    return trimmed.includes("-----END CERTIFICATE-----");
  }
  // Bare base64: must be non-trivial length and only contain b64 chars.
  if (trimmed.length < 100) return false;
  return /^[A-Za-z0-9+/=\s]+$/.test(trimmed);
}

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ orgId: string }> },
) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId, Role.ADMIN);

    const row = await prisma.samlConfig.findUnique({ where: { organizationId: orgId } });
    if (!row) {
      return Response.json({ ok: false, errors: ["SAML is not configured"] }, { status: 404 });
    }

    const errors: string[] = [];
    if (!certLooksValid(row.idpCertificate)) {
      errors.push("idpCertificate does not look like a valid PEM/base64 certificate");
    }
    try {
      const u = new URL(row.idpSsoUrl);
      if (u.protocol !== "https:" && u.protocol !== "http:") {
        errors.push("idpSsoUrl is not http(s)");
      }
    } catch {
      errors.push("idpSsoUrl is not a valid URL");
    }
    const probe = await probeUrl(row.idpSsoUrl);
    if (!probe.ok) {
      errors.push(
        `idpSsoUrl is not reachable: ${probe.error ?? `HTTP ${probe.status ?? "unknown"}`}`,
      );
    }

    return Response.json({
      ok: errors.length === 0,
      errors: errors.length ? errors : undefined,
      probe: { reachable: probe.ok, status: probe.status },
    });
  } catch (e) {
    return jsonError(e);
  }
}
