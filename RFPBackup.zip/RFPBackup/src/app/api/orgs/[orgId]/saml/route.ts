// Admin-only SAML configuration management.
//
//   GET    — return the current SamlConfig (cert truncated for display)
//   PUT    — upsert the SamlConfig; audited as SAML_CONFIGURED
//   DELETE — remove the SamlConfig; audited as SAML_REMOVED
//
// Cert handling: clients only ever PUT the cert. GET returns a truncated form
// ("first 40 + ... + last 40") so admin UIs can confirm it's set without
// echoing the full PEM (which would inflate the wire payload and isn't
// secret, just unwieldy).

import { NextRequest } from "next/server";
import { z } from "zod";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";

function truncateCert(cert: string | null | undefined): string | null {
  if (!cert) return null;
  const compact = cert.replace(/\s+/g, " ").trim();
  if (compact.length <= 96) return compact;
  return `${compact.slice(0, 40)}…${compact.slice(-40)}`;
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ orgId: string }> },
) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId, Role.ADMIN);
    const row = await prisma.samlConfig.findUnique({ where: { organizationId: orgId } });
    if (!row) return Response.json({ config: null });
    return Response.json({
      config: {
        id: row.id,
        idpEntityId: row.idpEntityId,
        idpSsoUrl: row.idpSsoUrl,
        idpCertificatePreview: truncateCert(row.idpCertificate),
        idpCertificateLength: row.idpCertificate.length,
        spEntityId: row.spEntityId,
        attributeMappings: row.attributeMappings,
        enforced: row.enforced,
        enabled: row.enabled,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
      },
    });
  } catch (e) {
    return jsonError(e);
  }
}

const attributeMappingsSchema = z
  .object({
    email: z.string().min(1).optional(),
    name: z.string().optional(),
    groups: z.string().optional(),
    externalId: z.string().optional(),
  })
  .optional();

const putSchema = z.object({
  idpEntityId: z.string().min(1),
  idpSsoUrl: z.string().url(),
  idpCertificate: z.string().min(20),
  spEntityId: z.string().min(1).optional(),
  attributeMappings: attributeMappingsSchema,
  enforced: z.boolean().optional(),
  enabled: z.boolean().optional(),
});

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ orgId: string }> },
) {
  try {
    const { orgId } = await params;
    const { user } = await requireMembership(orgId, Role.ADMIN);
    const body = putSchema.parse(await req.json());

    const mappings = {
      email: body.attributeMappings?.email ?? "email",
      name: body.attributeMappings?.name ?? "name",
      groups: body.attributeMappings?.groups ?? "groups",
      externalId: body.attributeMappings?.externalId ?? "externalId",
    };

    const row = await prisma.samlConfig.upsert({
      where: { organizationId: orgId },
      update: {
        idpEntityId: body.idpEntityId,
        idpSsoUrl: body.idpSsoUrl,
        idpCertificate: body.idpCertificate,
        spEntityId: body.spEntityId ?? null,
        attributeMappings: mappings,
        ...(body.enforced !== undefined ? { enforced: body.enforced } : {}),
        ...(body.enabled !== undefined ? { enabled: body.enabled } : {}),
      },
      create: {
        organizationId: orgId,
        idpEntityId: body.idpEntityId,
        idpSsoUrl: body.idpSsoUrl,
        idpCertificate: body.idpCertificate,
        spEntityId: body.spEntityId ?? null,
        attributeMappings: mappings,
        enforced: body.enforced ?? false,
        enabled: body.enabled ?? true,
      },
    });

    void audit({
      event: "SAML_CONFIGURED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "samlConfig",
      targetId: row.id,
      metadata: {
        idpEntityId: row.idpEntityId,
        enforced: row.enforced,
        enabled: row.enabled,
      },
      ...auditContextFromRequest(req),
    });

    return Response.json({
      config: {
        id: row.id,
        idpEntityId: row.idpEntityId,
        idpSsoUrl: row.idpSsoUrl,
        idpCertificatePreview: truncateCert(row.idpCertificate),
        idpCertificateLength: row.idpCertificate.length,
        spEntityId: row.spEntityId,
        attributeMappings: row.attributeMappings,
        enforced: row.enforced,
        enabled: row.enabled,
      },
    });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ orgId: string }> },
) {
  try {
    const { orgId } = await params;
    const { user } = await requireMembership(orgId, Role.ADMIN);
    const existing = await prisma.samlConfig.findUnique({
      where: { organizationId: orgId },
    });
    if (!existing) return Response.json({ ok: true });
    await prisma.samlConfig.delete({ where: { organizationId: orgId } });

    void audit({
      event: "SAML_REMOVED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "samlConfig",
      targetId: existing.id,
      metadata: { idpEntityId: existing.idpEntityId },
      ...auditContextFromRequest(req),
    });

    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
