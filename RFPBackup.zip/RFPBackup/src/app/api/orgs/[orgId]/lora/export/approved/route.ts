// GET /api/orgs/[orgId]/lora/export/approved
//
// Admin-only download of the org's APPROVED responses as OpenAI-format
// JSONL training data. Same shape as the goldens route — see
// `./goldens/route.ts` for the design notes. AutoRFP does NOT train models.

import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { exportApprovedResponsesJsonl } from "@/lib/lora/export";
import { NotFoundError } from "@/lib/errors";

export const GET = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  const org = await prisma.organization.findUnique({
    where: { id: orgId },
    select: { slug: true },
  });
  if (!org) throw new NotFoundError("Organization not found");

  const result = await exportApprovedResponsesJsonl(orgId);
  const filename = `approved-${org.slug}-${todayISO()}.jsonl`;

  void audit({
    event: "LORA_DATASET_EXPORTED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "Response",
    metadata: {
      kind: "approved",
      exampleCount: result.exampleCount,
      filename,
      warning: result.warning,
    },
    ...auditContextFromRequest(req),
  });

  return new Response(result.jsonl, {
    status: 200,
    headers: {
      "Content-Type": "application/jsonl",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "X-Example-Count": String(result.exampleCount),
      ...(result.warning ? { "X-Export-Warning": result.warning } : {}),
    },
  });
});

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
