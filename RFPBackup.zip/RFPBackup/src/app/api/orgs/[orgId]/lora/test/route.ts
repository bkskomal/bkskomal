// POST /api/orgs/[orgId]/lora/test
//
// Admin-only one-shot test of the configured LoRA / fine-tune adapter.
// Sends the user-supplied question to the org's LLM client with the
// adapter URL as the `model` parameter, and returns the model's answer +
// latency. AutoRFP does NOT train models — this route just verifies that
// the configured adapter is reachable and answering.
//
// Returns:
//   { ok: true,  answer, model, ms }                    on success
//   { ok: false, error,  model, ms }  (HTTP 200)        on inference failure
//   400 when no adapter is configured.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { getAiClients } from "@/lib/ai/client";
import { resolveAdapter } from "@/lib/lora/resolver";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { ValidationError } from "@/lib/errors";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

const bodySchema = z.object({
  question: z.string().min(3).max(2000),
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  // Cheap rate-limit reuse — the adapter test goes through an external
  // provider just like the existing AI-config test, so share the budget.
  await rateLimit(RATE_LIMITS.providerTest, {
    userId: user.id,
    orgId,
    route: "lora/test",
  });

  const { question } = bodySchema.parse(await req.json());

  const adapter = await resolveAdapter(orgId);
  if (!adapter) {
    throw new ValidationError(
      "No adapter configured. Save an adapter URL first, then try again.",
    );
  }

  const { llm } = await getAiClients(orgId);
  const started = Date.now();
  let answer = "";
  let ok = false;
  let errorMessage: string | null = null;

  try {
    const resp = await llm.chat.completions.create({
      model: adapter.url,
      max_tokens: 256,
      temperature: 0,
      messages: [
        // Short, opinionated system prompt — matches what the export module
        // ships with each training example, so fine-tunes trained against
        // that prompt behave consistently here.
        {
          role: "system",
          content:
            "You are an expert proposal writer. Answer the RFP question directly, specifically, and with confidence.",
        },
        { role: "user", content: question },
      ],
    });
    answer = resp.choices[0]?.message?.content?.trim() ?? "";
    ok = answer.length > 0;
  } catch (e) {
    errorMessage = e instanceof Error ? e.message : String(e);
  }

  const ms = Date.now() - started;

  void audit({
    event: "LORA_ADAPTER_TESTED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: orgId,
    metadata: {
      model: adapter.url,
      ms,
      ok,
      error: errorMessage,
    },
    ...auditContextFromRequest(req),
  });

  if (!ok) {
    return Response.json(
      {
        ok: false,
        model: adapter.url,
        ms,
        error: errorMessage ?? "Adapter returned an empty response.",
      },
      { status: 200 }, // not a server error — the call itself succeeded
    );
  }

  return Response.json({
    ok: true,
    model: adapter.url,
    ms,
    answer,
  });
});
