import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// Mocks for auth + prisma + audit, matching the cache route's pattern.
const { authMock, prismaMock, auditMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  prismaMock: {
    membership: {
      findUnique: vi.fn(),
    },
    orgAiConfig: {
      findUnique: vi.fn(),
      upsert: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});

import { GET, PUT } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const session = { user: { id: USER_ID } };
const params = () => ({ params: Promise.resolve({ orgId: ORG_ID }) });

function buildPutRequest(body: unknown) {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/lora`, {
    method: "PUT",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

function buildGetRequest() {
  return new NextRequest(`http://x/api/orgs/${ORG_ID}/lora`, { method: "GET" });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "ADMIN",
  });
  prismaMock.orgAiConfig.findUnique.mockResolvedValue(null);
  prismaMock.orgAiConfig.upsert.mockResolvedValue({});
  auditMock.mockResolvedValue(undefined);
});

describe("GET /api/orgs/:orgId/lora", () => {
  it("returns current adapterUrl and adapterMeta", async () => {
    prismaMock.orgAiConfig.findUnique.mockResolvedValueOnce({
      loraAdapterUrl: "ft:gpt-4o-mini:acme::abc",
      loraAdapterMeta: { baseModel: "gpt-4o-mini", rank: 8 },
    });
    const res = await GET(buildGetRequest(), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.adapterUrl).toBe("ft:gpt-4o-mini:acme::abc");
    expect(body.adapterMeta).toEqual({ baseModel: "gpt-4o-mini", rank: 8 });
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await GET(buildGetRequest(), params());
    expect(res.status).toBe(403);
  });
});

describe("PUT /api/orgs/:orgId/lora", () => {
  it("persists adapterUrl + adapterMeta and audits LORA_ADAPTER_CONFIGURED", async () => {
    const res = await PUT(
      buildPutRequest({
        adapterUrl: "ft:gpt-4o-mini:acme::xyz",
        adapterMeta: { baseModel: "gpt-4o-mini", rank: 8, provider: "openai_ft" },
      }),
      params(),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.adapterUrl).toBe("ft:gpt-4o-mini:acme::xyz");

    expect(prismaMock.orgAiConfig.upsert).toHaveBeenCalledTimes(1);
    const upsertArg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    expect(upsertArg.where).toEqual({ organizationId: ORG_ID });
    expect(upsertArg.update.loraAdapterUrl).toBe("ft:gpt-4o-mini:acme::xyz");
    expect(upsertArg.update.loraAdapterMeta.baseModel).toBe("gpt-4o-mini");

    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    const payload = auditMock.mock.calls[0][0];
    expect(payload.event).toBe("LORA_ADAPTER_CONFIGURED");
    expect(payload.metadata.cleared).toBe(false);
    expect(payload.metadata.adapterUrl).toBe("ft:gpt-4o-mini:acme::xyz");
  });

  it("clears the adapter when adapterUrl is null", async () => {
    const res = await PUT(buildPutRequest({ adapterUrl: null }), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.adapterUrl).toBeNull();

    const upsertArg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    expect(upsertArg.update.loraAdapterUrl).toBeNull();
    // Meta is wiped alongside the URL — see route comment.
    expect(upsertArg.update.loraAdapterMeta).toBeNull();

    await new Promise((r) => setImmediate(r));
    const payload = auditMock.mock.calls[0][0];
    expect(payload.metadata.cleared).toBe(true);
  });

  it("clears the adapter when adapterUrl is an empty string", async () => {
    const res = await PUT(buildPutRequest({ adapterUrl: "" }), params());
    expect(res.status).toBe(200);
    const upsertArg = prismaMock.orgAiConfig.upsert.mock.calls[0][0];
    expect(upsertArg.update.loraAdapterUrl).toBeNull();
  });

  it("returns 403 for non-admin callers", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await PUT(
      buildPutRequest({ adapterUrl: "x", adapterMeta: { baseModel: "y" } }),
      params(),
    );
    expect(res.status).toBe(403);
    expect(prismaMock.orgAiConfig.upsert).not.toHaveBeenCalled();
    expect(auditMock).not.toHaveBeenCalled();
  });

  it("400s on a missing adapterUrl field (the field is required, not optional)", async () => {
    const res = await PUT(buildPutRequest({ adapterMeta: { baseModel: "x" } }), params());
    expect(res.status).toBe(400);
  });
});
