// LoRA / fine-tune adapter configuration (Tier C3).
//
// Admin-only GET + PUT. AutoRFP does NOT train models — these routes just
// persist the user-supplied adapter URL (or fine-tune model name) plus
// informational metadata describing how it was trained. The URL is treated
// as the model identifier at chat-completions time; AutoRFP never
// downloads, attaches, or inspects the adapter file.
//
// Setting `adapterUrl: null` (or empty string) clears the override and
// generations fall back to the org's standard model.

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { audit, auditContextFromRequest } from "@/lib/audit";
import type { Prisma } from "@prisma/client";

export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);

  const row = await prisma.orgAiConfig.findUnique({
    where: { organizationId: orgId },
    select: { loraAdapterUrl: true, loraAdapterMeta: true },
  });

  return Response.json({
    adapterUrl: row?.loraAdapterUrl ?? null,
    adapterMeta: (row?.loraAdapterMeta ?? null) as unknown,
  });
});

// Allowed providers — informational, mirrored from the AdapterProvider union
// in `lib/lora/resolver.ts`. We don't strictly need this on the server (the
// resolver tolerates unknowns), but rejecting bogus values at the edge gives
// users a clearer error than silently dropping them.
const providerEnum = z.enum([
  "openai_ft",
  "vllm",
  "openrouter",
  "ollama",
  "together",
  "other",
]);

const metaSchema = z
  .object({
    baseModel: z.string().min(1).max(200),
    rank: z.number().int().min(1).max(2048).optional(),
    trainedAt: z.string().min(1).max(64).optional(),
    trainSize: z.number().int().min(0).max(10_000_000).optional(),
    provider: providerEnum.optional(),
    notes: z.string().max(2000).optional(),
  })
  // Drop unknown keys silently — the meta is informational, and users may
  // want to attach future fields without us blocking the request.
  .strip();

const putSchema = z.object({
  // Null OR empty string both clear the adapter. We accept either for the
  // common case "user backspaced the input and hit save".
  adapterUrl: z.string().max(500).nullable(),
  adapterMeta: metaSchema.nullable().optional(),
});

export const PUT = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);
  const body = putSchema.parse(await req.json());

  const url = body.adapterUrl?.trim() ?? null;
  const cleared = !url;

  const data: Record<string, unknown> = {
    loraAdapterUrl: cleared ? null : url,
    // Clear the meta too when the URL is cleared so we don't leave stale
    // metadata pointing at a now-removed adapter. When the URL is set, an
    // explicit `null` in the body clears the meta; `undefined` leaves it
    // alone. We coerce undefined → existing-value via the `if` guard.
    ...(cleared
      ? { loraAdapterMeta: null as Prisma.InputJsonValue | null }
      : body.adapterMeta !== undefined
        ? { loraAdapterMeta: (body.adapterMeta ?? null) as Prisma.InputJsonValue | null }
        : {}),
  };

  await prisma.orgAiConfig.upsert({
    where: { organizationId: orgId },
    update: data,
    create: { organizationId: orgId, ...data },
  });

  void audit({
    event: "LORA_ADAPTER_CONFIGURED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "OrgAiConfig",
    targetId: orgId,
    metadata: {
      adapterUrl: cleared ? null : url,
      baseModel: body.adapterMeta?.baseModel ?? null,
      cleared,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({
    ok: true,
    adapterUrl: cleared ? null : url,
    adapterMeta: cleared ? null : (body.adapterMeta ?? null),
  });
});
