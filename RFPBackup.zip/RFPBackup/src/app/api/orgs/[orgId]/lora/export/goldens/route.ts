// GET /api/orgs/[orgId]/lora/export/goldens
//
// Admin-only download of the org's GoldenAnswer corpus as an OpenAI-format
// JSONL fine-tune file. AutoRFP does NOT train models — this is purely an
// export for the user to upload to OpenAI Fine-tuning, Together.ai,
// Hugging Face AutoTrain, or whichever external trainer they choose.
//
// Filename: `goldens-{orgSlug}-{ISODate}.jsonl`. Audited as
// `LORA_DATASET_EXPORTED` with metadata `{ kind: "goldens", exampleCount,
// filename }`. The body is the JSONL itself; the response carries
// `Content-Type: application/jsonl` so curl/wget save it correctly.

import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { exportGoldenAnswersJsonl } from "@/lib/lora/export";
import { NotFoundError } from "@/lib/errors";

export const GET = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId, Role.ADMIN);

  const org = await prisma.organization.findUnique({
    where: { id: orgId },
    select: { slug: true },
  });
  if (!org) throw new NotFoundError("Organization not found");

  const result = await exportGoldenAnswersJsonl(orgId);
  const filename = `goldens-${org.slug}-${todayISO()}.jsonl`;

  void audit({
    event: "LORA_DATASET_EXPORTED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "GoldenAnswer",
    metadata: {
      kind: "goldens",
      exampleCount: result.exampleCount,
      filename,
      warning: result.warning,
    },
    ...auditContextFromRequest(req),
  });

  // application/jsonl is the conventional MIME for newline-delimited JSON.
  // Some tools also accept application/x-ndjson; we pick jsonl because
  // OpenAI's fine-tune docs reference the .jsonl extension by name.
  return new Response(result.jsonl, {
    status: 200,
    headers: {
      "Content-Type": "application/jsonl",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "X-Example-Count": String(result.exampleCount),
      ...(result.warning ? { "X-Export-Warning": result.warning } : {}),
    },
  });
});

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}
