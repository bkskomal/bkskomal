// Admin-only viewer for the org audit log.
//
// Returns the last 100 entries for the given organization. For deeper paging
// callers pass `?cursor=<lastId>` and we return entries strictly older than
// that ID. Order is `createdAt desc`; cursor uses the row id (cuids are
// timestamp-prefixed so lexical ordering matches insertion order well enough
// for paging).

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { Role } from "@prisma/client";

const PAGE_SIZE = 100;

const querySchema = z.object({
  cursor: z.string().min(1).max(64).optional(),
});

export const GET = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  // Admin-only: the audit log can contain sensitive ip / actor metadata.
  await requireMembership(orgId, Role.ADMIN);

  const url = new URL(req.url);
  const { cursor } = querySchema.parse({
    cursor: url.searchParams.get("cursor") ?? undefined,
  });

  const entries = await prisma.auditLog.findMany({
    where: { organizationId: orgId },
    orderBy: { createdAt: "desc" },
    take: PAGE_SIZE + 1,
    ...(cursor ? { cursor: { id: cursor }, skip: 1 } : {}),
  });

  const hasMore = entries.length > PAGE_SIZE;
  const page = hasMore ? entries.slice(0, PAGE_SIZE) : entries;
  const nextCursor = hasMore ? page[page.length - 1].id : null;

  return Response.json({ entries: page, nextCursor });
});
