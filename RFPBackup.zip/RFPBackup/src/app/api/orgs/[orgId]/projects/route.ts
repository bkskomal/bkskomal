import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireMembership } from "@/lib/authz";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const projects = await prisma.project.findMany({
      where: { organizationId: orgId },
      include: {
        _count: { select: { rfps: true } },
        defaultIndex: { select: { id: true, name: true } },
      },
      orderBy: { updatedAt: "desc" },
    });
    return Response.json({ projects });
  } catch (e) {
    return jsonError(e);
  }
}

const createSchema = z.object({
  name: z.string().min(2).max(100),
  description: z.string().max(500).optional(),
  defaultIndexId: z.string().optional().nullable(),
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ orgId: string }> }) {
  try {
    const { orgId } = await params;
    await requireMembership(orgId);
    const body = createSchema.parse(await req.json());

    let defaultIndexId = body.defaultIndexId ?? null;
    if (!defaultIndexId) {
      const indexes = await prisma.knowledgeIndex.findMany({
        where: { organizationId: orgId },
        select: { id: true },
        take: 2,
      });
      if (indexes.length === 1) defaultIndexId = indexes[0].id;
    }

    const project = await prisma.project.create({
      data: { ...body, defaultIndexId, organizationId: orgId },
    });
    return Response.json({ project }, { status: 201 });
  } catch (e) {
    return jsonError(e);
  }
}
