import { z } from "zod";
import { PipelineStepKind, PipelineStepMode, Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { DEFAULT_PIPELINE, STEP_CATALOG } from "@/lib/pipeline/catalog";

const stepSchema = z.object({
  kind: z.nativeEnum(PipelineStepKind),
  label: z.string().min(1).max(120),
  description: z.string().max(500).optional(),
  mode: z.nativeEnum(PipelineStepMode),
  config: z.record(z.string(), z.unknown()).optional(),
});

const createSchema = z.object({
  name: z.string().min(2).max(100),
  description: z.string().max(500).optional(),
  steps: z.array(stepSchema).min(1).max(40),
  isDefault: z.boolean().optional(),
});

export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId);
  const templates = await prisma.pipelineTemplate.findMany({
    where: { organizationId: orgId },
    orderBy: [{ isDefault: "desc" }, { updatedAt: "desc" }],
    include: { _count: { select: { runs: true, defaultForProjects: true } } },
  });
  return Response.json({
    templates,
    catalog: STEP_CATALOG,
    fallback: DEFAULT_PIPELINE,
  });
});

export const POST = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId, Role.ADMIN);
  const body = createSchema.parse(await req.json());
  validateSteps(body.steps);

  const tpl = await prisma.$transaction(async (tx) => {
    if (body.isDefault) {
      await tx.pipelineTemplate.updateMany({
        where: { organizationId: orgId, isDefault: true },
        data: { isDefault: false },
      });
    }
    return tx.pipelineTemplate.create({
      data: {
        organizationId: orgId,
        name: body.name,
        description: body.description,
        steps: body.steps as never,
        isDefault: body.isDefault ?? false,
      },
    });
  });

  return Response.json({ template: tpl }, { status: 201 });
});

function validateSteps(steps: z.infer<typeof stepSchema>[]) {
  for (const s of steps) {
    const meta = STEP_CATALOG[s.kind];
    if (!meta.allowedModes.includes(s.mode)) {
      throw new Error(`Step "${s.kind}" doesn't allow mode "${s.mode}"`);
    }
  }
}
