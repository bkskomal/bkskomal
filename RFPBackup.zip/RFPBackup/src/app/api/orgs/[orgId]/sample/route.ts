import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { loadSampleRfp } from "@/lib/sample-data";

export const POST = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  const { user } = await requireMembership(orgId);
  const result = await loadSampleRfp({ organizationId: orgId, userId: user.id });
  return Response.json(result, { status: 201 });
});
