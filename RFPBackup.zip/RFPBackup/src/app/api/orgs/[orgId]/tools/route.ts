import { z } from "zod";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireMembership } from "@/lib/authz";
import { toolRegistry } from "@/lib/ai/tools/registry";
import "@/lib/ai/tools/builtin";

/**
 * Returns every registered tool + whether it's enabled for this org.
 * Tools without a ToolConfig row are enabled by default.
 */
export const GET = withApiHandler<{ orgId: string }>(async (_req, { params }) => {
  const { orgId } = await params;
  await requireMembership(orgId);
  const configs = await prisma.toolConfig.findMany({
    where: { organizationId: orgId },
    select: { name: true, enabled: true },
  });
  const overrides = new Map(configs.map((c) => [c.name, c.enabled]));
  const tools = toolRegistry.list().map((t) => ({
    name: t.name,
    description: t.description,
    enabled: overrides.get(t.name) !== false,
    hasOverride: overrides.has(t.name),
  }));
  return Response.json({ tools });
});

const putSchema = z.object({
  changes: z.array(
    z.object({
      name: z.string(),
      enabled: z.boolean(),
    }),
  ),
});

export const PUT = withApiHandler<{ orgId: string }>(async (req, { params }) => {
  const { orgId } = await params;
  // Tool config changes are admin-only: they affect what the AI can do.
  await requireMembership(orgId, Role.ADMIN);
  const { changes } = putSchema.parse(await req.json());

  // Reject names we don't actually have registered — prevents stale rows.
  const registered = new Set(toolRegistry.list().map((t) => t.name));
  const valid = changes.filter((c) => registered.has(c.name));

  await Promise.all(
    valid.map((c) =>
      prisma.toolConfig.upsert({
        where: { organizationId_name: { organizationId: orgId, name: c.name } },
        update: { enabled: c.enabled },
        create: { organizationId: orgId, name: c.name, enabled: c.enabled },
      }),
    ),
  );

  return Response.json({ updated: valid.length });
});
