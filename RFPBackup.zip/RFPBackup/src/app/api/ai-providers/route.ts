import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { PROVIDERS } from "@/lib/ai/providers";

export const GET = withApiHandler(async () => {
  await requireUser();
  return Response.json({ providers: Object.values(PROVIDERS) });
});
