import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

const { authMock, prismaMock, sessionMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  prismaMock: {
    response: { findUnique: vi.fn() },
    membership: { findUnique: vi.fn() },
  },
  sessionMock: {
    acquireEditLock: vi.fn(),
    getEditState: vi.fn(),
    releaseEditLock: vi.fn(),
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/response-edit/session", () => sessionMock);

// Import after the mocks bind.
import { GET, POST, DELETE } from "./route";

const USER_ID = "user-a";
const ORG_ID = "org-1";
const RESPONSE_ID = "resp-1";
const session = { user: { id: USER_ID } };

function buildRequest(method: "GET" | "POST" | "DELETE") {
  return new NextRequest(
    `http://x/api/responses/${RESPONSE_ID}/edit-session`,
    { method },
  );
}
const params = () => ({ params: Promise.resolve({ responseId: RESPONSE_ID }) });

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.response.findUnique.mockResolvedValue({
    id: RESPONSE_ID,
    question: { rfp: { project: { organizationId: ORG_ID } } },
  });
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
});

describe("GET /api/responses/:id/edit-session", () => {
  it("returns the edit state shape", async () => {
    sessionMock.getEditState.mockResolvedValueOnce({
      editorId: USER_ID,
      editor: { id: USER_ID, name: "Alice", email: "a@x" },
      lastHeartbeat: new Date("2026-05-14T11:59:00Z"),
      version: 4,
      draftContent: "wip",
      draftUpdatedAt: new Date("2026-05-14T11:59:00Z"),
      isStale: false,
    });

    const res = await GET(buildRequest("GET"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({
      editorId: USER_ID,
      version: 4,
      draftContent: "wip",
      isStale: false,
    });
    expect(body.editor).toMatchObject({ name: "Alice" });
    expect(typeof body.lastHeartbeat).toBe("string");
  });

  it("returns 403 when caller is not a member of the response's org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await GET(buildRequest("GET"), params());
    expect(res.status).toBe(403);
  });

  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await GET(buildRequest("GET"), params());
    expect(res.status).toBe(401);
  });
});

describe("POST /api/responses/:id/edit-session (acquire)", () => {
  it("returns 200 with the session payload on a successful acquire", async () => {
    sessionMock.acquireEditLock.mockResolvedValueOnce({
      ok: true,
      session: {
        editorId: USER_ID,
        version: 0,
        draftContent: null,
        draftUpdatedAt: null,
      },
    });
    const res = await POST(buildRequest("POST"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.session.editorId).toBe(USER_ID);
    expect(sessionMock.acquireEditLock).toHaveBeenCalledWith({
      responseId: RESPONSE_ID,
      userId: USER_ID,
    });
  });

  it("returns 409 with lockedBy info when another user holds the lock", async () => {
    sessionMock.acquireEditLock.mockResolvedValueOnce({
      ok: false,
      reason: "locked_by_other",
      lockedBy: { id: "other", name: "Bob", email: "b@x" },
      lastHeartbeat: new Date("2026-05-14T11:59:30Z"),
    });
    const res = await POST(buildRequest("POST"), params());
    expect(res.status).toBe(409);
    const body = await res.json();
    expect(body.ok).toBe(false);
    expect(body.reason).toBe("locked_by_other");
    expect(body.lockedBy.name).toBe("Bob");
  });
});

describe("DELETE /api/responses/:id/edit-session (release)", () => {
  it("calls releaseEditLock and returns ok", async () => {
    sessionMock.releaseEditLock.mockResolvedValueOnce(undefined);
    const res = await DELETE(buildRequest("DELETE"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(sessionMock.releaseEditLock).toHaveBeenCalledWith({
      responseId: RESPONSE_ID,
      userId: USER_ID,
    });
  });

  it("returns 403 when caller is not a member", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await DELETE(buildRequest("DELETE"), params());
    expect(res.status).toBe(403);
    expect(sessionMock.releaseEditLock).not.toHaveBeenCalled();
  });
});
