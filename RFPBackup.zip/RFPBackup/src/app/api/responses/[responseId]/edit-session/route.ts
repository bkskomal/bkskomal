// Response edit-session lifecycle endpoint.
//
//   GET    — anyone with response-read access can see who's editing.
//   POST   — write-access caller takes the soft lock.
//   DELETE — write-access caller releases their lock (no-op if not holder).
//
// See lib/response-edit/session.ts for the lock semantics. The single most
// important thing to remember reading this file: this is NOT a CRDT. The
// lock is advisory (TTL=60s) and content writes are last-writer-wins on a
// version check. Two clients can never reach the draft endpoint at the
// same time because of the lock, but a stale tab whose lock expired can
// still try and will get back `lock_lost`.

import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { prisma } from "@/lib/prisma";
import {
  acquireEditLock,
  getEditState,
  releaseEditLock,
} from "@/lib/response-edit/session";

/**
 * Verify the caller is a member of the response's owning org. Returns the
 * caller and the responseId for convenience. We don't differentiate between
 * "read" and "write" access here — there's no read-only role in the
 * Membership model; if you're in the org you can both view and edit.
 */
async function resolveAccess(responseId: string) {
  const user = await requireUser();
  const resp = await prisma.response.findUnique({
    where: { id: responseId },
    select: { id: true, question: { select: { rfp: { select: { project: { select: { organizationId: true } } } } } } },
  });
  if (!resp) throw new NotFoundError("Response not found");
  const orgId = resp.question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw new ForbiddenError("Not a member of this organization");
  return { user, orgId };
}

export const GET = withApiHandler<{ responseId: string }>(async (_req, { params }) => {
  const { responseId } = await params;
  await resolveAccess(responseId);
  const state = await getEditState(responseId);
  return Response.json({
    editorId: state.editorId,
    editor: state.editor,
    lastHeartbeat: state.lastHeartbeat ? state.lastHeartbeat.toISOString() : null,
    version: state.version,
    draftContent: state.draftContent,
    draftUpdatedAt: state.draftUpdatedAt ? state.draftUpdatedAt.toISOString() : null,
    isStale: state.isStale,
  });
});

export const POST = withApiHandler<{ responseId: string }>(async (_req, { params }) => {
  const { responseId } = await params;
  const { user } = await resolveAccess(responseId);
  const result = await acquireEditLock({ responseId, userId: user.id });
  if (!result.ok) {
    // 409 maps the "someone else owns it" case to a recognisable HTTP code
    // without burning a 403 (which would imply a permissions problem). The
    // client distinguishes via the `reason` field in the body.
    return Response.json(
      {
        ok: false,
        reason: result.reason,
        lockedBy: result.lockedBy,
        lastHeartbeat: result.lastHeartbeat.toISOString(),
      },
      { status: 409 },
    );
  }
  return Response.json({
    ok: true,
    session: {
      editorId: result.session.editorId,
      version: result.session.version,
      draftContent: result.session.draftContent,
      draftUpdatedAt: result.session.draftUpdatedAt
        ? result.session.draftUpdatedAt.toISOString()
        : null,
    },
  });
});

export const DELETE = withApiHandler<{ responseId: string }>(async (_req, { params }) => {
  const { responseId } = await params;
  const { user } = await resolveAccess(responseId);
  await releaseEditLock({ responseId, userId: user.id });
  return Response.json({ ok: true });
});
