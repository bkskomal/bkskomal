// Debounced draft autosave endpoint.
//
// Client calls PUT here every AUTOSAVE_DEBOUNCE_MS (~5s) of content
// changes. Body: `{ content, expectedVersion }`. The expectedVersion is
// the version the client saw on its last acquire/commit — if it doesn't
// match the server's, someone else formally committed in between and we
// refuse the save rather than silently overwrite their work.
//
// Returns 409 on version_conflict OR lock_lost. The client distinguishes
// via the `reason` field in the body.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { prisma } from "@/lib/prisma";
import { saveDraft } from "@/lib/response-edit/session";

const putSchema = z.object({
  // Cap at 1 MB of text — well above any realistic Response.content size
  // (in practice these are paragraphs, not books). Rejects accidental
  // PDF uploads or runaway client bugs before they hit the DB.
  content: z.string().max(1_000_000),
  expectedVersion: z.number().int().min(0),
});

async function resolveAccess(responseId: string) {
  const user = await requireUser();
  const resp = await prisma.response.findUnique({
    where: { id: responseId },
    select: {
      id: true,
      question: { select: { rfp: { select: { project: { select: { organizationId: true } } } } } },
    },
  });
  if (!resp) throw new NotFoundError("Response not found");
  const orgId = resp.question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw new ForbiddenError("Not a member of this organization");
  return { user };
}

export const PUT = withApiHandler<{ responseId: string }>(async (req, { params }) => {
  const { responseId } = await params;
  const { user } = await resolveAccess(responseId);
  const body = putSchema.parse(await req.json());
  const result = await saveDraft({
    responseId,
    userId: user.id,
    content: body.content,
    expectedVersion: body.expectedVersion,
  });
  if (!result.ok) {
    return Response.json(
      {
        ok: false,
        reason: result.reason,
        serverVersion: result.serverVersion,
      },
      { status: 409 },
    );
  }
  return Response.json({ ok: true, version: result.version });
});
