// Heartbeat endpoint — refreshes the caller's edit-lock liveness.
//
// The client polls this every ~20s (well under HEARTBEAT_TTL_MS=60s) while
// the user has the editor open. A 200 means "you still own the lock; here
// is when it would expire if you stopped polling now". A 409 means someone
// else took over (or the lock expired) — the client should drop into
// read-only mode and offer the user a "re-acquire" affordance.

import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { prisma } from "@/lib/prisma";
import { heartbeat } from "@/lib/response-edit/session";

async function resolveAccess(responseId: string) {
  const user = await requireUser();
  const resp = await prisma.response.findUnique({
    where: { id: responseId },
    select: {
      id: true,
      question: { select: { rfp: { select: { project: { select: { organizationId: true } } } } } },
    },
  });
  if (!resp) throw new NotFoundError("Response not found");
  const orgId = resp.question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw new ForbiddenError("Not a member of this organization");
  return { user };
}

export const POST = withApiHandler<{ responseId: string }>(async (_req, { params }) => {
  const { responseId } = await params;
  const { user } = await resolveAccess(responseId);
  const result = await heartbeat({ responseId, userId: user.id });
  if (!result.ok) {
    return Response.json(
      { ok: false, reason: result.reason },
      { status: 409 },
    );
  }
  return Response.json({ ok: true, expiresAt: result.expiresAt.toISOString() });
});
