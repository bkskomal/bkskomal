import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// Hoisted mocks for prisma + auth + the grounding library. The route reaches
// out to all three; we mock them so the test doesn't need a live DB or LLM.

const { authMock, prismaMock, scoreGroundingMock, auditMock } = vi.hoisted(() => {
  return {
    authMock: vi.fn(),
    auditMock: vi.fn().mockResolvedValue(undefined),
    scoreGroundingMock: vi.fn(),
    prismaMock: {
      response: {
        findUnique: vi.fn(),
        update: vi.fn(),
      },
      membership: {
        findUnique: vi.fn(),
      },
    },
  };
});

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/ai/grounding", () => ({
  scoreGrounding: (...args: unknown[]) => scoreGroundingMock(...args),
}));

vi.mock("@/lib/audit", () => ({
  audit: (...args: unknown[]) => auditMock(...args),
  auditContextFromRequest: () => ({}),
}));

import { GET, POST } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const RESPONSE_ID = "resp-1";

const session = { user: { id: USER_ID } };

function buildResponseFixture(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RESPONSE_ID,
    content: "We use AES-256 at rest. [Source 1]",
    needsReview: false,
    groundingScore: 0.85,
    groundingNotes: [{ claim: "AES-256 at rest.", support: "supported" }],
    groundingAt: new Date("2026-05-01T12:00:00Z"),
    sources: [
      { id: "src-1", excerpt: "Encryption uses AES-256-GCM.", fileName: "sec.md", page: null },
    ],
    question: {
      rfp: {
        project: { organizationId: ORG_ID },
      },
    },
    ...overrides,
  };
}

const params = () => ({ params: Promise.resolve({ responseId: RESPONSE_ID }) });

function buildRequest(method: "GET" | "POST" = "POST") {
  return new NextRequest(`http://x/api/responses/${RESPONSE_ID}/grounding`, { method });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.response.findUnique.mockResolvedValue(buildResponseFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  prismaMock.response.update.mockImplementation(async (args: { data: Record<string, unknown> }) => ({
    ...buildResponseFixture(),
    ...args.data,
    groundingAt: args.data.groundingAt ?? new Date(),
  }));
  scoreGroundingMock.mockResolvedValue({
    score: 0.4,
    claims: [
      { claim: "Made-up claim.", support: "unsupported", note: "no source" },
      { claim: "Real claim.", support: "supported", sourceIds: ["src-1"] },
    ],
    judgeModel: "test-judge",
    ms: 42,
  });
});

describe("GET /api/responses/:id/grounding", () => {
  it("returns the persisted grounding payload", async () => {
    const res = await GET(buildRequest("GET"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({
      groundingScore: 0.85,
      groundingNotes: expect.any(Array),
    });
    expect(body.groundingAt).toBe("2026-05-01T12:00:00.000Z");
  });

  it("returns 404 for an unknown response id", async () => {
    prismaMock.response.findUnique.mockResolvedValueOnce(null);
    const res = await GET(buildRequest("GET"), params());
    expect(res.status).toBe(404);
  });

  it("returns 403 for non-members", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await GET(buildRequest("GET"), params());
    expect(res.status).toBe(403);
  });
});

describe("POST /api/responses/:id/grounding", () => {
  it("re-scores, persists, audits, and returns the new payload", async () => {
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200);
    const body = await res.json();

    // Score from the mocked judge propagated through.
    expect(body.groundingScore).toBe(0.4);
    expect(body.judgeModel).toBe("test-judge");

    // Persisted via prisma.response.update with the new fields.
    expect(prismaMock.response.update).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: RESPONSE_ID },
        data: expect.objectContaining({
          groundingScore: 0.4,
          // 0.4 < 0.6 threshold → needsReview should flip to true.
          needsReview: true,
        }),
      }),
    );

    // Audit row written with the right event.
    expect(auditMock).toHaveBeenCalledWith(
      expect.objectContaining({
        event: "RESPONSE_REGROUNDED",
        actorId: USER_ID,
        organizationId: ORG_ID,
        targetType: "Response",
        targetId: RESPONSE_ID,
      }),
    );

    // The judge was invoked against the response's current content + sources.
    expect(scoreGroundingMock).toHaveBeenCalledWith(
      expect.objectContaining({
        content: "We use AES-256 at rest. [Source 1]",
        organizationId: ORG_ID,
        sources: expect.arrayContaining([expect.objectContaining({ id: "src-1" })]),
      }),
    );
  });

  it("returns 403 for non-members and skips the judge", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(403);
    expect(scoreGroundingMock).not.toHaveBeenCalled();
    expect(auditMock).not.toHaveBeenCalled();
  });

  it("returns 404 for an unknown response id", async () => {
    prismaMock.response.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(404);
    expect(scoreGroundingMock).not.toHaveBeenCalled();
  });

  it("preserves an existing needsReview=true flag even when grounding is high", async () => {
    prismaMock.response.findUnique.mockResolvedValueOnce(buildResponseFixture({ needsReview: true }));
    scoreGroundingMock.mockResolvedValueOnce({
      score: 0.95,
      claims: [{ claim: "Solid.", support: "supported" }],
      judgeModel: "test-judge",
      ms: 10,
    });
    await POST(buildRequest(), params());
    expect(prismaMock.response.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ needsReview: true }),
      }),
    );
  });
});
