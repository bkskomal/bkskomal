// On-demand grounding endpoint.
//
// Two operations on the same response:
//   - GET  → return the persisted grounding payload (score / claims / when)
//   - POST → re-run the LLM-judge pass against the current `content` and the
//            already-attached sources, persist the new result, audit-log it.
//
// We always run grounding against the response.content as it currently
// exists, NOT the original generation output. That makes this endpoint useful
// after a human edit — they save the answer, click "Re-score", and the badge
// updates against what they actually wrote.
//
// Auth: requires write access (Membership row) on the owning org. API key
// scope check is intentionally NOT applied here — this is a session-only
// endpoint reached from the UI; the existing `/responses/:id` PATCH uses the
// same model.

import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { jsonError, requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { scoreGrounding } from "@/lib/ai/grounding";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { GROUNDING_REVIEW_THRESHOLD } from "@/lib/ai/generate";
import { log } from "@/lib/logger";

/**
 * Resolve the response and confirm the caller has access. Returns both the
 * caller and the response (with its sources joined) so handlers don't need to
 * re-query.
 *
 * Throws NotFoundError / ForbiddenError so `jsonError` (which understands
 * AppError) returns the right status code; bare `new Error` would otherwise
 * fall through to the generic 500 path.
 */
async function resolveAccess(responseId: string) {
  const user = await requireUser();
  const resp = await prisma.response.findUnique({
    where: { id: responseId },
    include: {
      sources: true,
      question: { include: { rfp: { include: { project: true } } } },
    },
  });
  if (!resp) throw new NotFoundError("Response not found");
  const orgId = resp.question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw new ForbiddenError("Not a member of this organization");
  return { user, resp, orgId };
}

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ responseId: string }> },
) {
  try {
    const { responseId } = await params;
    const { resp } = await resolveAccess(responseId);
    return Response.json({
      groundingScore: resp.groundingScore,
      groundingNotes: resp.groundingNotes,
      groundingAt: resp.groundingAt ? resp.groundingAt.toISOString() : null,
    });
  } catch (e) {
    return jsonError(e);
  }
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ responseId: string }> },
) {
  try {
    const { responseId } = await params;
    const { user, resp, orgId } = await resolveAccess(responseId);

    // Run the judge against the CURRENT content (post-edit if applicable) and
    // the persisted sources. We never touch the source list here — re-grading
    // uses whatever evidence the original generation pulled.
    const grounding = await scoreGrounding({
      content: resp.content,
      sources: resp.sources.map((s) => ({
        id: s.id,
        content: s.excerpt,
        fileName: s.fileName ?? undefined,
        page: s.page ?? null,
      })),
      organizationId: orgId,
    });

    // Recompute needsReview using the same threshold as generate.ts. We
    // intentionally only DOWNGRADE — i.e. raise a flag when grounding is
    // weak — rather than clearing a previously-set review flag, since other
    // signals (negative feedback, etc.) may also have raised it.
    const needsReview = resp.needsReview || grounding.score < GROUNDING_REVIEW_THRESHOLD;

    const updated = await prisma.response.update({
      where: { id: responseId },
      data: {
        groundingScore: grounding.score,
        groundingNotes: grounding.claims as never,
        groundingAt: new Date(),
        needsReview,
      },
    });

    void audit({
      event: "RESPONSE_REGROUNDED",
      actorId: user.id,
      organizationId: orgId,
      targetType: "Response",
      targetId: responseId,
      metadata: {
        score: grounding.score,
        claimCount: grounding.claims.length,
        judgeModel: grounding.judgeModel,
        ms: grounding.ms,
      },
      ...auditContextFromRequest(req),
    });

    log().info(
      {
        responseId,
        score: grounding.score,
        claimCount: grounding.claims.length,
        ms: grounding.ms,
      },
      "response regrounded",
    );

    return Response.json({
      groundingScore: updated.groundingScore,
      groundingNotes: updated.groundingNotes,
      groundingAt: updated.groundingAt ? updated.groundingAt.toISOString() : null,
      needsReview: updated.needsReview,
      judgeModel: grounding.judgeModel,
      ms: grounding.ms,
    });
  } catch (e) {
    return jsonError(e);
  }
}
