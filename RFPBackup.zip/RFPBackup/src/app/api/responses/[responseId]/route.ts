import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireUser } from "@/lib/authz";

const patchSchema = z.object({ content: z.string() });

async function ensureAccess(responseId: string) {
  const user = await requireUser();
  const resp = await prisma.response.findUnique({
    where: { id: responseId },
    include: { question: { include: { rfp: { include: { project: true } } } } },
  });
  if (!resp) throw Object.assign(new Error("Not found"), { status: 404 });
  const orgId = resp.question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw Object.assign(new Error("Forbidden"), { status: 403 });
  return { user, resp };
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ responseId: string }> }) {
  try {
    const { responseId } = await params;
    await ensureAccess(responseId);
    const body = patchSchema.parse(await req.json());
    const updated = await prisma.response.update({
      where: { id: responseId },
      data: { content: body.content },
    });
    return Response.json({ response: updated });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ responseId: string }> }) {
  try {
    const { responseId } = await params;
    await ensureAccess(responseId);
    await prisma.response.delete({ where: { id: responseId } });
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
