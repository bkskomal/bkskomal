import { NextRequest } from "next/server";
import { z } from "zod";
import { FeedbackKind } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { jsonError, requireUser } from "@/lib/authz";

const bodySchema = z.object({
  kind: z.nativeEnum(FeedbackKind),
  comment: z.string().max(500).optional(),
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ responseId: string }> }) {
  try {
    const { responseId } = await params;
    const user = await requireUser();
    const body = bodySchema.parse(await req.json());

    const resp = await prisma.response.findUnique({
      where: { id: responseId },
      include: { question: { include: { rfp: { include: { project: true } } } } },
    });
    if (!resp) return Response.json({ error: "Not found" }, { status: 404 });
    const orgId = resp.question.rfp.project.organizationId;
    const member = await prisma.membership.findUnique({
      where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
    });
    if (!member) return Response.json({ error: "Forbidden" }, { status: 403 });

    const feedback = await prisma.feedback.upsert({
      where: { responseId_userId: { responseId, userId: user.id } },
      update: { kind: body.kind, comment: body.comment },
      create: { responseId, userId: user.id, kind: body.kind, comment: body.comment },
    });

    return Response.json({ feedback });
  } catch (e) {
    return jsonError(e);
  }
}
