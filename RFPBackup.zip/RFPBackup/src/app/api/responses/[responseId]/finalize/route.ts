// Commit (finalize) endpoint.
//
// Promotes the in-flight draft to Response.content, releases the soft lock,
// and bumps the version. After this call there is no draftContent and no
// active editor on the row — the response is "published".
//
// Body: { content?, expectedVersion }
//   - `content` is optional override. If omitted, the persisted draft is
//     used. This gives the UI flexibility: typical Publish flow doesn't
//     send the body at all (server already has the latest draft from the
//     last debounced save), but a UI that wants to commit a different
//     value (e.g. the user pasted a clean version into the Publish modal)
//     can override.
//   - `expectedVersion` matches the version the client saw on acquire.
//     Mismatch ⇒ 409 (someone else committed first). The UI prompts the
//     user to reload.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { prisma } from "@/lib/prisma";
import { commitDraft } from "@/lib/response-edit/session";
import { audit, auditContextFromRequest } from "@/lib/audit";

const postSchema = z.object({
  // Same cap as the draft endpoint — see note there.
  content: z.string().max(1_000_000).optional(),
  expectedVersion: z.number().int().min(0),
});

async function resolveAccess(responseId: string) {
  const user = await requireUser();
  const resp = await prisma.response.findUnique({
    where: { id: responseId },
    select: {
      id: true,
      question: { select: { rfp: { select: { project: { select: { organizationId: true } } } } } },
    },
  });
  if (!resp) throw new NotFoundError("Response not found");
  const orgId = resp.question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: orgId } },
  });
  if (!membership) throw new ForbiddenError("Not a member of this organization");
  return { user, orgId };
}

export const POST = withApiHandler<{ responseId: string }>(async (req, { params }) => {
  const { responseId } = await params;
  const { user, orgId } = await resolveAccess(responseId);
  const body = postSchema.parse(await req.json());

  const result = await commitDraft({
    responseId,
    userId: user.id,
    expectedVersion: body.expectedVersion,
    contentOverride: body.content,
  });

  if (!result.ok) {
    return Response.json(
      {
        ok: false,
        reason: result.reason,
        serverVersion: result.serverVersion,
      },
      { status: 409 },
    );
  }

  // Audit fire-and-forget. Captures the version bump + content length so a
  // future support investigation can answer "who clobbered my draft" without
  // diffing the full content blob into the audit row.
  void audit({
    event: "RESPONSE_COMMITTED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "Response",
    targetId: responseId,
    metadata: {
      previousVersion: body.expectedVersion,
      newVersion: result.version,
      contentLength: result.content.length,
      usedOverride: typeof body.content === "string",
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({
    ok: true,
    version: result.version,
    content: result.content,
  });
});
