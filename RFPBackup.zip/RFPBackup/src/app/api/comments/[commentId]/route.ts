import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";

export const DELETE = withApiHandler<{ commentId: string }>(async (_req, { params }) => {
  const { commentId } = await params;
  const user = await requireUser();
  const comment = await prisma.comment.findUnique({
    where: { id: commentId },
    include: { question: { include: { rfp: { include: { project: true } } } } },
  });
  if (!comment) throw new NotFoundError("Comment not found");
  // Only the author or an org admin/owner can delete.
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId: user.id,
        organizationId: comment.question.rfp.project.organizationId,
      },
    },
  });
  if (!member) throw new ForbiddenError("Not a member");
  if (comment.authorId !== user.id && member.role === "MEMBER") {
    throw new ForbiddenError("Only the author or an admin can delete this comment");
  }
  await prisma.comment.delete({ where: { id: commentId } });
  return Response.json({ ok: true });
});
