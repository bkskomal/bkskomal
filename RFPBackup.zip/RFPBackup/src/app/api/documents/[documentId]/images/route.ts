// List ImageEmbedding rows for a single Document — backs the "Images" tab
// in the KB document viewer. Org membership is required (org-scoped read).
//
// We deliberately omit the `vector` column from the projection — those are
// 512-d float arrays and only useful server-side. The UI just needs paths,
// captions, OCR snippets, and page numbers.

import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { prisma } from "@/lib/prisma";
import { ForbiddenError, NotFoundError } from "@/lib/errors";

export const GET = withApiHandler<{ documentId: string }>(async (_req, { params }) => {
  const { documentId } = await params;
  const user = await requireUser();

  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    select: { id: true, index: { select: { organizationId: true } } },
  });
  if (!doc) throw new NotFoundError("Document not found");

  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: { userId: user.id, organizationId: doc.index.organizationId },
    },
  });
  if (!member) throw new ForbiddenError("Not a member of this organization");

  const images = await prisma.imageEmbedding.findMany({
    where: { documentId },
    orderBy: [{ page: "asc" }, { createdAt: "asc" }],
    select: {
      id: true,
      imagePath: true,
      mimeType: true,
      caption: true,
      ocrText: true,
      page: true,
      width: true,
      height: true,
      chunkId: true,
      createdAt: true,
    },
  });

  return Response.json({
    documentId,
    count: images.length,
    images: images.map((i) => ({
      ...i,
      createdAt: i.createdAt.toISOString(),
    })),
  });
});
