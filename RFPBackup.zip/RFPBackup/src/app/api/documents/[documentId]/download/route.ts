// Stream the original uploaded file for download. Refuses synthetic / sample
// documents (no source file on disk) — those are viewable via the chunks API
// instead.

import { readFile, stat } from "node:fs/promises";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError, ValidationError } from "@/lib/errors";

export const GET = withApiHandler<{ documentId: string }>(async (_req, { params }) => {
  const { documentId } = await params;
  const user = await requireUser();
  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    include: { index: { select: { organizationId: true } } },
  });
  if (!doc) throw new NotFoundError("Document not found");
  const member = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId: user.id, organizationId: doc.index.organizationId } },
  });
  if (!member) throw new ForbiddenError("Not a member of this organization");

  if (doc.storagePath.startsWith("(synthetic)")) {
    throw new ValidationError("This document was seeded by the platform and has no original file. Open the viewer to read the content.");
  }

  try {
    await stat(doc.storagePath);
  } catch {
    throw new NotFoundError("Original file is missing on disk");
  }

  const buf = await readFile(doc.storagePath);
  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": doc.mimeType || "application/octet-stream",
      "Content-Disposition": `attachment; filename="${doc.fileName.replace(/"/g, "")}"`,
      "Content-Length": String(buf.length),
    },
  });
});
