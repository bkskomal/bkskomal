import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { deleteUpload } from "@/lib/storage";

async function loadAndAuthorize(documentId: string, userId: string) {
  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    include: { index: { select: { id: true, name: true, organizationId: true } } },
  });
  if (!doc) throw new NotFoundError("Document not found");
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: { userId, organizationId: doc.index.organizationId },
    },
  });
  if (!member) throw new ForbiddenError("Not a member of this organization");
  return doc;
}

export const GET = withApiHandler<{ documentId: string }>(async (_req, { params }) => {
  const { documentId } = await params;
  const user = await requireUser();
  const doc = await loadAndAuthorize(documentId, user.id);

  // Pull chunks (without embeddings — they're large and not useful to the UI).
  const chunks = await prisma.documentChunk.findMany({
    where: { documentId },
    orderBy: { ordinal: "asc" },
    select: { id: true, ordinal: true, content: true, page: true },
  });

  return Response.json({
    document: {
      id: doc.id,
      name: doc.name,
      fileName: doc.fileName,
      fileSize: doc.fileSize,
      mimeType: doc.mimeType,
      status: doc.status,
      errorMessage: doc.errorMessage,
      createdAt: doc.createdAt,
      updatedAt: doc.updatedAt,
      index: doc.index,
      isSynthetic: doc.storagePath.startsWith("(synthetic)"),
      chunkCount: chunks.length,
      totalChars: chunks.reduce((n, c) => n + c.content.length, 0),
      sourceUrl: doc.sourceUrl ?? null,
      sourceDate: doc.sourceDate ?? null,
      staleReason: doc.staleReason ?? null,
    },
    chunks,
  });
});

export const DELETE = withApiHandler<{ documentId: string }>(async (_req, { params }) => {
  const { documentId } = await params;
  const user = await requireUser();
  const doc = await loadAndAuthorize(documentId, user.id);
  await prisma.document.delete({ where: { id: documentId } });
  await deleteUpload(doc.storagePath);
  return Response.json({ ok: true });
});
