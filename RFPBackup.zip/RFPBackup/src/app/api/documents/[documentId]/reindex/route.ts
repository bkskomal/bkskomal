import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { jsonError, requireUser } from "@/lib/authz";
import { ingestDocument } from "@/lib/indexing";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ documentId: string }> },
) {
  try {
    const { documentId } = await params;
    const user = await requireUser();
    const doc = await prisma.document.findUnique({
      where: { id: documentId },
      include: { index: true },
    });
    if (!doc) return Response.json({ error: "Not found" }, { status: 404 });
    const member = await prisma.membership.findUnique({
      where: { userId_organizationId: { userId: user.id, organizationId: doc.index.organizationId } },
    });
    if (!member) return Response.json({ error: "Forbidden" }, { status: 403 });

    ingestDocument(documentId).catch((err) => console.error("[ingest]", err));
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
