// Health endpoint — liveness + readiness in one.
//
// Runs three sub-checks in parallel with a per-check timeout so a hung
// dependency can't wedge the whole probe. Overall status is "ok" only if
// the database check passes — everything else is informational.
//
// Intentionally bypasses `withApiHandler` and auth: load balancers and
// container runtimes need to hit this without credentials, and we want the
// response shape to stay stable even when the structured-logger or auth
// stack itself is misbehaving.

import { prisma } from "@/lib/prisma";
import { log } from "@/lib/logger";

type CheckStatus = "ok" | "fail" | "skipped" | "unconfigured";

interface CheckResult {
  status: CheckStatus;
  ms: number;
  detail?: string;
}

const TIMEOUT_MS = 3000;

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    promise.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (e) => {
        clearTimeout(timer);
        reject(e);
      },
    );
  });
}

async function checkDatabase(): Promise<CheckResult> {
  const started = Date.now();
  try {
    await withTimeout(prisma.$queryRaw`SELECT 1`, TIMEOUT_MS, "database");
    return { status: "ok", ms: Date.now() - started };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return { status: "fail", ms: Date.now() - started, detail };
  }
}

async function checkEmbedding(): Promise<CheckResult> {
  const started = Date.now();
  try {
    const baseUrl = process.env.EMBEDDING_BASE_URL ?? "";
    const mod = await withTimeout(
      import("@/lib/ai/embeddings-local"),
      TIMEOUT_MS,
      "embedding import",
    );
    // Reference embedLocal so this file stays a real consumer of the module
    // (and so tree-shaking can't drop it from the standalone bundle).
    void mod.embedLocal;
    const local = mod.isLocalEmbeddingUrl(baseUrl);
    if (local) {
      return { status: "ok", ms: Date.now() - started, detail: "local model (lazy-loaded)" };
    }
    return {
      status: "skipped",
      ms: Date.now() - started,
      detail: "remote endpoint — not checked here",
    };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return { status: "fail", ms: Date.now() - started, detail };
  }
}

function checkLlm(): CheckResult {
  const started = Date.now();
  const key = process.env.LLM_API_KEY;
  const placeholders = new Set(["", "ollama", "local", "changeme", "change-me", "your-api-key"]);
  if (!key || placeholders.has(key.trim().toLowerCase())) {
    return {
      status: "unconfigured",
      ms: Date.now() - started,
      detail: "LLM_API_KEY is missing or set to a placeholder",
    };
  }
  return { status: "ok", ms: Date.now() - started, detail: "LLM_API_KEY is set" };
}

/**
 * Probe the configured Milvus backend. Skipped when no org has selected
 * MILVUS — most deployments stay on Postgres so we don't want to noise the
 * health endpoint with "unconfigured" entries.
 *
 * When multiple orgs use Milvus we probe just one (the most-recently active,
 * proxied via OrgAiConfig.updatedAt) — health is per-cluster and the
 * connection is shared per (uri, token) pair, so a single probe covers
 * the breaker state for all callers.
 */
async function checkVector(): Promise<CheckResult> {
  const started = Date.now();
  try {
    const candidate = await withTimeout(
      prisma.orgAiConfig.findFirst({
        where: { vectorBackend: "MILVUS", milvusUri: { not: null } },
        orderBy: { updatedAt: "desc" },
        select: { organizationId: true },
      }),
      TIMEOUT_MS,
      "vector candidate lookup",
    );
    if (!candidate) {
      return {
        status: "skipped",
        ms: Date.now() - started,
        detail: "no org configured for Milvus",
      };
    }

    // Lazy import — keeps the SDK out of the standalone build for orgs that
    // don't use Milvus.
    const { createMilvusForOrg } = await import("@/lib/ai/vector/milvus");
    const store = await createMilvusForOrg(candidate.organizationId);
    const probe = await withTimeout(
      store.health(candidate.organizationId),
      TIMEOUT_MS,
      "milvus health",
    );
    return {
      status: probe.ok ? "ok" : "fail",
      ms: Date.now() - started,
      detail: probe.detail,
    };
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    return { status: "fail", ms: Date.now() - started, detail };
  }
}

export const GET = async (): Promise<Response> => {
  log().info({ route: "/api/health" }, "health check");

  const [database, embedding, vector] = await Promise.all([
    checkDatabase(),
    checkEmbedding(),
    checkVector(),
  ]);
  const llm = checkLlm();

  const checks = { database, embedding, llm, vector };
  const overall: "ok" | "degraded" = database.status === "ok" ? "ok" : "degraded";

  return Response.json(
    { status: overall, checks },
    { status: overall === "ok" ? 200 : 503 },
  );
};
