import { jsonError, requireUser } from "@/lib/authz";
import { toolRegistry } from "@/lib/ai/tools/registry";
import "@/lib/ai/tools/builtin";

export async function GET() {
  try {
    await requireUser();
    return Response.json({
      tools: toolRegistry.list().map((t) => ({
        name: t.name,
        description: t.description,
      })),
    });
  } catch (e) {
    return jsonError(e);
  }
}
