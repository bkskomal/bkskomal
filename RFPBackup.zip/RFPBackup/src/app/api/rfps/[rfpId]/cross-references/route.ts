import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { findCrossReferences } from "@/lib/ai/cross-reference";

/**
 * GET /api/rfps/:rfpId/cross-references
 *
 * Returns hint-level matches between the primary RFP's questions and the
 * rawText of its attachments. The UI uses these to render
 * "also asked in: SECURITY_QUESTIONNAIRE" badges next to a question.
 *
 * Hints, not authoritative — generation does not depend on these.
 */
export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  const { rfp } = await requireRfpAccess(rfpId);
  const crossRefs = await findCrossReferences({
    rfpId,
    organizationId: rfp.project.organizationId,
  });
  return Response.json({ crossRefs });
});
