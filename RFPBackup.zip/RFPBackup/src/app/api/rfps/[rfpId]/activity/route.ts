import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";

export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const events = await prisma.activityEvent.findMany({
    where: { rfpId },
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { actor: { select: { id: true, name: true, email: true } } },
  });
  return Response.json({ events });
});
