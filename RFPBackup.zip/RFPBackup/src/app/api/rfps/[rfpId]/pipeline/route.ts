import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { advance, createRunForRfp } from "@/lib/pipeline/engine";

/**
 * Read the current pipeline run for an RFP. Creates one on the fly if the
 * RFP was uploaded before pipelines existed.
 */
export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  let run = await prisma.pipelineRun.findUnique({
    where: { rfpId },
    include: { steps: { orderBy: { index: "asc" } }, template: { select: { name: true } } },
  });
  if (!run) {
    await createRunForRfp(rfpId);
    run = await prisma.pipelineRun.findUnique({
      where: { rfpId },
      include: { steps: { orderBy: { index: "asc" } }, template: { select: { name: true } } },
    });
  }

  // Tick the engine on every poll. AUTO step handlers are idempotent — they
  // observe state and either advance (SUCCEEDED/FAILED), self-heal (RUNNING
  // with a re-kicked worker), or wait (RUNNING). Without this call, AUTO
  // steps that need a re-check (e.g. processRfp finished after the engine
  // last ran) would sit in RUNNING until the next manual POST. Cheap no-op
  // when the run is already SUCCEEDED / FAILED / STOPPED / PAUSED.
  if (run && (run.status === "RUNNING" || run.status === "PENDING")) {
    try {
      await advance(rfpId);
      run = await prisma.pipelineRun.findUnique({
        where: { rfpId },
        include: { steps: { orderBy: { index: "asc" } }, template: { select: { name: true } } },
      });
    } catch (err) {
      console.error("[pipeline GET] advance threw", err);
    }
  }

  // Resolve pausedById -> {name, email} for the UI badge. Separate query
  // because pausedById has no Prisma relation defined on the model.
  let pausedBy: { id: string; name: string | null; email: string | null } | null = null;
  if (run?.pausedById) {
    pausedBy = await prisma.user.findUnique({
      where: { id: run.pausedById },
      select: { id: true, name: true, email: true },
    });
  }

  return Response.json({ run: run ? { ...run, pausedBy } : null });
});

/**
 * Re-run advance() — useful as a manual refresh / nudge.
 */
export const POST = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  await advance(rfpId);
  return Response.json({ ok: true });
});
