// PATCH /api/rfps/[rfpId]/pipeline/edit — edit remaining steps of a paused run.

import { z } from "zod";
import { PipelineStepMode } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { editRunSteps, type PipelineStepEdit } from "@/lib/pipeline/engine";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { logActivity } from "@/lib/activity";

const editSchema = z.object({
  index: z.number().int().nonnegative(),
  label: z.string().min(1).max(200).optional(),
  mode: z.nativeEnum(PipelineStepMode).optional(),
  // Step config is opaque JSON — validated against the step's handler later.
  config: z.unknown().optional(),
  action: z.enum(["skip", "reset"]).optional(),
});

const bodySchema = z.object({
  edits: z.array(editSchema).min(1).max(50),
});

export const PATCH = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);
  const body = bodySchema.parse(await req.json());

  await editRunSteps(rfpId, body.edits as PipelineStepEdit[]);

  void audit({
    event: "PIPELINE_EDITED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      editCount: body.edits.length,
      indices: body.edits.map((e) => e.index),
      actions: body.edits.map((e) => e.action ?? "modify"),
    },
    ...auditContextFromRequest(req),
  });
  void logActivity({
    rfpId,
    actorId: user.id,
    kind: "RFP_PROCESSED",
    payload: {
      pipelineAction: "EDITED",
      editCount: body.edits.length,
      indices: body.edits.map((e) => e.index),
    },
  });

  return Response.json({ ok: true });
});
