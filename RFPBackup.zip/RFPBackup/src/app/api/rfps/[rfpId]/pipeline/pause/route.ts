// POST /api/rfps/[rfpId]/pipeline/pause — pause an in-flight pipeline run.

import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { pauseRun } from "@/lib/pipeline/engine";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { logActivity } from "@/lib/activity";

const bodySchema = z.object({ reason: z.string().max(500).optional() });

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);
  const raw = await req.json().catch(() => ({}));
  const body = bodySchema.parse(raw);

  await pauseRun(rfpId, user.id, body.reason);

  void audit({
    event: "PIPELINE_PAUSED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: { reason: body.reason ?? null },
    ...auditContextFromRequest(req),
  });
  void logActivity({
    rfpId,
    actorId: user.id,
    kind: "RFP_PROCESSED",
    payload: { pipelineAction: "PAUSED", reason: body.reason ?? null },
  });

  return Response.json({ ok: true });
});
