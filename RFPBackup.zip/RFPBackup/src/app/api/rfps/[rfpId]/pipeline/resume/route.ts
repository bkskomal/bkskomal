// POST /api/rfps/[rfpId]/pipeline/resume — resume a paused pipeline run.

import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { resumeRun } from "@/lib/pipeline/engine";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { logActivity } from "@/lib/activity";

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);

  await resumeRun(rfpId);

  void audit({
    event: "PIPELINE_RESUMED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    ...auditContextFromRequest(req),
  });
  void logActivity({
    rfpId,
    actorId: user.id,
    kind: "RFP_PROCESSED",
    payload: { pipelineAction: "RESUMED" },
  });

  return Response.json({ ok: true });
});
