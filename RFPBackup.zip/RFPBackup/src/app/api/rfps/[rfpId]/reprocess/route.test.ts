import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";
import { _resetForTests } from "@/lib/rate-limit";

// ---------------------------------------------------------------------------
// Mocks. Hoisted helpers so factory closures see them.
// ---------------------------------------------------------------------------

const { authMock, processRfpMock, prismaMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  processRfpMock: vi.fn(),
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
    },
    membership: {
      findUnique: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/rfp-pipeline", () => ({
  processRfp: (...args: unknown[]) => processRfpMock(...args),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

// Import after the mocks bind.
import { POST } from "./route";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const USER_ID = "user-1";
const ORG_ID = "org-1";
const RFP_ID = "rfp-1";

const session = { user: { id: USER_ID } };

function buildRfpFixture(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RFP_ID,
    title: "Acme RFP",
    project: {
      id: "proj-1",
      organizationId: ORG_ID,
    },
    ...overrides,
  };
}

function buildRequest() {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/reprocess`, { method: "POST" });
}

const params = () => ({ params: Promise.resolve({ rfpId: RFP_ID }) });

// ---------------------------------------------------------------------------
// Setup — reset state per test.
// ---------------------------------------------------------------------------

beforeEach(() => {
  _resetForTests();
  vi.clearAllMocks();

  authMock.mockResolvedValue(session);
  prismaMock.rFP.findUnique.mockResolvedValue(buildRfpFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  // processRfp is fire-and-forget; default to a resolved promise so the
  // unhandled-rejection path in the route's `.catch` doesn't fire.
  processRfpMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// Tests.
// ---------------------------------------------------------------------------

describe("POST /api/rfps/:rfpId/reprocess — auth gating", () => {
  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.code).toBe("unauthenticated");
    // No pipeline kickoff on failed auth.
    expect(processRfpMock).not.toHaveBeenCalled();
  });

  it("returns 404 when RFP does not exist", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(404);
    expect(processRfpMock).not.toHaveBeenCalled();
  });

  it("returns 403 when user is not a member of the owning org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(403);
    const body = await res.json();
    expect(body.code).toBe("forbidden");
    expect(processRfpMock).not.toHaveBeenCalled();
  });
});

describe("POST /api/rfps/:rfpId/reprocess — happy path", () => {
  it("returns 200 { ok: true } and kicks off processRfp with the rfpId", async () => {
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true });
    expect(processRfpMock).toHaveBeenCalledTimes(1);
    expect(processRfpMock).toHaveBeenCalledWith(RFP_ID);
  });

  it("returns immediately without awaiting the pipeline (fire-and-forget)", async () => {
    // Hang the pipeline indefinitely — the response must still resolve.
    processRfpMock.mockImplementationOnce(() => new Promise(() => {}));
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({ ok: true });
  });
});

describe("POST /api/rfps/:rfpId/reprocess — error propagation", () => {
  it("a pipeline rejection is swallowed via .catch and logged (does not affect response)", async () => {
    // The route is `processRfp(rfpId).catch(...)` so a sync throw inside the
    // promise still resolves the request 200. We verify the response is 200
    // and the catch logger fires.
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    processRfpMock.mockRejectedValueOnce(new Error("parser blew up"));

    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200);
    // Yield so the rejection settles and .catch runs.
    await new Promise((r) => setImmediate(r));
    expect(consoleSpy).toHaveBeenCalled();
    const args = consoleSpy.mock.calls.flat().map(String).join(" ");
    expect(args).toContain("[rfp pipeline]");
    consoleSpy.mockRestore();
  });

  it("a DB error inside requireRfpAccess surfaces as 500", async () => {
    // Simulate Prisma blowing up during access check.
    prismaMock.rFP.findUnique.mockRejectedValueOnce(new Error("connection lost"));
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(500);
    expect(processRfpMock).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// Note on rate limiting and request validation:
//
// This route currently has NO rate limiting and NO request body to validate
// (it's a parameterless POST). That's a deliberate audit finding rather than a
// test gap — see the report. We assert the route does not 429 today so a
// regression that adds limiting without test coverage will surface.
// ---------------------------------------------------------------------------

describe("POST /api/rfps/:rfpId/reprocess — current contract (no rate limit, no body)", () => {
  it("does not return 429 even on a tight burst", async () => {
    const statuses: number[] = [];
    for (let i = 0; i < 20; i++) {
      const res = await POST(buildRequest(), params());
      statuses.push(res.status);
    }
    expect(statuses.every((s) => s === 200)).toBe(true);
  });
});
