import { NextRequest } from "next/server";
import { jsonError, requireRfpAccess } from "@/lib/authz";
import { processRfp } from "@/lib/rfp-pipeline";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ rfpId: string }> }) {
  try {
    const { rfpId } = await params;
    await requireRfpAccess(rfpId);
    processRfp(rfpId).catch((err) => console.error("[rfp pipeline]", err));
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
