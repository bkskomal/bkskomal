import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Mocks. Hoisted so factories can close over them.
// ---------------------------------------------------------------------------

const {
  authMock,
  auditMock,
  parseMatrixXlsxMock,
  readFileMock,
  prismaMock,
} = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn().mockResolvedValue(undefined),
  parseMatrixXlsxMock: vi.fn(),
  readFileMock: vi.fn(),
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
      update: vi.fn(),
    },
    membership: {
      findUnique: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/audit", () => ({
  audit: (...args: unknown[]) => auditMock(...args),
  auditContextFromRequest: () => ({}),
}));
vi.mock("@/lib/parsers/pricing-matrix", () => ({
  parseMatrixXlsx: (...args: unknown[]) => parseMatrixXlsxMock(...args),
  emitMatrixXlsx: () => Buffer.from("stub"),
}));
vi.mock("node:fs/promises", async () => {
  const actual = await vi.importActual<typeof import("node:fs/promises")>(
    "node:fs/promises",
  );
  return { ...actual, readFile: (...args: unknown[]) => readFileMock(...args) };
});

import { GET, PATCH } from "./route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const PROJECT_ID = "proj-1";
const PARENT_RFP_ID = "rfp-parent";
const ATTACHMENT_ID = "rfp-att-matrix";

const session = { user: { id: USER_ID } };

function buildParentRfpFixture() {
  return {
    id: PARENT_RFP_ID,
    title: "Acme RFP",
    parentRfpId: null,
    projectId: PROJECT_ID,
    project: { id: PROJECT_ID, organizationId: ORG_ID },
  };
}

function buildMatrixAttachment(overrides: Record<string, unknown> = {}) {
  return {
    id: ATTACHMENT_ID,
    parentRfpId: PARENT_RFP_ID,
    storagePath: "/tmp/uploads/pricing.xlsx",
    fileName: "pricing.xlsx",
    docRole: "PRICING_MATRIX",
    mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    pricingMatrix: {
      headers: ["Item", "Tier 1", "Tier 2"],
      rows: [
        {
          label: "License",
          cells: [{ value: "$100" }, {}],
        },
        {
          label: "Support",
          cells: [{}, {}],
        },
      ],
    },
    ...overrides,
  };
}

const params = () => ({
  params: Promise.resolve({ rfpId: PARENT_RFP_ID, attachmentId: ATTACHMENT_ID }),
});

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
});

// ---------------------------------------------------------------------------
// GET
// ---------------------------------------------------------------------------

describe("GET /api/rfps/:rfpId/attachments/:attachmentId/matrix", () => {
  it("returns the persisted matrix in the response body", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture()) // requireRfpAccess
      .mockResolvedValueOnce(buildMatrixAttachment()); // loadMatrixAttachment
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
    );
    const res = await GET(req, params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.matrix.headers).toEqual(["Item", "Tier 1", "Tier 2"]);
    expect(body.matrix.rows).toHaveLength(2);
    expect(body.matrix.rows[0]).toEqual({
      label: "License",
      cells: [{ value: "$100" }, {}],
    });
  });

  it("lazy-parses the .xlsx when pricingMatrix JSON is null", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildMatrixAttachment({ pricingMatrix: null }));
    readFileMock.mockResolvedValueOnce(Buffer.from([1, 2, 3]));
    parseMatrixXlsxMock.mockResolvedValueOnce({
      headers: ["Item", "Tier"],
      rows: [{ label: "X", cells: [{ value: "$1" }] }],
    });
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
    );
    const res = await GET(req, params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.matrix.headers).toEqual(["Item", "Tier"]);
    expect(prismaMock.rFP.update).toHaveBeenCalledOnce();
    const updateArgs = prismaMock.rFP.update.mock.calls[0][0];
    expect(updateArgs.where).toEqual({ id: ATTACHMENT_ID });
    expect(updateArgs.data.pricingMatrix.rows[0].label).toBe("X");
  });

  it("returns 403 when the caller is not a member of the parent's org", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(buildParentRfpFixture());
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
    );
    const res = await GET(req, params());
    expect(res.status).toBe(403);
  });

  it("400s when the attachment is not a pricing matrix", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildMatrixAttachment({ docRole: "REFERENCE" }));
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
    );
    const res = await GET(req, params());
    expect(res.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// PATCH
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/attachments/:attachmentId/matrix", () => {
  it("persists an updated generated value to the matrix JSON", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildMatrixAttachment());
    prismaMock.rFP.update.mockResolvedValueOnce({});
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          rowIndex: 0,
          cellIndex: 1,
          generated: "$200",
          confidence: 0.8,
        }),
      },
    );
    const res = await PATCH(req, params());
    expect(res.status).toBe(200);

    const updateArgs = prismaMock.rFP.update.mock.calls[0][0];
    expect(updateArgs.where).toEqual({ id: ATTACHMENT_ID });
    const persisted = updateArgs.data.pricingMatrix;
    expect(persisted.rows[0].cells[1].generated).toBe("$200");
    expect(persisted.rows[0].cells[1].confidence).toBe(0.8);
    // value for the same cell remains unset because we didn't pass one.
    expect(persisted.rows[0].cells[1].value).toBeUndefined();

    expect(auditMock).toHaveBeenCalledOnce();
    expect(auditMock.mock.calls[0][0].event).toBe("MATRIX_CELL_UPDATED");
  });

  it("400s when rowIndex is out of range", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildMatrixAttachment());
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          rowIndex: 99,
          cellIndex: 0,
          generated: "x",
        }),
      },
    );
    const res = await PATCH(req, params());
    expect(res.status).toBe(400);
    expect(prismaMock.rFP.update).not.toHaveBeenCalled();
  });

  it("403s when caller is not a member of the parent's org", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(buildParentRfpFixture());
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}/matrix`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ rowIndex: 0, cellIndex: 0, generated: "x" }),
      },
    );
    const res = await PATCH(req, params());
    expect(res.status).toBe(403);
  });
});
