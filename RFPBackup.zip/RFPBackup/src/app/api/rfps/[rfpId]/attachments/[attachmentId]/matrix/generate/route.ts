// SSE-streaming pricing-matrix generator.
//
// POST body: { rowIndices?: number[] }
//   - rowIndices omitted/empty → generate every row in the matrix.
//   - otherwise generate only the named rows × all columns.
//
// For each cell we call generateMatrixCell (lib/ai/extract-matrix.ts) and
// stream a single SSE event with the per-cell result before persisting.
// Why stream:
//   - Even a small 20×5 matrix is 100 LLM calls. The user wants to watch
//     cells fill in, not stare at a spinner for 90s.
//   - Persisting after each cell means a connection drop only loses the
//     un-streamed tail; on reconnect, the GET endpoint returns whatever
//     completed so far.
//
// Failure model: a per-cell error becomes a `cell` event with
// generated="NEEDS INFO" / confidence=0 (the extractor already swallows
// exceptions). Catastrophic failures (DB write etc.) emit an `error` event
// and close the stream cleanly so the EventSource client sees it.
//
// Audit: ONE audit row per invocation (not per cell) — auditing 100 cells
// would drown the trail.

import { z } from "zod";
import { NextRequest } from "next/server";
import { RfpDocRole } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { requireRfpAccess } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";
import {
  parseMatrixXlsx,
  type PricingMatrix,
  type PricingCell,
} from "@/lib/parsers/pricing-matrix";
import { generateMatrixCell } from "@/lib/ai/extract-matrix";
import { matrixCellsGeneratedTotal } from "@/lib/metrics";
import { readFile } from "node:fs/promises";

const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const MAX_ATTACHMENT_CONTEXT = 4;
const ATTACHMENT_CONTEXT_BUDGET = 1500;

const bodySchema = z.object({
  rowIndices: z.array(z.number().int().nonnegative()).optional(),
});

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ rfpId: string; attachmentId: string }> },
): Promise<Response> {
  const { rfpId, attachmentId } = await params;

  // Auth + load BEFORE we open the stream so error responses are normal JSON
  // (the EventSource client doesn't surface 401 bodies meaningfully).
  let user: { id: string };
  let orgId: string;
  let attachment: {
    id: string;
    parentRfpId: string | null;
    storagePath: string;
    fileName: string;
    docRole: RfpDocRole;
    mimeType: string;
    pricingMatrix: unknown;
  };
  try {
    const access = await requireRfpAccess(rfpId);
    user = access.user;
    orgId = access.rfp.project.organizationId;
    const found = await prisma.rFP.findUnique({
      where: { id: attachmentId },
      select: {
        id: true,
        parentRfpId: true,
        storagePath: true,
        fileName: true,
        docRole: true,
        mimeType: true,
        pricingMatrix: true,
      },
    });
    if (!found || found.parentRfpId !== rfpId) {
      return Response.json({ error: "Attachment not found" }, { status: 404 });
    }
    if (found.docRole !== RfpDocRole.PRICING_MATRIX) {
      return Response.json(
        { error: `Attachment is not a pricing matrix (docRole=${found.docRole})` },
        { status: 400 },
      );
    }
    attachment = found;
  } catch (err) {
    const status =
      err instanceof Error && err.name === "AuthError"
        ? 401
        : err instanceof Error && err.name === "ForbiddenError"
          ? 403
          : err instanceof Error && err.name === "NotFoundError"
            ? 404
            : 500;
    return Response.json(
      { error: err instanceof Error ? err.message : "Internal error" },
      { status },
    );
  }

  const body = bodySchema.parse(await req.json().catch(() => ({})));

  // Resolve the matrix — lazy-parse if needed so a freshly-uploaded sheet
  // can be generated without a prior GET round-trip.
  let matrix = (attachment.pricingMatrix as PricingMatrix | null) ?? null;
  if (!matrix && attachment.mimeType === XLSX_MIME) {
    try {
      const buf = await readFile(attachment.storagePath);
      matrix = await parseMatrixXlsx(buf);
    } catch (err) {
      return Response.json(
        { error: "Could not parse matrix file: " + (err instanceof Error ? err.message : String(err)) },
        { status: 500 },
      );
    }
  }
  matrix = matrix ?? { headers: [], rows: [] };

  if (matrix.rows.length === 0 || matrix.headers.length <= 1) {
    return Response.json(
      { error: "Matrix has no rows or columns to generate" },
      { status: 400 },
    );
  }

  const rowIndices =
    body.rowIndices && body.rowIndices.length > 0
      ? body.rowIndices.filter((i) => i >= 0 && i < matrix!.rows.length)
      : matrix.rows.map((_, i) => i);

  // Pull a small context bundle ONCE for the entire matrix invocation:
  // golden answers (org-level) + companion-doc snippets attached to the
  // parent RFP. Re-using the same blocks per cell keeps prompt construction
  // cheap and the LLM warm with the same prefix.
  const contextBlocks = await buildContextBundle(rfpId, orgId, attachment.fileName);

  void audit({
    event: "MATRIX_GENERATED",
    actorId: user.id,
    organizationId: orgId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      attachmentId,
      rowCount: rowIndices.length,
      cellCount: rowIndices.length * (matrix.headers.length - 1),
    },
    ...auditContextFromRequest(req),
  });

  const stream = new ReadableStream({
    async start(controller) {
      const enc = new TextEncoder();
      const send = (event: string, data: unknown) => {
        try {
          controller.enqueue(
            enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
          );
        } catch {
          // controller closed by client disconnect — nothing to do.
        }
      };

      send("start", {
        attachmentId,
        rowIndices,
        cellsPerRow: matrix!.headers.length - 1,
      });

      try {
        const cellCount = matrix!.headers.length - 1;
        for (const rowIndex of rowIndices) {
          const row = matrix!.rows[rowIndex];
          if (!row) continue;
          for (let cellIndex = 0; cellIndex < cellCount; cellIndex++) {
            const columnHeader = matrix!.headers[cellIndex + 1] ?? "";
            const result = await generateMatrixCell({
              rowLabel: row.label,
              columnHeader,
              contextBlocks,
              organizationId: orgId,
            });
            matrixCellsGeneratedTotal.inc({ org: orgId });
            const existing = row.cells[cellIndex] ?? ({} as PricingCell);
            const updated: PricingCell = {
              ...existing,
              generated: result.generated,
              generatedAt: new Date().toISOString(),
              confidence: result.confidence,
            };
            row.cells[cellIndex] = updated;
            // Persist incrementally so a dropped connection still keeps the
            // cells we already generated.
            await prisma.rFP.update({
              where: { id: attachmentId },
              data: { pricingMatrix: matrix as unknown as never },
            });
            send("cell", {
              rowIndex,
              cellIndex,
              generated: result.generated,
              confidence: result.confidence,
            });
          }
        }
        send("done", { ok: true });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        send("error", { message });
      } finally {
        try {
          controller.close();
        } catch {
          // already closed
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}

/**
 * Build a small context bundle for matrix-cell generation. We avoid running
 * the heavier retrieval pipeline used by generateResponse — for a pricing
 * cell, "what does similar product Y cost?" doesn't benefit from KB chunk
 * reranking, and we'd pay the latency on every cell. Instead:
 *   - golden answers (top 6 recent) provide the org's price/format style,
 *   - any READY companion attachments are spliced in as raw context.
 */
async function buildContextBundle(
  primaryRfpId: string,
  orgId: string,
  fileName: string,
): Promise<string[]> {
  const blocks: string[] = [];
  try {
    const goldens = await prisma.goldenAnswer.findMany({
      where: { organizationId: orgId },
      orderBy: { updatedAt: "desc" },
      take: 6,
      select: { question: true, answer: true },
    });
    for (const g of goldens) {
      blocks.push(`Past answer\nQ: ${g.question}\nA: ${g.answer}`);
    }
  } catch {
    // best effort
  }
  try {
    const attachments = await prisma.rFP.findMany({
      where: { parentRfpId: primaryRfpId },
      orderBy: { createdAt: "asc" },
      take: MAX_ATTACHMENT_CONTEXT,
      select: { docRole: true, fileName: true, rawText: true },
    });
    for (const a of attachments) {
      if (!a.rawText) continue;
      const t = a.rawText.slice(0, ATTACHMENT_CONTEXT_BUDGET).trim();
      if (!t) continue;
      blocks.push(`${a.docRole} (${a.fileName})\n${t}`);
    }
  } catch {
    // best effort
  }
  // Pin the matrix's own filename as a context hint — useful when the user
  // gives the file a meaningful name like "acme-pricing-tier-2026.xlsx".
  blocks.unshift(`Pricing matrix file: ${fileName}`);
  return blocks;
}
