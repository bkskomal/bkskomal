import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Mocks. Hoisted so factory closures see them.
// ---------------------------------------------------------------------------

const {
  authMock,
  parseDocumentMock,
  saveUploadMock,
  deleteUploadMock,
  logActivityMock,
  auditMock,
  prismaMock,
} = vi.hoisted(() => ({
  authMock: vi.fn(),
  parseDocumentMock: vi.fn(),
  saveUploadMock: vi.fn(),
  deleteUploadMock: vi.fn(),
  logActivityMock: vi.fn().mockResolvedValue(undefined),
  auditMock: vi.fn().mockResolvedValue(undefined),
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
      findMany: vi.fn(),
      create: vi.fn(),
      update: vi.fn(),
      delete: vi.fn(),
    },
    membership: {
      findUnique: vi.fn(),
    },
    question: {
      createMany: vi.fn(),
      findMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/parsers", async () => {
  const actual = await vi.importActual<typeof import("@/lib/parsers")>("@/lib/parsers");
  return {
    ...actual,
    parseDocument: (...args: unknown[]) => parseDocumentMock(...args),
  };
});
vi.mock("@/lib/storage", () => ({
  saveUpload: (...args: unknown[]) => saveUploadMock(...args),
  deleteUpload: (...args: unknown[]) => deleteUploadMock(...args),
}));
vi.mock("@/lib/activity", () => ({
  logActivity: (...args: unknown[]) => logActivityMock(...args),
}));
vi.mock("@/lib/audit", () => ({
  audit: (...args: unknown[]) => auditMock(...args),
  auditContextFromRequest: () => ({}),
}));

import { POST, GET } from "./route";
import { DELETE, PATCH } from "./[attachmentId]/route";

const USER_ID = "user-1";
const ORG_ID = "org-1";
const PROJECT_ID = "proj-1";
const PARENT_RFP_ID = "rfp-parent";
const ATTACHMENT_ID = "rfp-att";

const session = { user: { id: USER_ID } };

function buildParentRfpFixture(overrides: Record<string, unknown> = {}) {
  return {
    id: PARENT_RFP_ID,
    title: "Acme RFP",
    parentRfpId: null,
    projectId: PROJECT_ID,
    project: {
      id: PROJECT_ID,
      organizationId: ORG_ID,
    },
    ...overrides,
  };
}

function buildAttachmentFixture(overrides: Record<string, unknown> = {}) {
  return {
    id: ATTACHMENT_ID,
    title: "questionnaire.pdf",
    parentRfpId: PARENT_RFP_ID,
    projectId: PROJECT_ID,
    fileName: "questionnaire.pdf",
    fileSize: 12,
    mimeType: "application/pdf",
    storagePath: "/tmp/uploads/questionnaire.pdf",
    docRole: "SECURITY_QUESTIONNAIRE",
    createdAt: new Date("2026-01-01T00:00:00Z"),
    updatedAt: new Date("2026-01-01T00:00:00Z"),
    ...overrides,
  };
}

function buildMultipart(fileName: string, content: string, docRole: string): NextRequest {
  const fd = new FormData();
  const file = new File([content], fileName, { type: "application/pdf" });
  fd.append("file", file);
  fd.append("docRole", docRole);
  return new NextRequest(`http://x/api/rfps/${PARENT_RFP_ID}/attachments`, {
    method: "POST",
    body: fd,
  });
}

const params = () => ({ params: Promise.resolve({ rfpId: PARENT_RFP_ID }) });
const attachmentParams = () => ({
  params: Promise.resolve({ rfpId: PARENT_RFP_ID, attachmentId: ATTACHMENT_ID }),
});

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.rFP.findUnique.mockResolvedValue(buildParentRfpFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  prismaMock.rFP.findMany.mockResolvedValue([]);
  prismaMock.rFP.create.mockResolvedValue(buildAttachmentFixture());
  prismaMock.rFP.update.mockResolvedValue(buildAttachmentFixture());
  prismaMock.rFP.delete.mockResolvedValue(buildAttachmentFixture());
  saveUploadMock.mockResolvedValue({ storagePath: "/tmp/uploads/questionnaire.pdf" });
  parseDocumentMock.mockResolvedValue({ text: "Q1: encryption?\nQ2: backups?" });
  prismaMock.question.findMany.mockResolvedValue([]);
});

// ---------------------------------------------------------------------------
// POST
// ---------------------------------------------------------------------------

describe("POST /api/rfps/:rfpId/attachments", () => {
  it("creates a child RFP with parentRfpId + docRole and 201s", async () => {
    const req = buildMultipart("questionnaire.pdf", "stub", "SECURITY_QUESTIONNAIRE");
    const res = await POST(req, params());
    expect(res.status).toBe(201);
    expect(prismaMock.rFP.create).toHaveBeenCalledOnce();
    const args = prismaMock.rFP.create.mock.calls[0][0];
    expect(args.data.parentRfpId).toBe(PARENT_RFP_ID);
    expect(args.data.docRole).toBe("SECURITY_QUESTIONNAIRE");
    expect(args.data.projectId).toBe(PROJECT_ID);
    expect(args.data.status).toBe("READY");
  });

  it("returns 403 when caller is not a member of the parent's org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const req = buildMultipart("addendum.pdf", "stub", "ADDENDUM");
    const res = await POST(req, params());
    expect(res.status).toBe(403);
    expect(prismaMock.rFP.create).not.toHaveBeenCalled();
  });

  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const req = buildMultipart("addendum.pdf", "stub", "ADDENDUM");
    const res = await POST(req, params());
    expect(res.status).toBe(401);
    expect(prismaMock.rFP.create).not.toHaveBeenCalled();
  });

  it("rejects PRIMARY as a docRole (only legal for the parent)", async () => {
    const req = buildMultipart("addendum.pdf", "stub", "PRIMARY");
    const res = await POST(req, params());
    expect(res.status).toBe(400);
    expect(prismaMock.rFP.create).not.toHaveBeenCalled();
  });

  it("rejects unsupported file extensions", async () => {
    const fd = new FormData();
    fd.append("file", new File(["stub"], "questionnaire.exe", { type: "application/octet-stream" }));
    fd.append("docRole", "ADDENDUM");
    const req = new NextRequest(`http://x/api/rfps/${PARENT_RFP_ID}/attachments`, {
      method: "POST",
      body: fd,
    });
    const res = await POST(req, params());
    expect(res.status).toBe(400);
    expect(prismaMock.rFP.create).not.toHaveBeenCalled();
  });

  it("does NOT trigger question extraction (no Question rows created)", async () => {
    const req = buildMultipart("questionnaire.pdf", "stub", "SECURITY_QUESTIONNAIRE");
    const res = await POST(req, params());
    expect(res.status).toBe(201);
    // The route must never go through processRfp/extractQuestions on attachments.
    expect(prismaMock.question.createMany).not.toHaveBeenCalled();
  });

  it("audits the attachment add", async () => {
    const req = buildMultipart("questionnaire.pdf", "stub", "SECURITY_QUESTIONNAIRE");
    await POST(req, params());
    expect(auditMock).toHaveBeenCalledOnce();
    expect(auditMock.mock.calls[0][0].event).toBe("RFP_ATTACHMENT_ADDED");
  });

  it("rejects attaching to an attachment (no nested trees)", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(
      buildParentRfpFixture({ parentRfpId: "some-other-parent" }),
    );
    const req = buildMultipart("addendum.pdf", "stub", "ADDENDUM");
    const res = await POST(req, params());
    expect(res.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// GET
// ---------------------------------------------------------------------------

describe("GET /api/rfps/:rfpId/attachments", () => {
  it("lists attachments for the RFP, sorted oldest-first", async () => {
    prismaMock.rFP.findMany.mockResolvedValueOnce([
      buildAttachmentFixture({ id: "a1", createdAt: new Date("2026-01-01T00:00:00Z") }),
      buildAttachmentFixture({ id: "a2", createdAt: new Date("2026-01-02T00:00:00Z") }),
    ]);
    const req = new NextRequest(`http://x/api/rfps/${PARENT_RFP_ID}/attachments`);
    const res = await GET(req, params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.attachments).toHaveLength(2);
    expect(prismaMock.rFP.findMany.mock.calls[0][0].orderBy).toEqual({ createdAt: "asc" });
  });
});

// ---------------------------------------------------------------------------
// DELETE
// ---------------------------------------------------------------------------

describe("DELETE /api/rfps/:rfpId/attachments/:attachmentId", () => {
  it("removes an attachment when parentRfpId matches", async () => {
    prismaMock.rFP.findUnique
      // parent (requireRfpAccess)
      .mockResolvedValueOnce(buildParentRfpFixture())
      // attachment (loadAttachment)
      .mockResolvedValueOnce(buildAttachmentFixture());
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}`,
      { method: "DELETE" },
    );
    const res = await DELETE(req, attachmentParams());
    expect(res.status).toBe(200);
    expect(prismaMock.rFP.delete).toHaveBeenCalledWith({ where: { id: ATTACHMENT_ID } });
    expect(deleteUploadMock).toHaveBeenCalledWith("/tmp/uploads/questionnaire.pdf");
  });

  it("404s when the attachment belongs to a different parent", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildAttachmentFixture({ parentRfpId: "other-parent" }));
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}`,
      { method: "DELETE" },
    );
    const res = await DELETE(req, attachmentParams());
    expect(res.status).toBe(404);
    expect(prismaMock.rFP.delete).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// PATCH (re-classify)
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/attachments/:attachmentId", () => {
  it("re-classifies an attachment's docRole", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildAttachmentFixture({ docRole: "REFERENCE" }));
    prismaMock.rFP.update.mockResolvedValueOnce(
      buildAttachmentFixture({ docRole: "PRICING_MATRIX" }),
    );
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ docRole: "PRICING_MATRIX" }),
      },
    );
    const res = await PATCH(req, attachmentParams());
    expect(res.status).toBe(200);
    expect(prismaMock.rFP.update).toHaveBeenCalledWith(
      expect.objectContaining({ where: { id: ATTACHMENT_ID }, data: { docRole: "PRICING_MATRIX" } }),
    );
  });

  it("rejects PRIMARY as a target role", async () => {
    prismaMock.rFP.findUnique
      .mockResolvedValueOnce(buildParentRfpFixture())
      .mockResolvedValueOnce(buildAttachmentFixture());
    const req = new NextRequest(
      `http://x/api/rfps/${PARENT_RFP_ID}/attachments/${ATTACHMENT_ID}`,
      {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ docRole: "PRIMARY" }),
      },
    );
    const res = await PATCH(req, attachmentParams());
    expect(res.status).toBe(400);
  });
});
