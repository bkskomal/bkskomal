// Shared helpers for the pricing-matrix routes. Lives outside route.ts so
// the route files keep only HTTP-method exports (Next.js requirement).

import { RfpDocRole } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { NotFoundError, ValidationError } from "@/lib/errors";

/**
 * Confirm the attachment exists, lives under the supplied parent, and that
 * its docRole is PRICING_MATRIX. Returns 404 (not 400) for mismatched
 * parents so we don't leak the existence of unrelated rows.
 */
export async function loadMatrixAttachment(rfpId: string, attachmentId: string) {
  const attachment = await prisma.rFP.findUnique({
    where: { id: attachmentId },
    select: {
      id: true,
      parentRfpId: true,
      storagePath: true,
      fileName: true,
      docRole: true,
      mimeType: true,
      pricingMatrix: true,
    },
  });
  if (!attachment) throw new NotFoundError("Attachment not found");
  if (attachment.parentRfpId !== rfpId) {
    throw new NotFoundError("Attachment not found on this RFP");
  }
  if (attachment.docRole !== RfpDocRole.PRICING_MATRIX) {
    throw new ValidationError(
      `Attachment is not a pricing matrix (docRole=${attachment.docRole})`,
    );
  }
  return attachment;
}

export const XLSX_MIME =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
