import { NextRequest } from "next/server";
import { z } from "zod";
import { RfpDocRole } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { ValidationError } from "@/lib/errors";
import { detectMime, parseDocument } from "@/lib/parsers";
import { saveUpload } from "@/lib/storage";
import { logActivity } from "@/lib/activity";
import { audit, auditContextFromRequest } from "@/lib/audit";

const docRoleSchema = z.nativeEnum(RfpDocRole).refine((r) => r !== RfpDocRole.PRIMARY, {
  message: "Attachments may not be PRIMARY — that's reserved for the parent RFP.",
});

/**
 * GET /api/rfps/:rfpId/attachments
 *
 * Returns the companion documents attached to this RFP, oldest first. The
 * primary RFP itself is NOT included — the caller already has it.
 */
export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const attachments = await prisma.rFP.findMany({
    where: { parentRfpId: rfpId },
    orderBy: { createdAt: "asc" },
    select: {
      id: true,
      title: true,
      fileName: true,
      fileSize: true,
      mimeType: true,
      docRole: true,
      createdAt: true,
      updatedAt: true,
    },
  });
  return Response.json({ attachments });
});

/**
 * POST /api/rfps/:rfpId/attachments
 *
 * Multipart upload that creates a child RFP row tied to the parent. We parse
 * the document and store rawText so generation can pull it in as supplementary
 * context, but we deliberately SKIP question extraction — attachments are
 * context, not their own question source.
 *
 * Body (multipart/form-data):
 *   - file:    the document
 *   - docRole: one of ADDENDUM | SECURITY_QUESTIONNAIRE | PRICING_MATRIX | SOW | REFERENCE
 *   - title:   optional override; defaults to the file name
 */
export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId: parentRfpId } = await params;
  const { user, rfp: parent } = await requireRfpAccess(parentRfpId);

  // Don't allow attaching to an attachment — keep the tree flat.
  if (parent.parentRfpId) {
    throw new ValidationError("Cannot attach to an attachment. Use the parent RFP.");
  }

  const form = await (req as NextRequest).formData();
  const file = form.get("file");
  const rawRole = form.get("docRole");
  const title = (form.get("title") as string | null) ?? "";
  if (!(file instanceof File)) throw new ValidationError("Missing file");
  const docRole = docRoleSchema.parse(rawRole);
  const mime = detectMime(file.name);
  if (!mime) throw new ValidationError(`Unsupported file type: ${file.name}`);

  const buf = Buffer.from(await file.arrayBuffer());
  const { storagePath } = await saveUpload(`rfp/${parent.projectId}/attachments`, file.name, buf);

  // Create the row FIRST so a parser failure still leaves the user a record
  // they can delete and retry.
  const attachment = await prisma.rFP.create({
    data: {
      projectId: parent.projectId,
      title: title || file.name,
      fileName: file.name,
      fileSize: file.size,
      mimeType: mime,
      storagePath,
      parentRfpId,
      docRole,
      // Attachments don't go through question extraction. Mark them READY so
      // the pipeline UI doesn't try to wait on them.
      status: "READY",
    },
  });

  // Parse + persist rawText. Errors here are non-fatal: the attachment exists
  // and the user can re-upload if parsing matters.
  try {
    const { text } = await parseDocument(storagePath, mime, parent.project.organizationId);
    await prisma.rFP.update({
      where: { id: attachment.id },
      data: { rawText: text },
    });
  } catch (err) {
    console.warn("[attachments] parse failed", { id: attachment.id, err });
    await prisma.rFP.update({
      where: { id: attachment.id },
      data: { errorMessage: err instanceof Error ? err.message : String(err) },
    });
  }

  // TODO(multi-doc): when a PRICING_MATRIX or SECURITY_QUESTIONNAIRE is added
  // we could re-run the primary's question extraction with the attachment text
  // as additional context, enriching question.context with hints like
  // "this question references the pricing matrix in row 14". Out of scope for
  // the initial multi-doc package work — keep extraction unchanged for now.

  void logActivity({
    rfpId: parentRfpId,
    actorId: user.id,
    // No dedicated ActivityKind for attachments yet — ride RFP_UPLOADED with
    // a payload marker so the activity feed can render a distinct row.
    kind: "RFP_UPLOADED",
    payload: {
      attachmentId: attachment.id,
      fileName: file.name,
      fileSize: file.size,
      docRole,
      kind: "RFP_ATTACHED",
    },
  });

  void audit({
    event: "RFP_ATTACHMENT_ADDED",
    actorId: user.id,
    organizationId: parent.project.organizationId,
    targetType: "rfp",
    targetId: parentRfpId,
    metadata: { attachmentId: attachment.id, docRole, fileName: file.name },
    ...auditContextFromRequest(req),
  });

  return Response.json({ attachment }, { status: 201 });
});
