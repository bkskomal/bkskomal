// Download the completed pricing matrix as an .xlsx.
//
// Roundtrips the persisted JSON back through emitMatrixXlsx. Filename is
// "{originalName}-completed.xlsx" (with a soft fallback if the original
// didn't have an .xlsx extension). Audited as MATRIX_EXPORTED.

import { RfpDocRole } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { NotFoundError, ValidationError } from "@/lib/errors";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { emitMatrixXlsx, type PricingMatrix } from "@/lib/parsers/pricing-matrix";

type Params = { rfpId: string; attachmentId: string };

const XLSX_CONTENT_TYPE =
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

export const GET = withApiHandler<Params>(async (req, { params }) => {
  const { rfpId, attachmentId } = await params;
  const { user, rfp: parent } = await requireRfpAccess(rfpId);

  const attachment = await prisma.rFP.findUnique({
    where: { id: attachmentId },
    select: {
      id: true,
      parentRfpId: true,
      fileName: true,
      docRole: true,
      pricingMatrix: true,
    },
  });
  if (!attachment) throw new NotFoundError("Attachment not found");
  if (attachment.parentRfpId !== rfpId) {
    throw new NotFoundError("Attachment not found on this RFP");
  }
  if (attachment.docRole !== RfpDocRole.PRICING_MATRIX) {
    throw new ValidationError("Attachment is not a pricing matrix");
  }

  const matrix = (attachment.pricingMatrix as PricingMatrix | null) ?? {
    headers: [],
    rows: [],
  };
  const buf = emitMatrixXlsx(matrix);

  void audit({
    event: "MATRIX_EXPORTED",
    actorId: user.id,
    organizationId: parent.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      attachmentId,
      rowCount: matrix.rows.length,
      headerCount: matrix.headers.length,
    },
    ...auditContextFromRequest(req),
  });

  const baseName = attachment.fileName.replace(/\.xlsx?$/i, "");
  const downloadName = `${baseName || "pricing-matrix"}-completed.xlsx`;

  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": XLSX_CONTENT_TYPE,
      "Content-Disposition": `attachment; filename="${downloadName.replace(/"/g, "")}"`,
      "Content-Length": String(buf.byteLength),
      "Cache-Control": "no-store",
    },
  });
});
