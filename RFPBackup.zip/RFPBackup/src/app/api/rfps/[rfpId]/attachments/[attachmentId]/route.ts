import { z } from "zod";
import { RfpDocRole } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { NotFoundError, ValidationError } from "@/lib/errors";
import { deleteUpload } from "@/lib/storage";
import { audit, auditContextFromRequest } from "@/lib/audit";

type Params = { rfpId: string; attachmentId: string };

const reclassifySchema = z.object({
  docRole: z.nativeEnum(RfpDocRole).refine((r) => r !== RfpDocRole.PRIMARY, {
    message: "Cannot demote/promote PRIMARY via this endpoint.",
  }),
});

async function loadAttachment(rfpId: string, attachmentId: string) {
  const attachment = await prisma.rFP.findUnique({
    where: { id: attachmentId },
    select: {
      id: true,
      parentRfpId: true,
      storagePath: true,
      fileName: true,
      docRole: true,
    },
  });
  if (!attachment) throw new NotFoundError("Attachment not found");
  // Strict parent match — prevents one RFP from deleting another's
  // attachments by guessing IDs.
  if (attachment.parentRfpId !== rfpId) {
    throw new NotFoundError("Attachment not found on this RFP");
  }
  return attachment;
}

/**
 * DELETE /api/rfps/:rfpId/attachments/:attachmentId
 *
 * Removes the attachment row and its underlying upload. Cascade is wired at
 * the FK level, but we also clean up the file on disk.
 */
export const DELETE = withApiHandler<Params>(async (req, { params }) => {
  const { rfpId, attachmentId } = await params;
  const { user, rfp: parent } = await requireRfpAccess(rfpId);
  const attachment = await loadAttachment(rfpId, attachmentId);

  await prisma.rFP.delete({ where: { id: attachmentId } });
  await deleteUpload(attachment.storagePath);

  void audit({
    event: "RFP_ATTACHMENT_REMOVED",
    actorId: user.id,
    organizationId: parent.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: { attachmentId, docRole: attachment.docRole, fileName: attachment.fileName },
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true });
});

/**
 * PATCH /api/rfps/:rfpId/attachments/:attachmentId
 *
 * Re-classifies an attachment (e.g. user uploaded as REFERENCE but it's
 * actually the SECURITY_QUESTIONNAIRE). Body: { docRole }.
 */
export const PATCH = withApiHandler<Params>(async (req, { params }) => {
  const { rfpId, attachmentId } = await params;
  const { user, rfp: parent } = await requireRfpAccess(rfpId);
  const existing = await loadAttachment(rfpId, attachmentId);

  const body = reclassifySchema.parse(await req.json().catch(() => ({})));
  if (!body.docRole) throw new ValidationError("Missing docRole");

  const updated = await prisma.rFP.update({
    where: { id: attachmentId },
    data: { docRole: body.docRole },
    select: {
      id: true,
      title: true,
      fileName: true,
      fileSize: true,
      mimeType: true,
      docRole: true,
      createdAt: true,
      updatedAt: true,
    },
  });

  void audit({
    event: "RFP_ATTACHMENT_RECLASSIFIED",
    actorId: user.id,
    organizationId: parent.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      attachmentId,
      from: existing.docRole,
      to: body.docRole,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ attachment: updated });
});
