// Pricing-matrix GET + PATCH for a single attachment.
//
// GET: return the parsed matrix. If the attachment is an .xlsx with role
//      PRICING_MATRIX and `pricingMatrix` is still null (e.g. uploaded
//      before this feature shipped), we lazy-parse the file on the fly and
//      persist the result so subsequent loads are O(1).
// PATCH: update exactly one cell. Body shape:
//        { rowIndex, cellIndex, generated?, value?, confidence? }
//      All fields besides the indices are optional and individually applied.
//      Audited as MATRIX_CELL_UPDATED.

import { readFile } from "node:fs/promises";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { ValidationError } from "@/lib/errors";
import { audit, auditContextFromRequest } from "@/lib/audit";
import {
  parseMatrixXlsx,
  type PricingMatrix,
  type PricingCell,
} from "@/lib/parsers/pricing-matrix";
import { loadMatrixAttachment, XLSX_MIME } from "./_helpers";

type Params = { rfpId: string; attachmentId: string };

const patchSchema = z.object({
  rowIndex: z.number().int().nonnegative(),
  cellIndex: z.number().int().nonnegative(),
  generated: z.string().optional(),
  value: z.string().optional(),
  confidence: z.number().min(0).max(1).optional(),
});

export const GET = withApiHandler<Params>(async (_req, { params }) => {
  const { rfpId, attachmentId } = await params;
  await requireRfpAccess(rfpId);
  const attachment = await loadMatrixAttachment(rfpId, attachmentId);

  let matrix = attachment.pricingMatrix as PricingMatrix | null;

  // Lazy parse: when the JSON column is empty but the file on disk is an
  // .xlsx, do a one-shot parse and persist. This lets us turn on the
  // feature for attachments uploaded before the parser shipped.
  if (!matrix && attachment.mimeType === XLSX_MIME) {
    try {
      const buf = await readFile(attachment.storagePath);
      matrix = await parseMatrixXlsx(buf);
      await prisma.rFP.update({
        where: { id: attachmentId },
        data: { pricingMatrix: matrix as unknown as never },
      });
    } catch (err) {
      // Don't block the read — surface an empty matrix so the UI renders
      // the editor and the user can decide what to do.
      console.warn("[matrix] lazy parse failed", { attachmentId, err });
      matrix = { headers: [], rows: [] };
    }
  }

  return Response.json({
    matrix: matrix ?? { headers: [], rows: [] },
    attachment: {
      id: attachment.id,
      fileName: attachment.fileName,
      docRole: attachment.docRole,
      mimeType: attachment.mimeType,
    },
  });
});

export const PATCH = withApiHandler<Params>(async (req, { params }) => {
  const { rfpId, attachmentId } = await params;
  const { user, rfp: parent } = await requireRfpAccess(rfpId);
  const attachment = await loadMatrixAttachment(rfpId, attachmentId);

  const body = patchSchema.parse(await req.json().catch(() => ({})));

  const matrix = (attachment.pricingMatrix as PricingMatrix | null) ?? {
    headers: [],
    rows: [],
  };
  const row = matrix.rows[body.rowIndex];
  if (!row) throw new ValidationError(`Row index ${body.rowIndex} out of range`);
  const cell = row.cells[body.cellIndex];
  if (!cell) {
    throw new ValidationError(`Cell index ${body.cellIndex} out of range`);
  }

  const updated: PricingCell = { ...cell };
  if (body.value !== undefined) updated.value = body.value;
  if (body.generated !== undefined) {
    updated.generated = body.generated;
    updated.generatedAt = new Date().toISOString();
  }
  if (body.confidence !== undefined) updated.confidence = body.confidence;
  row.cells[body.cellIndex] = updated;

  await prisma.rFP.update({
    where: { id: attachmentId },
    data: { pricingMatrix: matrix as unknown as never },
  });

  void audit({
    event: "MATRIX_CELL_UPDATED",
    actorId: user.id,
    organizationId: parent.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      attachmentId,
      rowIndex: body.rowIndex,
      cellIndex: body.cellIndex,
      fields: {
        value: body.value !== undefined,
        generated: body.generated !== undefined,
        confidence: body.confidence !== undefined,
      },
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ cell: updated });
});
