import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Hoisted mocks for prisma, auth, audit and the predict service.
// ---------------------------------------------------------------------------

const { authMock, prismaMock, auditMock, serviceMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  serviceMock: {
    scoreAndPersist: vi.fn(),
    applyOverride: vi.fn(),
  },
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
    },
    membership: {
      findUnique: vi.fn(),
    },
    winPrediction: {
      findUnique: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});

vi.mock("@/lib/predict/service", () => ({
  scoreAndPersist: serviceMock.scoreAndPersist,
  applyOverride: serviceMock.applyOverride,
}));

// Import after the mocks bind.
import { GET, POST, PATCH } from "./route";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const USER_ID = "user_pred_1";
const ORG_ID = "org_pred_1";
const RFP_ID = "rfp_pred_1";
const session = { user: { id: USER_ID } };

function buildRfp() {
  return {
    id: RFP_ID,
    title: "Pred RFP",
    project: { id: "proj_pred", organizationId: ORG_ID },
  };
}

function buildPrediction(
  overrides: Partial<Record<string, unknown>> = {},
): Record<string, unknown> {
  return {
    rfpId: RFP_ID,
    probability: 0.62,
    recommendation: "go",
    features: {
      questionCount: 10,
      avgQuestionConfidence: 0.7,
      avgGroundingScore: 0.8,
      complexityDist: { simple: 0.5, moderate: 0.3, complex: 0.2 },
      eligibilityDist: { answerable: 0.7, needs_info: 0.2, out_of_scope: 0.1 },
      daysToDeadline: 14,
      historicalWinRate: 0.6,
      similarRfpCount: 3,
      similarRfpWinRate: 0.67,
      hasGoldenAnswerCoverage: 0.4,
      daysSinceOldestSource: 200,
    },
    contributions: { historicalWinRate: 0.2, similarRfpWinRate: 0.1 },
    modelVersion: "win-predictor-v1",
    overrideAction: null,
    overrideById: null,
    overrideAt: null,
    createdAt: new Date("2026-04-01T00:00:00Z"),
    updatedAt: new Date("2026-04-02T00:00:00Z"),
    ...overrides,
  };
}

const params = () => ({ params: Promise.resolve({ rfpId: RFP_ID }) });

function getReq() {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/prediction`, { method: "GET" });
}
function postReq() {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/prediction`, { method: "POST" });
}
function patchReq(body: unknown) {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/prediction`, {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.rFP.findUnique.mockResolvedValue(buildRfp());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "ADMIN",
  });
  prismaMock.winPrediction.findUnique.mockResolvedValue(buildPrediction());
  serviceMock.scoreAndPersist.mockResolvedValue({
    probability: 0.62,
    recommendation: "go",
    contributions: { historicalWinRate: 0.2 },
    modelVersion: "win-predictor-v1",
    features: buildPrediction().features,
  });
  serviceMock.applyOverride.mockResolvedValue(undefined);
  auditMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// GET — shape and gating.
// ---------------------------------------------------------------------------

describe("GET /api/rfps/:rfpId/prediction", () => {
  it("returns the prediction shape decoded from JSON columns", async () => {
    const res = await GET(getReq(), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.rfpId).toBe(RFP_ID);
    expect(body.probability).toBe(0.62);
    expect(body.recommendation).toBe("go");
    expect(body.effectiveRecommendation).toBe("go");
    expect(body.features).toMatchObject({ questionCount: 10 });
    expect(body.contributions).toMatchObject({ historicalWinRate: 0.2 });
    expect(body.modelVersion).toBe("win-predictor-v1");
    expect(body.overrideAction).toBeNull();
  });

  it("reports an override-aware effectiveRecommendation when overrideAction is set", async () => {
    prismaMock.winPrediction.findUnique.mockResolvedValueOnce(
      buildPrediction({
        recommendation: "go",
        overrideAction: "no_bid",
        overrideById: USER_ID,
        overrideAt: new Date("2026-04-03T00:00:00Z"),
      }),
    );
    const res = await GET(getReq(), params());
    const body = await res.json();
    expect(body.recommendation).toBe("go");
    expect(body.effectiveRecommendation).toBe("no_bid");
    expect(body.overrideAction).toBe("no_bid");
  });

  it("returns 404 when no prediction exists yet", async () => {
    prismaMock.winPrediction.findUnique.mockResolvedValueOnce(null);
    const res = await GET(getReq(), params());
    expect(res.status).toBe(404);
  });

  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await GET(getReq(), params());
    expect(res.status).toBe(401);
  });

  it("returns 403 when the user is not a member", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await GET(getReq(), params());
    expect(res.status).toBe(403);
  });
});

// ---------------------------------------------------------------------------
// POST — re-score is admin-gated and audited.
// ---------------------------------------------------------------------------

describe("POST /api/rfps/:rfpId/prediction", () => {
  it("rescore is audited as WIN_PREDICTION_RESCORED", async () => {
    const res = await POST(postReq(), params());
    expect(res.status).toBe(200);
    await new Promise((r) => setImmediate(r));
    expect(serviceMock.scoreAndPersist).toHaveBeenCalledWith(RFP_ID);
    expect(auditMock).toHaveBeenCalledTimes(1);
    const payload = auditMock.mock.calls[0][0];
    expect(payload.event).toBe("WIN_PREDICTION_RESCORED");
    expect(payload.actorId).toBe(USER_ID);
    expect(payload.organizationId).toBe(ORG_ID);
    expect(payload.targetId).toBe(RFP_ID);
    expect(payload.metadata).toMatchObject({
      probability: 0.62,
      recommendation: "go",
    });
  });

  it("returns 403 for non-admin members", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await POST(postReq(), params());
    expect(res.status).toBe(403);
    expect(serviceMock.scoreAndPersist).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// PATCH — override is admin-gated and audited.
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/prediction", () => {
  it("override is audited as WIN_PREDICTION_OVERRIDDEN", async () => {
    const res = await PATCH(patchReq({ action: "go" }), params());
    expect(res.status).toBe(200);
    await new Promise((r) => setImmediate(r));
    expect(serviceMock.applyOverride).toHaveBeenCalledWith({
      rfpId: RFP_ID,
      action: "go",
      userId: USER_ID,
    });
    expect(auditMock).toHaveBeenCalledTimes(1);
    const payload = auditMock.mock.calls[0][0];
    expect(payload.event).toBe("WIN_PREDICTION_OVERRIDDEN");
    expect(payload.metadata).toEqual({ action: "go" });
  });

  it("accepts action: null to clear the override", async () => {
    const res = await PATCH(patchReq({ action: null }), params());
    expect(res.status).toBe(200);
    expect(serviceMock.applyOverride).toHaveBeenCalledWith({
      rfpId: RFP_ID,
      action: null,
      userId: USER_ID,
    });
  });

  it("rejects unknown override actions with 400", async () => {
    const res = await PATCH(patchReq({ action: "maybe" }), params());
    expect(res.status).toBe(400);
    expect(serviceMock.applyOverride).not.toHaveBeenCalled();
  });

  it("returns 403 for non-admin members", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "MEMBER",
    });
    const res = await PATCH(patchReq({ action: "go" }), params());
    expect(res.status).toBe(403);
    expect(serviceMock.applyOverride).not.toHaveBeenCalled();
  });
});
