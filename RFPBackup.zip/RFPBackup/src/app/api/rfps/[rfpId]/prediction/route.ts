// Predictive win-scoring routes (Tier C — moonshot).
//
//   GET    /api/rfps/:rfpId/prediction  — current prediction + features.
//                                          Members only.
//   POST   /api/rfps/:rfpId/prediction  — re-run scorer. Admins only.
//                                          Audited as WIN_PREDICTION_RESCORED.
//   PATCH  /api/rfps/:rfpId/prediction  — set/clear human override. Admins
//                                          only. Audited as WIN_PREDICTION_OVERRIDDEN.
//
// The GET response unpacks `features` and `contributions` from the JSON
// columns so the UI never has to know about Prisma's Json type. POST and
// PATCH return the post-mutation shape so the panel can re-render without
// a follow-up GET.

import { z } from "zod";
import { Role } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { prisma } from "@/lib/prisma";
import { audit, auditContextFromRequest } from "@/lib/audit";
import {
  scoreAndPersist,
  applyOverride,
  type ScoreWithFeatures,
} from "@/lib/predict/service";
import type { PredictionFeatures } from "@/lib/predict/features";
import { NotFoundError } from "@/lib/errors";

const patchSchema = z.object({
  // null clears the override and falls back to the model recommendation.
  action: z.enum(["go", "no_bid"]).nullable(),
});

/**
 * Shape of the JSON payload returned to clients. Mirrors WinPrediction +
 * extras for convenience (decoded features/contributions, plus the
 * effective recommendation after override).
 */
interface PredictionResponse {
  rfpId: string;
  probability: number;
  recommendation: string;
  /** Recommendation the UI should *display* — override-aware. */
  effectiveRecommendation: string;
  features: PredictionFeatures | null;
  contributions: Record<string, number> | null;
  modelVersion: string;
  overrideAction: string | null;
  overrideById: string | null;
  overrideAt: string | null;
  createdAt: string;
  updatedAt: string;
}

export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const row = await prisma.winPrediction.findUnique({ where: { rfpId } });
  if (!row) {
    // No prediction yet — return a 404 so the client can render "not yet
    // scored" state instead of confusing the user with a zero-probability
    // placeholder.
    throw new NotFoundError("Prediction not found");
  }
  return Response.json(serialize(row));
});

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId, Role.ADMIN);
  const previous = await prisma.winPrediction.findUnique({
    where: { rfpId },
    select: { recommendation: true },
  });
  const result = await scoreAndPersist(rfpId);
  const row = await prisma.winPrediction.findUnique({ where: { rfpId } });

  void audit({
    event: "WIN_PREDICTION_RESCORED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      probability: result.probability,
      recommendation: result.recommendation,
      previousRecommendation: previous?.recommendation ?? null,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json(serialize(row!));
});

export const PATCH = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId, Role.ADMIN);
  const body = patchSchema.parse(await req.json());

  await applyOverride({ rfpId, action: body.action, userId: user.id });
  const row = await prisma.winPrediction.findUnique({ where: { rfpId } });

  void audit({
    event: "WIN_PREDICTION_OVERRIDDEN",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: { action: body.action },
    ...auditContextFromRequest(req),
  });

  return Response.json(serialize(row!));
});

/**
 * Marshal the WinPrediction Prisma row into the wire shape. We re-export
 * the JSON columns as concrete typed shapes so the client doesn't have to
 * type-narrow `unknown`. Override-aware `effectiveRecommendation` lets the
 * UI render the right badge without re-deriving the precedence rule.
 */
function serialize(
  row: NonNullable<Awaited<ReturnType<typeof prisma.winPrediction.findUnique>>>,
): PredictionResponse {
  const overrideAction = row.overrideAction;
  const effective = overrideAction ?? row.recommendation;
  return {
    rfpId: row.rfpId,
    probability: row.probability,
    recommendation: row.recommendation,
    effectiveRecommendation: effective,
    features: (row.features as unknown as PredictionFeatures) ?? null,
    contributions: (row.contributions as unknown as Record<string, number>) ?? null,
    modelVersion: row.modelVersion,
    overrideAction,
    overrideById: row.overrideById,
    overrideAt: row.overrideAt ? row.overrideAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

// Tests import this convenience type to share the wire-shape assertion.
export type { PredictionResponse };

// Convenience helper used by `service.scoreWithFeaturesUnused` indirection
// guards in tests — exported only to avoid an unused-import lint when the
// route is consumed standalone.
export type { ScoreWithFeatures };
