// Score an RFP's in-progress responses against the stored rubric criteria.
// SSE-streamed so the UI sees per-criterion progress as the LLM works
// through them; the final event carries the full RubricScore payload.

import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { scoreAndPersistRubric } from "@/lib/rubric/service";
import { log } from "@/lib/logger";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);

  const encoder = new TextEncoder();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const send = (event: string, data: unknown) => {
        try {
          controller.enqueue(
            encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
          );
        } catch {
          // controller may be closed if the client disconnected — just ignore
        }
      };
      send("start", { rfpId });

      try {
        const result = await scoreAndPersistRubric(rfpId, {
          onProgress: (s) => {
            send("criterion", s);
          },
        });
        send("done", result);

        void audit({
          event: "RUBRIC_SCORED",
          actorId: user.id,
          organizationId: rfp.project.organizationId,
          targetType: "rfp",
          targetId: rfpId,
          metadata: {
            totalScore: result.totalScore,
            weakestCriteria: result.weakestCriteria,
          },
          ...auditContextFromRequest(req),
        });
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        log().warn({ err: message, rfpId }, "rubric scoring failed");
        send("error", { error: message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
    },
  });
});
