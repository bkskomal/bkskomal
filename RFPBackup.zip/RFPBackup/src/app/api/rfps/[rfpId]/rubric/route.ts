// Evaluation rubric route — extract, view, override, and remove the auto-
// extracted rubric for an RFP.
//
// - GET    members:  current rubric (criteria + scores).
// - POST   members:  (re-)extract from rawText. Idempotent overwrite.
// - PATCH  members:  manual override of criteria (with weights). Clears prior
//                    scores because old criterion ids may have changed.
// - DELETE admins:   remove the rubric entirely.

import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { Role } from "@prisma/client";
import {
  extractAndPersistRubric,
  overrideRubricCriteria,
} from "@/lib/rubric/service";
import type { RubricCriterion } from "@/lib/rubric/extract";

const criterionSchema = z.object({
  id: z.string().min(1).max(80),
  label: z.string().min(1).max(200),
  weight: z.number().min(0).max(1),
  description: z.string().max(2000).default(""),
  mustHave: z.boolean().optional(),
});

const patchSchema = z.object({
  criteria: z.array(criterionSchema).min(1).max(20),
});

export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const rubric = await prisma.evaluationRubric.findUnique({
    where: { rfpId },
  });
  return Response.json({ rubric });
});

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);
  const row = await extractAndPersistRubric(rfpId);

  void audit({
    event: "RUBRIC_EXTRACTED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      criteriaCount: Array.isArray(row.criteria) ? row.criteria.length : 0,
      extractionConfidence: row.extractionConfidence,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ rubric: row });
});

export const PATCH = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);
  const body = patchSchema.parse(await req.json());
  const criteria: RubricCriterion[] = body.criteria.map((c) => ({
    id: c.id,
    label: c.label,
    weight: c.weight,
    description: c.description ?? "",
    mustHave: c.mustHave ?? false,
  }));
  const row = await overrideRubricCriteria(rfpId, criteria);

  void audit({
    event: "RUBRIC_OVERRIDDEN",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: { criteriaCount: criteria.length },
    ...auditContextFromRequest(req),
  });

  return Response.json({ rubric: row });
});

export const DELETE = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  // Admin-only: the rubric is part of the RFP's evaluation trail; once a team
  // has scored against it, deletion is destructive enough to require ADMIN.
  const { user, rfp } = await requireRfpAccess(rfpId, Role.ADMIN);
  await prisma.evaluationRubric.deleteMany({ where: { rfpId } });

  void audit({
    event: "RUBRIC_REMOVED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true });
});
