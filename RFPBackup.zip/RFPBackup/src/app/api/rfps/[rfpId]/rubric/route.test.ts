import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Hoisted mocks for the route's dependencies. We stub:
//   - auth + prisma so requireRfpAccess resolves (or refuses).
//   - the rubric service so the route tests stay narrowly focused on
//     auth/validation/audit — the service has its own tests.
//   - the audit module so we can assert on the emitted event without
//     bringing the real audit log into the test path.
// ---------------------------------------------------------------------------

const { authMock, prismaMock, auditMock, serviceMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  serviceMock: {
    extractAndPersistRubric: vi.fn(),
    overrideRubricCriteria: vi.fn(),
  },
  prismaMock: {
    rFP: { findUnique: vi.fn() },
    membership: { findUnique: vi.fn() },
    evaluationRubric: {
      findUnique: vi.fn(),
      deleteMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});
vi.mock("@/lib/rubric/service", () => ({
  extractAndPersistRubric: (...args: unknown[]) =>
    serviceMock.extractAndPersistRubric(...args),
  overrideRubricCriteria: (...args: unknown[]) =>
    serviceMock.overrideRubricCriteria(...args),
}));

import { GET, POST, PATCH, DELETE } from "./route";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const USER_ID = "user-1";
const ORG_ID = "org-1";
const RFP_ID = "rfp-1";
const session = { user: { id: USER_ID } };

function rfpFixture(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RFP_ID,
    title: "Acme RFP",
    project: { id: "proj-1", organizationId: ORG_ID },
    ...overrides,
  };
}

function jsonRequest(method: string, body?: unknown) {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/rubric`, {
    method,
    headers: { "content-type": "application/json" },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
}

const params = () => ({ params: Promise.resolve({ rfpId: RFP_ID }) });

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.rFP.findUnique.mockResolvedValue(rfpFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  prismaMock.evaluationRubric.findUnique.mockResolvedValue(null);
  prismaMock.evaluationRubric.deleteMany.mockResolvedValue({ count: 1 });
  serviceMock.extractAndPersistRubric.mockResolvedValue({
    rfpId: RFP_ID,
    criteria: [{ id: "tech", label: "Technical", weight: 1, description: "" }],
    extractionConfidence: 0.95,
    totalScore: null,
    perCriterionScores: null,
    scoredAt: null,
  });
  serviceMock.overrideRubricCriteria.mockResolvedValue({
    rfpId: RFP_ID,
    criteria: [],
    extractionConfidence: 1.0,
  });
  auditMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// GET — returns the current rubric (or null).
// ---------------------------------------------------------------------------

describe("GET /api/rfps/:rfpId/rubric", () => {
  it("returns the rubric row when present", async () => {
    prismaMock.evaluationRubric.findUnique.mockResolvedValueOnce({
      rfpId: RFP_ID,
      criteria: [{ id: "x", label: "X", weight: 1, description: "" }],
      extractionConfidence: 0.95,
      totalScore: 0.7,
      perCriterionScores: { x: { criterionId: "x", score: 0.7, rationale: "", evidence: [] } },
      scoredAt: new Date("2026-05-01T00:00:00Z"),
    });
    const res = await GET(jsonRequest("GET"), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.rubric.totalScore).toBe(0.7);
    expect(body.rubric.criteria).toHaveLength(1);
  });

  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await GET(jsonRequest("GET"), params());
    expect(res.status).toBe(401);
  });

  it("returns 403 when caller is not a member of the org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await GET(jsonRequest("GET"), params());
    expect(res.status).toBe(403);
  });
});

// ---------------------------------------------------------------------------
// POST — re-extract the rubric. Audited.
// ---------------------------------------------------------------------------

describe("POST /api/rfps/:rfpId/rubric", () => {
  it("calls the service and audits RUBRIC_EXTRACTED", async () => {
    const res = await POST(jsonRequest("POST"), params());
    expect(res.status).toBe(200);
    expect(serviceMock.extractAndPersistRubric).toHaveBeenCalledWith(RFP_ID);
    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    expect(auditMock.mock.calls[0][0].event).toBe("RUBRIC_EXTRACTED");
  });

  it("returns 403 when caller is not a member", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await POST(jsonRequest("POST"), params());
    expect(res.status).toBe(403);
    expect(serviceMock.extractAndPersistRubric).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// PATCH — manual override. Audited.
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/rubric", () => {
  it("overrides criteria and audits RUBRIC_OVERRIDDEN", async () => {
    const body = {
      criteria: [
        { id: "a", label: "A", weight: 0.5, description: "" },
        { id: "b", label: "B", weight: 0.5, description: "", mustHave: true },
      ],
    };
    const res = await PATCH(jsonRequest("PATCH", body), params());
    expect(res.status).toBe(200);
    expect(serviceMock.overrideRubricCriteria).toHaveBeenCalledTimes(1);
    const passedCriteria = serviceMock.overrideRubricCriteria.mock.calls[0][1];
    expect(passedCriteria).toHaveLength(2);
    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    expect(auditMock.mock.calls[0][0].event).toBe("RUBRIC_OVERRIDDEN");
  });

  it("rejects malformed bodies with 400", async () => {
    const res = await PATCH(jsonRequest("PATCH", { criteria: [] }), params());
    expect(res.status).toBe(400);
    expect(serviceMock.overrideRubricCriteria).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// DELETE — admin-only.
// ---------------------------------------------------------------------------

describe("DELETE /api/rfps/:rfpId/rubric", () => {
  it("removes the rubric when caller is admin", async () => {
    prismaMock.membership.findUnique.mockResolvedValue({
      userId: USER_ID,
      organizationId: ORG_ID,
      role: "ADMIN",
    });
    const res = await DELETE(jsonRequest("DELETE"), params());
    expect(res.status).toBe(200);
    expect(prismaMock.evaluationRubric.deleteMany).toHaveBeenCalledWith({
      where: { rfpId: RFP_ID },
    });
    await new Promise((r) => setImmediate(r));
    expect(auditMock).toHaveBeenCalledTimes(1);
    expect(auditMock.mock.calls[0][0].event).toBe("RUBRIC_REMOVED");
  });

  it("returns 403 when caller is a plain MEMBER", async () => {
    const res = await DELETE(jsonRequest("DELETE"), params());
    expect(res.status).toBe(403);
    expect(prismaMock.evaluationRubric.deleteMany).not.toHaveBeenCalled();
  });
});
