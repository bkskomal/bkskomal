import { z } from "zod";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { mineRfpToIndex } from "@/lib/rfp-mining";
import { ValidationError } from "@/lib/errors";
import { advance as advancePipeline } from "@/lib/pipeline/engine";

const bodySchema = z.object({
  indexId: z.string(),
  approvedOnly: z.boolean().optional(),
});

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const body = bodySchema.parse(await req.json());
  if (!body.indexId) throw new ValidationError("indexId required");
  const result = await mineRfpToIndex(rfpId, body.indexId, { approvedOnly: body.approvedOnly });
  void advancePipeline(rfpId);
  return Response.json(result, { status: 201 });
});
