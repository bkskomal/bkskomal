import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";

// ---------------------------------------------------------------------------
// Mocks. Hoisted helpers so factory closures see them.
// ---------------------------------------------------------------------------

const { authMock, prismaMock, auditMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  auditMock: vi.fn(),
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
      update: vi.fn(),
    },
    membership: {
      findUnique: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

// Spy on the actual audit module (not a full mock) so the contract
// (`audit({event, ...})` is called once per PATCH) is verifiable.
vi.mock("@/lib/audit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/audit")>("@/lib/audit");
  return {
    ...actual,
    audit: (...args: unknown[]) => auditMock(...args),
  };
});

// Import after the mocks bind.
import { GET, PATCH } from "./route";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const USER_ID = "user-1";
const ORG_ID = "org-1";
const RFP_ID = "rfp-1";
const session = { user: { id: USER_ID } };

function buildRfpFixture(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RFP_ID,
    title: "Acme RFP",
    outcome: "PENDING",
    outcomeAt: null,
    outcomeNote: null,
    project: {
      id: "proj-1",
      organizationId: ORG_ID,
    },
    ...overrides,
  };
}

function buildPatchRequest(body: unknown) {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/outcome`, {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

function buildGetRequest() {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/outcome`, { method: "GET" });
}

const params = () => ({ params: Promise.resolve({ rfpId: RFP_ID }) });

beforeEach(() => {
  vi.clearAllMocks();
  authMock.mockResolvedValue(session);
  prismaMock.rFP.findUnique.mockResolvedValue(buildRfpFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  // Default: PATCH update returns the WON shape so happy-path tests don't
  // need to redeclare it.
  prismaMock.rFP.update.mockResolvedValue({
    id: RFP_ID,
    title: "Acme RFP",
    outcome: "WON",
    outcomeAt: new Date("2026-01-15T12:00:00Z"),
    outcomeNote: "Closed-won via direct contract.",
    updatedAt: new Date("2026-01-15T12:00:00Z"),
  });
  auditMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// PATCH — happy path.
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/outcome — happy path", () => {
  it("returns 200 with the updated outcome and persists outcomeAt", async () => {
    const res = await PATCH(
      buildPatchRequest({ outcome: "WON", note: "Closed-won via direct contract." }),
      params(),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.outcome).toBe("WON");
    expect(body.outcomeAt).toBe("2026-01-15T12:00:00.000Z");
    expect(body.outcomeNote).toBe("Closed-won via direct contract.");

    expect(prismaMock.rFP.update).toHaveBeenCalledTimes(1);
    const updateCall = prismaMock.rFP.update.mock.calls[0][0];
    expect(updateCall.where).toEqual({ id: RFP_ID });
    expect(updateCall.data.outcome).toBe("WON");
    expect(updateCall.data.outcomeAt).toBeInstanceOf(Date);
    expect(updateCall.data.outcomeNote).toBe("Closed-won via direct contract.");
  });

  it("clears outcomeAt when outcome is reset to PENDING", async () => {
    prismaMock.rFP.update.mockResolvedValueOnce({
      id: RFP_ID,
      title: "Acme RFP",
      outcome: "PENDING",
      outcomeAt: null,
      outcomeNote: null,
      updatedAt: new Date("2026-02-01T00:00:00Z"),
    });
    const res = await PATCH(buildPatchRequest({ outcome: "PENDING" }), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.outcome).toBe("PENDING");
    expect(body.outcomeAt).toBeNull();

    const updateCall = prismaMock.rFP.update.mock.calls[0][0];
    expect(updateCall.data.outcome).toBe("PENDING");
    expect(updateCall.data.outcomeAt).toBeNull();
  });

  it("audits exactly once per PATCH with the RFP_OUTCOME_SET event", async () => {
    await PATCH(
      buildPatchRequest({ outcome: "LOST", note: "Lost on price." }),
      params(),
    );
    // Audit is fired-and-forgotten inside the route; we yield the loop so
    // the void-promise settles before asserting.
    await new Promise((r) => setImmediate(r));

    expect(auditMock).toHaveBeenCalledTimes(1);
    const auditPayload = auditMock.mock.calls[0][0];
    expect(auditPayload.event).toBe("RFP_OUTCOME_SET");
    expect(auditPayload.actorId).toBe(USER_ID);
    expect(auditPayload.organizationId).toBe(ORG_ID);
    expect(auditPayload.targetId).toBe(RFP_ID);
    expect(auditPayload.metadata).toMatchObject({ outcome: "WON", previousOutcome: "PENDING" });
  });
});

// ---------------------------------------------------------------------------
// PATCH — auth gating.
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/outcome — auth gating", () => {
  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await PATCH(buildPatchRequest({ outcome: "WON" }), params());
    expect(res.status).toBe(401);
    expect(prismaMock.rFP.update).not.toHaveBeenCalled();
  });

  it("returns 403 when the user is not a member of the RFP's org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await PATCH(buildPatchRequest({ outcome: "WON" }), params());
    expect(res.status).toBe(403);
    expect(prismaMock.rFP.update).not.toHaveBeenCalled();
    expect(auditMock).not.toHaveBeenCalled();
  });

  it("returns 404 when the RFP does not exist", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(null);
    const res = await PATCH(buildPatchRequest({ outcome: "WON" }), params());
    expect(res.status).toBe(404);
    expect(prismaMock.rFP.update).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// PATCH — validation.
// ---------------------------------------------------------------------------

describe("PATCH /api/rfps/:rfpId/outcome — validation", () => {
  it("rejects unknown outcome values with 400", async () => {
    const res = await PATCH(buildPatchRequest({ outcome: "MAYBE" }), params());
    expect(res.status).toBe(400);
    expect(prismaMock.rFP.update).not.toHaveBeenCalled();
  });

  it("rejects notes longer than 2000 chars", async () => {
    const note = "x".repeat(2001);
    const res = await PATCH(buildPatchRequest({ outcome: "WON", note }), params());
    expect(res.status).toBe(400);
  });
});

// ---------------------------------------------------------------------------
// GET — current outcome shape.
// ---------------------------------------------------------------------------

describe("GET /api/rfps/:rfpId/outcome", () => {
  it("returns the current outcome and note", async () => {
    prismaMock.rFP.findUnique.mockReset();
    // First call: requireRfpAccess (full include).
    prismaMock.rFP.findUnique.mockResolvedValueOnce(buildRfpFixture());
    // Second call: route's own select.
    prismaMock.rFP.findUnique.mockResolvedValueOnce({
      id: RFP_ID,
      outcome: "LOST",
      outcomeAt: new Date("2026-03-01T00:00:00Z"),
      outcomeNote: "Lost on roadmap fit.",
    });

    const res = await GET(buildGetRequest(), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toEqual({
      rfpId: RFP_ID,
      outcome: "LOST",
      outcomeAt: "2026-03-01T00:00:00.000Z",
      outcomeNote: "Lost on roadmap fit.",
    });
  });

  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await GET(buildGetRequest(), params());
    expect(res.status).toBe(401);
  });
});
