// RFP outcome route — closes the win/loss feedback loop.
//
// PATCH sets a terminal outcome on the RFP (WON / LOST / WITHDRAWN / NO_BID)
// or resets it back to PENDING. The outcome is consumed downstream by
// generation: golden answers tied to past WON RFPs get an additive boost in
// retrieval (see lib/ai/outcome-boost.ts) and LOST-tied answers surface a
// coaching note in the prompt.
//
// GET returns the current outcome shape so the UI chip stays in sync without
// re-fetching the entire RFP detail payload.

import { z } from "zod";
import { RfpOutcome } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { rfpOutcomesTotal } from "@/lib/metrics";
import { slackNotifyOutcomeSet } from "@/lib/integrations/slack-events";
import { scoreAndPersist as scoreAndPersistWinPrediction } from "@/lib/predict/service";
import { log } from "@/lib/logger";

const patchSchema = z.object({
  outcome: z.enum(["PENDING", "WON", "LOST", "WITHDRAWN", "NO_BID"]),
  note: z.string().max(2000).optional(),
});

export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    select: { id: true, outcome: true, outcomeAt: true, outcomeNote: true },
  });
  if (!rfp) {
    return Response.json({ error: "Not found" }, { status: 404 });
  }
  return Response.json({
    rfpId: rfp.id,
    outcome: rfp.outcome,
    outcomeAt: rfp.outcomeAt ? rfp.outcomeAt.toISOString() : null,
    outcomeNote: rfp.outcomeNote,
  });
});

export const PATCH = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp: existing } = await requireRfpAccess(rfpId);
  const body = patchSchema.parse(await req.json());

  // PENDING is the "reset" state — clear the timestamp so the chip reflects
  // "no outcome yet" rather than "decided on date X". Note is still
  // persisted (callers may want to record why the outcome was unset).
  const isPending = body.outcome === "PENDING";
  const updated = await prisma.rFP.update({
    where: { id: rfpId },
    data: {
      outcome: body.outcome as RfpOutcome,
      outcomeAt: isPending ? null : new Date(),
      outcomeNote: body.note ?? null,
    },
    select: {
      id: true,
      title: true,
      outcome: true,
      outcomeAt: true,
      outcomeNote: true,
      updatedAt: true,
    },
  });

  // Telemetry — bump per-outcome counter so dashboards can chart the
  // funnel. Best-effort: never let metrics break the response.
  try {
    rfpOutcomesTotal.inc({ outcome: updated.outcome });
  } catch {
    // ignore
  }

  // Audit. Fire-and-forget — see lib/audit.ts for the contract.
  void audit({
    event: "RFP_OUTCOME_SET",
    actorId: user.id,
    organizationId: existing.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: {
      outcome: updated.outcome,
      previousOutcome: existing.outcome,
      note: body.note ?? null,
    },
    ...auditContextFromRequest(req),
  });

  // Slack notification (Tier B1) — fire-and-forget. No-op when the org has
  // no Slack integration. Skipped when the outcome didn't actually change
  // (e.g. someone re-saving the same value) so the channel doesn't fill up
  // with duplicates.
  if (updated.outcome !== existing.outcome) {
    void slackNotifyOutcomeSet(existing.project.organizationId, {
      rfpTitle: updated.title,
      outcome: updated.outcome,
      setByName: user.name ?? user.email ?? "Someone",
      note: body.note ?? null,
    });
  }

  // Predictive win scoring (Tier C — moonshot). A new WON/LOST outcome on
  // *this* RFP shifts the org's historical win rate AND any "similar RFP"
  // signal anchored on the closed deal's topic. Re-score in-flight RFPs
  // that share a topic so their probabilities reflect the fresh datapoint.
  //
  // Run via setTimeout so the PATCH responds without waiting on the
  // (potentially several) cascading score writes. Errors are swallowed —
  // a stale prediction is much less bad than a 500 on the outcome route.
  if (updated.outcome !== existing.outcome) {
    setTimeout(() => {
      void rescoreRelatedRfps(rfpId, existing.project.organizationId).catch(
        (err) => {
          log().warn(
            { err: err instanceof Error ? err.message : String(err), rfpId },
            "cascade win-prediction rescore failed",
          );
        },
      );
    }, 0);
  }

  // NOTE on activity log: the win/loss outcome is intentionally not written
  // to ActivityEvent here because the ActivityKind enum (in schema.prisma,
  // which is out-of-scope for this iteration) does not yet include a
  // RFP_OUTCOME_SET kind. The audit log above is the durable record;
  // ActivityEvent is a UI-facing convenience and can be retro-filled when
  // the enum is extended.

  return Response.json({
    rfpId: updated.id,
    title: updated.title,
    outcome: updated.outcome,
    outcomeAt: updated.outcomeAt ? updated.outcomeAt.toISOString() : null,
    outcomeNote: updated.outcomeNote,
    updatedAt: updated.updatedAt.toISOString(),
  });
});

/**
 * Cascade re-score: when an outcome flips on `closedRfpId`, find up to 5
 * other in-flight RFPs in the same org whose questions share a topic with
 * the freshly closed one and refresh their WinPrediction rows. The cap is
 * defensive — there's no value in re-scoring an org's entire backlog
 * synchronously when only the freshest deals will be looked at.
 */
async function rescoreRelatedRfps(
  closedRfpId: string,
  organizationId: string,
): Promise<void> {
  // Pick the most-common topic on the closed RFP — same heuristic the
  // feature extractor uses internally so the cascade matches what the
  // scorer would see.
  const questions = await prisma.question.findMany({
    where: { rfpId: closedRfpId },
    select: { topic: true },
  });
  const topicFreq = new Map<string, number>();
  for (const q of questions) {
    const key = q.topic?.trim().toLowerCase();
    if (!key) continue;
    topicFreq.set(key, (topicFreq.get(key) ?? 0) + 1);
  }
  if (topicFreq.size === 0) return;
  const topTopic = [...topicFreq.entries()].sort((a, b) => b[1] - a[1])[0][0];

  // Find at most 5 in-flight RFPs (not WON/LOST/WITHDRAWN/NO_BID) in the
  // same org whose questions overlap on the topic. Excluding the closed
  // RFP itself keeps the cascade from chasing its own tail.
  const candidates = await prisma.rFP.findMany({
    where: {
      project: { organizationId },
      id: { not: closedRfpId },
      outcome: "PENDING",
      questions: {
        some: { topic: { contains: topTopic, mode: "insensitive" } },
      },
    },
    select: { id: true },
    orderBy: { updatedAt: "desc" },
    take: 5,
  });

  for (const c of candidates) {
    try {
      await scoreAndPersistWinPrediction(c.id);
    } catch (err) {
      log().warn(
        { err: err instanceof Error ? err.message : String(err), rfpId: c.id },
        "win prediction rescore failed for related RFP",
      );
    }
  }
}
