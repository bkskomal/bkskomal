import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { ValidationError } from "@/lib/errors";
import { exportRfpToWord } from "@/lib/export/word";
import { logActivity } from "@/lib/activity";
import { advance as advancePipeline } from "@/lib/pipeline/engine";
import { audit, auditContextFromRequest } from "@/lib/audit";

export const GET = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);

  const url = new URL(req.url);
  const format = url.searchParams.get("format") ?? "docx";
  const approvedOnly = url.searchParams.get("approvedOnly") === "1";
  const includeSources = url.searchParams.get("includeSources") !== "0";

  if (format !== "docx") {
    throw new ValidationError(`Unsupported format: ${format}`);
  }

  const { filename, buffer } = await exportRfpToWord(rfpId, { approvedOnly, includeSources });

  void logActivity({
    rfpId,
    actorId: user.id,
    kind: "EXPORT_GENERATED",
    payload: { format, approvedOnly, includeSources, byteSize: buffer.length },
  });
  void advancePipeline(rfpId);

  void audit({
    event: "RFP_EXPORTED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: { format, approvedOnly, includeSources, byteSize: buffer.length, filename },
    ...auditContextFromRequest(req),
  });

  return new Response(new Uint8Array(buffer), {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Content-Length": String(buffer.length),
    },
  });
});
