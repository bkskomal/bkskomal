import { z } from "zod";
import { QuestionStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { logActivity } from "@/lib/activity";
import { advance as advancePipeline } from "@/lib/pipeline/engine";

const bodySchema = z.object({
  questionIds: z.array(z.string()).min(1),
  status: z.nativeEnum(QuestionStatus).optional(),
  assigneeId: z.string().nullable().optional(),
});

export const PATCH = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);
  const body = bodySchema.parse(await req.json());

  // Constrain to questions actually on this RFP — defensive.
  const owned = await prisma.question.findMany({
    where: { id: { in: body.questionIds }, rfpId },
    select: { id: true },
  });
  const ownedIds = owned.map((q) => q.id);
  if (ownedIds.length === 0) return Response.json({ updated: 0 });

  await prisma.question.updateMany({
    where: { id: { in: ownedIds } },
    data: {
      ...(body.status !== undefined ? { status: body.status } : {}),
      ...(body.assigneeId !== undefined ? { assigneeId: body.assigneeId } : {}),
    },
  });

  void logActivity({
    rfpId,
    actorId: user.id,
    kind: body.status ? "QUESTION_STATUS_CHANGED" : "QUESTION_ASSIGNED",
    payload: { count: ownedIds.length, status: body.status, assigneeId: body.assigneeId, bulk: true },
  });

  void advancePipeline(rfpId);
  return Response.json({ updated: ownedIds.length });
});
