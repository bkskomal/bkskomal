import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";
import { _resetForTests, _setNowForTests } from "@/lib/rate-limit";

// ---------------------------------------------------------------------------
// Mocks. Hoisted helpers so factory closures see them.
// ---------------------------------------------------------------------------

const { authMock, runBulkGenerationMock, prismaMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  runBulkGenerationMock: vi.fn(),
  prismaMock: {
    rFP: {
      findUnique: vi.fn(),
    },
    membership: {
      findUnique: vi.fn(),
    },
    question: {
      findMany: vi.fn(),
    },
    bulkGeneration: {
      create: vi.fn(),
      findMany: vi.fn(),
    },
  },
}));

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/ai/bulk-generate", () => ({
  runBulkGeneration: (...args: unknown[]) => runBulkGenerationMock(...args),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

// Import after mocks bind.
import { POST, GET } from "./route";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const USER_ID = "user-1";
const ORG_ID = "org-1";
const RFP_ID = "rfp-1";

const session = { user: { id: USER_ID } };

function buildRfpFixture(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: RFP_ID,
    title: "Acme RFP",
    project: {
      id: "proj-1",
      organizationId: ORG_ID,
      defaultIndexId: null,
    },
    ...overrides,
  };
}

function buildRequest(body: unknown) {
  return new NextRequest(`http://x/api/rfps/${RFP_ID}/bulk-generate`, {
    method: "POST",
    body: JSON.stringify(body),
    headers: { "Content-Type": "application/json" },
  });
}

const params = () => ({ params: Promise.resolve({ rfpId: RFP_ID }) });

// ---------------------------------------------------------------------------
// Per-test reset.
// ---------------------------------------------------------------------------

beforeEach(() => {
  _resetForTests();
  vi.clearAllMocks();

  authMock.mockResolvedValue(session);
  prismaMock.rFP.findUnique.mockResolvedValue(buildRfpFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  prismaMock.question.findMany.mockResolvedValue([
    { id: "q1", confidence: null, responses: [] },
    { id: "q2", confidence: null, responses: [] },
  ]);
  prismaMock.bulkGeneration.create.mockResolvedValue({
    id: "bulk-1",
    rfpId: RFP_ID,
    questionIds: ["q1", "q2"],
    total: 2,
    status: "PENDING",
  });
  prismaMock.bulkGeneration.findMany.mockResolvedValue([]);
  runBulkGenerationMock.mockResolvedValue(undefined);
});

// ---------------------------------------------------------------------------
// Tests.
// ---------------------------------------------------------------------------

describe("POST /api/rfps/:rfpId/bulk-generate — auth gating", () => {
  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await POST(buildRequest({ mode: "unanswered" }), params());
    expect(res.status).toBe(401);
    expect(runBulkGenerationMock).not.toHaveBeenCalled();
  });

  it("returns 404 when RFP does not exist", async () => {
    prismaMock.rFP.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest({ mode: "unanswered" }), params());
    expect(res.status).toBe(404);
    expect(runBulkGenerationMock).not.toHaveBeenCalled();
  });

  it("returns 403 when user is not a member of the owning org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest({ mode: "unanswered" }), params());
    expect(res.status).toBe(403);
    expect(runBulkGenerationMock).not.toHaveBeenCalled();
  });
});

describe("POST /api/rfps/:rfpId/bulk-generate — happy path", () => {
  it("returns 201 with the bulk row, creates the BulkGeneration, and kicks off the worker", async () => {
    const res = await POST(buildRequest({ mode: "unanswered" }), params());
    expect(res.status).toBe(201);
    const body = await res.json();
    expect(body.bulk).toMatchObject({ id: "bulk-1", rfpId: RFP_ID });

    expect(prismaMock.bulkGeneration.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({
          rfpId: RFP_ID,
          startedById: USER_ID,
          questionIds: ["q1", "q2"],
          total: 2,
        }),
      }),
    );
    expect(runBulkGenerationMock).toHaveBeenCalledWith({ bulkId: "bulk-1" });
  });

  it('mode: "selected" only schedules the questions the user owns on the RFP', async () => {
    prismaMock.question.findMany.mockResolvedValueOnce([{ id: "q2" }]);
    prismaMock.bulkGeneration.create.mockResolvedValueOnce({
      id: "bulk-2",
      rfpId: RFP_ID,
      questionIds: ["q2"],
      total: 1,
    });
    const res = await POST(
      buildRequest({ mode: "selected", questionIds: ["q2", "q-not-mine"] }),
      params(),
    );
    expect(res.status).toBe(201);
    expect(prismaMock.bulkGeneration.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ questionIds: ["q2"], total: 1 }),
      }),
    );
  });

  it('mode: "low_confidence" filters to questions with confidence < 0.55', async () => {
    prismaMock.question.findMany.mockResolvedValueOnce([
      { id: "q1", confidence: 0.9, responses: [] },
      { id: "q2", confidence: 0.4, responses: [] },
      { id: "q3", confidence: null, responses: [] },
    ]);
    prismaMock.bulkGeneration.create.mockResolvedValueOnce({
      id: "bulk-3",
      questionIds: ["q2"],
      total: 1,
    });
    const res = await POST(buildRequest({ mode: "low_confidence" }), params());
    expect(res.status).toBe(201);
    expect(prismaMock.bulkGeneration.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ questionIds: ["q2"] }),
      }),
    );
  });
});

describe("POST /api/rfps/:rfpId/bulk-generate — validation", () => {
  it("returns 400 when the body fails schema validation", async () => {
    const res = await POST(buildRequest({ mode: "not-a-valid-mode" }), params());
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.code).toBe("validation_error");
    expect(runBulkGenerationMock).not.toHaveBeenCalled();
  });

  it('returns 400 when mode is "selected" but questionIds is missing', async () => {
    const res = await POST(buildRequest({ mode: "selected" }), params());
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.code).toBe("validation_error");
    expect(body.error).toMatch(/questionIds required/i);
  });

  it("returns 400 when no questions match the selected mode", async () => {
    prismaMock.question.findMany.mockResolvedValueOnce([]);
    const res = await POST(buildRequest({ mode: "all" }), params());
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.code).toBe("validation_error");
    expect(body.error).toMatch(/No questions match/i);
    expect(runBulkGenerationMock).not.toHaveBeenCalled();
  });
});

describe("POST /api/rfps/:rfpId/bulk-generate — rate limiting", () => {
  it("returns 429 with Retry-After + retryAfterSeconds once the bulkStart bucket drains", async () => {
    _setNowForTests(() => 1_700_000_000_000);

    // bulkStart capacity is 5 org-scoped tokens; burst past it.
    const N = 8;
    const statuses: number[] = [];
    let rateLimited: Response | null = null;
    for (let i = 0; i < N; i++) {
      const res = await POST(buildRequest({ mode: "unanswered" }), params());
      statuses.push(res.status);
      if (res.status === 429 && !rateLimited) rateLimited = res;
    }

    expect(statuses).toContain(429);
    expect(rateLimited).not.toBeNull();
    expect(rateLimited!.headers.get("Retry-After")).toBeTruthy();
    const body = await rateLimited!.json();
    expect(body).toMatchObject({
      code: "rate_limited",
      retryAfterSeconds: expect.any(Number),
    });
    expect(body.retryAfterSeconds).toBeGreaterThan(0);
  });
});

describe("POST /api/rfps/:rfpId/bulk-generate — error propagation", () => {
  it("returns 500 when the BulkGeneration row cannot be created", async () => {
    prismaMock.bulkGeneration.create.mockRejectedValueOnce(new Error("DB exploded"));
    const res = await POST(buildRequest({ mode: "unanswered" }), params());
    expect(res.status).toBe(500);
    expect(runBulkGenerationMock).not.toHaveBeenCalled();
  });

  it("a synchronous throw from runBulkGeneration is swallowed; response is still 201", async () => {
    // runBulkGeneration is fire-and-forget under .catch — verify the route
    // doesn't propagate that into the user response.
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});
    runBulkGenerationMock.mockRejectedValueOnce(new Error("worker crashed"));
    const res = await POST(buildRequest({ mode: "unanswered" }), params());
    expect(res.status).toBe(201);
    await new Promise((r) => setImmediate(r));
    expect(consoleSpy).toHaveBeenCalled();
    consoleSpy.mockRestore();
  });
});

describe("GET /api/rfps/:rfpId/bulk-generate", () => {
  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const req = new NextRequest(`http://x/api/rfps/${RFP_ID}/bulk-generate`);
    const res = await GET(req, params());
    expect(res.status).toBe(401);
  });

  it("returns the 10 most-recent runs for the rfp", async () => {
    prismaMock.bulkGeneration.findMany.mockResolvedValueOnce([
      { id: "bulk-99", status: "COMPLETED" },
      { id: "bulk-98", status: "RUNNING" },
    ]);
    const req = new NextRequest(`http://x/api/rfps/${RFP_ID}/bulk-generate`);
    const res = await GET(req, params());
    expect(res.status).toBe(200);
    expect(await res.json()).toEqual({
      runs: [
        { id: "bulk-99", status: "COMPLETED" },
        { id: "bulk-98", status: "RUNNING" },
      ],
    });
    expect(prismaMock.bulkGeneration.findMany).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { rfpId: RFP_ID },
        take: 10,
        orderBy: { startedAt: "desc" },
      }),
    );
  });
});
