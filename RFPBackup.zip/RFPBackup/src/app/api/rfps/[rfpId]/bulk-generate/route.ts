import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess } from "@/lib/authz";
import { ValidationError } from "@/lib/errors";
import { runBulkGeneration } from "@/lib/ai/bulk-generate";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

const bodySchema = z.object({
  // Mode: "all" generates for everything, "unanswered" skips questions that
  // already have a COMPLETED response, "low_confidence" only those below 0.55,
  // "selected" uses the explicit ids list.
  mode: z.enum(["all", "unanswered", "low_confidence", "selected"]).default("unanswered"),
  questionIds: z.array(z.string()).optional(),
  indexId: z.string().nullable().optional(),
  enableTools: z.boolean().optional(),
});

export const POST = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { user, rfp } = await requireRfpAccess(rfpId);
  await rateLimit(RATE_LIMITS.bulkStart, {
    userId: user.id,
    orgId: rfp.project.organizationId,
    route: "rfps/bulk-generate",
  });
  const body = bodySchema.parse(await req.json());

  // Resolve the question set based on mode.
  let questionIds: string[];
  if (body.mode === "selected") {
    if (!body.questionIds?.length) throw new ValidationError("questionIds required for 'selected' mode");
    const owned = await prisma.question.findMany({
      where: { id: { in: body.questionIds }, rfpId },
      select: { id: true },
    });
    questionIds = owned.map((q) => q.id);
  } else {
    const all = await prisma.question.findMany({
      where: { rfpId },
      orderBy: { number: "asc" },
      select: { id: true, confidence: true, responses: { select: { status: true }, orderBy: { createdAt: "desc" }, take: 1 } },
    });
    if (body.mode === "all") {
      questionIds = all.map((q) => q.id);
    } else if (body.mode === "unanswered") {
      questionIds = all
        .filter((q) => q.responses.length === 0 || q.responses[0]?.status !== "COMPLETED")
        .map((q) => q.id);
    } else {
      // low_confidence
      questionIds = all
        .filter((q) => typeof q.confidence === "number" && q.confidence < 0.55)
        .map((q) => q.id);
    }
  }

  if (questionIds.length === 0) {
    throw new ValidationError("No questions match the selected mode");
  }

  const indexId = body.indexId ?? rfp.project.defaultIndexId ?? null;

  const bulk = await prisma.bulkGeneration.create({
    data: {
      rfpId,
      startedById: user.id,
      questionIds,
      indexId,
      enableTools: body.enableTools !== false,
      total: questionIds.length,
    },
  });

  // Fire-and-forget; client polls /status.
  runBulkGeneration({ bulkId: bulk.id }).catch((e) => console.error("[bulk]", e));

  return Response.json({ bulk }, { status: 201 });
});

export const GET = withApiHandler<{ rfpId: string }>(async (_req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const runs = await prisma.bulkGeneration.findMany({
    where: { rfpId },
    orderBy: { startedAt: "desc" },
    take: 10,
  });
  return Response.json({ runs });
});
