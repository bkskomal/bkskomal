import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireRfpAccess, requireRfpAccessForRequest } from "@/lib/authz";
import { deleteUpload } from "@/lib/storage";
import { audit, auditContextFromRequest } from "@/lib/audit";

export const GET = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  // Accept either a session cookie OR a Bearer API key with READ scope.
  await requireRfpAccessForRequest(req, rfpId);
  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: {
      project: {
        include: {
          organization: { select: { id: true, name: true, slug: true } },
          defaultIndex: true,
        },
      },
      questions: {
        orderBy: { number: "asc" },
        include: {
          responses: {
            orderBy: { createdAt: "desc" },
            include: { sources: true, index: { select: { id: true, name: true } } },
          },
        },
      },
    },
  });
  return Response.json({ rfp });
});

const patchSchema = z.object({
  title: z.string().min(1).max(200).optional(),
  description: z.string().max(2000).nullable().optional(),
  dueDate: z.string().datetime().nullable().optional(),
});

export const PATCH = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  await requireRfpAccess(rfpId);
  const body = patchSchema.parse(await req.json());
  const rfp = await prisma.rFP.update({
    where: { id: rfpId },
    data: {
      ...(body.title !== undefined ? { title: body.title } : {}),
      ...(body.description !== undefined ? { description: body.description } : {}),
      ...(body.dueDate !== undefined
        ? { dueDate: body.dueDate === null ? null : new Date(body.dueDate) }
        : {}),
    },
  });
  return Response.json({ rfp });
});

export const DELETE = withApiHandler<{ rfpId: string }>(async (req, { params }) => {
  const { rfpId } = await params;
  const { rfp, user } = await requireRfpAccess(rfpId);
  await prisma.rFP.delete({ where: { id: rfpId } });
  await deleteUpload(rfp.storagePath);

  void audit({
    event: "RFP_DELETED",
    actorId: user.id,
    organizationId: rfp.project.organizationId,
    targetType: "rfp",
    targetId: rfpId,
    metadata: { title: rfp.title, projectId: rfp.projectId },
    ...auditContextFromRequest(req),
  });

  return Response.json({ ok: true });
});
