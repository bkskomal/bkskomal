// Static provider catalog for the new provider-cards picker. Returns the
// `ProviderDef[]` shape (lowercase ids, recommendedModels, isLocal, etc.).
//
// Unauthenticated by design — this is purely public configuration metadata
// used by the Settings UI to render the provider picker.

import { withApiHandler } from "@/lib/api-handler";
import { PROVIDER_DEFS, defaultProvider } from "@/lib/ai/providers";

export const GET = withApiHandler(async () => {
  return Response.json({
    providers: PROVIDER_DEFS,
    default: defaultProvider().id,
  });
});
