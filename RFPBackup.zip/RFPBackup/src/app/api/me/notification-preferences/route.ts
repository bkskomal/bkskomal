import { z } from "zod";
import { NotificationChannel, NotificationKind } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { getEffectivePreferences } from "@/lib/notifications/preferences";
import { NOTIFICATION_KIND_META } from "@/lib/notifications/types";

export const GET = withApiHandler(async () => {
  const user = await requireUser();
  const prefs = await getEffectivePreferences(user.id);
  return Response.json({
    preferences: prefs,
    meta: NOTIFICATION_KIND_META,
  });
});

const putSchema = z.object({
  changes: z.array(
    z.object({
      kind: z.nativeEnum(NotificationKind),
      channel: z.nativeEnum(NotificationChannel),
      enabled: z.boolean(),
    }),
  ),
});

export const PUT = withApiHandler(async (req) => {
  const user = await requireUser();
  const { changes } = putSchema.parse(await req.json());

  // Upsert each change. We could batch with a single SQL statement but the
  // change set is small (12 cells max) so this is fine.
  await Promise.all(
    changes.map((c) =>
      prisma.notificationPreference.upsert({
        where: { userId_kind_channel: { userId: user.id, kind: c.kind, channel: c.channel } },
        update: { enabled: c.enabled },
        create: { userId: user.id, kind: c.kind, channel: c.channel, enabled: c.enabled },
      }),
    ),
  );

  return Response.json({ preferences: await getEffectivePreferences(user.id) });
});
