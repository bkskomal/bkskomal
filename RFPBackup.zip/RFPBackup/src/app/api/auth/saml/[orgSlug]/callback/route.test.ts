import { describe, it, expect, vi, beforeEach } from "vitest";

// Hoisted mock state — vitest's vi.mock factory hoists; we put state in
// module-level constants and reach back into them via getters.
vi.mock("@/lib/prisma", () => ({
  prisma: {
    organization: { findUnique: vi.fn() },
    samlConfig: { findUnique: vi.fn() },
    user: { upsert: vi.fn() },
    membership: { upsert: vi.fn() },
    session: { create: vi.fn() },
    auditLog: { create: vi.fn() },
  },
}));

vi.mock("@/lib/saml/service-provider", async () => {
  const sp = {
    parseLoginResponse: vi.fn(),
  };
  return {
    buildSp: vi.fn(() => sp),
    consumeSamlResponse: vi.fn(),
    __sp: sp,
  };
});

import { prisma } from "@/lib/prisma";
import { POST } from "./route";
import * as serviceProvider from "@/lib/saml/service-provider";

type MockedFn = ReturnType<typeof vi.fn>;
const orgFindUnique = prisma.organization.findUnique as unknown as MockedFn;
const samlFindUnique = prisma.samlConfig.findUnique as unknown as MockedFn;
const userUpsert = prisma.user.upsert as unknown as MockedFn;
const membershipUpsert = prisma.membership.upsert as unknown as MockedFn;
const sessionCreate = prisma.session.create as unknown as MockedFn;
const auditCreate = prisma.auditLog.create as unknown as MockedFn;
const consumeSamlResponseMock =
  serviceProvider.consumeSamlResponse as unknown as MockedFn;

function makeFormDataRequest(samlResponse: string | null): Request {
  const fd = new FormData();
  if (samlResponse !== null) fd.set("SAMLResponse", samlResponse);
  return new Request("https://app.example.com/api/auth/saml/acme/callback", {
    method: "POST",
    body: fd,
  });
}

beforeEach(() => {
  orgFindUnique.mockReset();
  samlFindUnique.mockReset();
  userUpsert.mockReset();
  membershipUpsert.mockReset();
  sessionCreate.mockReset();
  auditCreate.mockReset();
  consumeSamlResponseMock.mockReset();

  // Default DB stubs for the happy path.
  orgFindUnique.mockResolvedValue({ id: "org-1", slug: "acme" });
  samlFindUnique.mockResolvedValue({
    organizationId: "org-1",
    idpEntityId: "https://idp",
    idpSsoUrl: "https://idp/sso",
    idpCertificate: "cert",
    spEntityId: "sp",
    attributeMappings: {
      email: "email",
      name: "name",
      groups: "groups",
      externalId: "externalId",
    },
    enforced: false,
    enabled: true,
  });
  userUpsert.mockResolvedValue({ id: "user-1", email: "bob@example.com" });
  membershipUpsert.mockResolvedValue({
    id: "m-1",
    userId: "user-1",
    organizationId: "org-1",
  });
  sessionCreate.mockResolvedValue({ id: "s-1", sessionToken: "token" });
  auditCreate.mockResolvedValue({ id: "audit-1" });
});

async function callRoute(req: Request, slug = "acme") {
  return POST(req as never, { params: Promise.resolve({ orgSlug: slug }) });
}

describe("POST /api/auth/saml/[orgSlug]/callback", () => {
  it("creates user + membership + session on a valid assertion", async () => {
    consumeSamlResponseMock.mockResolvedValueOnce({
      email: "bob@example.com",
      name: "Bob",
      externalId: "bob-1",
      groups: ["eng"],
    });
    const res = await callRoute(makeFormDataRequest("ENCODED_SAML"));
    // The route 302-redirects to /dashboard on success.
    expect(res.status).toBe(302);
    expect(userUpsert).toHaveBeenCalledTimes(1);
    expect(membershipUpsert).toHaveBeenCalledTimes(1);
    expect(sessionCreate).toHaveBeenCalledTimes(1);
    // Session cookie must be set.
    const cookies = res.headers.get("set-cookie") ?? "";
    expect(cookies).toMatch(/authjs\.session-token=/);
  });

  it("fires a SAML_SIGN_IN audit row on success", async () => {
    consumeSamlResponseMock.mockResolvedValueOnce({
      email: "bob@example.com",
      externalId: "bob-1",
    });
    await callRoute(makeFormDataRequest("ENCODED"));
    // audit() is fire-and-forget; await a microtask so the floating promise
    // settles before we assert.
    await new Promise((r) => setImmediate(r));
    expect(auditCreate).toHaveBeenCalledTimes(1);
    const arg = auditCreate.mock.calls[0][0];
    expect(arg.data.event).toBe("SAML_SIGN_IN");
    expect(arg.data.organizationId).toBe("org-1");
    expect(arg.data.actorId).toBe("user-1");
  });

  it("returns 401 when consumeSamlResponse throws a signature error", async () => {
    consumeSamlResponseMock.mockRejectedValueOnce(
      new Error("Signature mismatch on assertion"),
    );
    const res = await callRoute(makeFormDataRequest("TAMPERED"));
    expect(res.status).toBe(401);
    const body = await res.json();
    expect(body.error).toMatch(/signature/i);
    expect(sessionCreate).not.toHaveBeenCalled();
  });

  it("returns 400 when SAMLResponse is missing from the form body", async () => {
    const res = await callRoute(makeFormDataRequest(null));
    expect(res.status).toBe(400);
    expect(consumeSamlResponseMock).not.toHaveBeenCalled();
  });

  it("returns 404 when the org slug is unknown", async () => {
    orgFindUnique.mockResolvedValueOnce(null);
    const res = await callRoute(makeFormDataRequest("X"), "ghost");
    expect(res.status).toBe(404);
  });

  it("returns 404 when SAML is not configured for the org", async () => {
    samlFindUnique.mockResolvedValueOnce(null);
    const res = await callRoute(makeFormDataRequest("X"));
    expect(res.status).toBe(404);
  });
});
