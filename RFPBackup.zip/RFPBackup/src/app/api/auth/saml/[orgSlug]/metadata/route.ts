// Returns SP metadata XML for the IdP admin to upload. Identifies our
// ACS endpoint and entity ID. Unauthenticated — these values are public
// by SAML's design (the trust boundary is the certificate exchange).

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { loadSamlConfigForOrg } from "@/lib/saml/config";
import { buildSpMetadata } from "@/lib/saml/service-provider";

function callbackUrlFor(req: NextRequest, slug: string): string {
  let urlProto = "http";
  let urlHost = "localhost";
  try {
    const u = new URL(req.url);
    urlProto = u.protocol.replace(":", "");
    urlHost = u.host;
  } catch {
    /* fallthrough */
  }
  const proto = req.headers.get("x-forwarded-proto") ?? urlProto;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? urlHost;
  return `${proto}://${host}/api/auth/saml/${encodeURIComponent(slug)}/callback`;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ orgSlug: string }> },
) {
  const { orgSlug } = await params;
  const org = await prisma.organization.findUnique({ where: { slug: orgSlug } });
  if (!org) {
    return NextResponse.json({ error: "Organization not found" }, { status: 404 });
  }
  const config = await loadSamlConfigForOrg(org.id);
  if (!config) {
    return NextResponse.json({ error: "SAML not configured for this org" }, { status: 404 });
  }
  try {
    const callback = callbackUrlFor(req, orgSlug);
    const xml = buildSpMetadata(config, callback);
    return new NextResponse(xml, {
      status: 200,
      headers: {
        "content-type": "application/samlmetadata+xml; charset=utf-8",
        "content-disposition": `attachment; filename="autorfp-sp-metadata-${orgSlug}.xml"`,
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : "metadata error" },
      { status: 500 },
    );
  }
}
