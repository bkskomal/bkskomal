// SAML ACS (Assertion Consumer Service). The IdP POSTs the signed
// SAMLResponse here. We:
//   1. Validate the signature against the org's stored IdP cert.
//   2. Extract email / name / externalId / groups via attributeMappings.
//   3. Upsert the User row.
//   4. Ensure a Membership in this org (auto-create as MEMBER if missing —
//      auto-provisioning is the whole point of SAML SSO).
//   5. Issue a NextAuth session cookie directly (PrismaAdapter session table).
//   6. Audit + bump the metric, then redirect to /dashboard.
//
// On failure: bump the metric with the corresponding `result` label, emit a
// 401/500, and let the user retry. We don't redirect on failure — surfacing
// the error JSON makes debugging an IdP misconfiguration much faster.

import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { Role } from "@prisma/client";
import { loadSamlConfigForOrg } from "@/lib/saml/config";
import { buildSp, consumeSamlResponse } from "@/lib/saml/service-provider";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { samlLoginsTotal } from "@/lib/metrics";
import { log } from "@/lib/logger";

function callbackUrlFor(req: NextRequest, slug: string): string {
  // `req.nextUrl` is missing when tests pass a plain Request — fall back to
  // parsing the URL string. Header overrides still win because that's how
  // we run behind a reverse proxy.
  let urlProto = "http";
  let urlHost = "localhost";
  try {
    const u = new URL(req.url);
    urlProto = u.protocol.replace(":", "");
    urlHost = u.host;
  } catch {
    /* fallthrough to defaults */
  }
  const proto = req.headers.get("x-forwarded-proto") ?? urlProto;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? urlHost;
  return `${proto}://${host}/api/auth/saml/${encodeURIComponent(slug)}/callback`;
}

function isCertError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message.toLowerCase() : String(err).toLowerCase();
  return (
    msg.includes("signature") ||
    msg.includes("certificate") ||
    msg.includes("digest") ||
    msg.includes("cert") ||
    msg.includes("invalid")
  );
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ orgSlug: string }> },
) {
  const { orgSlug } = await params;
  const org = await prisma.organization.findUnique({ where: { slug: orgSlug } });
  if (!org) {
    samlLoginsTotal.inc({ org: orgSlug, result: "other_error" });
    return NextResponse.json({ error: "Organization not found" }, { status: 404 });
  }

  const config = await loadSamlConfigForOrg(org.id);
  if (!config) {
    samlLoginsTotal.inc({ org: org.id, result: "other_error" });
    return NextResponse.json({ error: "SAML not configured" }, { status: 404 });
  }

  let samlResponseB64: string;
  try {
    const fd = await req.formData();
    const v = fd.get("SAMLResponse");
    if (typeof v !== "string" || !v) {
      samlLoginsTotal.inc({ org: org.id, result: "other_error" });
      return NextResponse.json({ error: "Missing SAMLResponse" }, { status: 400 });
    }
    samlResponseB64 = v;
  } catch {
    samlLoginsTotal.inc({ org: org.id, result: "other_error" });
    return NextResponse.json({ error: "Bad request body" }, { status: 400 });
  }

  // Parse + validate the assertion.
  let principal: { email: string; name?: string; externalId?: string; groups?: string[] };
  try {
    const callback = callbackUrlFor(req, orgSlug);
    const sp = buildSp(config, callback);
    principal = await consumeSamlResponse(config, sp, samlResponseB64);
  } catch (e) {
    const certErr = isCertError(e);
    samlLoginsTotal.inc({
      org: org.id,
      result: certErr ? "cert_invalid" : "other_error",
    });
    log().warn(
      { err: { message: e instanceof Error ? e.message : String(e) }, orgId: org.id },
      "saml assertion validation failed",
    );
    return NextResponse.json(
      { error: certErr ? "SAML signature invalid" : "SAML assertion invalid" },
      { status: 401 },
    );
  }

  try {
    const user = await prisma.user.upsert({
      where: { email: principal.email },
      update: {
        name: principal.name ?? undefined,
        emailVerified: new Date(),
      },
      create: {
        email: principal.email,
        name: principal.name ?? principal.email.split("@")[0],
        emailVerified: new Date(),
      },
    });

    // Auto-provision membership. This is the SAML JIT-provisioning contract:
    // anyone who can produce a valid IdP assertion for an org becomes a
    // MEMBER of that org. Admins/owners must still be granted explicitly.
    await prisma.membership.upsert({
      where: { userId_organizationId: { userId: user.id, organizationId: org.id } },
      update: {},
      create: { userId: user.id, organizationId: org.id, role: Role.MEMBER },
    });

    // Issue a NextAuth-compatible session cookie. Mirrors what
    // /api/auth/dev does: insert a Session row and set the cookie that
    // PrismaAdapter expects.
    const sessionToken = randomBytes(32).toString("hex");
    const expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await prisma.session.create({
      data: { sessionToken, userId: user.id, expires },
    });

    samlLoginsTotal.inc({ org: org.id, result: "ok" });
    void audit({
      event: "SAML_SIGN_IN",
      actorId: user.id,
      organizationId: org.id,
      targetType: "user",
      targetId: user.id,
      metadata: {
        email: user.email,
        idpEntityId: config.idpEntityId,
        externalId: principal.externalId,
        groups: principal.groups,
      },
      ...auditContextFromRequest(req),
    });

    let urlProto = "http";
    let urlHost = "localhost";
    try {
      const u = new URL(req.url);
      urlProto = u.protocol.replace(":", "");
      urlHost = u.host;
    } catch {
      /* fallthrough */
    }
    const proto = req.headers.get("x-forwarded-proto") ?? urlProto;
    const host =
      req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? urlHost;
    const dest = `${proto}://${host}/dashboard`;
    const res = NextResponse.redirect(dest, 302);
    res.headers.append(
      "Set-Cookie",
      [
        `authjs.session-token=${sessionToken}`,
        `Path=/`,
        `HttpOnly`,
        `SameSite=Lax`,
        `Expires=${expires.toUTCString()}`,
      ].join("; "),
    );
    return res;
  } catch (e) {
    samlLoginsTotal.inc({ org: org.id, result: "other_error" });
    log().error(
      { err: { message: e instanceof Error ? e.message : String(e) }, orgId: org.id },
      "saml callback post-validation failure",
    );
    return NextResponse.json({ error: "SAML callback failed" }, { status: 500 });
  }
}
