// Kick off a SAML SSO flow: redirect the browser to the IdP with a
// SAMLRequest. Identified by org slug (not id) so users can sign in without
// having a session yet — the slug is public/shareable, the id is internal.

import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { loadSamlConfigForOrg } from "@/lib/saml/config";
import { buildLoginRedirect } from "@/lib/saml/service-provider";
import { log } from "@/lib/logger";

function callbackUrlFor(req: NextRequest, slug: string): string {
  let urlProto = "http";
  let urlHost = "localhost";
  try {
    const u = new URL(req.url);
    urlProto = u.protocol.replace(":", "");
    urlHost = u.host;
  } catch {
    /* fallthrough */
  }
  const proto = req.headers.get("x-forwarded-proto") ?? urlProto;
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? urlHost;
  return `${proto}://${host}/api/auth/saml/${encodeURIComponent(slug)}/callback`;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ orgSlug: string }> },
) {
  const { orgSlug } = await params;

  const org = await prisma.organization.findUnique({ where: { slug: orgSlug } });
  if (!org) {
    return NextResponse.json({ error: "Organization not found" }, { status: 404 });
  }
  const config = await loadSamlConfigForOrg(org.id);
  if (!config) {
    return NextResponse.json({ error: "SAML not configured for this org" }, { status: 404 });
  }

  try {
    const callback = callbackUrlFor(req, orgSlug);
    const { url } = buildLoginRedirect(config, callback);
    return NextResponse.redirect(url, 302);
  } catch (e) {
    log().error(
      { err: { message: e instanceof Error ? e.message : String(e) }, orgId: org.id },
      "saml login redirect failed",
    );
    return NextResponse.json({ error: "SAML configuration error" }, { status: 500 });
  }
}
