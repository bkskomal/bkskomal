// Dev sign-in API. Enabled when NODE_ENV=development OR ENABLE_DEV_AUTH=1.
// Used by the /auth/dev page and as a CLI smoke-test entrypoint.

import { NextRequest } from "next/server";
import { z } from "zod";
import { randomBytes } from "node:crypto";
import { prisma } from "@/lib/prisma";
import { jsonError } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";

const bodySchema = z.object({
  email: z.string().email(),
  name: z.string().optional(),
});

function devAuthEnabled(): boolean {
  return process.env.NODE_ENV === "development" || process.env.ENABLE_DEV_AUTH === "1";
}

export async function POST(req: NextRequest) {
  if (!devAuthEnabled()) {
    return Response.json({ error: "Dev sign-in is disabled" }, { status: 403 });
  }
  try {
    let payload: { email: string; name?: string };
    const ct = req.headers.get("content-type") ?? "";
    if (ct.includes("application/json")) {
      payload = bodySchema.parse(await req.json());
    } else {
      const fd = await req.formData();
      payload = bodySchema.parse({
        email: fd.get("email"),
        name: fd.get("name") ?? undefined,
      });
    }

    const email = payload.email.trim().toLowerCase();
    const name = (payload.name ?? "").trim() || email.split("@")[0];

    const user = await prisma.user.upsert({
      where: { email },
      update: { name, emailVerified: new Date() },
      create: { email, name, emailVerified: new Date() },
    });

    const sessionToken = randomBytes(32).toString("hex");
    const expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    await prisma.session.create({
      data: { sessionToken, userId: user.id, expires },
    });

    const res = Response.json({ ok: true, userId: user.id, email: user.email });
    res.headers.append(
      "Set-Cookie",
      [
        `authjs.session-token=${sessionToken}`,
        `Path=/`,
        `HttpOnly`,
        `SameSite=Lax`,
        `Expires=${expires.toUTCString()}`,
      ].join("; "),
    );

    void audit({
      event: "USER_SIGNED_IN",
      actorId: user.id,
      organizationId: null,
      targetType: "user",
      targetId: user.id,
      metadata: { method: "dev", email: user.email },
      ...auditContextFromRequest(req),
    });

    return res;
  } catch (e) {
    return jsonError(e);
  }
}
