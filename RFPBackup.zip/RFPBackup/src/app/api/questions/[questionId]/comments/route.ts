import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { logActivity } from "@/lib/activity";
import { extractRawMentions, resolveMentions } from "@/lib/mentions";
import { notifyMany, type NotifyInput } from "@/lib/notifications/service";
import { truncate } from "@/lib/utils";
import { slackNotifyMention } from "@/lib/integrations/slack-events";

async function loadQuestion(questionId: string, userId: string) {
  const q = await prisma.question.findUnique({
    where: { id: questionId },
    include: { rfp: { include: { project: true } } },
  });
  if (!q) throw new NotFoundError("Question not found");
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: { userId, organizationId: q.rfp.project.organizationId },
    },
  });
  if (!member) throw new ForbiddenError("Not a member");
  return q;
}

export const GET = withApiHandler<{ questionId: string }>(async (_req, { params }) => {
  const { questionId } = await params;
  const user = await requireUser();
  await loadQuestion(questionId, user.id);
  const comments = await prisma.comment.findMany({
    where: { questionId },
    include: {
      author: { select: { id: true, name: true, email: true } },
      mentions: { include: { user: { select: { id: true, name: true, email: true } } } },
    },
    orderBy: { createdAt: "asc" },
  });
  return Response.json({ comments });
});

const createSchema = z.object({ body: z.string().min(1).max(4000) });

export const POST = withApiHandler<{ questionId: string }>(async (req, { params }) => {
  const { questionId } = await params;
  const user = await requireUser();
  const q = await loadQuestion(questionId, user.id);
  const { body } = createSchema.parse(await req.json());

  // Resolve @mentions against the org's membership.
  const orgMembers = await prisma.membership.findMany({
    where: { organizationId: q.rfp.project.organizationId },
    select: { user: { select: { id: true, email: true } } },
  });
  const memberEntries = orgMembers.map((m) => ({ id: m.user.id, email: m.user.email }));
  const rawMentions = extractRawMentions(body);
  const mentionedIds = resolveMentions(rawMentions, memberEntries);

  const comment = await prisma.comment.create({
    data: {
      questionId,
      authorId: user.id,
      body,
      mentions: mentionedIds.length
        ? { create: mentionedIds.map((userId) => ({ userId })) }
        : undefined,
    },
    include: {
      author: { select: { id: true, name: true, email: true } },
      mentions: { include: { user: { select: { id: true, name: true, email: true } } } },
    },
  });

  void logActivity({
    rfpId: q.rfpId,
    actorId: user.id,
    kind: "COMMENT_ADDED",
    payload: {
      questionId,
      number: q.number,
      commentId: comment.id,
      mentions: mentionedIds.length,
    },
  });

  // Notifications: mention recipients → COMMENT_MENTION; the question
  // assignee (if any and not the commenter and not already mentioned) →
  // COMMENT_ON_YOUR_QUESTION.
  const actorName = user.name ?? user.email ?? "A teammate";
  const excerpt = truncate(body, 200);
  const orgId = q.rfp.project.organizationId;
  const tasks: NotifyInput[] = [];

  for (const mid of mentionedIds) {
    tasks.push({
      ctx: {
        userId: mid,
        actorId: user.id,
        organizationId: orgId,
        rfpId: q.rfpId,
        questionId: q.id,
        commentId: comment.id,
      },
      payload: {
        kind: "COMMENT_MENTION",
        data: {
          rfpTitle: q.rfp.title,
          questionNumber: q.number,
          questionText: q.text,
          actorName,
          excerpt,
        },
      },
    });
  }

  if (
    q.assigneeId &&
    q.assigneeId !== user.id &&
    !mentionedIds.includes(q.assigneeId)
  ) {
    tasks.push({
      ctx: {
        userId: q.assigneeId,
        actorId: user.id,
        organizationId: orgId,
        rfpId: q.rfpId,
        questionId: q.id,
        commentId: comment.id,
      },
      payload: {
        kind: "COMMENT_ON_YOUR_QUESTION",
        data: {
          rfpTitle: q.rfp.title,
          questionNumber: q.number,
          questionText: q.text,
          actorName,
          excerpt,
        },
      },
    });
  }

  void notifyMany(tasks);

  // Slack notifications (Tier B1) — fire-and-forget. One Slack message per
  // mention, mirroring the per-recipient COMMENT_MENTION notification path
  // above. Build a permalink the channel can click into. Resolved mention
  // user objects come from the `comment.mentions` include we already did.
  if (mentionedIds.length > 0) {
    const mentionUsers = new Map(comment.mentions.map((m) => [m.user.id, m.user]));
    const commentUrl = `/dashboard/rfps/${q.rfpId}?org=${orgId}&question=${q.id}&comment=${comment.id}`;
    for (const mid of mentionedIds) {
      const mentioned = mentionUsers.get(mid);
      const mentionedName = mentioned?.name ?? mentioned?.email ?? "Someone";
      void slackNotifyMention(orgId, {
        mentionedUserName: mentionedName,
        mentionerName: actorName,
        commentText: body,
        rfpTitle: q.rfp.title,
        commentUrl,
      });
    }
  }

  return Response.json({ comment }, { status: 201 });
});
