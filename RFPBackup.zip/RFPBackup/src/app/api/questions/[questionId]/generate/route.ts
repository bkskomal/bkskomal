import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { auth } from "@/lib/auth";
import { generateResponse, type ResponseStep } from "@/lib/ai/generate";
import { logActivity } from "@/lib/activity";
import { rateLimit, RATE_LIMITS, RateLimitError } from "@/lib/rate-limit";
import { slackNotifyResponseGenerated } from "@/lib/integrations/slack-events";

const bodySchema = z.object({
  indexId: z.string().nullable().optional(),
  enableTools: z.boolean().optional(),
});

export async function POST(req: NextRequest, { params }: { params: Promise<{ questionId: string }> }) {
  const session = await auth();
  if (!session?.user?.id) return new Response("Unauthorized", { status: 401 });
  const userId = session.user.id;

  const { questionId } = await params;
  const body = bodySchema.parse(await req.json().catch(() => ({})));

  const question = await prisma.question.findUnique({
    where: { id: questionId },
    include: { rfp: { include: { project: { include: { organization: true, defaultIndex: true } } } } },
  });
  if (!question) return new Response("Not found", { status: 404 });

  const orgId = question.rfp.project.organizationId;
  const membership = await prisma.membership.findUnique({
    where: { userId_organizationId: { userId, organizationId: orgId } },
  });
  if (!membership) return new Response("Forbidden", { status: 403 });

  try {
    await rateLimit(RATE_LIMITS.generate, { userId, orgId, route: "questions/generate" });
  } catch (e) {
    if (e instanceof RateLimitError) {
      return new Response(
        JSON.stringify({ error: e.message, code: e.code, retryAfterSeconds: e.retryAfterSeconds }),
        {
          status: 429,
          headers: {
            "Content-Type": "application/json",
            "Retry-After": String(e.retryAfterSeconds),
          },
        },
      );
    }
    throw e;
  }

  const indexId = body.indexId ?? question.rfp.project.defaultIndexId ?? null;

  // Pre-create the response row so the UI can reference it for feedback.
  const draft = await prisma.response.create({
    data: { questionId, indexId, status: "GENERATING", content: "" },
  });

  const stream = new ReadableStream({
    async start(controller) {
      const enc = new TextEncoder();
      const send = (event: string, data: unknown) => {
        controller.enqueue(enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`));
      };

      send("start", { responseId: draft.id });

      try {
        // Semantic golden lookup — finds the most relevant past Q&A even
        // when the new question is worded completely differently. Falls
        // back to recency for orgs whose goldens aren't embedded yet.
        const { findRelevantGoldens } = await import("@/lib/ai/golden-search");
        const goldenAnswers = await findRelevantGoldens({
          organizationId: orgId,
          questionText: question.text,
          take: 6,
        });

        const result = await generateResponse({
          question: question.text,
          indexId,
          goldenAnswers,
          enableTools: body.enableTools ?? true,
          // Plumb the extractor-assigned complexity through for model routing
          // (Phase 3B). The Question model's `complexity` is a free string;
          // we narrow to the routing-recognised values, anything else becomes
          // undefined → falls back to the standard model.
          complexity:
            question.complexity === "simple" ||
            question.complexity === "moderate" ||
            question.complexity === "complex"
              ? question.complexity
              : undefined,
          ctx: {
            organizationId: orgId,
            projectId: question.rfp.projectId,
            rfpId: question.rfpId,
            questionId,
            defaultIndexId: indexId,
            userId,
          },
          onStep: (step: ResponseStep) => send("step", step),
        });

        await prisma.response.update({
          where: { id: draft.id },
          data: {
            status: "COMPLETED",
            content: result.content,
            reasoning: result.reasoning as never,
            confidence: result.confidence,
            needsReview: result.needsReview,
            // Grounding fields are nullable on the schema; we only set them
            // when the second-pass judge actually returned a result. A failed
            // judge leaves them null so the UI knows the response is ungraded.
            ...(result.grounding
              ? {
                  groundingScore: result.grounding.score,
                  groundingNotes: result.grounding.claims as never,
                  groundingAt: new Date(),
                }
              : {}),
            sources: {
              create: result.sources.map((s) => ({
                chunkId: s.id,
                score: s.score,
                excerpt: s.content.slice(0, 1000),
                fileName: s.fileName,
                page: s.page,
              })),
            },
          },
        });

        // Cache confidence on the question for fast filtering in the table view.
        await prisma.question.update({
          where: { id: questionId },
          data: { confidence: result.confidence },
        });

        void logActivity({
          rfpId: question.rfpId,
          actorId: userId,
          kind: "RESPONSE_GENERATED",
          payload: {
            questionId,
            questionNumber: question.number,
            confidence: result.confidence,
            sourceCount: result.sources.length,
          },
        });
        // Slack notification (Tier B1) — fire-and-forget. The integration
        // resolver short-circuits when the org has no Slack set up so this
        // is cheap on the unconfigured path.
        void slackNotifyResponseGenerated(orgId, {
          rfpTitle: question.rfp.title,
          questionText: question.text,
          confidence: result.confidence,
          groundingScore: result.grounding?.score ?? null,
          responseUrl: `/dashboard/rfps/${question.rfpId}?org=${orgId}&question=${questionId}`,
        });

        send("done", {
          responseId: draft.id,
          content: result.content,
          sources: result.sources,
          confidence: result.confidence,
          needsReview: result.needsReview,
          grounding: result.grounding
            ? {
                score: result.grounding.score,
                claims: result.grounding.claims,
                judgeModel: result.grounding.judgeModel,
                ms: result.grounding.ms,
              }
            : null,
          // Stale-source warnings (Tier B2). Empty list when no cited doc is
          // stale. The response viewer renders a banner above the answer
          // when this is non-empty; the per-doc reasons are also already in
          // `reasoning` as `stale_source` steps for the activity drawer.
          staleSourceWarnings: result.staleSourceWarnings,
        });
      } catch (e) {
        const message = e instanceof Error ? e.message : String(e);
        await prisma.response.update({
          where: { id: draft.id },
          data: { status: "FAILED", content: `Error: ${message}` },
        });
        send("error", { message });
      } finally {
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
