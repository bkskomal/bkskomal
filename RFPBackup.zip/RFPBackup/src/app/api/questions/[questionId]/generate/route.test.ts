import { describe, expect, it, beforeEach, vi } from "vitest";
import { NextRequest } from "next/server";
import { _resetForTests, _setNowForTests } from "@/lib/rate-limit";

// ---------------------------------------------------------------------------
// Mocks. vi.mock is hoisted to the top, so any state the factory closes over
// must be created via vi.hoisted (which is also hoisted).
// ---------------------------------------------------------------------------

const { authMock, generateResponseMock, logActivityMock, prismaMock } = vi.hoisted(() => {
  return {
    authMock: vi.fn(),
    generateResponseMock: vi.fn(),
    logActivityMock: vi.fn().mockResolvedValue(undefined),
    prismaMock: {
      question: {
        findUnique: vi.fn(),
        update: vi.fn(),
      },
      membership: {
        findUnique: vi.fn(),
      },
      response: {
        create: vi.fn(),
        update: vi.fn(),
      },
      goldenAnswer: {
        findMany: vi.fn(),
        // Phase H — semantic golden retrieval calls count() to decide whether
        // to do a BGE re-rank or fall back to recency. Returning 0 short-
        // circuits to "no goldens" without exercising the embedding path.
        count: vi.fn().mockResolvedValue(0),
        findUnique: vi.fn(),
        update: vi.fn(),
      },
    },
  };
});

vi.mock("@/lib/auth", () => ({
  auth: () => authMock(),
}));

vi.mock("@/lib/ai/generate", () => ({
  generateResponse: (...args: unknown[]) => generateResponseMock(...args),
}));

vi.mock("@/lib/activity", () => ({
  logActivity: (...args: unknown[]) => logActivityMock(...args),
}));

vi.mock("@/lib/prisma", () => ({
  prisma: prismaMock,
}));

// Import after mocks so the route binds to them.
import { POST } from "./route";

// ---------------------------------------------------------------------------
// Fixtures.
// ---------------------------------------------------------------------------

const USER_ID = "user-1";
const ORG_ID = "org-1";
const QUESTION_ID = "q-1";
const RFP_ID = "rfp-1";
const PROJECT_ID = "proj-1";

const session = { user: { id: USER_ID } };

function buildQuestionFixture(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    id: QUESTION_ID,
    number: 1,
    text: "What is your security posture?",
    rfpId: RFP_ID,
    rfp: {
      id: RFP_ID,
      projectId: PROJECT_ID,
      project: {
        id: PROJECT_ID,
        organizationId: ORG_ID,
        defaultIndexId: null,
        organization: { id: ORG_ID, name: "Acme" },
        defaultIndex: null,
      },
    },
    ...overrides,
  };
}

function buildGenerateResult() {
  return {
    content: "We use AES-256 at rest. [Source 1]",
    reasoning: [],
    sources: [
      {
        id: "chunk-1",
        score: 0.9,
        content: "Encryption details...",
        fileName: "security.md",
        page: 1,
      },
    ],
    confidence: 0.85,
    needsReview: false,
  };
}

function buildRequest(body: unknown = {}) {
  return new NextRequest("http://x/api/questions/q-1/generate", {
    method: "POST",
    body: JSON.stringify(body),
    headers: { "Content-Type": "application/json" },
  });
}

const params = () => ({ params: Promise.resolve({ questionId: QUESTION_ID }) });

// Read an SSE stream and parse it into ordered (event, data) tuples.
async function readSse(res: Response): Promise<Array<{ event: string; data: unknown }>> {
  expect(res.body).not.toBeNull();
  const reader = res.body!.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
  }
  buf += decoder.decode();

  const events: Array<{ event: string; data: unknown }> = [];
  for (const chunk of buf.split("\n\n")) {
    const trimmed = chunk.trim();
    if (!trimmed) continue;
    const lines = trimmed.split("\n");
    let event = "message";
    let dataRaw = "";
    for (const line of lines) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataRaw += line.slice(5).trim();
    }
    let data: unknown = dataRaw;
    try {
      data = JSON.parse(dataRaw);
    } catch {
      // leave as string
    }
    events.push({ event, data });
  }
  return events;
}

// ---------------------------------------------------------------------------
// Test setup — fresh mocks + fresh rate-limit bucket per test.
// ---------------------------------------------------------------------------

beforeEach(() => {
  _resetForTests();
  vi.clearAllMocks();

  // Defaults: authenticated, member, question exists, no golden answers, draft
  // response is returned, and generation returns a happy result.
  authMock.mockResolvedValue(session);
  prismaMock.question.findUnique.mockResolvedValue(buildQuestionFixture());
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: "MEMBER",
  });
  prismaMock.response.create.mockResolvedValue({ id: "resp-1" });
  prismaMock.response.update.mockResolvedValue({});
  prismaMock.question.update.mockResolvedValue({});
  prismaMock.goldenAnswer.findMany.mockResolvedValue([]);
  generateResponseMock.mockResolvedValue(buildGenerateResult());
});

// ---------------------------------------------------------------------------
// Tests.
// ---------------------------------------------------------------------------

describe("POST /api/questions/:questionId/generate — auth gating", () => {
  it("returns 401 when unauthenticated", async () => {
    authMock.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(401);
  });

  it("returns 401 when session has no user id", async () => {
    authMock.mockResolvedValueOnce({ user: {} });
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(401);
  });

  it("returns 404 when the question does not exist", async () => {
    prismaMock.question.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(404);
  });

  it("returns 403 when the user has no membership in the org", async () => {
    prismaMock.membership.findUnique.mockResolvedValueOnce(null);
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(403);
  });
});

describe("POST /api/questions/:questionId/generate — happy path", () => {
  it("returns a 200 SSE stream with start → step → done in order", async () => {
    // Make generate emit a couple of steps.
    generateResponseMock.mockImplementationOnce(async (opts: { onStep?: (s: unknown) => void }) => {
      opts.onStep?.({ step: "analyzing", detail: "thinking" });
      opts.onStep?.({ step: "drafting", detail: "writing" });
      return buildGenerateResult();
    });

    const res = await POST(buildRequest({ indexId: null, enableTools: true }), params());
    expect(res.status).toBe(200);
    expect(res.headers.get("Content-Type")).toContain("text/event-stream");

    const events = await readSse(res);
    const types = events.map((e) => e.event);

    // First event must be `start`, last must be `done`.
    expect(types[0]).toBe("start");
    expect(types[types.length - 1]).toBe("done");
    // At least the two emitted step events appear, in order, between them.
    const stepEvents = events.filter((e) => e.event === "step");
    expect(stepEvents.length).toBeGreaterThanOrEqual(2);
    expect(stepEvents[0].data).toMatchObject({ step: "analyzing" });
    expect(stepEvents[1].data).toMatchObject({ step: "drafting" });

    // `start` carries the draft responseId.
    expect((events[0].data as { responseId: string }).responseId).toBe("resp-1");
    // `done` carries the final content + confidence.
    const doneEv = events.find((e) => e.event === "done");
    expect(doneEv?.data).toMatchObject({
      responseId: "resp-1",
      content: "We use AES-256 at rest. [Source 1]",
      confidence: 0.85,
      needsReview: false,
    });
  });

  it("creates a GENERATING draft response, then updates it to COMPLETED with sources", async () => {
    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200);
    await readSse(res);

    expect(prismaMock.response.create).toHaveBeenCalledWith({
      data: { questionId: QUESTION_ID, indexId: null, status: "GENERATING", content: "" },
    });
    expect(prismaMock.response.update).toHaveBeenCalledWith(
      expect.objectContaining({
        where: { id: "resp-1" },
        data: expect.objectContaining({
          status: "COMPLETED",
          content: "We use AES-256 at rest. [Source 1]",
          confidence: 0.85,
          needsReview: false,
        }),
      }),
    );
    expect(prismaMock.question.update).toHaveBeenCalledWith({
      where: { id: QUESTION_ID },
      data: { confidence: 0.85 },
    });
    expect(logActivityMock).toHaveBeenCalledWith(
      expect.objectContaining({
        rfpId: RFP_ID,
        actorId: USER_ID,
        kind: "RESPONSE_GENERATED",
      }),
    );
  });
});

describe("POST /api/questions/:questionId/generate — validation", () => {
  it("rejects bodies with wrong field types (ZodError) before streaming starts", async () => {
    const res = await POST(
      new NextRequest("http://x/api/questions/q-1/generate", {
        method: "POST",
        body: JSON.stringify({ enableTools: "not-a-boolean" }),
        headers: { "Content-Type": "application/json" },
      }),
      params(),
    ).catch((e) => e);

    if (res instanceof Response) {
      expect(res.status).toBeGreaterThanOrEqual(400);
      expect(res.status).toBeLessThan(500);
    } else {
      expect(res).toBeInstanceOf(Error);
      expect(String(res)).toMatch(/Zod|validation|invalid/i);
    }
    // Crucially: no draft response was created on a malformed body.
    expect(prismaMock.response.create).not.toHaveBeenCalled();
  });
});

describe("POST /api/questions/:questionId/generate — rate limiting", () => {
  it("returns 429 with Retry-After + retryAfterSeconds once the bucket is empty", async () => {
    // Pin time so the bucket doesn't refill between calls.
    _setNowForTests(() => 1_700_000_000_000);

    // Capacity for the generate rule is 30 org-scoped tokens. Burst past it.
    const N = 32;
    const statuses: number[] = [];
    let rateLimited: Response | null = null;
    for (let i = 0; i < N; i++) {
      const res = await POST(buildRequest(), params());
      // Drain the stream on 200s so we don't leak resources.
      if (res.body && res.status === 200) await readSse(res);
      statuses.push(res.status);
      if (res.status === 429 && !rateLimited) rateLimited = res;
    }

    expect(statuses).toContain(429);
    expect(rateLimited).not.toBeNull();
    expect(rateLimited!.headers.get("Retry-After")).toBeTruthy();
    const body = await rateLimited!.json();
    expect(body).toMatchObject({
      code: "rate_limited",
      retryAfterSeconds: expect.any(Number),
    });
    expect(body.retryAfterSeconds).toBeGreaterThan(0);
  });
});

describe("POST /api/questions/:questionId/generate — error propagation", () => {
  it("on LLM failure emits an `error` SSE event and marks the response FAILED", async () => {
    generateResponseMock.mockRejectedValueOnce(new Error("LLM down"));
    const consoleSpy = vi.spyOn(console, "error").mockImplementation(() => {});

    const res = await POST(buildRequest(), params());
    expect(res.status).toBe(200); // streams always return 200; errors travel in-band

    const events = await readSse(res);
    const errEv = events.find((e) => e.event === "error");
    expect(errEv).toBeTruthy();
    expect((errEv!.data as { message: string }).message).toContain("LLM down");

    // The draft response should have been transitioned to FAILED.
    const failedUpdate = prismaMock.response.update.mock.calls.find(
      (call) => (call[0] as { data: { status: string } }).data.status === "FAILED",
    );
    expect(failedUpdate).toBeTruthy();

    consoleSpy.mockRestore();
  });
});
