import { z } from "zod";
import { QuestionStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError, ValidationError } from "@/lib/errors";
import { logActivity } from "@/lib/activity";
import { notify } from "@/lib/notifications/service";
import { advance as advancePipeline } from "@/lib/pipeline/engine";

const patchSchema = z.object({
  status: z.nativeEnum(QuestionStatus).optional(),
  assigneeId: z.string().nullable().optional(),
  dueDate: z.string().datetime().nullable().optional(),
});

async function loadAndAuthorize(questionId: string, userId: string) {
  const q = await prisma.question.findUnique({
    where: { id: questionId },
    include: { rfp: { include: { project: true } } },
  });
  if (!q) throw new NotFoundError("Question not found");
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId,
        organizationId: q.rfp.project.organizationId,
      },
    },
  });
  if (!member) throw new ForbiddenError("Not a member");
  return q;
}

export const PATCH = withApiHandler<{ questionId: string }>(async (req, { params }) => {
  const { questionId } = await params;
  const user = await requireUser();
  const body = patchSchema.parse(await req.json());
  const q = await loadAndAuthorize(questionId, user.id);

  if (body.assigneeId !== undefined && body.assigneeId !== null) {
    const assigneeMember = await prisma.membership.findUnique({
      where: {
        userId_organizationId: {
          userId: body.assigneeId,
          organizationId: q.rfp.project.organizationId,
        },
      },
    });
    if (!assigneeMember) throw new ValidationError("Assignee is not a member of this organization");
  }

  const updated = await prisma.question.update({
    where: { id: questionId },
    data: {
      ...(body.status !== undefined ? { status: body.status } : {}),
      ...(body.assigneeId !== undefined ? { assigneeId: body.assigneeId } : {}),
      ...(body.dueDate !== undefined
        ? { dueDate: body.dueDate === null ? null : new Date(body.dueDate) }
        : {}),
    },
    include: { assignee: { select: { id: true, name: true, email: true } } },
  });

  if (body.status && body.status !== q.status) {
    void logActivity({
      rfpId: q.rfpId,
      actorId: user.id,
      kind: "QUESTION_STATUS_CHANGED",
      payload: { questionId, from: q.status, to: body.status, number: q.number },
    });
  }
  if (body.assigneeId !== undefined && body.assigneeId !== q.assigneeId) {
    void logActivity({
      rfpId: q.rfpId,
      actorId: user.id,
      kind: "QUESTION_ASSIGNED",
      payload: { questionId, assigneeId: body.assigneeId, number: q.number },
    });

    if (body.assigneeId) {
      void notify({
        ctx: {
          userId: body.assigneeId,
          actorId: user.id,
          organizationId: q.rfp.project.organizationId,
          rfpId: q.rfpId,
          questionId: q.id,
        },
        payload: {
          kind: "QUESTION_ASSIGNED",
          data: {
            rfpTitle: q.rfp.title,
            questionNumber: q.number,
            questionText: q.text,
            actorName: user.name ?? user.email ?? "A teammate",
          },
        },
      });
    }
  }

  // Status / assignee changes can satisfy a pipeline step (e.g. assignment,
  // internal review, approval). Advance the run so the UI updates.
  if (body.status !== undefined || body.assigneeId !== undefined) {
    void advancePipeline(q.rfpId);
  }

  return Response.json({ question: updated });
});
