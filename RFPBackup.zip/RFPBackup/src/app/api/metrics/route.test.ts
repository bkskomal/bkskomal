import { afterEach, describe, expect, it } from "vitest";
import { GET } from "./route";
import { _resetEnvCacheForTests } from "@/lib/env";

describe("/api/metrics", () => {
  const ORIG_TOKEN = process.env.METRICS_TOKEN;

  afterEach(() => {
    if (ORIG_TOKEN === undefined) delete process.env.METRICS_TOKEN;
    else process.env.METRICS_TOKEN = ORIG_TOKEN;
    _resetEnvCacheForTests();
  });

  it("returns 200 text/plain when no token is configured", async () => {
    delete process.env.METRICS_TOKEN;
    _resetEnvCacheForTests();
    const res = await GET(new Request("http://x/api/metrics"));
    expect(res.status).toBe(200);
    const ct = res.headers.get("content-type") ?? "";
    expect(ct).toMatch(/text\/plain/);
    expect(ct).toMatch(/version=0\.0\.4/);
    const body = await res.text();
    expect(body).toContain("# HELP");
    expect(body).toContain("# TYPE");
  });

  it("rejects missing bearer when METRICS_TOKEN is set", async () => {
    process.env.METRICS_TOKEN = "secret-shh";
    _resetEnvCacheForTests();
    const res = await GET(new Request("http://x/api/metrics"));
    expect(res.status).toBe(401);
  });

  it("accepts a matching bearer when METRICS_TOKEN is set", async () => {
    process.env.METRICS_TOKEN = "secret-shh";
    _resetEnvCacheForTests();
    const res = await GET(
      new Request("http://x/api/metrics", {
        headers: { authorization: "Bearer secret-shh" },
      }),
    );
    expect(res.status).toBe(200);
  });
});
