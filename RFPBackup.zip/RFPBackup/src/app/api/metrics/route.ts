// Prometheus exposition endpoint.
//
// Intentionally bypasses `withApiHandler` and the session/cookie auth stack.
// Operators scrape /metrics from inside the cluster (or via a sidecar
// scraper); the surface should look identical no matter what state the rest
// of the app is in. If METRICS_TOKEN is set we require a bearer header;
// otherwise the endpoint is open and the operator is expected to gate it
// with network policy.

import { exposition } from "@/lib/metrics";
import { env } from "@/lib/env";

export const dynamic = "force-dynamic";

export async function GET(req: Request): Promise<Response> {
  const token = env.METRICS_TOKEN;
  if (token) {
    const auth = req.headers.get("authorization") ?? "";
    const expected = `Bearer ${token}`;
    if (auth !== expected) {
      return new Response("unauthorized", {
        status: 401,
        headers: { "Content-Type": "text/plain; charset=utf-8" },
      });
    }
  }
  const body = exposition();
  return new Response(body, {
    status: 200,
    headers: {
      // Prometheus exposition format. The "version=0.0.4" parameter advertises
      // the legacy text format that every Prom client speaks.
      "Content-Type": "text/plain; version=0.0.4; charset=utf-8",
      "Cache-Control": "no-store",
    },
  });
}
