// Tests for the image-serve route.
//
// Covers the four exit conditions called out in the build plan:
//   - 200 happy path with the correct mime + cache headers
//   - 400 on a path-traversal attempt
//   - 404 on a path that doesn't match any ImageEmbedding row
//   - 403 when the row exists but only in a foreign org
// Plus a regression check that the bytes returned are exactly what was on disk.

import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";
import { mkdtemp, mkdir, writeFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const { authMock, prismaMock } = vi.hoisted(() => ({
  authMock: vi.fn(),
  prismaMock: {
    membership: { findMany: vi.fn() },
    imageEmbedding: { findFirst: vi.fn() },
  },
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));

const USER_ID = "user_img_1";
const ORG_ID = "org_img_1";
const FOREIGN_ORG = "org_other";

let tmpRoot: string;
let cwdSpy: ReturnType<typeof vi.spyOn> | null = null;

async function withFile(
  filename: string,
  bytes: Buffer,
): Promise<string> {
  const dir = path.join(tmpRoot, "uploads", "images");
  await mkdir(dir, { recursive: true });
  const abs = path.join(dir, filename);
  await writeFile(abs, bytes);
  return abs;
}

beforeEach(async () => {
  tmpRoot = await mkdtemp(path.join(os.tmpdir(), "autorfp-images-"));
  // The route resolves IMAGES_ROOT off process.cwd() at module load time,
  // so we have to reset modules and re-import after pinning cwd. We use a
  // spy because the platform-native chdir is fragile in vitest workers.
  cwdSpy = vi.spyOn(process, "cwd").mockReturnValue(tmpRoot);
  vi.resetModules();

  authMock.mockReset();
  prismaMock.membership.findMany.mockReset();
  prismaMock.imageEmbedding.findFirst.mockReset();

  authMock.mockResolvedValue({ user: { id: USER_ID } });
  prismaMock.membership.findMany.mockResolvedValue([{ organizationId: ORG_ID }]);
});

afterEach(async () => {
  cwdSpy?.mockRestore();
  await rm(tmpRoot, { recursive: true, force: true });
});

async function importRoute() {
  const mod = await import("./route");
  return mod.GET;
}

function makeReq(url = "http://localhost/api/images/abc.png"): Request {
  return new Request(url);
}

const params = (segments: string[]) => ({
  params: Promise.resolve({ path: segments }),
});

describe("GET /api/images/[...path]", () => {
  it("returns 200 with bytes and the right cache + content-type headers", async () => {
    const bytes = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
    await withFile("abc.png", bytes);
    prismaMock.imageEmbedding.findFirst.mockResolvedValueOnce({
      mimeType: "image/png",
    });

    const GET = await importRoute();
    const res = await GET(makeReq(), params(["abc.png"]));

    expect(res.status).toBe(200);
    expect(res.headers.get("Content-Type")).toBe("image/png");
    expect(res.headers.get("Cache-Control")).toBe(
      "private, max-age=3600, must-revalidate",
    );
    expect(res.headers.get("Content-Length")).toBe(String(bytes.length));
    const body = Buffer.from(await res.arrayBuffer());
    expect(body.equals(bytes)).toBe(true);
    // Confirm the auth check is org-scoped: the resolver only consulted
    // membership.findMany once and never asked about a foreign org.
    expect(prismaMock.membership.findMany).toHaveBeenCalledWith({
      where: { userId: USER_ID },
      select: { organizationId: true },
    });
  });

  it("rejects path-traversal attempts with 400 (no DB hit)", async () => {
    const GET = await importRoute();
    const res = await GET(
      makeReq("http://localhost/api/images/..%2Fetc%2Fpasswd"),
      params(["../etc/passwd"]),
    );
    expect(res.status).toBe(400);
    expect(prismaMock.imageEmbedding.findFirst).not.toHaveBeenCalled();
  });

  it("rejects encoded traversal segments with 400", async () => {
    const GET = await importRoute();
    const res = await GET(
      makeReq("http://localhost/api/images/%2e%2e/abc.png"),
      params(["..", "abc.png"]),
    );
    expect(res.status).toBe(400);
  });

  it("returns 404 when no ImageEmbedding row references the path", async () => {
    prismaMock.imageEmbedding.findFirst
      .mockResolvedValueOnce(null) // org-scoped lookup → miss
      .mockResolvedValueOnce(null); // global probe → also miss → true 404

    const GET = await importRoute();
    const res = await GET(makeReq(), params(["abc.png"]));
    expect(res.status).toBe(404);
  });

  it("returns 403 when the row exists but in a foreign org", async () => {
    prismaMock.imageEmbedding.findFirst
      .mockResolvedValueOnce(null) // not in caller's orgs
      .mockResolvedValueOnce({ id: "img_foreign" }); // exists somewhere

    const GET = await importRoute();
    const res = await GET(makeReq(), params(["abc.png"]));
    expect(res.status).toBe(403);
    // Authorization checked the foreign org; no disk read should fire.
    expect(prismaMock.imageEmbedding.findFirst).toHaveBeenCalledTimes(2);
    expect(prismaMock.imageEmbedding.findFirst.mock.calls[0][0]).toMatchObject({
      where: expect.objectContaining({
        organizationId: { in: [ORG_ID] },
      }),
    });
    expect(prismaMock.imageEmbedding.findFirst.mock.calls[1][0]).toMatchObject({
      where: expect.objectContaining({ imagePath: "images/abc.png" }),
    });
    void FOREIGN_ORG;
  });

  it("returns 404 when the row exists but the on-disk file is missing", async () => {
    prismaMock.imageEmbedding.findFirst.mockResolvedValueOnce({
      mimeType: "image/png",
    });
    const GET = await importRoute();
    const res = await GET(makeReq(), params(["abc.png"]));
    expect(res.status).toBe(404);
  });
});
