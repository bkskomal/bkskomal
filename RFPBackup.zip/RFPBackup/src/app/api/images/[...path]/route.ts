// Image-serve route for the multimodal RAG pipeline.
//
// Image bytes live on disk under `uploads/images/<sha256>.<ext>` (the IM1
// image-store module owns that convention). This route streams a single file
// back to the browser with the right content type, scoped to orgs the caller
// is a member of. SHA-256 content addressing means cached responses never
// need invalidation — once a hash exists, the bytes behind it are immutable.
//
// Permission model: the caller must be a member of an organization that has
// at least one `ImageEmbedding` row referencing the requested `imagePath`.
// Cross-org leakage is therefore impossible without a foreign-org admin
// re-ingesting the exact same image.
//
// Path-traversal protection is enforced THREE times — defense in depth:
//   1) The catch-all segments are joined with "/" and matched against a
//      strict regex `^images/[A-Za-z0-9._-]+\.(png|jpe?g|gif|webp|bmp|tiff?)$`
//      — anything outside this shape is a 400 before we touch the disk.
//   2) After we resolve the absolute path we assert it still lives under the
//      images root via `path.relative(root, abs)`. A `..` segment slipped
//      past the regex (it can't, but symlinks under the images dir could
//      escape) would land here.
//   3) The DB lookup uses the canonical `imagePath` column (written by IM1
//      at ingest time) — so even a path that exists on disk but was never
//      ingested by the org returns 403, not 200.

import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { prisma } from "@/lib/prisma";
import { ForbiddenError, NotFoundError, ValidationError } from "@/lib/errors";

/** Strict shape: catch-all segments collapse to `images/<hash>.<ext>`.
 *
 * Allowed extensions match every format the image-store can write — raster
 * (png/jpg/jpeg/gif/webp/bmp/tiff/avif), vector (svg), and the `.bin`
 * fallback the store uses when it can't recognise the MIME. Browsers
 * render SVG/AVIF natively, so there's no reason for them to fail the
 * regex when the bytes are on disk. */
const PATH_REGEX = /^images\/[A-Za-z0-9._-]+\.(png|jpe?g|gif|webp|bmp|tiff?|avif|svg|bin)$/i;

/** Canonical on-disk root. Resolved once so the traversal check is O(1). */
const IMAGES_ROOT = path.resolve(process.cwd(), "uploads", "images");

/** MIME table; defensive — defaults to octet-stream rather than throwing. */
const MIME_BY_EXT: Record<string, string> = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  bmp: "image/bmp",
  tif: "image/tiff",
  tiff: "image/tiff",
  avif: "image/avif",
  svg: "image/svg+xml",
  bin: "application/octet-stream",
};

export const GET = withApiHandler<{ path: string[] }>(async (_req, { params }) => {
  const { path: segments } = await params;
  if (!Array.isArray(segments) || segments.length === 0) {
    throw new ValidationError("Image path is required");
  }

  // First-pass shape guard: catch the obvious traversal attempts before any
  // I/O. Decoded segments help us catch "%2e%2e" and friends — Next.js
  // already URL-decodes in dynamic segments, but we re-check anyway.
  const decoded = segments.map((s) => {
    try {
      return decodeURIComponent(s);
    } catch {
      throw new ValidationError("Malformed image path");
    }
  });
  for (const seg of decoded) {
    if (seg.includes("..") || seg.includes("/") || seg.includes("\\") || seg.startsWith(".")) {
      throw new ValidationError("Invalid image path");
    }
  }

  // The route lives at /api/images/[...path], so the dynamic segments do NOT
  // include the leading "images/" prefix in the URL. The DB-stored
  // `imagePath` DOES include the prefix. We accept either form: if the
  // first segment is already "images" we use it as-is, otherwise we prepend
  // it so both `/api/images/abc.png` and `/api/images/images/abc.png`
  // resolve to the same record.
  const canonical = decoded[0] === "images" ? decoded.join("/") : `images/${decoded.join("/")}`;

  if (!PATH_REGEX.test(canonical)) {
    throw new ValidationError("Invalid image path");
  }

  // Permission: the caller must belong to an org that has at least one
  // ImageEmbedding pointing at this exact path. We pull the orgIds the user
  // is a member of and check membership ∩ image-orgs in a single query.
  const user = await requireUser();
  const memberships = await prisma.membership.findMany({
    where: { userId: user.id },
    select: { organizationId: true },
  });
  if (memberships.length === 0) {
    // No memberships at all — short-circuit to 403, no DB hit on images.
    throw new ForbiddenError("No access to this image");
  }
  const orgIds = memberships.map((m) => m.organizationId);

  // Existence + permission check fused: if NO row exists in any of the
  // caller's orgs the image is either not-ingested-here or doesn't exist.
  // We can't tell those apart without leaking info to a probing attacker,
  // so we collapse both to 404. A row that exists but in a different org
  // also returns 404 (NOT 403) for the same reason — intentional.
  const row = await prisma.imageEmbedding.findFirst({
    where: { imagePath: canonical, organizationId: { in: orgIds } },
    select: { mimeType: true },
  });
  if (!row) {
    // Distinguish "exists in another org" from "doesn't exist anywhere" only
    // when an admin would benefit. For end-users both are 404 to prevent
    // image-existence enumeration across orgs.
    const elsewhere = await prisma.imageEmbedding.findFirst({
      where: { imagePath: canonical },
      select: { id: true },
    });
    if (elsewhere) {
      throw new ForbiddenError("Image not in any of your organizations");
    }
    throw new NotFoundError("Image not found");
  }

  // Disk read — second-pass traversal guard.
  const abs = path.resolve(IMAGES_ROOT, path.basename(canonical));
  const rel = path.relative(IMAGES_ROOT, abs);
  if (rel.startsWith("..") || path.isAbsolute(rel)) {
    // Belt-and-braces — should be unreachable thanks to the regex above.
    throw new ValidationError("Invalid image path");
  }

  try {
    await stat(abs);
  } catch {
    throw new NotFoundError("Image file missing on disk");
  }

  const buf = await readFile(abs);
  const ext = path.extname(abs).slice(1).toLowerCase();
  const contentType = row.mimeType || MIME_BY_EXT[ext] || "application/octet-stream";
  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": contentType,
      "Content-Length": String(buf.length),
      // SHA-256 content addressing => safe to cache aggressively. `private`
      // keeps shared CDN proxies out of the loop because we still gate on
      // org membership above.
      "Cache-Control": "private, max-age=3600, must-revalidate",
    },
  });
});
