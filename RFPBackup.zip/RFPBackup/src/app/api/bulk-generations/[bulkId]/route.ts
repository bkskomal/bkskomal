import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { ForbiddenError, NotFoundError } from "@/lib/errors";
import { cancelBulk } from "@/lib/ai/bulk-generate";

async function loadOrThrow(bulkId: string, userId: string) {
  const b = await prisma.bulkGeneration.findUnique({
    where: { id: bulkId },
    include: { rfp: { include: { project: true } } },
  });
  if (!b) throw new NotFoundError("Bulk run not found");
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: { userId, organizationId: b.rfp.project.organizationId },
    },
  });
  if (!member) throw new ForbiddenError("Not a member");
  return b;
}

export const GET = withApiHandler<{ bulkId: string }>(async (_req, { params }) => {
  const { bulkId } = await params;
  const user = await requireUser();
  const b = await loadOrThrow(bulkId, user.id);
  return Response.json({ bulk: b });
});

export const DELETE = withApiHandler<{ bulkId: string }>(async (_req, { params }) => {
  const { bulkId } = await params;
  const user = await requireUser();
  await loadOrThrow(bulkId, user.id);
  cancelBulk(bulkId);
  return Response.json({ ok: true });
});
