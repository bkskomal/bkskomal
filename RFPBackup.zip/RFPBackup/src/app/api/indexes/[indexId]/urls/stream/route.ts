// Streaming variant of /api/indexes/[indexId]/urls.
//
// Same request shape; emits Server-Sent Events as each page is fetched and
// ingested. Lets the UI render a progress bar and a Stop button:
//   - Stop  → client aborts the fetch → req.signal fires → scrapeSite breaks
//             the BFS loop after the in-flight page finishes.
//   - Auto-refresh → each `page` event tells the UI a new Document row exists
//             so it can hot-prepend it without a manual reload.
//
// Events (each one `event: <name>\ndata: <json>\n\n`):
//   - start  { mode, totalSeeds, maxPages, sameOriginOnly }
//   - page   { url, ok, documentId?, imageCount?, error?, visited, ingested, failed, queued }
//   - done   { visited, ingested, failed, durationMs }
//   - error  { message }
//
// The route caps total pages server-side at 100 to keep a single request from
// running for hours (the non-streaming route has the same cap via zod).

import { NextRequest } from "next/server";
import { z } from "zod";
import { requireIndexAccess } from "@/lib/authz";
import { ingestUrl, ingestSite } from "@/lib/scraper/ingest";
import { log } from "@/lib/logger";

export const dynamic = "force-dynamic";

const schema = z.object({
  urls: z.array(z.string().url()).min(1).max(25),
  options: z
    .object({
      respectRobots: z.boolean().optional(),
      timeoutMs: z.number().int().min(1000).max(120_000).optional(),
      maxImages: z.number().int().min(0).max(200).optional(),
      acceptLanguage: z.string().max(120).optional(),
      allowInsecureTlsFallback: z.boolean().optional(),
      scrapeImages: z.boolean().optional(),
    })
    .optional(),
  crawl: z
    .object({
      enabled: z.boolean(),
      // When undefined → scrapeSite uses its server-side default (500).
      maxPages: z.number().int().min(1).max(500).optional(),
      maxDepth: z.number().int().min(0).max(50).optional(),
      sameOriginOnly: z.boolean().optional(),
      perHostDelayMs: z.number().int().min(0).max(10_000).optional(),
    })
    .optional(),
});

function describeError(err: unknown): string {
  if (!(err instanceof Error)) return String(err);
  let cur: Error | undefined = err;
  const chain: string[] = [];
  let depth = 0;
  while (cur && depth < 5) {
    const code = (cur as Error & { code?: string }).code;
    chain.push(code ? `${code}: ${cur.message}` : cur.message);
    cur = (cur as Error & { cause?: Error }).cause;
    depth++;
  }
  return chain.join(" → ");
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ indexId: string }> },
) {
  let indexId: string;
  let body: z.infer<typeof schema>;
  try {
    indexId = (await params).indexId;
    await requireIndexAccess(indexId);
    body = schema.parse(await req.json());
  } catch (e) {
    // Pre-stream errors (auth / validation) should be returned as plain JSON
    // with an appropriate status — streaming an SSE error body from a 200
    // response would confuse fetch callers checking res.ok.
    const status =
      e instanceof Error && /not found|forbidden/i.test(e.message) ? 404 : 400;
    return Response.json(
      { error: e instanceof Error ? e.message : "Bad request" },
      { status },
    );
  }

  const t0 = Date.now();
  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const encoder = new TextEncoder();
      const send = (event: string, data: unknown) => {
        try {
          controller.enqueue(
            encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
          );
        } catch {
          // Stream closed by client — swallow and let the loops detect via signal.
        }
      };

      const counters = { visited: 0, ingested: 0, failed: 0 };
      const crawlEnabled = body.crawl?.enabled === true;

      send("start", {
        mode: crawlEnabled ? "crawl" : "single",
        totalSeeds: body.urls.length,
        maxPages: body.crawl?.maxPages ?? body.urls.length,
        sameOriginOnly: body.crawl?.sameOriginOnly ?? true,
      });

      try {
        if (crawlEnabled) {
          // BFS crawl per seed URL. ingestSite fires `onPageIngested` as
          // each page completes — we forward those into SSE events so the UI
          // updates in real time without waiting for the whole crawl.
          for (const seedUrl of body.urls) {
            if (req.signal.aborted) break;
            try {
              await ingestSite({
                indexId,
                seedUrl,
                onPageIngested: (p) => {
                  counters.visited++;
                  if (p.ok) counters.ingested++;
                  else counters.failed++;
                  send("page", {
                    url: p.url,
                    ok: p.ok,
                    documentId: p.documentId,
                    imageCount: p.imageCount,
                    error: p.error,
                    visited: counters.visited,
                    ingested: counters.ingested,
                    failed: counters.failed,
                  });
                },
                crawlOpts: {
                  ...body.options,
                  maxPages: body.crawl?.maxPages,
                  maxDepth: body.crawl?.maxDepth,
                  sameOriginOnly: body.crawl?.sameOriginOnly,
                  perHostDelayMs: body.crawl?.perHostDelayMs,
                  signal: req.signal,
                },
              });
            } catch (err) {
              counters.visited++;
              counters.failed++;
              send("page", {
                url: seedUrl,
                ok: false,
                error: describeError(err),
                visited: counters.visited,
                ingested: counters.ingested,
                failed: counters.failed,
              });
            }
          }
        } else {
          // Single-URL mode — one ingest per URL, one page event per URL.
          for (const url of body.urls) {
            if (req.signal.aborted) break;
            try {
              const r = await ingestUrl({
                indexId,
                url,
                scrapeOpts: { ...body.options, signal: req.signal },
              });
              counters.visited++;
              counters.ingested++;
              send("page", {
                url,
                ok: true,
                documentId: r.documentId,
                imageCount: r.imageCount,
                visited: counters.visited,
                ingested: counters.ingested,
                failed: counters.failed,
              });
            } catch (err) {
              counters.visited++;
              counters.failed++;
              const detail = describeError(err);
              log().warn(
                { err: { message: detail }, indexId, url },
                "url ingest failed (stream)",
              );
              send("page", {
                url,
                ok: false,
                error: detail,
                visited: counters.visited,
                ingested: counters.ingested,
                failed: counters.failed,
              });
            }
          }
        }

        send("done", { ...counters, durationMs: Date.now() - t0 });
      } catch (err) {
        send("error", { message: describeError(err) });
      } finally {
        try {
          controller.close();
        } catch {
          // already closed
        }
      }
    },
    cancel() {
      // Browser disconnect / Stop button — req.signal will already be
      // aborted, which scrapeSite checks at every iteration.
    },
  });

  return new Response(stream, {
    status: 200,
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      // Prevents some intermediaries from buffering SSE chunks.
      "X-Accel-Buffering": "no",
    },
  });
}
