import { NextRequest } from "next/server";
import { z } from "zod";
import { jsonError, requireIndexAccess } from "@/lib/authz";
import { ingestUrl, ingestSite } from "@/lib/scraper/ingest";
import { log } from "@/lib/logger";

const schema = z.object({
  urls: z.array(z.string().url()).min(1).max(25),
  // Optional per-request overrides that get forwarded to the scraper.
  options: z
    .object({
      respectRobots: z.boolean().optional(),
      timeoutMs: z.number().int().min(1000).max(120_000).optional(),
      maxImages: z.number().int().min(0).max(200).optional(),
      acceptLanguage: z.string().max(120).optional(),
      allowInsecureTlsFallback: z.boolean().optional(),
      scrapeImages: z.boolean().optional(),
    })
    .optional(),
  // When set, each URL is treated as a seed for a BFS crawl through internal
  // links. Total page budget capped server-side at 100 per request so a bad
  // input can't melt the box.
  crawl: z
    .object({
      enabled: z.boolean(),
      // When undefined → scrapeSite uses its server-side default (500).
      maxPages: z.number().int().min(1).max(500).optional(),
      maxDepth: z.number().int().min(0).max(50).optional(),
      sameOriginOnly: z.boolean().optional(),
      perHostDelayMs: z.number().int().min(0).max(10_000).optional(),
    })
    .optional(),
});

function describeError(err: unknown): string {
  if (!(err instanceof Error)) return String(err);
  // Unwrap up to 5 levels of cause so undici's bare "fetch failed" doesn't
  // mask the real reason (TLS chain, refused connection, DNS, etc.).
  let cur: Error | undefined = err;
  const chain: string[] = [];
  let depth = 0;
  while (cur && depth < 5) {
    const code = (cur as Error & { code?: string }).code;
    chain.push(code ? `${code}: ${cur.message}` : cur.message);
    cur = (cur as Error & { cause?: Error }).cause;
    depth++;
  }
  return chain.join(" → ");
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ indexId: string }> },
) {
  try {
    const { indexId } = await params;
    await requireIndexAccess(indexId);
    const body = schema.parse(await req.json());

    // Sequential to keep per-host rate-pressure low + Milvus writes serialized.
    // 25 URLs cap above is the budget; if a caller wants more they can paginate.
    const results: Array<{
      url: string;
      ok: boolean;
      documentId?: string;
      reused?: boolean;
      binary?: boolean;
      finalUrl?: string;
      imageCount?: number;
      scrapeMs?: number;
      warnings?: { code: string; message: string }[];
      error?: string;
    }> = [];

    if (body.crawl?.enabled) {
      // CRAWL mode: each URL is a seed for BFS through internal links.
      for (const url of body.urls) {
        try {
          const r = await ingestSite({
            indexId,
            seedUrl: url,
            crawlOpts: {
              ...body.options,
              maxPages: body.crawl.maxPages,
              maxDepth: body.crawl.maxDepth,
              sameOriginOnly: body.crawl.sameOriginOnly,
              perHostDelayMs: body.crawl.perHostDelayMs,
            },
          });
          // Flatten the crawl result into the same per-URL results shape so
          // the UI can display every page that was visited.
          for (const p of r.pages) {
            results.push({
              url: p.url,
              ok: p.ok,
              documentId: p.documentId,
              reused: p.reused,
              imageCount: p.imageCount,
              error: p.error,
            });
          }
          log().info(
            { indexId, seedUrl: url, visited: r.pagesVisited, ingested: r.pagesIngested, failed: r.pagesFailed },
            "site crawl ingested",
          );
        } catch (err) {
          const detail = describeError(err);
          log().warn(
            {
              err: err instanceof Error
                ? { name: err.name, message: err.message, cause: describeError(err) }
                : { value: String(err) },
              indexId,
              seedUrl: url,
            },
            "site crawl failed",
          );
          results.push({ url, ok: false, error: detail });
        }
      }
    } else {
      // SINGLE-URL mode (default): scrape each URL as a standalone document.
      for (const url of body.urls) {
        try {
          const r = await ingestUrl({ indexId, url, scrapeOpts: body.options });
          results.push({
            url,
            ok: true,
            documentId: r.documentId,
            reused: r.reused,
            binary: r.binary,
            finalUrl: r.finalUrl,
            imageCount: r.imageCount,
            scrapeMs: r.scrapeMs,
            warnings: r.warnings,
          });
        } catch (err) {
          const detail = describeError(err);
          log().warn(
            {
              err: err instanceof Error
                ? { name: err.name, message: err.message, cause: describeError(err) }
                : { value: String(err) },
              indexId,
              url,
            },
            "url ingest failed",
          );
          results.push({ url, ok: false, error: detail });
        }
      }
    }

    const succeeded = results.filter((r) => r.ok).length;
    return Response.json(
      {
        succeeded,
        failed: results.length - succeeded,
        results,
      },
      { status: succeeded > 0 ? 201 : 400 },
    );
  } catch (e) {
    return jsonError(e);
  }
}
