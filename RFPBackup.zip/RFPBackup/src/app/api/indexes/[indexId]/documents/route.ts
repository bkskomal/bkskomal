import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { jsonError, requireIndexAccess } from "@/lib/authz";
import { detectMime } from "@/lib/parsers";
import { saveUpload } from "@/lib/storage";
import { ingestDocument } from "@/lib/indexing";

export async function POST(req: NextRequest, { params }: { params: Promise<{ indexId: string }> }) {
  try {
    const { indexId } = await params;
    await requireIndexAccess(indexId);
    const form = await req.formData();
    const files = form.getAll("files");
    if (files.length === 0) return Response.json({ error: "Missing files" }, { status: 400 });

    const created = [];
    for (const f of files) {
      if (!(f instanceof File)) continue;
      const mime = detectMime(f.name);
      if (!mime) {
        return Response.json({ error: `Unsupported file: ${f.name}` }, { status: 400 });
      }
      const buf = Buffer.from(await f.arrayBuffer());
      const { storagePath } = await saveUpload(`index/${indexId}`, f.name, buf);
      const doc = await prisma.document.create({
        data: {
          indexId,
          name: f.name,
          fileName: f.name,
          fileSize: f.size,
          mimeType: mime,
          storagePath,
        },
      });
      created.push(doc);
      ingestDocument(doc.id).catch((err) => console.error("[ingest]", err));
    }
    return Response.json({ documents: created }, { status: 201 });
  } catch (e) {
    return jsonError(e);
  }
}
