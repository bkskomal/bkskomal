// Tests for the image-search-by-text-query route.

import { describe, expect, it, beforeEach, vi } from "vitest";
import { ApiKeyScope, Role } from "@prisma/client";

const {
  authMock,
  authenticateBearerMock,
  prismaMock,
  embedTextMock,
  searchImagesMock,
  forOrgMock,
} = vi.hoisted(() => ({
  authMock: vi.fn(),
  authenticateBearerMock: vi.fn(),
  prismaMock: {
    knowledgeIndex: { findUnique: vi.fn() },
    membership: { findUnique: vi.fn() },
    imageEmbedding: { findMany: vi.fn() },
  },
  embedTextMock: vi.fn(),
  searchImagesMock: vi.fn(),
  forOrgMock: vi.fn(),
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/auth-bearer", () => ({
  authenticateBearer: (...args: unknown[]) => authenticateBearerMock(...args),
}));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/ai/clip", () => ({
  getClipEmbedder: () => ({
    model: "clip-test",
    dimensions: 4,
    embedTextForImageSearch: (...args: unknown[]) => embedTextMock(...args),
  }),
}));
vi.mock("@/lib/ai/vector", () => ({
  vectorStoreResolver: {
    forOrg: (...args: unknown[]) => forOrgMock(...args),
  },
}));

import { POST } from "./route";

const INDEX_ID = "idx_imgsearch";
const ORG_ID = "org_imgsearch";
const USER_ID = "user_imgsearch";

const params = () => ({ params: Promise.resolve({ indexId: INDEX_ID }) });

function req(body: unknown): Request {
  return new Request(
    `http://localhost/api/indexes/${INDEX_ID}/images/search`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    },
  );
}

beforeEach(() => {
  authMock.mockReset();
  authenticateBearerMock.mockReset();
  embedTextMock.mockReset();
  searchImagesMock.mockReset();
  forOrgMock.mockReset();
  Object.values(prismaMock).forEach((m) =>
    Object.values(m).forEach((fn) => (fn as ReturnType<typeof vi.fn>).mockReset()),
  );

  authenticateBearerMock.mockResolvedValue({
    via: "api-key",
    userId: USER_ID,
    organizationId: ORG_ID,
    scope: ApiKeyScope.WRITE,
    keyId: "key_x",
  });
  prismaMock.knowledgeIndex.findUnique.mockResolvedValue({
    id: INDEX_ID,
    organizationId: ORG_ID,
  });
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: Role.MEMBER,
  });
  embedTextMock.mockResolvedValue([0.1, 0.2, 0.3, 0.4]);
  searchImagesMock.mockResolvedValue([
    {
      id: "img_1",
      score: 0.91,
      imagePath: "images/abc.png",
      caption: "Architecture diagram",
      ocrText: "HA failover",
      page: 3,
      documentId: "doc_1",
      chunkId: "chunk_1",
    },
  ]);
  forOrgMock.mockResolvedValue({
    id: "postgres",
    supportsImages: true,
    searchImages: searchImagesMock,
  });
  prismaMock.imageEmbedding.findMany.mockResolvedValue([
    {
      id: "img_1",
      width: 800,
      height: 600,
      mimeType: "image/png",
      documentId: "doc_1",
    },
  ]);
});

describe("POST /api/indexes/:id/images/search", () => {
  it("encodes the query via CLIP, calls searchImages, and returns hits", async () => {
    const res = await POST(req({ query: "architecture diagram", topK: 5 }), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(embedTextMock).toHaveBeenCalledWith("architecture diagram");
    expect(searchImagesMock).toHaveBeenCalledWith(
      ORG_ID,
      INDEX_ID,
      [0.1, 0.2, 0.3, 0.4],
      { topK: 5 },
    );
    expect(body.hits).toHaveLength(1);
    expect(body.hits[0]).toMatchObject({
      id: "img_1",
      imagePath: "images/abc.png",
      caption: "Architecture diagram",
      width: 800,
      height: 600,
      mimeType: "image/png",
    });
  });

  it("returns 403 without WRITE scope", async () => {
    authenticateBearerMock.mockResolvedValueOnce({
      via: "api-key",
      userId: USER_ID,
      organizationId: ORG_ID,
      scope: ApiKeyScope.READ,
      keyId: "key_x",
    });
    const res = await POST(req({ query: "x" }), params());
    expect(res.status).toBe(403);
    expect(searchImagesMock).not.toHaveBeenCalled();
  });

  it("returns 400 on an empty query", async () => {
    const res = await POST(req({ query: "" }), params());
    expect(res.status).toBe(400);
    expect(searchImagesMock).not.toHaveBeenCalled();
  });

  it("returns 501 when the backend doesn't support image search", async () => {
    forOrgMock.mockResolvedValueOnce({
      id: "postgres",
      supportsImages: false,
    });
    const res = await POST(req({ query: "x" }), params());
    expect(res.status).toBe(501);
  });
});
