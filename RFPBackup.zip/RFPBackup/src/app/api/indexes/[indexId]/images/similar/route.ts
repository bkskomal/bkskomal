// Image-similarity search ("find similar images to this one").
//
// Loads the existing image's stored CLIP vector (no re-encoding round-trip
// to disk needed) and asks the org's vector store for its nearest neighbours
// in the same index. The originating image is returned at score=1.0; we
// strip it from the results before returning so the UI doesn't render the
// query thumbnail in its own "similar" grid.
//
// This route is the back-end for the "Find similar" button on the modal
// inside the KB document viewer's Images tab.

import { z } from "zod";
import { ApiKeyScope, Role } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { requireIndexAccessForRequest } from "@/lib/authz";
import { ForbiddenError, NotFoundError, ValidationError } from "@/lib/errors";
import { vectorStoreResolver } from "@/lib/ai/vector";
import { imagesSearchedTotal } from "@/lib/metrics";
import { prisma } from "@/lib/prisma";

const bodySchema = z.object({
  imageId: z.string().min(1),
  topK: z.number().int().min(1).max(50).optional(),
});

export const POST = withApiHandler<{ indexId: string }>(async (req, { params }) => {
  const { indexId } = await params;
  const { index } = await requireIndexAccessForRequest(req, indexId, {
    minScope: ApiKeyScope.WRITE,
    minRole: Role.MEMBER,
  });

  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      throw new ValidationError("Invalid request body", err.flatten());
    }
    throw err;
  }
  const topK = body.topK ?? 8;

  // Look up the image, ensuring it belongs to THIS index (not just the org).
  // A user holding only the indexId in the URL must not be able to pivot
  // through to images that live in a sibling index.
  const image = await prisma.imageEmbedding.findUnique({
    where: { id: body.imageId },
    select: {
      id: true,
      vector: true,
      organizationId: true,
      indexId: true,
      imagePath: true,
    },
  });
  if (!image) throw new NotFoundError("Image not found");
  if (image.organizationId !== index.organizationId) {
    throw new ForbiddenError("Image not in this organization");
  }
  if (image.indexId !== indexId) {
    throw new NotFoundError("Image not in this index");
  }
  if (!Array.isArray(image.vector) || image.vector.length === 0) {
    // IM1 writes the vector at ingest. A null/empty vector means the row
    // landed before CLIP succeeded (or after a partial failure). Treat as
    // 404 — the caller cannot recover by retry on this endpoint.
    throw new NotFoundError("Image vector unavailable; re-index the document");
  }

  const store = await vectorStoreResolver.forOrg(index.organizationId);
  if (
    typeof (store as { searchImages?: unknown }).searchImages !== "function" ||
    (store as { supportsImages?: boolean }).supportsImages === false
  ) {
    return Response.json(
      {
        error: "This organization's vector backend does not support image search",
        code: "image_search_unsupported",
        hits: [],
      },
      { status: 501 },
    );
  }

  // Ask for one extra hit since we'll strip the source image from results.
  const requested = Math.min(50, topK + 1);
  const hits = await (
    store as unknown as {
      searchImages: (
        orgId: string,
        indexId: string,
        v: number[],
        opts: { topK: number; minScore?: number },
      ) => Promise<
        Array<{
          id: string;
          score: number;
          imagePath?: string;
          caption?: string;
          ocrText?: string;
          page?: number;
          documentId?: string;
          chunkId?: string;
        }>
      >;
    }
  ).searchImages(index.organizationId, indexId, image.vector, { topK: requested });

  imagesSearchedTotal.inc({
    backend: store.id ?? "postgres",
    mode: "image_similarity",
  });

  const filtered = hits.filter((h) => h.id !== image.id).slice(0, topK);

  // Hydrate the same metadata fields as the text-query route so the UI can
  // share its hit-rendering component across the two surfaces.
  const imageRows = await prisma.imageEmbedding.findMany({
    where: { id: { in: filtered.map((h) => h.id) } },
    select: {
      id: true,
      width: true,
      height: true,
      mimeType: true,
      documentId: true,
    },
  });
  const byId = new Map(imageRows.map((r) => [r.id, r]));

  return Response.json({
    sourceImageId: image.id,
    sourceImagePath: image.imagePath,
    topK,
    hits: filtered.map((h) => {
      const meta = byId.get(h.id);
      return {
        id: h.id,
        score: h.score,
        imagePath: h.imagePath,
        caption: h.caption ?? null,
        ocrText: h.ocrText ?? null,
        page: h.page ?? null,
        documentId: h.documentId ?? meta?.documentId ?? null,
        chunkId: h.chunkId ?? null,
        width: meta?.width ?? null,
        height: meta?.height ?? null,
        mimeType: meta?.mimeType ?? null,
      };
    }),
  });
});
