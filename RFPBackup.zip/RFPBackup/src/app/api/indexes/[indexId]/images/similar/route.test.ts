// Tests for the image-similarity ("find similar") route.

import { describe, expect, it, beforeEach, vi } from "vitest";
import { ApiKeyScope, Role } from "@prisma/client";

const {
  authMock,
  authenticateBearerMock,
  prismaMock,
  searchImagesMock,
  forOrgMock,
} = vi.hoisted(() => ({
  authMock: vi.fn(),
  authenticateBearerMock: vi.fn(),
  prismaMock: {
    knowledgeIndex: { findUnique: vi.fn() },
    membership: { findUnique: vi.fn() },
    imageEmbedding: {
      findUnique: vi.fn(),
      findMany: vi.fn(),
    },
  },
  searchImagesMock: vi.fn(),
  forOrgMock: vi.fn(),
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/auth-bearer", () => ({
  authenticateBearer: (...args: unknown[]) => authenticateBearerMock(...args),
}));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/ai/vector", () => ({
  vectorStoreResolver: {
    forOrg: (...args: unknown[]) => forOrgMock(...args),
  },
}));

import { POST } from "./route";

const INDEX_ID = "idx_imgsim";
const ORG_ID = "org_imgsim";
const USER_ID = "user_imgsim";

const params = () => ({ params: Promise.resolve({ indexId: INDEX_ID }) });

function req(body: unknown): Request {
  return new Request(
    `http://localhost/api/indexes/${INDEX_ID}/images/similar`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    },
  );
}

beforeEach(() => {
  authMock.mockReset();
  authenticateBearerMock.mockReset();
  searchImagesMock.mockReset();
  forOrgMock.mockReset();
  Object.values(prismaMock).forEach((m) =>
    Object.values(m).forEach((fn) => (fn as ReturnType<typeof vi.fn>).mockReset()),
  );

  authenticateBearerMock.mockResolvedValue({
    via: "api-key",
    userId: USER_ID,
    organizationId: ORG_ID,
    scope: ApiKeyScope.WRITE,
    keyId: "key_y",
  });
  prismaMock.knowledgeIndex.findUnique.mockResolvedValue({
    id: INDEX_ID,
    organizationId: ORG_ID,
  });
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: Role.MEMBER,
  });
});

describe("POST /api/indexes/:id/images/similar", () => {
  it("loads the image vector, searches, strips self, and returns hits", async () => {
    prismaMock.imageEmbedding.findUnique.mockResolvedValueOnce({
      id: "img_src",
      vector: [0.5, 0.5, 0.5, 0.5],
      organizationId: ORG_ID,
      indexId: INDEX_ID,
      imagePath: "images/src.png",
    });
    searchImagesMock.mockResolvedValueOnce([
      { id: "img_src", score: 1.0, imagePath: "images/src.png" }, // self — must be stripped
      {
        id: "img_b",
        score: 0.93,
        imagePath: "images/b.png",
        caption: "Diagram B",
        ocrText: null,
        page: 4,
        documentId: "doc_x",
        chunkId: "chunk_b",
      },
    ]);
    forOrgMock.mockResolvedValueOnce({
      id: "postgres",
      supportsImages: true,
      searchImages: searchImagesMock,
    });
    prismaMock.imageEmbedding.findMany.mockResolvedValueOnce([
      {
        id: "img_b",
        width: 1024,
        height: 768,
        mimeType: "image/png",
        documentId: "doc_x",
      },
    ]);

    const res = await POST(req({ imageId: "img_src", topK: 3 }), params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.sourceImageId).toBe("img_src");
    expect(body.hits).toHaveLength(1);
    expect(body.hits[0].id).toBe("img_b");
    // The store should have been asked for topK + 1 candidates so the
    // self-strip leaves the user with the right count.
    expect(searchImagesMock).toHaveBeenCalledWith(
      ORG_ID,
      INDEX_ID,
      [0.5, 0.5, 0.5, 0.5],
      { topK: 4 },
    );
  });

  it("returns 404 for a non-existent imageId", async () => {
    prismaMock.imageEmbedding.findUnique.mockResolvedValueOnce(null);
    const res = await POST(req({ imageId: "img_unknown" }), params());
    expect(res.status).toBe(404);
    expect(searchImagesMock).not.toHaveBeenCalled();
  });

  it("returns 404 when the image lives in a different index", async () => {
    prismaMock.imageEmbedding.findUnique.mockResolvedValueOnce({
      id: "img_src",
      vector: [0.5, 0.5, 0.5, 0.5],
      organizationId: ORG_ID,
      indexId: "idx_other",
      imagePath: "images/src.png",
    });
    const res = await POST(req({ imageId: "img_src" }), params());
    expect(res.status).toBe(404);
  });

  it("returns 403 when the image is in another organization", async () => {
    prismaMock.imageEmbedding.findUnique.mockResolvedValueOnce({
      id: "img_src",
      vector: [0.5, 0.5, 0.5, 0.5],
      organizationId: "org_other",
      indexId: INDEX_ID,
      imagePath: "images/src.png",
    });
    const res = await POST(req({ imageId: "img_src" }), params());
    expect(res.status).toBe(403);
  });
});
