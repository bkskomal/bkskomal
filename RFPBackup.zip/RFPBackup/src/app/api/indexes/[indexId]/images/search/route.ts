// Image search by natural-language description.
//
// Encodes the caller's free-text query through the CLIP text encoder
// (`embedTextForImageSearch`), which produces a 512-d L2-normalised vector
// in the same space as the stored image embeddings. We then hand that
// vector to the org's resolved VectorStore and return the top-K hits.
//
// Coordination notes:
//   - IM1 owns the CLIP module (`@/lib/ai/clip`). We import `getClipEmbedder`
//     directly rather than reaching through retrieval.ts (IM2 owns that).
//   - IM2 owns vector-store image methods. We call `searchImages` on the
//     resolved store; if the backend somehow lacks the method we 501 with a
//     clear message rather than crashing.
//   - WRITE scope is required because text→image search is a generation-side
//     surface (used during response drafting). READ scope still gets the
//     hits via the KB viewer's gallery search box, which is also gated by
//     this same WRITE check today — tightening to READ later is purely a
//     scope-rank flip in `requireIndexAccessForRequest`.

import { z } from "zod";
import { ApiKeyScope, Role } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { requireIndexAccessForRequest } from "@/lib/authz";
import { ValidationError } from "@/lib/errors";
import { vectorStoreResolver } from "@/lib/ai/vector";
import { getClipEmbedder } from "@/lib/ai/clip";
import { imagesSearchedTotal } from "@/lib/metrics";
import { prisma } from "@/lib/prisma";

const bodySchema = z.object({
  query: z.string().min(1).max(500),
  topK: z.number().int().min(1).max(50).optional(),
});

export const POST = withApiHandler<{ indexId: string }>(async (req, { params }) => {
  const { indexId } = await params;
  const { index } = await requireIndexAccessForRequest(req, indexId, {
    minScope: ApiKeyScope.WRITE,
    minRole: Role.MEMBER,
  });

  let body: z.infer<typeof bodySchema>;
  try {
    body = bodySchema.parse(await req.json());
  } catch (err) {
    if (err instanceof z.ZodError) {
      throw new ValidationError("Invalid request body", err.flatten());
    }
    throw err;
  }
  const topK = body.topK ?? 8;

  // Encode the query in CLIP space. This is cheap once the model is warm
  // (~30ms on CPU); first call may load ~85MB of weights and take a few
  // seconds. We let the request hang for that — the user explicitly asked
  // for an image search and the alternative (background warm-up) would
  // require a separate /api/_warm route we don't have yet.
  const embedder = getClipEmbedder();
  const queryVector = await embedder.embedTextForImageSearch(body.query);

  const store = await vectorStoreResolver.forOrg(index.organizationId);
  // Guard: backends that don't implement the multimodal extension. Both
  // PostgresVectorStore and MilvusVectorStore declare `supportsImages = true`
  // in the IM2 work; this branch is the safety net for a hypothetical
  // future backend that lands without image support.
  if (
    typeof (store as { searchImages?: unknown }).searchImages !== "function" ||
    (store as { supportsImages?: boolean }).supportsImages === false
  ) {
    return Response.json(
      {
        error: "This organization's vector backend does not support image search",
        code: "image_search_unsupported",
        hits: [],
      },
      { status: 501 },
    );
  }

  // Backend-typed cast — narrowed by the guard above. We avoid pulling
  // VectorStoreImages into the public surface here so this route stays
  // resilient if the contract evolves.
  const hits = await (
    store as unknown as {
      searchImages: (
        orgId: string,
        indexId: string,
        v: number[],
        opts: { topK: number; minScore?: number },
      ) => Promise<
        Array<{
          id: string;
          score: number;
          imagePath?: string;
          caption?: string;
          ocrText?: string;
          page?: number;
          documentId?: string;
          chunkId?: string;
        }>
      >;
    }
  ).searchImages(index.organizationId, indexId, queryVector, { topK });

  imagesSearchedTotal.inc({
    backend: store.id ?? "postgres",
    mode: "text_query",
  });

  // Hydrate width/height + canonical mimeType from the DB so the UI can
  // render thumbnails with intrinsic sizing. The list is bounded by topK
  // (≤ 50) so this fan-out is cheap.
  const imageRows = await prisma.imageEmbedding.findMany({
    where: { id: { in: hits.map((h) => h.id) } },
    select: {
      id: true,
      width: true,
      height: true,
      mimeType: true,
      documentId: true,
    },
  });
  const byId = new Map(imageRows.map((r) => [r.id, r]));

  return Response.json({
    query: body.query,
    topK,
    hits: hits.map((h) => {
      const meta = byId.get(h.id);
      return {
        id: h.id,
        score: h.score,
        imagePath: h.imagePath,
        caption: h.caption ?? null,
        ocrText: h.ocrText ?? null,
        page: h.page ?? null,
        documentId: h.documentId ?? meta?.documentId ?? null,
        chunkId: h.chunkId ?? null,
        width: meta?.width ?? null,
        height: meta?.height ?? null,
        mimeType: meta?.mimeType ?? null,
      };
    }),
  });
});
