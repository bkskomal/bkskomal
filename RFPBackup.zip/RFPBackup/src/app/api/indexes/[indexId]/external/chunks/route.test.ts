import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ApiKeyScope, Role } from "@prisma/client";

const {
  authMock,
  authenticateBearerMock,
  prismaMock,
  resolveAiConfigMock,
  vectorResolverMock,
  upsertMock,
  auditMock,
  rateLimitMock,
} = vi.hoisted(() => ({
  authMock: vi.fn(),
  authenticateBearerMock: vi.fn(),
  prismaMock: {
    knowledgeIndex: { findUnique: vi.fn() },
    membership: { findUnique: vi.fn() },
    document: { findMany: vi.fn(), updateMany: vi.fn() },
    documentChunk: { create: vi.fn() },
    $transaction: vi.fn(),
  },
  resolveAiConfigMock: vi.fn(),
  vectorResolverMock: vi.fn(),
  upsertMock: vi.fn().mockResolvedValue(undefined),
  auditMock: vi.fn().mockResolvedValue(undefined),
  rateLimitMock: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/auth-bearer", () => ({
  authenticateBearer: (...args: unknown[]) => authenticateBearerMock(...args),
}));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/ai/config", () => ({
  resolveAiConfig: (...args: unknown[]) => resolveAiConfigMock(...args),
}));
vi.mock("@/lib/ai/vector", () => ({
  vectorStoreResolver: {
    writersForOrg: (...args: unknown[]) => vectorResolverMock(...args),
  },
}));
vi.mock("@/lib/audit", () => ({
  audit: (...args: unknown[]) => auditMock(...args),
  auditContextFromRequest: () => ({}),
}));
vi.mock("@/lib/rate-limit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/rate-limit")>(
    "@/lib/rate-limit",
  );
  return {
    ...actual,
    rateLimit: (...args: unknown[]) => rateLimitMock(...args),
  };
});

import { POST } from "./route";

const INDEX_ID = "idx_chunks";
const ORG_ID = "org_chunks";
const USER_ID = "user_chunks";
const KEY_ID = "key_chunks";
const DIM = 4;

function buildEmbedding(): number[] {
  return [0.1, 0.2, 0.3, 0.4];
}

function makeRequest(body: unknown): Request {
  return new Request(
    `http://localhost/api/indexes/${INDEX_ID}/external/chunks`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    },
  );
}

const params = () => ({ params: Promise.resolve({ indexId: INDEX_ID }) });

beforeEach(() => {
  authMock.mockReset();
  authenticateBearerMock.mockReset();
  upsertMock.mockReset();
  upsertMock.mockResolvedValue(undefined);
  vectorResolverMock.mockReset();
  resolveAiConfigMock.mockReset();
  auditMock.mockReset();
  auditMock.mockResolvedValue(undefined);
  rateLimitMock.mockReset();
  rateLimitMock.mockResolvedValue(undefined);
  Object.values(prismaMock).forEach((m) => {
    if (typeof m === "function") return;
    Object.values(m).forEach((fn) => (fn as ReturnType<typeof vi.fn>).mockReset());
  });
  (prismaMock.$transaction as ReturnType<typeof vi.fn>).mockReset();

  authenticateBearerMock.mockResolvedValue({
    via: "api-key",
    userId: USER_ID,
    organizationId: ORG_ID,
    scope: ApiKeyScope.WRITE,
    keyId: KEY_ID,
  });
  prismaMock.knowledgeIndex.findUnique.mockResolvedValue({
    id: INDEX_ID,
    name: "Chunks KB",
    organizationId: ORG_ID,
  });
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: Role.MEMBER,
  });
  resolveAiConfigMock.mockResolvedValue({ embedding: { dimensions: DIM } });
  vectorResolverMock.mockResolvedValue([
    { supportsHybrid: true, upsert: upsertMock },
  ]);
  prismaMock.document.findMany.mockResolvedValue([{ id: "doc_a" }]);
  prismaMock.document.updateMany.mockResolvedValue({ count: 1 });
  // $transaction receives an array of pending Prisma promises in this code
  // path. We just resolve them all and return the resulting array — the
  // route reads `id` and `documentId` off each entry.
  (prismaMock.$transaction as ReturnType<typeof vi.fn>).mockImplementation(
    async (calls: Promise<unknown>[]) => {
      const results = await Promise.all(calls);
      return results;
    },
  );
  prismaMock.documentChunk.create.mockImplementation(async (args: {
    data: { documentId: string; ordinal: number };
  }) => ({
    id: `chunk_${args.data.documentId}_${args.data.ordinal}`,
    documentId: args.data.documentId,
  }));
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe("POST /api/indexes/:id/external/chunks", () => {
  it("upserts pre-embedded chunks via the resolver and audits", async () => {
    const req = makeRequest({
      chunks: [
        {
          documentId: "doc_a",
          content: "hello world",
          ordinal: 0,
          embedding: buildEmbedding(),
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.accepted).toBe(1);
    expect(body.errors).toEqual([]);

    expect(upsertMock).toHaveBeenCalledTimes(1);
    const upserted = upsertMock.mock.calls[0][0];
    expect(upserted).toHaveLength(1);
    expect(upserted[0]).toMatchObject({
      id: "chunk_doc_a_0",
      embedding: buildEmbedding(),
      metadata: expect.objectContaining({
        documentId: "doc_a",
        indexId: INDEX_ID,
        organizationId: ORG_ID,
      }),
    });

    expect(prismaMock.document.updateMany).toHaveBeenCalledWith({
      where: { id: { in: ["doc_a"] } },
      data: { status: "INDEXED" },
    });
    expect(auditMock).toHaveBeenCalledWith(
      expect.objectContaining({
        event: "EXTERNAL_INGEST_CHUNKS",
        organizationId: ORG_ID,
        metadata: expect.objectContaining({ count: 1 }),
      }),
    );
  });

  it("returns 400 when an embedding length doesn't match the org's dimensions", async () => {
    const req = makeRequest({
      chunks: [
        {
          documentId: "doc_a",
          content: "wrong length",
          ordinal: 0,
          embedding: [0.1, 0.2], // length 2, expected 4
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.code).toBe("validation_error");
    expect(JSON.stringify(body.details ?? body)).toContain("embedding length");
    expect(upsertMock).not.toHaveBeenCalled();
  });

  it("forwards a sparseEmbedding to the writer when supplied", async () => {
    const req = makeRequest({
      chunks: [
        {
          documentId: "doc_a",
          content: "we use AES-256 encryption",
          ordinal: 0,
          embedding: buildEmbedding(),
          sparseEmbedding: { indices: [101, 202], values: [1.5, 0.7] },
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(200);
    const upserted = upsertMock.mock.calls[0][0];
    expect(upserted[0].sparseEmbedding).toEqual({
      indices: [101, 202],
      values: [1.5, 0.7],
    });
  });

  it("rejects an unknown documentId with 404", async () => {
    prismaMock.document.findMany.mockResolvedValueOnce([]); // doc_unknown isn't in this index
    const req = makeRequest({
      chunks: [
        {
          documentId: "doc_unknown",
          content: "x",
          ordinal: 0,
          embedding: buildEmbedding(),
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(404);
    expect(upsertMock).not.toHaveBeenCalled();
  });

  it("rejects a sparseEmbedding with mismatched indices/values lengths", async () => {
    const req = makeRequest({
      chunks: [
        {
          documentId: "doc_a",
          content: "x",
          ordinal: 0,
          embedding: buildEmbedding(),
          sparseEmbedding: { indices: [1, 2, 3], values: [0.5] },
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(400);
  });

  it("returns 401 without a Bearer token", async () => {
    authenticateBearerMock.mockResolvedValue(null);
    authMock.mockResolvedValue(null);
    const req = makeRequest({
      chunks: [
        { documentId: "doc_a", content: "x", ordinal: 0, embedding: buildEmbedding() },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(401);
  });
});
