// External delete — DELETE /api/indexes/:indexId/external/documents/:documentId
//
// Removes a Document and cascades its chunks (Prisma onDelete: Cascade).
// Also fires a vector-store delete so any backend-mirrored vectors are
// pruned on the same wire as the Postgres rows.

import { ApiKeyScope } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { NotFoundError } from "@/lib/errors";
import { requireIndexAccessForRequest } from "@/lib/authz";
import { prisma } from "@/lib/prisma";
import { deleteUpload } from "@/lib/storage";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { vectorStoreResolver } from "@/lib/ai/vector";
import { log } from "@/lib/logger";

export const DELETE = withApiHandler<{ indexId: string; documentId: string }>(
  async (req, { params }) => {
    const { indexId, documentId } = await params;
    const { index, principal } = await requireIndexAccessForRequest(req, indexId, {
      minScope: ApiKeyScope.WRITE,
    });

    const doc = await prisma.document.findFirst({
      where: { id: documentId, indexId },
      include: { chunks: { select: { id: true } } },
    });
    if (!doc) throw new NotFoundError("Document not found in this index");

    const chunkIds = doc.chunks.map((c) => c.id);

    // Best-effort vector-store delete — Postgres just drops rows, Milvus
    // honours the chunkIds via partition_key=orgId. We swallow failures so
    // the Postgres delete still proceeds (the next reindex sweep will tidy up).
    if (chunkIds.length > 0) {
      try {
        const stores = await vectorStoreResolver.writersForOrg(index.organizationId);
        await Promise.all(
          stores.map((s) => s.delete(index.organizationId, chunkIds)),
        );
      } catch (err) {
        log().warn(
          {
            err: err instanceof Error ? err.message : String(err),
            documentId,
            indexId,
          },
          "vector-store delete failed during external doc delete; continuing",
        );
      }
    }

    await prisma.document.delete({ where: { id: documentId } });
    if (doc.storagePath) {
      void deleteUpload(doc.storagePath);
    }

    void audit({
      event: "EXTERNAL_DELETE_DOCUMENT",
      actorId: principal.userId,
      organizationId: index.organizationId,
      targetType: "document",
      targetId: documentId,
      metadata: {
        fileName: doc.fileName,
        chunkCount: chunkIds.length,
        apiKeyId: principal.via === "api-key" ? principal.keyId : null,
      },
      ...auditContextFromRequest(req),
    });

    return Response.json({ ok: true, deletedChunks: chunkIds.length });
  },
);
