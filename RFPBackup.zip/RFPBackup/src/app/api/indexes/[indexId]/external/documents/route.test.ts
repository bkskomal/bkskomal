import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ApiKeyScope, Role } from "@prisma/client";

const {
  authMock,
  authenticateBearerMock,
  prismaMock,
  saveUploadMock,
  ingestDocumentMock,
  ingestDocumentFromContentMock,
  auditMock,
  rateLimitMock,
} = vi.hoisted(() => ({
  authMock: vi.fn(),
  authenticateBearerMock: vi.fn(),
  prismaMock: {
    knowledgeIndex: { findUnique: vi.fn() },
    membership: { findUnique: vi.fn() },
    document: { create: vi.fn() },
  },
  saveUploadMock: vi.fn(),
  ingestDocumentMock: vi.fn(),
  ingestDocumentFromContentMock: vi.fn(),
  auditMock: vi.fn().mockResolvedValue(undefined),
  rateLimitMock: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("@/lib/auth", () => ({ auth: () => authMock() }));
vi.mock("@/lib/auth-bearer", () => ({
  authenticateBearer: (...args: unknown[]) => authenticateBearerMock(...args),
}));
vi.mock("@/lib/prisma", () => ({ prisma: prismaMock }));
vi.mock("@/lib/storage", () => ({
  saveUpload: (...args: unknown[]) => saveUploadMock(...args),
  deleteUpload: vi.fn(),
}));
vi.mock("@/lib/indexing", () => ({
  ingestDocument: (...args: unknown[]) => ingestDocumentMock(...args),
  ingestDocumentFromContent: (...args: unknown[]) => ingestDocumentFromContentMock(...args),
}));
vi.mock("@/lib/audit", () => ({
  audit: (...args: unknown[]) => auditMock(...args),
  auditContextFromRequest: () => ({}),
}));
vi.mock("@/lib/rate-limit", async () => {
  const actual = await vi.importActual<typeof import("@/lib/rate-limit")>(
    "@/lib/rate-limit",
  );
  return {
    ...actual,
    rateLimit: (...args: unknown[]) => rateLimitMock(...args),
  };
});

import { POST } from "./route";

const INDEX_ID = "idx_external_1";
const ORG_ID = "org_external_1";
const USER_ID = "user_external_1";
const KEY_ID = "key_external_1";

const indexFixture = {
  id: INDEX_ID,
  name: "External KB",
  organizationId: ORG_ID,
};

function makeRequest(body: unknown, headers: Record<string, string> = {}): Request {
  return new Request(
    `http://localhost/api/indexes/${INDEX_ID}/external/documents`,
    {
      method: "POST",
      headers: { "content-type": "application/json", ...headers },
      body: JSON.stringify(body),
    },
  );
}

const params = () => ({ params: Promise.resolve({ indexId: INDEX_ID }) });

beforeEach(() => {
  authMock.mockReset();
  authenticateBearerMock.mockReset();
  Object.values(prismaMock).forEach((m) =>
    Object.values(m).forEach((fn) => (fn as ReturnType<typeof vi.fn>).mockReset()),
  );
  saveUploadMock.mockReset();
  ingestDocumentMock.mockReset();
  ingestDocumentMock.mockResolvedValue(undefined);
  ingestDocumentFromContentMock.mockReset();
  ingestDocumentFromContentMock.mockResolvedValue(undefined);
  auditMock.mockReset();
  rateLimitMock.mockReset();
  rateLimitMock.mockResolvedValue(undefined);
  auditMock.mockResolvedValue(undefined);

  // Default: writeable bearer, valid org membership.
  authenticateBearerMock.mockResolvedValue({
    via: "api-key",
    userId: USER_ID,
    organizationId: ORG_ID,
    scope: ApiKeyScope.WRITE,
    keyId: KEY_ID,
  });
  prismaMock.knowledgeIndex.findUnique.mockResolvedValue(indexFixture);
  prismaMock.membership.findUnique.mockResolvedValue({
    userId: USER_ID,
    organizationId: ORG_ID,
    role: Role.MEMBER,
  });
  saveUploadMock.mockResolvedValue({ storagePath: "/tmp/uploaded" });
  prismaMock.document.create.mockImplementation(async ({ data }: { data: { fileName: string } }) => ({
    id: `doc_${data.fileName}`,
    status: "PENDING",
    fileName: data.fileName,
  }));
});

afterEach(() => {
  vi.restoreAllMocks();
});

describe("POST /api/indexes/:id/external/documents", () => {
  it("accepts a content-only document and routes through ingestDocumentFromContent", async () => {
    const req = makeRequest({
      documents: [
        {
          name: "SOC2 Audit",
          fileName: "soc2.txt",
          mimeType: "text/plain",
          content: "We use AES-256 encryption at rest.",
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(202);
    const body = await res.json();
    expect(body.accepted).toBe(1);
    expect(body.documents[0].fileName).toBe("soc2.txt");

    expect(ingestDocumentFromContentMock).toHaveBeenCalledTimes(1);
    expect(ingestDocumentFromContentMock).toHaveBeenCalledWith(
      "doc_soc2.txt",
      "We use AES-256 encryption at rest.",
    );
    expect(ingestDocumentMock).not.toHaveBeenCalled();
    expect(auditMock).toHaveBeenCalledWith(
      expect.objectContaining({
        event: "EXTERNAL_INGEST_DOCUMENTS",
        organizationId: ORG_ID,
        metadata: expect.objectContaining({ count: 1, mode: "content" }),
      }),
    );
  });

  it("accepts a base64 document and routes through the parser pipeline (ingestDocument)", async () => {
    const raw = Buffer.from("hello world", "utf8").toString("base64");
    const req = makeRequest({
      documents: [
        {
          name: "Whitepaper",
          fileName: "wp.pdf",
          mimeType: "application/pdf",
          contentBase64: raw,
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(202);
    expect(ingestDocumentMock).toHaveBeenCalledTimes(1);
    expect(ingestDocumentMock).toHaveBeenCalledWith("doc_wp.pdf");
    expect(ingestDocumentFromContentMock).not.toHaveBeenCalled();
    expect(auditMock).toHaveBeenCalledWith(
      expect.objectContaining({
        metadata: expect.objectContaining({ mode: "base64" }),
      }),
    );
  });

  it("returns 401 when no API key is supplied (and no session)", async () => {
    authenticateBearerMock.mockResolvedValue(null);
    authMock.mockResolvedValue(null);
    const req = makeRequest({ documents: [{ name: "x", fileName: "x.txt", mimeType: "text/plain", content: "x" }] });
    const res = await POST(req, params());
    expect(res.status).toBe(401);
  });

  it("returns 403 when the API key has only READ scope", async () => {
    authenticateBearerMock.mockResolvedValue({
      via: "api-key",
      userId: USER_ID,
      organizationId: ORG_ID,
      scope: ApiKeyScope.READ,
      keyId: KEY_ID,
    });
    const req = makeRequest({
      documents: [{ name: "x", fileName: "x.txt", mimeType: "text/plain", content: "x" }],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(403);
  });

  it("returns 400 when both content and contentBase64 are present", async () => {
    const req = makeRequest({
      documents: [
        {
          name: "bad",
          fileName: "x.txt",
          mimeType: "text/plain",
          content: "hi",
          contentBase64: Buffer.from("hi").toString("base64"),
        },
      ],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(400);
  });

  it("forwards rate-limit rejections (429)", async () => {
    const { RateLimitError } = await vi.importActual<typeof import("@/lib/rate-limit")>(
      "@/lib/rate-limit",
    );
    rateLimitMock.mockRejectedValueOnce(new RateLimitError("too many", 30));
    const req = makeRequest({
      documents: [{ name: "x", fileName: "x.txt", mimeType: "text/plain", content: "x" }],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(429);
    expect(res.headers.get("Retry-After")).toBe("30");
  });

  it("rejects cross-org API keys with 403", async () => {
    authenticateBearerMock.mockResolvedValue({
      via: "api-key",
      userId: USER_ID,
      organizationId: "other_org",
      scope: ApiKeyScope.WRITE,
      keyId: KEY_ID,
    });
    const req = makeRequest({
      documents: [{ name: "x", fileName: "x.txt", mimeType: "text/plain", content: "x" }],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(403);
  });

  it("returns 404 when the index doesn't exist", async () => {
    prismaMock.knowledgeIndex.findUnique.mockResolvedValue(null);
    const req = makeRequest({
      documents: [{ name: "x", fileName: "x.txt", mimeType: "text/plain", content: "x" }],
    });
    const res = await POST(req, params());
    expect(res.status).toBe(404);
  });
});
