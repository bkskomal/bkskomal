// External pre-embedded chunk push — POST /api/indexes/:indexId/external/chunks
//
// For ETL pipelines that have already done parsing AND embedding upstream
// (e.g. a Spark job that batch-embeds with the org's embedding model and
// then drops the vectors here). We persist the DocumentChunk row, then
// hand the embeddings to the per-org VectorStore via the resolver — same
// path as the in-process indexer, just bypassing parse + embed.
//
// Validates each chunk's embedding length against the org's
// `embeddingDimensions` so a misconfigured pipeline is rejected up front
// rather than producing garbage retrieval later.

import { z } from "zod";
import { ApiKeyScope } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { NotFoundError, ValidationError } from "@/lib/errors";
import { requireIndexAccessForRequest } from "@/lib/authz";
import { prisma } from "@/lib/prisma";
import { resolveAiConfig } from "@/lib/ai/config";
import { vectorStoreResolver } from "@/lib/ai/vector";
import type { ChunkVec } from "@/lib/ai/vector/types";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";

const sparseVectorSchema = z.object({
  indices: z.array(z.number().int().nonnegative()),
  values: z.array(z.number()),
});

const chunkInputSchema = z
  .object({
    documentId: z.string().min(1),
    content: z.string().min(1),
    ordinal: z.number().int().nonnegative(),
    page: z.number().int().positive().optional(),
    section: z.string().max(500).optional(),
    kind: z.string().max(50).optional(),
    embedding: z.array(z.number()).min(1),
    sparseEmbedding: sparseVectorSchema.optional(),
  })
  .refine(
    (c) =>
      !c.sparseEmbedding ||
      c.sparseEmbedding.indices.length === c.sparseEmbedding.values.length,
    { message: "sparseEmbedding indices and values must be the same length" },
  );

const bodySchema = z.object({
  chunks: z.array(chunkInputSchema).min(1).max(500),
});

export type ExternalChunkInput = z.infer<typeof chunkInputSchema>;

export const POST = withApiHandler<{ indexId: string }>(async (req, { params }) => {
  const { indexId } = await params;
  const { index, principal } = await requireIndexAccessForRequest(req, indexId, {
    minScope: ApiKeyScope.WRITE,
  });

  await rateLimit(RATE_LIMITS.externalIngest, {
    userId: principal.userId,
    orgId: index.organizationId,
    route: "POST /api/indexes/:id/external/chunks",
  });

  const body = bodySchema.parse(await req.json());
  const orgId = index.organizationId;

  // Embedding dimension check against the org's resolved AI config. Vectors
  // of the wrong length would silently degrade retrieval, so reject early.
  const aiConfig = await resolveAiConfig(orgId);
  const expectedDim = aiConfig.embedding.dimensions;

  const errors: string[] = [];
  const valid: ExternalChunkInput[] = [];
  for (const c of body.chunks) {
    if (c.embedding.length !== expectedDim) {
      errors.push(
        `chunk[ordinal=${c.ordinal}] documentId=${c.documentId}: embedding length ${c.embedding.length} != org embeddingDimensions ${expectedDim}`,
      );
      continue;
    }
    valid.push(c);
  }

  // Resolve all referenced documents in ONE round-trip and ensure they
  // belong to this index. Unknown docs are rejected — caller must create
  // them via /external/documents first.
  const refDocIds = Array.from(new Set(valid.map((c) => c.documentId)));
  if (refDocIds.length > 0) {
    const known = await prisma.document.findMany({
      where: { id: { in: refDocIds }, indexId },
      select: { id: true },
    });
    const knownSet = new Set(known.map((d) => d.id));
    if (knownSet.size !== refDocIds.length) {
      const missing = refDocIds.filter((id) => !knownSet.has(id));
      throw new NotFoundError(
        `Unknown documentId(s) in this index: ${missing.join(", ")}`,
      );
    }
  }

  if (valid.length === 0) {
    if (errors.length > 0) {
      throw new ValidationError("All chunks failed validation", { errors });
    }
    return Response.json({ accepted: 0, errors });
  }

  // Persist DocumentChunk rows first (with empty Float[] embedding — the
  // VectorStore upsert is the source of truth for the actual vector). Use
  // a single createMany call where possible.
  const created = await prisma.$transaction(
    valid.map((c) =>
      prisma.documentChunk.create({
        data: {
          documentId: c.documentId,
          ordinal: c.ordinal,
          content: c.content,
          page: c.page ?? null,
          section: c.section ?? null,
          kind: c.kind ?? null,
          // Postgres VectorStore writes the real embedding; Milvus stores
          // it on its side. We seed an empty array so the column type is
          // satisfied even if no writer ever fills it (defensive).
          embedding: [],
        },
        select: { id: true, documentId: true },
      }),
    ),
  );

  // Build ChunkVec inputs for the resolver — one writer call per backend.
  const chunkVecs: ChunkVec[] = created.map((row, i) => {
    const c = valid[i];
    return {
      id: row.id,
      embedding: c.embedding,
      // Caller-supplied sparse vector is forwarded as-is. When the backend
      // doesn't support hybrid (Postgres) the field is silently ignored.
      sparseEmbedding: c.sparseEmbedding,
      metadata: {
        documentId: c.documentId,
        indexId,
        organizationId: orgId,
        section: c.section,
        kind: c.kind,
        page: c.page,
      },
    } satisfies ChunkVec;
  });

  const writers = await vectorStoreResolver.writersForOrg(orgId);
  await Promise.all(writers.map((w) => w.upsert(chunkVecs)));

  // Mark touched documents as INDEXED so retrieval picks them up. Idempotent.
  await prisma.document.updateMany({
    where: { id: { in: Array.from(new Set(valid.map((c) => c.documentId))) } },
    data: { status: "INDEXED" },
  });

  void audit({
    event: "EXTERNAL_INGEST_CHUNKS",
    actorId: principal.userId,
    organizationId: orgId,
    targetType: "knowledge_index",
    targetId: indexId,
    metadata: {
      count: valid.length,
      errors: errors.length,
      apiKeyId: principal.via === "api-key" ? principal.keyId : null,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json({ accepted: valid.length, errors });
});
