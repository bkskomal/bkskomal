// External ingest endpoint — POST /api/indexes/:indexId/external/documents
//
// Bearer-auth-only entry point intended for NiFi / Airflow / n8n / generic
// ETL jobs. The caller supplies one or more documents per request, with
// either ALREADY-EXTRACTED text (`content`) or RAW BYTES (`contentBase64`)
// to feed through the parser pipeline. Each item is persisted as a Document
// row, parsed (when applicable), chunked, embedded, and upserted through
// the per-org VectorStore (Postgres or Milvus).
//
// Auth:  API key with WRITE scope (sessions also accepted for human-in-the-
//        loop testing, but the endpoint exists primarily for machines).
// Limit: RATE_LIMITS.externalIngest = 100/min per org.
// Audit: EXTERNAL_INGEST_DOCUMENTS with `{ count, mode }` metadata.

import { z } from "zod";
import { ApiKeyScope } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { ValidationError } from "@/lib/errors";
import { requireIndexAccessForRequest } from "@/lib/authz";
import { prisma } from "@/lib/prisma";
import { saveUpload } from "@/lib/storage";
import { detectMime } from "@/lib/parsers";
import { ingestDocument, ingestDocumentFromContent } from "@/lib/indexing";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { rateLimit, RATE_LIMITS } from "@/lib/rate-limit";
import { log } from "@/lib/logger";

// One doc input. Either `content` (already-text — skip parser) OR
// `contentBase64` (raw bytes — feed through parseAndProcess). Exactly one
// is required.
const docInputSchema = z
  .object({
    name: z.string().min(1).max(200),
    fileName: z.string().min(1).max(255),
    mimeType: z.string().min(1).max(100),
    sourceUrl: z.string().url().optional(),
    content: z.string().optional(),
    contentBase64: z.string().optional(),
    sourceDate: z.string().datetime().optional(),
  })
  .refine(
    (d) =>
      (d.content !== undefined && d.contentBase64 === undefined) ||
      (d.content === undefined && d.contentBase64 !== undefined),
    {
      message: "Exactly one of `content` or `contentBase64` must be provided",
    },
  );

const bodySchema = z.object({
  documents: z.array(docInputSchema).min(1).max(50),
});

export type ExternalDocInput = z.infer<typeof docInputSchema>;

interface AcceptedDoc {
  id: string;
  fileName: string;
  status: "PENDING" | "PROCESSING" | "INDEXED" | "FAILED";
}

export const POST = withApiHandler<{ indexId: string }>(async (req, { params }) => {
  const { indexId } = await params;
  const { index, principal } = await requireIndexAccessForRequest(req, indexId, {
    minScope: ApiKeyScope.WRITE,
  });

  await rateLimit(RATE_LIMITS.externalIngest, {
    userId: principal.userId,
    orgId: index.organizationId,
    route: "POST /api/indexes/:id/external/documents",
  });

  const body = bodySchema.parse(await req.json());

  const accepted: AcceptedDoc[] = [];
  let textOnly = 0;
  let bytesOnly = 0;

  for (const item of body.documents) {
    if (item.content !== undefined) textOnly += 1;
    else bytesOnly += 1;

    // Persist a Document row up-front so the caller gets back an id even if
    // parsing/embedding fails downstream. We always run ingest async (return
    // PENDING) so the request completes quickly — same pattern as the
    // interactive upload route.
    let storagePath = "";
    let fileSize = 0;
    if (item.contentBase64 !== undefined) {
      const buf = decodeBase64(item.contentBase64);
      const out = await saveUpload(`index/${indexId}/external`, item.fileName, buf);
      storagePath = out.storagePath;
      fileSize = buf.byteLength;
    } else {
      // For pre-parsed text, we still record an artifact on disk so
      // re-ingest paths (e.g. parser version bumps) have something to read.
      const buf = Buffer.from(item.content!, "utf8");
      const out = await saveUpload(`index/${indexId}/external`, item.fileName, buf);
      storagePath = out.storagePath;
      fileSize = buf.byteLength;
    }

    // For base64 path: validate the mime is one we can parse. For text path:
    // mime is informational only (the caller knows what they're describing).
    if (item.contentBase64 !== undefined) {
      const detected = detectMime(item.fileName);
      if (!detected && !item.mimeType) {
        throw new ValidationError(
          `Unsupported file type for ${item.fileName} — provide a recognized mimeType`,
        );
      }
    }

    const doc = await prisma.document.create({
      data: {
        indexId,
        name: item.name,
        fileName: item.fileName,
        fileSize,
        mimeType: item.mimeType,
        storagePath,
        sourceDate: item.sourceDate ? new Date(item.sourceDate) : null,
      },
      select: { id: true, status: true, fileName: true },
    });

    // Kick off ingest. Don't await — the caller polls /external/status to
    // observe completion. Errors are caught and logged so one bad doc doesn't
    // poison the request.
    if (item.content !== undefined) {
      const text = item.content;
      ingestDocumentFromContent(doc.id, text).catch((err) =>
        log().error(
          { err: err instanceof Error ? err.message : String(err), documentId: doc.id },
          "external content ingest failed",
        ),
      );
    } else {
      ingestDocument(doc.id).catch((err) =>
        log().error(
          { err: err instanceof Error ? err.message : String(err), documentId: doc.id },
          "external base64 ingest failed",
        ),
      );
    }

    accepted.push({ id: doc.id, fileName: doc.fileName, status: doc.status });
  }

  void audit({
    event: "EXTERNAL_INGEST_DOCUMENTS",
    actorId: principal.userId,
    organizationId: index.organizationId,
    targetType: "knowledge_index",
    targetId: indexId,
    metadata: {
      count: accepted.length,
      mode: textOnly > 0 && bytesOnly > 0 ? "mixed" : textOnly > 0 ? "content" : "base64",
      apiKeyId: principal.via === "api-key" ? principal.keyId : null,
    },
    ...auditContextFromRequest(req),
  });

  return Response.json(
    { accepted: accepted.length, documents: accepted },
    { status: 202 },
  );
});

function decodeBase64(b64: string): Buffer {
  // Strip data-URL prefix if present (NiFi's Base64EncodeContent doesn't add
  // one, but n8n's Move Binary Data sometimes does).
  const cleaned = b64.replace(/^data:[^;]+;base64,/, "");
  try {
    return Buffer.from(cleaned, "base64");
  } catch {
    throw new ValidationError("contentBase64 is not valid base64");
  }
}
