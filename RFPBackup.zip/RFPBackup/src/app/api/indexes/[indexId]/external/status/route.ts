// External status — GET /api/indexes/:indexId/external/status
//
// Lightweight health probe for ETL pipelines: returns document/chunk counts
// and the timestamp of the most recent ingest. Cheap enough that NiFi can
// poll it after a batch to confirm the docs landed.

import { ApiKeyScope } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { requireIndexAccessForRequest } from "@/lib/authz";
import { prisma } from "@/lib/prisma";

export const GET = withApiHandler<{ indexId: string }>(async (req, { params }) => {
  const { indexId } = await params;
  // READ scope is enough for status — orchestrators may want a separate
  // read-only key for monitoring.
  await requireIndexAccessForRequest(req, indexId, { minScope: ApiKeyScope.READ });

  const [documentCount, chunkCount, lastDoc] = await Promise.all([
    prisma.document.count({ where: { indexId } }),
    prisma.documentChunk.count({ where: { document: { indexId } } }),
    prisma.document.findFirst({
      where: { indexId },
      orderBy: { updatedAt: "desc" },
      select: { updatedAt: true },
    }),
  ]);

  return Response.json({
    documentCount,
    chunkCount,
    lastIngestAt: lastDoc?.updatedAt?.toISOString() ?? null,
  });
});
