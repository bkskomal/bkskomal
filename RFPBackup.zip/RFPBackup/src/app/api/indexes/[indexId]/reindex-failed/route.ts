import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireIndexAccess } from "@/lib/authz";
import { ingestDocument } from "@/lib/indexing";
import { embed } from "@/lib/ai/embeddings";
import { SAMPLE_KB_DOCS } from "@/lib/sample-data";

/**
 * Re-trigger ingestion for every document in this index that's currently
 * FAILED or PENDING.
 *
 * Synthetic (sample) documents are re-embedded in place using the bundled
 * content; real (uploaded) documents are re-parsed from their storagePath.
 * Returns immediately; per-doc work runs in the background.
 */
export const POST = withApiHandler<{ indexId: string }>(async (_req, { params }) => {
  const { indexId } = await params;
  const { index } = await requireIndexAccess(indexId);
  const stuck = await prisma.document.findMany({
    where: { indexId, status: { in: ["FAILED", "PENDING"] } },
    select: { id: true, name: true, storagePath: true },
  });

  const sampleByName = new Map(SAMPLE_KB_DOCS.map((s) => [s.name, s.content]));
  let queuedReal = 0;
  let queuedSynthetic = 0;

  for (const d of stuck) {
    if (d.storagePath.startsWith("(synthetic)")) {
      const content = sampleByName.get(d.name);
      if (!content) continue;
      void reembedSynthetic(d.id, content, index.organizationId);
      queuedSynthetic++;
    } else {
      ingestDocument(d.id).catch((err) => console.error("[reindex-failed]", err));
      queuedReal++;
    }
  }

  return Response.json({ queued: queuedReal + queuedSynthetic, real: queuedReal, synthetic: queuedSynthetic });
});

async function reembedSynthetic(documentId: string, content: string, orgId: string): Promise<void> {
  await prisma.document.update({
    where: { id: documentId },
    data: { status: "PROCESSING", errorMessage: null },
  });
  try {
    await prisma.documentChunk.deleteMany({ where: { documentId } });
    const vec = await embed(content, orgId);
    await prisma.documentChunk.create({
      data: { documentId, ordinal: 0, content, embedding: vec },
    });
    await prisma.document.update({
      where: { id: documentId },
      data: { status: "INDEXED" },
    });
  } catch (e) {
    await prisma.document.update({
      where: { id: documentId },
      data: { status: "FAILED", errorMessage: e instanceof Error ? e.message : String(e) },
    });
  }
}
