import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireIndexAccess } from "@/lib/authz";
import { vectorStoreResolver, supportsImages } from "@/lib/ai/vector";
import { deleteUpload } from "@/lib/storage";
import { log } from "@/lib/logger";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ indexId: string }> }) {
  try {
    const { indexId } = await params;
    await requireIndexAccess(indexId);
    const index = await prisma.knowledgeIndex.findUnique({
      where: { id: indexId },
      include: {
        documents: {
          orderBy: { createdAt: "desc" },
          include: { _count: { select: { chunks: true } } },
        },
      },
    });
    return Response.json({ index });
  } catch (e) {
    return jsonError(e);
  }
}

const patchSchema = z.object({
  name: z.string().min(2).max(80).optional(),
  description: z.string().max(500).optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ indexId: string }> }) {
  try {
    const { indexId } = await params;
    await requireIndexAccess(indexId);
    const body = patchSchema.parse(await req.json());
    const index = await prisma.knowledgeIndex.update({ where: { id: indexId }, data: body });
    return Response.json({ index });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ indexId: string }> }) {
  try {
    const { indexId } = await params;
    await requireIndexAccess(indexId);

    // Capture the org id + storage paths up-front. The Prisma delete below
    // cascades the rows away — we need this metadata BEFORE the cascade fires.
    const idx = await prisma.knowledgeIndex.findUnique({
      where: { id: indexId },
      select: {
        organizationId: true,
        documents: { select: { id: true, storagePath: true } },
      },
    });
    if (!idx) return Response.json({ ok: true });

    // Vector-store cleanup (Milvus). Postgres backend stores embeddings on
    // the rows themselves, so the Prisma cascade handles it — for Milvus we
    // need to drop everything tagged with this indexId from the per-org
    // collections (chunks + images). Failures here are logged + swallowed:
    // orphaned vectors are recoverable via a re-index, but a hung delete
    // shouldn't block the UI from removing the KB.
    try {
      const writers = await vectorStoreResolver.writersForOrg(idx.organizationId);
      for (const w of writers) {
        try {
          await w.deleteIndex(idx.organizationId, indexId);
        } catch (err) {
          log().warn(
            {
              err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
              indexId,
              orgId: idx.organizationId,
            },
            "vector-store deleteIndex failed; continuing with cascade",
          );
        }
        if (supportsImages(w)) {
          try {
            await w.deleteImagesForIndex(idx.organizationId, indexId);
          } catch (err) {
            log().warn(
              {
                err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
                indexId,
                orgId: idx.organizationId,
              },
              "vector-store deleteImagesForIndex failed; continuing with cascade",
            );
          }
        }
      }
    } catch (err) {
      log().warn(
        {
          err: err instanceof Error ? { name: err.name, message: err.message } : { value: String(err) },
          indexId,
        },
        "vector-store resolver failed during KB delete; continuing with cascade",
      );
    }

    // Cascade-delete the Postgres rows (Documents → DocumentChunks +
    // ImageEmbeddings via onDelete: Cascade).
    await prisma.knowledgeIndex.delete({ where: { id: indexId } });

    // Best-effort filesystem cleanup. Already-gone files are silently ignored
    // inside deleteUpload.
    for (const d of idx.documents) {
      if (d.storagePath) await deleteUpload(d.storagePath);
    }

    return Response.json({
      ok: true,
      deletedDocuments: idx.documents.length,
    });
  } catch (e) {
    return jsonError(e);
  }
}
