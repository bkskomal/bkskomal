import { withApiHandler } from "@/lib/api-handler";
import { requireIndexAccess } from "@/lib/authz";
import { seedSampleDocs } from "@/lib/seed-docs";

export const POST = withApiHandler<{ indexId: string }>(async (_req, { params }) => {
  const { indexId } = await params;
  const { index } = await requireIndexAccess(indexId);
  const result = await seedSampleDocs(indexId, index.organizationId);
  return Response.json(result, { status: 201 });
});
