// DELETE → revoke a personal API key. Idempotent: if the key is already
// revoked or never existed for this user, we still respond 200 to keep the
// client flow simple.

import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { revokeApiKey } from "@/lib/api-keys";
import { prisma } from "@/lib/prisma";

export const DELETE = withApiHandler<{ keyId: string }>(async (req, { params }) => {
  const user = await requireUser();
  const { keyId } = await params;

  // Look up the key first so we can audit the org/prefix even though the
  // revoke is scoped by userId.
  const key = await prisma.apiKey.findFirst({
    where: { id: keyId, userId: user.id },
  });

  await revokeApiKey({ id: keyId, userId: user.id });

  if (key) {
    void audit({
      event: "API_KEY_REVOKED",
      actorId: user.id,
      organizationId: key.organizationId,
      targetType: "api_key",
      targetId: key.id,
      metadata: { name: key.name, prefix: key.prefix },
      ...auditContextFromRequest(req),
    });
  }

  return Response.json({ ok: true });
});
