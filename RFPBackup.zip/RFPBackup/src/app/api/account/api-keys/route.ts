// Personal API key management for the signed-in user.
//
// GET  → list this user's keys (no hash, no token)
// POST → mint a new key. The plaintext token is in the response body and is
//        the only time it will ever be visible — the client must surface it
//        immediately and warn the user to copy it.

import { z } from "zod";
import { ApiKeyScope } from "@prisma/client";
import { withApiHandler } from "@/lib/api-handler";
import { requireUser } from "@/lib/authz";
import { audit, auditContextFromRequest } from "@/lib/audit";
import { issueApiKey, listApiKeys } from "@/lib/api-keys";
import { ForbiddenError } from "@/lib/errors";
import { prisma } from "@/lib/prisma";

export const GET = withApiHandler(async () => {
  const user = await requireUser();
  const keys = await listApiKeys(user.id);
  return Response.json({ keys });
});

const postSchema = z.object({
  name: z.string().min(1).max(100),
  organizationId: z.string().min(1).nullable().optional(),
  scope: z.nativeEnum(ApiKeyScope).default(ApiKeyScope.READ),
  // 1 day .. 5 years; null = no expiry.
  expiresInDays: z.number().int().positive().max(365 * 5).nullable().optional(),
});

export const POST = withApiHandler(async (req) => {
  const user = await requireUser();
  const body = postSchema.parse(await req.json());

  // If they specified an org, make sure they're a member of it.
  if (body.organizationId) {
    const membership = await prisma.membership.findUnique({
      where: {
        userId_organizationId: { userId: user.id, organizationId: body.organizationId },
      },
    });
    if (!membership) {
      throw new ForbiddenError("Not a member of that organization");
    }
  }

  const expiresAt = body.expiresInDays
    ? new Date(Date.now() + body.expiresInDays * 24 * 60 * 60 * 1000)
    : null;

  const issued = await issueApiKey({
    name: body.name,
    userId: user.id,
    organizationId: body.organizationId ?? null,
    scope: body.scope,
    expiresAt,
  });

  void audit({
    event: "API_KEY_CREATED",
    actorId: user.id,
    organizationId: body.organizationId ?? null,
    targetType: "api_key",
    targetId: issued.id,
    metadata: { name: issued.name, scope: issued.scope, prefix: issued.prefix },
    ...auditContextFromRequest(req),
  });

  return Response.json({ key: issued }, { status: 201 });
});
