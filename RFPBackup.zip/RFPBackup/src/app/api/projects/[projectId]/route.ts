import { NextRequest } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { jsonError, requireProjectAccess } from "@/lib/authz";

export async function GET(_req: NextRequest, { params }: { params: Promise<{ projectId: string }> }) {
  try {
    const { projectId } = await params;
    await requireProjectAccess(projectId);
    const project = await prisma.project.findUnique({
      where: { id: projectId },
      include: {
        organization: { select: { id: true, name: true, slug: true } },
        defaultIndex: true,
        rfps: {
          orderBy: { createdAt: "desc" },
          include: { _count: { select: { questions: true } } },
        },
      },
    });
    return Response.json({ project });
  } catch (e) {
    return jsonError(e);
  }
}

const patchSchema = z.object({
  name: z.string().min(2).max(100).optional(),
  description: z.string().max(500).optional(),
  defaultIndexId: z.string().nullable().optional(),
  defaultPipelineTemplateId: z.string().nullable().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ projectId: string }> }) {
  try {
    const { projectId } = await params;
    await requireProjectAccess(projectId);
    const body = patchSchema.parse(await req.json());
    const project = await prisma.project.update({ where: { id: projectId }, data: body });
    return Response.json({ project });
  } catch (e) {
    return jsonError(e);
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ projectId: string }> }) {
  try {
    const { projectId } = await params;
    await requireProjectAccess(projectId);
    await prisma.project.delete({ where: { id: projectId } });
    return Response.json({ ok: true });
  } catch (e) {
    return jsonError(e);
  }
}
