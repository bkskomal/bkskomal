import { NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { withApiHandler } from "@/lib/api-handler";
import { requireProjectAccess } from "@/lib/authz";
import { ValidationError } from "@/lib/errors";
import { detectMime } from "@/lib/parsers";
import { saveUpload } from "@/lib/storage";
import { processRfp } from "@/lib/rfp-pipeline";
import { logActivity } from "@/lib/activity";
import { createRunForRfp } from "@/lib/pipeline/engine";

export const POST = withApiHandler<{ projectId: string }>(async (req, { params }) => {
  const { projectId } = await params;
  const { user } = await requireProjectAccess(projectId);

  const form = await (req as NextRequest).formData();
  const file = form.get("file");
  const title = (form.get("title") as string | null) ?? "";
  if (!(file instanceof File)) throw new ValidationError("Missing file");
  const mime = detectMime(file.name);
  if (!mime) throw new ValidationError(`Unsupported file type: ${file.name}`);

  const buf = Buffer.from(await file.arrayBuffer());
  const { storagePath } = await saveUpload(`rfp/${projectId}`, file.name, buf);

  const rfp = await prisma.rFP.create({
    data: {
      projectId,
      title: title || file.name,
      fileName: file.name,
      fileSize: file.size,
      mimeType: mime,
      storagePath,
    },
  });

  void logActivity({
    rfpId: rfp.id,
    actorId: user.id,
    kind: "RFP_UPLOADED",
    payload: { fileName: file.name, fileSize: file.size },
  });

  // Create the pipeline run + kick off async processing. The engine watches
  // RFP.status and will advance when EXTRACT_QUESTIONS finishes.
  void createRunForRfp(rfp.id);
  processRfp(rfp.id).catch((err) => console.error("[rfp pipeline]", err));

  return Response.json({ rfp }, { status: 201 });
});
