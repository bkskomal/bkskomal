import { notFound, redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { IndexDetailClient } from "./client";

export default async function IndexDetailPage({
  params,
}: {
  params: Promise<{ indexId: string }>;
}) {
  const { indexId } = await params;
  const session = await auth();
  if (!session?.user?.id) redirect("/auth/signin");

  const index = await prisma.knowledgeIndex.findUnique({
    where: { id: indexId },
    include: {
      documents: {
        orderBy: { createdAt: "desc" },
        include: { _count: { select: { chunks: true } } },
      },
    },
  });
  if (!index) notFound();
  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: { userId: session.user.id, organizationId: index.organizationId },
    },
  });
  if (!member) notFound();

  return (
    <IndexDetailClient
      index={{
        id: index.id,
        name: index.name,
        description: index.description,
        organizationId: index.organizationId,
      }}
      role={member.role}
      documents={index.documents.map((d) => ({
        id: d.id,
        name: d.name,
        fileName: d.fileName,
        fileSize: d.fileSize,
        status: d.status,
        chunkCount: d._count.chunks,
        errorMessage: d.errorMessage,
        createdAt: d.createdAt.toISOString(),
        sourceDate: d.sourceDate?.toISOString() ?? null,
        staleReason: d.staleReason,
        sourceUrl: d.sourceUrl ?? null,
      }))}
    />
  );
}
