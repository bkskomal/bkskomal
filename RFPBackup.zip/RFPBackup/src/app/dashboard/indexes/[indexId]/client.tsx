"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useDropzone } from "react-dropzone";
import {
  AlertTriangle,
  ArrowLeft,
  Clock,
  FileText,
  Globe,
  Library,
  Link2,
  Loader2,
  RefreshCw,
  Sparkles,
  Trash2,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { DocumentViewer } from "@/components/index/document-viewer";
import { cn, formatBytes, formatDate } from "@/lib/utils";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";

interface IdxInfo {
  id: string;
  name: string;
  description: string | null;
  organizationId: string;
}

interface DocRow {
  id: string;
  name: string;
  fileName: string;
  fileSize: number;
  status: string;
  chunkCount: number;
  errorMessage: string | null;
  createdAt: string;
  // Stale-source detection (Tier B2). `staleReason` is the tri-state stale
  // flag — non-null string means "the staleness rule flagged this doc", and
  // the string is the tooltip text. `sourceDate` is the detected/declared
  // "as of" date; null when we couldn't identify one.
  sourceDate: string | null;
  staleReason: string | null;
  // When ingested by URL scrape, the canonical URL it came from. null for
  // hand-uploaded files. Used by the UI to swap the file icon for a globe.
  sourceUrl?: string | null;
}

const STATUS_VARIANT: Record<string, "default" | "info" | "success" | "warning" | "destructive"> = {
  PENDING: "info",
  PROCESSING: "warning",
  INDEXED: "success",
  FAILED: "destructive",
};

export function IndexDetailClient({
  index,
  documents: initialDocs,
  role,
}: {
  index: IdxInfo;
  documents: DocRow[];
  role: "OWNER" | "ADMIN" | "MEMBER";
}) {
  const router = useRouter();
  const confirm = useConfirm();
  const [docs, setDocs] = useState(initialDocs);
  const [uploading, setUploading] = useState(false);
  const [refreshingStaleness, setRefreshingStaleness] = useState(false);
  const [staleFilter, setStaleFilter] = useState(false);
  const [urlInput, setUrlInput] = useState("");
  const [scraping, setScraping] = useState(false);
  const [deletingKb, setDeletingKb] = useState(false);
  // Two independent toggles for URL ingest:
  //   • crawlEnabled  — turn on BFS crawl of internal links (default off:
  //                     just scrape the pasted URL(s) themselves)
  //   • limitPages    — only meaningful when crawlEnabled. When OFF, crawl
  //                     the entire site up to the server's 500-page hard
  //                     ceiling. When ON, reveal a number input + cap at
  //                     that count.
  const [crawlEnabled, setCrawlEnabled] = useState(false);
  const [limitPages, setLimitPages] = useState(false);
  const [crawlMaxPages, setCrawlMaxPages] = useState(20);
  // Whether to also fetch + CLIP-embed images found on the scraped pages.
  // ON by default because the user explicitly asked for image-based matching;
  // turn off for a fast text-only ingest.
  const [scrapeImages, setScrapeImages] = useState(true);
  // Live progress + per-page log from the SSE stream. Visible only while
  // a scrape is running; cleared on the next submit. `target` is the cap
  // we report against in the progress bar — equals max-pages for crawl,
  // and the URL count for single-URL mode.
  const [progress, setProgress] = useState<{
    target: number;
    visited: number;
    ingested: number;
    failed: number;
    log: Array<{ url: string; ok: boolean; error?: string; imageCount?: number }>;
  } | null>(null);
  // AbortController for the in-flight stream — the Stop button calls .abort().
  const scrapeAbortRef = useRef<AbortController | null>(null);
  // Live upload progress (% + bytes) for the file dropzone. Visible only
  // while files are uploading; cleared on the next drop. We use XHR (not
  // fetch) because the standard `fetch` API doesn't expose upload progress.
  const [uploadProgress, setUploadProgress] = useState<{
    loaded: number;
    total: number;
    files: string[];
  } | null>(null);
  const uploadXhrRef = useRef<XMLHttpRequest | null>(null);
  const isAdmin = role === "OWNER" || role === "ADMIN";
  const staleCount = docs.filter((d) => d.staleReason).length;
  const visibleDocs = staleFilter ? docs.filter((d) => d.staleReason) : docs;

  // Re-sync local `docs` state whenever the server-rendered prop changes.
  // Without this, `useState(initialDocs)` only seeds once — after the first
  // render, every router.refresh() fetches new data but the client component
  // keeps showing the original list (no visible auto-refresh after upload /
  // scrape). We merge by id: server rows win for fields the server owns
  // (status, chunkCount, sourceUrl, etc.), but any optimistic rows we added
  // locally that don't yet exist on the server are kept until the server
  // catches up.
  useEffect(() => {
    setDocs((prev) => {
      const byIdNew = new Map(initialDocs.map((d) => [d.id, d] as const));
      const merged: DocRow[] = initialDocs.slice();
      for (const old of prev) {
        if (!byIdNew.has(old.id) && old.id.startsWith("optimistic-")) {
          // Optimistic row still in flight — keep it until server materializes it.
          merged.push(old);
        }
      }
      return merged;
    });
  }, [initialDocs]);

  useEffect(() => {
    const inflight = docs.some((d) => d.status === "PENDING" || d.status === "PROCESSING");
    if (!inflight) return;
    const interval = setInterval(() => router.refresh(), 2000);
    return () => clearInterval(interval);
  }, [docs, router]);

  const onDrop = useCallback(
    async (files: File[]) => {
      if (files.length === 0) return;
      setUploading(true);
      // Optimistic placeholder rows so the user sees the files appear in the
      // list the moment the drop completes — without waiting for the POST
      // round-trip + router.refresh. Replaced by the real rows once the
      // server returns them.
      const placeholders: DocRow[] = files.map((f, i) => ({
        id: `optimistic-${Date.now()}-${i}`,
        name: f.name,
        fileName: f.name,
        fileSize: f.size,
        status: "PENDING",
        chunkCount: 0,
        errorMessage: null,
        createdAt: new Date().toISOString(),
        sourceDate: null,
        staleReason: null,
        sourceUrl: null,
      }));
      setDocs((prev) => [...placeholders, ...prev]);
      const totalBytes = files.reduce((n, f) => n + f.size, 0);
      setUploadProgress({ loaded: 0, total: totalBytes, files: files.map((f) => f.name) });
      try {
        const fd = new FormData();
        for (const f of files) fd.append("files", f);

        // XMLHttpRequest gives us upload.onprogress (fetch does not). We
        // wrap it in a Promise so the surrounding async flow is unchanged.
        const result = await new Promise<{ ok: boolean; status: number; body: string; aborted: boolean }>(
          (resolve) => {
            const xhr = new XMLHttpRequest();
            uploadXhrRef.current = xhr;
            xhr.open("POST", `/api/indexes/${index.id}/documents`);
            xhr.upload.addEventListener("progress", (e) => {
              if (e.lengthComputable) {
                setUploadProgress((cur) =>
                  cur ? { ...cur, loaded: e.loaded, total: e.total } : cur,
                );
              }
            });
            xhr.addEventListener("load", () =>
              resolve({ ok: xhr.status >= 200 && xhr.status < 300, status: xhr.status, body: xhr.responseText, aborted: false }),
            );
            xhr.addEventListener("error", () =>
              resolve({ ok: false, status: 0, body: "network error", aborted: false }),
            );
            xhr.addEventListener("abort", () =>
              resolve({ ok: false, status: 0, body: "aborted", aborted: true }),
            );
            xhr.send(fd);
          },
        );

        if (result.aborted) {
          // Remove optimistic rows on cancel.
          setDocs((prev) => prev.filter((d) => !placeholders.some((p) => p.id === d.id)));
          toast({ title: "Upload cancelled" });
          return;
        }
        if (!result.ok) {
          setDocs((prev) => prev.filter((d) => !placeholders.some((p) => p.id === d.id)));
          let msg = `HTTP ${result.status}`;
          try {
            msg = JSON.parse(result.body).error ?? msg;
          } catch {
            /* keep msg */
          }
          toast({ title: "Upload failed", description: msg, variant: "destructive" });
          return;
        }
        let body: { documents?: unknown[] } = {};
        try {
          body = JSON.parse(result.body);
        } catch {
          /* leave empty */
        }
        const created: Array<{ id: string; name: string; fileName: string; fileSize: number; mimeType: string; status: string }> = (body.documents ?? []) as Array<{ id: string; name: string; fileName: string; fileSize: number; mimeType: string; status: string }>;
        // Swap optimistic rows for real server rows so the IDs match.
        setDocs((prev) => {
          const withoutOptimistic = prev.filter(
            (d) => !placeholders.some((p) => p.id === d.id),
          );
          const realRows: DocRow[] = created.map((d) => ({
            id: d.id,
            name: d.name,
            fileName: d.fileName,
            fileSize: d.fileSize,
            status: d.status,
            chunkCount: 0,
            errorMessage: null,
            createdAt: new Date().toISOString(),
            sourceDate: null,
            staleReason: null,
            sourceUrl: null,
          }));
          return [...realRows, ...withoutOptimistic];
        });
        toast({ title: `Uploaded ${files.length} file${files.length === 1 ? "" : "s"}`, variant: "success" });
        router.refresh();
      } finally {
        setUploading(false);
        setUploadProgress(null);
        uploadXhrRef.current = null;
      }
    },
    [index.id, router],
  );

  function cancelUpload() {
    uploadXhrRef.current?.abort();
  }

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  async function submitUrls() {
    // Accept comma-, newline-, or whitespace-separated URLs. Light client-side
    // validation; the server enforces the strict zod schema.
    const urls = urlInput
      .split(/[\s,]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    if (urls.length === 0) {
      toast({ title: "Paste at least one URL", variant: "destructive" });
      return;
    }

    // Decide the page budget:
    //   • crawl off               → just the URL(s) the user pasted
    //   • crawl on,  limit off    → server-side ceiling (500)
    //   • crawl on,  limit on     → user's explicit number (1..500)
    const capped = limitPages ? Math.max(1, Math.min(500, crawlMaxPages)) : 500;
    const targetMax = crawlEnabled ? capped : urls.length;

    // Abort any previous in-flight stream before starting a new one.
    scrapeAbortRef.current?.abort();
    const ctrl = new AbortController();
    scrapeAbortRef.current = ctrl;
    setProgress({ target: targetMax, visited: 0, ingested: 0, failed: 0, log: [] });
    setScraping(true);

    try {
      const res = await fetch(`/api/indexes/${index.id}/urls/stream`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: ctrl.signal,
        body: JSON.stringify({
          urls,
          options: { scrapeImages },
          // Only include the crawl block when the user opted in. When opted
          // in, send the cap only if "Crawl limited no of pages" is also on.
          ...(crawlEnabled
            ? {
                crawl: {
                  enabled: true,
                  ...(limitPages ? { maxPages: capped } : {}),
                  sameOriginOnly: true,
                },
              }
            : {}),
        }),
      });
      if (!res.ok || !res.body) {
        toast({
          title: "Scrape failed",
          description: `HTTP ${res.status}`,
          variant: "destructive",
        });
        return;
      }
      // Parse Server-Sent Events from the response stream.
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let succeeded = 0;
      let failed = 0;
      let aborted = false;
      while (true) {
        let chunk: ReadableStreamReadResult<Uint8Array>;
        try {
          chunk = await reader.read();
        } catch (e) {
          if (ctrl.signal.aborted) {
            aborted = true;
            break;
          }
          throw e;
        }
        if (chunk.done) break;
        buffer += decoder.decode(chunk.value, { stream: true });
        // Each SSE message ends with "\n\n". Split on that, keep the trailing
        // partial in `buffer` for the next chunk.
        let sep: number;
        while ((sep = buffer.indexOf("\n\n")) >= 0) {
          const block = buffer.slice(0, sep);
          buffer = buffer.slice(sep + 2);
          const evMatch = /^event:\s*(\S+)/m.exec(block);
          const dataMatch = /^data:\s*(.*)$/m.exec(block);
          if (!evMatch || !dataMatch) continue;
          const event = evMatch[1];
          let data: Record<string, unknown> = {};
          try {
            data = JSON.parse(dataMatch[1]);
          } catch {
            continue;
          }
          if (event === "page") {
            const p = data as {
              url: string;
              ok: boolean;
              error?: string;
              imageCount?: number;
              visited: number;
              ingested: number;
              failed: number;
            };
            if (p.ok) succeeded++;
            else failed++;
            setProgress((cur) =>
              cur
                ? {
                    ...cur,
                    visited: p.visited,
                    ingested: p.ingested,
                    failed: p.failed,
                    log: [...cur.log, { url: p.url, ok: p.ok, error: p.error, imageCount: p.imageCount }],
                  }
                : cur,
            );
            // Live KB list refresh — pull the latest doc row in for this index
            // so the user sees each page land as it completes.
            router.refresh();
          } else if (event === "done") {
            // Final summary — counters in `data` already reflected via page events.
          } else if (event === "error") {
            const m = (data as { message?: string }).message ?? "Unknown error";
            toast({ title: "Scrape stream error", description: m, variant: "destructive" });
          }
        }
      }

      if (aborted) {
        toast({
          title: "Stopped",
          description: `Scrape stopped — ${succeeded} ingested, ${failed} failed.`,
        });
      } else {
        toast({
          title: `Scraped ${succeeded} page${succeeded === 1 ? "" : "s"}`,
          description: failed > 0 ? `${failed} failed — see log.` : "All pages indexed.",
          variant: failed > 0 ? undefined : "success",
        });
      }
      if (succeeded > 0) setUrlInput("");
      router.refresh();
    } catch (err) {
      if (!ctrl.signal.aborted) {
        toast({
          title: "Scrape failed",
          description: err instanceof Error ? err.message : String(err),
          variant: "destructive",
        });
      }
    } finally {
      setScraping(false);
      scrapeAbortRef.current = null;
    }
  }

  function stopScrape() {
    scrapeAbortRef.current?.abort();
  }

  async function deleteEntireKb() {
    if (
      !(await confirm(
        `This removes ALL ${docs.length} document${docs.length === 1 ? "" : "s"}, ` +
          "their chunks, image embeddings, and the Milvus collection. " +
          "This cannot be undone.",
        {
          title: `Delete "${index.name}"?`,
          destructive: true,
          confirmLabel: "Delete KB",
        },
      ))
    ) {
      return;
    }
    setDeletingKb(true);
    try {
      const res = await fetch(`/api/indexes/${index.id}`, { method: "DELETE" });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        toast({
          title: "Delete failed",
          description: body.error ?? `HTTP ${res.status}`,
          variant: "destructive",
        });
        return;
      }
      toast({ title: "Knowledge base deleted", variant: "success" });
      router.push(`/dashboard/indexes?org=${index.organizationId}`);
    } finally {
      setDeletingKb(false);
    }
  }

  async function reindex(id: string) {
    await fetch(`/api/documents/${id}/reindex`, { method: "POST" });
    setDocs((prev) => prev.map((d) => (d.id === id ? { ...d, status: "PENDING" } : d)));
    router.refresh();
  }

  async function remove(id: string) {
    if (!(await confirm("Delete this document and all its embeddings?", { destructive: true, confirmLabel: "Delete" }))) return;
    const res = await fetch(`/api/documents/${id}`, { method: "DELETE" });
    if (res.ok) {
      setDocs((prev) => prev.filter((d) => d.id !== id));
      toast({ title: "Document removed" });
    }
  }

  const [seeding, setSeeding] = useState(false);
  const [reindexing, setReindexing] = useState(false);
  const [viewingDocId, setViewingDocId] = useState<string | null>(null);
  const failedCount = docs.filter((d) => d.status === "FAILED" || d.status === "PENDING").length;

  async function seedSamples() {
    setSeeding(true);
    try {
      const res = await fetch(`/api/indexes/${index.id}/seed-samples`, { method: "POST" });
      if (!res.ok) {
        toast({ title: "Seed failed", description: (await res.json()).error });
        return;
      }
      const r = await res.json();
      const parts: string[] = [];
      if (r.added > 0) parts.push(`added ${r.added}`);
      if (r.retried > 0) parts.push(`retried ${r.retried}`);
      if (r.skipped > 0) parts.push(`skipped ${r.skipped}`);
      if (r.failed > 0) parts.push(`${r.failed} still failed`);
      toast({
        title: "Sample docs processed",
        description: parts.join(" · ") || "Nothing to do.",
        variant: r.failed > 0 ? undefined : "success",
      });
      router.refresh();
    } finally {
      setSeeding(false);
    }
  }

  async function refreshStaleness() {
    setRefreshingStaleness(true);
    try {
      const res = await fetch(
        `/api/orgs/${index.organizationId}/sources/refresh-staleness`,
        { method: "POST" },
      );
      if (!res.ok) {
        toast({ title: "Refresh failed", description: (await res.json()).error });
        return;
      }
      const r = await res.json();
      toast({
        title: `Re-scanned ${r.scanned} document${r.scanned === 1 ? "" : "s"}`,
        description: `${r.flagged} flagged as stale.`,
        variant: "success",
      });
      router.refresh();
    } finally {
      setRefreshingStaleness(false);
    }
  }

  async function reindexFailed() {
    setReindexing(true);
    try {
      const res = await fetch(`/api/indexes/${index.id}/reindex-failed`, { method: "POST" });
      if (!res.ok) {
        toast({ title: "Reindex failed", description: (await res.json()).error });
        return;
      }
      const r = await res.json();
      toast({
        title: `Re-indexing ${r.queued} document${r.queued === 1 ? "" : "s"}`,
        description: "Running in the background — refresh in a few seconds.",
        variant: "success",
      });
      setTimeout(() => router.refresh(), 2500);
    } finally {
      setReindexing(false);
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title={index.name}
        subtitle={index.description ?? undefined}
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${index.organizationId}` },
          { label: "Knowledge Bases", href: `/dashboard/indexes?org=${index.organizationId}` },
          { label: index.name },
        ]}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            {failedCount > 0 ? (
              <Button variant="outline" size="sm" onClick={reindexFailed} disabled={reindexing}>
                {reindexing ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <RefreshCw className="h-3.5 w-3.5" />
                )}
                Re-index failed ({failedCount})
              </Button>
            ) : null}
            {isAdmin ? (
              <Button
                variant="outline"
                size="sm"
                onClick={refreshStaleness}
                disabled={refreshingStaleness}
                title="Re-evaluate every document against the staleness rule"
              >
                {refreshingStaleness ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Clock className="h-3.5 w-3.5" />
                )}
                Refresh staleness
              </Button>
            ) : null}
            <Button variant="outline" size="sm" onClick={seedSamples} disabled={seeding}>
              {seeding ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Sparkles className="h-3.5 w-3.5" />
              )}
              Load sample documents
            </Button>
            {isAdmin ? (
              <Button
                variant="destructive"
                size="sm"
                onClick={deleteEntireKb}
                disabled={deletingKb}
                title="Delete this entire knowledge base and all its documents, chunks, and image embeddings"
              >
                {deletingKb ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Trash2 className="h-3.5 w-3.5" />
                )}
                Delete KB
              </Button>
            ) : null}
          </div>
        }
      />

      <div className="grid gap-3 md:grid-cols-2">
        <Card>
          <CardContent className="p-0">
            {/*
              While an upload is in flight, the dropzone is replaced by a
              progress bar + Stop button. We don't render the dropzone at
              all in that state so a second drop can't race the first.
            */}
            {uploadProgress ? (
              <div className="space-y-2 p-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium">
                    Uploading {uploadProgress.files.length} file
                    {uploadProgress.files.length === 1 ? "" : "s"}…{" "}
                    <span className="text-muted-foreground">
                      {formatBytes(uploadProgress.loaded)} / {formatBytes(uploadProgress.total)}
                      {uploadProgress.total > 0
                        ? ` (${Math.round((uploadProgress.loaded / uploadProgress.total) * 100)}%)`
                        : ""}
                    </span>
                  </span>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={cancelUpload}
                    className="h-6 px-2 text-[11px]"
                  >
                    Stop
                  </Button>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{
                      width: `${
                        uploadProgress.total > 0
                          ? Math.min(100, (uploadProgress.loaded / uploadProgress.total) * 100)
                          : 0
                      }%`,
                    }}
                  />
                </div>
                <div className="max-h-24 overflow-y-auto text-[11px] font-mono text-muted-foreground space-y-0.5">
                  {uploadProgress.files.map((name) => (
                    <div key={name} className="truncate" title={name}>
                      · {name}
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div
                {...getRootProps()}
                className={`grid cursor-pointer place-items-center border-2 border-dashed rounded-xl p-8 text-center transition-colors ${isDragActive ? "border-primary bg-primary/5" : "hover:bg-accent/40"}`}
              >
                <input {...getInputProps()} />
                {uploading ? (
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                ) : (
                  <Upload className="h-8 w-8 text-muted-foreground" />
                )}
                <div className="mt-3 text-sm font-medium">
                  {isDragActive ? "Drop here…" : "Drop files to upload"}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  PDF, Word, Excel, PowerPoint, HTML, txt, markdown.
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Globe className="h-4 w-4 text-primary" /> Scrape URLs
            </div>
            <p className="text-xs text-muted-foreground">
              Paste up to 25 URLs (one per line). Text + images are extracted,
              embedded, and stored in the same KB as uploaded files. PDFs and
              Office docs hosted at URLs are downloaded and parsed normally.
            </p>
            <Textarea
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://example.com/whitepaper&#10;https://docs.example.com/security"
              rows={4}
              className="font-mono text-xs"
              disabled={scraping}
            />
            {/* Crawl-entire-site checkbox (kept as-is). */}
            <label className="flex flex-wrap items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={crawlEnabled}
                onChange={(e) => {
                  setCrawlEnabled(e.target.checked);
                  // Unchecking crawl also disables the page-limit option —
                  // the limit only makes sense when we're crawling.
                  if (!e.target.checked) setLimitPages(false);
                }}
                disabled={scraping}
                className="h-3.5 w-3.5"
              />
              <span>Crawl entire site (follow internal links)</span>
            </label>

            {/* Page-limit checkbox — only meaningful when crawl is on. */}
            <label
              className={cn(
                "flex flex-wrap items-center gap-2 pl-6 text-xs",
                !crawlEnabled && "opacity-50",
              )}
            >
              <input
                type="checkbox"
                checked={limitPages}
                onChange={(e) => setLimitPages(e.target.checked)}
                disabled={scraping || !crawlEnabled}
                className="h-3.5 w-3.5"
              />
              <span>Crawl limited no of pages</span>
              {crawlEnabled && limitPages ? (
                <>
                  <span className="text-muted-foreground">— max pages:</span>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={crawlMaxPages}
                    onChange={(e) => setCrawlMaxPages(parseInt(e.target.value, 10) || 20)}
                    disabled={scraping}
                    className="h-7 w-16 rounded border bg-background px-2 text-xs"
                  />
                </>
              ) : null}
            </label>
            <label className="flex flex-wrap items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={scrapeImages}
                onChange={(e) => setScrapeImages(e.target.checked)}
                disabled={scraping}
                className="h-3.5 w-3.5"
              />
              <span>
                Scrape images too{" "}
                <span className="text-muted-foreground">
                  — fetch + CLIP-embed each page&apos;s images for visual matching
                </span>
              </span>
            </label>

            {/* Live progress bar + per-page log + Stop button. Only visible
                while a scrape is in flight; cleared on the next submit. */}
            {progress ? (
              <div className="rounded-lg border bg-muted/30 p-3 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span>
                    {progress.visited} / {progress.target} pages
                    {progress.ingested > 0 ? ` · ${progress.ingested} ok` : ""}
                    {progress.failed > 0 ? ` · ${progress.failed} failed` : ""}
                  </span>
                  {scraping ? (
                    <Button size="sm" variant="destructive" onClick={stopScrape} className="h-6 px-2 text-[11px]">
                      Stop
                    </Button>
                  ) : null}
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{
                      width: `${Math.min(100, (progress.visited / Math.max(1, progress.target)) * 100)}%`,
                    }}
                  />
                </div>
                {progress.log.length > 0 ? (
                  <div className="max-h-40 overflow-y-auto rounded border bg-background/60 p-2 text-[11px] font-mono space-y-0.5">
                    {progress.log.slice(-50).map((p, i) => (
                      <div
                        key={`${p.url}-${i}`}
                        className={`truncate ${p.ok ? "text-foreground" : "text-destructive"}`}
                        title={p.error ?? p.url}
                      >
                        {p.ok ? "✓" : "✗"} {p.url}
                        {p.ok && typeof p.imageCount === "number"
                          ? ` · ${p.imageCount} img`
                          : ""}
                        {p.error ? ` — ${p.error.slice(0, 80)}` : ""}
                      </div>
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}

            <div className="flex justify-end">
              <Button size="sm" onClick={submitUrls} disabled={scraping || !urlInput.trim()}>
                {scraping ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Link2 className="h-3.5 w-3.5" />
                )}
                {!crawlEnabled
                  ? "Scrape & add"
                  : limitPages
                    ? `Crawl ${crawlMaxPages} & add`
                    : "Crawl entire site & add"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {staleCount > 0 ? (
        <div
          className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-100"
          role="status"
          data-testid="stale-summary-banner"
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            <span>
              <strong>{staleCount}</strong> of {docs.length} document{docs.length === 1 ? "" : "s"} flagged
              as stale.
            </span>
          </div>
          <Button
            size="sm"
            variant={staleFilter ? "default" : "outline"}
            onClick={() => setStaleFilter((v) => !v)}
          >
            {staleFilter ? "Show all" : "Show stale only"}
          </Button>
        </div>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Documents</CardTitle>
          <CardDescription>
            {visibleDocs.length} {staleFilter ? "stale" : "indexed"}
            {staleFilter && docs.length !== visibleDocs.length ? ` of ${docs.length}` : ""}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {visibleDocs.length === 0 ? (
            <div className="grid place-items-center rounded-lg border-2 border-dashed py-12 text-sm text-muted-foreground">
              {staleFilter ? "No stale documents." : "No documents yet."}
            </div>
          ) : (
            visibleDocs.map((d) => (
              // div, not button: this row contains inner <Button> icons
              // (re-index + delete), and <button> inside <button> is invalid
              // HTML — triggers a hydration error. The role + tabIndex +
              // keyboard handler keep the row keyboard-accessible.
              <div
                key={d.id}
                role="button"
                tabIndex={0}
                onClick={() => setViewingDocId(d.id)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setViewingDocId(d.id);
                  }
                }}
                className="group flex w-full items-center justify-between rounded-lg border bg-card p-3 text-left transition-colors hover:bg-accent/40 cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <div className="flex min-w-0 items-center gap-3">
                  {d.sourceUrl ? (
                    <Globe className="h-4 w-4 shrink-0 text-primary" />
                  ) : (
                    <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                  )}
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{d.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatBytes(d.fileSize)} · {d.chunkCount} chunks · {formatDate(d.createdAt)}
                      {d.sourceDate ? ` · as of ${d.sourceDate.slice(0, 10)}` : ""}
                    </div>
                    {d.sourceUrl ? (
                      <div className="mt-0.5 truncate text-xs text-primary/80">
                        <Link2 className="mr-1 inline h-3 w-3 align-middle" />
                        {d.sourceUrl}
                      </div>
                    ) : null}
                    {d.errorMessage ? (
                      <div className="mt-1 text-xs text-destructive">{d.errorMessage}</div>
                    ) : null}
                  </div>
                </div>
                <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  {d.staleReason ? (
                    <Badge variant="destructive" title={d.staleReason}>
                      <AlertTriangle className="mr-1 h-3 w-3" />
                      Stale
                    </Badge>
                  ) : null}
                  <Badge variant={STATUS_VARIANT[d.status] ?? "outline"}>
                    {d.status === "PROCESSING" ? (
                      <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                    ) : null}
                    {d.status}
                  </Badge>
                  <Button size="icon" variant="ghost" onClick={() => reindex(d.id)} title="Re-index">
                    <RefreshCw className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(d.id)} title="Delete">
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      <DocumentViewer
        documentId={viewingDocId}
        open={viewingDocId !== null}
        onOpenChange={(open) => !open && setViewingDocId(null)}
      />
    </div>
  );
}
