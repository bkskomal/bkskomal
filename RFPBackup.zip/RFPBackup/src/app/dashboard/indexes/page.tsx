import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { IndexesClient } from "./client";

export default async function IndexesPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization } = await getActiveOrg(sp.org);

  const indexes = await prisma.knowledgeIndex.findMany({
    where: { organizationId: organization.id },
    include: { _count: { select: { documents: true } } },
    orderBy: { createdAt: "desc" },
  });

  return (
    <IndexesClient
      orgId={organization.id}
      initialIndexes={indexes.map((i) => ({
        id: i.id,
        name: i.name,
        description: i.description,
        documentCount: i._count.documents,
      }))}
    />
  );
}
