"use client";

import { useRouter } from "next/navigation";
import Link from "next/link";
import { useState } from "react";
import { Library, Plus, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import { PageHeader } from "@/components/dashboard/page-header";

interface IdxRow {
  id: string;
  name: string;
  description: string | null;
  documentCount: number;
}

export function IndexesClient({
  orgId,
  initialIndexes,
}: {
  orgId: string;
  initialIndexes: IdxRow[];
}) {
  const router = useRouter();
  const [indexes, setIndexes] = useState(initialIndexes);
  const [open, setOpen] = useState(false);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Knowledge Bases"
        subtitle="Each index is a vector store. Add product docs, past RFPs, sales decks — anything the AI should cite."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${orgId}` },
          { label: "Knowledge Bases" },
        ]}
        actions={
          <Button variant="gradient" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New Index
          </Button>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {indexes.map((i) => (
          <Link key={i.id} href={`/dashboard/indexes/${i.id}?org=${orgId}`}>
            <Card className="h-full transition-all hover:shadow-md hover:-translate-y-0.5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Library className="h-4 w-4 text-primary" /> {i.name}
                </CardTitle>
                {i.description ? <CardDescription>{i.description}</CardDescription> : null}
              </CardHeader>
              <CardContent className="text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <FileText className="h-3.5 w-3.5" /> {i.documentCount} documents
                </span>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <CreateIndexDialog
        open={open}
        onOpenChange={setOpen}
        orgId={orgId}
        onCreated={(idx) => {
          setIndexes((prev) => [
            { id: idx.id, name: idx.name, description: idx.description ?? null, documentCount: 0 },
            ...prev,
          ]);
          router.refresh();
        }}
      />
    </div>
  );
}

function CreateIndexDialog({
  open,
  onOpenChange,
  orgId,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  orgId: string;
  onCreated: (idx: { id: string; name: string; description?: string }) => void;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    const res = await fetch(`/api/orgs/${orgId}/indexes`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, description }),
    });
    setPending(false);
    if (!res.ok) {
      toast({ title: "Couldn't create index", description: (await res.json()).error });
      return;
    }
    const { index } = await res.json();
    toast({ title: "Index created", variant: "success" });
    onCreated(index);
    onOpenChange(false);
    setName("");
    setDescription("");
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New knowledge index</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description (optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="gradient" disabled={pending}>
              {pending ? "Creating…" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
