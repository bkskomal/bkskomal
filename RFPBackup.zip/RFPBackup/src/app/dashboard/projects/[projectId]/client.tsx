"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { useDropzone } from "react-dropzone";
import { ArrowLeft, FileText, Library, Upload, Loader2, GitBranch, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { formatBytes, formatDate } from "@/lib/utils";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";

interface ProjectInfo {
  id: string;
  name: string;
  description: string | null;
  organizationId: string;
  organizationName: string;
  defaultIndex: { id: string; name: string } | null;
  defaultPipelineTemplateId: string | null;
}

interface PipelineTplOption {
  id: string;
  name: string;
  isDefault: boolean;
}

interface RfpRow {
  id: string;
  title: string;
  fileName: string;
  status: string;
  questionCount: number;
  createdAt: string;
  errorMessage: string | null;
}

const STATUS_VARIANT: Record<string, "default" | "info" | "success" | "warning" | "destructive"> = {
  UPLOADED: "info",
  EXTRACTING: "warning",
  READY: "success",
  GENERATING: "warning",
  COMPLETED: "success",
  FAILED: "destructive",
};

export function ProjectDetailClient({
  project,
  rfps: initialRfps,
  pipelineTemplates,
}: {
  project: ProjectInfo;
  rfps: RfpRow[];
  pipelineTemplates: PipelineTplOption[];
}) {
  const router = useRouter();
  const confirm = useConfirm();
  const [rfps, setRfps] = useState(initialRfps);
  const [activeTemplateId, setActiveTemplateId] = useState<string>(
    project.defaultPipelineTemplateId ?? "__org_default__",
  );

  const [deleting, setDeleting] = useState(false);
  async function deleteProject() {
    const total = rfps.length;
    const msg = total > 0
      ? `Delete project "${project.name}" AND all ${total} RFP(s) under it (questions, responses, sources, comments — irreversible)?`
      : `Delete project "${project.name}"?`;
    if (!(await confirm(msg, { destructive: true, confirmLabel: "Delete", title: `Delete "${project.name}"?` }))) return;
    setDeleting(true);
    try {
      const res = await fetch(`/api/projects/${project.id}`, { method: "DELETE" });
      if (!res.ok) {
        const body = await res.text();
        toast({ title: "Delete failed", description: body.slice(0, 200), variant: "destructive" });
        setDeleting(false);
        return;
      }
      toast({ title: "Project deleted", description: `Removed ${total} RFP(s) and all associated data.` });
      router.push(`/dashboard/projects?org=${project.organizationId}`);
      router.refresh();
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      toast({ title: "Delete failed", description: msg, variant: "destructive" });
      setDeleting(false);
    }
  }

  async function setProjectTemplate(value: string) {
    setActiveTemplateId(value);
    const body = {
      defaultPipelineTemplateId: value === "__org_default__" ? null : value,
    };
    const res = await fetch(`/api/projects/${project.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    if (res.ok) {
      toast({ title: "Workflow template updated", variant: "success" });
      router.refresh();
    } else {
      toast({ title: "Couldn't update template" });
    }
  }
  const [uploading, setUploading] = useState(false);

  // Poll while any RFPs are mid-processing.
  useEffect(() => {
    const inflight = rfps.some((r) =>
      ["UPLOADED", "EXTRACTING", "GENERATING"].includes(r.status),
    );
    if (!inflight) return;
    const interval = setInterval(() => router.refresh(), 3000);
    return () => clearInterval(interval);
  }, [rfps, router]);

  const onDrop = useCallback(
    async (files: File[]) => {
      if (files.length === 0) return;
      setUploading(true);
      try {
        for (const f of files) {
          const fd = new FormData();
          fd.append("file", f);
          fd.append("title", f.name);
          const res = await fetch(`/api/projects/${project.id}/rfps`, {
            method: "POST",
            body: fd,
          });
          if (!res.ok) {
            const err = await res.json();
            toast({ title: `Upload failed: ${f.name}`, description: err.error });
            continue;
          }
          const { rfp } = await res.json();
          toast({ title: `Uploaded: ${f.name}`, variant: "success" });
          setRfps((prev) => [
            {
              id: rfp.id,
              title: rfp.title,
              fileName: rfp.fileName,
              status: rfp.status,
              questionCount: 0,
              createdAt: rfp.createdAt,
              errorMessage: null,
            },
            ...prev,
          ]);
        }
      } finally {
        setUploading(false);
        router.refresh();
      }
    },
    [project.id, router],
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.presentationml.presentation": [".pptx"],
      "application/vnd.ms-powerpoint": [".ppt"],
      "text/plain": [".txt"],
      "text/markdown": [".md"],
    },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title={project.name}
        subtitle={project.description ?? undefined}
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${project.organizationId}` },
          { label: "Projects", href: `/dashboard/projects?org=${project.organizationId}` },
          { label: project.name },
        ]}
        actions={
          <div className="flex flex-col items-end gap-2">
            <Button
              variant="destructive"
              size="sm"
              onClick={deleteProject}
              disabled={deleting}
              title={rfps.length > 0
                ? `Delete project AND all ${rfps.length} RFP(s) under it`
                : "Delete this project"}
            >
              {deleting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
              <span className="ml-1">Delete project</span>
              {rfps.length > 0 ? (
                <span className="ml-1 rounded bg-destructive-foreground/20 px-1.5 py-0.5 text-[10px] font-semibold">
                  +{rfps.length} RFP{rfps.length === 1 ? "" : "s"}
                </span>
              ) : null}
            </Button>
            {project.defaultIndex ? (
              <Badge variant="outline" className="gap-1">
                <Library className="h-3 w-3" /> {project.defaultIndex.name}
              </Badge>
            ) : (
              <Badge variant="warning">No default index</Badge>
            )}
            <div className="flex items-center gap-2 text-xs">
              <GitBranch className="h-3 w-3 text-muted-foreground" />
              <span className="text-muted-foreground">Workflow:</span>
              <Select value={activeTemplateId} onValueChange={setProjectTemplate}>
                <SelectTrigger className="h-7 text-xs w-[220px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__org_default__">Use org default</SelectItem>
                  {pipelineTemplates.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name}
                      {t.isDefault ? " ★" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        }
      />

      <Card>
        <CardContent className="p-0">
          <div
            {...getRootProps()}
            className={`grid cursor-pointer place-items-center border-2 border-dashed rounded-xl p-10 text-center transition-colors ${isDragActive ? "border-primary bg-primary/5" : "border-border hover:bg-accent/40"}`}
          >
            <input {...getInputProps()} />
            {uploading ? (
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            ) : (
              <Upload className="h-8 w-8 text-muted-foreground" />
            )}
            <div className="mt-3 text-sm font-medium">
              {isDragActive ? "Drop the RFP here…" : "Drop an RFP file or click to upload"}
            </div>
            <div className="mt-1 text-xs text-muted-foreground">
              PDF, Word, Excel, PowerPoint, txt or markdown. We&apos;ll extract questions automatically.
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>RFPs</CardTitle>
          <CardDescription>{rfps.length} document{rfps.length === 1 ? "" : "s"}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-2">
          {rfps.length === 0 ? (
            <div className="grid place-items-center rounded-lg border-2 border-dashed py-12 text-sm text-muted-foreground">
              No RFPs yet — upload one above.
            </div>
          ) : (
            rfps.map((r) => (
              <Link
                key={r.id}
                href={`/dashboard/rfps/${r.id}?org=${project.organizationId}`}
                className="flex items-center justify-between rounded-lg border bg-card p-3 transition-colors hover:bg-accent"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                  <div className="min-w-0">
                    <div className="truncate text-sm font-medium">{r.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {r.fileName} · {r.questionCount} questions · {formatDate(r.createdAt)}
                    </div>
                    {r.errorMessage ? (
                      <div className="mt-1 text-xs text-destructive">{r.errorMessage}</div>
                    ) : null}
                  </div>
                </div>
                <Badge variant={STATUS_VARIANT[r.status] ?? "outline"}>
                  {r.status === "EXTRACTING" || r.status === "GENERATING" ? (
                    <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                  ) : null}
                  {r.status}
                </Badge>
              </Link>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
