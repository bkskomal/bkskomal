import { notFound, redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ProjectDetailClient } from "./client";

export default async function ProjectDetailPage({
  params,
}: {
  params: Promise<{ projectId: string }>;
}) {
  const { projectId } = await params;
  const session = await auth();
  if (!session?.user?.id) redirect("/auth/signin");

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      organization: { select: { id: true, name: true } },
      defaultIndex: { select: { id: true, name: true } },
      defaultPipelineTemplate: { select: { id: true, name: true } },
      rfps: {
        orderBy: { createdAt: "desc" },
        include: { _count: { select: { questions: true } } },
      },
    },
  });
  if (!project) notFound();

  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId: session.user.id,
        organizationId: project.organizationId,
      },
    },
  });
  if (!member) notFound();

  const templates = await prisma.pipelineTemplate.findMany({
    where: { organizationId: project.organizationId },
    select: { id: true, name: true, isDefault: true },
    orderBy: [{ isDefault: "desc" }, { name: "asc" }],
  });

  return (
    <ProjectDetailClient
      project={{
        id: project.id,
        name: project.name,
        description: project.description,
        organizationId: project.organizationId,
        organizationName: project.organization.name,
        defaultIndex: project.defaultIndex,
        defaultPipelineTemplateId: project.defaultPipelineTemplateId,
      }}
      pipelineTemplates={templates}
      rfps={project.rfps.map((r) => ({
        id: r.id,
        title: r.title,
        fileName: r.fileName,
        status: r.status,
        questionCount: r._count.questions,
        createdAt: r.createdAt.toISOString(),
        errorMessage: r.errorMessage,
      }))}
    />
  );
}
