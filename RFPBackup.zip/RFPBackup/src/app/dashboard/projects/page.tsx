import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { ProjectsClient } from "./client";

export default async function ProjectsPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string; new?: string }>;
}) {
  const sp = await searchParams;
  const { organization } = await getActiveOrg(sp.org);

  const [projects, indexes] = await Promise.all([
    prisma.project.findMany({
      where: { organizationId: organization.id },
      include: {
        _count: { select: { rfps: true } },
        defaultIndex: { select: { id: true, name: true } },
      },
      orderBy: { updatedAt: "desc" },
    }),
    prisma.knowledgeIndex.findMany({
      where: { organizationId: organization.id },
      select: { id: true, name: true },
      orderBy: { createdAt: "asc" },
    }),
  ]);

  return (
    <ProjectsClient
      orgId={organization.id}
      orgName={organization.name}
      initialProjects={projects.map((p) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        rfpCount: p._count.rfps,
        defaultIndex: p.defaultIndex,
        updatedAt: p.updatedAt.toISOString(),
      }))}
      indexes={indexes}
      autoOpenCreate={sp.new === "1"}
    />
  );
}
