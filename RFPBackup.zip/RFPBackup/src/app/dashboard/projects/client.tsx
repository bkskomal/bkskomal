"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FolderKanban, Plus, FileText, Library } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { PageHeader } from "@/components/dashboard/page-header";
import { formatDate } from "@/lib/utils";

interface Project {
  id: string;
  name: string;
  description: string | null;
  rfpCount: number;
  defaultIndex: { id: string; name: string } | null;
  updatedAt: string;
}

interface Props {
  orgId: string;
  orgName: string;
  initialProjects: Project[];
  indexes: { id: string; name: string }[];
  autoOpenCreate: boolean;
}

export function ProjectsClient({ orgId, initialProjects, indexes, autoOpenCreate }: Props) {
  const router = useRouter();
  const [projects, setProjects] = useState(initialProjects);
  const [open, setOpen] = useState(autoOpenCreate);

  useEffect(() => {
    if (autoOpenCreate) setOpen(true);
  }, [autoOpenCreate]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Projects"
        subtitle="Group RFPs by client, deal, or initiative."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${orgId}` },
          { label: "Projects" },
        ]}
        actions={
          <Button variant="gradient" onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> New Project
          </Button>
        }
      />

      {projects.length === 0 ? (
        <Card>
          <CardContent className="grid place-items-center py-16 text-center">
            <FolderKanban className="h-10 w-10 text-muted-foreground" />
            <div className="mt-4 text-lg font-medium">No projects yet</div>
            <p className="mt-1 max-w-sm text-sm text-muted-foreground">
              Projects organize related RFPs and pin a default knowledge base.
            </p>
            <Button className="mt-4" variant="gradient" onClick={() => setOpen(true)}>
              <Plus className="h-4 w-4" /> Create your first project
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {projects.map((p) => (
            <Link key={p.id} href={`/dashboard/projects/${p.id}?org=${orgId}`}>
              <Card className="h-full transition-all hover:shadow-md hover:-translate-y-0.5">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FolderKanban className="h-4 w-4 text-primary" /> {p.name}
                  </CardTitle>
                  {p.description ? (
                    <CardDescription>{p.description}</CardDescription>
                  ) : null}
                </CardHeader>
                <CardContent className="flex items-center justify-between text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <FileText className="h-3.5 w-3.5" /> {p.rfpCount} RFPs
                  </span>
                  {p.defaultIndex ? (
                    <span className="flex items-center gap-1">
                      <Library className="h-3.5 w-3.5" /> {p.defaultIndex.name}
                    </span>
                  ) : null}
                  <span>{formatDate(p.updatedAt)}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}

      <CreateProjectDialog
        open={open}
        onOpenChange={setOpen}
        orgId={orgId}
        indexes={indexes}
        onCreated={(p) => {
          setProjects((prev) => [
            {
              id: p.id,
              name: p.name,
              description: p.description ?? null,
              rfpCount: 0,
              defaultIndex:
                indexes.find((i) => i.id === p.defaultIndexId) ?? null,
              updatedAt: new Date().toISOString(),
            },
            ...prev,
          ]);
          router.refresh();
        }}
      />
    </div>
  );
}

function CreateProjectDialog({
  open,
  onOpenChange,
  orgId,
  indexes,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  orgId: string;
  indexes: { id: string; name: string }[];
  onCreated: (project: { id: string; name: string; description?: string; defaultIndexId?: string }) => void;
}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [indexId, setIndexId] = useState<string>(indexes[0]?.id ?? "");
  const [pending, setPending] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    const res = await fetch(`/api/orgs/${orgId}/projects`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, description, defaultIndexId: indexId || null }),
    });
    setPending(false);
    if (!res.ok) {
      toast({ title: "Couldn't create project", description: (await res.json()).error });
      return;
    }
    const { project } = await res.json();
    toast({ title: "Project created", variant: "success" });
    onCreated(project);
    onOpenChange(false);
    setName("");
    setDescription("");
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New project</DialogTitle>
          <DialogDescription>Group RFPs and pin a default knowledge base.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description (optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label>Default knowledge base</Label>
            <Select value={indexId} onValueChange={setIndexId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose an index" />
              </SelectTrigger>
              <SelectContent>
                {indexes.map((i) => (
                  <SelectItem key={i.id} value={i.id}>
                    {i.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="gradient" disabled={pending}>
              {pending ? "Creating…" : "Create"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
