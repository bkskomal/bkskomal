import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { toolRegistry } from "@/lib/ai/tools/registry";
import "@/lib/ai/tools/builtin";
import { ToolsClient } from "./client";

export default async function ToolsPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization, membership } = await getActiveOrg(sp.org);

  const configs = await prisma.toolConfig.findMany({
    where: { organizationId: organization.id },
    select: { name: true, enabled: true },
  });
  const overrides = new Map(configs.map((c) => [c.name, c.enabled]));

  const tools = toolRegistry.list().map((t) => ({
    name: t.name,
    description: t.description,
    enabled: overrides.get(t.name) !== false,
  }));

  return (
    <ToolsClient
      orgId={organization.id}
      role={membership.role}
      initial={tools}
    />
  );
}
