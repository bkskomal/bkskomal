"use client";

import { useState, useMemo } from "react";
import { Wrench, Loader2, Save, RotateCcw } from "lucide-react";
import { Role } from "@prisma/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import { PageHeader } from "@/components/dashboard/page-header";

interface ToolRow {
  name: string;
  description: string;
  enabled: boolean;
}

interface Props {
  orgId: string;
  role: Role;
  initial: ToolRow[];
}

// Tools the model uses most frequently for RFP work — grouped so the UI is
// scannable rather than a flat list. Names listed here are matched against
// the registry; anything not in any group falls into "Other".
const GROUPS: Array<{ id: string; label: string; description: string; names: string[] }> = [
  {
    id: "retrieval",
    label: "Knowledge & retrieval",
    description: "How the model finds evidence to ground its answers.",
    names: ["search_knowledge_base", "search_golden_answers", "find_similar_past_responses", "list_indexes", "list_documents"],
  },
  {
    id: "context",
    label: "RFP context",
    description: "Lets the model orient itself on the current RFP.",
    names: ["get_rfp_context", "list_rfp_questions", "get_question_detail"],
  },
  {
    id: "utility",
    label: "Utilities",
    description: "Small deterministic helpers for math, dates, and length.",
    names: ["calculator", "days_until", "word_count"],
  },
];

export function ToolsClient({ orgId, role, initial }: Props) {
  const [tools, setTools] = useState<ToolRow[]>(initial);
  const [dirty, setDirty] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const canEdit = role === "OWNER" || role === "ADMIN";

  const byName = useMemo(() => new Map(tools.map((t) => [t.name, t])), [tools]);
  const grouped = useMemo(() => {
    const used = new Set<string>();
    const out = GROUPS.map((g) => ({
      ...g,
      tools: g.names.map((n) => byName.get(n)).filter(Boolean) as ToolRow[],
    }));
    out.forEach((g) => g.tools.forEach((t) => used.add(t.name)));
    const other = tools.filter((t) => !used.has(t.name));
    if (other.length) {
      out.push({
        id: "other",
        label: "Other",
        description: "Custom tools registered by your org or recently added.",
        names: other.map((t) => t.name),
        tools: other,
      });
    }
    return out;
  }, [tools, byName]);

  const enabledCount = tools.filter((t) => t.enabled).length;

  function toggle(name: string) {
    setTools((prev) => prev.map((t) => (t.name === name ? { ...t, enabled: !t.enabled } : t)));
    setDirty((d) => new Set(d).add(name));
  }

  async function save() {
    setSaving(true);
    try {
      const changes = Array.from(dirty).map((name) => {
        const t = tools.find((x) => x.name === name)!;
        return { name, enabled: t.enabled };
      });
      const res = await fetch(`/api/orgs/${orgId}/tools`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ changes }),
      });
      if (!res.ok) {
        toast({ title: "Couldn't save", description: (await res.json()).error });
        return;
      }
      toast({ title: "Tool config saved", variant: "success" });
      setDirty(new Set());
    } finally {
      setSaving(false);
    }
  }

  function enableAll() {
    setTools((prev) => prev.map((t) => ({ ...t, enabled: true })));
    setDirty(new Set(tools.map((t) => t.name)));
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Tools"
        subtitle="The AI can call these tools while answering. Disable any you don't want the model to invoke. Tools without an override are enabled by default."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${orgId}` },
          { label: "Tools" },
        ]}
        actions={
          <div className="flex items-center gap-2">
            <Badge variant="outline">{enabledCount} / {tools.length} enabled</Badge>
            {canEdit && enabledCount < tools.length ? (
              <Button variant="ghost" size="sm" onClick={enableAll}>
                <RotateCcw className="h-4 w-4" /> Enable all
              </Button>
            ) : null}
          </div>
        }
      />

      {grouped.map((g) => (
        <Card key={g.id}>
          <CardHeader>
            <CardTitle className="text-base">{g.label}</CardTitle>
            <CardDescription>{g.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {g.tools.map((t) => (
              <label
                key={t.name}
                className="flex items-start gap-3 rounded-lg border bg-card p-3 cursor-pointer hover:bg-accent/30 transition-colors"
              >
                <div className="pt-0.5">
                  <Checkbox
                    checked={t.enabled}
                    onCheckedChange={() => canEdit && toggle(t.name)}
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <code className="font-mono text-sm font-semibold">{t.name}</code>
                    {t.enabled ? (
                      <Badge variant="success" className="text-[10px]">enabled</Badge>
                    ) : (
                      <Badge variant="outline" className="text-[10px]">disabled</Badge>
                    )}
                    {dirty.has(t.name) ? (
                      <Badge variant="warning" className="text-[10px]">unsaved</Badge>
                    ) : null}
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{t.description}</p>
                </div>
              </label>
            ))}
          </CardContent>
        </Card>
      ))}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add your own tool</CardTitle>
          <CardDescription>Two-step pattern</CardDescription>
        </CardHeader>
        <CardContent>
          <pre className="scrollbar-thin overflow-x-auto rounded-lg bg-muted p-4 text-xs">{`// src/lib/ai/tools/builtin.ts (or any file imported from there)

toolRegistry.register({
  name: "my_tool",
  description: "What the model should know about this tool",
  schema: z.object({
    query: z.string().describe("What to search for"),
  }),
  async execute({ query }, ctx) {
    // ctx has organizationId, projectId, rfpId, userId, defaultIndexId
    return { result: "..." };
  },
});`}</pre>
          <p className="mt-3 text-xs text-muted-foreground">
            Once registered, the tool appears on this page automatically and is exposed to the LLM
            via the OpenAI function-calling spec. Toggle it off here to hide it from the model
            without removing it from the codebase.
          </p>
        </CardContent>
      </Card>

      {canEdit ? (
        <div className="sticky bottom-0 -mx-4 flex items-center justify-end gap-2 border-t bg-background/90 px-4 py-3 backdrop-blur lg:-mx-8 lg:px-8">
          {dirty.size > 0 ? (
            <span className="self-center text-xs text-muted-foreground">
              {dirty.size} unsaved change{dirty.size === 1 ? "" : "s"}
            </span>
          ) : null}
          <Button variant="gradient" onClick={save} disabled={saving || dirty.size === 0}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save tool config
          </Button>
        </div>
      ) : null}
    </div>
  );
}
