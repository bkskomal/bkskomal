import { getActiveOrg } from "@/lib/dashboard";
import { resolveAiConfig } from "@/lib/ai/config";
import { PROVIDERS } from "@/lib/ai/providers";
import { maskSecret } from "@/lib/crypto";
import { prisma } from "@/lib/prisma";
import { SettingsClient } from "./client";

export default async function SettingsPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization, membership } = await getActiveOrg(sp.org);
  const resolved = await resolveAiConfig(organization.id);

  // Pull routing fields directly — they aren't part of ResolvedAiConfig since
  // they're decided per-request, not per-org-on-startup.
  const routingRow = await prisma.orgAiConfig.findUnique({
    where: { organizationId: organization.id },
    select: { routingEnabled: true, llmModelSimple: true, llmModelComplex: true },
  });

  const aiConfig = {
    llm: {
      provider: resolved.llm.provider,
      baseUrl: resolved.llm.baseUrl,
      apiKey: "__KEEP__",
      apiKeyMasked: maskSecret(resolved.llm.apiKey),
      hasApiKey: Boolean(resolved.llm.apiKey),
      model: resolved.llm.model,
      httpReferer: resolved.llm.httpReferer ?? "",
      appTitle: resolved.llm.appTitle ?? "",
    },
    embedding: {
      provider: resolved.embedding.provider,
      baseUrl: resolved.embedding.baseUrl,
      apiKey: "__KEEP__",
      apiKeyMasked: maskSecret(resolved.embedding.apiKey),
      hasApiKey: Boolean(resolved.embedding.apiKey),
      model: resolved.embedding.model,
      dimensions: resolved.embedding.dimensions,
    },
    llamaparse: {
      enabled: resolved.llamaparse.enabled,
      apiKey: "__KEEP__",
      apiKeyMasked: maskSecret(resolved.llamaparse.apiKey ?? ""),
      hasApiKey: Boolean(resolved.llamaparse.apiKey),
      resultType: resolved.llamaparse.resultType,
    },
    routing: {
      enabled: routingRow?.routingEnabled ?? false,
      modelSimple: routingRow?.llmModelSimple ?? "",
      modelComplex: routingRow?.llmModelComplex ?? "",
    },
    source: resolved.source,
  };

  return (
    <SettingsClient
      org={{ id: organization.id, name: organization.name, slug: organization.slug }}
      role={membership.role}
      aiConfig={aiConfig}
      providers={Object.values(PROVIDERS)}
    />
  );
}
