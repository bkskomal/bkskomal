"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Settings as SettingsIcon, AlertTriangle } from "lucide-react";
import { AiProvider, Role } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { AiConfigForm } from "@/components/settings/ai-config-form";
import { NotificationPreferences } from "@/components/settings/notification-preferences";
import { ApiKeysSection } from "@/components/settings/api-keys-section";
import { CacheSection } from "@/components/settings/cache-section";
import { SlackIntegrationSection } from "@/components/settings/slack-integration-section";
import { SamlSection } from "@/components/settings/saml-section";
import { LoraSection } from "@/components/settings/lora-section";
import { VectorBackendSection } from "@/components/settings/vector-backend-section";
import { RagRetrievalSection } from "@/components/settings/rag-retrieval-section";
import { ExtractionSection } from "@/components/settings/extraction-section";
import { ScrapingSection } from "@/components/settings/scraping-section";
import { GenerationSection } from "@/components/settings/generation-section";
import { RagProviderSection } from "@/components/settings/rag-provider-section";
import { ChatProviderSection } from "@/components/settings/chat-provider-section";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";

interface AiConfigState {
  llm: {
    provider: AiProvider | null;
    baseUrl: string;
    apiKey: string;
    apiKeyMasked: string;
    hasApiKey: boolean;
    model: string;
    httpReferer: string;
    appTitle: string;
  };
  embedding: {
    provider: AiProvider | null;
    baseUrl: string;
    apiKey: string;
    apiKeyMasked: string;
    hasApiKey: boolean;
    model: string;
    dimensions: number;
  };
  llamaparse: {
    enabled: boolean;
    apiKey: string;
    apiKeyMasked: string;
    hasApiKey: boolean;
    resultType: "text" | "markdown";
  };
  // Model routing (Phase 3B). Standard model lives on llm.model — these are
  // just the per-tier overrides + the master toggle.
  routing: {
    enabled: boolean;
    modelSimple: string;
    modelComplex: string;
  };
  source: any;
}

interface ProviderInfo {
  id: AiProvider;
  shortId: string;
  label: string;
  llmBaseUrl: string;
  embeddingBaseUrl?: string;
  llmModels: string[];
  embeddingModels?: Array<{ name: string; dimensions: number }>;
  keyHint?: string;
  keyUrl?: string;
  hasEmbeddings: boolean;
  hasModelsApi: boolean;
  isLocal: boolean;
  requiresApiKey: boolean;
  notes?: string;
}

interface Props {
  org: { id: string; name: string; slug: string };
  role: Role;
  aiConfig: AiConfigState;
  providers: ProviderInfo[];
}

export function SettingsClient({ org, role, aiConfig, providers }: Props) {
  const router = useRouter();
  const confirm = useConfirm();
  const [name, setName] = useState(org.name);
  const [pending, setPending] = useState(false);
  const canEdit = role === "OWNER" || role === "ADMIN";
  const isOwner = role === "OWNER";

  async function rename(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    const res = await fetch(`/api/orgs/${org.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name }),
    });
    setPending(false);
    if (res.ok) {
      toast({ title: "Saved", variant: "success" });
      router.refresh();
    } else {
      toast({ title: "Couldn't save", description: (await res.json()).error });
    }
  }

  async function deleteOrg() {
    if (!(await confirm(`This cannot be undone.`, { title: `Permanently delete "${org.name}"?`, destructive: true, confirmLabel: "Delete organization" }))) return;
    const res = await fetch(`/api/orgs/${org.id}`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Organization deleted" });
      router.push("/dashboard");
    } else {
      toast({ title: "Couldn't delete", description: (await res.json()).error });
    }
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Settings"
        subtitle={`Organization: ${org.name}`}
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${org.id}` },
          { label: "Settings" },
        ]}
      />

      <Card>
        <CardHeader>
          <CardTitle>Organization</CardTitle>
          <CardDescription>Slug: {org.slug}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={rename} className="flex max-w-md gap-2">
            <div className="flex-1">
              <Label htmlFor="org-name" className="sr-only">
                Name
              </Label>
              <Input
                id="org-name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                disabled={!canEdit}
              />
            </div>
            <Button type="submit" disabled={!canEdit || pending}>
              Save
            </Button>
          </form>
        </CardContent>
      </Card>

      <div>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="text-lg font-semibold tracking-tight">AI configuration</h2>
          <p className="text-xs text-muted-foreground">
            Org-level settings override the env defaults. API keys are encrypted at rest.
          </p>
        </div>
        <AiConfigForm orgId={org.id} canEdit={canEdit} initial={aiConfig} providers={providers} />
      </div>

      <NotificationPreferences />

      <ApiKeysSection orgId={org.id} />

      {canEdit ? <SlackIntegrationSection orgId={org.id} canEdit={canEdit} /> : null}

      {canEdit ? <SamlSection orgId={org.id} orgSlug={org.slug} /> : null}

      {canEdit ? <CacheSection orgId={org.id} canEdit={canEdit} /> : null}

      {canEdit ? <LoraSection orgId={org.id} /> : null}

      {canEdit ? <VectorBackendSection orgId={org.id} /> : null}

      <ChatProviderSection orgId={org.id} canEdit={canEdit} />

      <RagProviderSection orgId={org.id} canEdit={canEdit} />

      <RagRetrievalSection orgId={org.id} canEdit={canEdit} />

      <ExtractionSection orgId={org.id} canEdit={canEdit} />

      <ScrapingSection orgId={org.id} canEdit={canEdit} />

      <GenerationSection orgId={org.id} canEdit={canEdit} />

      {isOwner ? (
        <Card className="border-destructive/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <AlertTriangle className="h-4 w-4" />
              Danger zone
            </CardTitle>
            <CardDescription>
              Delete this organization and everything in it: projects, RFPs, indexes, documents,
              and members.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="destructive" onClick={deleteOrg}>
              Delete organization
            </Button>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
