import { ArrowDownRight, ArrowRight, ArrowUpRight, BarChart3, CheckCircle2, Clock, FileSearch, FileStack, HardDrive, Image as ImageIcon, Layers, ShieldAlert, ShieldCheck, Sparkles, Trophy } from "lucide-react";
import { getActiveOrg } from "@/lib/dashboard";
import { computeOrgInsights } from "@/lib/insights";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ConfidenceHistogramChart, OutcomeDistributionBar, ThroughputChart } from "./insights-client";
import { PageHeader } from "@/components/dashboard/page-header";

export default async function InsightsPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization } = await getActiveOrg(sp.org);
  const insights = await computeOrgInsights(organization.id);
  const c = insights.cards;

  return (
    <div className="space-y-8">
      <PageHeader
        title="Insights"
        subtitle="Last 30 days of activity. Counters refresh on every page load."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${organization.id}` },
          { label: "Insights" },
        ]}
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard
          icon={CheckCircle2}
          label="Questions answered (30d)"
          value={String(c.questionsAnswered)}
        />
        <StatCard
          icon={Sparkles}
          label="Avg confidence (30d)"
          value={c.avgConfidence == null ? "—" : `${(c.avgConfidence * 100).toFixed(0)}%`}
          trendPct={c.avgConfidenceTrendPct}
        />
        <StatCard
          icon={Clock}
          label="Avg time to answer"
          value={formatDuration(c.avgTimeToAnswerMs)}
        />
        <StatCard
          icon={Layers}
          label="RFPs in flight"
          value={String(c.rfpsInFlight)}
        />
        <StatCard
          icon={FileSearch}
          label="Bulk-generation jobs (30d)"
          value={String(c.bulkJobsRun)}
        />
        <StatCard
          icon={ShieldAlert}
          label="Rate-limit blocks (7d)"
          value={String(c.rateLimitBlocks7d)}
        />
        <StatCard
          icon={ShieldCheck}
          label="Grounded answers (30d)"
          value={c.groundedAnswersPct == null ? "—" : `${c.groundedAnswersPct.toFixed(0)}%`}
        />
        <StatCard
          icon={FileStack}
          label="Avg docs per RFP"
          value={c.avgDocsPerRfp == null ? "—" : c.avgDocsPerRfp.toFixed(1)}
        />
        <StatCard
          icon={Trophy}
          label="Win rate (90d)"
          value={c.winRatePct90d == null ? "—" : `${c.winRatePct90d.toFixed(0)}%`}
          sublabel={
            c.winRatePct90d == null
              ? "No decided RFPs in window"
              : `${c.wonCount90d} won · ${c.lostCount90d} lost`
          }
        />
        <StatCard
          icon={ImageIcon}
          label="Images indexed (30d)"
          value={String(c.imagesIndexed30d)}
        />
        <StatCard
          icon={HardDrive}
          label="Image storage (est.)"
          value={c.imageStorageMb > 0 ? `${c.imageStorageMb.toFixed(1)} MB` : "—"}
          sublabel="Approx. width×height×4 across all images"
        />
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              RFP outcome distribution
            </CardTitle>
            <CardDescription>
              All-time. Closes the win/loss feedback loop — WON answers feed
              forward into retrieval, LOST surface coaching on similar future
              questions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <OutcomeDistributionBar data={insights.charts.outcomeDistribution} />
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Confidence distribution
            </CardTitle>
            <CardDescription>Self-rated confidence on responses, last 30d.</CardDescription>
          </CardHeader>
          <CardContent>
            <ConfidenceHistogramChart data={insights.charts.confidenceHistogram} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Throughput by day
            </CardTitle>
            <CardDescription>Questions answered per day, last 30d.</CardDescription>
          </CardHeader>
          <CardContent>
            <ThroughputChart data={insights.charts.throughputByDay} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  trendPct,
  sublabel,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  trendPct?: number | null;
  /** Optional secondary line (e.g. "3 won · 1 lost"). Rendered below the
   *  label in muted text. Mutually OK to use alongside trendPct. */
  sublabel?: string;
}) {
  let trend: React.ReactNode = null;
  if (trendPct != null) {
    const TrendIcon = trendPct > 0 ? ArrowUpRight : trendPct < 0 ? ArrowDownRight : ArrowRight;
    const colorClass = trendPct > 0 ? "text-emerald-600" : trendPct < 0 ? "text-rose-600" : "text-muted-foreground";
    trend = (
      <span className={`mt-1 inline-flex items-center text-xs font-medium ${colorClass}`}>
        <TrendIcon className="h-3 w-3" />
        {trendPct > 0 ? "+" : ""}
        {trendPct.toFixed(1)}% vs prior 30d
      </span>
    );
  }
  return (
    <Card className="overflow-hidden">
      <CardContent className="flex items-start justify-between gap-3 p-6">
        <div className="min-w-0">
          <div className="text-2xl font-bold tracking-tight">{value}</div>
          <div className="mt-1 text-xs text-muted-foreground">{label}</div>
          {sublabel ? (
            <div className="mt-1 text-[11px] text-muted-foreground/80">{sublabel}</div>
          ) : null}
          {trend}
        </div>
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
          <Icon className="h-5 w-5" />
        </div>
      </CardContent>
    </Card>
  );
}

function formatDuration(ms: number | null): string {
  if (ms == null || !Number.isFinite(ms) || ms < 0) return "—";
  const sec = Math.round(ms / 1000);
  if (sec < 60) return `${sec}s`;
  const min = Math.round(sec / 60);
  if (min < 60) return `${min}m`;
  const hr = Math.round(min / 60 * 10) / 10;
  if (hr < 48) return `${hr}h`;
  const days = Math.round((hr / 24) * 10) / 10;
  return `${days}d`;
}
