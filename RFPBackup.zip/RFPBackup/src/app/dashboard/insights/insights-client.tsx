"use client";

// Inline-SVG charts for the insights dashboard. We deliberately avoid pulling
// in a chart library — the data shapes are simple, and rolling our own keeps
// the bundle lean and the styling consistent with the rest of the app.
//
// Both charts render as a fixed-height responsive SVG with a viewBox; the
// container scales horizontally. Each bar shows a hover tooltip via <title>.

import { useState } from "react";

interface BucketDatum {
  bucket: string;
  count: number;
}

interface DayDatum {
  date: string;
  count: number;
}

const CHART_W = 600;
const CHART_H = 200;
const PAD = { top: 12, right: 12, bottom: 28, left: 32 };

export function ConfidenceHistogramChart({ data }: { data: BucketDatum[] }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  const innerW = CHART_W - PAD.left - PAD.right;
  const innerH = CHART_H - PAD.top - PAD.bottom;
  const barW = innerW / data.length - 4;

  return (
    <ChartShell ariaLabel="Confidence distribution histogram" max={max}>
      {data.map((d, i) => {
        const h = (d.count / max) * innerH;
        const x = PAD.left + i * (innerW / data.length) + 2;
        const y = PAD.top + (innerH - h);
        return (
          <g key={d.bucket}>
            <rect
              x={x}
              y={y}
              width={barW}
              height={h}
              rx={2}
              className="fill-primary/70 hover:fill-primary"
            >
              <title>{`${d.bucket}: ${d.count}`}</title>
            </rect>
            <text
              x={x + barW / 2}
              y={CHART_H - 8}
              textAnchor="middle"
              className="fill-muted-foreground text-[9px]"
            >
              {d.bucket.split("-")[0]}
            </text>
          </g>
        );
      })}
    </ChartShell>
  );
}

export function ThroughputChart({ data }: { data: DayDatum[] }) {
  const max = Math.max(1, ...data.map((d) => d.count));
  const innerW = CHART_W - PAD.left - PAD.right;
  const innerH = CHART_H - PAD.top - PAD.bottom;
  const barW = Math.max(1, innerW / data.length - 1);
  const [hover, setHover] = useState<number | null>(null);

  return (
    <ChartShell ariaLabel="Throughput by day" max={max}>
      {data.map((d, i) => {
        const h = (d.count / max) * innerH;
        const x = PAD.left + i * (innerW / data.length) + 0.5;
        const y = PAD.top + (innerH - h);
        const isHover = hover === i;
        return (
          <g
            key={d.date}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
          >
            <rect
              x={x}
              y={y}
              width={barW}
              height={h}
              rx={1}
              className={isHover ? "fill-primary" : "fill-primary/60"}
            >
              <title>{`${d.date}: ${d.count}`}</title>
            </rect>
          </g>
        );
      })}
      {/* x-axis labels: just first / mid / last to avoid clutter */}
      {[0, Math.floor(data.length / 2), data.length - 1]
        .filter((idx) => data[idx])
        .map((idx) => {
          const x = PAD.left + idx * (innerW / data.length) + barW / 2;
          return (
            <text
              key={idx}
              x={x}
              y={CHART_H - 8}
              textAnchor="middle"
              className="fill-muted-foreground text-[9px]"
            >
              {data[idx].date.slice(5)}
            </text>
          );
        })}
    </ChartShell>
  );
}

// --- Win/loss feedback loop: stacked outcome bar ---
//
// Renders a single horizontal stacked bar so the eye can compare relative
// outcome shares at a glance. Colors are anchored to the same semantics used
// by the RFP-detail outcome chip so the dashboard and the chip stay legible
// when read together: green = WON, red = LOST, amber = WITHDRAWN, slate =
// NO_BID, muted = PENDING.
const OUTCOME_COLORS: Record<string, string> = {
  PENDING: "fill-muted-foreground/40",
  WON: "fill-emerald-500",
  LOST: "fill-rose-500",
  WITHDRAWN: "fill-amber-400",
  NO_BID: "fill-slate-400",
};

const OUTCOME_LABELS: Record<string, string> = {
  PENDING: "Pending",
  WON: "Won",
  LOST: "Lost",
  WITHDRAWN: "Withdrawn",
  NO_BID: "No bid",
};

interface OutcomeDatum {
  outcome: "PENDING" | "WON" | "LOST" | "WITHDRAWN" | "NO_BID";
  count: number;
}

export function OutcomeDistributionBar({ data }: { data: OutcomeDatum[] }) {
  const total = data.reduce((acc, d) => acc + d.count, 0);
  if (total === 0) {
    return (
      <p className="py-6 text-center text-sm text-muted-foreground">
        No RFPs yet. Outcomes will appear here once you start setting them
        on RFP detail pages.
      </p>
    );
  }
  // Single bar, 24px tall. We compute cumulative offsets so the segments
  // butt together with no gap and the legend below maps 1:1.
  const barH = 24;
  const barW = CHART_W - PAD.left - PAD.right;
  let xOffset = PAD.left;
  return (
    <div className="w-full space-y-3">
      <svg
        viewBox={`0 0 ${CHART_W} ${barH + 16}`}
        className="h-10 w-full"
        role="img"
        aria-label="RFP outcome distribution"
      >
        {data.map((d) => {
          const w = (d.count / total) * barW;
          const x = xOffset;
          xOffset += w;
          return (
            <rect
              key={d.outcome}
              x={x}
              y={8}
              width={w}
              height={barH}
              className={OUTCOME_COLORS[d.outcome]}
            >
              <title>{`${OUTCOME_LABELS[d.outcome]}: ${d.count} (${((d.count / total) * 100).toFixed(0)}%)`}</title>
            </rect>
          );
        })}
      </svg>
      <ul className="flex flex-wrap gap-x-4 gap-y-1 text-xs">
        {data.map((d) => (
          <li key={d.outcome} className="flex items-center gap-1.5 text-muted-foreground">
            <span
              className={`inline-block h-2 w-2 rounded-sm ${OUTCOME_COLORS[d.outcome].replace("fill-", "bg-")}`}
            />
            <span className="font-medium text-foreground">{OUTCOME_LABELS[d.outcome]}</span>
            <span>·</span>
            <span>{d.count}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ChartShell({
  ariaLabel,
  max,
  children,
}: {
  ariaLabel: string;
  max: number;
  children: React.ReactNode;
}) {
  const innerH = CHART_H - PAD.top - PAD.bottom;
  return (
    <div className="w-full">
      <svg
        viewBox={`0 0 ${CHART_W} ${CHART_H}`}
        className="h-48 w-full"
        role="img"
        aria-label={ariaLabel}
      >
        {/* y-axis grid: max + half */}
        <line
          x1={PAD.left}
          x2={CHART_W - PAD.right}
          y1={PAD.top + innerH}
          y2={PAD.top + innerH}
          className="stroke-border"
        />
        <line
          x1={PAD.left}
          x2={CHART_W - PAD.right}
          y1={PAD.top + innerH / 2}
          y2={PAD.top + innerH / 2}
          className="stroke-border/40"
          strokeDasharray="2 4"
        />
        <text
          x={PAD.left - 4}
          y={PAD.top + 4}
          textAnchor="end"
          className="fill-muted-foreground text-[9px]"
        >
          {max}
        </text>
        <text
          x={PAD.left - 4}
          y={PAD.top + innerH + 4}
          textAnchor="end"
          className="fill-muted-foreground text-[9px]"
        >
          0
        </text>
        {children}
      </svg>
    </div>
  );
}
