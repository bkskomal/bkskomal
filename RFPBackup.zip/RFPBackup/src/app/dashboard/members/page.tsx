import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { MembersClient } from "./client";

export default async function MembersPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization, membership } = await getActiveOrg(sp.org);

  const [members, invites] = await Promise.all([
    prisma.membership.findMany({
      where: { organizationId: organization.id },
      include: { user: { select: { email: true, name: true } } },
      orderBy: { createdAt: "asc" },
    }),
    prisma.invite.findMany({
      where: { organizationId: organization.id, acceptedAt: null },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  return (
    <MembersClient
      orgId={organization.id}
      currentRole={membership.role}
      members={members.map((m) => ({
        id: m.id,
        role: m.role,
        userId: m.userId,
        email: m.user.email,
        name: m.user.name,
      }))}
      invites={invites.map((i) => ({
        id: i.id,
        email: i.email,
        role: i.role,
        token: i.token,
        expiresAt: i.expiresAt.toISOString(),
      }))}
    />
  );
}
