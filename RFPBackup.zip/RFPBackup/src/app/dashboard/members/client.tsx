"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Mail, UserPlus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { Role } from "@prisma/client";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";

interface MemberRow {
  id: string;
  role: Role;
  userId: string;
  email: string;
  name: string | null;
}
interface InviteRow {
  id: string;
  email: string;
  role: Role;
  token: string;
  expiresAt: string;
}

export function MembersClient({
  orgId,
  currentRole,
  members: initialMembers,
  invites: initialInvites,
}: {
  orgId: string;
  currentRole: Role;
  members: MemberRow[];
  invites: InviteRow[];
}) {
  const router = useRouter();
  const confirm = useConfirm();
  const [members, setMembers] = useState(initialMembers);
  const [invites, setInvites] = useState(initialInvites);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("MEMBER");

  const canManage = currentRole === "OWNER" || currentRole === "ADMIN";

  async function invite(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch(`/api/orgs/${orgId}/members`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email, role }),
    });
    if (!res.ok) {
      toast({ title: "Failed to invite", description: (await res.json()).error });
      return;
    }
    const data = await res.json();
    if (data.attached) {
      setMembers((prev) => [
        ...prev,
        {
          id: data.membership.id,
          role: data.membership.role,
          userId: data.membership.userId,
          email,
          name: null,
        },
      ]);
      toast({ title: "Member added", variant: "success" });
    } else {
      setInvites((prev) => [data.invite, ...prev]);
      toast({ title: `Invite sent to ${email}`, variant: "success" });
    }
    setEmail("");
    router.refresh();
  }

  async function changeRole(membershipId: string, newRole: Role) {
    const res = await fetch(`/api/orgs/${orgId}/members/${membershipId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ role: newRole }),
    });
    if (!res.ok) {
      toast({ title: "Couldn't update", description: (await res.json()).error });
      return;
    }
    setMembers((prev) => prev.map((m) => (m.id === membershipId ? { ...m, role: newRole } : m)));
  }

  async function remove(membershipId: string) {
    if (!(await confirm("Remove this member?", { destructive: true, confirmLabel: "Remove" }))) return;
    const res = await fetch(`/api/orgs/${orgId}/members/${membershipId}`, { method: "DELETE" });
    if (!res.ok) {
      toast({ title: "Couldn't remove", description: (await res.json()).error });
      return;
    }
    setMembers((prev) => prev.filter((m) => m.id !== membershipId));
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Members"
        subtitle="Invite teammates and manage their roles."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${orgId}` },
          { label: "Members" },
        ]}
      />

      {canManage ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Invite</CardTitle>
            <CardDescription>
              We&apos;ll create an invite token. Existing users get attached immediately.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={invite} className="flex flex-wrap gap-2">
              <div className="flex-1 min-w-[200px]">
                <Label htmlFor="email" className="sr-only">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="teammate@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <Select value={role} onValueChange={(v) => setRole(v as Role)}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="MEMBER">Member</SelectItem>
                  <SelectItem value="ADMIN">Admin</SelectItem>
                  <SelectItem value="OWNER">Owner</SelectItem>
                </SelectContent>
              </Select>
              <Button type="submit" variant="gradient">
                <UserPlus className="h-4 w-4" /> Invite
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Active members</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {members.map((m) => {
            const initials = (m.name ?? m.email).slice(0, 2).toUpperCase();
            return (
              <div
                key={m.id}
                className="flex items-center justify-between rounded-lg border bg-card p-3"
              >
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>{initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="text-sm font-medium">{m.name ?? m.email}</div>
                    {m.name ? (
                      <div className="text-xs text-muted-foreground">{m.email}</div>
                    ) : null}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {canManage ? (
                    <Select value={m.role} onValueChange={(v) => changeRole(m.id, v as Role)}>
                      <SelectTrigger className="w-[120px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MEMBER">Member</SelectItem>
                        <SelectItem value="ADMIN">Admin</SelectItem>
                        <SelectItem value="OWNER">Owner</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Badge variant="outline">{m.role}</Badge>
                  )}
                  {canManage ? (
                    <Button size="icon" variant="ghost" onClick={() => remove(m.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  ) : null}
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {invites.length ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Pending invites</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {invites.map((i) => (
              <div
                key={i.id}
                className="flex items-center justify-between rounded-lg border bg-card p-3"
              >
                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm">{i.email}</div>
                    <div className="text-xs text-muted-foreground">Token: {i.token.slice(0, 8)}…</div>
                  </div>
                </div>
                <Badge variant="outline">{i.role}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
