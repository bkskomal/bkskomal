import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { GoldenClient } from "./client";

export default async function GoldenPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization } = await getActiveOrg(sp.org);

  const items = await prisma.goldenAnswer.findMany({
    where: { organizationId: organization.id },
    orderBy: { updatedAt: "desc" },
  });

  return (
    <GoldenClient
      orgId={organization.id}
      items={items.map((i) => ({
        id: i.id,
        question: i.question,
        answer: i.answer,
        tags: i.tags,
        updatedAt: i.updatedAt.toISOString(),
      }))}
    />
  );
}
