"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Star, Trash2, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";
import { formatDate } from "@/lib/utils";

interface Item {
  id: string;
  question: string;
  answer: string;
  tags: string[];
  updatedAt: string;
}

export function GoldenClient({ orgId, items: initial }: { orgId: string; items: Item[] }) {
  const router = useRouter();
  const confirm = useConfirm();
  const [items, setItems] = useState(initial);
  const [editing, setEditing] = useState<Item | null>(null);
  const [open, setOpen] = useState(false);

  function openNew() {
    setEditing(null);
    setOpen(true);
  }
  function openEdit(item: Item) {
    setEditing(item);
    setOpen(true);
  }

  async function remove(id: string) {
    if (!(await confirm("Delete this golden answer?", { destructive: true, confirmLabel: "Delete" }))) return;
    const res = await fetch(`/api/orgs/${orgId}/golden/${id}`, { method: "DELETE" });
    if (res.ok) {
      setItems((prev) => prev.filter((i) => i.id !== id));
      toast({ title: "Deleted" });
      router.refresh();
    }
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Golden Answers"
        subtitle="Curated reference Q&A pairs the model uses as style and content guidance for similar future questions."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${orgId}` },
          { label: "Golden Answers" },
        ]}
        actions={
          <Button variant="gradient" onClick={openNew}>
            <Plus className="h-4 w-4" /> New Golden Answer
          </Button>
        }
      />

      {items.length === 0 ? (
        <Card>
          <CardContent className="grid place-items-center py-16 text-center">
            <Star className="h-10 w-10 text-amber-500" />
            <div className="mt-4 text-lg font-medium">No golden answers yet</div>
            <p className="mt-1 max-w-sm text-sm text-muted-foreground">
              Pin your best past responses here. The model will use them as in-context guidance
              when generating similar new responses.
            </p>
            <Button className="mt-4" variant="gradient" onClick={openNew}>
              <Plus className="h-4 w-4" /> Add the first one
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {items.map((it) => (
            <Card key={it.id}>
              <CardHeader>
                <CardTitle className="text-base">{it.question}</CardTitle>
                <CardDescription>Updated {formatDate(it.updatedAt)}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="line-clamp-4 text-sm text-muted-foreground whitespace-pre-wrap">
                  {it.answer}
                </p>
                <div className="mt-3 flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(it)}>
                    <Pencil className="h-4 w-4" /> Edit
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => remove(it.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" /> Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <GoldenDialog
        open={open}
        onOpenChange={setOpen}
        orgId={orgId}
        editing={editing}
        onSaved={(item) => {
          setItems((prev) => {
            const existing = prev.find((p) => p.id === item.id);
            if (existing) return prev.map((p) => (p.id === item.id ? item : p));
            return [item, ...prev];
          });
          router.refresh();
        }}
      />
    </div>
  );
}

function GoldenDialog({
  open,
  onOpenChange,
  orgId,
  editing,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  orgId: string;
  editing: Item | null;
  onSaved: (item: Item) => void;
}) {
  const [question, setQuestion] = useState(editing?.question ?? "");
  const [answer, setAnswer] = useState(editing?.answer ?? "");
  const [pending, setPending] = useState(false);

  // Reset on edit change
  if (editing && editing.question !== question && editing.answer !== answer && !pending) {
    // leave inputs as-is; user is editing
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    const url = editing
      ? `/api/orgs/${orgId}/golden/${editing.id}`
      : `/api/orgs/${orgId}/golden`;
    const method = editing ? "PATCH" : "POST";
    const res = await fetch(url, {
      method,
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question, answer }),
    });
    setPending(false);
    if (!res.ok) {
      toast({ title: "Couldn't save", description: (await res.json()).error });
      return;
    }
    const { item } = await res.json();
    onSaved({
      id: item.id,
      question: item.question,
      answer: item.answer,
      tags: item.tags ?? [],
      updatedAt: item.updatedAt,
    });
    toast({ title: "Saved", variant: "success" });
    onOpenChange(false);
    setQuestion("");
    setAnswer("");
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{editing ? "Edit golden answer" : "New golden answer"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="g-q">Question</Label>
            <Textarea
              id="g-q"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              required
              rows={3}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="g-a">Ideal answer</Label>
            <Textarea
              id="g-a"
              value={answer}
              onChange={(e) => setAnswer(e.target.value)}
              required
              rows={10}
              className="font-mono text-sm leading-relaxed"
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" variant="gradient" disabled={pending}>
              {pending ? "Saving…" : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
