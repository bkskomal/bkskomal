"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  AlertTriangle,
  ArrowLeft,
  Sparkles,
  RefreshCw,
  ChevronRight,
  ThumbsUp,
  ThumbsDown,
  FileText,
  Loader2,
  XCircle,
  MessageSquare,
  Layers,
  Download,
  Activity as ActivityIcon,
  Trash2,
} from "lucide-react";
import { QuestionStatus, FeedbackKind } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Markdown } from "@/components/markdown";
import { ChatPanel } from "@/components/chat/chat-panel";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import { cn, truncate } from "@/lib/utils";
import { QuestionTable, type QuestionRow } from "@/components/rfp/question-table";
import { StatusBadge } from "@/components/rfp/status-badge";
import { StatusPicker } from "@/components/rfp/status-picker";
import { AssigneePicker } from "@/components/rfp/assignee-picker";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";
import { CommentsThread } from "@/components/rfp/comments-thread";
import { ActivityFeed } from "@/components/rfp/activity-feed";
import { BulkProgress } from "@/components/rfp/bulk-progress";
import { DueDatePill } from "@/components/rfp/due-date";
import { RfpDueDateEditor } from "@/components/rfp/due-date-editor";
import { PipelineStepper } from "@/components/rfp/pipeline-stepper";
import { DocumentsPanel, type AttachmentRow } from "@/components/rfp/documents-panel";
import { OutcomeChip, type RfpOutcomeValue } from "@/components/rfp/outcome-chip";
import { ResponseEditor } from "@/components/rfp/response-editor";
import { RubricPanel, type RubricView } from "@/components/rfp/rubric-panel";
import { WinPredictionPanel } from "@/components/rfp/win-prediction-panel";
import { ImageSourceCitation } from "@/components/rfp/image-source-citation";

interface RfpInfo {
  id: string;
  title: string;
  status: string;
  errorMessage: string | null;
  fileName: string;
  fileSize: number;
  projectId: string;
  projectName: string;
  organizationId: string;
  defaultIndexId: string | null;
  dueDate: string | null;
  outcome: RfpOutcomeValue;
  outcomeNote: string | null;
}

export interface CrossRefView {
  primaryQuestionId: string;
  attachmentRfpId: string;
  attachmentQuestionNumber?: number;
  attachmentSnippet: string;
  reason: string;
}

interface SourceImageInfo {
  id: string;
  imagePath: string;
  caption: string | null;
  ocrText: string | null;
  page: number | null;
  width: number | null;
  height: number | null;
  documentId: string;
  indexId: string;
}

interface SourceRow {
  id: string;
  fileName: string | null;
  page: number | null;
  excerpt: string;
  score: number;
  // Phase IM: image citations render with an inline thumbnail. `kind` is
  // "text" for the legacy / default case and "image" only when the linked
  // chunk is a figure-kind block with an associated ImageEmbedding row.
  kind?: "text" | "image";
  image?: SourceImageInfo | null;
}

/**
 * Per-claim grounding label, matching the GroundingClaim shape on the server.
 * Stored as Json on Response.groundingNotes.
 */
interface GroundingClaim {
  claim: string;
  support: "supported" | "weak" | "unsupported";
  sourceIds?: string[];
  note?: string;
}

/** Mirror of the StaleSourceWarning shape on the server (lib/ai/generate). */
interface StaleSourceWarning {
  documentId: string;
  fileName: string;
  reason: string;
  sourceDate: string | null;
}

interface ResponseInfo {
  id: string;
  content: string;
  status: string;
  indexId: string | null;
  confidence: number | null;
  needsReview: boolean;
  groundingScore: number | null;
  groundingNotes: GroundingClaim[] | unknown | null;
  groundingAt: string | null;
  sources: SourceRow[];
  myFeedback: FeedbackKind | null;
  /**
   * Stale-source warnings (Tier B2). Non-empty when the generator flagged
   * at least one cited document as older than the staleness threshold; the
   * viewer renders a banner above the response.
   */
  staleSourceWarnings?: StaleSourceWarning[];
}

interface QuestionView {
  id: string;
  number: number;
  section: string | null;
  text: string;
  status: QuestionStatus;
  confidence: number | null;
  commentCount: number;
  dueDate: string | null;
  assignee: { id: string; name: string | null; email: string } | null;
  latestResponse: ResponseInfo | null;
}

interface Member {
  userId: string;
  email: string;
  name: string | null;
}

interface ReasoningStep {
  step: string;
  detail: string;
  data?: unknown;
}

interface Props {
  currentUserId: string;
  isAdmin?: boolean;
  rfp: RfpInfo;
  indexes: { id: string; name: string }[];
  members: Member[];
  runningBulkId: string | null;
  questions: QuestionView[];
  attachments?: AttachmentRow[];
  crossRefs?: CrossRefView[];
  rubric?: RubricView | null;
}

export function RfpViewer(props: Props) {
  const { currentUserId, rfp, indexes, members } = props;
  const isAdmin = props.isAdmin ?? false;
  const attachments = props.attachments ?? [];
  const crossRefs = props.crossRefs ?? [];
  // Group cross-refs by primary question id once so the per-question lookup
  // in the detail panel is O(1).
  const crossRefByQuestion = useMemo(() => {
    const map = new Map<string, CrossRefView[]>();
    for (const r of crossRefs) {
      const list = map.get(r.primaryQuestionId);
      if (list) list.push(r);
      else map.set(r.primaryQuestionId, [r]);
    }
    return map;
  }, [crossRefs]);
  // Build a lookup from attachment id to docRole for badge labeling.
  const attachmentRoleById = useMemo(() => {
    const m = new Map<string, string>();
    for (const a of attachments) m.set(a.id, a.docRole);
    return m;
  }, [attachments]);
  const router = useRouter();
  const confirm = useConfirm();
  const [questions, setQuestions] = useState(props.questions);
  const [activeId, setActiveId] = useState<string | null>(props.questions[0]?.id ?? null);
  const [indexId, setIndexId] = useState<string>(rfp.defaultIndexId ?? "");
  const [enableTools, setEnableTools] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);
  const [activityOpen, setActivityOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [deletingRfp, setDeletingRfp] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [runningBulkId, setRunningBulkId] = useState<string | null>(props.runningBulkId);
  const [rfpDueDate, setRfpDueDate] = useState<string | null>(rfp.dueDate);

  // Sync from props on refresh.
  useEffect(() => {
    setQuestions(props.questions);
  }, [props.questions]);

  useEffect(() => {
    if (!["UPLOADED", "EXTRACTING"].includes(rfp.status)) return;
    const interval = setInterval(() => router.refresh(), 3000);
    return () => clearInterval(interval);
  }, [rfp.status, router]);

  useEffect(() => {
    if (!runningBulkId) return;
    const i = setInterval(() => router.refresh(), 4000);
    return () => clearInterval(i);
  }, [runningBulkId, router]);

  const active = questions.find((q) => q.id === activeId) ?? null;

  // IMPORTANT: every hook (including the `stats` useMemo below) MUST run on
  // every render — including the "not yet READY" early-return branch — or
  // React fires "change in the order of Hooks called" when the RFP status
  // flips. So we compute `stats` here, before the conditional return.
  const stats = useMemo(() => {
    let answered = 0;
    let approved = 0;
    let needsReview = 0;
    for (const q of questions) {
      if (q.latestResponse?.status === "COMPLETED") answered++;
      if (q.status === "APPROVED") approved++;
      if (q.latestResponse?.needsReview) needsReview++;
    }
    return { total: questions.length, answered, approved, needsReview };
  }, [questions]);

  if (rfp.status !== "READY" && rfp.status !== "GENERATING" && rfp.status !== "COMPLETED") {
    return (
      <div className="space-y-6">
        <BackLink rfp={rfp} />
        <Card>
          <CardContent className="grid place-items-center gap-3 py-20 text-center">
            {rfp.status === "FAILED" ? (
              <>
                <XCircle className="h-10 w-10 text-destructive" />
                <div className="text-lg font-medium">Processing failed</div>
                <p className="max-w-md text-sm text-muted-foreground">
                  {rfp.errorMessage ?? "Something went wrong while extracting questions."}
                </p>
                <Button onClick={() => reprocess(rfp.id, router)}>
                  <RefreshCw className="h-4 w-4" /> Try again
                </Button>
              </>
            ) : (
              <>
                <Loader2 className="h-10 w-10 animate-spin text-primary" />
                <div className="text-lg font-medium">Extracting questions…</div>
                {/* div not p: Badge renders a div, and <p><div/></p> is
                    invalid HTML → React fires a hydration warning. */}
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  Status: <Badge variant="outline">{rfp.status}</Badge>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  function patchQuestion(id: string, patch: Partial<QuestionView>) {
    setQuestions((prev) => prev.map((q) => (q.id === id ? { ...q, ...patch } : q)));
  }

  async function changeStatus(id: string, status: QuestionStatus) {
    patchQuestion(id, { status });
    await fetch(`/api/questions/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ status }),
    });
  }
  async function changeAssignee(id: string, userId: string | null) {
    const member = userId ? members.find((m) => m.userId === userId) : null;
    patchQuestion(id, {
      assignee: member ? { id: member.userId, name: member.name, email: member.email } : null,
    });
    await fetch(`/api/questions/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ assigneeId: userId }),
    });
  }

  function toggleSelected(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    if (selectedIds.size === questions.length) setSelectedIds(new Set());
    else setSelectedIds(new Set(questions.map((q) => q.id)));
  }
  function clearSelection() {
    setSelectedIds(new Set());
  }

  async function bulkSetStatus(status: QuestionStatus) {
    if (selectedIds.size === 0) return;
    const ids = Array.from(selectedIds);
    setQuestions((prev) => prev.map((q) => (selectedIds.has(q.id) ? { ...q, status } : q)));
    await fetch(`/api/rfps/${rfp.id}/questions/bulk`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ questionIds: ids, status }),
    });
    toast({ title: `${ids.length} updated → ${status}`, variant: "success" });
    clearSelection();
    router.refresh();
  }

  async function startBulk(mode: "all" | "unanswered" | "low_confidence" | "selected") {
    const body: any = { mode, indexId: indexId || rfp.defaultIndexId, enableTools };
    if (mode === "selected") body.questionIds = Array.from(selectedIds);
    const res = await fetch(`/api/rfps/${rfp.id}/bulk-generate`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json();
      toast({ title: "Couldn't start bulk", description: err.error });
      return;
    }
    const { bulk } = await res.json();
    setRunningBulkId(bulk.id);
    setBulkOpen(false);
    clearSelection();
    toast({ title: `Bulk started · ${bulk.total} questions`, variant: "success" });
  }

  function exportRfp(approvedOnly: boolean, includeSources: boolean) {
    const url = new URL(`/api/rfps/${rfp.id}/export`, window.location.origin);
    url.searchParams.set("format", "docx");
    if (approvedOnly) url.searchParams.set("approvedOnly", "1");
    if (!includeSources) url.searchParams.set("includeSources", "0");
    window.location.href = url.toString();
    setExportOpen(false);
  }

  const tableRows: QuestionRow[] = questions.map((q) => ({
    id: q.id,
    number: q.number,
    section: q.section,
    text: q.text,
    status: q.status,
    assignee: q.assignee,
    hasResponse: q.latestResponse?.status === "COMPLETED",
    needsReview: q.latestResponse?.needsReview ?? false,
    confidence: q.confidence,
    commentCount: q.commentCount,
    dueDate: q.dueDate,
  }));

  return (
    <div className="space-y-4">
      <PageHeader
        title={rfp.title}
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${rfp.organizationId}` },
          { label: "Projects", href: `/dashboard/projects?org=${rfp.organizationId}` },
          { label: rfp.projectName, href: `/dashboard/projects/${rfp.projectId}?org=${rfp.organizationId}` },
          { label: rfp.title },
        ]}
        className="mb-2"
      />
      <BackLink rfp={rfp} />

      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            {/* RFP title chip alongside the inline status/outcome controls.
                The big page title now lives in PageHeader above; we keep
                a small hidden h1 for screen-reader landmark. */}
            <h2 className="sr-only">{rfp.title}</h2>
            {/* Win/loss outcome chip — click to set/edit */}
            <OutcomeChip
              rfpId={rfp.id}
              initialOutcome={rfp.outcome}
              initialNote={rfp.outcomeNote}
            />
            {/* Predicted win likelihood (Tier C — moonshot). Sits next to
                the outcome chip so the team sees both "what we expect"
                and "what actually happened" in one glance. */}
            <WinPredictionPanel rfpId={rfp.id} isAdmin={isAdmin} />
          </div>
          <p className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <FileText className="h-3 w-3" /> {rfp.fileName}
            </span>
            <span>·</span>
            <span>{stats.total} questions</span>
            <span>·</span>
            <span>{stats.answered} answered</span>
            <span>·</span>
            <span className="text-emerald-600 dark:text-emerald-300">{stats.approved} approved</span>
            {stats.needsReview > 0 ? (
              <>
                <span>·</span>
                <span className="text-amber-600 dark:text-amber-300">{stats.needsReview} need review</span>
              </>
            ) : null}
            <span>·</span>
            <RfpDueDateEditor rfpId={rfp.id} current={rfpDueDate} onChange={setRfpDueDate} />
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Select value={indexId} onValueChange={setIndexId}>
            <SelectTrigger className="w-[200px] h-8 text-xs">
              <SelectValue placeholder="Knowledge index" />
            </SelectTrigger>
            <SelectContent>
              {indexes.map((i) => (
                <SelectItem key={i.id} value={i.id}>
                  {i.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant={enableTools ? "default" : "outline"}
            size="sm"
            onClick={() => setEnableTools((v) => !v)}
            title="Allow the model to call tools"
          >
            Tools {enableTools ? "ON" : "OFF"}
          </Button>
          <Button variant="outline" size="sm" onClick={() => setChatOpen(true)}>
            <MessageSquare className="h-4 w-4" /> Chat
          </Button>
          <Button variant="outline" size="sm" onClick={() => setActivityOpen(true)}>
            <ActivityIcon className="h-4 w-4" /> Activity
          </Button>
          <Button variant="outline" size="sm" onClick={() => setExportOpen(true)}>
            <Download className="h-4 w-4" /> Export
          </Button>
          <Button variant="gradient" size="sm" onClick={() => setBulkOpen(true)} disabled={!!runningBulkId}>
            <Layers className="h-4 w-4" /> Bulk Generate
          </Button>
          <Button
            variant="destructive"
            size="sm"
            disabled={deletingRfp}
            onClick={async () => {
              const msg = `${stats.total} question(s), ${stats.answered} response(s), comments, sources, and attachments will be deleted. This is irreversible.`;
              if (!(await confirm(msg, { title: `Delete RFP "${rfp.title}"?`, destructive: true, confirmLabel: "Delete RFP" }))) return;
              setDeletingRfp(true);
              try {
                const res = await fetch(`/api/rfps/${rfp.id}`, { method: "DELETE" });
                if (!res.ok) {
                  const body = await res.text();
                  toast({ title: "Delete failed", description: body.slice(0, 200), variant: "destructive" });
                  setDeletingRfp(false);
                  return;
                }
                toast({ title: "RFP deleted" });
                router.push(`/dashboard/projects/${rfp.projectId}`);
                router.refresh();
              } catch (e) {
                toast({
                  title: "Delete failed",
                  description: e instanceof Error ? e.message : String(e),
                  variant: "destructive",
                });
                setDeletingRfp(false);
              }
            }}
            title="Delete this RFP and everything under it"
          >
            {deletingRfp ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            Delete RFP
          </Button>
        </div>
      </div>

      <PipelineStepper rfpId={rfp.id} />

      <DocumentsPanel
        rfpId={rfp.id}
        primary={{ fileName: rfp.fileName, fileSize: rfp.fileSize }}
        attachments={attachments}
      />

      {runningBulkId ? (
        <BulkProgress
          bulkId={runningBulkId}
          onDone={() => {
            setRunningBulkId(null);
            router.refresh();
          }}
        />
      ) : null}

      {/* Auto-extracted evaluation rubric. Sits above the questions table so
          the team sees their score against buyer criteria before diving into
          individual answers. */}
      <RubricPanel rfpId={rfp.id} initial={props.rubric ?? null} />

      {selectedIds.size > 0 ? (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-primary/5 p-2">
          <span className="text-xs font-medium">{selectedIds.size} selected</span>
          <span className="ml-2 text-xs text-muted-foreground">Set status:</span>
          {(["TODO", "IN_PROGRESS", "IN_REVIEW", "APPROVED"] as QuestionStatus[]).map((s) => (
            <Button key={s} size="sm" variant="ghost" onClick={() => bulkSetStatus(s)}>
              <StatusBadge status={s} size="sm" />
            </Button>
          ))}
          <span className="ml-auto" />
          <Button size="sm" variant="default" onClick={() => startBulk("selected")} disabled={!!runningBulkId}>
            <Sparkles className="h-3.5 w-3.5" /> Generate {selectedIds.size}
          </Button>
          <Button size="sm" variant="ghost" onClick={clearSelection}>
            Clear
          </Button>
        </div>
      ) : null}

      {/*
        Two-column layout. We DROP the old `h-[calc(100vh-19rem)]` cap on
        both columns — those caused the content to clip at the bottom and
        forced three nested scrollbars (page > main > inner panel). Now:
          - The table column shows the full list, paged naturally by the
            window scrollbar.
          - The detail / discussion column is `lg:sticky` so it stays in
            view as the user scrolls the question table on desktop, with
            `max-h-[calc(100vh-7rem)] overflow-y-auto` so a very long
            discussion can still scroll independently inside the panel.
            On mobile (lg-), it just stacks below the table.
      */}
      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(420px,2fr)] lg:items-start">
        <div className="min-w-0">
          <QuestionTable
            questions={tableRows}
            members={members}
            activeId={activeId}
            selectedIds={selectedIds}
            onSelect={(id) => setActiveId(id)}
            onToggleSelected={toggleSelected}
            onToggleAll={toggleAll}
            onStatusChange={(id, s) => changeStatus(id, s)}
            onAssigneeChange={(id, uid) => changeAssignee(id, uid)}
          />
        </div>

        {active ? (
          <QuestionDetailPanel
            key={active.id}
            currentUserId={currentUserId}
            members={members}
            question={active}
            indexId={indexId || rfp.defaultIndexId || null}
            enableTools={enableTools}
            crossRefs={crossRefByQuestion.get(active.id) ?? []}
            attachmentRoleById={attachmentRoleById}
            onResponseUpdate={(updated) =>
              patchQuestion(active.id, {
                latestResponse: updated,
                confidence: updated.confidence,
              })
            }
            onStatusChange={(s) => changeStatus(active.id, s)}
            onAssigneeChange={(uid) => changeAssignee(active.id, uid)}
            onCommentCountChange={(count) => patchQuestion(active.id, { commentCount: count })}
          />
        ) : (
          <Card>
            <CardContent className="py-20 text-center text-sm text-muted-foreground">
              Select a question.
            </CardContent>
          </Card>
        )}
      </div>

      {/* Chat with this RFP */}
      <Dialog open={chatOpen} onOpenChange={setChatOpen}>
        <DialogContent className="max-w-3xl p-0 sm:rounded-2xl h-[85vh] grid grid-rows-[auto_1fr]">
          <DialogTitle className="sr-only">Chat with this RFP</DialogTitle>
          <div className="overflow-hidden">
            <ChatPanel
              organizationId={rfp.organizationId}
              scope="RFP"
              rfpId={rfp.id}
              indexId={indexId || rfp.defaultIndexId || null}
              scopeLabel={`RFP · ${rfp.title}`}
              suggestions={[
                "Summarize the key requirements in this RFP",
                "What's the deadline / submission format?",
                "Group questions by section",
                "Draft an answer for question 1",
                "Which questions look hardest to answer?",
              ]}
            />
          </div>
        </DialogContent>
      </Dialog>

      {/* Activity */}
      <Dialog open={activityOpen} onOpenChange={setActivityOpen}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Activity</DialogTitle>
            <DialogDescription>Everything that&apos;s happened on this RFP.</DialogDescription>
          </DialogHeader>
          <ActivityFeed rfpId={rfp.id} />
        </DialogContent>
      </Dialog>

      {/* Export */}
      <Dialog open={exportOpen} onOpenChange={setExportOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Export RFP response</DialogTitle>
            <DialogDescription>Generate a Word document with all questions and answers.</DialogDescription>
          </DialogHeader>
          <ExportDialogContent onExport={exportRfp} />
        </DialogContent>
      </Dialog>

      {/* Bulk generate */}
      <Dialog open={bulkOpen} onOpenChange={setBulkOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Bulk generate responses</DialogTitle>
            <DialogDescription>
              Run the AI on many questions at once. 3 parallel workers, with progress shown live.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => startBulk("unanswered")}
            >
              <Sparkles className="h-4 w-4" /> Generate all <strong>unanswered</strong> questions
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => startBulk("low_confidence")}
            >
              <RefreshCw className="h-4 w-4" /> Re-generate <strong>low-confidence</strong> answers (&lt; 55%)
            </Button>
            <Button
              variant="outline"
              className="w-full justify-start"
              onClick={() => startBulk("all")}
            >
              <Layers className="h-4 w-4" /> Generate <strong>all</strong> questions (overwrites)
            </Button>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setBulkOpen(false)}>
              Cancel
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ExportDialogContent({
  onExport,
}: {
  onExport: (approvedOnly: boolean, includeSources: boolean) => void;
}) {
  const [approvedOnly, setApprovedOnly] = useState(false);
  const [includeSources, setIncludeSources] = useState(true);
  return (
    <div className="space-y-4">
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={approvedOnly}
          onChange={(e) => setApprovedOnly(e.target.checked)}
          className="h-4 w-4"
        />
        Only include <strong>approved</strong> questions
      </label>
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={includeSources}
          onChange={(e) => setIncludeSources(e.target.checked)}
          className="h-4 w-4"
        />
        Include source citations under each answer
      </label>
      <DialogFooter>
        <Button variant="gradient" onClick={() => onExport(approvedOnly, includeSources)}>
          <Download className="h-4 w-4" /> Download .docx
        </Button>
      </DialogFooter>
    </div>
  );
}

function BackLink({ rfp }: { rfp: RfpInfo }) {
  return (
    <Link
      href={`/dashboard/projects/${rfp.projectId}?org=${rfp.organizationId}`}
      className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
    >
      <ArrowLeft className="h-3.5 w-3.5" /> {rfp.projectName}
    </Link>
  );
}

async function reprocess(rfpId: string, router: ReturnType<typeof useRouter>) {
  const res = await fetch(`/api/rfps/${rfpId}/reprocess`, { method: "POST" });
  if (res.ok) router.refresh();
}

function QuestionDetailPanel({
  currentUserId,
  members,
  question,
  indexId,
  enableTools,
  crossRefs,
  attachmentRoleById,
  onResponseUpdate,
  onStatusChange,
  onAssigneeChange,
  onCommentCountChange,
}: {
  currentUserId: string;
  members: Member[];
  question: QuestionView;
  indexId: string | null;
  enableTools: boolean;
  crossRefs: CrossRefView[];
  attachmentRoleById: Map<string, string>;
  onResponseUpdate: (response: ResponseInfo) => void;
  onStatusChange: (s: QuestionStatus) => void;
  onAssigneeChange: (userId: string | null) => void;
  onCommentCountChange: (count: number) => void;
}) {
  const [generating, setGenerating] = useState(false);
  const [steps, setSteps] = useState<ReasoningStep[]>([]);
  const [streamedContent, setStreamedContent] = useState<string | null>(null);
  const [showSources, setShowSources] = useState(false);
  const [showSteps, setShowSteps] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  // NB: editing state used to live here (textarea + Save button). That flow
  // is now owned by <ResponseEditor>, which adds the soft lock + heartbeat
  // + debounced auto-save layer. The legacy /responses/:id PATCH route is
  // still exposed but no longer reached from this UI.

  async function generate() {
    abortRef.current?.abort();
    const ac = new AbortController();
    abortRef.current = ac;
    setGenerating(true);
    setSteps([]);
    setStreamedContent("");
    setShowSteps(true);

    try {
      const res = await fetch(`/api/questions/${question.id}/generate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ indexId, enableTools }),
        signal: ac.signal,
      });
      if (!res.ok || !res.body) {
        toast({ title: "Generation failed", description: await res.text() });
        return;
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() ?? "";
        for (const evt of events) {
          if (!evt.trim()) continue;
          const lines = evt.split("\n");
          const event = lines.find((l) => l.startsWith("event: "))?.slice(7).trim();
          const data = lines.find((l) => l.startsWith("data: "))?.slice(6);
          if (!data) continue;
          const parsed = JSON.parse(data);

          if (event === "step") {
            setSteps((prev) => [...prev, parsed as ReasoningStep]);
          } else if (event === "done") {
            setStreamedContent(parsed.content);
            onResponseUpdate({
              id: parsed.responseId,
              content: parsed.content,
              status: "COMPLETED",
              indexId,
              confidence: parsed.confidence,
              needsReview: parsed.needsReview,
              groundingScore: parsed.grounding ? parsed.grounding.score : null,
              groundingNotes: parsed.grounding ? parsed.grounding.claims : null,
              groundingAt: parsed.grounding ? new Date().toISOString() : null,
              sources: parsed.sources.map((s: any) => ({
                id: s.id,
                fileName: s.fileName,
                page: s.page,
                excerpt: s.content,
                score: s.score,
                // Phase IM: the SSE generate stream doesn't carry image
                // metadata yet (IM2's retrieval extension is the upstream
                // owner). Default to text-kind so the existing renderer
                // path stays correct; image citations land on next
                // page-refresh once persisted.
                kind: (s.kind === "image" ? "image" : "text") as "text" | "image",
                image: s.image ?? null,
              })),
              myFeedback: null,
              staleSourceWarnings: Array.isArray(parsed.staleSourceWarnings)
                ? parsed.staleSourceWarnings
                : [],
            });
            toast({ title: "Response ready", variant: "success" });
          } else if (event === "error") {
            toast({ title: "Generation error", description: parsed.message });
          }
        }
      }
    } catch (e) {
      if ((e as Error).name !== "AbortError") {
        toast({ title: "Generation failed", description: (e as Error).message });
      }
    } finally {
      setGenerating(false);
    }
  }

  async function vote(kind: "UP" | "DOWN") {
    if (!question.latestResponse) return;
    const res = await fetch(`/api/responses/${question.latestResponse.id}/feedback`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ kind }),
    });
    if (res.ok) {
      onResponseUpdate({ ...question.latestResponse, myFeedback: kind });
      toast({ title: kind === "UP" ? "Thanks for the feedback" : "Noted — we'll learn from this" });
    }
  }

  const displayedContent = streamedContent ?? question.latestResponse?.content ?? "";
  const r = question.latestResponse;

  return (
    // Sticks below the dashboard header on lg+ so it stays in view while the
    // user scrolls the question list. `max-h-[calc(100vh-7rem)] overflow-y-auto`
    // gives it its OWN scrollbar only when the discussion is taller than the
    // viewport — short discussions just sit naturally with the page.
    <div className="scrollbar-thin space-y-4 pr-1 lg:sticky lg:top-20 lg:max-h-[calc(100vh-7rem)] lg:overflow-y-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between gap-3">
            <CardDescription>
              Question {question.number}
              {question.section ? ` · ${question.section}` : ""}
            </CardDescription>
            <div className="flex items-center gap-2">
              <StatusPicker status={question.status} onChange={onStatusChange} size="sm" />
              <AssigneePicker
                members={members}
                current={question.assignee}
                onChange={onAssigneeChange}
                size="sm"
              />
            </div>
          </div>
          <CardTitle className="text-base font-medium leading-relaxed mt-2">{question.text}</CardTitle>
          {crossRefs.length > 0 ? (
            <div className="mt-3 flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] font-medium text-muted-foreground">Also in:</span>
              {(() => {
                // De-dupe by docRole — multiple snippet hits in one questionnaire
                // shouldn't render five identical badges. Title carries the
                // first matched snippet for hover context.
                const seen = new Set<string>();
                return crossRefs
                  .map((c) => {
                    const role = attachmentRoleById.get(c.attachmentRfpId) ?? "ATTACHMENT";
                    const key = `${role}:${c.attachmentRfpId}`;
                    if (seen.has(key)) return null;
                    seen.add(key);
                    return (
                      <Badge
                        key={key}
                        variant="info"
                        className="text-[10px]"
                        title={`${c.reason} — "${c.attachmentSnippet}"`}
                      >
                        {role}
                        {c.attachmentQuestionNumber != null ? ` Q${c.attachmentQuestionNumber}` : ""}
                      </Badge>
                    );
                  })
                  .filter(Boolean);
              })()}
            </div>
          ) : null}
        </CardHeader>
      </Card>

      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <CardTitle className="text-base">Response</CardTitle>
            {r?.status === "COMPLETED" ? (
              <>
                {typeof r.confidence === "number" ? (
                  <Badge
                    variant={r.confidence >= 0.7 ? "success" : r.confidence >= 0.5 ? "info" : "warning"}
                    className="text-xs"
                  >
                    {Math.round(r.confidence * 100)}% confidence
                  </Badge>
                ) : null}
                <GroundingBadge
                  responseId={r.id}
                  score={r.groundingScore}
                  notes={r.groundingNotes}
                  onUpdate={(score, notes) =>
                    onResponseUpdate({
                      ...r,
                      groundingScore: score,
                      groundingNotes: notes,
                      groundingAt: new Date().toISOString(),
                    })
                  }
                />
                {r.needsReview ? (
                  <Badge variant="warning" className="text-xs">Needs review</Badge>
                ) : null}
              </>
            ) : null}
          </div>
          <div className="flex items-center gap-2">
            {r ? (
              <>
                <Button size="sm" variant="ghost" onClick={() => vote("UP")}>
                  <ThumbsUp
                    className={cn(
                      "h-4 w-4",
                      r.myFeedback === "UP" && "text-emerald-500 fill-emerald-500",
                    )}
                  />
                </Button>
                <Button size="sm" variant="ghost" onClick={() => vote("DOWN")}>
                  <ThumbsDown
                    className={cn(
                      "h-4 w-4",
                      r.myFeedback === "DOWN" && "text-destructive fill-destructive",
                    )}
                  />
                </Button>
                {/* Edit affordance is now provided by ResponseEditor's
                    internal "Start editing" button (soft lock + heartbeat).
                    Keeping the markup minimal here so vote buttons line up. */}
              </>
            ) : null}
            <Button size="sm" variant="gradient" onClick={generate} disabled={generating}>
              {generating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {r ? "Regenerate" : "Generate"}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {steps.length > 0 ? (
            <ReasoningSteps steps={steps} expanded={showSteps} onToggle={() => setShowSteps((v) => !v)} />
          ) : null}

          {r?.staleSourceWarnings && r.staleSourceWarnings.length > 0 ? (
            <div
              className="flex flex-col gap-2 rounded-lg border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900 dark:border-amber-700 dark:bg-amber-950/40 dark:text-amber-100"
              data-testid="stale-source-warning"
            >
              <div className="flex items-center gap-2 font-medium">
                <AlertTriangle className="h-4 w-4" />
                <span>
                  This answer cites {r.staleSourceWarnings.length} source
                  {r.staleSourceWarnings.length === 1 ? "" : "s"} older than the staleness threshold.
                </span>
              </div>
              <ul className="ml-6 list-disc text-xs">
                {r.staleSourceWarnings.map((w) => (
                  <li key={w.documentId}>
                    <span className="font-medium">{w.fileName}</span>
                    {w.sourceDate ? ` (as of ${w.sourceDate.slice(0, 10)})` : ""} — {w.reason}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {/* Live generation stream (no lock involved — bypass the editor). */}
          {streamedContent != null && generating ? (
            <div className="rounded-lg bg-muted/40 p-4">
              <Markdown>{streamedContent}</Markdown>
            </div>
          ) : r && r.id ? (
            // Real, persisted response — render the collab-aware editor.
            // It handles its own read/edit modes, soft lock, heartbeat,
            // debounced save, and Publish commit. NOT a CRDT — see the
            // header in response-editor.tsx for the trade-off.
            <ResponseEditor
              responseId={r.id}
              currentUserId={currentUserId}
              initialContent={displayedContent}
              onCommitted={(content) => onResponseUpdate({ ...r, content })}
            />
          ) : displayedContent ? (
            <div className="rounded-lg bg-muted/40 p-4">
              <Markdown>{displayedContent}</Markdown>
            </div>
          ) : (
            <div className="grid place-items-center rounded-lg border-2 border-dashed py-12 text-center">
              <Sparkles className="h-8 w-8 text-muted-foreground" />
              <div className="mt-2 text-sm font-medium">No response yet</div>
              <p className="mt-1 text-xs text-muted-foreground">
                Click <strong>Generate</strong> to draft an answer from your knowledge base.
              </p>
            </div>
          )}

          {r?.sources.length ? (
            <div>
              <button
                onClick={() => setShowSources((v) => !v)}
                className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                <ChevronRight
                  className={cn("h-4 w-4 transition-transform", showSources && "rotate-90")}
                />
                {r.sources.length} source{r.sources.length === 1 ? "" : "s"}
              </button>
              {showSources ? (
                <div className="mt-3 space-y-2">
                  {r.sources.map((s, i) =>
                    s.kind === "image" && s.image ? (
                      <ImageSourceCitation key={s.id} index={i} source={s} />
                    ) : (
                      <div key={s.id} className="rounded-lg border bg-card p-3">
                        <div className="flex items-center justify-between text-xs font-medium">
                          <span className="truncate">
                            [Source {i + 1}] {s.fileName ?? "—"}
                            {s.page ? ` · p.${s.page}` : ""}
                          </span>
                          <Badge variant="outline" className="text-[10px]">
                            {Math.round(s.score * 100)}%
                          </Badge>
                        </div>
                        <p className="mt-1 line-clamp-4 text-xs text-muted-foreground">{s.excerpt}</p>
                      </div>
                    ),
                  )}
                </div>
              ) : null}
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="pt-6">
          <CommentsThread
            questionId={question.id}
            currentUserId={currentUserId}
            onCountChange={onCommentCountChange}
          />
        </CardContent>
      </Card>
    </div>
  );
}

/**
 * Grounding badge + collapsible per-claim breakdown.
 *
 * Color tiers (chosen to match the GROUNDING_REVIEW_THRESHOLD on the server):
 *   - score ≥ 0.9   → green   (almost everything backed by sources)
 *   - 0.6 ≤ score < 0.9 → yellow  (some weak / inferred claims)
 *   - score < 0.6   → red     (auto-flagged for human review)
 *   - score == null → neutral outline (not yet judged)
 *
 * Re-score POSTs to the regrounding endpoint and updates locally on success.
 */
function GroundingBadge({
  responseId,
  score,
  notes,
  onUpdate,
}: {
  responseId: string;
  score: number | null;
  notes: GroundingClaim[] | unknown | null;
  onUpdate: (score: number | null, notes: unknown) => void;
}) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  // The Json column may arrive as anything; coerce defensively.
  const claims: GroundingClaim[] = Array.isArray(notes)
    ? (notes as GroundingClaim[])
    : [];

  async function rescore() {
    setBusy(true);
    try {
      const res = await fetch(`/api/responses/${responseId}/grounding`, { method: "POST" });
      if (!res.ok) {
        toast({ title: "Re-score failed", description: await res.text() });
        return;
      }
      const body = await res.json();
      onUpdate(body.groundingScore ?? null, body.groundingNotes ?? null);
      toast({ title: "Re-scored", variant: "success" });
    } catch (e) {
      toast({ title: "Re-score failed", description: (e as Error).message });
    } finally {
      setBusy(false);
    }
  }

  if (score == null) {
    return (
      <div className="flex items-center gap-1">
        <Badge variant="outline" className="text-xs">Not graded</Badge>
        <button
          type="button"
          onClick={rescore}
          disabled={busy}
          className="text-[10px] underline text-muted-foreground hover:text-foreground disabled:opacity-50"
          title="Run the grounding judge"
        >
          {busy ? "Scoring…" : "Score"}
        </button>
      </div>
    );
  }

  const variant: "success" | "warning" | "destructive" =
    score >= 0.9 ? "success" : score >= 0.6 ? "warning" : "destructive";
  const unsupported = claims.filter((c) => c.support === "unsupported");
  const weak = claims.filter((c) => c.support === "weak");
  const tooltip =
    `${claims.length} claim${claims.length === 1 ? "" : "s"} · ` +
    `${claims.length - unsupported.length - weak.length} supported, ${weak.length} weak, ${unsupported.length} unsupported`;

  return (
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          title={tooltip}
          className="inline-flex items-center"
        >
          <Badge variant={variant} className="text-xs cursor-pointer">
            {Math.round(score * 100)}% grounded
          </Badge>
        </button>
        <button
          type="button"
          onClick={rescore}
          disabled={busy}
          className="text-[10px] underline text-muted-foreground hover:text-foreground disabled:opacity-50"
          title="Re-run the grounding judge against the current answer"
        >
          {busy ? "Re-scoring…" : "Re-score"}
        </button>
      </div>
      {open && claims.length > 0 ? (
        <div className="mt-1 max-w-md rounded-lg border bg-card p-2 text-[11px] space-y-1.5">
          {/* Highlight unsupported first (most important to fix), then weak,
              then supported as a quiet tail. */}
          {[...unsupported, ...weak, ...claims.filter((c) => c.support === "supported")].map((c, i) => (
            <div key={i} className="flex items-start gap-2">
              <span
                className={cn(
                  "mt-0.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full",
                  c.support === "supported" && "bg-emerald-500",
                  c.support === "weak" && "bg-amber-500",
                  c.support === "unsupported" && "bg-rose-500",
                )}
                aria-hidden
              />
              <div className="min-w-0">
                <div className="font-medium">{truncate(c.claim, 140)}</div>
                {c.note ? (
                  <div className="text-muted-foreground">{truncate(c.note, 200)}</div>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function ReasoningSteps({
  steps,
  expanded,
  onToggle,
}: {
  steps: ReasoningStep[];
  expanded: boolean;
  onToggle: () => void;
}) {
  const ICONS: Record<string, string> = {
    analyzing: "🧠",
    searching: "🔍",
    tool_call: "🛠️",
    drafting: "✍️",
    complete: "✅",
    error: "⚠️",
  };
  return (
    <div className="rounded-lg border bg-muted/30">
      <button
        onClick={onToggle}
        className="flex w-full items-center justify-between px-3 py-2 text-xs font-medium text-muted-foreground hover:text-foreground"
      >
        <span>Reasoning ({steps.length} steps)</span>
        <ChevronRight className={cn("h-3.5 w-3.5 transition-transform", expanded && "rotate-90")} />
      </button>
      {expanded ? (
        <ol className="space-y-1 border-t px-3 py-2 text-xs">
          {steps.map((s, i) => (
            <li key={i} className="flex items-start gap-2">
              <span>{ICONS[s.step] ?? "•"}</span>
              <div>
                <span className="font-medium uppercase tracking-wider text-muted-foreground">
                  {s.step}
                </span>{" "}
                <span>{truncate(s.detail, 200)}</span>
              </div>
            </li>
          ))}
        </ol>
      ) : null}
    </div>
  );
}
