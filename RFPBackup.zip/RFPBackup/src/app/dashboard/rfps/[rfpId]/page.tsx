import { notFound, redirect } from "next/navigation";
import { auth } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { findCrossReferences } from "@/lib/ai/cross-reference";
import { RfpViewer } from "./viewer";

/**
 * Pull stale-source warnings out of the persisted reasoning JSON. The
 * generator emits `stale_source` SSE steps and persists the full step list
 * on `Response.reasoning`; the warning payload lives on `.data`. Returns
 * an empty list when reasoning is null/non-array or no stale steps fired —
 * downstream UI just renders nothing.
 */
function extractStaleSourceWarnings(reasoning: unknown): Array<{
  documentId: string;
  fileName: string;
  reason: string;
  sourceDate: string | null;
}> {
  if (!Array.isArray(reasoning)) return [];
  const out: Array<{ documentId: string; fileName: string; reason: string; sourceDate: string | null }> = [];
  for (const step of reasoning) {
    if (!step || typeof step !== "object") continue;
    if ((step as { step?: unknown }).step !== "stale_source") continue;
    const data = (step as { data?: unknown }).data;
    if (!data || typeof data !== "object") continue;
    const d = data as { documentId?: unknown; fileName?: unknown; reason?: unknown; sourceDate?: unknown };
    if (typeof d.documentId !== "string" || typeof d.fileName !== "string" || typeof d.reason !== "string") {
      continue;
    }
    out.push({
      documentId: d.documentId,
      fileName: d.fileName,
      reason: d.reason,
      sourceDate: typeof d.sourceDate === "string" ? d.sourceDate : null,
    });
  }
  return out;
}

export default async function RfpPage({ params }: { params: Promise<{ rfpId: string }> }) {
  const { rfpId } = await params;
  const session = await auth();
  if (!session?.user?.id) redirect("/auth/signin");

  const rfp = await prisma.rFP.findUnique({
    where: { id: rfpId },
    include: {
      project: {
        include: {
          organization: { select: { id: true, name: true } },
          defaultIndex: { select: { id: true, name: true } },
        },
      },
      questions: {
        orderBy: { number: "asc" },
        include: {
          assignee: { select: { id: true, name: true, email: true } },
          _count: { select: { comments: true } },
          responses: {
            orderBy: { createdAt: "desc" },
            take: 1,
            include: {
              // Pull the chunk's `kind` so the viewer can switch between
              // text and image citation rendering. Image citations also
              // need the parent chunk's ImageEmbedding so the inline
              // thumbnail has a path + caption + OCR text.
              sources: {
                include: {
                  chunk: {
                    select: {
                      id: true,
                      kind: true,
                      imageEmbeddings: {
                        select: {
                          id: true,
                          imagePath: true,
                          caption: true,
                          ocrText: true,
                          page: true,
                          width: true,
                          height: true,
                          documentId: true,
                          indexId: true,
                        },
                        take: 1,
                      },
                    },
                  },
                },
              },
              index: { select: { id: true, name: true } },
              feedback: { where: { userId: session.user.id } },
            },
          },
        },
      },
    },
  });
  if (!rfp) notFound();

  const member = await prisma.membership.findUnique({
    where: {
      userId_organizationId: {
        userId: session.user.id,
        organizationId: rfp.project.organizationId,
      },
    },
  });
  if (!member) notFound();

  const [indexes, members, runningBulk, attachments, crossRefs, rubric] = await Promise.all([
    prisma.knowledgeIndex.findMany({
      where: { organizationId: rfp.project.organizationId },
      select: { id: true, name: true },
      orderBy: { createdAt: "asc" },
    }),
    prisma.membership.findMany({
      where: { organizationId: rfp.project.organizationId },
      include: { user: { select: { id: true, name: true, email: true } } },
      orderBy: { createdAt: "asc" },
    }),
    prisma.bulkGeneration.findFirst({
      where: { rfpId, status: { in: ["PENDING", "RUNNING"] } },
      orderBy: { startedAt: "desc" },
    }),
    prisma.rFP.findMany({
      where: { parentRfpId: rfpId },
      orderBy: { createdAt: "asc" },
      select: {
        id: true,
        fileName: true,
        fileSize: true,
        mimeType: true,
        docRole: true,
        createdAt: true,
      },
    }),
    findCrossReferences({ rfpId, organizationId: rfp.project.organizationId }).catch(() => []),
    prisma.evaluationRubric.findUnique({ where: { rfpId } }),
  ]);

  // Surface admin status to the viewer so admin-only controls (re-score,
  // override) on the WinPredictionPanel render conditionally without an
  // extra fetch round-trip.
  const isAdmin = member.role === "ADMIN" || member.role === "OWNER";

  return (
    <RfpViewer
      currentUserId={session.user.id}
      isAdmin={isAdmin}
      rfp={{
        id: rfp.id,
        title: rfp.title,
        status: rfp.status,
        errorMessage: rfp.errorMessage,
        fileName: rfp.fileName,
        fileSize: rfp.fileSize,
        projectId: rfp.projectId,
        projectName: rfp.project.name,
        organizationId: rfp.project.organizationId,
        defaultIndexId: rfp.project.defaultIndexId,
        dueDate: rfp.dueDate ? rfp.dueDate.toISOString() : null,
        outcome: rfp.outcome,
        outcomeNote: rfp.outcomeNote,
      }}
      indexes={indexes}
      members={members.map((m) => ({
        userId: m.user.id,
        email: m.user.email,
        name: m.user.name,
      }))}
      runningBulkId={runningBulk?.id ?? null}
      attachments={attachments.map((a) => ({
        id: a.id,
        fileName: a.fileName,
        fileSize: a.fileSize,
        mimeType: a.mimeType,
        docRole: a.docRole,
        createdAt: a.createdAt.toISOString(),
      }))}
      rubric={
        rubric
          ? {
              criteria: Array.isArray(rubric.criteria)
                ? (rubric.criteria as unknown as Array<{
                    id: string;
                    label: string;
                    weight: number;
                    description: string;
                    mustHave?: boolean;
                  }>)
                : [],
              totalScore: rubric.totalScore ?? null,
              perCriterionScores:
                rubric.perCriterionScores && typeof rubric.perCriterionScores === "object"
                  ? (rubric.perCriterionScores as unknown as Record<
                      string,
                      { criterionId: string; score: number; rationale: string; evidence: string[] }
                    >)
                  : null,
              extractionConfidence: rubric.extractionConfidence ?? null,
              scoredAt: rubric.scoredAt ? rubric.scoredAt.toISOString() : null,
            }
          : null
      }
      crossRefs={crossRefs.map((r) => ({
        primaryQuestionId: r.primaryQuestionId,
        attachmentRfpId: r.attachmentRfpId,
        attachmentQuestionNumber: r.attachmentQuestionNumber,
        attachmentSnippet: r.attachmentSnippet,
        reason: r.reason,
      }))}
      questions={rfp.questions.map((q) => ({
        dueDate: q.dueDate ? q.dueDate.toISOString() : null,
        id: q.id,
        number: q.number,
        section: q.section,
        text: q.text,
        status: q.status,
        confidence: q.confidence,
        commentCount: q._count.comments,
        assignee: q.assignee
          ? { id: q.assignee.id, name: q.assignee.name, email: q.assignee.email }
          : null,
        latestResponse: q.responses[0]
          ? {
              id: q.responses[0].id,
              content: q.responses[0].content,
              status: q.responses[0].status,
              indexId: q.responses[0].indexId,
              confidence: q.responses[0].confidence,
              needsReview: q.responses[0].needsReview,
              groundingScore: q.responses[0].groundingScore,
              groundingNotes: q.responses[0].groundingNotes,
              groundingAt: q.responses[0].groundingAt
                ? q.responses[0].groundingAt.toISOString()
                : null,
              sources: q.responses[0].sources.map((s) => {
                // Phase IM: figure-kind chunks carry a linked ImageEmbedding
                // row. Surface a normalised `kind` ("image" | "text") +
                // optional image metadata so the viewer can render thumbnail
                // citations inline. We fall through to "text" whenever the
                // chunk is missing or its kind isn't "figure" so existing
                // responses keep rendering exactly as before.
                const chunkKind = s.chunk?.kind ?? null;
                const img = s.chunk?.imageEmbeddings?.[0] ?? null;
                const isImage = chunkKind === "figure" && !!img;
                return {
                  id: s.id,
                  fileName: s.fileName,
                  page: s.page,
                  excerpt: s.excerpt,
                  score: s.score,
                  kind: isImage ? ("image" as const) : ("text" as const),
                  image: isImage && img
                    ? {
                        id: img.id,
                        imagePath: img.imagePath,
                        caption: img.caption,
                        ocrText: img.ocrText,
                        page: img.page,
                        width: img.width,
                        height: img.height,
                        documentId: img.documentId,
                        indexId: img.indexId,
                      }
                    : null,
                };
              }),
              myFeedback: q.responses[0].feedback[0]?.kind ?? null,
              // Stale-source warnings are persisted as `stale_source` steps in
              // the reasoning JSON. Re-hydrate them here so the viewer's
              // banner survives a page reload, not just the live SSE stream.
              staleSourceWarnings: extractStaleSourceWarnings(q.responses[0].reasoning),
            }
          : null,
      }))}
    />
  );
}
