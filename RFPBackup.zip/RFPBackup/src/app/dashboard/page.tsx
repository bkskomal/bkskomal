import Link from "next/link";
import { ArrowRight, FileText, Library, FolderKanban, Users } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SampleCard } from "@/components/dashboard/sample-card";
import { PageHeader } from "@/components/dashboard/page-header";
import { StatCard } from "@/components/dashboard/stat-card";
import { formatDateTime, truncate } from "@/lib/utils";

export default async function DashboardOverview({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization } = await getActiveOrg(sp.org);
  const orgId = organization.id;

  const [projectCount, indexCount, memberCount, rfpCount, recentRfps, recentResponses] = await Promise.all([
    prisma.project.count({ where: { organizationId: orgId } }),
    prisma.knowledgeIndex.count({ where: { organizationId: orgId } }),
    prisma.membership.count({ where: { organizationId: orgId } }),
    prisma.rFP.count({ where: { project: { organizationId: orgId } } }),
    prisma.rFP.findMany({
      where: { project: { organizationId: orgId } },
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { project: true, _count: { select: { questions: true } } },
    }),
    prisma.response.findMany({
      where: { question: { rfp: { project: { organizationId: orgId } } } },
      take: 5,
      orderBy: { createdAt: "desc" },
      include: { question: { include: { rfp: true } } },
    }),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader
        title="Dashboard"
        subtitle={organization.name}
        breadcrumb={[{ label: "Home", href: `/dashboard?org=${orgId}` }, { label: "Overview" }]}
        actions={
          <Button asChild variant="gradient">
            <Link href={`/dashboard/projects?org=${orgId}&new=1`}>New Project</Link>
          </Button>
        }
      />

      {/* AdminLTE-style "small-box" stat cards — solid bright bg, big number,
          decorative icon, "More info →" footer that links into the section. */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          variant="info"
          value={projectCount}
          label="Projects"
          icon={FolderKanban}
          href={`/dashboard/projects?org=${orgId}`}
        />
        <StatCard
          variant="success"
          value={rfpCount}
          label="RFPs in flight"
          icon={FileText}
          href={`/dashboard/projects?org=${orgId}`}
        />
        <StatCard
          variant="warning"
          value={indexCount}
          label="Knowledge bases"
          icon={Library}
          href={`/dashboard/indexes?org=${orgId}`}
        />
        <StatCard
          variant="danger"
          value={memberCount}
          label="Members"
          icon={Users}
          href={`/dashboard/members?org=${orgId}`}
        />
      </div>

      {recentRfps.length === 0 ? <SampleCard orgId={orgId} /> : null}

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex-row items-center justify-between">
            <div>
              <CardTitle>Recent RFPs</CardTitle>
              <CardDescription>Latest uploaded proposals across projects.</CardDescription>
            </div>
            <Button asChild variant="ghost" size="sm">
              <Link href={`/dashboard/projects?org=${orgId}`}>
                View all <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentRfps.length === 0 ? (
              <EmptyHint label="No RFPs yet" hint="Create a project, then upload an RFP." />
            ) : (
              recentRfps.map((r) => (
                <Link
                  key={r.id}
                  href={`/dashboard/rfps/${r.id}?org=${orgId}`}
                  className="group flex items-center justify-between rounded-lg border bg-card p-3 transition-colors hover:bg-accent"
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <FileText className="h-4 w-4 shrink-0 text-muted-foreground" />
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">{r.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {r.project.name} · {r._count.questions} questions
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline">{r.status}</Badge>
                </Link>
              ))
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent responses</CardTitle>
            <CardDescription>Latest AI-generated answers.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-2">
            {recentResponses.length === 0 ? (
              <EmptyHint label="No responses yet" hint="Generate one from any RFP question." />
            ) : (
              recentResponses.map((r) => (
                <Link
                  key={r.id}
                  href={`/dashboard/rfps/${r.question.rfpId}?org=${orgId}`}
                  className="block rounded-lg border bg-card p-3 transition-colors hover:bg-accent"
                >
                  <div className="text-xs font-medium text-muted-foreground">
                    {formatDateTime(r.createdAt)} · {r.status}
                  </div>
                  <div className="mt-1 text-sm">{truncate(r.question.text, 100)}</div>
                </Link>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function EmptyHint({ label, hint }: { label: string; hint: string }) {
  return (
    <div className="grid place-items-center rounded-lg border-2 border-dashed py-12 text-center">
      <div className="text-sm font-medium">{label}</div>
      <div className="mt-1 text-xs text-muted-foreground">{hint}</div>
    </div>
  );
}
