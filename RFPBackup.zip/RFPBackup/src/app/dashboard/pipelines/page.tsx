import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { PipelinesClient } from "./client";

export default async function PipelinesPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string }>;
}) {
  const sp = await searchParams;
  const { organization, membership } = await getActiveOrg(sp.org);

  const [templates, runs] = await Promise.all([
    prisma.pipelineTemplate.findMany({
      where: { organizationId: organization.id },
      orderBy: [{ isDefault: "desc" }, { updatedAt: "desc" }],
      include: { _count: { select: { runs: true, defaultForProjects: true } } },
    }),
    prisma.pipelineRun.findMany({
      where: { template: { organizationId: organization.id } },
      orderBy: { updatedAt: "desc" },
      take: 30,
      include: {
        steps: { orderBy: { index: "asc" }, select: { status: true } },
        rfp: {
          select: {
            id: true,
            title: true,
            dueDate: true,
            project: { select: { id: true, name: true } },
          },
        },
        template: { select: { name: true } },
      },
    }),
  ]);

  return (
    <PipelinesClient
      orgId={organization.id}
      role={membership.role}
      templates={templates.map((t) => ({
        id: t.id,
        name: t.name,
        description: t.description,
        isDefault: t.isDefault,
        runCount: t._count.runs,
        defaultForProjects: t._count.defaultForProjects,
        stepCount: Array.isArray(t.steps) ? (t.steps as unknown[]).length : 0,
        updatedAt: t.updatedAt.toISOString(),
      }))}
      runs={runs.map((r) => ({
        id: r.id,
        rfpId: r.rfp.id,
        rfpTitle: r.rfp.title,
        projectName: r.rfp.project.name,
        templateName: r.template.name,
        status: r.status,
        currentStepIndex: r.currentStepIndex,
        steps: r.steps.map((s) => s.status),
        dueDate: r.rfp.dueDate?.toISOString() ?? null,
        updatedAt: r.updatedAt.toISOString(),
      }))}
    />
  );
}
