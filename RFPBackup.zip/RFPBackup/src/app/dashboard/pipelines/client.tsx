"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  GitBranch,
  Plus,
  Star,
  Edit3,
  Trash2,
  ChevronRight,
  CircleDashed,
  CircleDot,
  Loader2,
  CheckCircle2,
  XCircle,
  Clock,
  SkipForward,
} from "lucide-react";
import { PipelineStepStatus, Role } from "@prisma/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { cn, formatDateTime } from "@/lib/utils";
import { PageHeader } from "@/components/dashboard/page-header";
import { useConfirm } from "@/components/ui/confirm";
import { DueDatePill } from "@/components/rfp/due-date";
import { TemplateEditorDialog } from "@/components/pipelines/template-editor-dialog";

interface TemplateRow {
  id: string;
  name: string;
  description: string | null;
  isDefault: boolean;
  runCount: number;
  defaultForProjects: number;
  stepCount: number;
  updatedAt: string;
}

interface RunRow {
  id: string;
  rfpId: string;
  rfpTitle: string;
  projectName: string;
  templateName: string;
  status: string;
  currentStepIndex: number;
  steps: PipelineStepStatus[];
  dueDate: string | null;
  updatedAt: string;
}

interface Props {
  orgId: string;
  role: Role;
  templates: TemplateRow[];
  runs: RunRow[];
}

const STATUS_DOT: Record<PipelineStepStatus, string> = {
  PENDING: "bg-muted-foreground/30",
  RUNNING: "bg-sky-500",
  WAITING_FOR_INPUT: "bg-amber-500",
  SUCCEEDED: "bg-emerald-500",
  FAILED: "bg-destructive",
  SKIPPED: "bg-muted-foreground/40",
  CANCELLED: "bg-muted-foreground/40",
};

const RUN_STATUS_BADGE: Record<string, "default" | "info" | "success" | "warning" | "destructive"> = {
  PENDING: "info",
  RUNNING: "info",
  WAITING_FOR_INPUT: "warning",
  SUCCEEDED: "success",
  FAILED: "destructive",
  CANCELLED: "outline" as never,
};

export function PipelinesClient({ orgId, role, templates: initialTpls, runs }: Props) {
  const router = useRouter();
  const confirm = useConfirm();
  const [templates, setTemplates] = useState(initialTpls);
  const [editing, setEditing] = useState<{ id: string | null } | null>(null);
  const canEdit = role === "OWNER" || role === "ADMIN";

  async function setDefault(templateId: string) {
    const r = await fetch(`/api/pipeline-templates/${templateId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ isDefault: true }),
    });
    if (r.ok) {
      setTemplates((prev) =>
        prev.map((t) => ({ ...t, isDefault: t.id === templateId })),
      );
      toast({ title: "Default template updated", variant: "success" });
      router.refresh();
    } else {
      toast({ title: "Couldn't set default", description: (await r.json()).error });
    }
  }

  async function removeTemplate(t: TemplateRow) {
    if (!(await confirm("This can't be undone.", { title: `Delete template "${t.name}"?`, destructive: true, confirmLabel: "Delete" }))) return;
    const r = await fetch(`/api/pipeline-templates/${t.id}`, { method: "DELETE" });
    if (r.ok) {
      setTemplates((prev) => prev.filter((x) => x.id !== t.id));
      toast({ title: "Template deleted" });
      router.refresh();
    } else {
      toast({ title: "Couldn't delete", description: (await r.json()).error });
    }
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Workflows"
        subtitle="Configure the steps every RFP runs through. Each step can be auto, manual, or ask for a decision."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${orgId}` },
          { label: "Workflows" },
        ]}
        actions={
          canEdit ? (
            <Button variant="gradient" onClick={() => setEditing({ id: null })}>
              <Plus className="h-4 w-4" /> New Template
            </Button>
          ) : null
        }
      />

      {/* Templates */}
      <div>
        <h2 className="mb-3 text-lg font-semibold">Templates</h2>
        {templates.length === 0 ? (
          <Card>
            <CardContent className="grid place-items-center py-12 text-center">
              <GitBranch className="h-8 w-8 text-muted-foreground" />
              <div className="mt-3 text-sm font-medium">No templates yet</div>
              <p className="mt-1 max-w-sm text-xs text-muted-foreground">
                A default 9-step template is created automatically the first time an RFP is uploaded.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-3 md:grid-cols-2">
            {templates.map((t) => (
              <Card key={t.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <CardTitle className="flex items-center gap-2 text-base">
                        {t.isDefault ? <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" /> : null}
                        <span className="truncate">{t.name}</span>
                      </CardTitle>
                      {t.description ? (
                        <CardDescription className="line-clamp-2">{t.description}</CardDescription>
                      ) : null}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline">{t.stepCount} steps</Badge>
                    <Badge variant="outline">{t.runCount} runs</Badge>
                    {t.defaultForProjects > 0 ? (
                      <Badge variant="outline">{t.defaultForProjects} project default</Badge>
                    ) : null}
                    <span className="ml-auto text-[10px]">{formatDateTime(t.updatedAt)}</span>
                  </div>
                  {canEdit ? (
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {!t.isDefault ? (
                        <Button size="sm" variant="ghost" onClick={() => setDefault(t.id)}>
                          <Star className="h-3.5 w-3.5" /> Set as default
                        </Button>
                      ) : null}
                      <Button size="sm" variant="outline" onClick={() => setEditing({ id: t.id })}>
                        <Edit3 className="h-3.5 w-3.5" /> Edit
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeTemplate(t)}
                        disabled={t.isDefault && templates.length === 1}
                      >
                        <Trash2 className="h-3.5 w-3.5 text-destructive" />
                      </Button>
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Active runs */}
      <div>
        <h2 className="mb-3 text-lg font-semibold">Recent runs</h2>
        {runs.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center text-sm text-muted-foreground">
              No workflow runs yet. Upload an RFP to start one.
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardContent className="p-0">
              {runs.map((r) => (
                <Link
                  key={r.id}
                  href={`/dashboard/rfps/${r.rfpId}?org=${orgId}`}
                  className="group flex items-center gap-3 border-b px-4 py-3 transition-colors hover:bg-accent/40 last:border-b-0"
                >
                  <Badge variant={RUN_STATUS_BADGE[r.status] ?? "outline"} className="shrink-0">
                    {r.status === "RUNNING" || r.status === "PENDING" ? (
                      <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                    ) : null}
                    {r.status}
                  </Badge>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{r.rfpTitle}</div>
                    <div className="text-xs text-muted-foreground">
                      {r.projectName} · {r.templateName} · step {r.currentStepIndex + 1}/{r.steps.length}
                    </div>
                  </div>
                  <div className="hidden lg:flex items-center gap-1">
                    {r.steps.map((s, i) => (
                      <span
                        key={i}
                        className={cn("h-2 w-2 rounded-full", STATUS_DOT[s])}
                        title={`Step ${i + 1}: ${s}`}
                      />
                    ))}
                  </div>
                  {r.dueDate ? <DueDatePill dueDate={r.dueDate} size="sm" /> : null}
                  <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0" />
                </Link>
              ))}
            </CardContent>
          </Card>
        )}
      </div>

      <TemplateEditorDialog
        orgId={orgId}
        templateId={editing?.id ?? null}
        open={editing !== null}
        onOpenChange={(o) => !o && setEditing(null)}
        onSaved={() => router.refresh()}
      />
    </div>
  );
}
