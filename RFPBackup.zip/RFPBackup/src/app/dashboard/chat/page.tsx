import { prisma } from "@/lib/prisma";
import { getActiveOrg } from "@/lib/dashboard";
import { ChatPageClient } from "./client";
import { PageHeader } from "@/components/dashboard/page-header";

export default async function ChatPage({
  searchParams,
}: {
  searchParams: Promise<{ org?: string; thread?: string }>;
}) {
  const sp = await searchParams;
  const { organization } = await getActiveOrg(sp.org);

  const threads = await prisma.chatThread.findMany({
    where: { organizationId: organization.id },
    orderBy: { updatedAt: "desc" },
    take: 50,
    include: {
      _count: { select: { messages: true } },
      project: { select: { name: true } },
      rfp: { select: { title: true } },
      index: { select: { name: true } },
    },
  });

  let activeThread = null;
  if (sp.thread) {
    activeThread = await prisma.chatThread.findUnique({
      where: { id: sp.thread },
      include: { messages: { orderBy: { createdAt: "asc" } } },
    });
    if (activeThread && activeThread.organizationId !== organization.id) {
      activeThread = null;
    }
  }

  return (
    <div className="space-y-4">
      <PageHeader
        title="Chat"
        subtitle="Talk to your knowledge base, projects, or individual RFPs."
        breadcrumb={[
          { label: "Home", href: `/dashboard?org=${organization.id}` },
          { label: "Chat" },
        ]}
      />
      <ChatPageClient
        organizationId={organization.id}
      threads={threads.map((t) => ({
        id: t.id,
        title: t.title,
        scope: t.scope,
        scopeRef:
          t.rfp?.title ??
          t.project?.name ??
          t.index?.name ??
          organization.name,
        messageCount: t._count.messages,
        updatedAt: t.updatedAt.toISOString(),
      }))}
      activeThread={
        activeThread
          ? {
              id: activeThread.id,
              scope: activeThread.scope,
              projectId: activeThread.projectId,
              rfpId: activeThread.rfpId,
              indexId: activeThread.indexId,
              title: activeThread.title,
              messages: activeThread.messages.map((m) => ({
                id: m.id,
                role: m.role,
                content: m.content,
                metadata: (m.metadata as any) ?? null,
              })),
            }
          : null
      }
      />
    </div>
  );
}
