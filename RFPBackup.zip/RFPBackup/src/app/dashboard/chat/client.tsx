"use client";

import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Plus, MessageSquare, Trash2, FolderKanban, FileText, Library, Building2 } from "lucide-react";
import { ChatScope } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChatPanel } from "@/components/chat/chat-panel";
import { toast } from "@/components/ui/use-toast";
import { cn, formatDateTime, truncate } from "@/lib/utils";
import { useConfirm } from "@/components/ui/confirm";

interface ThreadRow {
  id: string;
  title: string;
  scope: ChatScope;
  scopeRef: string;
  messageCount: number;
  updatedAt: string;
}

interface ActiveThread {
  id: string;
  scope: ChatScope;
  projectId: string | null;
  rfpId: string | null;
  indexId: string | null;
  title: string;
  messages: Array<{ id: string; role: any; content: string; metadata: any }>;
}

const SCOPE_ICON: Record<ChatScope, React.ComponentType<{ className?: string }>> = {
  ORG: Building2,
  PROJECT: FolderKanban,
  RFP: FileText,
  INDEX: Library,
};

export function ChatPageClient({
  organizationId,
  threads,
  activeThread,
}: {
  organizationId: string;
  threads: ThreadRow[];
  activeThread: ActiveThread | null;
}) {
  const router = useRouter();
  const sp = useSearchParams();
  const confirm = useConfirm();

  function openThread(id: string) {
    const next = new URLSearchParams(sp.toString());
    next.set("thread", id);
    router.push(`?${next.toString()}`);
  }
  function newChat() {
    const next = new URLSearchParams(sp.toString());
    next.delete("thread");
    router.push(`?${next.toString()}`);
  }
  async function remove(id: string) {
    if (!(await confirm("Delete this conversation?", { destructive: true, confirmLabel: "Delete" }))) return;
    const res = await fetch(`/api/chat/threads/${id}`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Deleted" });
      if (activeThread?.id === id) newChat();
      else router.refresh();
    }
  }

  return (
    <div className="grid h-[calc(100vh-14rem)] min-h-[480px] gap-4 lg:grid-cols-[280px_1fr]">
      <aside className="flex min-h-0 flex-col rounded-xl border bg-card">
        <div className="flex items-center justify-between border-b p-3">
          <h2 className="text-sm font-semibold">Conversations</h2>
          <Button size="sm" variant="gradient" onClick={newChat} className="h-7 px-2 text-xs">
            <Plus className="h-3 w-3" /> New
          </Button>
        </div>
        <div className="scrollbar-thin flex-1 overflow-y-auto p-2">
          {threads.length === 0 ? (
            <div className="grid place-items-center py-12 text-center text-xs text-muted-foreground">
              <MessageSquare className="mb-2 h-6 w-6 opacity-50" />
              No conversations yet.
            </div>
          ) : (
            <ul className="space-y-1">
              {threads.map((t) => {
                const Icon = SCOPE_ICON[t.scope];
                const active = activeThread?.id === t.id;
                return (
                  <li key={t.id}>
                    <button
                      onClick={() => openThread(t.id)}
                      className={cn(
                        "group flex w-full items-start gap-2 rounded-lg p-2 text-left text-xs transition-colors hover:bg-accent",
                        active && "bg-accent",
                      )}
                    >
                      <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-medium">{t.title}</div>
                        <div className="truncate text-[10px] text-muted-foreground">
                          {t.scope} · {t.scopeRef} · {t.messageCount} msg
                        </div>
                      </div>
                      <Trash2
                        className="h-3.5 w-3.5 opacity-0 transition-opacity hover:text-destructive group-hover:opacity-100"
                        onClick={(e) => {
                          e.stopPropagation();
                          remove(t.id);
                        }}
                      />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </aside>

      <main className="min-h-0 overflow-hidden rounded-xl border bg-card">
        {activeThread ? (
          <ChatPanel
            threadId={activeThread.id}
            organizationId={organizationId}
            scope={activeThread.scope}
            projectId={activeThread.projectId}
            rfpId={activeThread.rfpId}
            indexId={activeThread.indexId}
            scopeLabel={scopeLabelOf(activeThread, threads)}
            initialMessages={activeThread.messages.map((m) => ({
              id: m.id,
              role: m.role,
              content: m.content,
              metadata: m.metadata,
            }))}
          />
        ) : (
          <ChatPanel
            organizationId={organizationId}
            scope="ORG"
            scopeLabel="Organization-wide"
            suggestions={[
              "Summarize what's in our knowledge base",
              "What RFPs are currently open?",
              "Help me draft an answer about our security posture",
              "List the most common questions across recent RFPs",
            ]}
          />
        )}
      </main>
    </div>
  );
}

function scopeLabelOf(thread: ActiveThread, threads: ThreadRow[]): string {
  const t = threads.find((x) => x.id === thread.id);
  return t ? `${thread.scope} · ${t.scopeRef}` : thread.scope;
}
