"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";

export default function NewOrgPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [pending, setPending] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    const res = await fetch("/api/orgs", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name }),
    });
    setPending(false);
    if (!res.ok) {
      toast({ title: "Couldn't create org", description: (await res.json()).error });
      return;
    }
    const { org } = await res.json();
    toast({ title: "Organization created", variant: "success" });
    router.push(`/dashboard?org=${org.id}`);
  }

  return (
    <div className="mx-auto max-w-md py-12">
      <Card>
        <CardHeader className="text-center">
          <div className="mx-auto grid h-12 w-12 place-items-center rounded-lg bg-gradient-to-br from-primary to-fuchsia-500">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <CardTitle className="mt-4">Create an organization</CardTitle>
          <CardDescription>
            Workspaces in OATI AutoRFP are organizations. You can invite teammates afterward.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Organization name</Label>
              <Input
                id="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                minLength={2}
                placeholder="Acme Inc"
                autoFocus
              />
            </div>
            <Button type="submit" variant="gradient" className="w-full" disabled={pending}>
              {pending ? "Creating…" : "Create organization"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
