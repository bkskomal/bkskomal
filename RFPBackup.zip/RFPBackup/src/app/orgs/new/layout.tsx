import { redirect } from "next/navigation";
import { auth } from "@/lib/auth";

export default async function NewOrgLayout({ children }: { children: React.ReactNode }) {
  const session = await auth();
  if (!session?.user?.id) redirect("/auth/signin?callbackUrl=/orgs/new");
  return <>{children}</>;
}
