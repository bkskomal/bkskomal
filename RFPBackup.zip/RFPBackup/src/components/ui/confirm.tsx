"use client";

// React confirm + alert dialogs, replacing window.confirm() / window.alert().
//
// Usage:
//   1. Mount <ConfirmProvider> once near the root (DashboardShell does this).
//   2. Anywhere underneath, call the hook:
//
//        const confirm = useConfirm();
//        if (await confirm("Delete project?")) { ... }
//
//        const alert = useAlert();
//        await alert("Done!");
//
// Both return a Promise<boolean> / Promise<void> so the caller can `await`
// the user's decision exactly like the native APIs, but the dialog matches
// the rest of the app (Radix dialog, dark/solarized themes, keyboard-trap,
// destructive button styling, etc.).

import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
} from "react";
import { AlertTriangle, Info } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export interface ConfirmOptions {
  title?: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  /** When true, the confirm button uses the destructive (red) style. */
  destructive?: boolean;
}

export interface AlertOptions {
  title?: string;
  description?: string;
  okLabel?: string;
}

type Pending =
  | {
      kind: "confirm";
      opts: Required<ConfirmOptions>;
      resolve: (ok: boolean) => void;
    }
  | {
      kind: "alert";
      opts: Required<AlertOptions>;
      resolve: () => void;
    };

interface ConfirmCtx {
  confirm: (message: string, opts?: ConfirmOptions) => Promise<boolean>;
  alert: (message: string, opts?: AlertOptions) => Promise<void>;
}

const Ctx = createContext<ConfirmCtx | null>(null);

const DEFAULT_CONFIRM: Required<ConfirmOptions> = {
  title: "Are you sure?",
  description: "",
  confirmLabel: "Confirm",
  cancelLabel: "Cancel",
  destructive: false,
};
const DEFAULT_ALERT: Required<AlertOptions> = {
  title: "Notice",
  description: "",
  okLabel: "OK",
};

export function ConfirmProvider({ children }: { children: React.ReactNode }) {
  const [pending, setPending] = useState<Pending | null>(null);

  // Hold a stable callback that knows the current `pending` via a ref —
  // avoids re-creating the ctx value on every state change (which would
  // bust memos in every consumer).
  const pendingRef = useRef<Pending | null>(null);
  pendingRef.current = pending;

  const confirm = useCallback(
    (message: string, opts?: ConfirmOptions) =>
      new Promise<boolean>((resolve) => {
        setPending({
          kind: "confirm",
          opts: {
            ...DEFAULT_CONFIRM,
            ...(opts ?? {}),
            description: opts?.description ?? message,
            title: opts?.title ?? (message.length <= 80 ? message : DEFAULT_CONFIRM.title),
          },
          resolve,
        });
      }),
    [],
  );

  const alert = useCallback(
    (message: string, opts?: AlertOptions) =>
      new Promise<void>((resolve) => {
        setPending({
          kind: "alert",
          opts: {
            ...DEFAULT_ALERT,
            ...(opts ?? {}),
            description: opts?.description ?? message,
            title: opts?.title ?? (message.length <= 80 ? message : DEFAULT_ALERT.title),
          },
          resolve,
        });
      }),
    [],
  );

  const value = useMemo<ConfirmCtx>(() => ({ confirm, alert }), [confirm, alert]);

  function settle(result: boolean) {
    const cur = pendingRef.current;
    setPending(null);
    if (!cur) return;
    if (cur.kind === "confirm") cur.resolve(result);
    else cur.resolve();
  }

  return (
    <Ctx.Provider value={value}>
      {children}
      <Dialog
        open={pending !== null}
        onOpenChange={(open) => {
          // Treat outside-click / Esc as cancel (false). For alert, just close.
          if (!open) settle(false);
        }}
      >
        {pending ? (
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-base">
                {pending.kind === "confirm" && pending.opts.destructive ? (
                  <AlertTriangle className="h-4 w-4 text-destructive" />
                ) : (
                  <Info className="h-4 w-4 text-primary" />
                )}
                {pending.opts.title}
              </DialogTitle>
              {pending.opts.description ? (
                <DialogDescription className="whitespace-pre-wrap">
                  {pending.opts.description}
                </DialogDescription>
              ) : null}
            </DialogHeader>
            <DialogFooter className="gap-2 sm:gap-2">
              {pending.kind === "confirm" ? (
                <>
                  <Button variant="outline" onClick={() => settle(false)}>
                    {pending.opts.cancelLabel}
                  </Button>
                  <Button
                    variant={pending.opts.destructive ? "destructive" : "default"}
                    onClick={() => settle(true)}
                    autoFocus
                  >
                    {pending.opts.confirmLabel}
                  </Button>
                </>
              ) : (
                <Button onClick={() => settle(true)} autoFocus>
                  {pending.opts.okLabel}
                </Button>
              )}
            </DialogFooter>
          </DialogContent>
        ) : null}
      </Dialog>
    </Ctx.Provider>
  );
}

export function useConfirm() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useConfirm must be used inside <ConfirmProvider>");
  return ctx.confirm;
}

export function useAlert() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAlert must be used inside <ConfirmProvider>");
  return ctx.alert;
}
