"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Send,
  Loader2,
  Sparkles,
  Wrench,
  CheckCircle2,
  AlertTriangle,
  User as UserIcon,
  Paperclip,
  FileText,
  X,
} from "lucide-react";
import { ChatScope } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { Markdown } from "@/components/markdown";
import { cn, truncate } from "@/lib/utils";

interface Message {
  id: string;
  role: "USER" | "ASSISTANT" | "TOOL" | "SYSTEM";
  content: string;
  metadata?: { sources?: any[]; toolCalls?: any[] } | null;
  pending?: boolean;
}

interface Step {
  step: string;
  detail?: string;
  data?: unknown;
}

export interface ChatScopeProps {
  organizationId: string;
  scope: ChatScope;
  projectId?: string | null;
  rfpId?: string | null;
  indexId?: string | null;
  /** Human-readable label for the scope, shown in the header. */
  scopeLabel: string;
}

interface ChatPanelProps extends ChatScopeProps {
  /** If provided, opens an existing thread; otherwise creates one on first message. */
  threadId?: string;
  initialMessages?: Message[];
  /** Suggested prompts shown when the thread is empty. */
  suggestions?: string[];
  className?: string;
}

export function ChatPanel({
  organizationId,
  scope,
  projectId,
  rfpId,
  indexId,
  scopeLabel,
  threadId: initialThreadId,
  initialMessages = [],
  suggestions = [],
  className,
}: ChatPanelProps) {
  const router = useRouter();
  const [threadId, setThreadId] = useState<string | undefined>(initialThreadId);
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [input, setInput] = useState("");
  const [pending, setPending] = useState(false);
  const [steps, setSteps] = useState<Step[]>([]);
  const [enableTools, setEnableTools] = useState(true);
  // Phase C: Agentic mode dispatches to the LangGraph research agent
  // (plan→search→draft→critique→revise). Mutually exclusive with tools —
  // the agent has its own retrieval loop and doesn't use the tool registry.
  const [enableAgentic, setEnableAgentic] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  // Files attached via the paperclip button. Each is uploaded to the thread's
  // KB index (or auto-created "Chat Uploads" when the thread isn't scoped to
  // a KB) and tracked here so the user sees a chip and the next assistant
  // turn knows which document IDs are available.
  const [attachments, setAttachments] = useState<
    Array<{ id: string; name: string; size: number; status: "uploading" | "indexed" | "failed"; documentId?: string; error?: string }>
  >([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, steps]);

  async function ensureThread(): Promise<string> {
    if (threadId) return threadId;
    const res = await fetch("/api/chat/threads", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ organizationId, scope, projectId, rfpId, indexId }),
    });
    if (!res.ok) throw new Error((await res.json()).error ?? "Couldn't create thread");
    const { thread } = await res.json();
    setThreadId(thread.id);
    return thread.id;
  }

  async function uploadFiles(files: File[]) {
    if (files.length === 0) return;
    const tid = await ensureThread();
    for (const file of files) {
      const localId = `att-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      setAttachments((prev) => [
        ...prev,
        { id: localId, name: file.name, size: file.size, status: "uploading" },
      ]);
      try {
        const fd = new FormData();
        fd.append("file", file);
        const res = await fetch(`/api/chat/threads/${tid}/upload`, {
          method: "POST",
          body: fd,
        });
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          setAttachments((prev) =>
            prev.map((a) =>
              a.id === localId
                ? { ...a, status: "failed", error: body.error ?? `HTTP ${res.status}` }
                : a,
            ),
          );
          continue;
        }
        const body = await res.json();
        setAttachments((prev) =>
          prev.map((a) =>
            a.id === localId
              ? { ...a, status: "indexed", documentId: body.document?.id }
              : a,
          ),
        );
      } catch (e) {
        setAttachments((prev) =>
          prev.map((a) =>
            a.id === localId
              ? { ...a, status: "failed", error: e instanceof Error ? e.message : String(e) }
              : a,
          ),
        );
      }
    }
  }

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || pending) return;

    setPending(true);
    setSteps([]);
    setInput("");

    // Append a compact "📎 attachments" footnote so the LLM sees which
    // documentIds it can pass to start_rfp_process / search_knowledge_base.
    // We clear the attachments list on the same turn — they're "consumed".
    const indexedAttachments = attachments.filter(
      (a) => a.status === "indexed" && a.documentId,
    );
    const composedContent =
      indexedAttachments.length > 0
        ? `${trimmed}\n\n---\n_Attached files (documentId in parentheses — use start_rfp_process to convert any of these to an RFP):_\n${indexedAttachments
            .map((a) => `- ${a.name} (\`${a.documentId}\`)`)
            .join("\n")}`
        : trimmed;
    if (indexedAttachments.length > 0) setAttachments([]);

    // Optimistic user message + placeholder assistant message
    const userMsg: Message = {
      id: `tmp-${Date.now()}`,
      role: "USER",
      content: composedContent,
    };
    const assistantPlaceholder: Message = {
      id: `tmp-a-${Date.now()}`,
      role: "ASSISTANT",
      content: "",
      pending: true,
    };
    setMessages((prev) => [...prev, userMsg, assistantPlaceholder]);

    try {
      const tid = await ensureThread();
      const res = await fetch(`/api/chat/threads/${tid}/messages`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ content: composedContent, enableTools, enableAgentic }),
      });
      if (!res.ok || !res.body) {
        const errText = await res.text();
        toast({ title: "Chat failed", description: truncate(errText, 200) });
        setMessages((prev) => prev.filter((m) => !m.pending));
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split("\n\n");
        buffer = events.pop() ?? "";
        for (const evt of events) {
          if (!evt.trim()) continue;
          const lines = evt.split("\n");
          const event = lines.find((l) => l.startsWith("event: "))?.slice(7).trim();
          const data = lines.find((l) => l.startsWith("data: "))?.slice(6);
          if (!data) continue;
          const parsed = JSON.parse(data);

          if (event === "step") {
            setSteps((prev) => [...prev, parsed as Step]);
          } else if (event === "done") {
            setMessages((prev) =>
              prev.map((m) =>
                m.pending
                  ? {
                      id: parsed.assistantMessageId,
                      role: "ASSISTANT",
                      content: parsed.content,
                      metadata: parsed.metadata,
                    }
                  : m,
              ),
            );
          } else if (event === "title") {
            // Trigger a refresh so sidebars showing thread titles update.
            router.refresh();
          } else if (event === "error") {
            toast({ title: "Chat error", description: parsed.message });
            setMessages((prev) => prev.filter((m) => !m.pending));
          }
        }
      }
    } catch (e) {
      toast({ title: "Chat failed", description: e instanceof Error ? e.message : String(e) });
      setMessages((prev) => prev.filter((m) => !m.pending));
    } finally {
      setPending(false);
      setSteps([]);
    }
  }

  return (
    <div className={cn("flex h-full flex-col", className)}>
      <div className="flex items-center justify-between border-b px-4 py-2.5">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <span className="text-sm font-medium">AI Chat</span>
          <Badge variant="outline" className="text-[10px]">{scopeLabel}</Badge>
        </div>
        <div className="flex items-center gap-1.5">
          {/* Phase C: Agentic mode toggle. Mutually exclusive with Tools — the
              research agent runs its own retrieval loop and doesn't dispatch
              to the tool registry. Picking one auto-clears the other. */}
          <Button
            size="sm"
            variant={enableAgentic ? "gradient" : "outline"}
            onClick={() => {
              setEnableAgentic((v) => {
                const next = !v;
                if (next) setEnableTools(false);
                return next;
              });
            }}
            title="Multi-step research agent: plan → search → critique → revise"
            className="h-7 px-2 text-xs"
          >
            <Sparkles className="h-3 w-3" /> Agent {enableAgentic ? "ON" : "OFF"}
          </Button>
          <Button
            size="sm"
            variant={enableTools ? "default" : "outline"}
            onClick={() => {
              setEnableTools((v) => {
                const next = !v;
                if (next) setEnableAgentic(false);
                return next;
              });
            }}
            disabled={enableAgentic}
            title={enableAgentic ? "Disabled while Agent mode is on" : "Allow the assistant to call tools"}
            className="h-7 px-2 text-xs"
          >
            <Wrench className="h-3 w-3" /> Tools {enableTools ? "ON" : "OFF"}
          </Button>
        </div>
      </div>

      <div ref={scrollRef} className="scrollbar-thin min-h-0 flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 ? (
          <EmptyState suggestions={suggestions} onPick={(s) => send(s)} />
        ) : (
          messages.map((m) => <MessageBubble key={m.id} message={m} />)
        )}
        {steps.length > 0 ? <StepsTrace steps={steps} /> : null}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="border-t bg-background p-3"
        onDragOver={(e) => {
          e.preventDefault();
        }}
        onDrop={(e) => {
          e.preventDefault();
          const files = Array.from(e.dataTransfer.files ?? []);
          if (files.length > 0) void uploadFiles(files);
        }}
      >
        {/* Attachment chips — shown while files are uploading or staged for
            the next turn. Click × to drop one before sending. */}
        {attachments.length > 0 ? (
          <div className="mb-2 flex flex-wrap gap-1.5">
            {attachments.map((a) => (
              <span
                key={a.id}
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-md border px-2 py-1 text-xs",
                  a.status === "indexed"
                    ? "border-emerald-500/40 bg-emerald-50 text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-100"
                    : a.status === "failed"
                      ? "border-destructive/40 bg-destructive/10 text-destructive"
                      : "border-muted-foreground/30 bg-muted text-muted-foreground",
                )}
                title={a.error ?? a.documentId ?? "uploading…"}
              >
                {a.status === "uploading" ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : a.status === "failed" ? (
                  <AlertTriangle className="h-3 w-3" />
                ) : (
                  <FileText className="h-3 w-3" />
                )}
                <span className="max-w-[180px] truncate">{a.name}</span>
                <button
                  type="button"
                  onClick={() => setAttachments((prev) => prev.filter((x) => x.id !== a.id))}
                  className="text-muted-foreground hover:text-foreground"
                  aria-label="Remove attachment"
                >
                  <X className="h-3 w-3" />
                </button>
              </span>
            ))}
          </div>
        ) : null}

        <div className="flex gap-2">
          {/* Paperclip → opens file picker; same files can also be drag-dropped onto the whole input area. */}
          <input
            type="file"
            ref={fileInputRef}
            multiple
            className="hidden"
            onChange={(e) => {
              const files = Array.from(e.target.files ?? []);
              if (files.length > 0) void uploadFiles(files);
              // reset so picking the same file twice still fires onChange
              if (fileInputRef.current) fileInputRef.current.value = "";
            }}
          />
          <Button
            type="button"
            size="icon"
            variant="outline"
            onClick={() => fileInputRef.current?.click()}
            disabled={pending}
            title="Attach a file (PDF, DOCX, XLSX, PPTX, etc.) — drops also work"
          >
            <Paperclip className="h-4 w-4" />
          </Button>
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              attachments.length > 0
                ? "Tell me what to do with the file…  (try: “start an RFP process from this document”)"
                : "Ask anything…  (⏎ to send, ⇧⏎ for new line)"
            }
            className="min-h-[44px] max-h-40 resize-none"
            rows={1}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(input);
              }
            }}
            disabled={pending}
          />
          <Button type="submit" size="icon" variant="gradient" disabled={pending || !input.trim()}>
            {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      </form>
    </div>
  );
}

function EmptyState({
  suggestions,
  onPick,
}: {
  suggestions: string[];
  onPick: (s: string) => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-primary/20 to-fuchsia-500/20">
        <Sparkles className="h-5 w-5 text-primary" />
      </div>
      <h3 className="mt-3 text-base font-semibold">Start a conversation</h3>
      <p className="mt-1 max-w-sm text-xs text-muted-foreground">
        Ask questions about your RFPs, your knowledge base, or have me draft responses for you.
      </p>
      {suggestions.length ? (
        <div className="mt-4 grid w-full max-w-md gap-2">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => onPick(s)}
              className="rounded-lg border bg-card px-3 py-2 text-left text-xs hover:bg-accent transition-colors"
            >
              {s}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "USER";
  const sources = message.metadata?.sources ?? [];

  return (
    <div className={cn("flex gap-3", isUser && "flex-row-reverse")}>
      <div
        className={cn(
          "grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs font-bold",
          isUser
            ? "bg-secondary text-secondary-foreground"
            : "bg-gradient-to-br from-primary to-fuchsia-500 text-white",
        )}
      >
        {isUser ? <UserIcon className="h-3.5 w-3.5" /> : <Sparkles className="h-3.5 w-3.5" />}
      </div>
      <div className={cn("min-w-0 max-w-[85%] flex-1", isUser && "flex flex-col items-end")}>
        <div
          className={cn(
            "rounded-2xl px-4 py-2.5",
            isUser
              ? "bg-primary text-primary-foreground"
              : "bg-card border",
          )}
        >
          {message.pending ? (
            <div className="flex items-center gap-1 py-1">
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-current" />
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-current" style={{ animationDelay: "0.2s" }} />
              <span className="pulse-dot inline-block h-1.5 w-1.5 rounded-full bg-current" style={{ animationDelay: "0.4s" }} />
            </div>
          ) : isUser ? (
            <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
          ) : (
            <Markdown>{message.content}</Markdown>
          )}
        </div>
        {!isUser && sources.length > 0 ? (
          <details className="mt-1.5 text-xs text-muted-foreground">
            <summary className="cursor-pointer hover:text-foreground">
              {sources.length} source{sources.length === 1 ? "" : "s"}
            </summary>
            <div className="mt-2 space-y-1">
              {sources.map((s: any, i: number) => (
                <div key={i} className="rounded border bg-muted/40 p-2">
                  <div className="flex items-center justify-between text-[10px] font-medium">
                    <span>[Source {i + 1}] {s.documentName ?? "—"}{s.page ? ` · p.${s.page}` : ""}</span>
                    {typeof s.score === "number" ? (
                      <span className="opacity-60">{Math.round(s.score * 100)}%</span>
                    ) : null}
                  </div>
                  <p className="mt-1 line-clamp-3">{s.excerpt}</p>
                </div>
              ))}
            </div>
          </details>
        ) : null}
      </div>
    </div>
  );
}

function StepsTrace({ steps }: { steps: Step[] }) {
  const ICON: Record<string, React.ReactNode> = {
    thinking: <Loader2 className="h-3 w-3 animate-spin" />,
    tool_call: <Wrench className="h-3 w-3" />,
    tool_result: <CheckCircle2 className="h-3 w-3 text-emerald-500" />,
    delta: <Loader2 className="h-3 w-3 animate-spin" />,
    error: <AlertTriangle className="h-3 w-3 text-destructive" />,
  };
  return (
    <div className="flex flex-col gap-1.5 rounded-lg border bg-muted/30 p-2.5 text-xs text-muted-foreground">
      {steps.slice(-5).map((s, i) => (
        <div key={i} className="flex items-center gap-2">
          {ICON[s.step] ?? null}
          <span className="font-mono uppercase tracking-wider text-[10px]">{s.step}</span>
          <span className="truncate">{s.detail}</span>
        </div>
      ))}
    </div>
  );
}
