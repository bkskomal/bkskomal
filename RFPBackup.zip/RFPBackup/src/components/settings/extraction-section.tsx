"use client";

// Question Extraction settings panel (Phase A.2).
//
// Lets admins control how RFPs are split, extracted, and classified:
//   - Pinned extraction model (separate from chat model — extraction is
//     structured-output, so a smaller/faster model usually works fine)
//   - Stage-2 eligibility classification on/off (turn off to skip the extra
//     LLM call when you only need "is this a question" with no nuance)
// Advanced:
//   - Custom system prompt (overrides the built-in V2 prompt; useful for
//     domain-specific RFPs where generic extraction returns noise)
//   - Batch size in KB (smaller = more granular, more LLM calls)
//   - Concurrency (parallel batches — capped by provider rate limits)
//
// Defaults preserve current behavior — empty model = use env/llmModel,
// empty prompt = use built-in.

import { useCallback, useEffect, useState } from "react";
import {
  FileQuestion,
  Loader2,
  ChevronDown,
  ChevronRight,
  Save,
  RotateCcw,
  Sparkles,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";

interface ExtractionConfig {
  /** Empty string = inherit (env or llmModel). */
  model: string;
  /** Empty string = use built-in V2 system prompt. */
  promptOverride: string;
  eligibilityEnabled: boolean;
  batchSizeKb: number;
  concurrency: number;
}

interface Props {
  orgId: string;
  canEdit: boolean;
}

// Defaults match the resolver fallbacks. Used to render before the GET
// resolves and as the "Reset to defaults" target.
const DEFAULTS: ExtractionConfig = {
  model: "",
  promptOverride: "",
  eligibilityEnabled: true,
  batchSizeKb: 12,
  concurrency: 3,
};

export function ExtractionSection({ orgId, canEdit }: Props) {
  const [config, setConfig] = useState<ExtractionConfig>(DEFAULTS);
  const [initial, setInitial] = useState<ExtractionConfig>(DEFAULTS);
  const [resolvedModel, setResolvedModel] = useState<string>("");
  const [source, setSource] = useState<"org" | "default">("default");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [advanced, setAdvanced] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`);
      if (!res.ok) return;
      const body = await res.json();
      const e = body.config?.extraction;
      if (e) {
        // The resolver always returns a resolved model id, even when the org
        // hasn't pinned one. We store the resolved value separately so we can
        // show it as the placeholder ("currently using …") in the input.
        setResolvedModel(e.model ?? "");
        const next: ExtractionConfig = {
          // Only treat as "pinned" if source says org; else keep input empty
          // and use the resolved model as a placeholder.
          model: body.config?.source?.extraction === "org" && e.model ? e.model : "",
          promptOverride: e.promptOverride ?? "",
          eligibilityEnabled: e.eligibilityEnabled ?? true,
          batchSizeKb: e.batchSizeKb ?? DEFAULTS.batchSizeKb,
          concurrency: e.concurrency ?? DEFAULTS.concurrency,
        };
        setConfig(next);
        setInitial(next);
      }
      setSource(body.config?.source?.extraction ?? "default");
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void load();
  }, [load]);

  const dirty = JSON.stringify(config) !== JSON.stringify(initial);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          extraction: {
            // Empty string → null on the server, which clears the override.
            model: config.model.trim() === "" ? null : config.model.trim(),
            promptOverride: config.promptOverride.trim() === "" ? null : config.promptOverride,
            eligibilityEnabled: config.eligibilityEnabled,
            batchSizeKb: config.batchSizeKb,
            concurrency: config.concurrency,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error });
        return;
      }
      toast({ title: "Extraction settings saved", variant: "success" });
      setInitial(config);
      setSource("org");
      // Re-fetch to pull the newly-resolved model id back into the placeholder.
      await load();
    } finally {
      setSaving(false);
    }
  }

  async function resetToDefaults() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          extraction: {
            model: null,
            promptOverride: null,
            eligibilityEnabled: null,
            batchSizeKb: null,
            concurrency: null,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't reset", description: e.error });
        return;
      }
      toast({ title: "Reset to defaults", variant: "success" });
      setConfig(DEFAULTS);
      setInitial(DEFAULTS);
      setSource("default");
      await load();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileQuestion className="h-4 w-4" />
              Question extraction
              <Badge variant={source === "org" ? "info" : "outline"} className="ml-1 text-[10px]">
                {source === "org" ? "Customized" : "Defaults"}
              </Badge>
            </CardTitle>
            <CardDescription>
              How RFP text is split into batches, extracted into questions, and classified
              for eligibility. Default model + prompt work for most generic RFPs.
            </CardDescription>
          </div>
          {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* ----- Simple tier ----- */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs" htmlFor="ex-model">
              Extraction model
            </Label>
            <Input
              id="ex-model"
              value={config.model}
              onChange={(e) => setConfig({ ...config, model: e.target.value })}
              disabled={!canEdit || loading}
              placeholder={resolvedModel ? `Currently: ${resolvedModel}` : "Inherit from chat model"}
              className="h-9 font-mono text-xs"
            />
            <p className="text-[11px] text-muted-foreground">
              Pin a fast structured-output model (e.g. <code>gpt-4o-mini</code>, <code>llama-3.3-8b</code>).
              Leave empty to use the chat model.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Stage-2 eligibility pass</Label>
            <div className="flex h-9 items-center gap-2">
              <input
                type="checkbox"
                id="ex-elig"
                checked={config.eligibilityEnabled}
                onChange={(e) => setConfig({ ...config, eligibilityEnabled: e.target.checked })}
                disabled={!canEdit || loading}
                className="h-4 w-4"
              />
              <label htmlFor="ex-elig" className="text-sm">
                Classify each question's eligibility
              </label>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Adds one LLM call per batch. Disable to halve extraction cost when you don&apos;t
              need per-question answerability tags.
            </p>
          </div>
        </div>

        {/* ----- Advanced tier ----- */}
        <div className="rounded-lg border bg-muted/20">
          <button
            type="button"
            onClick={() => setAdvanced((v) => !v)}
            className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:bg-muted/40"
            aria-expanded={advanced}
          >
            <span className="flex items-center gap-1.5">
              {advanced ? (
                <ChevronDown className="h-3.5 w-3.5" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5" />
              )}
              Advanced
            </span>
            <span className="text-[10px] uppercase tracking-wider opacity-70">
              {advanced ? "Hide" : "Show"}
            </span>
          </button>
          {advanced ? (
            <div className="space-y-4 border-t px-3 py-3">
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="ex-prompt">
                  Custom system prompt (overrides built-in)
                </Label>
                <Textarea
                  id="ex-prompt"
                  value={config.promptOverride}
                  onChange={(e) => setConfig({ ...config, promptOverride: e.target.value })}
                  disabled={!canEdit || loading}
                  placeholder="Leave blank to use the built-in V2 extraction prompt"
                  rows={5}
                  className="font-mono text-xs"
                />
                <p className="text-[11px] text-muted-foreground">
                  Must instruct the model to return JSON of shape <code>{`{questions: [...]}`}</code>.
                  Wrong shape = zero questions extracted.
                </p>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-xs" htmlFor="ex-batchkb">
                    Batch size (KB)
                  </Label>
                  <Input
                    id="ex-batchkb"
                    type="number"
                    min={1}
                    max={128}
                    value={config.batchSizeKb}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        batchSizeKb: clampInt(e.target.value, 1, 128, DEFAULTS.batchSizeKb),
                      })
                    }
                    disabled={!canEdit || loading}
                    className="h-9"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Max bytes per LLM call. Smaller = more batches, more granular failures.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs" htmlFor="ex-concurrency">
                    Concurrency
                  </Label>
                  <Input
                    id="ex-concurrency"
                    type="number"
                    min={1}
                    max={16}
                    value={config.concurrency}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        concurrency: clampInt(e.target.value, 1, 16, DEFAULTS.concurrency),
                      })
                    }
                    disabled={!canEdit || loading}
                    className="h-9"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Parallel batches in flight. Raise for big RFPs, lower if you hit rate limits.
                  </p>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* ----- Actions ----- */}
        {canEdit ? (
          <div className="flex items-center justify-end gap-2 pt-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={resetToDefaults}
              disabled={saving || (source === "default" && !dirty)}
              title="Clear org overrides and use platform defaults"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset to defaults
            </Button>
            <Button
              variant="gradient"
              size="sm"
              onClick={save}
              disabled={saving || !dirty}
            >
              {saving ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Save className="h-3.5 w-3.5" />
              )}
              Save changes
            </Button>
          </div>
        ) : (
          <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3" />
            Read-only &mdash; ADMIN or OWNER role required to change extraction settings.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function clampInt(raw: string, min: number, max: number, fallback: number): number {
  const n = parseInt(raw, 10);
  if (Number.isNaN(n)) return fallback;
  if (n < min) return min;
  if (n > max) return max;
  return n;
}
