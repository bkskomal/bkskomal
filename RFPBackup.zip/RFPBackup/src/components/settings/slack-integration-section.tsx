"use client";

// Slack integration settings panel (Tier B1).
//
// Three sub-sections:
//   1. Status — connected/not-configured + team name + test button.
//   2. Token & channel — bot token field (write-only after first save),
//      channel picker populated from /channels, webhook fallback URL.
//   3. Event preferences — 4 checkboxes mapping to slack-events kinds.
//
// All requests hit /api/orgs/[orgId]/integrations/slack and the route's
// admin-only middleware enforces access. We still hide destructive controls
// behind a `canEdit` prop so non-admins don't see them.

import { useEffect, useState } from "react";
import { CheckCircle2, Loader2, Slack as SlackIcon, Trash2 } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useConfirm } from "@/components/ui/confirm";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";

const KEEP_EXISTING = "__KEEP__";

const EVENT_KINDS = [
  { key: "rfp_uploaded", label: "RFP processed", hint: "Fires when an uploaded RFP finishes extraction." },
  { key: "response_generated", label: "Response generated", hint: "Fires after an AI answer is produced." },
  { key: "mention", label: "Mentions in comments", hint: "Fires when a teammate is @mentioned." },
  { key: "outcome_set", label: "Outcome set", hint: "Fires when an RFP is marked WON / LOST / etc." },
] as const;

type EventKey = (typeof EVENT_KINDS)[number]["key"];

interface IntegrationRow {
  id: string;
  enabled: boolean;
  teamId: string | null;
  teamName: string | null;
  defaultChannelId: string | null;
  defaultChannelName: string | null;
  webhookUrl: string | null;
  botTokenPrefix: string;
  hasBotToken: boolean;
  eventPreferences: Record<EventKey, boolean>;
}

interface SlackChannel {
  id: string;
  name: string;
  isPrivate: boolean;
}

export function SlackIntegrationSection({ orgId, canEdit }: { orgId: string; canEdit: boolean }) {
  const confirm = useConfirm();
  const [row, setRow] = useState<IntegrationRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [channels, setChannels] = useState<SlackChannel[]>([]);
  const [channelsLoading, setChannelsLoading] = useState(false);

  // Form state — local mirror of `row` we mutate as the admin edits. The
  // token field is special: empty means "leave existing alone"; non-empty
  // means "replace". We never re-render an existing secret; the API only
  // sends back a masked prefix.
  const [botToken, setBotToken] = useState("");
  const [defaultChannelId, setDefaultChannelId] = useState<string>("");
  const [defaultChannelName, setDefaultChannelName] = useState<string>("");
  const [webhookUrl, setWebhookUrl] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [eventPrefs, setEventPrefs] = useState<Record<EventKey, boolean>>({
    rfp_uploaded: true,
    response_generated: true,
    mention: true,
    outcome_set: true,
  });

  async function refresh() {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/integrations/slack`);
      if (!res.ok) {
        toast({ title: "Couldn't load Slack integration" });
        return;
      }
      const data = (await res.json()) as { integration: IntegrationRow | null };
      const r = data.integration;
      setRow(r);
      if (r) {
        setEnabled(r.enabled);
        setDefaultChannelId(r.defaultChannelId ?? "");
        setDefaultChannelName(r.defaultChannelName ?? "");
        setWebhookUrl(r.webhookUrl ?? "");
        setEventPrefs({
          rfp_uploaded: r.eventPreferences?.rfp_uploaded !== false,
          response_generated: r.eventPreferences?.response_generated !== false,
          mention: r.eventPreferences?.mention !== false,
          outcome_set: r.eventPreferences?.outcome_set !== false,
        });
      } else {
        // Defaults for a fresh setup.
        setEnabled(true);
        setDefaultChannelId("");
        setDefaultChannelName("");
        setWebhookUrl("");
        setEventPrefs({
          rfp_uploaded: true,
          response_generated: true,
          mention: true,
          outcome_set: true,
        });
      }
      setBotToken("");
    } finally {
      setLoading(false);
    }
  }

  async function loadChannels() {
    if (!row?.hasBotToken) return;
    setChannelsLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/integrations/slack/channels`);
      if (res.ok) {
        const data = (await res.json()) as { channels: SlackChannel[] };
        setChannels(data.channels ?? []);
      }
    } finally {
      setChannelsLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  useEffect(() => {
    if (row?.hasBotToken) {
      void loadChannels();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [row?.hasBotToken]);

  async function save() {
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        enabled,
        defaultChannelId: defaultChannelId || null,
        defaultChannelName: defaultChannelName || null,
        webhookUrl: webhookUrl || null,
        eventPreferences: eventPrefs,
      };
      if (botToken.trim()) {
        body.botToken = botToken.trim();
      } else if (row?.hasBotToken) {
        body.botToken = KEEP_EXISTING;
      }
      const res = await fetch(`/api/orgs/${orgId}/integrations/slack`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: err.error });
        return;
      }
      toast({ title: "Slack integration saved", variant: "success" });
      await refresh();
    } finally {
      setSaving(false);
    }
  }

  async function test() {
    setTesting(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/integrations/slack/test`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ channelId: defaultChannelId || undefined }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok && data.ok) {
        toast({ title: "Test message sent", variant: "success" });
      } else {
        toast({
          title: "Test failed",
          description: data.error ?? "Unknown error",
        });
      }
    } finally {
      setTesting(false);
    }
  }

  async function disconnect() {
    if (!(await confirm("Notifications will stop immediately.", { title: "Disconnect Slack?", destructive: true, confirmLabel: "Disconnect" }))) return;
    const res = await fetch(`/api/orgs/${orgId}/integrations/slack`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Slack disconnected" });
      await refresh();
    } else {
      const err = await res.json().catch(() => ({}));
      toast({ title: "Couldn't disconnect", description: err.error });
    }
  }

  function onSelectChannel(value: string) {
    setDefaultChannelId(value);
    const match = channels.find((c) => c.id === value);
    setDefaultChannelName(match?.name ?? "");
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <SlackIcon className="h-5 w-5" />
          Slack integration
          {row && row.enabled && (row.hasBotToken || row.webhookUrl) ? (
            <Badge variant="success" className="ml-2">
              <CheckCircle2 className="mr-1 h-3 w-3" /> Connected
              {row.teamName ? ` to ${row.teamName}` : ""}
            </Badge>
          ) : (
            <Badge variant="secondary" className="ml-2">Not configured</Badge>
          )}
        </CardTitle>
        <CardDescription>
          Send RFP events to a Slack channel. Bot tokens are recommended (rich messages, channel
          picker); incoming webhooks are a simpler fallback.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </div>
        ) : (
          <>
            <div className="space-y-4">
              <div>
                <Label htmlFor="slack-bot-token">Bot user OAuth token</Label>
                <Input
                  id="slack-bot-token"
                  type="password"
                  placeholder={row?.hasBotToken ? row.botTokenPrefix : "xoxb-..."}
                  value={botToken}
                  onChange={(e) => setBotToken(e.target.value)}
                  disabled={!canEdit}
                  autoComplete="off"
                />
                <p className="mt-1 text-xs text-muted-foreground">
                  {row?.hasBotToken
                    ? "Leave blank to keep the existing token."
                    : "Create a Slack app, install it to your workspace, and paste the bot token."}
                </p>
              </div>

              <div>
                <Label htmlFor="slack-channel">Default channel</Label>
                {row?.hasBotToken ? (
                  <Select
                    value={defaultChannelId}
                    onValueChange={onSelectChannel}
                    disabled={!canEdit || channelsLoading}
                  >
                    <SelectTrigger id="slack-channel">
                      <SelectValue
                        placeholder={
                          channelsLoading ? "Loading channels..." : "Select a channel"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {channels.map((c) => (
                        <SelectItem key={c.id} value={c.id}>
                          {c.isPrivate ? "🔒 " : "# "}
                          {c.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                ) : (
                  <Input
                    id="slack-channel"
                    placeholder="Channel ID (e.g. C0123456789)"
                    value={defaultChannelId}
                    onChange={(e) => setDefaultChannelId(e.target.value)}
                    disabled={!canEdit}
                  />
                )}
              </div>

              <div>
                <Label htmlFor="slack-webhook">Incoming webhook URL (fallback)</Label>
                <Input
                  id="slack-webhook"
                  type="url"
                  placeholder="https://hooks.slack.com/services/..."
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  disabled={!canEdit}
                />
                <p className="mt-1 text-xs text-muted-foreground">
                  Used only when no bot token is set. Webhooks can't enumerate channels.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <Checkbox
                  id="slack-enabled"
                  checked={enabled}
                  onCheckedChange={(v) => setEnabled(Boolean(v))}
                  disabled={!canEdit}
                />
                <Label htmlFor="slack-enabled" className="cursor-pointer">
                  Integration enabled
                </Label>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-sm font-medium">Event preferences</h3>
              <p className="text-xs text-muted-foreground">
                Untoggle to mute a specific event kind without disconnecting.
              </p>
              <div className="space-y-2">
                {EVENT_KINDS.map((evt) => (
                  <div key={evt.key} className="flex items-start gap-2">
                    <Checkbox
                      id={`slack-evt-${evt.key}`}
                      checked={eventPrefs[evt.key]}
                      onCheckedChange={(v) =>
                        setEventPrefs((prev) => ({ ...prev, [evt.key]: Boolean(v) }))
                      }
                      disabled={!canEdit}
                    />
                    <div>
                      <Label htmlFor={`slack-evt-${evt.key}`} className="cursor-pointer">
                        {evt.label}
                      </Label>
                      <p className="text-xs text-muted-foreground">{evt.hint}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button onClick={save} disabled={!canEdit || saving}>
                {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Save
              </Button>
              <Button
                variant="outline"
                onClick={test}
                disabled={!canEdit || testing || !row}
              >
                {testing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Send test message
              </Button>
              {row ? (
                <Button
                  variant="destructive"
                  onClick={disconnect}
                  disabled={!canEdit}
                  className="ml-auto"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Disconnect
                </Button>
              ) : null}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
