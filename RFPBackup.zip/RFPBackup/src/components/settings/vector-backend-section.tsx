"use client";

// Vector backend settings panel (Phase V).
//
// Lets admins:
//   1. Pick the vector store backend (Postgres default, Milvus opt-in).
//   2. Configure Milvus connection details (URI + API token + collection name +
//      isolation strategy). The token is write-only — once saved we render a
//      masked fingerprint, never the plaintext.
//   3. Test the connection before committing it (POST /test).
//   4. Toggle dual-write during a cutover (Postgres + Milvus on every upsert).
//   5. Trigger a backfill from Postgres → Milvus (POST /migrate).
//   6. Disconnect — wipes the Milvus fields and reverts to Postgres.
//
// Admin-only — the parent gates rendering, the API routes enforce.

import { useCallback, useEffect, useState } from "react";
import {
  Database,
  CheckCircle2,
  XCircle,
  Loader2,
  Trash2,
  PlugZap,
  ArrowRightLeft,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useConfirm } from "@/components/ui/confirm";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";

type Backend = "POSTGRES" | "MILVUS";
type Isolation = "partition" | "collection";

interface VectorConfig {
  vectorBackend: Backend;
  milvusUri: string | null;
  milvusTokenSet: boolean;
  milvusTokenMasked: string | null;
  milvusCollection: string | null;
  milvusIsolation: Isolation;
  vectorDualWrite: boolean;
  vectorMigratedAt: string | null;
}

interface TestResult {
  ok: boolean;
  ms: number;
  detail: string | null;
  error: string | null;
  vectorCount: number | null;
}

interface MigrateResult {
  ok: boolean;
  scanned: number;
  written: number;
  errors: number;
  durationMs: number;
}

const DEFAULT_COLLECTION = "autorfp_chunks";

export function VectorBackendSection({ orgId }: { orgId: string }) {
  const confirm = useConfirm();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [migrating, setMigrating] = useState(false);

  const [persisted, setPersisted] = useState<VectorConfig | null>(null);

  const [backend, setBackend] = useState<Backend>("POSTGRES");
  const [uri, setUri] = useState("");
  const [token, setToken] = useState("");
  const [collection, setCollection] = useState("");
  const [isolation, setIsolation] = useState<Isolation>("partition");
  const [dualWrite, setDualWrite] = useState(false);

  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [migrateResult, setMigrateResult] = useState<MigrateResult | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/vector`);
      if (!res.ok) {
        toast({ title: "Couldn't load vector backend configuration" });
        return;
      }
      const data = (await res.json()) as VectorConfig;
      setPersisted(data);
      setBackend(data.vectorBackend);
      setUri(data.milvusUri ?? "");
      setToken("");
      setCollection(data.milvusCollection ?? "");
      setIsolation(data.milvusIsolation);
      setDualWrite(data.vectorDualWrite);
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function save() {
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        vectorBackend: backend,
        milvusUri: uri.trim() || null,
        milvusCollection: collection.trim() || null,
        milvusIsolation: isolation,
        vectorDualWrite: dualWrite,
      };
      // Only include the token field when the user typed something — leaving
      // it out preserves the previously saved value. Empty-string is treated
      // as "no change". Pressing the explicit "Clear token" button below
      // sends `null` to wipe.
      if (token.trim()) body.milvusToken = token.trim();

      const res = await fetch(`/api/orgs/${orgId}/vector`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        toast({ title: "Saved", variant: "success" });
        setToken("");
        await refresh();
      } else {
        toast({
          title: "Couldn't save",
          description: (await res.json()).error,
        });
      }
    } finally {
      setSaving(false);
    }
  }

  async function clearToken() {
    if (!(await confirm("Future Milvus calls will be unauthenticated.", { title: "Clear the saved token?", destructive: true, confirmLabel: "Clear" }))) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/vector`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ milvusToken: null }),
      });
      if (res.ok) {
        toast({ title: "Token cleared", variant: "success" });
        await refresh();
      } else {
        toast({
          title: "Couldn't clear token",
          description: (await res.json()).error,
        });
      }
    } finally {
      setSaving(false);
    }
  }

  async function disconnect() {
    if (
      !confirm(
        "Revert to Postgres? The Milvus URI and token will be cleared. Existing Milvus data is left untouched.",
      )
    ) {
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/vector`, { method: "DELETE" });
      if (res.ok) {
        toast({ title: "Reverted to Postgres", variant: "success" });
        setTestResult(null);
        setMigrateResult(null);
        await refresh();
      } else {
        toast({
          title: "Couldn't disconnect",
          description: (await res.json()).error,
        });
      }
    } finally {
      setSaving(false);
    }
  }

  async function runTest() {
    if (!uri.trim()) {
      toast({ title: "Enter a Milvus URI first." });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const body: Record<string, unknown> = {
        uri: uri.trim(),
        collection: collection.trim() || undefined,
        isolation,
      };
      // Prefer the freshly-typed token; if the user hasn't entered one this
      // session, the route can still test the connection without auth (some
      // self-hosted Milvus clusters don't require it).
      if (token.trim()) body.token = token.trim();

      const res = await fetch(`/api/orgs/${orgId}/vector/test`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = (await res.json()) as TestResult;
      setTestResult(data);
      if (!data.ok) {
        toast({ title: "Connection failed", description: data.error ?? "" });
      } else {
        toast({ title: `Connected (${data.ms}ms)`, variant: "success" });
      }
    } catch (e) {
      setTestResult({
        ok: false,
        ms: 0,
        detail: null,
        error: e instanceof Error ? e.message : String(e),
        vectorCount: null,
      });
    } finally {
      setTesting(false);
    }
  }

  async function runMigrate(dryRun: boolean) {
    if (!persisted?.milvusUri) {
      toast({ title: "Save Milvus connection details first." });
      return;
    }
    if (
      !dryRun &&
      !confirm(
        "Backfill all Postgres-stored embeddings to Milvus? This may take several minutes for large indexes.",
      )
    ) {
      return;
    }
    setMigrating(true);
    setMigrateResult(null);
    try {
      const res = await fetch(`/api/orgs/${orgId}/vector/migrate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ dryRun }),
      });
      const data = (await res.json()) as MigrateResult;
      setMigrateResult(data);
      if (data.ok) {
        toast({
          title: dryRun
            ? `Dry-run: would write ${data.written} of ${data.scanned} chunks`
            : `Backfill complete: wrote ${data.written} chunks`,
          variant: "success",
        });
        if (!dryRun) await refresh();
      } else {
        toast({
          title: "Backfill had errors",
          description: `${data.errors} errors, ${data.written} ok`,
        });
      }
    } finally {
      setMigrating(false);
    }
  }

  const isMilvus = backend === "MILVUS";
  const persistedMilvus = persisted?.vectorBackend === "MILVUS";

  return (
    <Card id="vector-backend">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-4 w-4 text-primary" />
          Vector backend
          {persistedMilvus ? (
            <Badge variant="secondary">Milvus</Badge>
          ) : (
            <Badge variant="outline">Postgres</Badge>
          )}
          {persisted?.vectorMigratedAt ? (
            <Badge variant="secondary" title={persisted.vectorMigratedAt}>
              Migrated {new Date(persisted.vectorMigratedAt).toLocaleDateString()}
            </Badge>
          ) : persistedMilvus ? (
            <Badge variant="outline">Not migrated</Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          Postgres is the default — embeddings live in <code>DocumentChunk.embedding</code>.
          Switch to Milvus / Zilliz Cloud for production-scale vector search with native hybrid
          (dense + sparse) retrieval.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {loading ? (
          <div className="grid place-items-center py-6">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            {/* Backend picker */}
            <section>
              <Label className="text-sm font-medium">Backend</Label>
              <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
                <button
                  type="button"
                  onClick={() => setBackend("POSTGRES")}
                  className={`rounded-lg border p-3 text-left text-sm transition ${
                    backend === "POSTGRES"
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-accent"
                  }`}
                >
                  <div className="font-medium">Postgres (default)</div>
                  <div className="text-xs text-muted-foreground">
                    No external dependency. Uses cosine distance over the existing
                    embedding column. Great for orgs under ~1M chunks.
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setBackend("MILVUS")}
                  className={`rounded-lg border p-3 text-left text-sm transition ${
                    backend === "MILVUS"
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-accent"
                  }`}
                >
                  <div className="font-medium">Milvus / Zilliz Cloud</div>
                  <div className="text-xs text-muted-foreground">
                    Dedicated vector DB. HNSW + sparse hybrid search, partition-key tenant
                    isolation, scales horizontally.
                  </div>
                </button>
              </div>
            </section>

            {/* Milvus form */}
            {isMilvus ? (
              <section className="space-y-3 rounded-lg border bg-muted/20 p-4">
                <div>
                  <Label htmlFor="milvus-uri">Milvus URI</Label>
                  <Input
                    id="milvus-uri"
                    placeholder="https://<id>.api.gcp-us-west1.zillizcloud.com  •  http://localhost:19530"
                    value={uri}
                    onChange={(e) => setUri(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="milvus-token">
                    API token{" "}
                    {persisted?.milvusTokenSet ? (
                      <span className="text-xs font-normal text-muted-foreground">
                        (saved · {persisted.milvusTokenMasked} — leave blank to keep)
                      </span>
                    ) : (
                      <span className="text-xs font-normal text-muted-foreground">
                        (optional for unauthenticated self-hosted clusters)
                      </span>
                    )}
                  </Label>
                  <div className="flex gap-2">
                    <Input
                      id="milvus-token"
                      type="password"
                      placeholder={
                        persisted?.milvusTokenSet ? "•••• already saved ••••" : "username:password or API key"
                      }
                      value={token}
                      onChange={(e) => setToken(e.target.value)}
                      autoComplete="off"
                    />
                    {persisted?.milvusTokenSet ? (
                      <Button variant="ghost" onClick={() => void clearToken()} disabled={saving}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    ) : null}
                  </div>
                </div>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <div>
                    <Label htmlFor="milvus-collection">Collection name</Label>
                    <Input
                      id="milvus-collection"
                      placeholder={DEFAULT_COLLECTION}
                      value={collection}
                      onChange={(e) => setCollection(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="milvus-isolation">Tenant isolation</Label>
                    <Select
                      value={isolation}
                      onValueChange={(v) => setIsolation(v as Isolation)}
                    >
                      <SelectTrigger id="milvus-isolation">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="partition">Partition per org (recommended)</SelectItem>
                        <SelectItem value="collection">Collection per org (stronger)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Test */}
                <div className="flex flex-wrap items-center gap-2 pt-2">
                  <Button
                    variant="outline"
                    onClick={() => void runTest()}
                    disabled={testing}
                  >
                    {testing ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <PlugZap className="mr-2 h-4 w-4" />
                    )}
                    Test connection
                  </Button>
                  {testResult ? (
                    <span className="inline-flex items-center gap-1 text-sm">
                      {testResult.ok ? (
                        <>
                          <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                          <span className="text-emerald-700">
                            ok · {testResult.ms}ms
                            {testResult.vectorCount != null
                              ? ` · ${testResult.vectorCount} vectors`
                              : ""}
                          </span>
                        </>
                      ) : (
                        <>
                          <XCircle className="h-4 w-4 text-destructive" />
                          <span className="text-destructive">
                            {testResult.error ?? "failed"}
                          </span>
                        </>
                      )}
                    </span>
                  ) : null}
                </div>

                {/* Dual-write */}
                <div className="rounded-md border bg-background p-3">
                  <label className="flex cursor-pointer items-start gap-3">
                    <Checkbox
                      checked={dualWrite}
                      onCheckedChange={(v) => setDualWrite(Boolean(v))}
                      id="dual-write"
                    />
                    <div className="space-y-1 text-sm">
                      <div className="font-medium">Dual-write during cutover</div>
                      <p className="text-xs text-muted-foreground">
                        Writes go to BOTH Postgres and Milvus. Reads continue from the selected
                        backend. Recommended playbook: enable dual-write → run backfill → flip
                        backend to Milvus → verify retrieval quality → disable dual-write.
                      </p>
                    </div>
                  </label>
                </div>

                {/* Save */}
                <div className="flex flex-wrap gap-2 pt-2">
                  <Button onClick={() => void save()} disabled={saving}>
                    {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                    Save
                  </Button>
                  {persistedMilvus ? (
                    <Button
                      variant="ghost"
                      onClick={() => void disconnect()}
                      disabled={saving}
                    >
                      <Trash2 className="mr-2 h-4 w-4 text-destructive" />
                      Disconnect (revert to Postgres)
                    </Button>
                  ) : null}
                </div>

                {/* Migrate */}
                {persistedMilvus ? (
                  <section className="rounded-md border bg-background p-3">
                    <div className="mb-2 flex items-center gap-2 text-sm font-medium">
                      <ArrowRightLeft className="h-4 w-4 text-primary" />
                      Backfill from Postgres
                    </div>
                    <p className="mb-3 text-xs text-muted-foreground">
                      Copies every chunk&apos;s embedding from Postgres into Milvus. Idempotent —
                      safe to re-run. Run a dry-run first to preview the chunk count without
                      writing anything.
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <Button
                        variant="outline"
                        onClick={() => void runMigrate(true)}
                        disabled={migrating}
                      >
                        {migrating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Dry-run
                      </Button>
                      <Button onClick={() => void runMigrate(false)} disabled={migrating}>
                        {migrating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Backfill now
                      </Button>
                      {migrateResult ? (
                        <span className="text-sm text-muted-foreground">
                          scanned={migrateResult.scanned} · written={migrateResult.written} ·
                          errors={migrateResult.errors} · {migrateResult.durationMs}ms
                        </span>
                      ) : null}
                    </div>
                  </section>
                ) : null}
              </section>
            ) : (
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => void save()} disabled={saving || !persistedMilvus}>
                  {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Save (revert to Postgres)
                </Button>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
