"use client";

// RAG Provider settings panel (Phase D).
//
// Lets admins replace the entire internal retrieval pipeline with an external
// service that owns hybrid search + reranking + (optionally) augmentation.
// MVP supports a generic JSON contract — Vectara / Azure AI Search /
// Pinecone Assistants presets land as Phase D.2.
//
// Generic external HTTP contract:
//   POST {endpoint}
//   Body:  {query, topK, indexId, orgId}
//   200:   {chunks: [{id, content, documentName?, fileName?, page?, score?}]}

import { useCallback, useEffect, useState } from "react";
import {
  Globe2,
  Loader2,
  ChevronDown,
  ChevronRight,
  Save,
  RotateCcw,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const KEEP_EXISTING_SECRET = "__KEEP__";

type Kind = "INTERNAL" | "EXTERNAL_HTTP";

interface RagProviderConfig {
  kind: Kind;
  endpoint: string;
  apiKey: string;
  /** Edited as JSON-encoded string in the textarea, parsed on save. */
  extraHeadersJson: string;
}

interface Props {
  orgId: string;
  canEdit: boolean;
}

const DEFAULTS: RagProviderConfig = {
  kind: "INTERNAL",
  endpoint: "",
  apiKey: "",
  extraHeadersJson: "",
};

export function RagProviderSection({ orgId, canEdit }: Props) {
  const [config, setConfig] = useState<RagProviderConfig>(DEFAULTS);
  const [initial, setInitial] = useState<RagProviderConfig>(DEFAULTS);
  const [hasKey, setHasKey] = useState(false);
  const [keyMasked, setKeyMasked] = useState("");
  const [source, setSource] = useState<"org" | "default">("default");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [advanced, setAdvanced] = useState(false);
  const [headersError, setHeadersError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`);
      if (!res.ok) return;
      const body = await res.json();
      const r = body.config?.ragProvider;
      if (r) {
        setHasKey(Boolean(r.hasApiKey));
        setKeyMasked(r.apiKeyMasked ?? "");
        const next: RagProviderConfig = {
          kind: (r.kind ?? "INTERNAL") as Kind,
          endpoint: r.endpoint ?? "",
          apiKey: r.hasApiKey ? KEEP_EXISTING_SECRET : "",
          extraHeadersJson:
            r.extraHeaders && Object.keys(r.extraHeaders).length > 0
              ? JSON.stringify(r.extraHeaders, null, 2)
              : "",
        };
        setConfig(next);
        setInitial(next);
      }
      setSource(body.config?.source?.ragProvider ?? "default");
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void load();
  }, [load]);

  const dirty = JSON.stringify(config) !== JSON.stringify(initial);
  const needsExternalFields = config.kind !== "INTERNAL";

  function parseHeaders(): Record<string, string> | null {
    const trimmed = config.extraHeadersJson.trim();
    if (!trimmed) return {};
    try {
      const parsed = JSON.parse(trimmed);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
        setHeadersError("Headers must be a JSON object of string→string");
        return null;
      }
      const out: Record<string, string> = {};
      for (const [k, v] of Object.entries(parsed)) {
        if (typeof v !== "string") {
          setHeadersError(`Header "${k}" must be a string (got ${typeof v})`);
          return null;
        }
        out[k] = v;
      }
      setHeadersError(null);
      return out;
    } catch (e) {
      setHeadersError(`Invalid JSON: ${e instanceof Error ? e.message : "parse error"}`);
      return null;
    }
  }

  async function save() {
    const headers = parseHeaders();
    if (headers === null) return;
    if (needsExternalFields && !config.endpoint.trim()) {
      toast({ title: "Endpoint URL is required for external providers" });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ragProvider: {
            kind: config.kind,
            endpoint: config.endpoint.trim() === "" ? null : config.endpoint.trim(),
            apiKey: config.apiKey,
            extraHeaders: headers,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error });
        return;
      }
      toast({ title: "RAG provider saved", variant: "success" });
      await load();
      setSource(config.kind === "INTERNAL" ? "default" : "org");
    } finally {
      setSaving(false);
    }
  }

  async function resetToDefaults() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ragProvider: { kind: "INTERNAL", endpoint: null, apiKey: null, extraHeaders: {} },
        }),
      });
      if (!res.ok) return;
      toast({ title: "Reset to internal RAG", variant: "success" });
      setConfig(DEFAULTS);
      setInitial(DEFAULTS);
      setHasKey(false);
      setKeyMasked("");
      setSource("default");
      await load();
    } finally {
      setSaving(false);
    }
  }

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  async function testConnection() {
    if (!needsExternalFields || !config.endpoint.trim()) {
      setTestResult({ ok: false, message: "Set endpoint first" });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      // Reuses the save endpoint with a `?test=1` flag — handled below.
      const res = await fetch(`/api/orgs/${orgId}/ai-config/rag-test`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          endpoint: config.endpoint.trim(),
          apiKey: config.apiKey === KEEP_EXISTING_SECRET ? null : config.apiKey,
          extraHeaders: parseHeaders() ?? {},
        }),
      });
      const body = await res.json().catch(() => ({}));
      setTestResult({ ok: !!body.ok, message: body.message ?? `HTTP ${res.status}` });
    } finally {
      setTesting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Globe2 className="h-4 w-4" />
              RAG Provider
              <Badge variant={source === "org" ? "info" : "outline"} className="ml-1 text-[10px]">
                {source === "org" ? "External" : "Internal (default)"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Use this app&apos;s built-in hybrid retrieval, or delegate retrieval to an
              external service (Vectara, Azure AI Search, Pinecone Assistants, your own
              endpoint). External mode skips our reranker + contextual retrieval — the
              remote service owns those concerns.
            </CardDescription>
          </div>
          {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-1.5">
          <Label className="text-xs">Provider mode</Label>
          <Select
            value={config.kind}
            onValueChange={(v) => setConfig({ ...config, kind: v as Kind })}
            disabled={!canEdit || loading}
          >
            <SelectTrigger className="h-9 max-w-md"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="INTERNAL">Internal (default) — hybrid + cross-encoder</SelectItem>
              <SelectItem value="EXTERNAL_HTTP">External HTTP — generic JSON contract</SelectItem>
            </SelectContent>
          </Select>
          {needsExternalFields ? (
            <p className="flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-700 dark:text-amber-300">
              <AlertTriangle className="h-3 w-3 shrink-0" />
              External mode skips internal reranker + contextual retrieval. Vectara / Azure / Pinecone preset adapters arrive in Phase D.2 — until then, stand up a thin proxy that honors the contract below.
            </p>
          ) : null}
        </div>

        {needsExternalFields ? (
          <>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="rag-endpoint">Endpoint URL</Label>
                <Input
                  id="rag-endpoint"
                  type="url"
                  value={config.endpoint}
                  onChange={(e) => setConfig({ ...config, endpoint: e.target.value })}
                  disabled={!canEdit || loading}
                  placeholder="https://rag.example.com/v1/query"
                  className="h-9 font-mono text-xs"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="rag-key">API key (sent as Bearer)</Label>
                <Input
                  id="rag-key"
                  type="password"
                  value={config.apiKey === KEEP_EXISTING_SECRET ? keyMasked : config.apiKey}
                  onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                  disabled={!canEdit || loading}
                  placeholder={hasKey ? "Key stored (paste to replace)" : "Optional"}
                  className="h-9 font-mono text-xs"
                />
              </div>
            </div>

            <div className="rounded-lg border bg-muted/20">
              <button
                type="button"
                onClick={() => setAdvanced((v) => !v)}
                className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:bg-muted/40"
                aria-expanded={advanced}
              >
                <span className="flex items-center gap-1.5">
                  {advanced ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                  Advanced — custom headers + request shape
                </span>
                <span className="text-[10px] uppercase tracking-wider opacity-70">{advanced ? "Hide" : "Show"}</span>
              </button>
              {advanced ? (
                <div className="space-y-4 border-t px-3 py-3">
                  <div className="space-y-1.5">
                    <Label className="text-xs" htmlFor="rag-headers">Extra headers (JSON object, string→string)</Label>
                    <Textarea
                      id="rag-headers"
                      value={config.extraHeadersJson}
                      onChange={(e) => setConfig({ ...config, extraHeadersJson: e.target.value })}
                      disabled={!canEdit || loading}
                      rows={4}
                      placeholder={`{\n  "x-customer-id": "abc",\n  "x-corpus": "rfp-2026"\n}`}
                      className="font-mono text-xs"
                    />
                    {headersError ? (
                      <p className="text-[11px] text-destructive">{headersError}</p>
                    ) : (
                      <p className="text-[11px] text-muted-foreground">
                        Merged into the request. <code>Authorization: Bearer &lt;key&gt;</code> is added automatically.
                      </p>
                    )}
                  </div>

                  <details className="rounded-md border bg-background/60 p-3 text-[11px]">
                    <summary className="cursor-pointer font-medium text-foreground">Request / response contract</summary>
                    <pre className="mt-2 overflow-x-auto whitespace-pre text-[10px] text-muted-foreground">{`POST {endpoint}
  Authorization: Bearer {apiKey}        (when set)
  Content-Type: application/json
  ... + extraHeaders

  { "query": "...", "topK": 8, "indexId": "...", "orgId": "..." }

200 OK
  { "chunks": [
      {
        "id":           "string (required, unique)",
        "content":      "string (required)",
        "documentId":   "string (optional)",
        "documentName": "string (optional)",
        "fileName":     "string (optional)",
        "page":         "number | null (optional)",
        "score":        "number (optional, default 0.5)"
      }
    ]
  }`}</pre>
                  </details>
                </div>
              ) : null}
            </div>

            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={testConnection}
                disabled={!canEdit || testing || !config.endpoint.trim()}
              >
                {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                Test connection
              </Button>
              {testResult ? (
                <span className={cn(
                  "text-[11px]",
                  testResult.ok ? "text-emerald-600 dark:text-emerald-300" : "text-destructive",
                )}>
                  {testResult.ok ? "✓" : "✗"} {testResult.message}
                </span>
              ) : null}
            </div>
          </>
        ) : null}

        {canEdit ? (
          <div className="flex items-center justify-end gap-2 pt-1">
            <Button variant="ghost" size="sm" onClick={resetToDefaults} disabled={saving || source === "default"}>
              <RotateCcw className="h-3.5 w-3.5" /> Reset to internal
            </Button>
            <Button variant="gradient" size="sm" onClick={save} disabled={saving || !dirty}>
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Save changes
            </Button>
          </div>
        ) : (
          <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3" /> Read-only — ADMIN or OWNER role required.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
