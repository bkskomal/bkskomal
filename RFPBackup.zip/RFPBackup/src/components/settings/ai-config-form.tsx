"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Sparkles,
  Search,
  Wrench,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Eye,
  EyeOff,
  ExternalLink,
  RotateCcw,
  Save,
  Zap,
  PlugZap,
  KeyRound,
  Cpu,
  Cloud,
  Download,
  Route,
} from "lucide-react";
import { AiProvider } from "@prisma/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useConfirm } from "@/components/ui/confirm";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const KEEP = "__KEEP__";

interface ProviderInfo {
  id: AiProvider;
  shortId: string;
  label: string;
  llmBaseUrl: string;
  embeddingBaseUrl?: string;
  llmModels: string[];
  embeddingModels?: Array<{ name: string; dimensions: number }>;
  keyHint?: string;
  keyUrl?: string;
  hasEmbeddings: boolean;
  hasModelsApi: boolean;
  isLocal: boolean;
  requiresApiKey: boolean;
  notes?: string;
}

interface ConfigState {
  llm: {
    provider: AiProvider | null;
    baseUrl: string;
    apiKey: string; // KEEP sentinel or new value
    model: string;
    httpReferer: string;
    appTitle: string;
    apiKeyMasked: string;
    hasApiKey: boolean;
  };
  embedding: {
    provider: AiProvider | null;
    baseUrl: string;
    apiKey: string;
    model: string;
    dimensions: number;
    apiKeyMasked: string;
    hasApiKey: boolean;
  };
  llamaparse: {
    enabled: boolean;
    apiKey: string;
    resultType: "text" | "markdown";
    apiKeyMasked: string;
    hasApiKey: boolean;
  };
  // Model routing (Phase 3B). When enabled, simple/complex questions route
  // to per-tier models; moderate (or no complexity) falls back to llm.model.
  routing: {
    enabled: boolean;
    modelSimple: string;
    modelComplex: string;
  };
  source: {
    llmBaseUrl: "org" | "env";
    llmApiKey: "org" | "env";
    llmModel: "org" | "env";
    embeddingBaseUrl: "org" | "env";
    embeddingApiKey: "org" | "env";
    embeddingModel: "org" | "env";
    embeddingDimensions: "org" | "env";
    llamaparse: "org" | "env";
  };
}

interface Props {
  orgId: string;
  canEdit: boolean;
  initial: ConfigState;
  providers: ProviderInfo[];
}

type TestState =
  | { state: "idle" }
  | { state: "loading" }
  | { state: "ok"; message: string }
  | { state: "error"; message: string };

export function AiConfigForm({ orgId, canEdit, initial, providers }: Props) {
  const confirm = useConfirm();
  const [state, setState] = useState<ConfigState>(initial);
  const [saving, setSaving] = useState(false);
  const [llmTest, setLlmTest] = useState<TestState>({ state: "idle" });
  const [embTest, setEmbTest] = useState<TestState>({ state: "idle" });
  const [showLlmKey, setShowLlmKey] = useState(false);
  const [showEmbKey, setShowEmbKey] = useState(false);
  const [llmModels, setLlmModels] = useState<string[]>([]);
  const [embModels, setEmbModels] = useState<string[]>([]);
  const [loadingLlmModels, setLoadingLlmModels] = useState(false);
  const [loadingEmbModels, setLoadingEmbModels] = useState(false);
  // Ollama-specific picker state: list of locally-installed models (so we can
  // show "Pull" buttons for recommended models that aren't installed yet)
  // and the in-flight pull, if any.
  const [ollamaInstalled, setOllamaInstalled] = useState<string[] | null>(null);
  const [pullingModel, setPullingModel] = useState<string | null>(null);
  const [pullProgress, setPullProgress] = useState<number>(0);

  const providerById = useMemo(
    () => Object.fromEntries(providers.map((p) => [p.id, p])) as Record<AiProvider, ProviderInfo>,
    [providers],
  );

  // When the LLM provider is Ollama, pre-load the installed model list so
  // the picker can show "Pull" buttons for recommended-but-not-installed
  // models. We refetch whenever the base URL changes so the user can point
  // at a remote daemon and see its inventory.
  useEffect(() => {
    if (state.llm.provider !== "OLLAMA") {
      setOllamaInstalled(null);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const url = `/api/orgs/${orgId}/ai-config/models?provider=ollama&baseUrl=${encodeURIComponent(state.llm.baseUrl)}`;
        const res = await fetch(url);
        const data = await res.json();
        if (cancelled) return;
        if (data?.ok && Array.isArray(data.models)) {
          // GET response shape returns objects {name,sizeBytes,modifiedAt}.
          const names = data.models
            .map((m: { name?: string } | string) =>
              typeof m === "string" ? m : String(m?.name ?? ""),
            )
            .filter((s: string) => s.length > 0);
          setOllamaInstalled(names);
        } else {
          setOllamaInstalled([]);
        }
      } catch {
        if (!cancelled) setOllamaInstalled([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [state.llm.provider, state.llm.baseUrl, orgId]);

  async function pullOllama(name: string) {
    setPullingModel(name);
    setPullProgress(0);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config/models/pull`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ baseUrl: state.llm.baseUrl, name }),
      });
      if (!res.ok || !res.body) {
        toast({ title: "Pull failed", description: `HTTP ${res.status}` });
        return;
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        // SSE frames are separated by a blank line. Each frame has lines like
        // "event: progress" and "data: {...}".
        let sep: number;
        while ((sep = buffer.indexOf("\n\n")) >= 0) {
          const frame = buffer.slice(0, sep);
          buffer = buffer.slice(sep + 2);
          let eventName = "message";
          let dataLine = "";
          for (const line of frame.split("\n")) {
            if (line.startsWith("event:")) eventName = line.slice(6).trim();
            else if (line.startsWith("data:")) dataLine = line.slice(5).trim();
          }
          if (eventName === "progress" && dataLine) {
            try {
              const obj = JSON.parse(dataLine);
              if (typeof obj.pct === "number") setPullProgress(obj.pct);
            } catch {
              // ignore malformed frame
            }
          } else if (eventName === "error") {
            toast({ title: "Pull failed", description: dataLine });
          } else if (eventName === "done") {
            toast({ title: `Pulled ${name}`, variant: "success" });
            setOllamaInstalled((prev) => (prev ? [...new Set([...prev, name])] : [name]));
          }
        }
      }
    } catch (e) {
      toast({ title: "Pull failed", description: e instanceof Error ? e.message : String(e) });
    } finally {
      setPullingModel(null);
      setPullProgress(0);
    }
  }
  const llmPreset = state.llm.provider ? providerById[state.llm.provider] : undefined;
  const embPreset = state.embedding.provider ? providerById[state.embedding.provider] : undefined;

  function applyLlmProvider(p: AiProvider) {
    const preset = providerById[p];
    setState((s) => ({
      ...s,
      llm: {
        ...s.llm,
        provider: p,
        baseUrl: preset.llmBaseUrl,
        model: preset.llmModels[0] ?? s.llm.model,
        // Keep existing key by default — user can change.
      },
    }));
    setLlmTest({ state: "idle" });
    setLlmModels([]);
  }

  function applyEmbProvider(p: AiProvider) {
    const preset = providerById[p];
    setState((s) => ({
      ...s,
      embedding: {
        ...s.embedding,
        provider: p,
        baseUrl: preset.embeddingBaseUrl ?? preset.llmBaseUrl,
        model: preset.embeddingModels?.[0]?.name ?? s.embedding.model,
        dimensions: preset.embeddingModels?.[0]?.dimensions ?? s.embedding.dimensions,
      },
    }));
    setEmbTest({ state: "idle" });
    setEmbModels([]);
  }

  async function fetchModels(target: "llm" | "embedding") {
    const setLoading = target === "llm" ? setLoadingLlmModels : setLoadingEmbModels;
    const setList = target === "llm" ? setLlmModels : setEmbModels;
    const cfg = target === "llm" ? state.llm : state.embedding;
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config/models`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          target,
          baseUrl: cfg.baseUrl,
          apiKey: cfg.apiKey,
        }),
      });
      const data = await res.json();
      if (data.ok && Array.isArray(data.models)) {
        setList(data.models);
        toast({ title: `Loaded ${data.models.length} models`, variant: "success" });
      } else {
        toast({ title: "Couldn't fetch models", description: data.error });
      }
    } finally {
      setLoading(false);
    }
  }

  async function test(target: "llm" | "embedding") {
    const setT = target === "llm" ? setLlmTest : setEmbTest;
    const cfg = target === "llm" ? state.llm : state.embedding;
    setT({ state: "loading" });
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config/test`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          target,
          baseUrl: cfg.baseUrl,
          apiKey: cfg.apiKey,
          model: cfg.model,
          httpReferer: state.llm.httpReferer,
          appTitle: state.llm.appTitle,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setT({
          state: "ok",
          message:
            target === "llm"
              ? `OK · ${data.elapsedMs}ms · "${(data.sample ?? "").trim()}"`
              : `OK · ${data.elapsedMs}ms · ${data.dimensions}-dim vector`,
        });
      } else {
        setT({ state: "error", message: data.error ?? "Unknown error" });
      }
    } catch (e) {
      setT({ state: "error", message: e instanceof Error ? e.message : String(e) });
    }
  }

  async function save() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          llm: {
            provider: state.llm.provider,
            baseUrl: state.llm.baseUrl || null,
            apiKey: state.llm.apiKey,
            model: state.llm.model || null,
            httpReferer: state.llm.httpReferer || null,
            appTitle: state.llm.appTitle || null,
          },
          embedding: {
            provider: state.embedding.provider,
            baseUrl: state.embedding.baseUrl || null,
            apiKey: state.embedding.apiKey,
            model: state.embedding.model || null,
            dimensions: state.embedding.dimensions,
          },
          llamaparse: {
            enabled: state.llamaparse.enabled,
            apiKey: state.llamaparse.apiKey,
            resultType: state.llamaparse.resultType,
          },
          routing: {
            enabled: state.routing.enabled,
            // Empty string → null on the backend → clears the override.
            modelSimple: state.routing.modelSimple || null,
            modelComplex: state.routing.modelComplex || null,
          },
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        toast({ title: "Couldn't save", description: err.error ?? err.details });
      } else {
        toast({ title: "AI configuration saved", variant: "success" });
        // After save the keys are now stored — switch back to KEEP sentinel
        // so we don't accidentally re-save them on next edit.
        setState((s) => ({
          ...s,
          llm: { ...s.llm, apiKey: KEEP, hasApiKey: s.llm.apiKey !== "" || s.llm.hasApiKey },
          embedding: {
            ...s.embedding,
            apiKey: KEEP,
            hasApiKey: s.embedding.apiKey !== "" || s.embedding.hasApiKey,
          },
          llamaparse: {
            ...s.llamaparse,
            apiKey: KEEP,
            hasApiKey: s.llamaparse.apiKey !== "" || s.llamaparse.hasApiKey,
          },
        }));
      }
    } finally {
      setSaving(false);
    }
  }

  async function resetToEnv() {
    if (!(await confirm("Reset AI config back to environment defaults?", { destructive: true, confirmLabel: "Reset" }))) return;
    const res = await fetch(`/api/orgs/${orgId}/ai-config`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Reset to environment defaults", variant: "success" });
      window.location.reload();
    }
  }

  return (
    <div className="space-y-6">
      {/* Provider picker — quick-switch row of cards. Selecting a card
          fills the LLM section's base URL + a sensible default model and
          (for Ollama) surfaces the local model picker. */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-4 w-4 text-primary" /> Quick provider picker
          </CardTitle>
          <CardDescription>
            Pick where OATI AutoRFP should send chat requests. Local providers run on this machine and
            need no API key — ideal for development.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2 sm:grid-cols-3 lg:grid-cols-4">
            {providers.map((p) => {
              const selected = state.llm.provider === p.id;
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => canEdit && applyLlmProvider(p.id)}
                  disabled={!canEdit}
                  className={cn(
                    "flex flex-col items-start gap-1 rounded-lg border p-3 text-left transition",
                    selected
                      ? "border-primary bg-primary/5 ring-1 ring-primary"
                      : "hover:border-muted-foreground/50",
                    !canEdit && "opacity-60",
                  )}
                >
                  <div className="flex w-full items-center justify-between">
                    <span className="text-sm font-medium">{p.label.replace(" (self-hosted)", "")}</span>
                    {p.isLocal ? (
                      <Cpu className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                    ) : (
                      <Cloud className="h-3.5 w-3.5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {p.isLocal ? (
                      <Badge variant="success" className="text-[10px]">
                        Local
                      </Badge>
                    ) : null}
                    {!p.requiresApiKey ? (
                      <Badge variant="outline" className="text-[10px]">
                        No API key
                      </Badge>
                    ) : null}
                    {p.id === "OLLAMA" ? (
                      <Badge variant="info" className="text-[10px]">
                        Recommended
                      </Badge>
                    ) : null}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Ollama-specific helper: show recommended models with install state
              + a Pull button for anything missing locally. */}
          {state.llm.provider === "OLLAMA" && llmPreset ? (
            <div className="mt-4 rounded-md border bg-muted/30 p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Recommended Ollama models
                </span>
                {ollamaInstalled === null ? (
                  <span className="text-[11px] text-muted-foreground">
                    <Loader2 className="inline h-3 w-3 animate-spin" /> Probing…
                  </span>
                ) : (
                  <span className="text-[11px] text-muted-foreground">
                    {ollamaInstalled.length} installed
                  </span>
                )}
              </div>
              <ul className="space-y-1">
                {llmPreset.llmModels.slice(0, 6).map((m) => {
                  const installed = ollamaInstalled?.includes(m) ?? false;
                  const isPulling = pullingModel === m;
                  return (
                    <li
                      key={m}
                      className="flex items-center justify-between gap-2 rounded px-2 py-1 text-xs"
                    >
                      <span className="font-mono">{m}</span>
                      <div className="flex items-center gap-2">
                        {state.llm.model === m ? (
                          <Badge variant="info" className="text-[10px]">
                            Selected
                          </Badge>
                        ) : null}
                        {installed ? (
                          <span className="inline-flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="h-3 w-3" /> installed
                          </span>
                        ) : isPulling ? (
                          <span className="text-muted-foreground">
                            <Loader2 className="inline h-3 w-3 animate-spin" />{" "}
                            {Math.round(pullProgress * 100)}%
                          </span>
                        ) : (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => pullOllama(m)}
                            disabled={!canEdit || pullingModel !== null}
                            className="h-6 px-2 text-[11px]"
                          >
                            <Download className="h-3 w-3" /> Pull
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            setState((s) => ({ ...s, llm: { ...s.llm, model: m } }))
                          }
                          disabled={!canEdit}
                          className="h-6 px-2 text-[11px]"
                        >
                          Use
                        </Button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            </div>
          ) : null}
        </CardContent>
      </Card>

      {/* LLM */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                Language model
              </CardTitle>
              <CardDescription>
                Used for question extraction, response generation, chat, and reranking.
              </CardDescription>
            </div>
            <Badge variant="info">
              {state.llm.provider ?? "Unset"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Provider" source={state.source.llmBaseUrl}>
              <Select
                value={state.llm.provider ?? ""}
                onValueChange={(v) => applyLlmProvider(v as AiProvider)}
                disabled={!canEdit}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pick a provider" />
                </SelectTrigger>
                <SelectContent>
                  {providers.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Endpoint URL" source={state.source.llmBaseUrl}>
              <Input
                value={state.llm.baseUrl}
                onChange={(e) => setState((s) => ({ ...s, llm: { ...s.llm, baseUrl: e.target.value } }))}
                placeholder="https://api.example.com/v1"
                disabled={!canEdit}
              />
            </Field>
          </div>

          <Field label="API key" source={state.source.llmApiKey}>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showLlmKey ? "text" : "password"}
                  value={state.llm.apiKey === KEEP ? state.llm.apiKeyMasked : state.llm.apiKey}
                  onChange={(e) =>
                    setState((s) => ({ ...s, llm: { ...s.llm, apiKey: e.target.value } }))
                  }
                  placeholder={llmPreset?.keyHint ?? "API key"}
                  disabled={!canEdit}
                  className="pr-9 font-mono text-xs"
                />
                <button
                  type="button"
                  onClick={() => setShowLlmKey((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showLlmKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              {state.llm.hasApiKey ? (
                <RotateKeyButton
                  orgId={orgId}
                  target="llm"
                  canEdit={canEdit}
                  onRotated={() =>
                    setState((s) => ({
                      ...s,
                      llm: { ...s.llm, apiKey: KEEP, hasApiKey: true },
                    }))
                  }
                />
              ) : null}
              {llmPreset?.keyUrl ? (
                <Button asChild variant="outline" size="sm">
                  <a href={llmPreset.keyUrl} target="_blank" rel="noreferrer">
                    Get key <ExternalLink className="h-3 w-3" />
                  </a>
                </Button>
              ) : null}
            </div>
            {state.llm.hasApiKey && state.llm.apiKey === KEEP ? (
              <p className="mt-1 text-[11px] text-muted-foreground">
                A key is saved. Type a new value to replace, or leave as-is.
              </p>
            ) : null}
          </Field>

          <Field label="Model" source={state.source.llmModel}>
            <div className="flex gap-2">
              <div className="flex-1">
                <ModelInput
                  value={state.llm.model}
                  onChange={(v) => setState((s) => ({ ...s, llm: { ...s.llm, model: v } }))}
                  suggestions={llmModels.length > 0 ? llmModels : llmPreset?.llmModels ?? []}
                  disabled={!canEdit}
                />
              </div>
              {llmPreset?.hasModelsApi ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fetchModels("llm")}
                  disabled={loadingLlmModels || !canEdit}
                  title="Fetch live model list from this endpoint"
                >
                  {loadingLlmModels ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Search className="h-3.5 w-3.5" />
                  )}
                  List
                </Button>
              ) : null}
            </div>
          </Field>

          <details className="text-xs">
            <summary className="cursor-pointer text-muted-foreground">Advanced (analytics headers)</summary>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field label="HTTP-Referer" source={state.source.llmBaseUrl}>
                <Input
                  value={state.llm.httpReferer}
                  onChange={(e) =>
                    setState((s) => ({ ...s, llm: { ...s.llm, httpReferer: e.target.value } }))
                  }
                  disabled={!canEdit}
                  placeholder="https://your-app.example.com"
                />
              </Field>
              <Field label="X-Title" source={state.source.llmBaseUrl}>
                <Input
                  value={state.llm.appTitle}
                  onChange={(e) =>
                    setState((s) => ({ ...s, llm: { ...s.llm, appTitle: e.target.value } }))
                  }
                  disabled={!canEdit}
                  placeholder="AutoRFP"
                />
              </Field>
            </div>
          </details>

          {llmPreset?.notes ? (
            <p className="text-xs text-muted-foreground">{llmPreset.notes}</p>
          ) : null}

          <div className="flex items-center justify-between border-t pt-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => test("llm")}
              disabled={!canEdit || llmTest.state === "loading"}
            >
              {llmTest.state === "loading" ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <PlugZap className="h-3.5 w-3.5" />
              )}
              Test connection
            </Button>
            <TestResultBadge t={llmTest} />
          </div>
        </CardContent>
      </Card>

      {/* Model routing (Phase 3B). Routes by question complexity — simple
          questions go to a cheap model, complex to a premium one. Standard
          model (the one configured above) is used for moderate questions and
          as fallback when either override is left blank. */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Route className="h-4 w-4 text-primary" />
                Model routing
              </CardTitle>
              <CardDescription>
                Routes by question complexity. ~60% cost reduction with no quality loss on routed
                sets.
              </CardDescription>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={state.routing.enabled}
                onChange={(e) =>
                  setState((s) => ({ ...s, routing: { ...s.routing, enabled: e.target.checked } }))
                }
                disabled={!canEdit}
                className="h-4 w-4"
              />
              Enable model routing
            </label>
          </div>
        </CardHeader>
        {state.routing.enabled ? (
          <CardContent className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="Simple model">
                <ModelInput
                  value={state.routing.modelSimple}
                  onChange={(v) =>
                    setState((s) => ({ ...s, routing: { ...s.routing, modelSimple: v } }))
                  }
                  suggestions={
                    llmModels.length > 0 ? llmModels : llmPreset?.llmModels ?? []
                  }
                  disabled={!canEdit}
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Cheap model for &quot;simple&quot; questions. Falls back to the standard model when blank.
                  e.g. <span className="font-mono">llama3.2:3b</span> or{" "}
                  <span className="font-mono">gpt-4o-mini</span>.
                </p>
              </Field>
              <Field label="Standard model">
                <Input
                  value={state.llm.model}
                  readOnly
                  disabled
                  className="font-mono text-xs opacity-75"
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Used for &quot;moderate&quot; questions and as a fallback. Configure above.
                </p>
              </Field>
              <Field label="Complex model">
                <ModelInput
                  value={state.routing.modelComplex}
                  onChange={(v) =>
                    setState((s) => ({ ...s, routing: { ...s.routing, modelComplex: v } }))
                  }
                  suggestions={
                    llmModels.length > 0 ? llmModels : llmPreset?.llmModels ?? []
                  }
                  disabled={!canEdit}
                />
                <p className="mt-1 text-[11px] text-muted-foreground">
                  Premium model for &quot;complex&quot; questions. Falls back to the standard model when
                  blank. e.g. <span className="font-mono">llama3.3:70b</span> or{" "}
                  <span className="font-mono">gpt-4o</span>.
                </p>
              </Field>
            </div>
          </CardContent>
        ) : null}
      </Card>

      {/* Embedding */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-4 w-4 text-primary" />
                Embeddings
              </CardTitle>
              <CardDescription>
                Used to index knowledge-base documents and to search them semantically.
              </CardDescription>
            </div>
            <Badge variant="info">
              {state.embedding.provider ?? "Unset"}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Provider" source={state.source.embeddingBaseUrl}>
              <Select
                value={state.embedding.provider ?? ""}
                onValueChange={(v) => applyEmbProvider(v as AiProvider)}
                disabled={!canEdit}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Pick a provider" />
                </SelectTrigger>
                <SelectContent>
                  {providers
                    .filter((p) => p.hasEmbeddings || p.id === "CUSTOM")
                    .map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.label}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Endpoint URL" source={state.source.embeddingBaseUrl}>
              <Input
                value={state.embedding.baseUrl}
                onChange={(e) =>
                  setState((s) => ({ ...s, embedding: { ...s.embedding, baseUrl: e.target.value } }))
                }
                disabled={!canEdit}
              />
            </Field>
          </div>

          <Field label="API key" source={state.source.embeddingApiKey}>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showEmbKey ? "text" : "password"}
                  value={state.embedding.apiKey === KEEP ? state.embedding.apiKeyMasked : state.embedding.apiKey}
                  onChange={(e) =>
                    setState((s) => ({ ...s, embedding: { ...s.embedding, apiKey: e.target.value } }))
                  }
                  disabled={!canEdit}
                  className="pr-9 font-mono text-xs"
                  placeholder={embPreset?.keyHint ?? "API key"}
                />
                <button
                  type="button"
                  onClick={() => setShowEmbKey((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showEmbKey ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              {state.embedding.hasApiKey ? (
                <RotateKeyButton
                  orgId={orgId}
                  target="embedding"
                  canEdit={canEdit}
                  onRotated={() =>
                    setState((s) => ({
                      ...s,
                      embedding: { ...s.embedding, apiKey: KEEP, hasApiKey: true },
                    }))
                  }
                />
              ) : null}
            </div>
          </Field>

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Model" source={state.source.embeddingModel}>
              <div className="flex gap-2">
                <div className="flex-1">
                  <ModelInput
                    value={state.embedding.model}
                    onChange={(v) =>
                      setState((s) => {
                        // If we recognize the model in the preset, sync dimensions automatically.
                        const known = embPreset?.embeddingModels?.find((m) => m.name === v);
                        return {
                          ...s,
                          embedding: {
                            ...s.embedding,
                            model: v,
                            ...(known ? { dimensions: known.dimensions } : {}),
                          },
                        };
                      })
                    }
                    suggestions={
                      embModels.length > 0
                        ? embModels
                        : (embPreset?.embeddingModels ?? []).map((m) => m.name)
                    }
                    disabled={!canEdit}
                  />
                </div>
                {embPreset?.hasModelsApi ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fetchModels("embedding")}
                    disabled={loadingEmbModels || !canEdit}
                  >
                    {loadingEmbModels ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Search className="h-3.5 w-3.5" />
                    )}
                    List
                  </Button>
                ) : null}
              </div>
            </Field>
            <Field label="Dimensions" source={state.source.embeddingDimensions}>
              <Input
                type="number"
                min={1}
                value={state.embedding.dimensions}
                onChange={(e) =>
                  setState((s) => ({
                    ...s,
                    embedding: { ...s.embedding, dimensions: Number(e.target.value) || 0 },
                  }))
                }
                disabled={!canEdit}
              />
              <p className="mt-1 text-[11px] text-muted-foreground">
                Must match the model&apos;s output size. Mixed dimensions in an index will produce no
                results.
              </p>
            </Field>
          </div>

          <div className="flex items-center justify-between border-t pt-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => test("embedding")}
              disabled={!canEdit || embTest.state === "loading"}
            >
              {embTest.state === "loading" ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <PlugZap className="h-3.5 w-3.5" />
              )}
              Test connection
            </Button>
            <TestResultBadge t={embTest} />
          </div>
        </CardContent>
      </Card>

      {/* LlamaParse */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Wrench className="h-4 w-4 text-primary" />
                LlamaParse (optional)
              </CardTitle>
              <CardDescription>
                Premium PDF / Word / PowerPoint extraction with table & chart awareness. Off by
                default — local parsers are used otherwise.
              </CardDescription>
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={state.llamaparse.enabled}
                onChange={(e) =>
                  setState((s) => ({ ...s, llamaparse: { ...s.llamaparse, enabled: e.target.checked } }))
                }
                disabled={!canEdit}
                className="h-4 w-4"
              />
              Enabled
            </label>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <Field label="LlamaParse API key" source={state.source.llamaparse}>
            <Input
              type="password"
              value={state.llamaparse.apiKey === KEEP ? state.llamaparse.apiKeyMasked : state.llamaparse.apiKey}
              onChange={(e) =>
                setState((s) => ({ ...s, llamaparse: { ...s.llamaparse, apiKey: e.target.value } }))
              }
              disabled={!canEdit || !state.llamaparse.enabled}
              placeholder="llx-..."
              className="font-mono text-xs"
            />
            <p className="mt-1 text-[11px] text-muted-foreground">
              Get a key at{" "}
              <a
                href="https://cloud.llamaindex.ai"
                className="underline"
                target="_blank"
                rel="noreferrer"
              >
                cloud.llamaindex.ai
              </a>
              .
            </p>
          </Field>
          <Field label="Result format" source={state.source.llamaparse}>
            <Select
              value={state.llamaparse.resultType}
              onValueChange={(v) =>
                setState((s) => ({
                  ...s,
                  llamaparse: { ...s.llamaparse, resultType: v as "text" | "markdown" },
                }))
              }
              disabled={!canEdit || !state.llamaparse.enabled}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="markdown">Markdown (recommended)</SelectItem>
                <SelectItem value="text">Plain text</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </CardContent>
      </Card>

      {/* Save bar */}
      <div className="sticky bottom-0 -mx-4 flex items-center justify-end gap-2 border-t bg-background/90 px-4 py-3 backdrop-blur lg:-mx-8 lg:px-8">
        <Button variant="ghost" onClick={resetToEnv} disabled={!canEdit}>
          <RotateCcw className="h-4 w-4" /> Reset to env defaults
        </Button>
        <Button variant="gradient" onClick={save} disabled={!canEdit || saving}>
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save changes
        </Button>
      </div>
    </div>
  );
}

function Field({
  label,
  source,
  children,
}: {
  label: string;
  source?: "org" | "env";
  children: React.ReactNode;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-baseline justify-between">
        <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
        {source ? (
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground/60">
            from {source}
          </span>
        ) : null}
      </div>
      {children}
    </div>
  );
}

function ModelInput({
  value,
  onChange,
  suggestions,
  disabled,
}: {
  value: string;
  onChange: (v: string) => void;
  suggestions: string[];
  disabled?: boolean;
}) {
  const id = useMemo(() => `dl-${Math.random().toString(36).slice(2)}`, []);
  return (
    <>
      <Input
        list={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className="font-mono text-xs"
      />
      <datalist id={id}>
        {suggestions.map((s) => (
          <option key={s} value={s} />
        ))}
      </datalist>
    </>
  );
}

function RotateKeyButton({
  orgId,
  target,
  canEdit,
  onRotated,
}: {
  orgId: string;
  target: "llm" | "embedding";
  canEdit: boolean;
  onRotated: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [newKey, setNewKey] = useState("");
  const [pending, setPending] = useState(false);
  const [show, setShow] = useState(false);

  function reset() {
    setNewKey("");
    setShow(false);
    setPending(false);
  }

  async function submit() {
    if (!newKey.trim()) {
      toast({ title: "Enter a new key first" });
      return;
    }
    setPending(true);
    try {
      const body =
        target === "llm" ? { apiKey: newKey } : { embeddingApiKey: newKey };
      const res = await fetch(`/api/orgs/${orgId}/ai-config/rotate`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Couldn't rotate", description: data.error ?? "Unknown error" });
        return;
      }
      toast({
        title: target === "llm" ? "LLM API key rotated" : "Embedding API key rotated",
        description: `Effective ${new Date(data.rotatedAt).toLocaleTimeString()}`,
        variant: "success",
      });
      reset();
      setOpen(false);
      onRotated();
    } catch (e) {
      toast({
        title: "Couldn't rotate",
        description: e instanceof Error ? e.message : String(e),
      });
    } finally {
      setPending(false);
    }
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        disabled={!canEdit}
        onClick={() => setOpen(true)}
        title="Replace the stored API key with a new value"
      >
        <KeyRound className="h-3.5 w-3.5" /> Rotate
      </Button>
      <Dialog
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (!o) reset();
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rotate {target === "llm" ? "LLM" : "embedding"} API key</DialogTitle>
            <DialogDescription>
              Paste a new key below. The existing one is replaced immediately and the old value
              is no longer recoverable from this server. Any in-flight requests will continue
              with the previous key.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="rotate-new-key" className="text-xs uppercase tracking-wider text-muted-foreground">
              New API key
            </Label>
            <div className="relative">
              <Input
                id="rotate-new-key"
                type={show ? "text" : "password"}
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                placeholder="Paste the new key"
                disabled={pending}
                className="pr-9 font-mono text-xs"
                autoFocus
              />
              <button
                type="button"
                onClick={() => setShow((v) => !v)}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {show ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
              </button>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)} disabled={pending}>
              Cancel
            </Button>
            <Button variant="gradient" onClick={submit} disabled={pending || !newKey.trim()}>
              {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <KeyRound className="h-4 w-4" />}
              Rotate key
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function TestResultBadge({ t }: { t: TestState }) {
  if (t.state === "idle") return null;
  if (t.state === "loading") return <span className="text-xs text-muted-foreground">Testing…</span>;
  if (t.state === "ok") {
    return (
      <span className="inline-flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-300">
        <CheckCircle2 className="h-3.5 w-3.5" /> {t.message}
      </span>
    );
  }
  return (
    <span className="inline-flex max-w-[60%] items-center gap-1 truncate text-xs text-destructive" title={t.message}>
      <AlertCircle className="h-3.5 w-3.5 shrink-0" /> {t.message}
    </span>
  );
}
