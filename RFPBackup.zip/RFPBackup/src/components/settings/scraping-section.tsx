"use client";

// Web Scraping settings panel (Phase A.3).
//
// Lets admins control how URLs are fetched + parsed when added to an index:
//   - Engine: STATIC (default — cheerio + Readability, no JS) |
//             PLAYWRIGHT (local headless, Phase B) |
//             BROWSERLESS (remote service, Phase B)
//   - Honor robots.txt (default on)
//
// Advanced:
//   - Headless service URL + token (Browserless endpoint, etc.)
//   - Per-page timeout (ms)
//   - Max images per page
//
// PLAYWRIGHT / BROWSERLESS engines are accepted by the form but log a warn
// at scrape time and fall back to STATIC until Phase B ships the wiring.

import { useCallback, useEffect, useState } from "react";
import {
  Globe,
  Loader2,
  ChevronDown,
  ChevronRight,
  Save,
  RotateCcw,
  Sparkles,
  AlertTriangle,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const KEEP_EXISTING_SECRET = "__KEEP__";

type Engine = "STATIC" | "PLAYWRIGHT" | "BROWSERLESS";

interface ScrapingConfig {
  engine: Engine;
  headlessUrl: string;
  headlessToken: string;
  respectRobots: boolean;
  timeoutMs: number;
  maxImages: number;
}

interface Props {
  orgId: string;
  canEdit: boolean;
}

const DEFAULTS: ScrapingConfig = {
  engine: "STATIC",
  headlessUrl: "",
  headlessToken: "",
  respectRobots: true,
  timeoutMs: 20_000,
  maxImages: 48,
};

export function ScrapingSection({ orgId, canEdit }: Props) {
  const [config, setConfig] = useState<ScrapingConfig>(DEFAULTS);
  const [initial, setInitial] = useState<ScrapingConfig>(DEFAULTS);
  const [hasToken, setHasToken] = useState(false);
  const [tokenMasked, setTokenMasked] = useState("");
  const [source, setSource] = useState<"org" | "default">("default");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [advanced, setAdvanced] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`);
      if (!res.ok) return;
      const body = await res.json();
      const s = body.config?.scraping;
      if (s) {
        setHasToken(Boolean(s.hasHeadlessToken));
        setTokenMasked(s.headlessTokenMasked ?? "");
        const next: ScrapingConfig = {
          engine: s.engine ?? DEFAULTS.engine,
          headlessUrl: s.headlessUrl ?? "",
          // Sentinel: the form starts with "keep existing" so we don't
          // accidentally overwrite the saved token by re-PUT'ing.
          headlessToken: s.hasHeadlessToken ? KEEP_EXISTING_SECRET : "",
          respectRobots: s.respectRobots ?? true,
          timeoutMs: s.timeoutMs ?? DEFAULTS.timeoutMs,
          maxImages: s.maxImages ?? DEFAULTS.maxImages,
        };
        setConfig(next);
        setInitial(next);
      }
      setSource(body.config?.source?.scraping ?? "default");
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void load();
  }, [load]);

  const dirty = JSON.stringify(config) !== JSON.stringify(initial);
  const needsHeadlessFields = config.engine !== "STATIC";

  async function save() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          scraping: {
            engine: config.engine,
            headlessUrl: config.headlessUrl.trim() === "" ? null : config.headlessUrl.trim(),
            headlessToken: config.headlessToken,
            respectRobots: config.respectRobots,
            timeoutMs: config.timeoutMs,
            maxImages: config.maxImages,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error });
        return;
      }
      toast({ title: "Scraping settings saved", variant: "success" });
      await load();
      setSource("org");
    } finally {
      setSaving(false);
    }
  }

  async function clearToken() {
    setConfig({ ...config, headlessToken: "" });
    // Will be persisted on next Save; the empty string clears the stored token.
  }

  async function resetToDefaults() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          scraping: {
            engine: null,
            headlessUrl: null,
            headlessToken: null,
            respectRobots: null,
            timeoutMs: null,
            maxImages: null,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't reset", description: e.error });
        return;
      }
      toast({ title: "Reset to defaults", variant: "success" });
      setConfig(DEFAULTS);
      setInitial(DEFAULTS);
      setHasToken(false);
      setTokenMasked("");
      setSource("default");
      await load();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Web scraping
              <Badge variant={source === "org" ? "info" : "outline"} className="ml-1 text-[10px]">
                {source === "org" ? "Customized" : "Defaults"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Controls how URLs are fetched + parsed when added to a knowledge index.
              Default (Static) works for most marketing/docs sites.
            </CardDescription>
          </div>
          {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* ----- Simple tier ----- */}
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-xs">Engine</Label>
            <Select
              value={config.engine}
              onValueChange={(v) => setConfig({ ...config, engine: v as Engine })}
              disabled={!canEdit || loading}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="STATIC">Static (cheerio + Readability)</SelectItem>
                <SelectItem value="PLAYWRIGHT">Playwright (local headless)</SelectItem>
                <SelectItem value="BROWSERLESS">Browserless (remote)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">
              Static is fast + free. Headless engines render JS-driven SPAs.
            </p>
            {config.engine === "PLAYWRIGHT" ? (
              <p className="flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-700 dark:text-amber-300">
                <AlertTriangle className="h-3 w-3 shrink-0" />
                Requires <code>pnpm add playwright</code> + <code>pnpm exec playwright install chromium</code>{" "}
                on the server (~300 MB). If missing, scrape falls back to Static and logs the install command.
              </p>
            ) : null}
            {config.engine === "BROWSERLESS" && !config.headlessUrl ? (
              <p className="flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-700 dark:text-amber-300">
                <AlertTriangle className="h-3 w-3 shrink-0" />
                Set the headless service URL under Advanced (e.g. <code>https://chrome.browserless.io</code>) and paste your API token.
              </p>
            ) : null}
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">robots.txt</Label>
            <div className="flex h-9 items-center gap-2">
              <input
                type="checkbox"
                id="sc-robots"
                checked={config.respectRobots}
                onChange={(e) => setConfig({ ...config, respectRobots: e.target.checked })}
                disabled={!canEdit || loading}
                className="h-4 w-4"
              />
              <label htmlFor="sc-robots" className="text-sm">
                Honor <code className="text-xs">robots.txt</code>
              </label>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Disable only on sites you operate (or have explicit permission to scrape).
            </p>
          </div>
        </div>

        {/* ----- Advanced tier ----- */}
        <div className="rounded-lg border bg-muted/20">
          <button
            type="button"
            onClick={() => setAdvanced((v) => !v)}
            className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:bg-muted/40"
            aria-expanded={advanced}
          >
            <span className="flex items-center gap-1.5">
              {advanced ? (
                <ChevronDown className="h-3.5 w-3.5" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5" />
              )}
              Advanced
            </span>
            <span className="text-[10px] uppercase tracking-wider opacity-70">
              {advanced ? "Hide" : "Show"}
            </span>
          </button>
          {advanced ? (
            <div className="space-y-4 border-t px-3 py-3">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-xs" htmlFor="sc-url">
                    Headless service URL
                  </Label>
                  <Input
                    id="sc-url"
                    type="url"
                    value={config.headlessUrl}
                    onChange={(e) => setConfig({ ...config, headlessUrl: e.target.value })}
                    disabled={!canEdit || loading || !needsHeadlessFields}
                    placeholder="https://chrome.browserless.io"
                    className={cn("h-9 text-xs", !needsHeadlessFields && "opacity-50")}
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Endpoint for Browserless or a self-hosted Playwright service.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs" htmlFor="sc-token">
                    Headless API token
                  </Label>
                  <div className="flex gap-1">
                    <Input
                      id="sc-token"
                      type="password"
                      value={
                        config.headlessToken === KEEP_EXISTING_SECRET ? tokenMasked : config.headlessToken
                      }
                      onChange={(e) => setConfig({ ...config, headlessToken: e.target.value })}
                      disabled={!canEdit || loading || !needsHeadlessFields}
                      placeholder={hasToken ? "Token stored (paste to replace)" : "Paste token"}
                      className={cn(
                        "h-9 font-mono text-xs",
                        !needsHeadlessFields && "opacity-50",
                      )}
                    />
                    {hasToken && canEdit && needsHeadlessFields ? (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={clearToken}
                        title="Clear stored token"
                      >
                        Clear
                      </Button>
                    ) : null}
                  </div>
                  <p className="text-[11px] text-muted-foreground">
                    Encrypted at rest. Never shown after save.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs" htmlFor="sc-timeout">
                    Timeout (ms)
                  </Label>
                  <Input
                    id="sc-timeout"
                    type="number"
                    min={1000}
                    max={120_000}
                    step={1000}
                    value={config.timeoutMs}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        timeoutMs: clampInt(e.target.value, 1000, 120_000, DEFAULTS.timeoutMs),
                      })
                    }
                    disabled={!canEdit || loading}
                    className="h-9"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    How long to wait for a single page before giving up.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs" htmlFor="sc-images">
                    Max images per page
                  </Label>
                  <Input
                    id="sc-images"
                    type="number"
                    min={0}
                    max={500}
                    value={config.maxImages}
                    onChange={(e) =>
                      setConfig({
                        ...config,
                        maxImages: clampInt(e.target.value, 0, 500, DEFAULTS.maxImages),
                      })
                    }
                    disabled={!canEdit || loading}
                    className="h-9"
                  />
                  <p className="text-[11px] text-muted-foreground">
                    Cap on extracted images (CLIP embedding cost scales with this).
                  </p>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* ----- Actions ----- */}
        {canEdit ? (
          <div className="flex items-center justify-end gap-2 pt-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={resetToDefaults}
              disabled={saving || (source === "default" && !dirty)}
              title="Clear org overrides and use platform defaults"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset to defaults
            </Button>
            <Button
              variant="gradient"
              size="sm"
              onClick={save}
              disabled={saving || !dirty}
            >
              {saving ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Save className="h-3.5 w-3.5" />
              )}
              Save changes
            </Button>
          </div>
        ) : (
          <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3" />
            Read-only &mdash; ADMIN or OWNER role required to change scraping settings.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function clampInt(raw: string, min: number, max: number, fallback: number): number {
  const n = parseInt(raw, 10);
  if (Number.isNaN(n)) return fallback;
  if (n < min) return min;
  if (n > max) return max;
  return n;
}
