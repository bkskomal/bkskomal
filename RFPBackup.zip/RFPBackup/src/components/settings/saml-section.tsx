"use client";

// SAML SSO configuration card. Mirrors the pattern in api-keys-section /
// cache-section: client component, fetches its own state from
// /api/orgs/[orgId]/saml, renders a small editor, and lets admins/owners
// configure or remove the IdP binding.
//
// Visible to admin+ only (the parent gates rendering — we still rely on the
// API itself to enforce). Non-admins won't see this card.

import { useCallback, useEffect, useState } from "react";
import { Shield, ShieldCheck, ShieldAlert, Loader2, Download } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useConfirm } from "@/components/ui/confirm";
import { toast } from "@/components/ui/use-toast";

interface SamlConfigState {
  id: string;
  idpEntityId: string;
  idpSsoUrl: string;
  idpCertificatePreview: string | null;
  idpCertificateLength: number;
  spEntityId: string | null;
  attributeMappings: {
    email?: string;
    name?: string;
    groups?: string;
    externalId?: string;
  } | null;
  enforced: boolean;
  enabled: boolean;
}

interface Props {
  orgId: string;
  orgSlug: string;
}

const DEFAULT_MAPPINGS = {
  email: "email",
  name: "name",
  groups: "groups",
  externalId: "externalId",
};

export function SamlSection({ orgId, orgSlug }: Props) {
  const confirm = useConfirm();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [config, setConfig] = useState<SamlConfigState | null>(null);

  const [idpEntityId, setIdpEntityId] = useState("");
  const [idpSsoUrl, setIdpSsoUrl] = useState("");
  const [idpCertificate, setIdpCertificate] = useState("");
  const [spEntityId, setSpEntityId] = useState("");
  const [mapEmail, setMapEmail] = useState(DEFAULT_MAPPINGS.email);
  const [mapName, setMapName] = useState(DEFAULT_MAPPINGS.name);
  const [mapGroups, setMapGroups] = useState(DEFAULT_MAPPINGS.groups);
  const [mapExternalId, setMapExternalId] = useState(DEFAULT_MAPPINGS.externalId);
  const [enforced, setEnforced] = useState(false);

  const refresh = useCallback(async () => {
    const res = await fetch(`/api/orgs/${orgId}/saml`);
    if (!res.ok) {
      toast({ title: "Couldn't load SAML configuration" });
      return;
    }
    const data = (await res.json()) as { config: SamlConfigState | null };
    setConfig(data.config);
    if (data.config) {
      setIdpEntityId(data.config.idpEntityId);
      setIdpSsoUrl(data.config.idpSsoUrl);
      setIdpCertificate("");
      setSpEntityId(data.config.spEntityId ?? "");
      const m = data.config.attributeMappings ?? {};
      setMapEmail(m.email ?? DEFAULT_MAPPINGS.email);
      setMapName(m.name ?? DEFAULT_MAPPINGS.name);
      setMapGroups(m.groups ?? DEFAULT_MAPPINGS.groups);
      setMapExternalId(m.externalId ?? DEFAULT_MAPPINGS.externalId);
      setEnforced(data.config.enforced);
    }
  }, [orgId]);

  useEffect(() => {
    void refresh().finally(() => setLoading(false));
  }, [refresh]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const body: Record<string, unknown> = {
        idpEntityId,
        idpSsoUrl,
        attributeMappings: {
          email: mapEmail,
          name: mapName,
          groups: mapGroups,
          externalId: mapExternalId,
        },
        enforced,
      };
      if (spEntityId) body.spEntityId = spEntityId;
      // Only send the cert if the admin typed something — empty means "keep
      // existing".
      if (idpCertificate.trim()) {
        body.idpCertificate = idpCertificate.trim();
      } else if (!config) {
        toast({ title: "Certificate is required" });
        setSaving(false);
        return;
      } else {
        // Need to re-send the existing cert because PUT validates min length.
        // The simplest UX: ask the admin to re-paste only when they want to
        // change it; otherwise we read it back from the server and forward.
        const fetched = await fetch(`/api/orgs/${orgId}/saml`);
        const data = (await fetched.json()) as { config: SamlConfigState | null };
        if (!data.config) {
          toast({ title: "Couldn't read existing config" });
          setSaving(false);
          return;
        }
        // We can't read the full cert from the GET response (only a preview).
        // Require the admin to re-paste if they want to change anything else.
        // For now: if cert is empty AND a config exists, we still need to
        // send something — we'll require a re-paste on each save. Surface
        // that clearly:
        toast({
          title: "Paste the certificate to save changes",
          description:
            "For security, the certificate is not echoed back. Re-paste it to save.",
        });
        setSaving(false);
        return;
      }
      const res = await fetch(`/api/orgs/${orgId}/saml`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: (err as { error?: string }).error });
        return;
      }
      toast({ title: "Saved", variant: "success" });
      await refresh();
    } finally {
      setSaving(false);
    }
  }

  async function disconnect() {
    if (!(await confirm("Users will sign in via the regular methods again.", { title: "Disconnect SAML?", destructive: true, confirmLabel: "Disconnect" }))) {
      return;
    }
    const res = await fetch(`/api/orgs/${orgId}/saml`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "SAML removed", variant: "success" });
      setConfig(null);
      setIdpEntityId("");
      setIdpSsoUrl("");
      setIdpCertificate("");
      setSpEntityId("");
      setEnforced(false);
    } else {
      toast({ title: "Couldn't remove" });
    }
  }

  async function test() {
    setTesting(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/saml/test`, { method: "POST" });
      const data = (await res.json()) as { ok: boolean; errors?: string[] };
      if (data.ok) {
        toast({ title: "Connection looks good", variant: "success" });
      } else {
        toast({
          title: "Connection check failed",
          description: data.errors?.join("; ") ?? "Unknown error",
        });
      }
    } finally {
      setTesting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          SAML SSO
          {config ? (
            <Badge variant="success" className="ml-2 gap-1">
              <ShieldCheck className="h-3 w-3" />
              Connected to {config.idpEntityId}
            </Badge>
          ) : (
            <Badge variant="secondary" className="ml-2">
              Not configured
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          Let your IdP (Okta, Azure AD, Auth0, OneLogin, generic SAML) gate sign-in
          for this organization.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </div>
        ) : (
          <form onSubmit={save} className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="saml-idp-entity">IdP Entity ID / Issuer</Label>
                <Input
                  id="saml-idp-entity"
                  value={idpEntityId}
                  onChange={(e) => setIdpEntityId(e.target.value)}
                  placeholder="https://idp.example.com"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="saml-idp-sso">IdP SSO URL</Label>
                <Input
                  id="saml-idp-sso"
                  value={idpSsoUrl}
                  onChange={(e) => setIdpSsoUrl(e.target.value)}
                  placeholder="https://idp.example.com/sso/saml"
                  required
                />
              </div>
              <div className="md:col-span-2 space-y-1.5">
                <Label htmlFor="saml-cert">IdP Signing Certificate (PEM)</Label>
                <textarea
                  id="saml-cert"
                  className="min-h-32 w-full rounded-md border bg-background p-2 text-sm font-mono"
                  value={idpCertificate}
                  onChange={(e) => setIdpCertificate(e.target.value)}
                  placeholder={config ? `Current: ${config.idpCertificatePreview ?? ""}` : "-----BEGIN CERTIFICATE-----\n..."}
                />
                {config ? (
                  <p className="text-xs text-muted-foreground">
                    Paste a fresh certificate to update; leave blank to keep the
                    current one (you&apos;ll need to re-paste on any save).
                  </p>
                ) : null}
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="saml-sp-entity">SP Entity ID (optional)</Label>
                <Input
                  id="saml-sp-entity"
                  value={spEntityId}
                  onChange={(e) => setSpEntityId(e.target.value)}
                  placeholder="autorfp:org:<id>"
                />
              </div>
            </div>

            <div>
              <h4 className="mb-2 text-sm font-medium">Attribute mappings</h4>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="saml-map-email">Email</Label>
                  <Input id="saml-map-email" value={mapEmail} onChange={(e) => setMapEmail(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="saml-map-name">Name</Label>
                  <Input id="saml-map-name" value={mapName} onChange={(e) => setMapName(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="saml-map-groups">Groups</Label>
                  <Input id="saml-map-groups" value={mapGroups} onChange={(e) => setMapGroups(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="saml-map-extid">External ID</Label>
                  <Input id="saml-map-extid" value={mapExternalId} onChange={(e) => setMapExternalId(e.target.value)} />
                </div>
              </div>
            </div>

            <label className="flex items-start gap-3 rounded-md border bg-card/50 p-3">
              <input
                type="checkbox"
                className="mt-1 h-4 w-4"
                checked={enforced}
                onChange={(e) => setEnforced(e.target.checked)}
              />
              <span className="text-sm">
                <span className="font-medium flex items-center gap-1">
                  <ShieldAlert className="h-3.5 w-3.5 text-amber-600" />
                  Enforce SAML for this org
                </span>
                <span className="block text-muted-foreground">
                  Users will lose access via magic-link and OAuth. Make sure your
                  IdP is set up before you flip this.
                </span>
              </span>
            </label>

            <div className="flex flex-wrap items-center gap-2">
              <Button type="submit" disabled={saving}>
                {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Save
              </Button>
              <Button type="button" variant="outline" onClick={test} disabled={testing || !config}>
                {testing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Test connection
              </Button>
              {config ? (
                <a
                  href={`/api/auth/saml/${encodeURIComponent(orgSlug)}/metadata`}
                  className="inline-flex items-center gap-1 rounded-md border px-3 py-1.5 text-sm hover:bg-accent"
                >
                  <Download className="h-4 w-4" /> Download SP metadata
                </a>
              ) : null}
              {config ? (
                <Button type="button" variant="destructive" onClick={disconnect} className="ml-auto">
                  Disconnect
                </Button>
              ) : null}
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
