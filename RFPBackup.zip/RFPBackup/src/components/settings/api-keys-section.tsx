"use client";

import { useEffect, useState } from "react";
import {
  Key,
  Loader2,
  Plus,
  Copy,
  Check,
  Trash2,
  ShieldAlert,
} from "lucide-react";
import { ApiKeyScope } from "@prisma/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useConfirm } from "@/components/ui/confirm";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ApiKeyRow {
  id: string;
  name: string;
  prefix: string;
  scope: ApiKeyScope;
  organizationId: string | null;
  lastUsedAt: string | null;
  expiresAt: string | null;
  revokedAt: string | null;
  createdAt: string;
}

interface IssuedKeyResponse {
  id: string;
  name: string;
  token: string;
  prefix: string;
  scope: ApiKeyScope;
  createdAt: string;
}

function scopeBadgeVariant(scope: ApiKeyScope): "info" | "warning" | "destructive" {
  switch (scope) {
    case "READ":
      return "info";
    case "WRITE":
      return "warning";
    case "ADMIN":
      return "destructive";
  }
}

function statusOf(row: ApiKeyRow): { label: string; variant: "success" | "secondary" | "destructive" } {
  if (row.revokedAt) return { label: "Revoked", variant: "destructive" };
  if (row.expiresAt && new Date(row.expiresAt).getTime() <= Date.now()) {
    return { label: "Expired", variant: "secondary" };
  }
  return { label: "Active", variant: "success" };
}

function fmtDate(value: string | null): string {
  if (!value) return "—";
  return new Date(value).toLocaleString();
}

export function ApiKeysSection({ orgId }: { orgId: string }) {
  const confirm = useConfirm();
  const [rows, setRows] = useState<ApiKeyRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);

  async function refresh() {
    const res = await fetch("/api/account/api-keys");
    if (!res.ok) {
      toast({ title: "Couldn't load API keys" });
      return;
    }
    const data = await res.json();
    setRows(data.keys ?? []);
  }

  useEffect(() => {
    void refresh().finally(() => setLoading(false));
  }, []);

  async function revoke(row: ApiKeyRow) {
    if (!(await confirm("Any client using this key will start failing immediately.", { title: `Revoke "${row.name}"?`, destructive: true, confirmLabel: "Revoke" }))) return;
    const res = await fetch(`/api/account/api-keys/${row.id}`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Key revoked", variant: "success" });
      void refresh();
    } else {
      toast({ title: "Couldn't revoke", description: (await res.json()).error });
    }
  }

  return (
    <Card id="api-keys">
      <CardHeader className="flex flex-row items-start justify-between gap-4">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Key className="h-4 w-4 text-primary" />
            API keys
          </CardTitle>
          <CardDescription>
            Personal access tokens for using the OATI AutoRFP API from scripts and integrations.
            Send as <code className="rounded bg-muted px-1 py-0.5 text-xs">Authorization: Bearer &lt;token&gt;</code>.
          </CardDescription>
        </div>
        <Button onClick={() => setCreateOpen(true)} size="sm">
          <Plus className="h-4 w-4" />
          Create new key
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid place-items-center py-8">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          </div>
        ) : rows.length === 0 ? (
          <div className="rounded-lg border border-dashed py-8 text-center text-sm text-muted-foreground">
            No API keys yet. Create one to start calling the OATI AutoRFP API.
          </div>
        ) : (
          <div className="overflow-hidden rounded-lg border">
            <div className="grid grid-cols-[1.5fr_1.5fr_auto_1fr_1fr_auto_auto] items-center gap-4 border-b bg-muted/30 px-4 py-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <div>Name</div>
              <div>Prefix</div>
              <div>Scope</div>
              <div>Last used</div>
              <div>Expires</div>
              <div>Status</div>
              <div></div>
            </div>
            {rows.map((r) => {
              const st = statusOf(r);
              return (
                <div
                  key={r.id}
                  className="grid grid-cols-[1.5fr_1.5fr_auto_1fr_1fr_auto_auto] items-center gap-4 border-b px-4 py-3 last:border-b-0"
                >
                  <div className="text-sm font-medium">{r.name}</div>
                  <code className="text-xs text-muted-foreground">autorfp_{r.prefix}…</code>
                  <Badge variant={scopeBadgeVariant(r.scope)}>{r.scope}</Badge>
                  <div className="text-xs text-muted-foreground">{fmtDate(r.lastUsedAt)}</div>
                  <div className="text-xs text-muted-foreground">{fmtDate(r.expiresAt)}</div>
                  <Badge variant={st.variant}>{st.label}</Badge>
                  <div>
                    {!r.revokedAt ? (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => void revoke(r)}
                        aria-label={`Revoke ${r.name}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>

      <CreateKeyDialog
        open={createOpen}
        onOpenChange={setCreateOpen}
        orgId={orgId}
        onCreated={() => {
          void refresh();
        }}
      />
    </Card>
  );
}

function CreateKeyDialog({
  open,
  onOpenChange,
  orgId,
  onCreated,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orgId: string;
  onCreated: () => void;
}) {
  const [name, setName] = useState("");
  const [scope, setScope] = useState<ApiKeyScope>("READ");
  const [expiresInDays, setExpiresInDays] = useState<string>("");
  const [bindToOrg, setBindToOrg] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [issued, setIssued] = useState<IssuedKeyResponse | null>(null);
  const [copied, setCopied] = useState(false);

  function reset() {
    setName("");
    setScope("READ");
    setExpiresInDays("");
    setBindToOrg(true);
    setIssued(null);
    setCopied(false);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/account/api-keys", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          name,
          scope,
          organizationId: bindToOrg ? orgId : null,
          expiresInDays: expiresInDays ? Number(expiresInDays) : null,
        }),
      });
      if (!res.ok) {
        toast({ title: "Couldn't create key", description: (await res.json()).error });
        return;
      }
      const data = await res.json();
      setIssued(data.key);
      onCreated();
    } finally {
      setSubmitting(false);
    }
  }

  async function copy() {
    if (!issued) return;
    await navigator.clipboard.writeText(issued.token);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function close(next: boolean) {
    onOpenChange(next);
    if (!next) reset();
  }

  return (
    <Dialog open={open} onOpenChange={close}>
      <DialogContent>
        {issued ? (
          <>
            <DialogHeader>
              <DialogTitle>Key created — copy it now</DialogTitle>
              <DialogDescription>
                This is the only time you&apos;ll see this token. Store it somewhere safe before closing this dialog.
              </DialogDescription>
            </DialogHeader>
            <div className="rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-sm text-amber-900 dark:text-amber-200">
              <div className="flex items-start gap-2">
                <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
                <div>
                  Once you close this dialog, OATI AutoRFP cannot show the token again. If you lose it,
                  revoke the key and create a new one.
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Input readOnly value={issued.token} className="font-mono text-xs" />
              <Button onClick={copy} size="sm" variant="secondary">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied" : "Copy"}
              </Button>
            </div>
            <DialogFooter>
              <Button onClick={() => close(false)}>I&apos;ve saved it</Button>
            </DialogFooter>
          </>
        ) : (
          <form onSubmit={submit} className="contents">
            <DialogHeader>
              <DialogTitle>Create API key</DialogTitle>
              <DialogDescription>
                Personal access tokens authenticate API requests on your behalf.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="key-name">Name</Label>
                <Input
                  id="key-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. CI export script"
                  required
                  maxLength={100}
                />
              </div>
              <div>
                <Label htmlFor="key-scope">Scope</Label>
                <Select value={scope} onValueChange={(v) => setScope(v as ApiKeyScope)}>
                  <SelectTrigger id="key-scope">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="READ">Read — fetch RFPs, questions, responses</SelectItem>
                    <SelectItem value="WRITE">Write — create/update content</SelectItem>
                    <SelectItem value="ADMIN">Admin — manage org settings</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="key-expiry">Expires in days (optional)</Label>
                <Input
                  id="key-expiry"
                  type="number"
                  min={1}
                  max={365 * 5}
                  value={expiresInDays}
                  onChange={(e) => setExpiresInDays(e.target.value)}
                  placeholder="No expiry"
                />
              </div>
              <label className="flex items-start gap-2 text-sm">
                <input
                  type="checkbox"
                  className="mt-0.5"
                  checked={bindToOrg}
                  onChange={(e) => setBindToOrg(e.target.checked)}
                />
                <span>
                  Bind to current organization. Recommended — the key will only work for resources
                  in this org.
                </span>
              </label>
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => close(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting || !name}>
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
                Create key
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
