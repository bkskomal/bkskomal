"use client";

// Admin-only "Cache" settings panel for the semantic answer cache.
//
// Renders three pieces:
//   1. A stats card (total entries / total hits / estimated calls saved).
//   2. A bulk-purge control ("Purge entries older than N days").
//   3. A table of the most-recently-used entries with per-row "Invalidate".
//
// All requests hit /api/orgs/[orgId]/cache and its sub-routes. The route
// itself enforces admin-only access; we still hide the section behind a
// `canEdit` prop on the parent so non-admins don't see destructive buttons.

import { useEffect, useState } from "react";
import { Database, Loader2, Trash2 } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useConfirm } from "@/components/ui/confirm";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";

interface CacheRow {
  id: string;
  question: string;
  answer: string;
  indexId: string | null;
  hits: number;
  confidence: number | null;
  groundingScore: number | null;
  sourcesSnapshot: unknown;
  createdAt: string;
  lastUsedAt: string;
}

interface CacheStats {
  totalEntries: number;
  totalHits: number;
  estimatedCallsSaved: number;
}

function fmtDate(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString();
}

function sourceCount(snapshot: unknown): number {
  return Array.isArray(snapshot) ? snapshot.length : 0;
}

function truncate(s: string, n: number): string {
  if (s.length <= n) return s;
  return s.slice(0, n - 1) + "…";
}

export function CacheSection({ orgId, canEdit }: { orgId: string; canEdit: boolean }) {
  const confirm = useConfirm();
  const [rows, setRows] = useState<CacheRow[]>([]);
  const [stats, setStats] = useState<CacheStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [purging, setPurging] = useState(false);
  const [purgeDays, setPurgeDays] = useState<string>("90");

  async function refresh() {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/cache`);
      if (!res.ok) {
        toast({ title: "Couldn't load cache entries" });
        return;
      }
      const data = await res.json();
      setRows(data.entries ?? []);
      setStats(data.stats ?? null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orgId]);

  async function invalidate(row: CacheRow) {
    if (!(await confirm(`Invalidate cached answer for "${truncate(row.question, 60)}"?`, { destructive: true, confirmLabel: "Invalidate" }))) {
      return;
    }
    const res = await fetch(`/api/orgs/${orgId}/cache/${row.id}`, { method: "DELETE" });
    if (res.ok) {
      toast({ title: "Cache entry invalidated", variant: "success" });
      void refresh();
    } else {
      toast({ title: "Couldn't invalidate", description: (await res.json()).error });
    }
  }

  async function bulkPurge() {
    const days = Number(purgeDays);
    if (!Number.isFinite(days) || days < 0) {
      toast({ title: "Enter a non-negative number of days" });
      return;
    }
    if (
      !confirm(
        `Purge all cached entries idle for more than ${days} days? This cannot be undone.`,
      )
    ) {
      return;
    }
    setPurging(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/cache`, {
        method: "DELETE",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ olderThanDays: days }),
      });
      if (res.ok) {
        const data = await res.json();
        toast({ title: `Purged ${data.deleted} entries`, variant: "success" });
        void refresh();
      } else {
        toast({ title: "Couldn't purge", description: (await res.json()).error });
      }
    } finally {
      setPurging(false);
    }
  }

  return (
    <Card id="cache">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-4 w-4 text-primary" />
          Answer cache
        </CardTitle>
        <CardDescription>
          Previously generated answers are cached for fast reuse when the same (or
          a sufficiently similar) question is asked again in this org. The cache
          short-circuits the full LLM pipeline, saving latency and tokens.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Stats row */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <StatBox label="Cached entries" value={stats?.totalEntries ?? 0} />
          <StatBox label="Total hits served" value={stats?.totalHits ?? 0} />
          <StatBox
            label="Estimated calls saved"
            value={stats?.estimatedCallsSaved ?? 0}
          />
        </div>

        {/* Bulk purge */}
        {canEdit ? (
          <div className="flex flex-wrap items-end gap-3 rounded-lg border bg-muted/20 p-3">
            <div>
              <Label htmlFor="cache-purge-days">Purge entries older than</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="cache-purge-days"
                  type="number"
                  min={0}
                  max={3650}
                  value={purgeDays}
                  onChange={(e) => setPurgeDays(e.target.value)}
                  className="w-24"
                />
                <span className="text-sm text-muted-foreground">days</span>
              </div>
            </div>
            <Button
              variant="outline"
              onClick={() => void bulkPurge()}
              disabled={purging}
            >
              {purging ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
              Purge
            </Button>
            <p className="basis-full text-xs text-muted-foreground">
              Only entries whose <em>last used</em> date is older than the threshold are
              removed. Recently-served entries are kept regardless of age.
            </p>
          </div>
        ) : null}

        {/* Entries table */}
        {loading ? (
          <div className="grid place-items-center py-8">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          </div>
        ) : rows.length === 0 ? (
          <div className="rounded-lg border border-dashed py-8 text-center text-sm text-muted-foreground">
            No cached answers yet. Cached entries appear here after the first successful
            generation in this org.
          </div>
        ) : (
          <div className="overflow-hidden rounded-lg border">
            <div className="grid grid-cols-[2fr_auto_auto_1.2fr_auto] items-center gap-4 border-b bg-muted/30 px-4 py-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              <div>Question</div>
              <div>Hits</div>
              <div>Sources</div>
              <div>Last used</div>
              <div></div>
            </div>
            {rows.map((row) => (
              <div
                key={row.id}
                className="grid grid-cols-[2fr_auto_auto_1.2fr_auto] items-center gap-4 border-b px-4 py-3 last:border-b-0"
              >
                <div
                  className="truncate text-sm"
                  title={row.question}
                >
                  {truncate(row.question, 100)}
                </div>
                <Badge variant="secondary">{row.hits}</Badge>
                <span className="text-xs text-muted-foreground">
                  {sourceCount(row.sourcesSnapshot)}
                </span>
                <div className="text-xs text-muted-foreground">{fmtDate(row.lastUsedAt)}</div>
                <div>
                  {canEdit ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => void invalidate(row)}
                      aria-label={`Invalidate cached answer`}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StatBox({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-lg border bg-muted/20 p-3">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold tabular-nums">{value.toLocaleString()}</div>
    </div>
  );
}
