"use client";

import { useEffect, useState } from "react";
import { Bell, Mail, Loader2, Save } from "lucide-react";
import { NotificationKind } from "@prisma/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";

interface PreferenceRow {
  kind: NotificationKind;
  inApp: boolean;
  email: boolean;
}

interface Meta {
  label: string;
  description: string;
}

export function NotificationPreferences() {
  const [rows, setRows] = useState<PreferenceRow[]>([]);
  const [meta, setMeta] = useState<Record<NotificationKind, Meta>>({} as any);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dirty, setDirty] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetch("/api/me/notification-preferences")
      .then((r) => r.json())
      .then((d) => {
        setRows(d.preferences ?? []);
        setMeta(d.meta ?? {});
      })
      .finally(() => setLoading(false));
  }, []);

  function toggle(kind: NotificationKind, channel: "inApp" | "email") {
    setRows((prev) =>
      prev.map((r) => (r.kind === kind ? { ...r, [channel]: !r[channel] } : r)),
    );
    setDirty((d) => new Set(d).add(`${kind}:${channel}`));
  }

  async function save() {
    setSaving(true);
    try {
      const changes = rows.flatMap((r) => [
        ...(dirty.has(`${r.kind}:inApp`)
          ? [{ kind: r.kind, channel: "IN_APP" as const, enabled: r.inApp }]
          : []),
        ...(dirty.has(`${r.kind}:email`)
          ? [{ kind: r.kind, channel: "EMAIL" as const, enabled: r.email }]
          : []),
      ]);
      if (changes.length === 0) {
        toast({ title: "No changes" });
        return;
      }
      const res = await fetch("/api/me/notification-preferences", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ changes }),
      });
      if (res.ok) {
        const d = await res.json();
        setRows(d.preferences ?? rows);
        setDirty(new Set());
        toast({ title: "Preferences saved", variant: "success" });
      } else {
        toast({ title: "Couldn't save", description: (await res.json()).error });
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card id="notifications">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-primary" />
          Notification preferences
        </CardTitle>
        <CardDescription>
          Choose which notifications you want to receive, and on which channels.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="grid place-items-center py-8">
            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <>
            <div className="overflow-hidden rounded-lg border">
              <div className="grid grid-cols-[1fr_auto_auto] items-center gap-4 border-b bg-muted/30 px-4 py-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                <div>Event</div>
                <div className="flex items-center gap-1 text-center w-16">
                  <Bell className="h-3 w-3" /> In-app
                </div>
                <div className="flex items-center gap-1 text-center w-16">
                  <Mail className="h-3 w-3" /> Email
                </div>
              </div>
              {rows.map((r) => {
                const m = meta[r.kind];
                return (
                  <div
                    key={r.kind}
                    className="grid grid-cols-[1fr_auto_auto] items-center gap-4 border-b px-4 py-3 last:border-b-0"
                  >
                    <div>
                      <div className="text-sm font-medium">{m?.label ?? r.kind}</div>
                      {m?.description ? (
                        <div className="text-xs text-muted-foreground">{m.description}</div>
                      ) : null}
                    </div>
                    <div className="grid w-16 place-items-center">
                      <Checkbox
                        checked={r.inApp}
                        onCheckedChange={() => toggle(r.kind, "inApp")}
                      />
                    </div>
                    <div className="grid w-16 place-items-center">
                      <Checkbox
                        checked={r.email}
                        onCheckedChange={() => toggle(r.kind, "email")}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-4 flex justify-end gap-2">
              {dirty.size > 0 ? (
                <span className="self-center text-xs text-muted-foreground">
                  {dirty.size} pending change{dirty.size === 1 ? "" : "s"}
                </span>
              ) : null}
              <Button onClick={save} disabled={saving || dirty.size === 0} variant="gradient">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save preferences
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
