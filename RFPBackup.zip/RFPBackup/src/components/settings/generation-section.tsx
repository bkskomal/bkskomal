"use client";

// Answer Generation settings panel (Phase A.4).
//
// Lets admins control the final drafting + post-checks:
//   - Pinned generation model (overrides Phase 3B routing tiers; LoRA adapter
//     still wins when set)
//   - Grounding judge on/off (post-hoc claim-vs-source check)
//   - Semantic answer cache on/off
//
// Advanced:
//   - Pinned grounding judge model (defaults to extraction model)
//   - Semantic cache similarity threshold (0.5..1.0)
//
// Defaults preserve current behavior so flipping nothing changes nothing.

import { useCallback, useEffect, useState } from "react";
import {
  PenLine,
  Loader2,
  ChevronDown,
  ChevronRight,
  Save,
  RotateCcw,
  Sparkles,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface GenerationConfig {
  /** Empty string = inherit (routing decides). */
  pinnedModel: string;
  groundingEnabled: boolean;
  /** Empty string = inherit (uses extraction model). */
  groundingModel: string;
  cacheEnabled: boolean;
  /** 0.5..1.0 cosine similarity threshold. */
  cacheSimilarityThreshold: number;
}

interface Props {
  orgId: string;
  canEdit: boolean;
}

// Defaults match the resolver fallbacks.
const DEFAULTS: GenerationConfig = {
  pinnedModel: "",
  groundingEnabled: true,
  groundingModel: "",
  cacheEnabled: true,
  cacheSimilarityThreshold: 0.92,
};

export function GenerationSection({ orgId, canEdit }: Props) {
  const [config, setConfig] = useState<GenerationConfig>(DEFAULTS);
  const [initial, setInitial] = useState<GenerationConfig>(DEFAULTS);
  const [resolvedGroundingModel, setResolvedGroundingModel] = useState<string>("");
  const [source, setSource] = useState<"org" | "default">("default");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [advanced, setAdvanced] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`);
      if (!res.ok) return;
      const body = await res.json();
      const g = body.config?.generation;
      const orgSource = body.config?.source?.generation ?? "default";
      if (g) {
        setResolvedGroundingModel(g.groundingModel ?? "");
        const next: GenerationConfig = {
          pinnedModel: orgSource === "org" && g.pinnedModel ? g.pinnedModel : "",
          groundingEnabled: g.groundingEnabled ?? true,
          // Only treat as "pinned" if org has it set explicitly (vs. inherited).
          groundingModel: "",
          cacheEnabled: g.cacheEnabled ?? true,
          cacheSimilarityThreshold: g.cacheSimilarityThreshold ?? DEFAULTS.cacheSimilarityThreshold,
        };
        setConfig(next);
        setInitial(next);
      }
      setSource(orgSource);
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void load();
  }, [load]);

  const dirty = JSON.stringify(config) !== JSON.stringify(initial);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          generation: {
            pinnedModel: config.pinnedModel.trim() === "" ? null : config.pinnedModel.trim(),
            groundingEnabled: config.groundingEnabled,
            groundingModel:
              config.groundingModel.trim() === "" ? null : config.groundingModel.trim(),
            cacheEnabled: config.cacheEnabled,
            cacheSimilarityThreshold: config.cacheSimilarityThreshold,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error });
        return;
      }
      toast({ title: "Generation settings saved", variant: "success" });
      setInitial(config);
      setSource("org");
      await load();
    } finally {
      setSaving(false);
    }
  }

  async function resetToDefaults() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          generation: {
            pinnedModel: null,
            groundingEnabled: null,
            groundingModel: null,
            cacheEnabled: null,
            cacheSimilarityThreshold: null,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't reset", description: e.error });
        return;
      }
      toast({ title: "Reset to defaults", variant: "success" });
      setConfig(DEFAULTS);
      setInitial(DEFAULTS);
      setSource("default");
      await load();
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <PenLine className="h-4 w-4" />
              Answer generation
              <Badge variant={source === "org" ? "info" : "outline"} className="ml-1 text-[10px]">
                {source === "org" ? "Customized" : "Defaults"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Final drafting, grounding judge, and semantic answer cache. LoRA
              adapter (when set) always wins over the pinned model below.
            </CardDescription>
          </div>
          {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* ----- Simple tier ----- */}
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-1.5">
            <Label className="text-xs" htmlFor="g-model">
              Pinned generation model
            </Label>
            <Input
              id="g-model"
              value={config.pinnedModel}
              onChange={(e) => setConfig({ ...config, pinnedModel: e.target.value })}
              disabled={!canEdit || loading}
              placeholder="Inherit from routing"
              className="h-9 font-mono text-xs"
            />
            <p className="text-[11px] text-muted-foreground">
              Overrides routing tiers (Simple/Complex). LoRA adapter still wins.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Grounding judge</Label>
            <div className="flex h-9 items-center gap-2">
              <input
                type="checkbox"
                id="g-grounding"
                checked={config.groundingEnabled}
                onChange={(e) => setConfig({ ...config, groundingEnabled: e.target.checked })}
                disabled={!canEdit || loading}
                className="h-4 w-4"
              />
              <label htmlFor="g-grounding" className="text-sm">
                Run post-hoc claim check
              </label>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Adds one LLM call per answer. Score gates the review-queue badge.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Semantic cache</Label>
            <div className="flex h-9 items-center gap-2">
              <input
                type="checkbox"
                id="g-cache"
                checked={config.cacheEnabled}
                onChange={(e) => setConfig({ ...config, cacheEnabled: e.target.checked })}
                disabled={!canEdit || loading}
                className="h-4 w-4"
              />
              <label htmlFor="g-cache" className="text-sm">
                Reuse near-duplicate answers
              </label>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Skips drafting when a stored answer is &ge; threshold similar.
            </p>
          </div>
        </div>

        {/* ----- Advanced tier ----- */}
        <div className="rounded-lg border bg-muted/20">
          <button
            type="button"
            onClick={() => setAdvanced((v) => !v)}
            className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:bg-muted/40"
            aria-expanded={advanced}
          >
            <span className="flex items-center gap-1.5">
              {advanced ? (
                <ChevronDown className="h-3.5 w-3.5" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5" />
              )}
              Advanced
            </span>
            <span className="text-[10px] uppercase tracking-wider opacity-70">
              {advanced ? "Hide" : "Show"}
            </span>
          </button>
          {advanced ? (
            <div className="grid gap-4 border-t px-3 py-3 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="g-grounding-model">
                  Grounding judge model
                </Label>
                <Input
                  id="g-grounding-model"
                  value={config.groundingModel}
                  onChange={(e) => setConfig({ ...config, groundingModel: e.target.value })}
                  disabled={!canEdit || loading || !config.groundingEnabled}
                  placeholder={resolvedGroundingModel ? `Currently: ${resolvedGroundingModel}` : "Inherit from extraction"}
                  className={cn(
                    "h-9 font-mono text-xs",
                    !config.groundingEnabled && "opacity-50",
                  )}
                />
                <p className="text-[11px] text-muted-foreground">
                  Structured-output friendly. Falls back to the extraction model.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="g-cache-threshold">
                  Cache similarity threshold ({config.cacheSimilarityThreshold.toFixed(2)})
                </Label>
                <Input
                  id="g-cache-threshold"
                  type="range"
                  min={0.5}
                  max={1}
                  step={0.01}
                  value={config.cacheSimilarityThreshold}
                  onChange={(e) =>
                    setConfig({ ...config, cacheSimilarityThreshold: parseFloat(e.target.value) })
                  }
                  disabled={!canEdit || loading || !config.cacheEnabled}
                  className={cn("h-9", !config.cacheEnabled && "opacity-50")}
                />
                <p className="text-[11px] text-muted-foreground">
                  Higher = stricter hits (fewer reuses, less drift). 0.92 is the platform default.
                </p>
              </div>
            </div>
          ) : null}
        </div>

        {/* ----- Actions ----- */}
        {canEdit ? (
          <div className="flex items-center justify-end gap-2 pt-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={resetToDefaults}
              disabled={saving || (source === "default" && !dirty)}
              title="Clear org overrides and use platform defaults"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset to defaults
            </Button>
            <Button
              variant="gradient"
              size="sm"
              onClick={save}
              disabled={saving || !dirty}
            >
              {saving ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Save className="h-3.5 w-3.5" />
              )}
              Save changes
            </Button>
          </div>
        ) : (
          <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3" />
            Read-only &mdash; ADMIN or OWNER role required to change generation settings.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
