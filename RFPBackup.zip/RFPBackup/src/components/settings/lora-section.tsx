"use client";

// LoRA / fine-tune adapter settings panel (Tier C3).
//
// AutoRFP does NOT train models. This card is a thin wrapper around the
// /api/orgs/[orgId]/lora routes that:
//
//   1. Lets admins download their corpus as OpenAI-format JSONL training
//      data (golden answers + approved responses).
//   2. Lists recommended *external* training providers (informational).
//   3. Lets admins paste back a fine-tuned model name or adapter URL plus
//      informational metadata.
//   4. Runs a one-shot "Test this adapter" call so users can verify the
//      configured adapter actually serves a response.
//
// Admin-only — the parent gates rendering, the API enforces.

import { useCallback, useEffect, useState } from "react";
import {
  Sparkles,
  Download,
  Loader2,
  CheckCircle2,
  XCircle,
  ExternalLink,
  Trash2,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useConfirm } from "@/components/ui/confirm";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";

type Provider = "openai_ft" | "vllm" | "openrouter" | "ollama" | "together" | "other";

interface AdapterMeta {
  baseModel: string;
  rank?: number;
  trainedAt?: string;
  trainSize?: number;
  provider?: Provider;
  notes?: string;
}

interface TestResult {
  ok: boolean;
  model: string;
  ms: number;
  answer?: string;
  error?: string;
}

const PROVIDERS: { id: Provider; label: string; url: string; blurb: string }[] = [
  {
    id: "openai_ft",
    label: "OpenAI Fine-tuning",
    url: "https://platform.openai.com/finetune",
    blurb:
      "Upload the JSONL above, pick a base model, click Create. Paste the resulting ft:… name back here.",
  },
  {
    id: "together",
    label: "Together.ai",
    url: "https://docs.together.ai/docs/fine-tuning-overview",
    blurb:
      "Fine-tune open-weight models (Llama, Mistral) against the same JSONL. Paste the deployed model id back here.",
  },
  {
    id: "vllm",
    label: "Hugging Face AutoTrain / custom vLLM",
    url: "https://huggingface.co/autotrain",
    blurb:
      "Train a LoRA adapter and serve via vLLM. Paste the adapter id (or a file:// path your server can resolve) back here.",
  },
];

const CANNED_TEST_QUESTION =
  "Briefly describe how your organization handles SOC2 compliance.";

export function LoraSection({ orgId }: { orgId: string }) {
  const confirm = useConfirm();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  // Persisted state (what's on the server).
  const [persistedUrl, setPersistedUrl] = useState<string | null>(null);
  const [persistedMeta, setPersistedMeta] = useState<AdapterMeta | null>(null);

  // Form state (what the user is editing).
  const [url, setUrl] = useState("");
  const [baseModel, setBaseModel] = useState("");
  const [rank, setRank] = useState("");
  const [trainedAt, setTrainedAt] = useState("");
  const [trainSize, setTrainSize] = useState("");
  const [provider, setProvider] = useState<Provider | "">("");
  const [notes, setNotes] = useState("");

  // Test-question form state.
  const [testQuestion, setTestQuestion] = useState(CANNED_TEST_QUESTION);
  const [testResult, setTestResult] = useState<TestResult | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/lora`);
      if (!res.ok) {
        toast({ title: "Couldn't load adapter configuration" });
        return;
      }
      const data = (await res.json()) as {
        adapterUrl: string | null;
        adapterMeta: AdapterMeta | null;
      };
      setPersistedUrl(data.adapterUrl);
      setPersistedMeta(data.adapterMeta);
      setUrl(data.adapterUrl ?? "");
      setBaseModel(data.adapterMeta?.baseModel ?? "");
      setRank(data.adapterMeta?.rank != null ? String(data.adapterMeta.rank) : "");
      setTrainedAt(data.adapterMeta?.trainedAt ?? "");
      setTrainSize(
        data.adapterMeta?.trainSize != null ? String(data.adapterMeta.trainSize) : "",
      );
      setProvider((data.adapterMeta?.provider as Provider | undefined) ?? "");
      setNotes(data.adapterMeta?.notes ?? "");
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  async function downloadJsonl(kind: "goldens" | "approved") {
    // Hit the route, force a browser download via blob. We don't trust
    // window.location = … because we want to surface the
    // X-Export-Warning header to the user.
    const res = await fetch(`/api/orgs/${orgId}/lora/export/${kind}`);
    if (!res.ok) {
      toast({ title: `Download failed (${res.status})` });
      return;
    }
    const count = res.headers.get("X-Example-Count") ?? "?";
    const warning = res.headers.get("X-Export-Warning");
    const cd = res.headers.get("Content-Disposition") ?? "";
    const match = /filename="([^"]+)"/.exec(cd);
    const filename = match?.[1] ?? `${kind}.jsonl`;
    const text = await res.text();
    if (!text) {
      toast({
        title: warning ?? `No ${kind} data to export`,
        variant: "default",
      });
      return;
    }
    const blob = new Blob([text], { type: "application/jsonl" });
    const objUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(objUrl);
    toast({
      title: `Downloaded ${count} example(s)`,
      description: warning ?? `Saved to ${filename}.`,
      variant: warning ? "default" : "success",
    });
  }

  async function save() {
    if (!url.trim()) {
      toast({ title: "Enter an adapter URL or model name." });
      return;
    }
    if (!baseModel.trim()) {
      toast({ title: "Enter the base model the adapter was trained from." });
      return;
    }
    setSaving(true);
    try {
      const meta: AdapterMeta = { baseModel: baseModel.trim() };
      if (rank.trim()) {
        const n = Number(rank);
        if (Number.isFinite(n) && n > 0) meta.rank = Math.floor(n);
      }
      if (trainedAt.trim()) meta.trainedAt = trainedAt.trim();
      if (trainSize.trim()) {
        const n = Number(trainSize);
        if (Number.isFinite(n) && n >= 0) meta.trainSize = Math.floor(n);
      }
      if (provider) meta.provider = provider;
      if (notes.trim()) meta.notes = notes.trim();

      const res = await fetch(`/api/orgs/${orgId}/lora`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ adapterUrl: url.trim(), adapterMeta: meta }),
      });
      if (res.ok) {
        toast({ title: "Adapter saved", variant: "success" });
        await refresh();
      } else {
        toast({
          title: "Couldn't save",
          description: (await res.json()).error,
        });
      }
    } finally {
      setSaving(false);
    }
  }

  async function clearAdapter() {
    if (!(await confirm("Generations will fall back to the standard model.", { title: "Clear the adapter?", destructive: true, confirmLabel: "Clear" }))) {
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/lora`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ adapterUrl: null }),
      });
      if (res.ok) {
        toast({ title: "Adapter cleared", variant: "success" });
        await refresh();
        setTestResult(null);
      } else {
        toast({
          title: "Couldn't clear",
          description: (await res.json()).error,
        });
      }
    } finally {
      setSaving(false);
    }
  }

  async function runTest() {
    if (!testQuestion.trim()) {
      toast({ title: "Enter a test question first." });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch(`/api/orgs/${orgId}/lora/test`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ question: testQuestion }),
      });
      const data = (await res.json()) as TestResult;
      setTestResult(data);
      if (!res.ok) {
        toast({ title: "Test failed", description: data.error ?? "" });
      }
    } catch (e) {
      setTestResult({
        ok: false,
        model: persistedUrl ?? "",
        ms: 0,
        error: e instanceof Error ? e.message : String(e),
      });
    } finally {
      setTesting(false);
    }
  }

  const isActive = Boolean(persistedUrl?.trim());

  return (
    <Card id="lora">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          Fine-tuned model adapter
          {isActive ? (
            <Badge
              variant="secondary"
              title={
                persistedMeta
                  ? `Base: ${persistedMeta.baseModel ?? "?"}` +
                    (persistedMeta.trainedAt ? ` · Trained ${persistedMeta.trainedAt}` : "") +
                    (persistedMeta.trainSize ? ` · ${persistedMeta.trainSize} examples` : "")
                  : undefined
              }
            >
              Active
            </Badge>
          ) : null}
        </CardTitle>
        <CardDescription>
          OATI AutoRFP does <strong>not</strong> train models — training happens off-platform. Export
          your data, run a fine-tune with the provider of your choice, then paste the resulting
          model name back here. Every generation in this org will route through your adapter.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-8">
        {/* How it works callout */}
        <div className="rounded-lg border bg-muted/30 p-4 text-sm">
          <div className="mb-2 font-medium">How it works</div>
          <ol className="list-decimal space-y-1 pl-5 text-muted-foreground">
            <li>
              <strong>Export.</strong> Download your golden answers (curated Q/A pairs) and/or
              approved responses as a JSONL file in the OpenAI fine-tune format.
            </li>
            <li>
              <strong>Train externally.</strong> Upload that JSONL to a training provider (OpenAI
              Fine-tuning, Together.ai, Hugging Face AutoTrain, or a self-hosted vLLM stack).
            </li>
            <li>
              <strong>Import.</strong> Paste the resulting model name (e.g. <code>ft:gpt-4o-mini:…</code>)
              or adapter URL below, plus a quick note about how it was trained.
            </li>
          </ol>
        </div>

        {/* Step 1: Downloads */}
        <section>
          <div className="mb-2 text-sm font-medium">Step 1 — Export training data</div>
          <p className="mb-3 text-sm text-muted-foreground">
            Both files use the OpenAI chat-completions fine-tune JSONL format, which most
            providers accept directly. Each line is a self-contained training example.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => void downloadJsonl("goldens")}>
              <Download className="mr-2 h-4 w-4" />
              Download golden answers
            </Button>
            <Button variant="outline" onClick={() => void downloadJsonl("approved")}>
              <Download className="mr-2 h-4 w-4" />
              Download approved responses
            </Button>
          </div>
        </section>

        {/* Step 2: Recommended providers */}
        <section>
          <div className="mb-2 text-sm font-medium">Step 2 — Train (off-platform)</div>
          <p className="mb-3 text-sm text-muted-foreground">
            Pick whichever provider fits your stack. OATI AutoRFP doesn&apos;t care which one — we just
            consume the resulting model id.
          </p>
          <ul className="space-y-2">
            {PROVIDERS.map((p) => (
              <li key={p.id} className="rounded-md border p-3 text-sm">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium">{p.label}</span>
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                  >
                    Docs <ExternalLink className="h-3 w-3" />
                  </a>
                </div>
                <p className="text-xs text-muted-foreground">{p.blurb}</p>
              </li>
            ))}
          </ul>
        </section>

        {/* Step 3: Import adapter */}
        <section>
          <div className="mb-2 text-sm font-medium">Step 3 — Import the adapter</div>
          {loading ? (
            <div className="grid place-items-center py-6">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <Label htmlFor="lora-url">Adapter URL or model name</Label>
                <Input
                  id="lora-url"
                  placeholder="ft:gpt-4o-mini:acme::abc123  •  my-org/sales-lora  •  file:///opt/loras/sales.safetensors"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="lora-base">Base model</Label>
                <Input
                  id="lora-base"
                  placeholder="gpt-4o-mini, llama-3-8b, …"
                  value={baseModel}
                  onChange={(e) => setBaseModel(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="lora-provider">Provider</Label>
                <Select
                  value={provider || undefined}
                  onValueChange={(v) => setProvider(v as Provider)}
                >
                  <SelectTrigger id="lora-provider">
                    <SelectValue placeholder="(optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="openai_ft">OpenAI Fine-tuning</SelectItem>
                    <SelectItem value="together">Together.ai</SelectItem>
                    <SelectItem value="vllm">vLLM (self-hosted)</SelectItem>
                    <SelectItem value="openrouter">OpenRouter</SelectItem>
                    <SelectItem value="ollama">Ollama</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="lora-rank">LoRA rank (optional)</Label>
                <Input
                  id="lora-rank"
                  type="number"
                  placeholder="8"
                  value={rank}
                  onChange={(e) => setRank(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="lora-trainedAt">Trained at (optional)</Label>
                <Input
                  id="lora-trainedAt"
                  type="date"
                  value={trainedAt}
                  onChange={(e) => setTrainedAt(e.target.value)}
                />
              </div>
              <div>
                <Label htmlFor="lora-trainsize">Training set size (optional)</Label>
                <Input
                  id="lora-trainsize"
                  type="number"
                  placeholder="142"
                  value={trainSize}
                  onChange={(e) => setTrainSize(e.target.value)}
                />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="lora-notes">Notes (optional)</Label>
                <Textarea
                  id="lora-notes"
                  placeholder="e.g. v1 — trained on Q1 2026 goldens"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              <div className="sm:col-span-2 flex flex-wrap gap-2">
                <Button onClick={() => void save()} disabled={saving}>
                  {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                  Save adapter
                </Button>
                {isActive ? (
                  <Button
                    variant="ghost"
                    onClick={() => void clearAdapter()}
                    disabled={saving}
                  >
                    <Trash2 className="mr-2 h-4 w-4 text-destructive" />
                    Clear
                  </Button>
                ) : null}
              </div>
            </div>
          )}
        </section>

        {/* Step 4: Test */}
        {isActive ? (
          <section>
            <div className="mb-2 text-sm font-medium">Test this adapter</div>
            <p className="mb-3 text-sm text-muted-foreground">
              Sends a one-shot prompt through your adapter so you can confirm it&apos;s reachable
              and answering. Nothing is saved.
            </p>
            <div className="space-y-2">
              <Textarea
                value={testQuestion}
                onChange={(e) => setTestQuestion(e.target.value)}
                rows={2}
              />
              <Button onClick={() => void runTest()} disabled={testing}>
                {testing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                Run test
              </Button>
            </div>
            {testResult ? (
              <div className="mt-3 rounded-md border bg-muted/20 p-3 text-sm">
                <div className="mb-2 flex items-center gap-2">
                  {testResult.ok ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                  ) : (
                    <XCircle className="h-4 w-4 text-destructive" />
                  )}
                  <span className="font-medium">
                    {testResult.ok ? "Adapter responded" : "Adapter failed"}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    {testResult.model} · {testResult.ms}ms
                  </span>
                </div>
                <pre className="whitespace-pre-wrap break-words font-sans text-sm">
                  {testResult.answer ?? testResult.error}
                </pre>
              </div>
            ) : null}
          </section>
        ) : null}
      </CardContent>
    </Card>
  );
}
