"use client";

// Chat Provider settings panel (Phase E).
//
// Lets admins route chat traffic through either:
//   • INTERNAL — current runChatTurn / Agent toggle (default)
//   • OATI_USER_PROMPT — POST {prompt, conversation_id, metadata} to a
//     remote /UserPrompt endpoint
//
// When OATI is selected, the chat UI's Tools + Agent toggles are ignored
// server-side (the remote service owns retrieval + tool use). Metadata
// defaults (client/product/data_source/source + enable_* flags) are merged
// into every request body.

import { useCallback, useEffect, useState } from "react";
import {
  MessageSquare,
  Loader2,
  ChevronDown,
  ChevronRight,
  Save,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

const KEEP_EXISTING_SECRET = "__KEEP__";

type Kind = "INTERNAL" | "OATI_USER_PROMPT";

interface Metadata {
  user_id?: number | null;
  organization_id?: number | null;
  user_name?: string;
  user_timezone?: string;
  client?: string;
  product?: string;
  data_source?: string[]; // edited as comma-separated string in UI
  source?: string;
  enable_query_analyzer?: boolean;
  enable_follow_up?: boolean;
  enable_abbreviation?: boolean;
  json_stream?: boolean;
}

interface ChatProviderConfig {
  kind: Kind;
  endpoint: string;
  apiKey: string;
  metadata: Metadata;
  /** UI-only mirror of metadata.data_source as a comma-separated string. */
  dataSourceCsv: string;
}

interface Props {
  orgId: string;
  canEdit: boolean;
}

const DEFAULTS: ChatProviderConfig = {
  kind: "INTERNAL",
  endpoint: "",
  apiKey: "",
  metadata: {
    enable_query_analyzer: true,
    enable_follow_up: true,
    enable_abbreviation: true,
    json_stream: false,
  },
  dataSourceCsv: "",
};

export function ChatProviderSection({ orgId, canEdit }: Props) {
  const [config, setConfig] = useState<ChatProviderConfig>(DEFAULTS);
  const [initial, setInitial] = useState<ChatProviderConfig>(DEFAULTS);
  const [hasKey, setHasKey] = useState(false);
  const [keyMasked, setKeyMasked] = useState("");
  const [source, setSource] = useState<"org" | "default">("default");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [advanced, setAdvanced] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`);
      if (!res.ok) return;
      const body = await res.json();
      const c = body.config?.chatProvider;
      if (c) {
        setHasKey(Boolean(c.hasApiKey));
        setKeyMasked(c.apiKeyMasked ?? "");
        const md: Metadata = c.metadata ?? {};
        const next: ChatProviderConfig = {
          kind: (c.kind ?? "INTERNAL") as Kind,
          endpoint: c.endpoint ?? "",
          apiKey: c.hasApiKey ? KEEP_EXISTING_SECRET : "",
          metadata: {
            ...DEFAULTS.metadata,
            ...md,
          },
          dataSourceCsv: Array.isArray(md.data_source) ? md.data_source.join(", ") : "",
        };
        setConfig(next);
        setInitial(next);
      }
      setSource(body.config?.source?.chatProvider ?? "default");
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void load();
  }, [load]);

  const dirty = JSON.stringify(config) !== JSON.stringify(initial);
  const isExternal = config.kind !== "INTERNAL";

  function metadataForSave(): Metadata {
    return {
      user_id: typeof config.metadata.user_id === "number" ? config.metadata.user_id : null,
      organization_id:
        typeof config.metadata.organization_id === "number"
          ? config.metadata.organization_id
          : null,
      user_name: config.metadata.user_name?.trim() || undefined,
      user_timezone: config.metadata.user_timezone?.trim() || undefined,
      client: config.metadata.client?.trim() || undefined,
      product: config.metadata.product?.trim() || undefined,
      data_source: config.dataSourceCsv
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
      source: config.metadata.source?.trim() || undefined,
      enable_query_analyzer: !!config.metadata.enable_query_analyzer,
      enable_follow_up: !!config.metadata.enable_follow_up,
      enable_abbreviation: !!config.metadata.enable_abbreviation,
      json_stream: !!config.metadata.json_stream,
    };
  }

  async function save() {
    if (isExternal && !config.endpoint.trim()) {
      toast({ title: "Endpoint URL is required for external chat" });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          chatProvider: {
            kind: config.kind,
            endpoint: config.endpoint.trim() === "" ? null : config.endpoint.trim(),
            apiKey: config.apiKey,
            metadata: metadataForSave(),
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error });
        return;
      }
      toast({ title: "Chat provider saved", variant: "success" });
      await load();
    } finally {
      setSaving(false);
    }
  }

  async function resetToDefaults() {
    setSaving(true);
    try {
      await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          chatProvider: { kind: "INTERNAL", endpoint: null, apiKey: null, metadata: {} },
        }),
      });
      toast({ title: "Reset to internal chat", variant: "success" });
      setConfig(DEFAULTS);
      setInitial(DEFAULTS);
      setHasKey(false);
      setKeyMasked("");
      setSource("default");
      await load();
    } finally {
      setSaving(false);
    }
  }

  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  async function testConnection() {
    if (!isExternal || !config.endpoint.trim()) {
      setTestResult({ ok: false, message: "Set endpoint first" });
      return;
    }
    setTesting(true);
    setTestResult(null);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config/chat-test`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          endpoint: config.endpoint.trim(),
          apiKey: config.apiKey === KEEP_EXISTING_SECRET ? null : config.apiKey,
          metadata: metadataForSave(),
        }),
      });
      const body = await res.json().catch(() => ({}));
      setTestResult({ ok: !!body.ok, message: body.message ?? `HTTP ${res.status}` });
    } finally {
      setTesting(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              Chat Provider
              <Badge variant={source === "org" ? "info" : "outline"} className="ml-1 text-[10px]">
                {source === "org" ? "External" : "Internal (default)"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Route chat through this app&apos;s built-in agent + RAG, or delegate
              to an external endpoint (e.g. OATI&apos;s <code>/UserPrompt</code>).
              When external, the chat UI&apos;s Tools + Agent toggles are ignored —
              the remote service owns retrieval and tool calls.
            </CardDescription>
          </div>
          {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="space-y-1.5">
          <Label className="text-xs">Provider mode</Label>
          <Select
            value={config.kind}
            onValueChange={(v) => setConfig({ ...config, kind: v as Kind })}
            disabled={!canEdit || loading}
          >
            <SelectTrigger className="h-9 max-w-md"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="INTERNAL">Internal (default) — runChatTurn + Agent toggle</SelectItem>
              <SelectItem value="OATI_USER_PROMPT">OATI UserPrompt — POST to /UserPrompt</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isExternal ? (
          <>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="chat-endpoint">Endpoint URL</Label>
                <Input
                  id="chat-endpoint"
                  type="url"
                  value={config.endpoint}
                  onChange={(e) => setConfig({ ...config, endpoint: e.target.value })}
                  disabled={!canEdit || loading}
                  placeholder="http://aniketsa-d.dev.oati.local/network_api/api/v1/UserPrompt"
                  className="h-9 font-mono text-xs"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="chat-key">API key (sent as Bearer, optional)</Label>
                <Input
                  id="chat-key"
                  type="password"
                  value={config.apiKey === KEEP_EXISTING_SECRET ? keyMasked : config.apiKey}
                  onChange={(e) => setConfig({ ...config, apiKey: e.target.value })}
                  disabled={!canEdit || loading}
                  placeholder={hasKey ? "Key stored (paste to replace)" : "Optional"}
                  className="h-9 font-mono text-xs"
                />
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="chat-client">client</Label>
                <Input
                  id="chat-client"
                  value={config.metadata.client ?? ""}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, client: e.target.value } })
                  }
                  disabled={!canEdit || loading}
                  placeholder="AutoRFP"
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="chat-product">product</Label>
                <Input
                  id="chat-product"
                  value={config.metadata.product ?? ""}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, product: e.target.value } })
                  }
                  disabled={!canEdit || loading}
                  placeholder="OATI AutoRFP"
                  className="h-9"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="chat-source">source</Label>
                <Input
                  id="chat-source"
                  value={config.metadata.source ?? ""}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, source: e.target.value } })
                  }
                  disabled={!canEdit || loading}
                  placeholder="chat"
                  className="h-9"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs" htmlFor="chat-ds">data_source (comma-separated)</Label>
              <Input
                id="chat-ds"
                value={config.dataSourceCsv}
                onChange={(e) => setConfig({ ...config, dataSourceCsv: e.target.value })}
                disabled={!canEdit || loading}
                placeholder="kb-primary, soc2-2025, rfp-archive"
                className="h-9 font-mono text-xs"
              />
              <p className="text-[11px] text-muted-foreground">
                Sent as <code>metadata.data_source</code> on every request.
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  id="chat-qa"
                  checked={!!config.metadata.enable_query_analyzer}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, enable_query_analyzer: e.target.checked } })
                  }
                  disabled={!canEdit || loading}
                  className="h-4 w-4"
                />
                <label htmlFor="chat-qa">enable_query_analyzer</label>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  id="chat-fu"
                  checked={!!config.metadata.enable_follow_up}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, enable_follow_up: e.target.checked } })
                  }
                  disabled={!canEdit || loading}
                  className="h-4 w-4"
                />
                <label htmlFor="chat-fu">enable_follow_up</label>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  id="chat-abbr"
                  checked={!!config.metadata.enable_abbreviation}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, enable_abbreviation: e.target.checked } })
                  }
                  disabled={!canEdit || loading}
                  className="h-4 w-4"
                />
                <label htmlFor="chat-abbr">enable_abbreviation</label>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  id="chat-stream"
                  checked={!!config.metadata.json_stream}
                  onChange={(e) =>
                    setConfig({ ...config, metadata: { ...config.metadata, json_stream: e.target.checked } })
                  }
                  disabled={!canEdit || loading}
                  className="h-4 w-4"
                />
                <label htmlFor="chat-stream">json_stream</label>
              </div>
            </div>

            <div className="rounded-lg border bg-muted/20">
              <button
                type="button"
                onClick={() => setAdvanced((v) => !v)}
                className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:bg-muted/40"
                aria-expanded={advanced}
              >
                <span className="flex items-center gap-1.5">
                  {advanced ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
                  Advanced — user_id / org_id / timezone overrides
                </span>
                <span className="text-[10px] uppercase tracking-wider opacity-70">{advanced ? "Hide" : "Show"}</span>
              </button>
              {advanced ? (
                <div className="grid gap-4 border-t px-3 py-3 md:grid-cols-2">
                  <div className="space-y-1.5">
                    <Label className="text-xs">user_id (int)</Label>
                    <Input
                      type="number"
                      value={config.metadata.user_id ?? ""}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          metadata: {
                            ...config.metadata,
                            user_id: e.target.value === "" ? null : parseInt(e.target.value, 10),
                          },
                        })
                      }
                      disabled={!canEdit || loading}
                      placeholder="0"
                      className="h-9"
                    />
                    <p className="text-[11px] text-muted-foreground">Default 0. OATI&apos;s API expects int.</p>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">organization_id (int)</Label>
                    <Input
                      type="number"
                      value={config.metadata.organization_id ?? ""}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          metadata: {
                            ...config.metadata,
                            organization_id: e.target.value === "" ? null : parseInt(e.target.value, 10),
                          },
                        })
                      }
                      disabled={!canEdit || loading}
                      placeholder="0"
                      className="h-9"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">user_name override (optional)</Label>
                    <Input
                      value={config.metadata.user_name ?? ""}
                      onChange={(e) =>
                        setConfig({ ...config, metadata: { ...config.metadata, user_name: e.target.value } })
                      }
                      disabled={!canEdit || loading}
                      placeholder="(defaults to caller's name)"
                      className="h-9"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-xs">user_timezone</Label>
                    <Input
                      value={config.metadata.user_timezone ?? ""}
                      onChange={(e) =>
                        setConfig({ ...config, metadata: { ...config.metadata, user_timezone: e.target.value } })
                      }
                      disabled={!canEdit || loading}
                      placeholder="UTC"
                      className="h-9"
                    />
                  </div>
                </div>
              ) : null}
            </div>

            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={testConnection}
                disabled={!canEdit || testing || !config.endpoint.trim()}
              >
                {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
                Test connection
              </Button>
              {testResult ? (
                <span className={cn(
                  "text-[11px]",
                  testResult.ok ? "text-emerald-600 dark:text-emerald-300" : "text-destructive",
                )}>
                  {testResult.ok ? "✓" : "✗"} {testResult.message}
                </span>
              ) : null}
            </div>

            <p className="flex items-center gap-1.5 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[11px] text-amber-700 dark:text-amber-300">
              <AlertTriangle className="h-3 w-3 shrink-0" />
              When external is on, chat Tools + Agent toggles are ignored. follow_up_questions and references from the remote response are stored on the assistant message&apos;s metadata.
            </p>
          </>
        ) : null}

        {canEdit ? (
          <div className="flex items-center justify-end gap-2 pt-1">
            <Button variant="ghost" size="sm" onClick={resetToDefaults} disabled={saving || source === "default"}>
              <RotateCcw className="h-3.5 w-3.5" /> Reset to internal
            </Button>
            <Button variant="gradient" size="sm" onClick={save} disabled={saving || !dirty}>
              {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
              Save changes
            </Button>
          </div>
        ) : (
          <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3" /> Read-only — ADMIN or OWNER role required.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
