"use client";

// RAG & Retrieval settings panel (Phase A).
//
// Lets admins control the retrieval layer that feeds answer generation:
//   - Strategy: Hybrid (dense + sparse + RRF, default) | Dense-only | Sparse-only
//   - Reranker: None | LLM (current behavior, costs tokens) | Cross-encoder (local, free)
//   - Final top-K returned to the generator
//
// Two-tier layout: the basics are visible by default; the "Advanced" section
// (RRF k, dense weight, reranker model id, reranker candidate pool) collapses
// behind a toggle so admins aren't drowned in knobs they rarely touch.
//
// Defaults preserve current behavior so flipping nothing changes nothing.

import { useCallback, useEffect, useState } from "react";
import {
  Layers,
  Loader2,
  ChevronDown,
  ChevronRight,
  Sparkles,
  Save,
  RotateCcw,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

type Strategy = "HYBRID" | "DENSE_ONLY" | "SPARSE_ONLY";
type Reranker = "NONE" | "LLM" | "CROSS_ENCODER";

interface RetrievalConfig {
  strategy: Strategy;
  rerankerKind: Reranker;
  rerankerModel: string;
  rerankerTopK: number;
  topK: number;
  rrfK: number;
  denseWeight: number;
  contextualEnabled: boolean;
}

interface Props {
  orgId: string;
  canEdit: boolean;
}

// Defaults match the resolver's fallbacks. Used to render before the GET
// resolves and as the "Reset to defaults" target.
const DEFAULTS: RetrievalConfig = {
  strategy: "HYBRID",
  rerankerKind: "LLM",
  rerankerModel: "BAAI/bge-reranker-v2-m3",
  rerankerTopK: 20,
  topK: 8,
  rrfK: 60,
  denseWeight: 0.5,
  contextualEnabled: false,
};

export function RagRetrievalSection({ orgId, canEdit }: Props) {
  const [config, setConfig] = useState<RetrievalConfig>(DEFAULTS);
  const [initial, setInitial] = useState<RetrievalConfig>(DEFAULTS);
  const [source, setSource] = useState<"org" | "default">("default");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [advanced, setAdvanced] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`);
      if (!res.ok) return;
      const body = await res.json();
      const r = body.config?.retrieval;
      if (r) {
        const next: RetrievalConfig = {
          strategy: r.strategy ?? DEFAULTS.strategy,
          rerankerKind: r.rerankerKind ?? DEFAULTS.rerankerKind,
          rerankerModel: r.rerankerModel ?? DEFAULTS.rerankerModel,
          rerankerTopK: r.rerankerTopK ?? DEFAULTS.rerankerTopK,
          topK: r.topK ?? DEFAULTS.topK,
          rrfK: r.rrfK ?? DEFAULTS.rrfK,
          denseWeight: r.denseWeight ?? DEFAULTS.denseWeight,
          contextualEnabled: r.contextualEnabled ?? DEFAULTS.contextualEnabled,
        };
        setConfig(next);
        setInitial(next);
      }
      setSource(body.config?.source?.retrieval ?? "default");
    } finally {
      setLoading(false);
    }
  }, [orgId]);

  useEffect(() => {
    void load();
  }, [load]);

  const dirty = JSON.stringify(config) !== JSON.stringify(initial);

  async function save() {
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ retrieval: config }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error });
        return;
      }
      toast({ title: "Retrieval settings saved", variant: "success" });
      setInitial(config);
      setSource("org");
    } finally {
      setSaving(false);
    }
  }

  async function resetToDefaults() {
    // null on every field clears the org override → resolver falls back to defaults.
    setSaving(true);
    try {
      const res = await fetch(`/api/orgs/${orgId}/ai-config`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          retrieval: {
            strategy: null,
            rerankerKind: null,
            rerankerModel: null,
            rerankerTopK: null,
            topK: null,
            rrfK: null,
            denseWeight: null,
            contextualEnabled: null,
          },
        }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't reset", description: e.error });
        return;
      }
      toast({ title: "Reset to defaults", variant: "success" });
      setConfig(DEFAULTS);
      setInitial(DEFAULTS);
      setSource("default");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Layers className="h-4 w-4" />
              RAG &amp; retrieval
              <Badge variant={source === "org" ? "info" : "outline"} className="ml-1 text-[10px]">
                {source === "org" ? "Customized" : "Defaults"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Controls how the knowledge base is searched before an answer is drafted.
              Defaults match the current behavior &mdash; changing nothing is safe.
            </CardDescription>
          </div>
          {loading ? <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" /> : null}
        </div>
      </CardHeader>
      <CardContent className="space-y-5">
        {/* ----- Simple tier ----- */}
        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-1.5">
            <Label className="text-xs">Search strategy</Label>
            <Select
              value={config.strategy}
              onValueChange={(v) => setConfig({ ...config, strategy: v as Strategy })}
              disabled={!canEdit || loading}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="HYBRID">Hybrid (dense + sparse)</SelectItem>
                <SelectItem value="DENSE_ONLY">Dense only (embeddings)</SelectItem>
                <SelectItem value="SPARSE_ONLY">Sparse only (BM25)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">
              Hybrid catches exact terms <em>and</em> semantic matches.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">Reranker</Label>
            <Select
              value={config.rerankerKind}
              onValueChange={(v) => setConfig({ ...config, rerankerKind: v as Reranker })}
              disabled={!canEdit || loading}
            >
              <SelectTrigger className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="NONE">None (fastest)</SelectItem>
                <SelectItem value="LLM">LLM (costs tokens)</SelectItem>
                <SelectItem value="CROSS_ENCODER">Cross-encoder (local, free)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">
              Reordering the first pass is the single biggest quality lever.
            </p>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs" htmlFor="topk">
              Final top-K
            </Label>
            <Input
              id="topk"
              type="number"
              min={1}
              max={50}
              value={config.topK}
              onChange={(e) =>
                setConfig({ ...config, topK: clampInt(e.target.value, 1, 50, DEFAULTS.topK) })
              }
              disabled={!canEdit || loading}
              className="h-9"
            />
            <p className="text-[11px] text-muted-foreground">
              Chunks handed to the answer model. More = richer context, slower.
            </p>
          </div>
        </div>

        {/* ----- Advanced tier ----- */}
        <div className="rounded-lg border bg-muted/20">
          <button
            type="button"
            onClick={() => setAdvanced((v) => !v)}
            className="flex w-full items-center justify-between px-3 py-2 text-left text-xs font-medium text-muted-foreground hover:bg-muted/40"
            aria-expanded={advanced}
          >
            <span className="flex items-center gap-1.5">
              {advanced ? (
                <ChevronDown className="h-3.5 w-3.5" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5" />
              )}
              Advanced
            </span>
            <span className="text-[10px] uppercase tracking-wider opacity-70">
              {advanced ? "Hide" : "Show"}
            </span>
          </button>
          {advanced ? (
            <div className="grid gap-4 border-t px-3 py-3 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="rerankerModel">
                  Cross-encoder model
                </Label>
                <Input
                  id="rerankerModel"
                  value={config.rerankerModel}
                  onChange={(e) => setConfig({ ...config, rerankerModel: e.target.value })}
                  disabled={!canEdit || loading || config.rerankerKind !== "CROSS_ENCODER"}
                  placeholder="BAAI/bge-reranker-v2-m3"
                  className={cn(
                    "h-9 text-xs",
                    config.rerankerKind !== "CROSS_ENCODER" && "opacity-50",
                  )}
                />
                <p className="text-[11px] text-muted-foreground">
                  HuggingFace model id. Only used when reranker is Cross-encoder.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="rerankerTopK">
                  Rerank candidate pool
                </Label>
                <Input
                  id="rerankerTopK"
                  type="number"
                  min={1}
                  max={200}
                  value={config.rerankerTopK}
                  onChange={(e) =>
                    setConfig({
                      ...config,
                      rerankerTopK: clampInt(e.target.value, 1, 200, DEFAULTS.rerankerTopK),
                    })
                  }
                  disabled={!canEdit || loading || config.rerankerKind === "NONE"}
                  className={cn("h-9", config.rerankerKind === "NONE" && "opacity-50")}
                />
                <p className="text-[11px] text-muted-foreground">
                  How many first-pass hits the reranker scores before truncating to top-K.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="rrfK">
                  RRF k constant
                </Label>
                <Input
                  id="rrfK"
                  type="number"
                  min={1}
                  max={1000}
                  value={config.rrfK}
                  onChange={(e) =>
                    setConfig({ ...config, rrfK: clampInt(e.target.value, 1, 1000, DEFAULTS.rrfK) })
                  }
                  disabled={!canEdit || loading || config.strategy !== "HYBRID"}
                  className={cn("h-9", config.strategy !== "HYBRID" && "opacity-50")}
                />
                <p className="text-[11px] text-muted-foreground">
                  Reciprocal-rank fusion constant. Lower = more aggressive top-rank emphasis.
                </p>
              </div>

              <div className="space-y-1.5 md:col-span-2">
                <Label className="text-xs">Contextual retrieval (ingest-time)</Label>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="contextualEnabled"
                    checked={config.contextualEnabled}
                    onChange={(e) =>
                      setConfig({ ...config, contextualEnabled: e.target.checked })
                    }
                    disabled={!canEdit || loading}
                    className="h-4 w-4"
                  />
                  <label htmlFor="contextualEnabled" className="text-sm">
                    Prepend an LLM-generated context blurb to every chunk before embedding
                  </label>
                </div>
                <p className="text-[11px] text-muted-foreground">
                  Anthropic&apos;s 2024 technique &mdash; +10-30% recall@10 on long technical docs.
                  Costs one LLM call per chunk at <strong>ingest time only</strong> (not per query).
                  Existing chunks aren&apos;t backfilled; only newly-ingested documents pick this up.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs" htmlFor="denseWeight">
                  Dense weight ({config.denseWeight.toFixed(2)})
                </Label>
                <Input
                  id="denseWeight"
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={config.denseWeight}
                  onChange={(e) =>
                    setConfig({ ...config, denseWeight: parseFloat(e.target.value) })
                  }
                  disabled={!canEdit || loading || config.strategy !== "HYBRID"}
                  className={cn("h-9", config.strategy !== "HYBRID" && "opacity-50")}
                />
                <p className="text-[11px] text-muted-foreground">
                  0 = pure BM25, 1 = pure embeddings, 0.5 = balanced.
                </p>
              </div>
            </div>
          ) : null}
        </div>

        {/* ----- Actions ----- */}
        {canEdit ? (
          <div className="flex items-center justify-end gap-2 pt-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={resetToDefaults}
              disabled={saving || (source === "default" && !dirty)}
              title="Clear org overrides and use platform defaults"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              Reset to defaults
            </Button>
            <Button
              variant="gradient"
              size="sm"
              onClick={save}
              disabled={saving || !dirty}
            >
              {saving ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Save className="h-3.5 w-3.5" />
              )}
              Save changes
            </Button>
          </div>
        ) : (
          <p className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3" />
            Read-only &mdash; ADMIN or OWNER role required to change retrieval settings.
          </p>
        )}
      </CardContent>
    </Card>
  );
}

function clampInt(raw: string, min: number, max: number, fallback: number): number {
  const n = parseInt(raw, 10);
  if (Number.isNaN(n)) return fallback;
  if (n < min) return min;
  if (n > max) return max;
  return n;
}
