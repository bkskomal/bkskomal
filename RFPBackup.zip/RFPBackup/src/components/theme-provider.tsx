"use client";

import { createContext, useContext, useEffect, useState } from "react";

// 4 explicit themes plus "system" (follow OS preference between light/dark).
// Solarized variants are NOT system-driven — picking them is an explicit
// user choice.
export type Theme =
  | "light"
  | "dark"
  | "solarized-light"
  | "solarized-dark"
  | "system";

export type ResolvedTheme = "light" | "dark" | "solarized-light" | "solarized-dark";

interface ThemeContextValue {
  theme: Theme;
  resolvedTheme: ResolvedTheme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

const STORAGE_KEY = "autorfp.theme";

function getSystemTheme(): "light" | "dark" {
  if (typeof window === "undefined") return "light";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function applyThemeClasses(resolved: ResolvedTheme) {
  const html = document.documentElement;
  // Strip every theme-bearing class first so toggling is idempotent.
  html.classList.remove("dark", "solarized-light", "solarized-dark");
  if (resolved === "dark") {
    html.classList.add("dark");
  } else if (resolved === "solarized-light") {
    html.classList.add("solarized-light");
  } else if (resolved === "solarized-dark") {
    // Keep `.dark` on for solarized-dark so every Tailwind `dark:`
    // utility still resolves to the dark variant.
    html.classList.add("dark", "solarized-dark");
  }
  // "light" → no classes (the default `:root` palette wins).
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("system");
  const [resolvedTheme, setResolvedTheme] = useState<ResolvedTheme>("light");

  useEffect(() => {
    const saved = (localStorage.getItem(STORAGE_KEY) as Theme | null) ?? "system";
    setThemeState(saved);
  }, []);

  useEffect(() => {
    const resolved: ResolvedTheme = theme === "system" ? getSystemTheme() : theme;
    setResolvedTheme(resolved);
    applyThemeClasses(resolved);
  }, [theme]);

  useEffect(() => {
    if (theme !== "system") return;
    const m = window.matchMedia("(prefers-color-scheme: dark)");
    const handler = () => {
      const next: ResolvedTheme = m.matches ? "dark" : "light";
      setResolvedTheme(next);
      applyThemeClasses(next);
    };
    m.addEventListener("change", handler);
    return () => m.removeEventListener("change", handler);
  }, [theme]);

  const setTheme = (t: Theme) => {
    localStorage.setItem(STORAGE_KEY, t);
    setThemeState(t);
  };

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}
