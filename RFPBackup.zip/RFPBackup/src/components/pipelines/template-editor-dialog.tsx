"use client";

import { useEffect, useState } from "react";
import {
  Plus,
  Trash2,
  GripVertical,
  ChevronUp,
  ChevronDown,
  Save,
  Loader2,
  Sparkles,
  Info,
} from "lucide-react";
import { PipelineStepKind, PipelineStepMode } from "@prisma/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface CatalogEntry {
  kind: PipelineStepKind;
  label: string;
  description: string;
  defaultMode: PipelineStepMode;
  allowedModes: PipelineStepMode[];
  configHint?: string;
  marker?: boolean;
}

interface StepDraft {
  kind: PipelineStepKind;
  label: string;
  description?: string;
  mode: PipelineStepMode;
  config?: Record<string, unknown>;
}

interface Props {
  orgId: string;
  templateId: string | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onSaved: () => void;
}

export function TemplateEditorDialog({ orgId, templateId, open, onOpenChange, onSaved }: Props) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isDefault, setIsDefault] = useState(false);
  const [steps, setSteps] = useState<StepDraft[]>([]);
  const [catalog, setCatalog] = useState<Record<string, CatalogEntry>>({});
  const [fallback, setFallback] = useState<StepDraft[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Load catalog (always) + the template being edited (if any) when opened.
  useEffect(() => {
    if (!open) return;
    let cancel = false;
    setLoading(true);
    (async () => {
      const [catRes, tplRes] = await Promise.all([
        fetch(`/api/orgs/${orgId}/pipeline-templates`).then((r) => r.json()),
        templateId
          ? fetch(`/api/pipeline-templates/${templateId}`).then((r) => r.json())
          : Promise.resolve(null),
      ]);
      if (cancel) return;
      setCatalog(catRes.catalog ?? {});
      setFallback(catRes.fallback ?? []);
      if (tplRes?.template) {
        const t = tplRes.template;
        setName(t.name);
        setDescription(t.description ?? "");
        setIsDefault(t.isDefault);
        setSteps(t.steps as StepDraft[]);
      } else {
        // Creating a new template — start from the canonical fallback.
        setName("");
        setDescription("");
        setIsDefault(false);
        setSteps(catRes.fallback as StepDraft[]);
      }
      setLoading(false);
    })();
    return () => {
      cancel = true;
    };
  }, [open, orgId, templateId]);

  function move(i: number, delta: number) {
    const j = i + delta;
    if (j < 0 || j >= steps.length) return;
    setSteps((prev) => {
      const next = prev.slice();
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  }

  function remove(i: number) {
    setSteps((prev) => prev.filter((_, idx) => idx !== i));
  }

  function update(i: number, patch: Partial<StepDraft>) {
    setSteps((prev) => prev.map((s, idx) => (idx === i ? { ...s, ...patch } : s)));
  }

  function addStep(kind: PipelineStepKind) {
    const meta = catalog[kind];
    if (!meta) return;
    setSteps((prev) => [
      ...prev,
      {
        kind,
        label: meta.label,
        description: meta.description,
        mode: meta.defaultMode,
        config: defaultConfigFor(kind),
      },
    ]);
  }

  async function save() {
    setSaving(true);
    try {
      const url = templateId
        ? `/api/pipeline-templates/${templateId}`
        : `/api/orgs/${orgId}/pipeline-templates`;
      const method = templateId ? "PATCH" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ name, description, steps, isDefault }),
      });
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        toast({ title: "Couldn't save", description: e.error ?? "Unknown error" });
        return;
      }
      toast({ title: "Template saved", variant: "success" });
      onSaved();
      onOpenChange(false);
    } finally {
      setSaving(false);
    }
  }

  // The "Add step" menu shows every available kind.
  const availableKinds = Object.values(catalog) as CatalogEntry[];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] grid grid-rows-[auto_1fr_auto] gap-0 p-0">
        <DialogHeader className="border-b px-6 py-4">
          <DialogTitle>{templateId ? "Edit template" : "New workflow template"}</DialogTitle>
          <DialogDescription>
            Reorder, add, or remove steps. Each step's mode controls whether it runs automatically or
            waits for a human.
          </DialogDescription>
        </DialogHeader>

        <div className="scrollbar-thin overflow-y-auto px-6 py-4 space-y-4">
          {loading ? (
            <div className="grid place-items-center py-12">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              <div className="grid gap-3 md:grid-cols-2">
                <div className="space-y-1">
                  <Label htmlFor="tpl-name">Name</Label>
                  <Input
                    id="tpl-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Healthcare RFP Workflow"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="invisible md:visible">Default</Label>
                  <label className="flex items-center gap-2 text-sm h-9">
                    <input
                      type="checkbox"
                      checked={isDefault}
                      onChange={(e) => setIsDefault(e.target.checked)}
                      className="h-4 w-4"
                    />
                    Use as the organization's default template
                  </label>
                </div>
              </div>
              <div className="space-y-1">
                <Label htmlFor="tpl-desc">Description (optional)</Label>
                <Textarea
                  id="tpl-desc"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder="What's different about this workflow?"
                />
              </div>

              <div>
                <div className="mb-2 flex items-center justify-between">
                  <Label>Steps ({steps.length})</Label>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="sm" variant="outline">
                        <Plus className="h-3.5 w-3.5" /> Add step
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="max-h-80 overflow-y-auto">
                      <DropdownMenuLabel>Step library</DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      {availableKinds.map((k) => (
                        <DropdownMenuItem key={k.kind} onClick={() => addStep(k.kind)}>
                          <div className="min-w-0">
                            <div className="text-xs font-medium">{k.label}</div>
                            <div className="text-[10px] text-muted-foreground line-clamp-1">
                              {k.description}
                            </div>
                          </div>
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {steps.length === 0 ? (
                  <div className="grid place-items-center rounded-lg border-2 border-dashed py-8 text-sm text-muted-foreground">
                    No steps. Add at least one.
                  </div>
                ) : (
                  <div className="space-y-2">
                    {steps.map((s, i) => {
                      const meta = catalog[s.kind];
                      return (
                        <StepEditor
                          key={`${s.kind}-${i}`}
                          index={i}
                          step={s}
                          meta={meta}
                          isFirst={i === 0}
                          isLast={i === steps.length - 1}
                          onMoveUp={() => move(i, -1)}
                          onMoveDown={() => move(i, 1)}
                          onRemove={() => remove(i)}
                          onChange={(patch) => update(i, patch)}
                        />
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        <DialogFooter className="border-t px-6 py-3">
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button
            variant="gradient"
            onClick={save}
            disabled={saving || loading || !name.trim() || steps.length === 0}
          >
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Save template
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StepEditor({
  index,
  step,
  meta,
  isFirst,
  isLast,
  onMoveUp,
  onMoveDown,
  onRemove,
  onChange,
}: {
  index: number;
  step: StepDraft;
  meta: CatalogEntry | undefined;
  isFirst: boolean;
  isLast: boolean;
  onMoveUp: () => void;
  onMoveDown: () => void;
  onRemove: () => void;
  onChange: (patch: Partial<StepDraft>) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const allowedModes = meta?.allowedModes ?? ["AUTO", "MANUAL", "DECISION"];

  return (
    <div className={cn("rounded-lg border bg-card", expanded && "ring-2 ring-primary/20")}>
      <div className="flex items-center gap-2 p-2.5">
        <div className="flex flex-col">
          <button
            onClick={onMoveUp}
            disabled={isFirst}
            className="rounded p-0.5 hover:bg-accent disabled:opacity-30"
            title="Move up"
          >
            <ChevronUp className="h-3 w-3" />
          </button>
          <button
            onClick={onMoveDown}
            disabled={isLast}
            className="rounded p-0.5 hover:bg-accent disabled:opacity-30"
            title="Move down"
          >
            <ChevronDown className="h-3 w-3" />
          </button>
        </div>
        <GripVertical className="h-3.5 w-3.5 text-muted-foreground/40" />
        <span className="grid h-6 w-6 place-items-center rounded-full bg-primary/10 text-[10px] font-bold text-primary">
          {String(index + 1).padStart(2, "0")}
        </span>
        <div className="min-w-0 flex-1">
          <button
            onClick={() => setExpanded((v) => !v)}
            className="block w-full text-left"
          >
            <div className="text-sm font-medium truncate">{step.label}</div>
            <div className="text-[10px] text-muted-foreground font-mono">{step.kind}</div>
          </button>
        </div>
        <Select value={step.mode} onValueChange={(v) => onChange({ mode: v as PipelineStepMode })}>
          <SelectTrigger className="h-7 w-[110px] text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {allowedModes.map((m) => (
              <SelectItem key={m} value={m}>
                {m}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button size="icon" variant="ghost" onClick={onRemove}>
          <Trash2 className="h-3.5 w-3.5 text-destructive" />
        </Button>
      </div>
      {expanded ? (
        <div className="border-t bg-muted/30 p-3 space-y-2">
          <div className="space-y-1">
            <Label className="text-xs">Label</Label>
            <Input
              value={step.label}
              onChange={(e) => onChange({ label: e.target.value })}
              className="h-8 text-xs"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Description shown to operators</Label>
            <Textarea
              value={step.description ?? ""}
              onChange={(e) => onChange({ description: e.target.value })}
              rows={2}
              className="text-xs"
            />
          </div>
          {meta?.configHint ? (
            <div className="flex items-start gap-2 rounded-md bg-sky-500/10 p-2 text-xs text-sky-700 dark:text-sky-300">
              <Info className="h-3 w-3 mt-0.5 shrink-0" />
              <div>{meta.configHint}</div>
            </div>
          ) : null}
          <div className="space-y-1">
            <Label className="text-xs">Config (JSON)</Label>
            <Textarea
              value={JSON.stringify(step.config ?? {}, null, 2)}
              onChange={(e) => {
                try {
                  const parsed = JSON.parse(e.target.value || "{}");
                  onChange({ config: parsed });
                } catch {
                  /* ignore parse errors while typing */
                }
              }}
              rows={4}
              className="font-mono text-[10px]"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function defaultConfigFor(kind: PipelineStepKind): Record<string, unknown> {
  switch (kind) {
    case "GENERATE_RESPONSES":
      return { mode: "unanswered", enableTools: true };
    case "CONSOLIDATE_EXPORT":
      return { format: "docx", approvedOnly: true, includeSources: true };
    case "WEBHOOK":
      return { url: "https://example.com/hook" };
    default:
      return {};
  }
}
