"use client";

// Documents panel for the RFP detail page. Renders the primary doc + any
// companion attachments (security questionnaire, addendum, pricing matrix,
// SOW, references), with controls for adding, re-classifying, and removing
// attachments.
//
// State is local to this component. After every mutation we trigger a
// `router.refresh()` so the server-rendered parent picks up the new
// attachment list and cross-reference badges on next paint.

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { FileText, Loader2, Plus, Trash2, Upload } from "lucide-react";
import { RfpDocRole } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { useConfirm } from "@/components/ui/confirm";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/components/ui/use-toast";
import { PricingMatrixViewer } from "@/components/rfp/pricing-matrix-viewer";

export interface AttachmentRow {
  id: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  docRole: RfpDocRole;
  createdAt: string;
}

/** xlsx mime; matches the attachment uploader's accept list. */
const XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

export interface PrimaryDocInfo {
  fileName: string;
  fileSize: number;
}

interface Props {
  rfpId: string;
  primary: PrimaryDocInfo;
  attachments: AttachmentRow[];
}

const ATTACHABLE_ROLES: RfpDocRole[] = [
  RfpDocRole.ADDENDUM,
  RfpDocRole.SECURITY_QUESTIONNAIRE,
  RfpDocRole.PRICING_MATRIX,
  RfpDocRole.SOW,
  RfpDocRole.REFERENCE,
];

const ROLE_LABELS: Record<RfpDocRole, string> = {
  PRIMARY: "Primary",
  ADDENDUM: "Addendum",
  SECURITY_QUESTIONNAIRE: "Security questionnaire",
  PRICING_MATRIX: "Pricing matrix",
  SOW: "SOW",
  REFERENCE: "Reference",
};

const ROLE_VARIANTS: Record<RfpDocRole, "default" | "secondary" | "outline" | "warning" | "info"> = {
  PRIMARY: "default",
  ADDENDUM: "secondary",
  SECURITY_QUESTIONNAIRE: "warning",
  PRICING_MATRIX: "info",
  SOW: "secondary",
  REFERENCE: "outline",
};

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function DocumentsPanel({ rfpId, primary, attachments }: Props) {
  const router = useRouter();
  const [addOpen, setAddOpen] = useState(false);

  // Show the per-cell matrix viewer for each PRICING_MATRIX attachment that
  // is an .xlsx file. Non-xlsx pricing files (PDFs etc.) fall back to the
  // generic preview/listing — the structured cell editor only makes sense
  // when we have an actual grid to parse.
  const matrixAttachments = attachments.filter(
    (a) => a.docRole === RfpDocRole.PRICING_MATRIX && a.mimeType === XLSX_MIME,
  );

  return (
    <div className="space-y-4">
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <div>
          <CardTitle className="text-base">Documents</CardTitle>
          <CardDescription>Primary spec plus any companion documents (questionnaires, addenda, pricing).</CardDescription>
        </div>
        <Button size="sm" variant="gradient" onClick={() => setAddOpen(true)}>
          <Plus className="h-3.5 w-3.5" /> Add document
        </Button>
      </CardHeader>
      <CardContent>
        <div className="overflow-hidden rounded-lg border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs text-muted-foreground">
              <tr>
                <th className="px-3 py-2 text-left font-medium">File</th>
                <th className="px-3 py-2 text-left font-medium">Role</th>
                <th className="px-3 py-2 text-left font-medium">Size</th>
                <th className="px-3 py-2 text-left font-medium">Uploaded</th>
                <th className="px-3 py-2 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              <tr className="bg-primary/5">
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-primary" />
                    <span className="font-medium">{primary.fileName}</span>
                  </div>
                </td>
                <td className="px-3 py-2">
                  <Badge variant="default" className="text-[10px]">PRIMARY</Badge>
                </td>
                <td className="px-3 py-2 text-muted-foreground">{formatBytes(primary.fileSize)}</td>
                <td className="px-3 py-2 text-muted-foreground">—</td>
                <td className="px-3 py-2 text-right text-muted-foreground">—</td>
              </tr>
              {attachments.map((a) => (
                <AttachmentRowView key={a.id} rfpId={rfpId} attachment={a} onChange={() => router.refresh()} />
              ))}
              {attachments.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-3 py-6 text-center text-xs text-muted-foreground">
                    No companion documents yet. Click <strong>Add document</strong> to attach a security questionnaire, addendum, pricing matrix, or other reference.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </CardContent>

      <AddAttachmentDialog
        rfpId={rfpId}
        open={addOpen}
        onOpenChange={setAddOpen}
        onUploaded={() => {
          setAddOpen(false);
          router.refresh();
        }}
      />
    </Card>

    {matrixAttachments.map((a) => (
      <PricingMatrixViewer
        key={a.id}
        rfpId={rfpId}
        attachmentId={a.id}
        fileName={a.fileName}
      />
    ))}
    </div>
  );
}

function AttachmentRowView({
  rfpId,
  attachment,
  onChange,
}: {
  rfpId: string;
  attachment: AttachmentRow;
  onChange: () => void;
}) {
  const [updating, setUpdating] = useState(false);
  const confirm = useConfirm();

  async function reclassify(role: RfpDocRole) {
    setUpdating(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/attachments/${attachment.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ docRole: role }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Couldn't re-classify", description: err.error });
        return;
      }
      toast({ title: `Re-classified to ${ROLE_LABELS[role]}`, variant: "success" });
      onChange();
    } finally {
      setUpdating(false);
    }
  }

  async function remove() {
    if (!(await confirm("This can't be undone.", { title: `Delete ${attachment.fileName}?`, destructive: true, confirmLabel: "Delete" }))) return;
    setUpdating(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/attachments/${attachment.id}`, {
        method: "DELETE",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Couldn't delete", description: err.error });
        return;
      }
      toast({ title: "Attachment deleted", variant: "success" });
      onChange();
    } finally {
      setUpdating(false);
    }
  }

  return (
    <tr>
      <td className="px-3 py-2">
        <div className="flex items-center gap-2">
          <FileText className="h-4 w-4 text-muted-foreground" />
          <span>{attachment.fileName}</span>
        </div>
      </td>
      <td className="px-3 py-2">
        <Badge variant={ROLE_VARIANTS[attachment.docRole]} className="text-[10px]">
          {attachment.docRole}
        </Badge>
      </td>
      <td className="px-3 py-2 text-muted-foreground">{formatBytes(attachment.fileSize)}</td>
      <td className="px-3 py-2 text-muted-foreground">
        {new Date(attachment.createdAt).toLocaleDateString()}
      </td>
      <td className="px-3 py-2">
        <div className="flex items-center justify-end gap-2">
          <Select
            value={attachment.docRole}
            onValueChange={(v) => reclassify(v as RfpDocRole)}
            disabled={updating}
          >
            <SelectTrigger className="h-7 w-[170px] text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ATTACHABLE_ROLES.map((r) => (
                <SelectItem key={r} value={r} className="text-xs">
                  {ROLE_LABELS[r]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button size="sm" variant="ghost" onClick={remove} disabled={updating}>
            {updating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Trash2 className="h-3.5 w-3.5" />}
          </Button>
        </div>
      </td>
    </tr>
  );
}

function AddAttachmentDialog({
  rfpId,
  open,
  onOpenChange,
  onUploaded,
}: {
  rfpId: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onUploaded: () => void;
}) {
  const [docRole, setDocRole] = useState<RfpDocRole>(RfpDocRole.SECURITY_QUESTIONNAIRE);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  async function upload() {
    const file = fileRef.current?.files?.[0];
    if (!file) {
      toast({ title: "Pick a file first" });
      return;
    }
    const fd = new FormData();
    fd.append("file", file);
    fd.append("docRole", docRole);
    setUploading(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/attachments`, {
        method: "POST",
        body: fd,
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Upload failed", description: err.error ?? res.statusText });
        return;
      }
      toast({ title: "Attached", variant: "success" });
      if (fileRef.current) fileRef.current.value = "";
      onUploaded();
    } finally {
      setUploading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add companion document</DialogTitle>
          <DialogDescription>
            Attach an addendum, security questionnaire, pricing matrix, SOW, or reference. The file is parsed and used as supplementary context during response generation.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <label className="block text-sm font-medium">Document role</label>
          <Select value={docRole} onValueChange={(v) => setDocRole(v as RfpDocRole)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {ATTACHABLE_ROLES.map((r) => (
                <SelectItem key={r} value={r}>
                  {ROLE_LABELS[r]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <label className="block text-sm font-medium">File</label>
          <input
            type="file"
            ref={fileRef}
            accept=".pdf,.docx,.doc,.xlsx,.xls,.pptx,.ppt,.txt,.md"
            className="block w-full text-sm"
          />
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={uploading}>
            Cancel
          </Button>
          <Button variant="gradient" onClick={upload} disabled={uploading}>
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Upload
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
