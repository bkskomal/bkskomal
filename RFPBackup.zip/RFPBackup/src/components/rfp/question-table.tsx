"use client";

import { useMemo, useState } from "react";
import {
  CheckCircle2,
  MessageSquare,
  Search,
  Filter,
  Sparkles,
} from "lucide-react";
import { QuestionStatus } from "@prisma/client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { StatusBadge } from "./status-badge";
import { StatusPicker } from "./status-picker";
import { AssigneePicker } from "./assignee-picker";
import { DueDatePill } from "./due-date";
import { cn, truncate } from "@/lib/utils";

export interface QuestionRow {
  id: string;
  number: number;
  section: string | null;
  text: string;
  status: QuestionStatus;
  assignee: { id: string; name: string | null; email: string } | null;
  hasResponse: boolean;
  needsReview: boolean;
  confidence: number | null;
  commentCount: number;
  dueDate: string | null;
}

interface Member {
  userId: string;
  email: string;
  name: string | null;
}

interface Props {
  questions: QuestionRow[];
  members: Member[];
  activeId: string | null;
  selectedIds: Set<string>;
  onSelect: (id: string) => void;
  onToggleSelected: (id: string) => void;
  onToggleAll: () => void;
  onStatusChange: (id: string, status: QuestionStatus) => void;
  onAssigneeChange: (id: string, userId: string | null) => void;
}

const FILTERS: Array<{ key: string; label: string }> = [
  { key: "all", label: "All" },
  { key: "todo", label: "To do" },
  { key: "mine", label: "Assigned to me" },
  { key: "no_response", label: "No response" },
  { key: "needs_review", label: "Needs review" },
  { key: "approved", label: "Approved" },
];

export function QuestionTable(props: Props) {
  const {
    questions,
    members,
    activeId,
    selectedIds,
    onSelect,
    onToggleSelected,
    onToggleAll,
    onStatusChange,
    onAssigneeChange,
  } = props;

  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");

  // Note: "mine" filter resolves the current user via the assignee in the
  // selected questions — but we don't know the current user id here without
  // plumbing. Keep it as best-effort: members[0] is "me" approximation only
  // when consumer doesn't pass it. In practice we rely on direct UI selection.
  const filtered = useMemo(() => {
    let rows = questions;
    if (query.trim()) {
      const q = query.toLowerCase();
      rows = rows.filter(
        (r) =>
          r.text.toLowerCase().includes(q) ||
          (r.section ?? "").toLowerCase().includes(q) ||
          String(r.number).includes(q),
      );
    }
    switch (filter) {
      case "todo":
        rows = rows.filter((r) => r.status === "TODO");
        break;
      case "no_response":
        rows = rows.filter((r) => !r.hasResponse);
        break;
      case "needs_review":
        rows = rows.filter((r) => r.needsReview);
        break;
      case "approved":
        rows = rows.filter((r) => r.status === "APPROVED");
        break;
      // "mine" is handled by a separate prop in the future; for now it's a no-op
    }
    return rows;
  }, [questions, query, filter]);

  const allFilteredSelected =
    filtered.length > 0 && filtered.every((r) => selectedIds.has(r.id));
  const someFilteredSelected =
    !allFilteredSelected && filtered.some((r) => selectedIds.has(r.id));

  return (
    <div className="flex h-full min-h-0 flex-col rounded-xl border bg-card">
      <div className="flex flex-wrap items-center gap-2 border-b p-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter questions…"
            className="h-8 pl-7 text-xs"
          />
        </div>
        <div className="flex items-center gap-1">
          <Filter className="h-3.5 w-3.5 text-muted-foreground" />
          {FILTERS.map((f) => (
            <Button
              key={f.key}
              size="sm"
              variant={filter === f.key ? "default" : "outline"}
              onClick={() => setFilter(f.key)}
              className="h-7 px-2 text-xs"
            >
              {f.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3 border-b bg-muted/30 px-3 py-2 text-xs font-medium text-muted-foreground">
        <Checkbox
          checked={allFilteredSelected}
          indeterminate={someFilteredSelected}
          onCheckedChange={onToggleAll}
        />
        <span className="w-8 text-center">#</span>
        <span className="flex-1">Question</span>
        <span className="w-24">Status</span>
        <span className="w-16">Assignee</span>
        <span className="w-12 text-right">{filtered.length}</span>
      </div>

      <ul className="scrollbar-thin flex-1 overflow-y-auto">
        {filtered.length === 0 ? (
          <li className="grid place-items-center py-12 text-xs text-muted-foreground">
            No matching questions.
          </li>
        ) : (
          filtered.map((q) => {
            const active = q.id === activeId;
            const selected = selectedIds.has(q.id);
            return (
              <li
                key={q.id}
                className={cn(
                  "group flex cursor-pointer items-center gap-3 border-b px-3 py-2 transition-colors hover:bg-accent/40",
                  active && "bg-accent/60",
                  selected && "bg-primary/5",
                )}
                onClick={() => onSelect(q.id)}
              >
                <span onClick={(e) => e.stopPropagation()}>
                  <Checkbox checked={selected} onCheckedChange={() => onToggleSelected(q.id)} />
                </span>
                <span className="w-8 text-center text-xs font-mono text-muted-foreground">
                  {q.number}
                </span>
                <div className="min-w-0 flex-1">
                  {q.section ? (
                    <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      {truncate(q.section, 40)}
                    </div>
                  ) : null}
                  <div className="line-clamp-2 text-sm">{q.text}</div>
                  <div className="mt-1 flex items-center gap-2 text-[10px] text-muted-foreground">
                    {q.hasResponse ? (
                      <span className="inline-flex items-center gap-0.5 text-emerald-600 dark:text-emerald-300">
                        <CheckCircle2 className="h-2.5 w-2.5" /> response
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-0.5">
                        <Sparkles className="h-2.5 w-2.5" /> no response
                      </span>
                    )}
                    {typeof q.confidence === "number" ? (
                      <Badge variant="outline" className="text-[9px] py-0 px-1">
                        {Math.round(q.confidence * 100)}%
                      </Badge>
                    ) : null}
                    {q.needsReview ? (
                      <Badge variant="warning" className="text-[9px] py-0 px-1">
                        review
                      </Badge>
                    ) : null}
                    {q.commentCount > 0 ? (
                      <span className="inline-flex items-center gap-0.5">
                        <MessageSquare className="h-2.5 w-2.5" /> {q.commentCount}
                      </span>
                    ) : null}
                    {q.dueDate ? <DueDatePill dueDate={q.dueDate} size="sm" /> : null}
                  </div>
                </div>
                <div className="w-24" onClick={(e) => e.stopPropagation()}>
                  <StatusPicker
                    status={q.status}
                    onChange={(s) => onStatusChange(q.id, s)}
                    size="sm"
                  />
                </div>
                <div className="w-16" onClick={(e) => e.stopPropagation()}>
                  <AssigneePicker
                    members={members}
                    current={q.assignee}
                    onChange={(uid) => onAssigneeChange(q.id, uid)}
                    size="sm"
                  />
                </div>
              </li>
            );
          })
        )}
      </ul>
    </div>
  );
}
