"use client";

import { useState } from "react";
import {
  CheckCircle2,
  SkipForward,
  RotateCcw,
  Loader2,
  Sparkles,
  AlertCircle,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import { formatDateTime } from "@/lib/utils";
import type { StepRow } from "./pipeline-stepper";

interface Props {
  rfpId: string;
  step: StepRow | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onChanged: () => void;
}

export function PipelineStepDialog({ rfpId: _rfpId, step, open, onOpenChange, onChanged }: Props) {
  const [pending, setPending] = useState(false);
  const [note, setNote] = useState("");

  // For DECISION steps, draft the config the user will commit on "Run".
  const [decisionConfig, setDecisionConfig] = useState<Record<string, unknown>>({});

  if (!step) return null;

  async function call(action: string, body: Record<string, unknown> = {}) {
    if (!step) return;
    setPending(true);
    try {
      const r = await fetch(`/api/pipeline-steps/${step.id}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action, ...body }),
      });
      if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        toast({ title: "Action failed", description: e.error });
        return;
      }
      toast({ title: `Step ${action}`, variant: "success" });
      onChanged();
      onOpenChange(false);
    } finally {
      setPending(false);
    }
  }

  const isManual = step.mode === "MANUAL" && step.status === "WAITING_FOR_INPUT";
  const isDecision = step.mode === "DECISION" && step.status === "WAITING_FOR_INPUT";
  const isFailed = step.status === "FAILED";
  const decisionFields = decisionFieldsFor(step.kind);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="grid h-7 w-7 place-items-center rounded-full bg-primary/10 text-xs font-bold text-primary">
              {String(step.index + 1).padStart(2, "0")}
            </span>
            {step.label}
          </DialogTitle>
          {/* asChild lets DialogDescription forward its a11y attrs to a div
              instead of rendering a <p>. We need a div because the body
              contains Badge (a div) — <p><div/></p> is invalid HTML and
              triggers a hydration error. */}
          <DialogDescription asChild>
            <div className="text-sm text-muted-foreground space-y-1">
              <div>
                <Badge variant="outline" className="text-[10px]">{step.status}</Badge>{" "}
                <Badge variant="outline" className="text-[10px]">{step.mode}</Badge>
                {step.startedAt ? (
                  <span className="text-xs text-muted-foreground">
                    {" "}· started {formatDateTime(step.startedAt)}
                  </span>
                ) : null}
                {step.finishedAt ? (
                  <span className="text-xs text-muted-foreground">
                    {" "}· finished {formatDateTime(step.finishedAt)}
                  </span>
                ) : null}
              </div>
              {step.description ? <div className="text-xs">{step.description}</div> : null}
            </div>
          </DialogDescription>
        </DialogHeader>

        {step.blockedReason && step.status === "WAITING_FOR_INPUT" ? (
          <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-700 dark:text-amber-300">
            <div className="font-medium mb-1">Waiting on you</div>
            <div>{step.blockedReason}</div>
          </div>
        ) : null}

        {isFailed && step.errorMessage ? (
          <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs">
            <div className="flex items-center gap-1 font-medium text-destructive mb-1">
              <AlertCircle className="h-3 w-3" /> Failed
            </div>
            <div className="text-muted-foreground">{step.errorMessage}</div>
          </div>
        ) : null}

        {step.status === "SUCCEEDED" && step.result ? (
          <pre className="scrollbar-thin overflow-auto rounded-lg bg-muted/40 p-3 text-[11px] font-mono">
            {JSON.stringify(step.result, null, 2)}
          </pre>
        ) : null}

        {isManual ? (
          <div className="space-y-2">
            <Label htmlFor="note" className="text-xs">Note (optional)</Label>
            <Textarea
              id="note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="What did you do? Anything to flag?"
              rows={2}
            />
          </div>
        ) : null}

        {isDecision && decisionFields.length > 0 ? (
          <div className="space-y-2">
            <div className="text-xs font-medium">Confirm settings before running:</div>
            {decisionFields.map((f) => (
              <DecisionField
                key={f.key}
                field={f}
                stepConfig={(step.config as Record<string, unknown> | null) ?? {}}
                value={decisionConfig[f.key]}
                onChange={(v) => setDecisionConfig((s) => ({ ...s, [f.key]: v }))}
              />
            ))}
          </div>
        ) : null}

        <DialogFooter className="gap-2 flex-wrap">
          {isFailed ? (
            <Button variant="outline" onClick={() => call("retry")} disabled={pending}>
              <RotateCcw className="h-3.5 w-3.5" /> Retry
            </Button>
          ) : null}
          {(isManual || isDecision || step.status === "WAITING_FOR_INPUT") ? (
            <Button variant="ghost" onClick={() => call("skip")} disabled={pending}>
              <SkipForward className="h-3.5 w-3.5" /> Skip
            </Button>
          ) : null}
          {isManual ? (
            <Button variant="gradient" onClick={() => call("complete", { note })} disabled={pending}>
              {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
              Mark complete
            </Button>
          ) : null}
          {isDecision ? (
            <Button
              variant="gradient"
              onClick={() => call("decide", { config: decisionConfig })}
              disabled={pending}
            >
              {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
              Run with these settings
            </Button>
          ) : null}
          <Button variant="ghost" onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

interface DecisionField {
  key: string;
  label: string;
  type: "select" | "text" | "boolean";
  options?: { value: string; label: string }[];
  default?: unknown;
}

function decisionFieldsFor(kind: string): DecisionField[] {
  switch (kind) {
    case "GENERATE_RESPONSES":
      return [
        {
          key: "mode",
          label: "Which questions to generate",
          type: "select",
          options: [
            { value: "unanswered", label: "Only unanswered (recommended)" },
            { value: "all", label: "All questions (overwrites existing)" },
            { value: "low_confidence", label: "Only low-confidence (< 55%)" },
          ],
          default: "unanswered",
        },
      ];
    case "CONSOLIDATE_EXPORT":
      return [
        {
          key: "approvedOnly",
          label: "Approved questions only",
          type: "boolean",
          default: true,
        },
        {
          key: "includeSources",
          label: "Include source citations",
          type: "boolean",
          default: true,
        },
      ];
    default:
      return [];
  }
}

function DecisionField({
  field,
  stepConfig,
  value,
  onChange,
}: {
  field: DecisionField;
  stepConfig: Record<string, unknown>;
  value: unknown;
  onChange: (v: unknown) => void;
}) {
  // Resolve default: explicit decision draft → step.config → field.default
  const current =
    value !== undefined ? value : stepConfig[field.key] !== undefined ? stepConfig[field.key] : field.default;

  if (field.type === "select") {
    return (
      <div>
        <Label className="text-xs">{field.label}</Label>
        <Select value={String(current ?? "")} onValueChange={onChange}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {(field.options ?? []).map((o) => (
              <SelectItem key={o.value} value={o.value}>
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    );
  }
  if (field.type === "boolean") {
    return (
      <label className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={!!current}
          onChange={(e) => onChange(e.target.checked)}
          className="h-4 w-4"
        />
        {field.label}
      </label>
    );
  }
  return (
    <div>
      <Label className="text-xs">{field.label}</Label>
      <Input value={String(current ?? "")} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
