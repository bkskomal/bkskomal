"use client";

import { useEffect, useState } from "react";
import {
  CircleDashed,
  Loader2,
  Clock,
  CheckCircle2,
  XCircle,
  SkipForward,
  Sparkles,
  ChevronRight,
  Pause,
  Play,
  Square,
  MoreVertical,
  Pencil,
  RotateCcw,
} from "lucide-react";
import {
  PipelineStepKind,
  PipelineStepMode,
  PipelineStepStatus,
  PipelineRunStatus,
} from "@prisma/client";
import { cn, formatRelativeTime } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "@/components/ui/use-toast";
import { PipelineStepDialog } from "./pipeline-step-dialog";
import { PipelineEditDialog } from "./pipeline-edit-dialog";

export interface StepRow {
  id: string;
  index: number;
  kind: PipelineStepKind;
  label: string;
  description: string | null;
  mode: PipelineStepMode;
  status: PipelineStepStatus;
  config: any;
  result: any;
  errorMessage: string | null;
  blockedReason: string | null;
  /** Live "what is this step doing right now" text, set by handlers/processRfp
   *  while the step is RUNNING. Cleared on success/failure. */
  progressDetail: string | null;
  startedAt: string | null;
  finishedAt: string | null;
}

export interface PipelineRun {
  id: string;
  status: PipelineRunStatus;
  currentStepIndex: number;
  template: { name: string };
  steps: StepRow[];
  pausedAt: string | null;
  pausedById: string | null;
  pausedReason: string | null;
  pausedBy: { id: string; name: string | null; email: string | null } | null;
}

const POLL_INTERVAL_MS = 4000;

const STATUS_META: Record<
  PipelineStepStatus,
  { icon: any; ring: string; text: string; bg: string }
> = {
  PENDING: {
    icon: CircleDashed,
    ring: "border-muted-foreground/30",
    text: "text-muted-foreground",
    bg: "bg-card",
  },
  RUNNING: {
    icon: Loader2,
    ring: "border-sky-500",
    text: "text-sky-600 dark:text-sky-300",
    bg: "bg-sky-500/10",
  },
  WAITING_FOR_INPUT: {
    icon: Clock,
    ring: "border-amber-500",
    text: "text-amber-600 dark:text-amber-300",
    bg: "bg-amber-500/10",
  },
  SUCCEEDED: {
    icon: CheckCircle2,
    ring: "border-emerald-500",
    text: "text-emerald-600 dark:text-emerald-300",
    bg: "bg-emerald-500/10",
  },
  FAILED: {
    icon: XCircle,
    ring: "border-destructive",
    text: "text-destructive",
    bg: "bg-destructive/10",
  },
  SKIPPED: {
    icon: SkipForward,
    ring: "border-muted-foreground/30",
    text: "text-muted-foreground",
    bg: "bg-muted/40",
  },
  CANCELLED: {
    icon: XCircle,
    ring: "border-muted-foreground/30",
    text: "text-muted-foreground",
    bg: "bg-muted/40",
  },
};

interface Props {
  rfpId: string;
}

export function PipelineStepper({ rfpId }: Props) {
  const [run, setRun] = useState<PipelineRun | null>(null);
  const [openStepId, setOpenStepId] = useState<string | null>(null);
  const [editStepId, setEditStepId] = useState<string | null>(null);
  const [actionPending, setActionPending] = useState(false);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const r = await fetch(`/api/rfps/${rfpId}/pipeline`);
      if (!r.ok) return;
      const d = await r.json();
      setRun(d.run ?? null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const t = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(t);
  }, [rfpId]);

  async function callRunAction(action: "pause" | "resume" | "stop", body?: Record<string, unknown>) {
    setActionPending(true);
    try {
      const r = await fetch(`/api/rfps/${rfpId}/pipeline/${action}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body ?? {}),
      });
      if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        toast({ title: `${action} failed`, description: e.error });
        return;
      }
      toast({ title: `Workflow ${action}d`, variant: "success" });
      load();
    } finally {
      setActionPending(false);
    }
  }

  async function callStepEdit(index: number, action: "skip" | "reset") {
    setActionPending(true);
    try {
      const r = await fetch(`/api/rfps/${rfpId}/pipeline/edit`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ edits: [{ index, action }] }),
      });
      if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        toast({ title: `Could not ${action} step`, description: e.error });
        return;
      }
      toast({ title: `Step ${action === "skip" ? "skipped" : "reset"}`, variant: "success" });
      load();
    } finally {
      setActionPending(false);
    }
  }

  if (loading || !run) {
    return (
      <div className="rounded-xl border bg-card p-3 text-xs text-muted-foreground">
        <Loader2 className="inline h-3 w-3 animate-spin mr-1" /> Loading workflow…
      </div>
    );
  }

  const completed = run.steps.filter((s) => s.status === "SUCCEEDED").length;
  const total = run.steps.length;
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

  const canPause = run.status === "RUNNING" || run.status === "WAITING_FOR_INPUT";
  const isPaused = run.status === "PAUSED";
  const isStopped = run.status === "STOPPED";
  const pausedByName =
    run.pausedBy?.name ?? run.pausedBy?.email ?? "someone";

  return (
    <>
      <div className="rounded-xl border bg-card overflow-hidden">
        <div className="flex items-center justify-between border-b px-3 py-2 gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Sparkles className="h-3.5 w-3.5 text-primary shrink-0" />
            <span className="text-xs font-semibold truncate">{run.template.name}</span>
            <span className="text-[10px] text-muted-foreground whitespace-nowrap">
              · {completed}/{total} steps
              {run.status === "WAITING_FOR_INPUT" && ` · waiting on you`}
              {run.status === "FAILED" && ` · failed`}
              {run.status === "SUCCEEDED" && ` · complete`}
              {isPaused && ` · paused`}
              {isStopped && ` · stopped`}
            </span>
          </div>
          <div className="flex items-center gap-1 shrink-0">
            {canPause ? (
              <Button
                size="sm"
                variant="outline"
                onClick={() => callRunAction("pause")}
                disabled={actionPending}
                title="Pause this workflow run"
              >
                <Pause className="h-3.5 w-3.5" /> Pause
              </Button>
            ) : null}
            {isPaused ? (
              <>
                <Button
                  size="sm"
                  variant="gradient"
                  onClick={() => callRunAction("resume")}
                  disabled={actionPending}
                  title="Resume this workflow run"
                >
                  <Play className="h-3.5 w-3.5" /> Resume
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    const reason = window.prompt("Reason for stopping (optional):") ?? undefined;
                    void callRunAction("stop", reason ? { reason } : {});
                  }}
                  disabled={actionPending}
                  title="Stop this workflow run permanently"
                >
                  <Square className="h-3.5 w-3.5" /> Stop
                </Button>
              </>
            ) : null}
            <span className="text-[10px] text-muted-foreground pl-1">{pct}%</span>
          </div>
        </div>

        {isPaused && run.pausedAt ? (
          <div className="border-b bg-amber-500/10 px-3 py-1.5 text-[11px] text-amber-700 dark:text-amber-300">
            <Pause className="inline h-3 w-3 mr-1" />
            Paused by <span className="font-semibold">{pausedByName}</span>
            {" · "}
            {formatRelativeTime(run.pausedAt)}
            {run.pausedReason ? <> · Reason: {run.pausedReason}</> : null}
          </div>
        ) : null}

        {isStopped && run.pausedAt ? (
          <div className="border-b bg-muted/60 px-3 py-1.5 text-[11px] text-muted-foreground">
            <Square className="inline h-3 w-3 mr-1" />
            Stopped by <span className="font-semibold">{pausedByName}</span>
            {" · "}
            {formatRelativeTime(run.pausedAt)}
            {run.pausedReason ? <> · Reason: {run.pausedReason}</> : null}
          </div>
        ) : null}

        {/* Progress bar — determinate width AND, when the run is actively
            in flight, an indeterminate shimmer sweep on top so the user can
            see "the engine is doing something" even if the step count hasn't
            changed yet. `.progress-shimmer` (globals.css) overlays a moving
            highlight via ::after. */}
        <div
          className={cn(
            "relative h-1 overflow-hidden bg-muted",
            (run.status === "RUNNING" || run.status === "WAITING_FOR_INPUT") && "progress-shimmer",
          )}
        >
          <div
            className="h-full bg-gradient-to-r from-primary to-fuchsia-500 transition-all"
            style={{ width: `${pct}%` }}
          />
        </div>

        <div className="scrollbar-thin overflow-x-auto">
          <div className="flex items-stretch gap-1 px-3 py-3 min-w-max">
            {run.steps.map((step, i) => {
              const meta = STATUS_META[step.status];
              const Icon = meta.icon;
              const isCurrent = i === run.currentStepIndex && run.status !== "SUCCEEDED";
              const showEditMenu =
                isPaused &&
                (step.status === "PENDING" ||
                  step.status === "SUCCEEDED" ||
                  step.status === "FAILED" ||
                  step.status === "SKIPPED" ||
                  step.status === "CANCELLED");
              const canReset =
                step.status === "SUCCEEDED" ||
                step.status === "FAILED" ||
                step.status === "SKIPPED" ||
                step.status === "CANCELLED";
              const canSkip = step.status === "PENDING";
              const canEditDetails = step.status === "PENDING" && step.index >= run.currentStepIndex;
              return (
                <div key={step.id} className="flex items-stretch gap-1">
                  <div className="relative">
                    <button
                      onClick={() => setOpenStepId(step.id)}
                      className={cn(
                        "group relative flex flex-col gap-1 rounded-md border-2 px-2.5 py-2 text-left transition-all hover:shadow-md min-w-[140px] max-w-[200px]",
                        meta.ring,
                        meta.bg,
                        isCurrent && "ring-2 ring-primary/40",
                        // Active-work indicator: ping-pulse glow around the
                        // step card. Sits on top of the existing sky border
                        // from STATUS_META.RUNNING. Defined in globals.css
                        // (@keyframes step-running-ping).
                        step.status === "RUNNING" && "running-border",
                      )}
                      title={step.progressDetail ?? step.blockedReason ?? step.errorMessage ?? step.description ?? ""}
                    >
                      <div className="flex items-center justify-between">
                        <span className={cn("flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-bold", meta.text)}>
                          <Icon className={cn("h-3 w-3", step.status === "RUNNING" && "animate-spin")} />
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <span className="text-[9px] uppercase tracking-wider text-muted-foreground">
                          {step.mode}
                        </span>
                      </div>
                      <div className="text-xs font-medium leading-snug line-clamp-2">{step.label}</div>
                      {/* Live status text precedence (top → bottom):
                          1. RUNNING + progressDetail → live tick (sky)
                          2. WAITING_FOR_INPUT → blockedReason (amber)
                          3. FAILED → errorMessage (destructive)
                          4. SUCCEEDED + result → result summary
                          The engine clears progressDetail/blockedReason on
                          terminal states so the wrong one can't bleed through. */}
                      {step.status === "RUNNING" && step.progressDetail ? (
                        <div className={cn("text-[10px] line-clamp-2 animate-pulse", meta.text)}>
                          {step.progressDetail}
                        </div>
                      ) : step.status === "WAITING_FOR_INPUT" && step.blockedReason ? (
                        <div className={cn("text-[10px] line-clamp-2", meta.text)}>
                          {step.blockedReason}
                        </div>
                      ) : step.errorMessage ? (
                        <div className="text-[10px] text-destructive line-clamp-2">{step.errorMessage}</div>
                      ) : step.status === "SUCCEEDED" && step.result ? (
                        <div className="text-[10px] text-muted-foreground">
                          {summarizeResult(step.kind, step.result)}
                        </div>
                      ) : null}
                    </button>
                    {showEditMenu ? (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <button
                            className="absolute top-1 right-1 grid h-5 w-5 place-items-center rounded text-muted-foreground hover:bg-background/80 hover:text-foreground"
                            title="Step actions"
                            disabled={actionPending}
                          >
                            <MoreVertical className="h-3 w-3" />
                          </button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="text-xs">
                          {canEditDetails ? (
                            <DropdownMenuItem onSelect={() => setEditStepId(step.id)}>
                              <Pencil className="h-3 w-3" /> Edit…
                            </DropdownMenuItem>
                          ) : null}
                          {canSkip ? (
                            <DropdownMenuItem onSelect={() => callStepEdit(step.index, "skip")}>
                              <SkipForward className="h-3 w-3" /> Skip
                            </DropdownMenuItem>
                          ) : null}
                          {canReset ? (
                            <DropdownMenuItem onSelect={() => callStepEdit(step.index, "reset")}>
                              <RotateCcw className="h-3 w-3" /> Reset
                            </DropdownMenuItem>
                          ) : null}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    ) : null}
                  </div>
                  {i < run.steps.length - 1 ? (
                    <div className="flex items-center">
                      <ChevronRight className="h-3 w-3 text-muted-foreground/50" />
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <PipelineStepDialog
        rfpId={rfpId}
        step={run.steps.find((s) => s.id === openStepId) ?? null}
        open={openStepId !== null}
        onOpenChange={(o) => !o && setOpenStepId(null)}
        onChanged={load}
      />

      <PipelineEditDialog
        rfpId={rfpId}
        step={run.steps.find((s) => s.id === editStepId) ?? null}
        open={editStepId !== null}
        onOpenChange={(o) => !o && setEditStepId(null)}
        onSaved={load}
      />
    </>
  );
}

function summarizeResult(kind: PipelineStepKind, result: any): string | null {
  if (!result || typeof result !== "object") return null;
  switch (kind) {
    case "EXTRACT_QUESTIONS":
      return result.questionCount != null ? `${result.questionCount} questions` : null;
    case "ASSIGN_SMES":
      return result.assigned != null ? `${result.assigned}/${result.total} assigned` :
             result.autoAssigned != null ? `${result.autoAssigned} auto-assigned` : null;
    case "GENERATE_RESPONSES":
      return result.generated != null ? `${result.generated}/${result.total} answered` : null;
    case "INTERNAL_REVIEW":
      return result.reviewed != null ? `${result.reviewed} reviewed` : null;
    case "APPROVAL":
      return result.approved != null ? `${result.approved}/${result.total} approved` : null;
    case "CONSOLIDATE_EXPORT":
      return result.format ? `exported (${result.format})` : null;
    case "MINE_TO_KB":
      return result.pairCount != null ? `${result.pairCount} pairs mined` : null;
    case "WEBHOOK":
      return result.status != null ? `HTTP ${result.status}` : null;
    default:
      return null;
  }
}
