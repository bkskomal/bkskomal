"use client";

import { useState } from "react";
import { Calendar, Loader2, X } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "@/components/ui/use-toast";
import { DueDatePill } from "./due-date";

interface Props {
  rfpId: string;
  current: string | null;
  onChange: (next: string | null) => void;
}

/**
 * Small editor for the RFP-level due date. Renders as either a "Set due date"
 * button or the active DueDatePill — both open a dialog with a datetime-local
 * input. Modular: drop it anywhere you have the rfpId.
 */
export function RfpDueDateEditor({ rfpId, current, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState<string>(toLocalInput(current));
  const [saving, setSaving] = useState(false);

  async function save(clear = false) {
    setSaving(true);
    try {
      const dueDate = clear ? null : value ? new Date(value).toISOString() : null;
      const res = await fetch(`/api/rfps/${rfpId}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ dueDate }),
      });
      if (!res.ok) {
        toast({ title: "Couldn't save", description: (await res.json()).error });
        return;
      }
      onChange(dueDate);
      toast({ title: dueDate ? "Due date saved" : "Due date cleared", variant: "success" });
      setOpen(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-1 rounded-md text-xs hover:bg-accent px-1.5 py-0.5 transition-colors"
        title={current ? "Edit due date" : "Set a due date"}
      >
        {current ? (
          <DueDatePill dueDate={current} />
        ) : (
          <span className="inline-flex items-center gap-1 text-muted-foreground">
            <Calendar className="h-3 w-3" /> Set due date
          </span>
        )}
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>RFP due date</DialogTitle>
            <DialogDescription>
              Used for the deadline pill in the header and for the "due soon"
              notification (sent 24h before).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <Label htmlFor="due">Due date and time</Label>
            <Input
              id="due"
              type="datetime-local"
              value={value}
              onChange={(e) => setValue(e.target.value)}
            />
          </div>
          <DialogFooter className="gap-2">
            {current ? (
              <Button variant="ghost" onClick={() => save(true)} disabled={saving}>
                <X className="h-4 w-4" /> Clear
              </Button>
            ) : null}
            <Button variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button variant="gradient" onClick={() => save(false)} disabled={saving || !value}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Calendar className="h-4 w-4" />}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function toLocalInput(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
