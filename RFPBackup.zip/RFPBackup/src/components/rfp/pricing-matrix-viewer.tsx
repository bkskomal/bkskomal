"use client";

// Pricing-matrix viewer.
//
// Renders the parsed matrix from /api/rfps/:rfpId/attachments/:attachmentId/matrix
// as an editable table. Per-row "Generate" buttons stream AI cell completions
// via SSE (cells appear live). Top-right "Generate all" + "Download
// completed Excel" buttons wrap the bulk paths.
//
// State model:
//   - `matrix` is the source of truth; we mutate-in-place when streamed
//     events arrive (then setState with a shallow copy to trigger rerender).
//   - `generatingRows` is a Set of row indices currently being generated —
//     drives the per-row spinner. We allow only one generate stream at a
//     time to keep the UI predictable.
//   - "Generate all" calls the same endpoint with no rowIndices, which the
//     server treats as "every row".
//
// Editing: cells show `value` (frozen, read-only) and `generated`
// (editable textarea). Edits are persisted via PATCH on blur. We don't
// optimistically update because the round-trip is fast and stale state
// after a network failure is more confusing than a 200ms delay.

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Download, Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface Cell {
  value?: string;
  generated?: string;
  generatedAt?: string;
  confidence?: number;
}

interface Row {
  label: string;
  cells: Cell[];
}

export interface PricingMatrixViewerProps {
  rfpId: string;
  attachmentId: string;
  fileName: string;
}

interface MatrixState {
  headers: string[];
  rows: Row[];
}

export function PricingMatrixViewer({
  rfpId,
  attachmentId,
  fileName,
}: PricingMatrixViewerProps) {
  const [matrix, setMatrix] = useState<MatrixState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [generatingRows, setGeneratingRows] = useState<Set<number>>(new Set());
  const [generatingAll, setGeneratingAll] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const matrixUrl = `/api/rfps/${rfpId}/attachments/${attachmentId}/matrix`;

  // Initial load.
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(matrixUrl)
      .then(async (res) => {
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error ?? res.statusText);
        return res.json();
      })
      .then((body: { matrix: MatrixState }) => {
        if (cancelled) return;
        setMatrix(body.matrix);
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
      abortRef.current?.abort();
    };
  }, [matrixUrl]);

  const cellsPerRow = useMemo(
    () => Math.max(0, (matrix?.headers.length ?? 0) - 1),
    [matrix],
  );

  const persistCell = useCallback(
    async (rowIndex: number, cellIndex: number, patch: Partial<Cell>) => {
      try {
        const res = await fetch(matrixUrl, {
          method: "PATCH",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ rowIndex, cellIndex, ...patch }),
        });
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          toast({ title: "Couldn't save cell", description: body.error });
        }
      } catch (e) {
        toast({
          title: "Couldn't save cell",
          description: e instanceof Error ? e.message : String(e),
        });
      }
    },
    [matrixUrl],
  );

  const startGenerate = useCallback(
    async (rowIndices?: number[]) => {
      if (!matrix) return;
      if (generatingAll || generatingRows.size > 0) {
        toast({ title: "A generation is already in progress" });
        return;
      }
      const indices =
        rowIndices && rowIndices.length > 0
          ? rowIndices
          : matrix.rows.map((_, i) => i);
      if (indices.length === 0) {
        toast({ title: "Nothing to generate" });
        return;
      }
      if (rowIndices && rowIndices.length > 0) {
        setGeneratingRows(new Set(rowIndices));
      } else {
        setGeneratingAll(true);
      }

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const res = await fetch(`${matrixUrl}/generate`, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ rowIndices: rowIndices ?? [] }),
          signal: controller.signal,
        });
        if (!res.ok || !res.body) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error ?? `HTTP ${res.status}`);
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        // Each SSE event is two newlines separated. We parse opportunistically.
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let idx: number;
          while ((idx = buffer.indexOf("\n\n")) !== -1) {
            const raw = buffer.slice(0, idx);
            buffer = buffer.slice(idx + 2);
            const evt = parseSseEvent(raw);
            if (!evt) continue;
            if (evt.event === "cell") {
              const data = evt.data as {
                rowIndex: number;
                cellIndex: number;
                generated: string;
                confidence: number;
              };
              setMatrix((prev) => {
                if (!prev) return prev;
                const next: MatrixState = {
                  headers: prev.headers,
                  rows: prev.rows.map((r, i) => {
                    if (i !== data.rowIndex) return r;
                    return {
                      label: r.label,
                      cells: r.cells.map((c, j) =>
                        j === data.cellIndex
                          ? {
                              ...c,
                              generated: data.generated,
                              confidence: data.confidence,
                              generatedAt: new Date().toISOString(),
                            }
                          : c,
                      ),
                    };
                  }),
                };
                return next;
              });
            } else if (evt.event === "error") {
              const msg = (evt.data as { message?: string }).message ?? "stream error";
              toast({ title: "Generation error", description: msg });
            }
          }
        }
      } catch (e) {
        if ((e as Error).name !== "AbortError") {
          toast({
            title: "Generation failed",
            description: e instanceof Error ? e.message : String(e),
          });
        }
      } finally {
        setGeneratingRows(new Set());
        setGeneratingAll(false);
        abortRef.current = null;
      }
    },
    [matrix, matrixUrl, generatingAll, generatingRows.size],
  );

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center gap-2 p-6 text-sm text-muted-foreground">
          <Loader2 className="h-4 w-4 animate-spin" /> Loading pricing matrix…
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-6 text-sm text-destructive">
          Couldn't load pricing matrix: {error}
        </CardContent>
      </Card>
    );
  }

  if (!matrix || matrix.headers.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Pricing matrix</CardTitle>
          <CardDescription>
            {fileName} did not parse into a recognisable grid. Make sure the
            first row contains column headers and the first column lists
            line items.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between">
        <div>
          <CardTitle className="text-base">Pricing matrix · {fileName}</CardTitle>
          <CardDescription>
            {matrix.rows.length} line item{matrix.rows.length === 1 ? "" : "s"} ×{" "}
            {cellsPerRow} column{cellsPerRow === 1 ? "" : "s"}. AI fills empty
            cells with a draft answer; <strong>NEEDS INFO</strong> flags
            cells that need human input.
          </CardDescription>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="gradient"
            onClick={() => startGenerate()}
            disabled={generatingAll || generatingRows.size > 0}
          >
            {generatingAll ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Sparkles className="h-3.5 w-3.5" />
            )}
            Generate all
          </Button>
          <a
            href={`${matrixUrl}/export`}
            download
            className="inline-flex items-center gap-1 rounded-md border bg-background px-2.5 py-1.5 text-xs font-medium hover:bg-muted"
          >
            <Download className="h-3.5 w-3.5" />
            Download Excel
          </a>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="bg-muted/50 text-muted-foreground">
                <th className="sticky left-0 z-10 border bg-muted/50 px-2 py-2 text-left font-medium">
                  {matrix.headers[0] ?? "Item"}
                </th>
                {matrix.headers.slice(1).map((h, i) => (
                  <th key={i} className="border px-2 py-2 text-left font-medium">
                    {h || `Column ${i + 1}`}
                  </th>
                ))}
                <th className="border px-2 py-2 text-right font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {matrix.rows.map((row, rowIndex) => (
                <tr key={rowIndex} className="align-top">
                  <td className="sticky left-0 z-10 max-w-[220px] border bg-background px-2 py-2 font-medium">
                    {row.label || <span className="text-muted-foreground">(no label)</span>}
                  </td>
                  {Array.from({ length: cellsPerRow }).map((_, cellIndex) => {
                    const cell = row.cells[cellIndex] ?? {};
                    return (
                      <td key={cellIndex} className="border px-2 py-2">
                        <CellEditor
                          cell={cell}
                          onCommit={(patch) => persistCell(rowIndex, cellIndex, patch)}
                        />
                      </td>
                    );
                  })}
                  <td className="border px-2 py-2 text-right">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => startGenerate([rowIndex])}
                      disabled={
                        generatingAll || generatingRows.has(rowIndex)
                      }
                    >
                      {generatingRows.has(rowIndex) ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Sparkles className="h-3.5 w-3.5" />
                      )}
                      Generate
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}

function CellEditor({
  cell,
  onCommit,
}: {
  cell: Cell;
  onCommit: (patch: Partial<Cell>) => void;
}) {
  const [draft, setDraft] = useState<string>(cell.generated ?? "");
  // Re-sync when upstream (e.g. SSE stream) updates this cell.
  useEffect(() => {
    setDraft(cell.generated ?? "");
  }, [cell.generated]);

  const isNeedsInfo = (cell.generated ?? "").toUpperCase() === "NEEDS INFO";
  const hasValue = !!cell.value;

  return (
    <div className="flex flex-col gap-1">
      {hasValue ? (
        <div className="text-[11px] leading-tight">
          <span className="text-muted-foreground">Source:</span>{" "}
          <span className="font-mono">{cell.value}</span>
        </div>
      ) : null}
      <div className="flex items-start gap-1">
        <Badge variant="info" className="mt-0.5 shrink-0 text-[9px] uppercase">
          AI
        </Badge>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onBlur={() => {
            if (draft !== (cell.generated ?? "")) {
              onCommit({ generated: draft });
            }
          }}
          rows={1}
          placeholder="(empty)"
          className={cn(
            "w-full resize-y rounded border bg-background px-1.5 py-0.5 font-mono text-[11px] leading-tight",
            isNeedsInfo && "border-amber-500/60 bg-amber-50 text-amber-900",
          )}
        />
      </div>
      {cell.confidence != null && cell.generated ? (
        <div className="text-[10px] text-muted-foreground">
          conf {(cell.confidence * 100).toFixed(0)}%
        </div>
      ) : null}
    </div>
  );
}

interface SseEvent {
  event: string;
  data: unknown;
}

function parseSseEvent(raw: string): SseEvent | null {
  let event = "message";
  let dataLine = "";
  for (const line of raw.split("\n")) {
    if (line.startsWith("event:")) event = line.slice(6).trim();
    else if (line.startsWith("data:")) dataLine += line.slice(5).trim();
  }
  if (!dataLine) return null;
  try {
    return { event, data: JSON.parse(dataLine) };
  } catch {
    return null;
  }
}
