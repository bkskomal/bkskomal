"use client";

import { ChevronDown } from "lucide-react";
import { QuestionStatus } from "@prisma/client";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { StatusBadge, STATUS_LABELS } from "./status-badge";

interface Props {
  status: QuestionStatus;
  onChange: (s: QuestionStatus) => void;
  size?: "sm" | "md";
}

const ORDER: QuestionStatus[] = ["TODO", "IN_PROGRESS", "IN_REVIEW", "APPROVED"];

export function StatusPicker({ status, onChange, size = "md" }: Props) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="inline-flex items-center gap-1 rounded-md hover:bg-accent transition-colors px-1 py-0.5">
          <StatusBadge status={status} size={size} />
          <ChevronDown className="h-3 w-3 opacity-50" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start">
        {ORDER.map((s) => (
          <DropdownMenuItem key={s} onClick={() => onChange(s)}>
            <StatusBadge status={s} size="sm" />
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
