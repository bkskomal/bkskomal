"use client";

import { Calendar, AlertTriangle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  dueDate: string | Date | null | undefined;
  className?: string;
  size?: "sm" | "md";
}

/**
 * Compact due-date pill. Auto-colors:
 *   - overdue (in the past)    → destructive
 *   - due within 48h           → warning amber
 *   - due in the future        → muted
 */
export function DueDatePill({ dueDate, className, size = "md" }: Props) {
  if (!dueDate) return null;
  const d = typeof dueDate === "string" ? new Date(dueDate) : dueDate;
  const now = new Date();
  const ms = d.getTime() - now.getTime();
  const hours = ms / (1000 * 60 * 60);
  const days = ms / (1000 * 60 * 60 * 24);

  const isOverdue = ms < 0;
  const isSoon = !isOverdue && hours < 48;

  let label: string;
  if (isOverdue) {
    const absDays = Math.abs(Math.round(days));
    label = absDays === 0 ? "due today" : `${absDays}d overdue`;
  } else if (hours < 1) {
    label = "<1h left";
  } else if (hours < 24) {
    label = `${Math.round(hours)}h left`;
  } else {
    label = `due ${d.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`;
  }

  const Icon = isOverdue ? AlertTriangle : isSoon ? Clock : Calendar;
  return (
    <span
      title={d.toLocaleString()}
      className={cn(
        "inline-flex items-center gap-1 rounded-full border-transparent font-medium",
        isOverdue
          ? "bg-destructive/10 text-destructive"
          : isSoon
            ? "bg-amber-500/15 text-amber-700 dark:text-amber-300"
            : "bg-muted/60 text-muted-foreground",
        size === "sm" ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-0.5 text-xs",
        className,
      )}
    >
      <Icon className={size === "sm" ? "h-2.5 w-2.5" : "h-3 w-3"} />
      {label}
    </span>
  );
}
