"use client";

// Collaborative-aware response editor.
//
// CRITICAL: This is NOT a CRDT editor. There's no Yjs, no operational
// transform, no WebSocket layer. The contract is:
//
//   1. Soft lock with a 60s TTL, refreshed by 20s heartbeats.
//   2. Debounced auto-save every ~5s of content changes via PUT /draft.
//   3. Explicit "Publish" commits the draft via POST /finalize and
//      releases the lock; a stale tab in the meantime gets 409.
//
// Last debounced writer wins. Two clients can never reach the draft
// endpoint at the same time because of (1); a tab whose lock expired
// while backgrounded will get back `lock_lost` on its next save and
// drop into read-only mode rather than clobbering whoever took over.
//
// The component lives next to the response viewer in
// src/app/dashboard/rfps/[rfpId]/viewer.tsx and replaces the
// previously-inlined "edit textarea + save button". The Save button
// flow on Response.PATCH is preserved for the case where the user
// wants to push a single edit without entering the locked editor
// (e.g. fixing a typo on someone else's published answer).

import { useCallback, useEffect, useRef, useState } from "react";
import { Lock, Loader2, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Markdown } from "@/components/markdown";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface EditState {
  editorId: string | null;
  editor: { id: string; name: string | null; email: string } | null;
  lastHeartbeat: string | null;
  version: number;
  draftContent: string | null;
  draftUpdatedAt: string | null;
  isStale: boolean;
}

interface ResponseEditorProps {
  responseId: string;
  currentUserId: string;
  /** Initial content from the parent (Response.content). */
  initialContent: string;
  /** Bubble up the committed content + new version on Publish. */
  onCommitted: (content: string, version: number) => void;
}

/** Heartbeat cadence — well under HEARTBEAT_TTL_MS so transient hiccups don't drop the lock. */
const HEARTBEAT_INTERVAL_MS = 20_000;
/** Local mirror of AUTOSAVE_DEBOUNCE_MS — duplicated rather than imported to avoid pulling the server module into the bundle. */
const AUTOSAVE_DEBOUNCE_MS = 5_000;
/** Re-fetch the read-only state every 30s while NOT editing, so banners pick up other users' acquires. */
const POLL_INTERVAL_MS = 30_000;

/** Tiny inline debounced-callback hook so we don't add a runtime dep on lodash. */
function useDebouncedCallback<A extends unknown[]>(
  fn: (...args: A) => void,
  delay: number,
): (...args: A) => void {
  const fnRef = useRef(fn);
  fnRef.current = fn;
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  return useCallback(
    (...args: A) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(() => fnRef.current(...args), delay);
    },
    [delay],
  );
}

type SaveStatus = "idle" | "saving" | "saved" | "error";

export function ResponseEditor({
  responseId,
  currentUserId,
  initialContent,
  onCommitted,
}: ResponseEditorProps) {
  const [state, setState] = useState<EditState | null>(null);
  const [stateLoading, setStateLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [content, setContent] = useState(initialContent);
  const [saveStatus, setSaveStatus] = useState<SaveStatus>("idle");
  const [conflict, setConflict] = useState<string | null>(null);
  const editingRef = useRef(false);
  editingRef.current = editing;
  const versionRef = useRef(0);

  // Sync initialContent into local state when the parent re-renders with a new
  // response (e.g. user switched questions). Only when we're NOT actively
  // editing — otherwise we'd nuke the user's in-flight changes.
  useEffect(() => {
    if (!editingRef.current) setContent(initialContent);
  }, [initialContent, responseId]);

  // Initial state fetch + polling while NOT editing. We intentionally stop
  // polling while editing because the heartbeat loop already confirms our
  // ownership; double-polling would just be noise.
  const fetchState = useCallback(async () => {
    try {
      const res = await fetch(`/api/responses/${responseId}/edit-session`);
      if (!res.ok) return;
      const body = (await res.json()) as EditState;
      versionRef.current = body.version;
      setState(body);
    } catch {
      // Network blips are non-fatal; the next poll tick will retry.
    } finally {
      setStateLoading(false);
    }
  }, [responseId]);

  useEffect(() => {
    void fetchState();
  }, [fetchState]);

  useEffect(() => {
    if (editing) return; // suspend the public poll while we own the lock
    const i = setInterval(fetchState, POLL_INTERVAL_MS);
    return () => clearInterval(i);
  }, [editing, fetchState]);

  // Heartbeat loop, active only while editing.
  useEffect(() => {
    if (!editing) return;
    const tick = async () => {
      try {
        const res = await fetch(
          `/api/responses/${responseId}/edit-session/heartbeat`,
          { method: "POST" },
        );
        if (!res.ok) {
          // 409 → someone else took over (lock_lost). Drop to read-only and
          // refresh the banner so the user sees who has it now.
          setEditing(false);
          setSaveStatus("error");
          toast({
            title: "Edit lock lost",
            description: "Another user took over editing this response.",
          });
          void fetchState();
        }
      } catch {
        // ignore transient failures; next tick will retry. The server will
        // expire us if the network is truly down longer than TTL.
      }
    };
    const i = setInterval(tick, HEARTBEAT_INTERVAL_MS);
    return () => clearInterval(i);
  }, [editing, responseId, fetchState]);

  // Best-effort release on unmount IF we still own the lock. This isn't
  // guaranteed to fire on tab-close (browsers may skip cleanup on
  // navigation), but it covers the common case of clicking out of the
  // detail panel. The server-side TTL is the backstop for everything else.
  useEffect(() => {
    return () => {
      if (editingRef.current) {
        void fetch(`/api/responses/${responseId}/edit-session`, {
          method: "DELETE",
        }).catch(() => {
          /* swallow */
        });
      }
    };
  }, [responseId]);

  const debouncedSave = useDebouncedCallback((nextContent: string) => {
    void (async () => {
      setSaveStatus("saving");
      try {
        const res = await fetch(
          `/api/responses/${responseId}/edit-session/draft`,
          {
            method: "PUT",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({
              content: nextContent,
              expectedVersion: versionRef.current,
            }),
          },
        );
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          if (body.reason === "version_conflict") {
            // Someone else committed in between — the user's draft is
            // potentially stale relative to ground truth. We KEEP local
            // edits in the textarea but block further saves with a banner.
            setConflict(
              "Someone else committed first. Reload to see the latest version before saving.",
            );
            setSaveStatus("error");
          } else if (body.reason === "lock_lost") {
            // TTL expired (tab was probably backgrounded). Drop editing.
            setEditing(false);
            setSaveStatus("error");
            toast({
              title: "Edit lock expired",
              description: "Your edit lock timed out. Re-acquire to continue.",
            });
            void fetchState();
          } else {
            setSaveStatus("error");
          }
          return;
        }
        const body = await res.json();
        versionRef.current = body.version;
        setSaveStatus("saved");
      } catch {
        setSaveStatus("error");
      }
    })();
  }, AUTOSAVE_DEBOUNCE_MS);

  async function startEditing() {
    setStateLoading(true);
    try {
      const res = await fetch(`/api/responses/${responseId}/edit-session`, {
        method: "POST",
      });
      if (res.status === 409) {
        const body = await res.json();
        // Render the locked banner inline. State was already populated by
        // fetchState; refresh to be sure the banner picks up the latest
        // holder name (the 409 body has it too but state is the source of
        // truth for the rest of the render).
        void fetchState();
        toast({
          title: "Locked",
          description: `Editing locked by ${body.lockedBy?.name ?? body.lockedBy?.email ?? "another user"}.`,
        });
        return;
      }
      if (!res.ok) {
        toast({ title: "Couldn't start editing", description: await res.text() });
        return;
      }
      const body = await res.json();
      versionRef.current = body.session.version;
      // If there's an in-flight draft from a previous editing session by
      // the same user, surface it — otherwise we'd silently overwrite it
      // on the next debounced save.
      const restored = body.session.draftContent;
      if (typeof restored === "string" && restored !== content) {
        setContent(restored);
      }
      setConflict(null);
      setEditing(true);
      setSaveStatus("idle");
      void fetchState();
    } finally {
      setStateLoading(false);
    }
  }

  async function cancelEditing() {
    setEditing(false);
    setContent(initialContent);
    setSaveStatus("idle");
    setConflict(null);
    await fetch(`/api/responses/${responseId}/edit-session`, {
      method: "DELETE",
    }).catch(() => {
      /* swallow */
    });
    void fetchState();
  }

  async function publish() {
    setSaveStatus("saving");
    try {
      const res = await fetch(`/api/responses/${responseId}/finalize`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          content,
          expectedVersion: versionRef.current,
        }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        if (body.reason === "version_conflict") {
          setConflict(
            "Someone else committed first. Reload to see the latest version before publishing.",
          );
          setSaveStatus("error");
          return;
        }
        toast({ title: "Couldn't publish", description: body.reason ?? "" });
        setSaveStatus("error");
        return;
      }
      const body = await res.json();
      versionRef.current = body.version;
      onCommitted(body.content, body.version);
      setEditing(false);
      setSaveStatus("saved");
      setConflict(null);
      toast({ title: "Published", variant: "success" });
      void fetchState();
    } catch (e) {
      toast({ title: "Couldn't publish", description: (e as Error).message });
      setSaveStatus("error");
    }
  }

  // --- Render branches ---------------------------------------------------

  if (stateLoading && !state) {
    return (
      <div className="rounded-lg bg-muted/40 p-4">
        <div className="text-xs text-muted-foreground">Loading…</div>
      </div>
    );
  }

  // Locked by someone else (and not stale) → read-only with banner.
  const lockedByOther =
    !!state &&
    !!state.editorId &&
    state.editorId !== currentUserId &&
    !state.isStale;

  if (lockedByOther && !editing) {
    const name =
      state?.editor?.name ?? state?.editor?.email ?? "another user";
    return (
      <div className="space-y-3">
        <div className="flex items-center gap-2 rounded-lg border border-amber-500/40 bg-amber-50/60 px-3 py-2 text-sm text-amber-900 dark:bg-amber-950/40 dark:text-amber-200">
          <Lock className="h-4 w-4 shrink-0" />
          <span>Editing locked by {name}</span>
        </div>
        <div className="rounded-lg bg-muted/40 p-4">
          <Markdown>{content}</Markdown>
        </div>
      </div>
    );
  }

  if (editing) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-2 rounded-lg border border-emerald-500/40 bg-emerald-50/60 px-3 py-2 text-xs text-emerald-900 dark:bg-emerald-950/40 dark:text-emerald-200">
          <span className="flex items-center gap-2">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" />
            You are editing
          </span>
          <span className="font-mono text-[11px]">
            {saveStatus === "saving" ? (
              <span className="flex items-center gap-1">
                <Loader2 className="h-3 w-3 animate-spin" /> Saving…
              </span>
            ) : saveStatus === "saved" ? (
              "Saved"
            ) : saveStatus === "error" ? (
              "Save failed"
            ) : null}
          </span>
        </div>
        {conflict ? (
          <div className="flex items-center justify-between gap-2 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
            <span>{conflict}</span>
            <Button
              size="sm"
              variant="outline"
              onClick={() => window.location.reload()}
            >
              Reload
            </Button>
          </div>
        ) : null}
        <Textarea
          value={content}
          onChange={(e) => {
            setContent(e.target.value);
            setSaveStatus("idle");
            debouncedSave(e.target.value);
          }}
          rows={14}
          className="font-mono text-sm leading-relaxed"
        />
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={cancelEditing}>
            <X className="h-4 w-4" /> Cancel
          </Button>
          <Button
            variant="gradient"
            onClick={publish}
            disabled={saveStatus === "saving" || !!conflict}
          >
            <Save className="h-4 w-4" /> Publish
          </Button>
        </div>
      </div>
    );
  }

  // Idle, no editor (or stale) — show the content with a Start editing affordance.
  // If the lock is stale, the banner subtly hints why "Start editing" is
  // available even though `editorId` is non-null in the DB.
  const showStaleHint =
    !!state && !!state.editorId && state.editorId !== currentUserId && state.isStale;

  return (
    <div className="space-y-3">
      {showStaleHint ? (
        <div className="flex items-center justify-between gap-2 rounded-lg border border-muted bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
          <span>
            Previous editor ({state?.editor?.name ?? state?.editor?.email ?? "someone"}) has been idle — lock expired
          </span>
        </div>
      ) : null}
      <div className="flex justify-end">
        <Button size="sm" variant="outline" onClick={startEditing}>
          Start editing
        </Button>
      </div>
      <div className={cn("rounded-lg bg-muted/40 p-4")}>
        <Markdown>{content}</Markdown>
      </div>
    </div>
  );
}
