"use client";

import { CircleDashed, CircleDot, Eye, CheckCircle2 } from "lucide-react";
import { QuestionStatus } from "@prisma/client";
import { cn } from "@/lib/utils";

interface Props {
  status: QuestionStatus;
  className?: string;
  size?: "sm" | "md";
}

const META: Record<QuestionStatus, { label: string; icon: any; classes: string }> = {
  TODO: {
    label: "To do",
    icon: CircleDashed,
    classes: "text-muted-foreground bg-muted/40",
  },
  IN_PROGRESS: {
    label: "In progress",
    icon: CircleDot,
    classes: "text-sky-600 dark:text-sky-300 bg-sky-500/10",
  },
  IN_REVIEW: {
    label: "In review",
    icon: Eye,
    classes: "text-amber-600 dark:text-amber-300 bg-amber-500/10",
  },
  APPROVED: {
    label: "Approved",
    icon: CheckCircle2,
    classes: "text-emerald-600 dark:text-emerald-300 bg-emerald-500/10",
  },
};

export function StatusBadge({ status, className, size = "md" }: Props) {
  const { label, icon: Icon, classes } = META[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full border-transparent font-medium",
        classes,
        size === "sm" ? "px-1.5 py-0.5 text-[10px]" : "px-2 py-0.5 text-xs",
        className,
      )}
    >
      <Icon className={size === "sm" ? "h-2.5 w-2.5" : "h-3 w-3"} />
      {label}
    </span>
  );
}

export const STATUS_LABELS: Record<QuestionStatus, string> = {
  TODO: META.TODO.label,
  IN_PROGRESS: META.IN_PROGRESS.label,
  IN_REVIEW: META.IN_REVIEW.label,
  APPROVED: META.APPROVED.label,
};
