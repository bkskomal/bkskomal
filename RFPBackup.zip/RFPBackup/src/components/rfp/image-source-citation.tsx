"use client";

// Inline image citation for response sources whose underlying chunk is a
// figure (kind === "figure" with a linked ImageEmbedding). Renders a 40×40
// thumbnail next to the [Source N] label; clicking opens a modal with the
// full image, caption, OCR text, and a deep link into the KB document
// viewer where the chunk lives.

import { useState } from "react";
import Link from "next/link";
import { ExternalLink, Image as ImageIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { imageUrlFor } from "@/components/index/images-tab";

interface SourceImageInfo {
  id: string;
  imagePath: string;
  caption: string | null;
  ocrText: string | null;
  page: number | null;
  width: number | null;
  height: number | null;
  documentId: string;
  indexId: string;
}

interface ImageSourceLike {
  id: string;
  fileName: string | null;
  page: number | null;
  excerpt: string;
  score: number;
  image?: SourceImageInfo | null;
}

export function ImageSourceCitation({
  index,
  source,
}: {
  index: number;
  source: ImageSourceLike;
}) {
  const [open, setOpen] = useState(false);
  const img = source.image;
  if (!img) return null;
  const url = imageUrlFor(img.imagePath);

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex w-full items-start gap-3 rounded-lg border bg-card p-3 text-left transition-colors hover:bg-accent/40"
        data-testid="image-source-citation"
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={url}
          alt={img.caption ?? "Image source"}
          loading="lazy"
          className="h-10 w-10 shrink-0 rounded border bg-muted object-cover"
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-center justify-between text-xs font-medium">
            <span className="inline-flex items-center gap-1 truncate">
              <ImageIcon className="h-3 w-3 text-muted-foreground" />
              [Source {index + 1}] {source.fileName ?? "—"}
              {img.page != null
                ? ` · p.${img.page}`
                : source.page != null
                  ? ` · p.${source.page}`
                  : ""}
            </span>
            <Badge variant="outline" className="text-[10px]">
              {Math.round(source.score * 100)}%
            </Badge>
          </div>
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
            {img.caption ?? img.ocrText ?? source.excerpt}
          </p>
        </div>
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <ImageIcon className="h-4 w-4" />
              {img.caption ?? source.fileName ?? "Image source"}
              {img.page != null ? (
                <Badge variant="outline">page {img.page}</Badge>
              ) : null}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={url}
              alt={img.caption ?? "Image source"}
              className="max-h-[55vh] w-full rounded-lg border bg-muted object-contain"
            />
            {img.caption ? (
              <div>
                <div className="text-xs font-semibold text-muted-foreground">Caption</div>
                <div className="mt-1 text-sm">{img.caption}</div>
              </div>
            ) : null}
            {img.ocrText ? (
              <div>
                <div className="text-xs font-semibold text-muted-foreground">OCR text</div>
                <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap rounded-lg border bg-muted/30 p-3 text-xs">
                  {img.ocrText}
                </pre>
              </div>
            ) : null}
          </div>
          <DialogFooter className="flex-row items-center justify-between gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href={`/dashboard/indexes/${img.indexId}`}>
                <ExternalLink className="h-3.5 w-3.5" /> Open in KB
              </Link>
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
