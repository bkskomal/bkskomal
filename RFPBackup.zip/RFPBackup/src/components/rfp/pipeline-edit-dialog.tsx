"use client";

import { useEffect, useMemo, useState } from "react";
import { Loader2, Save } from "lucide-react";
import { PipelineStepMode } from "@prisma/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/components/ui/use-toast";
import type { StepRow } from "./pipeline-stepper";

interface Props {
  rfpId: string;
  step: StepRow | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onSaved: () => void;
}

/**
 * Lets a user tweak a single step's label / mode / config while the run is
 * paused. The config is edited as JSON text — the underlying handler accepts
 * arbitrary shapes, so we don't try to render a per-kind form here.
 */
export function PipelineEditDialog({ rfpId, step, open, onOpenChange, onSaved }: Props) {
  const [pending, setPending] = useState(false);
  const [label, setLabel] = useState("");
  const [mode, setMode] = useState<PipelineStepMode>("AUTO");
  const [configText, setConfigText] = useState("");
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Reset the form whenever the step under edit changes.
  useEffect(() => {
    if (!step) return;
    setLabel(step.label ?? "");
    setMode(step.mode);
    setConfigText(step.config != null ? JSON.stringify(step.config, null, 2) : "");
    setJsonError(null);
  }, [step?.id]);

  // Live-validate the JSON so the Save button can disable cleanly.
  const parsedConfig = useMemo(() => {
    if (configText.trim() === "") return { ok: true, value: undefined as unknown };
    try {
      return { ok: true, value: JSON.parse(configText) };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }, [configText]);

  if (!step) return null;

  async function save() {
    if (!step) return;
    if (!parsedConfig.ok) {
      setJsonError(parsedConfig.error ?? "Invalid JSON");
      return;
    }
    setPending(true);
    try {
      const r = await fetch(`/api/rfps/${rfpId}/pipeline/edit`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          edits: [
            {
              index: step.index,
              label,
              mode,
              config: parsedConfig.value,
            },
          ],
        }),
      });
      if (!r.ok) {
        const e = await r.json().catch(() => ({}));
        toast({ title: "Edit failed", description: e.error ?? "Could not save changes" });
        return;
      }
      toast({ title: "Step updated", variant: "success" });
      onSaved();
      onOpenChange(false);
    } finally {
      setPending(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit step {String(step.index + 1).padStart(2, "0")}</DialogTitle>
          <DialogDescription>
            Changes apply when you resume the run. Only steps at or after the
            current cursor can be edited freely.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div>
            <Label htmlFor="step-label" className="text-xs">Label</Label>
            <Input
              id="step-label"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              maxLength={200}
            />
          </div>

          <div>
            <Label className="text-xs">Mode</Label>
            <Select value={mode} onValueChange={(v) => setMode(v as PipelineStepMode)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AUTO">AUTO — engine runs it</SelectItem>
                <SelectItem value="MANUAL">MANUAL — user marks complete</SelectItem>
                <SelectItem value="DECISION">DECISION — user confirms before run</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="step-config" className="text-xs">Config (JSON)</Label>
            <Textarea
              id="step-config"
              value={configText}
              onChange={(e) => {
                setConfigText(e.target.value);
                setJsonError(null);
              }}
              rows={8}
              className="font-mono text-xs"
              placeholder='{ "mode": "unanswered" }'
            />
            {(!parsedConfig.ok || jsonError) ? (
              <div className="mt-1 text-[11px] text-destructive">
                {jsonError ?? (parsedConfig as { error: string }).error}
              </div>
            ) : null}
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={pending}>
            Cancel
          </Button>
          <Button variant="gradient" onClick={save} disabled={pending || !parsedConfig.ok}>
            {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Save className="h-3.5 w-3.5" />}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
