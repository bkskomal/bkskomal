"use client";

import { useEffect, useState } from "react";
import { Loader2, X, CheckCircle2, AlertCircle } from "lucide-react";
import { BulkGenerationStatus } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { toast } from "@/components/ui/use-toast";

interface BulkRow {
  id: string;
  status: BulkGenerationStatus;
  total: number;
  completed: number;
  failed: number;
}

export function BulkProgress({
  bulkId,
  onDone,
}: {
  bulkId: string;
  onDone?: () => void;
}) {
  const [bulk, setBulk] = useState<BulkRow | null>(null);

  useEffect(() => {
    let cancel = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const tick = async () => {
      try {
        const r = await fetch(`/api/bulk-generations/${bulkId}`);
        if (!r.ok) return;
        const { bulk: b } = await r.json();
        if (cancel) return;
        setBulk(b);
        if (["RUNNING", "PENDING"].includes(b.status)) {
          timer = setTimeout(tick, 1500);
        } else {
          if (b.status === "COMPLETED") {
            toast({
              title: `Bulk done · ${b.completed}/${b.total}`,
              description: b.failed > 0 ? `${b.failed} failed` : "All responses generated",
              variant: b.failed > 0 ? undefined : "success",
            });
          } else if (b.status === "FAILED") {
            toast({ title: "Bulk failed", description: "All questions failed to generate" });
          }
          onDone?.();
        }
      } catch {
        if (!cancel) timer = setTimeout(tick, 3000);
      }
    };
    tick();

    return () => {
      cancel = true;
      if (timer) clearTimeout(timer);
    };
  }, [bulkId, onDone]);

  async function cancel() {
    await fetch(`/api/bulk-generations/${bulkId}`, { method: "DELETE" });
  }

  if (!bulk) return null;

  const pct = bulk.total > 0 ? Math.round(((bulk.completed + bulk.failed) / bulk.total) * 100) : 0;
  const running = bulk.status === "RUNNING" || bulk.status === "PENDING";
  const done = bulk.status === "COMPLETED";
  const failed = bulk.status === "FAILED";

  return (
    <div className="flex items-center gap-3 rounded-lg border bg-card px-3 py-2">
      {running ? (
        <Loader2 className="h-4 w-4 animate-spin text-primary shrink-0" />
      ) : done ? (
        <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
      ) : (
        <AlertCircle className="h-4 w-4 text-destructive shrink-0" />
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-baseline justify-between gap-2 text-xs">
          <span className="font-medium">
            {running ? "Generating responses…" : done ? "Bulk generation complete" : "Bulk generation failed"}
          </span>
          <span className="text-muted-foreground">
            {bulk.completed}/{bulk.total}
            {bulk.failed > 0 ? ` · ${bulk.failed} failed` : ""}
          </span>
        </div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-muted">
          <div
            className={`h-full transition-all ${running ? "bg-gradient-to-r from-primary to-fuchsia-500" : done ? "bg-emerald-500" : "bg-destructive"}`}
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>
      {running ? (
        <Button size="icon" variant="ghost" onClick={cancel} title="Cancel">
          <X className="h-3.5 w-3.5" />
        </Button>
      ) : null}
    </div>
  );
}
