"use client";

import { useState } from "react";
import { UserCircle2, X } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

interface Member {
  userId: string;
  email: string;
  name: string | null;
}

interface Props {
  members: Member[];
  current: { id: string; name: string | null; email: string } | null;
  onChange: (userId: string | null) => void;
  size?: "sm" | "md";
  className?: string;
}

function initials(member: { name: string | null; email: string }) {
  return (member.name ?? member.email).slice(0, 2).toUpperCase();
}

export function AssigneePicker({ members, current, onChange, size = "md", className }: Props) {
  const [open, setOpen] = useState(false);
  const dim = size === "sm" ? "h-6 w-6" : "h-7 w-7";
  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5 text-xs hover:bg-accent transition-colors",
            className,
          )}
          title={current ? `Assigned to ${current.name ?? current.email}` : "Unassigned"}
        >
          {current ? (
            <>
              <Avatar className={dim}>
                <AvatarFallback className="text-[10px]">{initials(current)}</AvatarFallback>
              </Avatar>
              {size === "md" ? (
                <span className="hidden lg:inline truncate max-w-[100px]">
                  {current.name ?? current.email.split("@")[0]}
                </span>
              ) : null}
            </>
          ) : (
            <>
              <span className={cn("grid place-items-center rounded-full border border-dashed border-muted-foreground/40", dim)}>
                <UserCircle2 className="h-3 w-3 text-muted-foreground" />
              </span>
              {size === "md" ? <span className="text-muted-foreground hidden lg:inline">Unassigned</span> : null}
            </>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Assign to</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {members.map((m) => (
          <DropdownMenuItem
            key={m.userId}
            onClick={() => onChange(m.userId)}
          >
            <Avatar className="h-5 w-5">
              <AvatarFallback className="text-[10px]">{initials(m)}</AvatarFallback>
            </Avatar>
            <span className="truncate">{m.name ?? m.email}</span>
          </DropdownMenuItem>
        ))}
        {current ? (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onChange(null)}>
              <X className="h-4 w-4" /> Unassign
            </DropdownMenuItem>
          </>
        ) : null}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
