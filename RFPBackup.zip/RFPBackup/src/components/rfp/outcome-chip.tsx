"use client";

// RFP outcome chip — small status pill that lives in the RFP detail header.
//
// Design:
//   * Default state ("PENDING") is muted to avoid visual noise on RFPs that
//     haven't been decided yet.
//   * WON is emerald (matches the "success" badge variant on the rest of the
//     dashboard so the eye reads it the same way as approved questions).
//   * LOST is rose (matches "destructive") and shows a coaching-mode hint
//     because that's where the win/loss feedback loop kicks in.
//   * WITHDRAWN / NO_BID are amber/slate respectively — neutral terminals
//     (we didn't win or lose, the deal just didn't run).
//
// Click opens a small dialog (no popover primitive in the current dep tree)
// with a select for the outcome and a textarea for an optional note. Save
// PATCHes /api/rfps/:rfpId/outcome.

import { useState, useEffect } from "react";
import { Trophy, XCircle, MinusCircle, Ban, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export type RfpOutcomeValue = "PENDING" | "WON" | "LOST" | "WITHDRAWN" | "NO_BID";

interface Props {
  rfpId: string;
  initialOutcome: RfpOutcomeValue;
  initialNote: string | null;
  onChange?: (next: { outcome: RfpOutcomeValue; note: string | null }) => void;
}

interface OutcomeStyle {
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  pillClass: string;
  /** Only set on LOST — drives the "Coaching applied" subtitle. */
  coaching?: boolean;
}

const STYLES: Record<RfpOutcomeValue, OutcomeStyle> = {
  PENDING: {
    label: "Pending outcome",
    icon: Clock,
    pillClass: "bg-muted text-muted-foreground hover:bg-muted/80",
  },
  WON: {
    label: "Won",
    icon: Trophy,
    pillClass:
      "bg-emerald-500/15 text-emerald-700 hover:bg-emerald-500/25 dark:text-emerald-300",
  },
  LOST: {
    label: "Lost",
    icon: XCircle,
    pillClass: "bg-rose-500/15 text-rose-700 hover:bg-rose-500/25 dark:text-rose-300",
    coaching: true,
  },
  WITHDRAWN: {
    label: "Withdrawn",
    icon: MinusCircle,
    // Both terminal-but-undecided outcomes (WITHDRAWN, NO_BID) render grey
    // per spec — the eye reads them as "no win/loss signal recorded" rather
    // than success/failure.
    pillClass: "bg-slate-500/15 text-slate-700 hover:bg-slate-500/25 dark:text-slate-300",
  },
  NO_BID: {
    label: "No bid",
    icon: Ban,
    pillClass: "bg-slate-500/15 text-slate-700 hover:bg-slate-500/25 dark:text-slate-300",
  },
};

export function OutcomeChip({ rfpId, initialOutcome, initialNote, onChange }: Props) {
  const [outcome, setOutcome] = useState<RfpOutcomeValue>(initialOutcome);
  const [note, setNote] = useState<string>(initialNote ?? "");
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  // Form state mirrors the chip until the user actually saves — discard
  // unsaved edits when the dialog closes.
  const [draftOutcome, setDraftOutcome] = useState<RfpOutcomeValue>(initialOutcome);
  const [draftNote, setDraftNote] = useState<string>(initialNote ?? "");

  useEffect(() => {
    if (open) {
      setDraftOutcome(outcome);
      setDraftNote(note);
    }
  }, [open, outcome, note]);

  const style = STYLES[outcome];
  const Icon = style.icon;

  async function save() {
    setSaving(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/outcome`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          outcome: draftOutcome,
          note: draftNote.trim() || undefined,
        }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({
          title: "Couldn't save outcome",
          description: err.error ?? `HTTP ${res.status}`,
        });
        return;
      }
      const body = await res.json();
      const nextOutcome = body.outcome as RfpOutcomeValue;
      const nextNote: string | null = body.outcomeNote ?? null;
      setOutcome(nextOutcome);
      setNote(nextNote ?? "");
      onChange?.({ outcome: nextOutcome, note: nextNote });
      setOpen(false);
      toast({
        title: `Outcome set: ${STYLES[nextOutcome].label}`,
        variant: "success",
      });
    } catch (e) {
      toast({
        title: "Couldn't save outcome",
        description: e instanceof Error ? e.message : String(e),
      });
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors",
          style.pillClass,
        )}
        title="Click to set the RFP outcome"
      >
        <Icon className="h-3 w-3" />
        {style.label}
        {style.coaching ? (
          <span className="hidden sm:inline text-[10px] opacity-80">
            · Coaching applied to similar future questions
          </span>
        ) : null}
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Set RFP outcome</DialogTitle>
            <DialogDescription>
              Recording the deal outcome powers the win/loss feedback loop:
              answers from WON RFPs get a small boost in retrieval; LOST
              answers surface a coaching note on similar future questions.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">
                Outcome
              </label>
              <Select
                value={draftOutcome}
                onValueChange={(v) => setDraftOutcome(v as RfpOutcomeValue)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PENDING">Pending</SelectItem>
                  <SelectItem value="WON">Won</SelectItem>
                  <SelectItem value="LOST">Lost</SelectItem>
                  <SelectItem value="WITHDRAWN">Withdrawn</SelectItem>
                  <SelectItem value="NO_BID">No bid</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">
                Note (optional)
              </label>
              <Textarea
                value={draftNote}
                onChange={(e) => setDraftNote(e.target.value)}
                placeholder="Why was this won/lost? Anything reviewers should know."
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)} disabled={saving}>
              Cancel
            </Button>
            <Button variant="gradient" onClick={save} disabled={saving}>
              {saving ? "Saving…" : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
