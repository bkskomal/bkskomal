"use client";

import { useEffect, useState } from "react";
import {
  Activity,
  Upload,
  CheckCircle2,
  UserCheck,
  GitCommit,
  Sparkles,
  Edit3,
  ThumbsUp,
  MessageSquare,
  Layers,
  Download,
  Loader2,
} from "lucide-react";
import { ActivityKind } from "@prisma/client";
import { formatDateTime, truncate } from "@/lib/utils";

interface Event {
  id: string;
  kind: ActivityKind;
  payload: any;
  createdAt: string;
  actor: { id: string; name: string | null; email: string } | null;
}

const META: Record<ActivityKind, { icon: any; verb: string }> = {
  RFP_UPLOADED: { icon: Upload, verb: "uploaded the RFP" },
  RFP_PROCESSED: { icon: CheckCircle2, verb: "extracted questions from the RFP" },
  QUESTION_ASSIGNED: { icon: UserCheck, verb: "assigned a question" },
  QUESTION_STATUS_CHANGED: { icon: GitCommit, verb: "changed status" },
  RESPONSE_GENERATED: { icon: Sparkles, verb: "generated a response" },
  RESPONSE_EDITED: { icon: Edit3, verb: "edited a response" },
  RESPONSE_FEEDBACK: { icon: ThumbsUp, verb: "rated a response" },
  COMMENT_ADDED: { icon: MessageSquare, verb: "commented" },
  BULK_GENERATION_STARTED: { icon: Layers, verb: "started bulk generation" },
  BULK_GENERATION_COMPLETED: { icon: Layers, verb: "finished bulk generation" },
  EXPORT_GENERATED: { icon: Download, verb: "exported the RFP" },
};

export function ActivityFeed({ rfpId }: { rfpId: string }) {
  const [events, setEvents] = useState<Event[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancel = false;
    const tick = async () => {
      try {
        const r = await fetch(`/api/rfps/${rfpId}/activity`);
        const d = await r.json();
        if (!cancel) setEvents(d.events ?? []);
      } finally {
        if (!cancel) setLoading(false);
      }
    };
    tick();
    const interval = setInterval(tick, 8000);
    return () => {
      cancel = true;
      clearInterval(interval);
    };
  }, [rfpId]);

  if (loading) {
    return (
      <div className="grid place-items-center py-6">
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (events.length === 0) {
    return (
      <p className="text-xs text-muted-foreground">No activity yet.</p>
    );
  }

  return (
    <ol className="relative space-y-3 border-l border-border pl-4">
      {events.map((e) => {
        const meta = META[e.kind];
        const Icon = meta?.icon ?? Activity;
        const actorLabel = e.actor?.name ?? e.actor?.email ?? "System";
        return (
          <li key={e.id} className="relative">
            <span className="absolute -left-[22px] grid h-4 w-4 place-items-center rounded-full border bg-background">
              <Icon className="h-2.5 w-2.5 text-muted-foreground" />
            </span>
            <div className="text-xs">
              <div>
                <span className="font-medium">{actorLabel}</span>{" "}
                <span className="text-muted-foreground">{meta?.verb ?? e.kind}</span>
                {payloadHint(e.kind, e.payload)}
              </div>
              <div className="text-[10px] text-muted-foreground">
                {formatDateTime(e.createdAt)}
              </div>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function payloadHint(kind: ActivityKind, payload: any): React.ReactNode {
  if (!payload) return null;
  switch (kind) {
    case "QUESTION_STATUS_CHANGED":
      if (payload.bulk) return <span className="text-muted-foreground"> · {payload.count} questions → {payload.status}</span>;
      return <span className="text-muted-foreground"> · #{payload.number} → {payload.to}</span>;
    case "QUESTION_ASSIGNED":
      if (payload.bulk) return <span className="text-muted-foreground"> · {payload.count} questions</span>;
      return <span className="text-muted-foreground"> · #{payload.number}</span>;
    case "RESPONSE_GENERATED":
      return payload.questionNumber ? (
        <span className="text-muted-foreground"> · Q{payload.questionNumber}</span>
      ) : null;
    case "BULK_GENERATION_STARTED":
    case "BULK_GENERATION_COMPLETED":
      return payload.total ? (
        <span className="text-muted-foreground"> · {payload.completed ?? 0}/{payload.total}</span>
      ) : null;
    case "EXPORT_GENERATED":
      return payload.format ? (
        <span className="text-muted-foreground"> · {String(payload.format).toUpperCase()}</span>
      ) : null;
    case "COMMENT_ADDED":
      return payload.number ? (
        <span className="text-muted-foreground"> · Q{payload.number}</span>
      ) : null;
    default:
      return null;
  }
}
