"use client";

// Rubric panel on the RFP detail page.
//
// Renders the auto-extracted evaluation rubric for an RFP:
//   - top row: total-score badge (green / amber / red) + extraction
//     confidence indicator + action buttons.
//   - criteria list: per-criterion label, weight, score, rationale and a
//     short evidence preview the user can expand.
//   - a red "MUST-HAVE GAP" banner when any mustHave criterion scores < 0.5.
//
// Member buttons:
//   - Re-extract  → POST /api/rfps/:rfpId/rubric        (writes criteria)
//   - Re-score    → POST /api/rfps/:rfpId/rubric/score  (SSE)
//   - Edit        → opens the criteria editor modal (PATCH on save).

import { useState, useTransition, useEffect } from "react";
import {
  Loader2,
  RefreshCw,
  Plus,
  Trash2,
  Pencil,
  Sparkles,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

export interface RubricCriterionView {
  id: string;
  label: string;
  weight: number;
  description: string;
  mustHave?: boolean;
}

export interface CriterionScoreView {
  criterionId: string;
  score: number;
  rationale: string;
  evidence: string[];
}

export interface RubricView {
  criteria: RubricCriterionView[];
  totalScore: number | null;
  perCriterionScores: Record<string, CriterionScoreView> | null;
  extractionConfidence: number | null;
  scoredAt: string | null;
}

interface Props {
  rfpId: string;
  initial: RubricView | null;
}

// --- Helpers ---------------------------------------------------------------

function scoreBucket(s: number | null): "green" | "amber" | "red" | "gray" {
  if (s === null || s === undefined) return "gray";
  if (s >= 0.8) return "green";
  if (s >= 0.5) return "amber";
  return "red";
}

function bucketClass(b: "green" | "amber" | "red" | "gray"): string {
  switch (b) {
    case "green":
      return "bg-emerald-100 text-emerald-900 dark:bg-emerald-900/40 dark:text-emerald-100";
    case "amber":
      return "bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-100";
    case "red":
      return "bg-rose-100 text-rose-900 dark:bg-rose-900/40 dark:text-rose-100";
    case "gray":
      return "bg-muted text-muted-foreground";
  }
}

function barClass(s: number, mustHave?: boolean): string {
  if (mustHave && s < 0.5) return "bg-rose-500";
  if (s >= 0.8) return "bg-emerald-500";
  if (s >= 0.5) return "bg-amber-500";
  return "bg-rose-500";
}

function fmtPct(n: number | null): string {
  if (n === null || n === undefined) return "—";
  return `${Math.round(n * 100)}%`;
}

// --- Component -------------------------------------------------------------

export function RubricPanel({ rfpId, initial }: Props) {
  const [rubric, setRubric] = useState<RubricView | null>(initial);
  const [extracting, startExtract] = useTransition();
  const [scoring, setScoring] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Refetch from the server. Used after extract/score/edit so the panel
  // reflects the persisted state without a hard page reload.
  async function reload() {
    const res = await fetch(`/api/rfps/${rfpId}/rubric`);
    if (!res.ok) return;
    const body = (await res.json()) as { rubric: ServerRubric | null };
    setRubric(serverToView(body.rubric));
  }

  async function reExtract() {
    startExtract(async () => {
      try {
        const res = await fetch(`/api/rfps/${rfpId}/rubric`, { method: "POST" });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        await reload();
        toast({ title: "Rubric re-extracted" });
      } catch (err) {
        toast({
          title: "Re-extract failed",
          description: err instanceof Error ? err.message : String(err),
          variant: "destructive",
        });
      }
    });
  }

  async function reScore() {
    if (scoring) return;
    setScoring(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/rubric/score`, { method: "POST" });
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        // Parse one SSE frame at a time.
        let idx;
        while ((idx = buffer.indexOf("\n\n")) >= 0) {
          const frame = buffer.slice(0, idx);
          buffer = buffer.slice(idx + 2);
          handleSseFrame(frame);
        }
      }
      await reload();
      toast({ title: "Rubric scored" });
    } catch (err) {
      toast({
        title: "Scoring failed",
        description: err instanceof Error ? err.message : String(err),
        variant: "destructive",
      });
    } finally {
      setScoring(false);
    }
  }

  // Live SSE update: merge per-criterion scores into the local state as they
  // arrive so the UI bars fill in incrementally.
  function handleSseFrame(frame: string) {
    let event = "message";
    let data = "";
    for (const line of frame.split("\n")) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data = line.slice(5).trim();
    }
    if (!data) return;
    let parsed: unknown;
    try {
      parsed = JSON.parse(data);
    } catch {
      return;
    }
    if (event === "criterion") {
      const s = parsed as CriterionScoreView;
      setRubric((prev) =>
        prev
          ? {
              ...prev,
              perCriterionScores: { ...(prev.perCriterionScores ?? {}), [s.criterionId]: s },
            }
          : prev,
      );
    } else if (event === "done") {
      const r = parsed as { totalScore: number; weakestCriteria: string[] };
      setRubric((prev) => (prev ? { ...prev, totalScore: r.totalScore } : prev));
    }
  }

  async function saveOverride(criteria: RubricCriterionView[]) {
    const res = await fetch(`/api/rfps/${rfpId}/rubric`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ criteria }),
    });
    if (!res.ok) {
      toast({
        title: "Save failed",
        description: `HTTP ${res.status}`,
        variant: "destructive",
      });
      return;
    }
    await reload();
    setEditOpen(false);
    toast({ title: "Criteria saved" });
  }

  // No rubric row at all → quiet empty card with a "extract now" button.
  if (!rubric) {
    return (
      <Card>
        <CardContent className="flex items-center justify-between gap-4 py-4">
          <div className="text-sm text-muted-foreground">
            No evaluation rubric detected yet.
          </div>
          <Button size="sm" variant="outline" onClick={reExtract} disabled={extracting}>
            {extracting ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Sparkles className="h-3.5 w-3.5" />
            )}
            Extract rubric
          </Button>
        </CardContent>
      </Card>
    );
  }

  const totalBucket = scoreBucket(rubric.totalScore);
  const mustHaveGaps = rubric.criteria.filter((c) => {
    if (!c.mustHave) return false;
    const s = rubric.perCriterionScores?.[c.id];
    return s ? s.score < 0.5 : false;
  });

  return (
    <Card>
      <CardContent className="space-y-3 py-4">
        <div className="flex flex-wrap items-center gap-3">
          <div
            className={cn(
              "inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm font-medium",
              bucketClass(totalBucket),
            )}
            aria-label="Total rubric score"
          >
            <span>Rubric score</span>
            <span className="font-bold">{fmtPct(rubric.totalScore)}</span>
          </div>

          <Badge variant="outline" className="gap-1">
            <span className="text-muted-foreground">Extraction</span>
            <span className="font-medium">{fmtPct(rubric.extractionConfidence)}</span>
          </Badge>

          {rubric.scoredAt ? (
            <span className="text-xs text-muted-foreground">
              Scored {new Date(rubric.scoredAt).toLocaleString()}
            </span>
          ) : (
            <span className="text-xs text-muted-foreground">Not scored yet</span>
          )}

          <div className="ml-auto flex items-center gap-2">
            <Button size="sm" variant="ghost" onClick={reExtract} disabled={extracting}>
              {extracting ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <RefreshCw className="h-3.5 w-3.5" />
              )}
              Re-extract
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={reScore}
              disabled={scoring || rubric.criteria.length === 0}
            >
              {scoring ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Sparkles className="h-3.5 w-3.5" />
              )}
              Re-score
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setEditOpen(true)}>
              <Pencil className="h-3.5 w-3.5" />
              Edit criteria
            </Button>
          </div>
        </div>

        {mustHaveGaps.length > 0 ? (
          <div className="flex items-start gap-2 rounded-md border border-rose-300 bg-rose-50 p-2 text-sm text-rose-900 dark:border-rose-800 dark:bg-rose-950/40 dark:text-rose-100">
            <AlertTriangle className="mt-0.5 h-4 w-4 flex-shrink-0" />
            <div>
              <div className="font-semibold">MUST-HAVE GAP</div>
              <div className="text-xs">
                {mustHaveGaps.length} mandatory criterion
                {mustHaveGaps.length === 1 ? "" : "a"} scoring below 50%:{" "}
                {mustHaveGaps.map((c) => c.label).join(", ")}
              </div>
            </div>
          </div>
        ) : null}

        {rubric.criteria.length === 0 ? (
          <div className="text-sm text-muted-foreground">
            No criteria detected in the RFP. Click <em>Edit criteria</em> to define them
            manually.
          </div>
        ) : (
          <ul className="space-y-2">
            {rubric.criteria.map((c) => {
              const s = rubric.perCriterionScores?.[c.id] ?? null;
              const open = expandedId === c.id;
              return (
                <li key={c.id} className="rounded-md border p-2">
                  <button
                    type="button"
                    onClick={() => setExpandedId(open ? null : c.id)}
                    className="flex w-full items-center gap-3 text-left"
                    aria-expanded={open}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate text-sm font-medium">{c.label}</span>
                        {c.mustHave ? (
                          <Badge variant="destructive" className="h-5 px-1.5 text-[10px]">
                            must-have
                          </Badge>
                        ) : null}
                        <span className="text-xs text-muted-foreground">
                          weight {fmtPct(c.weight)}
                        </span>
                      </div>
                      <div className="mt-1 h-2 w-full rounded bg-muted">
                        <div
                          className={cn("h-2 rounded transition-all", s ? barClass(s.score, c.mustHave) : "bg-muted")}
                          style={{ width: s ? `${Math.round(s.score * 100)}%` : "0%" }}
                        />
                      </div>
                    </div>
                    <div className="w-12 text-right text-sm font-semibold tabular-nums">
                      {s ? fmtPct(s.score) : "—"}
                    </div>
                  </button>
                  {open ? (
                    <div className="mt-2 space-y-2 text-xs">
                      <div className="text-muted-foreground">{c.description}</div>
                      {s ? (
                        <>
                          <div>
                            <span className="font-medium">Rationale: </span>
                            {s.rationale || "—"}
                          </div>
                          {s.evidence.length > 0 ? (
                            <div>
                              <div className="font-medium">Evidence</div>
                              <ul className="mt-1 list-disc pl-5">
                                {s.evidence.slice(0, 3).map((e, i) => (
                                  <li key={i} className="text-muted-foreground">{e}</li>
                                ))}
                              </ul>
                            </div>
                          ) : null}
                        </>
                      ) : (
                        <div className="text-muted-foreground">Not scored yet</div>
                      )}
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>

      <EditCriteriaDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        initial={rubric.criteria}
        onSave={saveOverride}
      />
    </Card>
  );
}

// --- Server payload shape ---------------------------------------------------

interface ServerRubric {
  criteria: unknown;
  totalScore: number | null;
  perCriterionScores: unknown;
  extractionConfidence: number | null;
  scoredAt: string | null;
}

function serverToView(row: ServerRubric | null): RubricView | null {
  if (!row) return null;
  const criteria = Array.isArray(row.criteria)
    ? (row.criteria as RubricCriterionView[])
    : [];
  const perCriterion =
    row.perCriterionScores && typeof row.perCriterionScores === "object"
      ? (row.perCriterionScores as Record<string, CriterionScoreView>)
      : null;
  return {
    criteria,
    totalScore: row.totalScore ?? null,
    perCriterionScores: perCriterion,
    extractionConfidence: row.extractionConfidence ?? null,
    scoredAt: row.scoredAt ?? null,
  };
}

// --- Edit criteria modal ---------------------------------------------------

interface EditCriteriaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initial: RubricCriterionView[];
  onSave: (criteria: RubricCriterionView[]) => Promise<void> | void;
}

function EditCriteriaDialog({ open, onOpenChange, initial, onSave }: EditCriteriaDialogProps) {
  const [rows, setRows] = useState<RubricCriterionView[]>(initial);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) setRows(initial.length ? initial : [defaultCriterion(1)]);
  }, [open, initial]);

  const total = rows.reduce((acc, r) => acc + (r.weight || 0), 0);

  function updateRow(i: number, patch: Partial<RubricCriterionView>) {
    setRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  }
  function addRow() {
    setRows((prev) => [...prev, defaultCriterion(prev.length + 1)]);
  }
  function removeRow(i: number) {
    setRows((prev) => prev.filter((_, idx) => idx !== i));
  }

  async function submit() {
    setSaving(true);
    try {
      // Normalize weights to sum 1.0 before sending.
      const sum = rows.reduce((acc, r) => acc + (r.weight || 0), 0);
      const normalized = sum > 0
        ? rows.map((r) => ({ ...r, weight: r.weight / sum }))
        : rows.map((r) => ({ ...r, weight: 1 / Math.max(1, rows.length) }));
      await onSave(normalized);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Edit evaluation rubric</DialogTitle>
          <DialogDescription>
            Define how this RFP will be scored. Weights are normalized to sum to 100% on save.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[55vh] space-y-3 overflow-y-auto pr-1">
          {rows.map((r, i) => (
            <div key={i} className="grid grid-cols-12 gap-2 rounded-md border p-2">
              <div className="col-span-12 sm:col-span-7">
                <Label className="text-xs">Label</Label>
                <Input
                  value={r.label}
                  onChange={(e) => updateRow(i, { label: e.target.value })}
                  placeholder="e.g. Technical Approach"
                />
              </div>
              <div className="col-span-12 sm:col-span-5">
                <Label className="text-xs">
                  Weight ({Math.round((r.weight || 0) * 100)}%)
                </Label>
                <Input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={r.weight}
                  onChange={(e) => updateRow(i, { weight: parseFloat(e.target.value) })}
                />
              </div>
              <div className="col-span-12">
                <Label className="text-xs">Description</Label>
                <Textarea
                  rows={2}
                  value={r.description}
                  onChange={(e) => updateRow(i, { description: e.target.value })}
                  placeholder="What is the buyer looking for in this criterion?"
                />
              </div>
              <div className="col-span-12 flex items-center justify-between">
                <label className="flex items-center gap-2 text-xs">
                  <Checkbox
                    checked={r.mustHave ?? false}
                    onCheckedChange={(v) => updateRow(i, { mustHave: v === true })}
                  />
                  Must-have (gating)
                </label>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  onClick={() => removeRow(i)}
                  aria-label={`Remove ${r.label || `criterion ${i + 1}`}`}
                >
                  <Trash2 className="h-3.5 w-3.5" /> Remove
                </Button>
              </div>
            </div>
          ))}
          <Button type="button" size="sm" variant="outline" onClick={addRow}>
            <Plus className="h-3.5 w-3.5" /> Add criterion
          </Button>
        </div>
        <DialogFooter className="items-center">
          <div className="mr-auto text-xs text-muted-foreground">
            Sum of weights: {Math.round(total * 100)}% (will be normalized to 100%)
          </div>
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={saving || rows.length === 0}>
            {saving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function defaultCriterion(n: number): RubricCriterionView {
  return {
    id: `criterion-${n}-${Math.random().toString(36).slice(2, 7)}`,
    label: "",
    weight: 0.25,
    description: "",
    mustHave: false,
  };
}
