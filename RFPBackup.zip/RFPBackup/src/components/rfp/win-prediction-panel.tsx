"use client";

// Win-prediction panel (Tier C — moonshot).
//
// Lives in the RFP detail header next to the OutcomeChip. Renders:
//   * A probability gauge (0..100%) with traffic-light colouring tied to
//     the GO / REVIEW / NO_BID thresholds in scorer.ts.
//   * A big recommendation badge (override-aware: when an admin pins
//     overrideAction, the badge shows the override and a small "(forced)"
//     suffix so reviewers know the model didn't recommend this).
//   * Top 3 positive / top 3 negative feature contributions, decoded
//     from the JSON snapshot the scorer persisted.
//   * Re-score button (admins) — POST /api/rfps/:rfpId/prediction.
//   * Override dropdown (admins) — PATCH /api/rfps/:rfpId/prediction.
//   * Modal listing every feature when expanded.
//
// State model: the panel fetches on mount and re-fetches after each
// mutation. We deliberately don't poll — predictions only change when
// someone uploads, re-scores, or overrides. The parent (`RfpViewer`)
// passes `isAdmin` so the panel can show admin-only controls without
// re-querying membership.

import { useEffect, useState } from "react";
import {
  CheckCircle2,
  Ban,
  Eye,
  RefreshCw,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  Info,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { toast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils";

interface PredictionFeatures {
  questionCount: number;
  avgQuestionConfidence: number;
  avgGroundingScore: number;
  complexityDist: { simple: number; moderate: number; complex: number };
  eligibilityDist: { answerable: number; needs_info: number; out_of_scope: number };
  daysToDeadline: number | null;
  historicalWinRate: number;
  similarRfpCount: number;
  similarRfpWinRate: number | null;
  hasGoldenAnswerCoverage: number;
  daysSinceOldestSource: number | null;
}

interface PredictionResponse {
  rfpId: string;
  probability: number;
  recommendation: string;
  effectiveRecommendation: string;
  features: PredictionFeatures | null;
  contributions: Record<string, number> | null;
  modelVersion: string;
  overrideAction: string | null;
  overrideById: string | null;
  overrideAt: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Props {
  rfpId: string;
  /** Show admin-only controls (re-score, override). */
  isAdmin: boolean;
}

/** Maps the three tiers to their badge styling + icon + label. */
const TIER_STYLE: Record<
  string,
  {
    label: string;
    pill: string;
    badge: string;
    icon: React.ComponentType<{ className?: string }>;
  }
> = {
  go: {
    label: "GO",
    pill: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300",
    badge: "bg-emerald-500 text-white",
    icon: CheckCircle2,
  },
  review: {
    label: "REVIEW",
    pill: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
    badge: "bg-amber-500 text-white",
    icon: Eye,
  },
  no_bid: {
    label: "NO BID",
    pill: "bg-rose-500/15 text-rose-700 dark:text-rose-300",
    badge: "bg-rose-500 text-white",
    icon: Ban,
  },
};

/** Pretty labels for the contribution keys. Falls back to the raw key. */
const CONTRIBUTION_LABEL: Record<string, string> = {
  historicalWinRate: "Historical win rate",
  avgQuestionConfidence: "Answer confidence",
  avgGroundingScore: "Grounding score",
  complexity: "Complex questions",
  outOfScope: "Out-of-scope asks",
  needsInfo: "Needs-info gaps",
  daysToDeadline: "Deadline pressure",
  goldenAnswerCoverage: "Golden-answer coverage",
  similarRfpWinRate: "Similar-RFP outcomes",
  sourceStaleness: "Source staleness",
};

export function WinPredictionPanel({ rfpId, isAdmin }: Props) {
  const [data, setData] = useState<PredictionResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const res = await fetch(`/api/rfps/${rfpId}/prediction`);
        if (res.status === 404) {
          if (!cancelled) setMissing(true);
          return;
        }
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const body = (await res.json()) as PredictionResponse;
        if (!cancelled) setData(body);
      } catch (e) {
        if (!cancelled) {
          toast({
            title: "Couldn't load win prediction",
            description: e instanceof Error ? e.message : String(e),
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [rfpId]);

  async function rescore() {
    setBusy(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/prediction`, { method: "POST" });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({
          title: "Couldn't re-score",
          description: err.error ?? `HTTP ${res.status}`,
        });
        return;
      }
      const body = (await res.json()) as PredictionResponse;
      setData(body);
      setMissing(false);
      toast({ title: "Win prediction updated", variant: "success" });
    } finally {
      setBusy(false);
    }
  }

  async function setOverride(action: "go" | "no_bid" | null) {
    setBusy(true);
    try {
      const res = await fetch(`/api/rfps/${rfpId}/prediction`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({
          title: "Couldn't apply override",
          description: err.error ?? `HTTP ${res.status}`,
        });
        return;
      }
      const body = (await res.json()) as PredictionResponse;
      setData(body);
      setMissing(false);
      toast({
        title: action ? `Override pinned: ${TIER_STYLE[action].label}` : "Override cleared",
        variant: "success",
      });
    } finally {
      setBusy(false);
    }
  }

  if (loading) {
    return (
      <div className="inline-flex items-center gap-2 rounded-full bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">
        <RefreshCw className="h-3 w-3 animate-spin" /> Scoring…
      </div>
    );
  }

  if (missing || !data) {
    return isAdmin ? (
      <button
        type="button"
        onClick={rescore}
        disabled={busy}
        className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium text-muted-foreground hover:bg-muted/80"
        title="No prediction yet — click to score"
      >
        <RefreshCw className={cn("h-3 w-3", busy && "animate-spin")} /> Score win likelihood
      </button>
    ) : null;
  }

  const tier = TIER_STYLE[data.effectiveRecommendation] ?? TIER_STYLE.review;
  const Icon = tier.icon;
  const probabilityPct = Math.round(data.probability * 100);

  const sorted = Object.entries(data.contributions ?? {})
    .filter(([, v]) => Math.abs(v) > 0.0001)
    .sort((a, b) => b[1] - a[1]);
  const positives = sorted.filter(([, v]) => v > 0).slice(0, 3);
  const negatives = [...sorted].filter(([, v]) => v < 0).reverse().slice(0, 3);

  return (
    <>
      <div className="inline-flex items-center gap-2 rounded-md border bg-card px-2.5 py-1 text-xs">
        <Icon className={cn("h-4 w-4", tier.pill.split(" ")[1])} />
        <span
          className={cn("rounded-full px-2 py-0.5 text-[10px] font-bold", tier.badge)}
          title={
            data.overrideAction
              ? `Model recommended ${data.recommendation.toUpperCase()}; admin pinned ${data.effectiveRecommendation.toUpperCase()}`
              : `Model recommendation`
          }
        >
          {tier.label}
          {data.overrideAction ? " · forced" : ""}
        </span>
        <span className="font-mono text-xs tabular-nums" title="Predicted win probability">
          {probabilityPct}%
        </span>
        <button
          type="button"
          onClick={() => setDetailsOpen(true)}
          className="text-muted-foreground hover:text-foreground"
          title="See full feature breakdown"
        >
          <ChevronRight className="h-3 w-3" />
        </button>
        {isAdmin ? (
          <>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 px-1.5 text-[10px]"
              onClick={rescore}
              disabled={busy}
              title="Re-run the scorer"
            >
              <RefreshCw className={cn("h-3 w-3", busy && "animate-spin")} />
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-1.5 text-[10px]"
                  disabled={busy}
                  title="Override the model recommendation"
                >
                  Override
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setOverride("go")}>
                  Force GO
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setOverride("no_bid")}>
                  Force NO BID
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setOverride(null)}>
                  Clear override
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        ) : null}
      </div>

      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              Win prediction · {tier.label} · {probabilityPct}%
            </DialogTitle>
            <DialogDescription>
              The model anchors on this organisation&apos;s historical win
              rate and adjusts for the shape of the RFP, the strength of
              your draft answers, and how similar past deals turned out.
              It&apos;s a decision aid, not a forecast — pin an override
              if your gut says otherwise.
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="mb-1 flex items-center gap-1 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                <TrendingUp className="h-3 w-3" /> Top reasons it&apos;s worth bidding
              </h3>
              {positives.length === 0 ? (
                <p className="text-xs text-muted-foreground">No positive lift fired.</p>
              ) : (
                <ul className="space-y-1 text-xs">
                  {positives.map(([k, v]) => (
                    <li key={k} className="flex items-center justify-between gap-2">
                      <span>{CONTRIBUTION_LABEL[k] ?? k}</span>
                      <span className="font-mono text-emerald-600 dark:text-emerald-300">
                        +{(v * 100).toFixed(0)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div>
              <h3 className="mb-1 flex items-center gap-1 text-xs font-semibold text-rose-700 dark:text-rose-300">
                <TrendingDown className="h-3 w-3" /> Top reasons to be cautious
              </h3>
              {negatives.length === 0 ? (
                <p className="text-xs text-muted-foreground">No negative lift fired.</p>
              ) : (
                <ul className="space-y-1 text-xs">
                  {negatives.map(([k, v]) => (
                    <li key={k} className="flex items-center justify-between gap-2">
                      <span>{CONTRIBUTION_LABEL[k] ?? k}</span>
                      <span className="font-mono text-rose-600 dark:text-rose-300">
                        {(v * 100).toFixed(0)}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>

          {data.features ? (
            <div className="mt-4 space-y-1 rounded-md border bg-muted/30 p-3 text-xs">
              <h3 className="mb-1 flex items-center gap-1 font-semibold">
                <Info className="h-3 w-3" /> All features
              </h3>
              <FeatureRow label="Questions" value={data.features.questionCount.toString()} />
              <FeatureRow
                label="Avg answer confidence"
                value={fmtPct(data.features.avgQuestionConfidence)}
              />
              <FeatureRow
                label="Avg grounding score"
                value={fmtPct(data.features.avgGroundingScore)}
              />
              <FeatureRow
                label="Complex questions"
                value={fmtPct(data.features.complexityDist.complex)}
              />
              <FeatureRow
                label="Out-of-scope questions"
                value={fmtPct(data.features.eligibilityDist.out_of_scope)}
              />
              <FeatureRow
                label="Days to deadline"
                value={
                  data.features.daysToDeadline == null
                    ? "—"
                    : `${data.features.daysToDeadline}d`
                }
              />
              <FeatureRow
                label="Historical win rate"
                value={fmtPct(data.features.historicalWinRate)}
              />
              <FeatureRow
                label="Similar RFPs"
                value={`${data.features.similarRfpCount}${
                  data.features.similarRfpWinRate != null
                    ? ` (${fmtPct(data.features.similarRfpWinRate)})`
                    : ""
                }`}
              />
              <FeatureRow
                label="Golden-answer coverage"
                value={fmtPct(data.features.hasGoldenAnswerCoverage)}
              />
              <FeatureRow
                label="Oldest source age"
                value={
                  data.features.daysSinceOldestSource == null
                    ? "—"
                    : `${data.features.daysSinceOldestSource}d`
                }
              />
            </div>
          ) : null}

          <p className="mt-2 text-[10px] text-muted-foreground">
            Model {data.modelVersion} · updated {new Date(data.updatedAt).toLocaleString()}
            {data.overrideAction
              ? ` · pinned to ${data.overrideAction.toUpperCase()} by an admin`
              : ""}
          </p>
        </DialogContent>
      </Dialog>
    </>
  );
}

function FeatureRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-2 py-0.5">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono tabular-nums">{value}</span>
    </div>
  );
}

function fmtPct(value: number): string {
  return `${Math.round(value * 100)}%`;
}
