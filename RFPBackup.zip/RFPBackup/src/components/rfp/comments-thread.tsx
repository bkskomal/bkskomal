"use client";

import { useEffect, useState } from "react";
import { Trash2, Send, Loader2, MessageSquare } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/components/ui/use-toast";
import { formatDateTime } from "@/lib/utils";

interface Comment {
  id: string;
  body: string;
  createdAt: string;
  author: { id: string; name: string | null; email: string };
  mentions?: Array<{ user: { id: string; name: string | null; email: string } }>;
}

/**
 * Render comment body with @mentions highlighted. We don't trust the parsed
 * mentions list for rendering; we re-scan for @email/@handle tokens and just
 * style them. Strict server-side resolution still controls notifications.
 */
function RenderedBody({ body }: { body: string }) {
  const re = /(@[a-zA-Z0-9._-]+(?:@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})?)/g;
  const parts = body.split(re);
  return (
    <p className="text-sm whitespace-pre-wrap leading-relaxed">
      {parts.map((p, i) =>
        i % 2 === 1 ? (
          <span
            key={i}
            className="rounded bg-primary/15 text-primary font-medium px-1"
          >
            {p}
          </span>
        ) : (
          <span key={i}>{p}</span>
        ),
      )}
    </p>
  );
}

export function CommentsThread({
  questionId,
  currentUserId,
  onCountChange,
}: {
  questionId: string;
  currentUserId: string;
  onCountChange?: (count: number) => void;
}) {
  const [comments, setComments] = useState<Comment[]>([]);
  const [body, setBody] = useState("");
  const [pending, setPending] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancel = false;
    setLoading(true);
    fetch(`/api/questions/${questionId}/comments`)
      .then((r) => r.json())
      .then((d) => {
        if (cancel) return;
        setComments(d.comments ?? []);
        onCountChange?.((d.comments ?? []).length);
      })
      .finally(() => !cancel && setLoading(false));
    return () => {
      cancel = true;
    };
  }, [questionId, onCountChange]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!body.trim() || pending) return;
    setPending(true);
    const res = await fetch(`/api/questions/${questionId}/comments`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ body }),
    });
    setPending(false);
    if (!res.ok) {
      toast({ title: "Couldn't post", description: (await res.json()).error });
      return;
    }
    const { comment } = await res.json();
    const next = [...comments, comment];
    setComments(next);
    onCountChange?.(next.length);
    setBody("");
  }

  async function remove(id: string) {
    const res = await fetch(`/api/comments/${id}`, { method: "DELETE" });
    if (res.ok) {
      const next = comments.filter((c) => c.id !== id);
      setComments(next);
      onCountChange?.(next.length);
    } else {
      toast({ title: "Couldn't delete" });
    }
  }

  function initials(c: Comment) {
    return (c.author.name ?? c.author.email).slice(0, 2).toUpperCase();
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 text-sm font-medium">
        <MessageSquare className="h-4 w-4 text-muted-foreground" />
        Discussion {comments.length > 0 ? `(${comments.length})` : ""}
      </div>

      {loading ? (
        <div className="grid place-items-center py-6">
          <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
        </div>
      ) : comments.length === 0 ? (
        <p className="text-xs text-muted-foreground">
          No comments yet. Use this space to discuss the answer with teammates.
        </p>
      ) : (
        <ul className="space-y-3">
          {comments.map((c) => (
            <li key={c.id} className="flex gap-2.5">
              <Avatar className="h-7 w-7 shrink-0">
                <AvatarFallback className="text-[10px]">{initials(c)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1 rounded-lg border bg-card p-2.5">
                <div className="flex items-baseline justify-between gap-2">
                  <div className="text-xs font-medium">
                    {c.author.name ?? c.author.email}
                    <span className="ml-2 font-normal text-muted-foreground">
                      {formatDateTime(c.createdAt)}
                    </span>
                  </div>
                  {c.author.id === currentUserId ? (
                    <button
                      onClick={() => remove(c.id)}
                      className="opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                      title="Delete"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  ) : null}
                </div>
                <div className="mt-1">
                  <RenderedBody body={c.body} />
                </div>
                {c.mentions && c.mentions.length > 0 ? (
                  <div className="mt-1.5 text-[10px] text-muted-foreground">
                    Mentions: {c.mentions.map((m) => m.user.name ?? m.user.email).join(", ")}
                  </div>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
      )}

      <form onSubmit={submit} className="space-y-2">
        <Textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder="Add a comment…  Type @ to mention a teammate by email or username."
          rows={2}
          className="text-sm"
          disabled={pending}
        />
        <div className="flex justify-end">
          <Button size="sm" type="submit" disabled={!body.trim() || pending}>
            {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
            Post
          </Button>
        </div>
      </form>
    </div>
  );
}
