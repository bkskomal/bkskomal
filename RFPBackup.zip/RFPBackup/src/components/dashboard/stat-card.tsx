// AdminLTE-style "small-box" stat card — solid background color, big number,
// small label, decorative icon in the corner, "More info →" footer that links
// to a deeper view.
//
// Variants:
//   info     teal / cyan
//   success  green
//   warning  amber
//   danger   red
//   primary  blue / brand
//   indigo   purple-ish
//
// All variants render the same shape — only the bg / border colors change.

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

type StatVariant = "info" | "success" | "warning" | "danger" | "primary" | "indigo";

interface StatCardProps {
  variant?: StatVariant;
  value: number | string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  href?: string;
  /** Optional sub-line below the label (e.g. "↑ 4% from last week"). */
  hint?: string;
}

const VARIANT_BG: Record<StatVariant, string> = {
  info: "bg-cyan-500 hover:bg-cyan-600",
  success: "bg-emerald-500 hover:bg-emerald-600",
  warning: "bg-amber-500 hover:bg-amber-600",
  danger: "bg-rose-500 hover:bg-rose-600",
  primary: "bg-sky-600 hover:bg-sky-700",
  indigo: "bg-indigo-600 hover:bg-indigo-700",
};

const VARIANT_FOOTER: Record<StatVariant, string> = {
  info: "bg-cyan-600/80",
  success: "bg-emerald-600/80",
  warning: "bg-amber-600/80",
  danger: "bg-rose-600/80",
  primary: "bg-sky-700/80",
  indigo: "bg-indigo-700/80",
};

export function StatCard({
  variant = "info",
  value,
  label,
  icon: Icon,
  href,
  hint,
}: StatCardProps) {
  const inner = (
    <div className={cn("relative overflow-hidden rounded-xl text-white shadow-sm transition-colors", VARIANT_BG[variant])}>
      <div className="flex items-start justify-between gap-3 p-5">
        <div className="min-w-0">
          <div className="text-3xl font-bold leading-tight">{value}</div>
          <div className="mt-1 text-sm font-medium opacity-95">{label}</div>
          {hint ? <div className="mt-0.5 text-xs opacity-80">{hint}</div> : null}
        </div>
        {Icon ? (
          <Icon
            className="h-16 w-16 shrink-0 opacity-25"
            aria-hidden
          />
        ) : null}
      </div>
      {href ? (
        <div
          className={cn(
            "flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium",
            VARIANT_FOOTER[variant],
          )}
        >
          More info <ArrowRight className="h-3 w-3" />
        </div>
      ) : null}
    </div>
  );

  if (href) {
    return (
      <Link
        href={href}
        className="block focus:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-xl"
      >
        {inner}
      </Link>
    );
  }
  return inner;
}
