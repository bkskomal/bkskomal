"use client";

// Dark, collapsible left sidebar — Gentelella-style layout:
//   - Brand block at the top with the AutoRFP logo
//   - User profile block (avatar + greeting + name)
//   - Sectioned nav (General / Knowledge / Admin) with section headers
//   - Active item highlighted with a left accent bar
//   - Collapsed mode (icon-only, ~64px wide) toggled from the header hamburger;
//     hovering a collapsed item shows a tooltip with the label.
//
// State (collapsed) lives in DashboardShell so the header toggle stays in sync.

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState } from "react";
import {
  LayoutDashboard,
  FolderKanban,
  Library,
  Users,
  Settings,
  Star,
  Wrench,
  GitBranch,
  BarChart3,
  Search,
  MessageSquare,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface OrgRef {
  id: string;
  name: string;
  slug: string;
}

interface SidebarProps {
  orgs: OrgRef[];
  activeOrgId?: string;
  user?: { name?: string | null; email?: string | null };
  collapsed?: boolean;
  /** Callback invoked by the "Chat" action item — maximizes the right panel. */
  onChatMaximize?: () => void;
}

interface NavItem {
  /** Route href (link items). Mutually exclusive with `action`. */
  href?: string;
  /** Action key (button items). When present, item renders as <button>. */
  action?: "chat-maximize";
  label: string;
  icon: typeof LayoutDashboard;
  exact?: boolean;
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const NAV = (orgId: string): NavSection[] => [
  {
    title: "General",
    items: [
      { href: `/dashboard?org=${orgId}`, label: "Overview", icon: LayoutDashboard, exact: true },
      { href: `/dashboard/projects?org=${orgId}`, label: "Projects", icon: FolderKanban },
      { href: `/dashboard/pipelines?org=${orgId}`, label: "Workflows", icon: GitBranch },
      { href: `/dashboard/insights?org=${orgId}`, label: "Insights", icon: BarChart3 },
      // Chat lives in the persistent right-side panel; this entry just
      // maximizes that panel rather than navigating to a separate page.
      { action: "chat-maximize", label: "Chat", icon: MessageSquare },
    ],
  },
  {
    title: "Knowledge",
    items: [
      { href: `/dashboard/indexes?org=${orgId}`, label: "Knowledge Bases", icon: Library },
      { href: `/dashboard/golden?org=${orgId}`, label: "Golden Answers", icon: Star },
    ],
  },
  {
    title: "Admin",
    items: [
      { href: `/dashboard/tools?org=${orgId}`, label: "Tools", icon: Wrench },
      { href: `/dashboard/members?org=${orgId}`, label: "Members", icon: Users },
      { href: `/dashboard/settings?org=${orgId}`, label: "Settings", icon: Settings },
    ],
  },
];

export function Sidebar({ orgs, activeOrgId, user, collapsed = false, onChatMaximize }: SidebarProps) {
  const pathname = usePathname();
  const orgId = activeOrgId ?? orgs[0]?.id;
  const allSections = useMemo(() => (orgId ? NAV(orgId) : []), [orgId]);
  const [query, setQuery] = useState("");
  // Filter nav items by label (case-insensitive). Empty query = show all.
  const sections = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return allSections;
    return allSections
      .map((s) => ({ ...s, items: s.items.filter((i) => i.label.toLowerCase().includes(q)) }))
      .filter((s) => s.items.length > 0);
  }, [allSections, query]);

  const initials = ((user?.name ?? user?.email ?? "U") as string)
    .split(/\s+/)
    .map((s) => s[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const greeting = user?.name?.split(" ")[0] ?? user?.email?.split("@")[0] ?? "User";

  return (
    <aside
      className={cn(
        // Header (h-16) is full-width above; sticky top-16 keeps the nav
        // pinned just below it as the main column scrolls. self-start
        // prevents the flex row from stretching it.
        "sticky top-16 hidden shrink-0 flex-col self-start bg-[#2A3F54] text-slate-100 transition-all duration-200 lg:flex",
        collapsed ? "w-16" : "w-64",
      )}
      style={{ height: "calc(100vh - 4rem)" }}
    >
      {/* Brand removed — header is now full-width and shows it. */}

      {/* User profile block ------------------------------------------- */}
      {user && !collapsed ? (
        <div className="flex items-center gap-3 border-b border-white/5 px-4 py-4">
          <Avatar className="h-10 w-10 ring-2 ring-white/10">
            <AvatarFallback className="bg-slate-700 text-sm text-white">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="text-[11px] uppercase tracking-wider text-slate-400">
              Welcome,
            </div>
            <div className="truncate text-sm font-semibold text-white">{greeting}</div>
          </div>
        </div>
      ) : user ? (
        <div className="flex justify-center border-b border-white/5 py-4">
          <Avatar className="h-9 w-9 ring-2 ring-white/10">
            <AvatarFallback className="bg-slate-700 text-xs text-white">
              {initials}
            </AvatarFallback>
          </Avatar>
        </div>
      ) : null}

      {/* Search box (AdminLTE-style) --------------------------------- */}
      {!collapsed ? (
        <div className="border-b border-white/5 px-3 py-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search"
              className="w-full rounded-md border border-white/10 bg-white/5 py-1.5 pl-8 pr-2 text-xs text-white placeholder:text-slate-400 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
        </div>
      ) : null}

      {/* Navigation --------------------------------------------------- */}
      <nav className="flex-1 overflow-y-auto py-2">
        {sections.map((section, idx) => (
          <div key={section.title} className={cn(idx > 0 && "mt-3")}>
            {!collapsed ? (
              <div className="px-5 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                {section.title}
              </div>
            ) : (
              <div className="mx-3 my-2 border-t border-white/5" aria-hidden />
            )}
            <ul className="space-y-px">
              {section.items.map((item) => {
                const itemKey = item.href ?? `action:${item.action ?? item.label}`;
                const isLink = typeof item.href === "string";
                const active =
                  isLink && item.exact
                    ? pathname === item.href!.split("?")[0]
                    : isLink
                    ? pathname.startsWith(item.href!.split("?")[0])
                    : false;
                const className = cn(
                  "group relative flex w-full items-center gap-3 px-5 py-2 text-left text-sm transition-colors",
                  collapsed && "justify-center px-0",
                  active
                    ? "bg-[#1F2D3D] text-white"
                    : "text-slate-300 hover:bg-[#243646] hover:text-white",
                );
                const inner = (
                  <>
                    {active ? (
                      <span className="absolute left-0 top-0 h-full w-1 bg-primary" aria-hidden />
                    ) : null}
                    <item.icon className="h-4 w-4 shrink-0" />
                    {!collapsed ? <span className="truncate">{item.label}</span> : null}
                  </>
                );
                return (
                  <li key={itemKey}>
                    {isLink ? (
                      <Link href={item.href!} title={collapsed ? item.label : undefined} className={className}>
                        {inner}
                      </Link>
                    ) : (
                      // Action items (e.g. Chat → maximize). Rendered as a
                      // button so they don't navigate; the handler from
                      // DashboardShell does the work.
                      <button
                        type="button"
                        title={collapsed ? item.label : undefined}
                        className={className}
                        onClick={() => {
                          if (item.action === "chat-maximize") onChatMaximize?.();
                        }}
                      >
                        {inner}
                      </button>
                    )}
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      {/* Footer ------------------------------------------------------- */}
      <div className="border-t border-white/5 px-4 py-3 text-[10px] uppercase tracking-wider text-slate-500">
        {!collapsed ? "OATI AutoRFP · v1.0" : "v1"}
      </div>
    </aside>
  );
}
