"use client";

// Top-level shell for every /dashboard/* page. Owns the sidebar-collapsed
// state, persists it to localStorage, and forwards the toggle handler to the
// header (where the hamburger lives) and the collapsed flag to the sidebar.
//
// Kept as a client component because we need useState + window for
// persistence. The server layout fetches data and hands it down.

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { Sidebar } from "@/components/dashboard/sidebar";
import { Header } from "@/components/dashboard/header";
import { ChatSidebar } from "@/components/dashboard/chat-sidebar";
import { ConfirmProvider } from "@/components/ui/confirm";

const COLLAPSED_KEY = "autorfp.sidebar.collapsed";
const CHAT_OPEN_KEY = "autorfp.chatpanel.open";
const CHAT_MAX_KEY = "autorfp.chatpanel.maximized";

interface Props {
  user: { name?: string | null; email?: string | null };
  orgs: { id: string; name: string; slug: string }[];
  activeOrgId?: string;
  signOutAction: () => Promise<void>;
  children: React.ReactNode;
}

export function DashboardShell({
  user,
  orgs,
  activeOrgId,
  signOutAction,
  children,
}: Props) {
  // SSR + client both start "expanded" to avoid a hydration mismatch — we
  // upgrade to the persisted choice once the client has mounted.
  const [collapsed, setCollapsed] = useState(false);
  // Right-side chat panel: defaults open. Persisted across pages so the
  // user's choice sticks. SSR starts open; hydration may flip to closed.
  const [chatPanelOpen, setChatPanelOpen] = useState(true);
  // "Maximized" = chat takes the full content area (main column hidden,
  // left nav still visible). Opt-in via the chat-panel header button.
  const [chatMaximized, setChatMaximized] = useState(false);
  // Tracks whether the viewport is too narrow for the 400px expanded panel.
  // When true, the chat sidebar forces itself to the collapsed strip
  // regardless of the user's persisted preference — so the preference
  // isn't lost when the user shrinks the window and grows it back.
  const [narrowViewport, setNarrowViewport] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
    try {
      const stored = window.localStorage.getItem(COLLAPSED_KEY);
      if (stored === "1") setCollapsed(true);
      const chatStored = window.localStorage.getItem(CHAT_OPEN_KEY);
      // Default open: only flip to closed when explicitly "0".
      if (chatStored === "0") setChatPanelOpen(false);
      const maxStored = window.localStorage.getItem(CHAT_MAX_KEY);
      if (maxStored === "1") setChatMaximized(true);
    } catch {
      // ignore (private window, quota, etc.)
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(COLLAPSED_KEY, collapsed ? "1" : "0");
    } catch {
      // ignore
    }
  }, [collapsed, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(CHAT_OPEN_KEY, chatPanelOpen ? "1" : "0");
    } catch {
      // ignore
    }
  }, [chatPanelOpen, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(CHAT_MAX_KEY, chatMaximized ? "1" : "0");
    } catch {
      // ignore
    }
  }, [chatMaximized, hydrated]);

  // Auto-collapse the right chat panel on narrow viewports. Reads + listens
  // to a matchMedia query; threshold 1024px (Tailwind's `lg`). Doesn't
  // overwrite the user's persisted preference — restored when the viewport
  // grows back.
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(max-width: 1023px)");
    const onChange = () => setNarrowViewport(mq.matches);
    onChange();
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  // Effective state: narrow viewport forces collapsed (open=false) and
  // disables maximize (no point on a tiny screen).
  const effectiveChatOpen = chatPanelOpen && !narrowViewport;
  const effectiveChatMaximized = chatMaximized && !narrowViewport;

  // Auto-collapse the maximized chat when the user navigates to a different
  // page (e.g. clicking a left-nav link). The chat-maximize action item
  // doesn't change pathname so it doesn't trigger this. We track the prior
  // pathname in a ref so the effect only fires on REAL changes, not on the
  // initial mount.
  const pathname = usePathname();
  const lastPathRef = useRef<string | null>(null);
  useEffect(() => {
    if (lastPathRef.current !== null && lastPathRef.current !== pathname) {
      if (chatMaximized) setChatMaximized(false);
    }
    lastPathRef.current = pathname;
  }, [pathname, chatMaximized]);

  const activeOrg = orgs.find((o) => o.id === activeOrgId) ?? orgs[0];

  return (
    <ConfirmProvider>
      {/* Header lives in a top row spanning the FULL viewport width — left
          nav, main, and right chat all sit below it. Header is sticky so it
          stays visible while pages scroll. */}
      <div className="flex min-h-screen flex-col bg-background">
        <Header
          user={user}
          orgs={orgs}
          activeOrgId={activeOrgId}
          signOutAction={signOutAction}
          onMenuToggle={() => setCollapsed((v) => !v)}
          onChatToggle={() => setChatPanelOpen((v) => !v)}
          chatPanelOpen={effectiveChatOpen}
        />
        {/* Below-header row: three columns, each pinned to start just under
            the header. min-h-0 lets children manage their own scrolling. */}
        <div className="flex flex-1 min-h-0">
          <Sidebar
            orgs={orgs}
            activeOrgId={activeOrgId}
            user={user}
            collapsed={collapsed}
            onChatMaximize={() => {
              // From the left nav. Make sure the panel is open + maximized.
              setChatPanelOpen(true);
              setChatMaximized(true);
            }}
          />
          {/* Main content + footer column. Hidden when chat is maximized —
              chat takes the freed-up area. Left nav stays so users can
              still navigate while in maximized chat. */}
          <div className={effectiveChatMaximized ? "hidden" : "flex flex-1 flex-col min-w-0 bg-background"}>
            <main className="flex-1">
              <div className="container max-w-7xl py-6">{children}</div>
            </main>
            {/* AdminLTE-style content footer — copyright + version stamp.
                Kept simple; sits below content (not sticky) so it doesn't
                compete with page-level scroll. */}
            <footer className="border-t bg-card px-6 py-3 text-xs text-muted-foreground">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <strong>Copyright © 2025 OATI AutoRFP.</strong> All rights reserved.
                </div>
                <div>
                  Version <strong>1.0</strong>
                </div>
              </div>
            </footer>
          </div>
          {/* Right chat panel. Sits below the header (top-16) and is pinned
              to the viewport — sticky inside the below-header row so the
              main column can scroll independently. */}
          <ChatSidebar
            organizationId={activeOrg?.id}
            organizationName={activeOrg?.name}
            open={effectiveChatOpen}
            onToggle={() => setChatPanelOpen((v) => !v)}
            maximized={effectiveChatMaximized}
            onMaximizeToggle={() => setChatMaximized((v) => !v)}
          />
        </div>
      </div>
    </ConfirmProvider>
  );
}
