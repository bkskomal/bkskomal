// AdminLTE-style page header — title on the left, breadcrumb trail on the
// right, separated by a faint divider line under it. Used at the top of every
// dashboard page below the global header.
//
// Drop the right-hand `actions` slot when a page wants buttons inline with
// the title (e.g. "New Project" on the Overview page).

import Link from "next/link";
import { ChevronRight, Home } from "lucide-react";
import { cn } from "@/lib/utils";

export interface BreadcrumbItem {
  label: string;
  href?: string;
}

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  breadcrumb?: BreadcrumbItem[];
  actions?: React.ReactNode;
  className?: string;
}

export function PageHeader({
  title,
  subtitle,
  breadcrumb,
  actions,
  className,
}: PageHeaderProps) {
  return (
    <div
      className={cn(
        "border-b pb-4 mb-6 flex flex-wrap items-end justify-between gap-3",
        className,
      )}
    >
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {subtitle ? (
          <p className="mt-0.5 text-sm text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      <div className="flex items-end gap-3">
        {breadcrumb && breadcrumb.length > 0 ? (
          <nav
            aria-label="Breadcrumb"
            className="hidden items-center gap-1 text-xs text-muted-foreground sm:flex"
          >
            <Home className="h-3 w-3" />
            {breadcrumb.map((item, idx) => {
              const isLast = idx === breadcrumb.length - 1;
              return (
                <span key={`${item.label}-${idx}`} className="flex items-center gap-1">
                  <ChevronRight className="h-3 w-3 text-muted-foreground/60" />
                  {item.href && !isLast ? (
                    <Link
                      href={item.href}
                      className="hover:text-foreground hover:underline"
                    >
                      {item.label}
                    </Link>
                  ) : (
                    <span className={isLast ? "text-foreground" : ""}>{item.label}</span>
                  )}
                </span>
              );
            })}
          </nav>
        ) : null}
        {actions}
      </div>
    </div>
  );
}
