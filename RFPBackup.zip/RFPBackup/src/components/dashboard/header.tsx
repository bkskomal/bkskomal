"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useTransition } from "react";
import { Moon, Sun, ChevronDown, Plus, LogOut, Search, Monitor, Menu, Palette, Check, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useTheme } from "@/components/theme-provider";
import { CommandPalette, useCommandPalette } from "@/components/dashboard/command-palette";
import { NotificationsBell } from "@/components/dashboard/notifications-bell";
import { setActiveOrg } from "@/lib/actions/set-active-org";

interface HeaderProps {
  user: { name?: string | null; email?: string | null };
  orgs: { id: string; name: string; slug: string }[];
  activeOrgId?: string;
  signOutAction: () => Promise<void>;
  /** Optional sidebar-toggle callback wired by DashboardShell. */
  onMenuToggle?: () => void;
  /** Right-side chat panel toggle (DashboardShell owns the state). */
  onChatToggle?: () => void;
  /** Current open state of the right-side chat panel — drives the icon. */
  chatPanelOpen?: boolean;
}

export function Header({ user, orgs, activeOrgId, signOutAction, onMenuToggle, onChatToggle, chatPanelOpen }: HeaderProps) {
  const router = useRouter();
  const { theme, setTheme } = useTheme();
  const { open, setOpen } = useCommandPalette();
  const [, startTransition] = useTransition();

  const activeOrg = orgs.find((o) => o.id === activeOrgId) ?? orgs[0];

  const switchOrg = (orgId: string) => {
    startTransition(async () => {
      await setActiveOrg(orgId);
      router.push("/dashboard");
      router.refresh();
    });
  };

  const initials = (user.name ?? user.email ?? "U")
    .split(/\s+/)
    .map((s) => s[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b-2 border-border/80 bg-muted/70 px-4 shadow-[0_4px_12px_-4px_rgba(15,23,42,0.18)] backdrop-blur supports-[backdrop-filter]:bg-muted/60 lg:px-6">
      {/* Brand on the left edge — sidebar no longer carries it. Doubles as
          the home link. */}
      <Link href={`/dashboard?org=${activeOrgId ?? ""}`} className="flex shrink-0 items-center gap-2">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/oati-logo.png" alt="OATI" className="h-8 w-8 rounded-md object-cover" />
        <span className="hidden text-base font-bold tracking-tight md:inline">
          OATI <span className="font-normal text-muted-foreground">AutoRFP</span>
        </span>
      </Link>

      {/* Sidebar collapse toggle — Gentelella-style hamburger on the left. */}
      {onMenuToggle ? (
        <Button
          variant="ghost"
          size="icon"
          onClick={onMenuToggle}
          className="hidden lg:inline-flex"
          aria-label="Toggle sidebar"
        >
          <Menu className="h-5 w-5" />
        </Button>
      ) : null}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="h-9 gap-2 px-3">
            <span className="grid h-5 w-5 place-items-center rounded bg-gradient-to-br from-primary to-fuchsia-500 text-[10px] font-bold text-white">
              {activeOrg?.name.charAt(0)}
            </span>
            <span className="max-w-[160px] truncate text-sm font-medium">
              {activeOrg?.name ?? "No org"}
            </span>
            <ChevronDown className="h-3.5 w-3.5 opacity-60" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-64">
          <DropdownMenuLabel>Organizations</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {orgs.map((org) => (
            <DropdownMenuItem key={org.id} onClick={() => switchOrg(org.id)}>
              <span className="grid h-5 w-5 place-items-center rounded bg-gradient-to-br from-primary to-fuchsia-500 text-[10px] font-bold text-white">
                {org.name.charAt(0)}
              </span>
              <span className="truncate">{org.name}</span>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link href="/orgs/new">
              <Plus className="h-4 w-4" /> New organization
            </Link>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <Button
        variant="outline"
        className="ml-auto h-9 w-64 justify-start gap-2 text-muted-foreground"
        onClick={() => setOpen(true)}
      >
        <Search className="h-4 w-4" />
        <span className="text-sm">Search…</span>
        <kbd className="pointer-events-none ml-auto inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium opacity-100">
          ⌘K
        </kbd>
      </Button>

      <NotificationsBell />

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" aria-label="Theme">
            {theme === "dark" || theme === "solarized-dark" ? (
              <Moon className="h-4 w-4" />
            ) : theme === "light" || theme === "solarized-light" ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Monitor className="h-4 w-4" />
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Standard
          </DropdownMenuLabel>
          <DropdownMenuItem onClick={() => setTheme("light")}>
            <Sun className="h-4 w-4" /> Light
            {theme === "light" ? <Check className="ml-auto h-3.5 w-3.5" /> : null}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("dark")}>
            <Moon className="h-4 w-4" /> Dark
            {theme === "dark" ? <Check className="ml-auto h-3.5 w-3.5" /> : null}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Solarized
          </DropdownMenuLabel>
          <DropdownMenuItem onClick={() => setTheme("solarized-light")}>
            <Palette className="h-4 w-4" /> Solarized Light
            {theme === "solarized-light" ? <Check className="ml-auto h-3.5 w-3.5" /> : null}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setTheme("solarized-dark")}>
            <Palette className="h-4 w-4" /> Solarized Dark
            {theme === "solarized-dark" ? <Check className="ml-auto h-3.5 w-3.5" /> : null}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setTheme("system")}>
            <Monitor className="h-4 w-4" /> System
            {theme === "system" ? <Check className="ml-auto h-3.5 w-3.5" /> : null}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Right-side chat-panel toggle. Mirrors the left-hamburger pattern —
          quick way to minimize/restore the persistent chat sidebar. */}
      {onChatToggle ? (
        <Button
          variant="ghost"
          size="icon"
          onClick={onChatToggle}
          className="hidden lg:inline-flex"
          aria-label={chatPanelOpen ? "Minimize chat panel" : "Open chat panel"}
          title={chatPanelOpen ? "Minimize chat panel" : "Open chat panel"}
        >
          <MessageSquare className={chatPanelOpen ? "h-5 w-5 text-primary" : "h-5 w-5"} />
        </Button>
      ) : null}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-9 px-2">
            <Avatar className="h-7 w-7">
              <AvatarFallback>{initials}</AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-60">
          <DropdownMenuLabel>
            <div className="text-sm font-medium">{user.name ?? "Signed in"}</div>
            <div className="text-xs text-muted-foreground">{user.email}</div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link href={`/dashboard/settings?org=${activeOrgId ?? ""}`}>
              <Monitor className="h-4 w-4" /> Settings
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <form action={signOutAction} className="w-full">
              <button type="submit" className="flex w-full items-center gap-2">
                <LogOut className="h-4 w-4" /> Sign out
              </button>
            </form>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <CommandPalette open={open} onOpenChange={setOpen} orgs={orgs} activeOrgId={activeOrgId} />
    </header>
  );
}
