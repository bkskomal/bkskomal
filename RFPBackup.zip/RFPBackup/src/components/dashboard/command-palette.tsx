"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  FolderKanban,
  Library,
  Star,
  Wrench,
  Users,
  Plus,
  Sparkles,
  Settings as SettingsIcon,
  MessageSquare,
} from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

interface Item {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  action: () => void;
  group: string;
}

export function useCommandPalette() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  return { open, setOpen };
}

interface PaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orgs: { id: string; name: string }[];
  activeOrgId?: string;
}

export function CommandPalette({ open, onOpenChange, orgs, activeOrgId }: PaletteProps) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const orgId = activeOrgId ?? orgs[0]?.id ?? "";

  const items: Item[] = [
    {
      id: "projects",
      label: "Go to Projects",
      icon: FolderKanban,
      group: "Navigation",
      action: () => router.push(`/dashboard/projects?org=${orgId}`),
    },
    {
      id: "chat",
      label: "Open AI Chat",
      icon: MessageSquare,
      group: "Navigation",
      action: () => router.push(`/dashboard/chat?org=${orgId}`),
    },
    {
      id: "indexes",
      label: "Go to Knowledge Base",
      icon: Library,
      group: "Navigation",
      action: () => router.push(`/dashboard/indexes?org=${orgId}`),
    },
    {
      id: "golden",
      label: "Go to Golden Answers",
      icon: Star,
      group: "Navigation",
      action: () => router.push(`/dashboard/golden?org=${orgId}`),
    },
    {
      id: "tools",
      label: "Go to Tools",
      icon: Wrench,
      group: "Navigation",
      action: () => router.push(`/dashboard/tools?org=${orgId}`),
    },
    {
      id: "members",
      label: "Go to Members",
      icon: Users,
      group: "Navigation",
      action: () => router.push(`/dashboard/members?org=${orgId}`),
    },
    {
      id: "settings",
      label: "Open Settings",
      icon: SettingsIcon,
      group: "Navigation",
      action: () => router.push(`/dashboard/settings?org=${orgId}`),
    },
    {
      id: "new-project",
      label: "Create New Project",
      icon: Plus,
      group: "Actions",
      action: () => router.push(`/dashboard/projects?org=${orgId}&new=1`),
    },
    {
      id: "new-org",
      label: "Create New Organization",
      icon: Sparkles,
      group: "Actions",
      action: () => router.push("/orgs/new"),
    },
  ];

  const filtered = query
    ? items.filter((i) => i.label.toLowerCase().includes(query.toLowerCase()))
    : items;

  const grouped = filtered.reduce<Record<string, Item[]>>((acc, i) => {
    acc[i.group] = acc[i.group] ?? [];
    acc[i.group].push(i);
    return acc;
  }, {});

  const run = (item: Item) => {
    item.action();
    onOpenChange(false);
    setQuery("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl gap-0 p-0">
        <div className="border-b px-4 py-3">
          <Input
            autoFocus
            placeholder="Search commands…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="h-10 border-0 bg-transparent shadow-none focus-visible:ring-0"
            onKeyDown={(e) => {
              if (e.key === "Enter" && filtered[0]) run(filtered[0]);
            }}
          />
        </div>
        <div className="scrollbar-thin max-h-[400px] overflow-y-auto p-2">
          {Object.entries(grouped).map(([group, items]) => (
            <div key={group} className="mb-2">
              <div className="px-2 py-1 text-xs font-medium text-muted-foreground">{group}</div>
              {items.map((i) => (
                <button
                  key={i.id}
                  onClick={() => run(i)}
                  className="flex w-full items-center gap-3 rounded-md px-2 py-2 text-sm hover:bg-accent"
                >
                  <i.icon className="h-4 w-4 text-muted-foreground" />
                  {i.label}
                </button>
              ))}
            </div>
          ))}
          {filtered.length === 0 ? (
            <div className="px-3 py-6 text-center text-sm text-muted-foreground">
              No results.
            </div>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
}
