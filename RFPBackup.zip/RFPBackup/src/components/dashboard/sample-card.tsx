"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Sparkles, Loader2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "@/components/ui/use-toast";

export function SampleCard({ orgId }: { orgId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch(`/api/orgs/${orgId}/sample`, { method: "POST" });
    setLoading(false);
    if (!res.ok) {
      toast({ title: "Couldn't load sample", description: (await res.json()).error });
      return;
    }
    const { rfpId } = await res.json();
    toast({ title: "Sample loaded", variant: "success" });
    router.push(`/dashboard/rfps/${rfpId}?org=${orgId}`);
  }

  return (
    <Card className="overflow-hidden">
      <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/5 via-transparent to-fuchsia-500/5" />
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" /> See it in action
        </CardTitle>
        <CardDescription>
          Load a fully populated sample RFP and a small knowledge base. Try the bulk generate, chat,
          and export flows in seconds.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Button variant="gradient" onClick={load} disabled={loading}>
          {loading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="h-4 w-4" />
          )}
          Load sample RFP
        </Button>
      </CardContent>
    </Card>
  );
}
