"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Bell, BellRing, Check, CheckCheck, Loader2 } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "@/components/ui/use-toast";
import { cn, formatDateTime } from "@/lib/utils";
import { NotificationKind } from "@prisma/client";

interface NotificationItem {
  id: string;
  kind: NotificationKind;
  read: boolean;
  payload: any;
  rfpId: string | null;
  questionId: string | null;
  organizationId: string | null;
  createdAt: string;
  actor: { id: string; name: string | null; email: string } | null;
}

const ICONS: Record<NotificationKind, string> = {
  QUESTION_ASSIGNED: "📌",
  COMMENT_ON_YOUR_QUESTION: "💬",
  COMMENT_MENTION: "@",
  RFP_COMPLETED: "🎉",
  RFP_DEADLINE_APPROACHING: "⏰",
  BULK_GENERATION_COMPLETED: "⚡",
};

const POLL_INTERVAL_MS = 30_000;

export function NotificationsBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await fetch("/api/notifications");
      if (!res.ok) return;
      const data = await res.json();
      setItems(data.items ?? []);
      setUnreadCount(data.unreadCount ?? 0);
    } catch (err) {
      // Network-level error — server momentarily unreachable, e.g. during
      // a dev/prod server swap, a brief socket reset, or sleep/wake. We
      // poll every 60s anyway, so swallow it instead of surfacing an
      // unhandled "Failed to fetch" in the React dev overlay. Logged at
      // debug so it's visible if you're chasing connectivity issues.
      if (process.env.NODE_ENV !== "production") {
        // eslint-disable-next-line no-console
        console.debug("[notifications] poll failed", err);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const t = setInterval(load, POLL_INTERVAL_MS);
    return () => clearInterval(t);
  }, []);

  // Refresh when the dropdown opens so the user sees the latest immediately.
  useEffect(() => {
    if (open) load();
  }, [open]);

  async function markRead(id: string) {
    await fetch(`/api/notifications/${id}/read`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ read: true }),
    });
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    setUnreadCount((c) => Math.max(0, c - 1));
  }

  async function markAllRead() {
    const res = await fetch("/api/notifications/mark-all-read", { method: "POST" });
    if (res.ok) {
      setItems((prev) => prev.map((n) => ({ ...n, read: true })));
      setUnreadCount(0);
      toast({ title: "All marked as read" });
    }
  }

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label="Notifications">
          {unreadCount > 0 ? <BellRing className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
          {unreadCount > 0 ? (
            <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          ) : null}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[380px] p-0">
        <div className="flex items-center justify-between border-b px-3 py-2">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold">Notifications</span>
            {unreadCount > 0 ? (
              <Badge variant="default" className="text-[10px]">{unreadCount} new</Badge>
            ) : null}
          </div>
          <div className="flex items-center gap-1">
            {unreadCount > 0 ? (
              <Button size="sm" variant="ghost" onClick={markAllRead} className="h-7 px-2 text-xs">
                <CheckCheck className="h-3.5 w-3.5" /> Mark all read
              </Button>
            ) : null}
          </div>
        </div>

        <div className="scrollbar-thin max-h-[420px] overflow-y-auto">
          {loading && items.length === 0 ? (
            <div className="grid place-items-center py-12">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          ) : items.length === 0 ? (
            <div className="grid place-items-center py-12 text-center text-xs text-muted-foreground">
              <Bell className="mb-2 h-6 w-6 opacity-50" />
              You're all caught up.
            </div>
          ) : (
            <ul>
              {items.map((n) => (
                <NotificationRow
                  key={n.id}
                  item={n}
                  onClick={() => {
                    setOpen(false);
                    if (!n.read) markRead(n.id);
                  }}
                  onMarkRead={() => markRead(n.id)}
                />
              ))}
            </ul>
          )}
        </div>

        <div className="border-t px-3 py-2 text-right">
          <Link
            href="/dashboard/settings#notifications"
            className="text-[11px] text-muted-foreground hover:text-foreground"
            onClick={() => setOpen(false)}
          >
            Notification preferences →
          </Link>
        </div>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function NotificationRow({
  item,
  onClick,
  onMarkRead,
}: {
  item: NotificationItem;
  onClick: () => void;
  onMarkRead: () => void;
}) {
  const href = item.rfpId
    ? `/dashboard/rfps/${item.rfpId}`
    : item.organizationId
      ? `/dashboard?org=${item.organizationId}`
      : "/dashboard";
  const summary = summarize(item);
  const initials = (item.actor?.name ?? item.actor?.email ?? "·").slice(0, 2).toUpperCase();

  return (
    <li className={cn("group border-b last:border-b-0", !item.read && "bg-primary/5")}>
      <Link
        href={href}
        onClick={onClick}
        className="flex items-start gap-3 px-3 py-2.5 hover:bg-accent/40 transition-colors"
      >
        <div className="grid h-7 w-7 shrink-0 place-items-center rounded-full border bg-card text-xs">
          {item.actor ? (
            <Avatar className="h-7 w-7">
              <AvatarFallback className="text-[10px]">{initials}</AvatarFallback>
            </Avatar>
          ) : (
            <span>{ICONS[item.kind] ?? "•"}</span>
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="line-clamp-2 text-sm">{summary}</p>
          <p className="mt-0.5 text-[11px] text-muted-foreground">{formatDateTime(item.createdAt)}</p>
        </div>
        {!item.read ? (
          <button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onMarkRead();
            }}
            className="opacity-0 transition-opacity group-hover:opacity-100"
            title="Mark as read"
          >
            <Check className="h-3.5 w-3.5 text-muted-foreground hover:text-foreground" />
          </button>
        ) : null}
      </Link>
    </li>
  );
}

function summarize(n: NotificationItem): string {
  const d = n.payload ?? {};
  switch (n.kind) {
    case "QUESTION_ASSIGNED":
      return `${d.actorName ?? "Someone"} assigned you Q${d.questionNumber} on "${d.rfpTitle}"`;
    case "COMMENT_ON_YOUR_QUESTION":
      return `${d.actorName ?? "Someone"} commented on Q${d.questionNumber} of "${d.rfpTitle}"`;
    case "COMMENT_MENTION":
      return `${d.actorName ?? "Someone"} mentioned you in Q${d.questionNumber}`;
    case "RFP_COMPLETED":
      return `"${d.rfpTitle}" is complete (${d.approvedQuestions}/${d.totalQuestions} approved)`;
    case "RFP_DEADLINE_APPROACHING":
      return `"${d.rfpTitle}" is due in ${d.hoursUntilDue}h — ${d.unansweredCount} unanswered`;
    case "BULK_GENERATION_COMPLETED":
      return `Bulk generation done · ${d.completed}/${d.total} for "${d.rfpTitle}"`;
    default:
      return "Notification";
  }
}
