"use client";

// Right-side persistent chat panel. Like the left nav but mirrored — sits on
// every dashboard page, defaults open at ~400px, collapses to a 48px strip
// the user can re-expand with one click. State is persisted in localStorage
// (open + last-used threadId) so navigating between pages doesn't reset it.
//
// The panel scopes chat to the user's active organization (ORG scope). The
// existing full-screen /dashboard/chat page still works for multi-thread
// management; this sidebar is the always-available "ask the assistant"
// surface a la GitHub Copilot Chat / Cursor / Linear.

import { useCallback, useEffect, useState } from "react";
import { ChevronsRight, ChevronsLeft, Plus, MessageSquare, Sparkles, Maximize2, Minimize2, History, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn, formatDateTime } from "@/lib/utils";
import { ChatPanel } from "@/components/chat/chat-panel";

interface ThreadRow {
  id: string;
  title: string;
  messageCount: number;
  updatedAt: string;
}

interface Props {
  /** Active org id — chat is scoped here by default. */
  organizationId?: string;
  /** Org name shown in the panel header. */
  organizationName?: string;
  /** Effective open/collapsed state (DashboardShell resolves user pref + viewport). */
  open: boolean;
  /** Toggle callback (shell owns the state). */
  onToggle: () => void;
  /** Effective maximized state. */
  maximized: boolean;
  /** Toggle maximized state (shell owns it). */
  onMaximizeToggle: () => void;
}

const THREAD_KEY = "autorfp.chatpanel.threadId";
const WIDTH_KEY = "autorfp.chatpanel.width";
const MIN_WIDTH = 280;
const MAX_WIDTH = 800;
const DEFAULT_WIDTH = 400;

export function ChatSidebar({ organizationId, organizationName, open, onToggle, maximized, onMaximizeToggle }: Props) {
  // Per-org "last used thread" persistence. When the user comes back to this
  // org in a future session, we resume the same chat. New Chat clears it.
  const storageKey = organizationId ? `${THREAD_KEY}.${organizationId}` : null;
  const [threadId, setThreadId] = useState<string | undefined>(undefined);
  const [hydrated, setHydrated] = useState(false);
  // History view: when normal-mode, toggled via a button in the header.
  // When maximized, history is ALWAYS shown as a left column. The state
  // here only matters when not maximized.
  const [historyOpen, setHistoryOpen] = useState(false);
  const [threads, setThreads] = useState<ThreadRow[] | null>(null);
  const [loadingThreads, setLoadingThreads] = useState(false);
  // Drag-resize state for the normal (non-maximized) panel width. Persisted
  // in localStorage; clamped to [MIN_WIDTH, MAX_WIDTH].
  const [width, setWidth] = useState<number>(DEFAULT_WIDTH);
  const [resizing, setResizing] = useState(false);

  useEffect(() => {
    setHydrated(true);
    try {
      const storedW = window.localStorage.getItem(WIDTH_KEY);
      if (storedW) {
        const parsed = parseInt(storedW, 10);
        if (Number.isFinite(parsed)) {
          setWidth(Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, parsed)));
        }
      }
    } catch {
      // ignore
    }
    if (!storageKey) return;
    try {
      const stored = window.localStorage.getItem(storageKey);
      if (stored) setThreadId(stored);
    } catch {
      // ignore
    }
  }, [storageKey]);

  // Persist width changes after drag ends.
  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(WIDTH_KEY, String(width));
    } catch {
      // ignore
    }
  }, [width, hydrated]);

  // Drag handlers — attached to window only while a drag is active so we
  // don't burn cycles on every mousemove.
  useEffect(() => {
    if (!resizing) return;
    function onMove(e: MouseEvent) {
      // Panel is on the RIGHT, so dragging the handle LEFT widens the panel.
      // width = viewport.right - mouse.x
      const next = Math.max(MIN_WIDTH, Math.min(MAX_WIDTH, window.innerWidth - e.clientX));
      setWidth(next);
    }
    function onUp() {
      setResizing(false);
    }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
  }, [resizing]);

  useEffect(() => {
    if (!hydrated || !storageKey) return;
    try {
      if (threadId) window.localStorage.setItem(storageKey, threadId);
      else window.localStorage.removeItem(storageKey);
    } catch {
      // ignore
    }
  }, [threadId, hydrated, storageKey]);

  // Fetch threads whenever the panel is showing history (either maximized
  // or history toggle on). Re-fetches on org change so the list never
  // shows stale rows from a different tenant.
  const loadThreads = useCallback(async () => {
    if (!organizationId) return;
    setLoadingThreads(true);
    try {
      // The /api/chat/threads route already filters to active org via session.
      const res = await fetch(`/api/chat/threads?org=${organizationId}`);
      if (!res.ok) {
        setThreads([]);
        return;
      }
      const body = await res.json();
      const rows: ThreadRow[] = Array.isArray(body.threads)
        ? body.threads.map((t: { id: string; title?: string; _count?: { messages: number }; messageCount?: number; updatedAt: string }) => ({
            id: t.id,
            title: t.title || "New chat",
            messageCount: t._count?.messages ?? t.messageCount ?? 0,
            updatedAt: t.updatedAt,
          }))
        : [];
      setThreads(rows);
    } finally {
      setLoadingThreads(false);
    }
  }, [organizationId]);

  useEffect(() => {
    if (maximized || historyOpen) void loadThreads();
  }, [maximized, historyOpen, loadThreads]);

  function newChat() {
    setThreadId(undefined);
    setHistoryOpen(false);
  }

  function pickThread(id: string) {
    setThreadId(id);
    setHistoryOpen(false);
  }

  // --- Collapsed strip --------------------------------------------------------
  if (!open) {
    return (
      <aside
        // sticky top-16 + h-[calc(100vh-4rem)] = pinned below the main
        // header. self-start prevents the flex row from stretching it.
        className="sticky top-16 flex shrink-0 flex-col items-center gap-2 self-start border-l bg-card px-1 py-3"
        style={{ width: 48, height: "calc(100vh - 4rem)" }}
        aria-label="Chat panel (collapsed)"
      >
        <button
          onClick={onToggle}
          className="grid h-8 w-8 place-items-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground"
          title="Open chat panel"
          aria-label="Open chat panel"
        >
          <ChevronsLeft className="h-4 w-4" />
        </button>
        <button
          onClick={onToggle}
          className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-primary to-fuchsia-500 text-white shadow-sm hover:opacity-90"
          title="Open chat panel"
          aria-label="Open chat panel"
        >
          <Sparkles className="h-4 w-4" />
        </button>
        <div className="mt-1 text-[8px] uppercase tracking-wider text-muted-foreground" style={{ writingMode: "vertical-rl" }}>
          Chat
        </div>
      </aside>
    );
  }

  // --- Expanded panel ---------------------------------------------------------
  // History is always visible (as a left column inside this panel) when the
  // chat is MAXIMIZED. In normal mode the user toggles it via the header
  // History button.
  const showHistoryColumn = maximized;
  const showHistoryView = !maximized && historyOpen;

  return (
    <aside
      // sticky top-16 keeps panel pinned below the main header. When NOT
      // maximized: user-resizable width (drag the handle on the left edge).
      // When MAXIMIZED: flex-1 to swallow the freed-up space.
      className={cn(
        "sticky top-16 flex shrink-0 flex-col self-start border-l bg-card",
        maximized && "flex-1 shrink",
        // While dragging, suppress transition / pointer artifacts.
        resizing && "select-none",
      )}
      style={maximized ? { height: "calc(100vh - 4rem)" } : { width, height: "calc(100vh - 4rem)" }}
      aria-label="Chat panel"
    >
      {/* Drag handle — 4px-wide hot zone on the LEFT edge of the panel. Only
          interactive when NOT maximized. Visual cue: subtle hairline that
          turns primary-colored on hover/active. */}
      {!maximized ? (
        <div
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize chat panel"
          onMouseDown={(e) => {
            e.preventDefault();
            setResizing(true);
          }}
          onDoubleClick={() => setWidth(DEFAULT_WIDTH)}
          title="Drag to resize · double-click to reset"
          className={cn(
            "absolute left-0 top-0 z-10 h-full w-1.5 cursor-col-resize bg-transparent transition-colors",
            "hover:bg-primary/40",
            resizing && "bg-primary",
          )}
          style={{ marginLeft: -3 }}
        />
      ) : null}
      {/* Header row — matches main header height (h-16 is set on the main
          header; we use h-12 here since the brand+org is already on the
          main header bar above). */}
      <div className="flex h-12 shrink-0 items-center justify-between gap-2 border-b px-3">
        <div className="flex min-w-0 items-center gap-2">
          <MessageSquare className="h-3.5 w-3.5 shrink-0 text-primary" />
          <span className="truncate text-xs font-semibold">Assistant</span>
          {organizationName ? (
            <span className="truncate text-[10px] text-muted-foreground" title={organizationName}>
              · {organizationName}
            </span>
          ) : null}
        </div>
        <div className="flex shrink-0 items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            onClick={newChat}
            className="h-7 px-2 text-xs"
            title="Start a new conversation"
            disabled={!organizationId}
          >
            <Plus className="h-3 w-3" /> New
          </Button>
          {/* History toggle — only shown in normal mode; when maximized the
              history column is always rendered to the left. */}
          {!maximized ? (
            <button
              onClick={() => setHistoryOpen((v) => !v)}
              className={cn(
                "grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground",
                historyOpen && "bg-accent text-foreground",
              )}
              title="Conversation history"
              aria-label="Conversation history"
            >
              <History className="h-4 w-4" />
            </button>
          ) : null}
          <button
            onClick={onMaximizeToggle}
            className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground"
            title={maximized ? "Restore to normal size" : "Maximize chat (hide main content)"}
            aria-label={maximized ? "Restore to normal size" : "Maximize chat"}
          >
            {maximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </button>
          <button
            onClick={onToggle}
            className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-accent hover:text-foreground"
            title="Minimize chat panel"
            aria-label="Minimize chat panel"
          >
            <ChevronsRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="flex min-h-0 flex-1">
        {/* History column — always visible when maximized. Sits to the left
            of the chat. Clicking a thread loads it into the ChatPanel. */}
        {showHistoryColumn ? (
          <div className="flex w-72 shrink-0 flex-col border-r bg-muted/20">
            <div className="border-b px-3 py-2 text-[10px] uppercase tracking-wider text-muted-foreground">
              Conversations
            </div>
            <HistoryList
              threads={threads}
              loading={loadingThreads}
              activeId={threadId}
              onPick={pickThread}
              onRefresh={loadThreads}
            />
          </div>
        ) : null}

        {/* Body: either the history list (normal mode + toggle) or the chat. */}
        {showHistoryView ? (
          <div className="flex min-h-0 flex-1 flex-col">
            <div className="flex items-center gap-1 border-b px-2 py-1.5">
              <button
                onClick={() => setHistoryOpen(false)}
                className="grid h-6 w-6 place-items-center rounded text-muted-foreground hover:bg-accent hover:text-foreground"
                title="Back to chat"
                aria-label="Back to chat"
              >
                <ArrowLeft className="h-3.5 w-3.5" />
              </button>
              <span className="text-[11px] font-medium text-muted-foreground">
                Conversations
              </span>
            </div>
            <HistoryList
              threads={threads}
              loading={loadingThreads}
              activeId={threadId}
              onPick={pickThread}
              onRefresh={loadThreads}
            />
          </div>
        ) : (
          <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
            {organizationId ? (
              <ChatPanel
                key={`${organizationId}:${threadId ?? "new"}`}
                organizationId={organizationId}
                scope="ORG"
                scopeLabel="Organization"
                threadId={threadId}
                suggestions={[
                  "Summarize what's in our knowledge base",
                  "What RFPs are open?",
                  "Help me draft a security posture answer",
                  "What's the deadline on our most recent RFP?",
                ]}
                className="h-full rounded-none border-0"
              />
            ) : (
              <div className="grid h-full place-items-center px-4 text-center text-xs text-muted-foreground">
                Pick an organization to start chatting.
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}

// --- HistoryList -----------------------------------------------------------

function HistoryList({
  threads,
  loading,
  activeId,
  onPick,
  onRefresh,
}: {
  threads: ThreadRow[] | null;
  loading: boolean;
  activeId: string | undefined;
  onPick: (id: string) => void;
  onRefresh: () => void;
}) {
  if (loading && !threads) {
    return (
      <div className="grid place-items-center py-8 text-[11px] text-muted-foreground">Loading…</div>
    );
  }
  if (!threads || threads.length === 0) {
    return (
      <div className="space-y-2 px-3 py-6 text-center text-[11px] text-muted-foreground">
        <div>No past conversations yet.</div>
        <button onClick={onRefresh} className="text-primary hover:underline">Refresh</button>
      </div>
    );
  }
  return (
    <ul className="scrollbar-thin flex-1 overflow-y-auto p-2">
      {threads.map((t) => (
        <li key={t.id}>
          <button
            onClick={() => onPick(t.id)}
            className={cn(
              "group flex w-full flex-col items-start gap-0.5 rounded-md p-2 text-left text-xs transition-colors hover:bg-accent",
              activeId === t.id && "bg-accent",
            )}
            title={t.title}
          >
            <span className="line-clamp-1 text-sm font-medium">{t.title}</span>
            <span className="text-[10px] text-muted-foreground">
              {t.messageCount} msg · {formatDateTime(t.updatedAt)}
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}
