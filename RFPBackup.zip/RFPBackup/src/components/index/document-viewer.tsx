"use client";

import { useEffect, useState } from "react";
import {
  FileText,
  Download,
  Loader2,
  Hash,
  AlertCircle,
  Sparkles,
  RefreshCw,
  Globe,
  ExternalLink,
  Image as ImageIcon,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Markdown } from "@/components/markdown";
import { formatBytes, formatDateTime } from "@/lib/utils";
import { ImagesTab } from "@/components/index/images-tab";

interface Chunk {
  id: string;
  ordinal: number;
  content: string;
  page: number | null;
}

interface DocumentDetail {
  id: string;
  name: string;
  fileName: string;
  fileSize: number;
  mimeType: string;
  status: string;
  errorMessage: string | null;
  createdAt: string;
  updatedAt: string;
  index: { id: string; name: string };
  isSynthetic: boolean;
  chunkCount: number;
  totalChars: number;
  sourceUrl?: string | null;
}

const STATUS_VARIANT: Record<string, "default" | "info" | "success" | "warning" | "destructive"> = {
  PENDING: "info",
  PROCESSING: "warning",
  INDEXED: "success",
  FAILED: "destructive",
};

// The chunker always emits Markdown-flavoured text (headings, bold, lists,
// code fences, links — produced by astToMarkdown). So for every text-shaped
// document we want the viewer to render through the Markdown component, not
// dump the raw source. Includes scraped HTML (text/html) plus the obvious
// markdown / plain text formats. Binary parsers (PDF/DOCX/XLSX/PPTX) also
// go through the same chunker so they render correctly here too — render
// only fails-safe to <pre> when mimeType is genuinely unknown.
const MARKDOWN_MIMES = new Set([
  "text/markdown",
  "text/plain",
  "text/html",
  "application/xhtml+xml",
  "application/pdf",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
]);

export function DocumentViewer({
  documentId,
  open,
  onOpenChange,
}: {
  documentId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [doc, setDoc] = useState<DocumentDetail | null>(null);
  const [chunks, setChunks] = useState<Chunk[]>([]);
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState<"combined" | "chunks">("combined");
  // The viewer used to render only text. Phase IM adds the Images tab — a
  // top-level switcher between the chunk-content view and the gallery of
  // CLIP-extracted figures. We default to "text" so existing flows are
  // unchanged; the tab strip only surfaces when a doc has images.
  const [tab, setTab] = useState<"text" | "images">("text");
  const [imageCount, setImageCount] = useState<number | null>(null);

  // Lightweight count probe so the tab strip can render the badge without
  // mounting ImagesTab (which fetches the full image list). Skipped when
  // the dialog isn't open or no doc id is set.
  useEffect(() => {
    if (!open || !documentId) return;
    let cancel = false;
    setImageCount(null);
    fetch(`/api/documents/${documentId}/images`)
      .then((r) => r.json())
      .then((d) => {
        if (cancel) return;
        if (typeof d.count === "number") setImageCount(d.count);
      })
      .catch(() => {
        // Silent — the gallery surface will surface its own error if the
        // user actually opens the tab.
      });
    return () => {
      cancel = true;
    };
  }, [open, documentId]);

  useEffect(() => {
    if (!open || !documentId) return;
    let cancel = false;
    setLoading(true);
    setDoc(null);
    setChunks([]);
    fetch(`/api/documents/${documentId}`)
      .then((r) => r.json())
      .then((d) => {
        if (cancel) return;
        setDoc(d.document);
        setChunks(d.chunks ?? []);
      })
      .finally(() => !cancel && setLoading(false));
    return () => {
      cancel = true;
    };
  }, [open, documentId]);

  const combined = chunks.map((c) => c.content).join("\n\n---\n\n");
  const isMarkdown = doc ? MARKDOWN_MIMES.has(doc.mimeType) : false;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] grid grid-rows-[auto_auto_1fr_auto] gap-0 p-0">
        <DialogHeader className="border-b px-6 py-4">
          <DialogTitle className="flex items-center gap-2 text-base">
            {doc?.sourceUrl ? (
              <Globe className="h-4 w-4 text-primary" />
            ) : (
              <FileText className="h-4 w-4 text-primary" />
            )}
            {doc?.name ?? "Loading…"}
          </DialogTitle>
          {doc?.sourceUrl ? (
            <div className="-mt-1 text-xs">
              <a
                href={doc.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-primary hover:underline"
              >
                {doc.sourceUrl}
                <ExternalLink className="h-3 w-3" />
              </a>
            </div>
          ) : null}
          {doc ? (
            // asChild lets DialogDescription forward its a11y attributes to
            // the underlying div instead of rendering a <p>. We need a div
            // here because we mix block-level Badge components inline; a <p>
            // wrapping a <div> is invalid HTML and triggers a hydration mismatch.
            <DialogDescription asChild>
              <div className="text-muted-foreground flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                <Badge variant={STATUS_VARIANT[doc.status] ?? "outline"} className="text-[10px]">
                  {doc.status}
                </Badge>
                <span>{doc.fileName}</span>
                <span>·</span>
                <span>{formatBytes(doc.fileSize)}</span>
                <span>·</span>
                <span className="inline-flex items-center gap-1">
                  <Hash className="h-3 w-3" /> {doc.chunkCount} chunk{doc.chunkCount === 1 ? "" : "s"}
                </span>
                <span>·</span>
                <span>{doc.totalChars.toLocaleString()} chars</span>
                <span>·</span>
                <span>{doc.index.name}</span>
                <span>·</span>
                <span>{formatDateTime(doc.updatedAt)}</span>
                {doc.isSynthetic ? (
                  <Badge variant="outline" className="text-[10px]">
                    <Sparkles className="h-2.5 w-2.5" /> seeded
                  </Badge>
                ) : null}
              </div>
            </DialogDescription>
          ) : null}
        </DialogHeader>

        {doc?.errorMessage ? (
          <div className="flex items-start gap-2 border-b bg-destructive/5 px-6 py-3 text-xs">
            <AlertCircle className="h-3.5 w-3.5 mt-0.5 shrink-0 text-destructive" />
            <div>
              <div className="font-medium text-destructive">Embedding error</div>
              <div className="text-muted-foreground">{doc.errorMessage}</div>
            </div>
          </div>
        ) : null}

        {doc && (chunks.length > 1 || (imageCount ?? 0) > 0) ? (
          <div className="border-b px-6 py-2 flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground">Tab:</span>
            <Button
              size="sm"
              variant={tab === "text" ? "default" : "outline"}
              onClick={() => setTab("text")}
              className="h-6 px-2 text-xs"
            >
              Text
            </Button>
            <Button
              size="sm"
              variant={tab === "images" ? "default" : "outline"}
              onClick={() => setTab("images")}
              className="h-6 px-2 text-xs"
              disabled={(imageCount ?? 0) === 0}
              data-testid="document-images-tab-trigger"
            >
              <ImageIcon className="h-3 w-3" /> Images
              {imageCount != null ? (
                <Badge variant="outline" className="ml-1 text-[10px]">
                  {imageCount}
                </Badge>
              ) : null}
            </Button>
            {tab === "text" && chunks.length > 1 ? (
              <>
                <span className="ml-3 text-xs text-muted-foreground">View:</span>
                <Button
                  size="sm"
                  variant={view === "combined" ? "default" : "outline"}
                  onClick={() => setView("combined")}
                  className="h-6 px-2 text-xs"
                >
                  Combined
                </Button>
                <Button
                  size="sm"
                  variant={view === "chunks" ? "default" : "outline"}
                  onClick={() => setView("chunks")}
                  className="h-6 px-2 text-xs"
                >
                  By chunk
                </Button>
              </>
            ) : null}
          </div>
        ) : null}

        <div className="scrollbar-thin overflow-y-auto px-6 py-4">
          {tab === "images" && doc ? (
            <ImagesTab documentId={doc.id} indexId={doc.index.id} />
          ) : loading ? (
            <div className="grid place-items-center py-16">
              <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
            </div>
          ) : chunks.length === 0 ? (
            <div className="grid place-items-center py-16 text-center text-sm text-muted-foreground">
              <RefreshCw className="mb-2 h-6 w-6 opacity-50" />
              No content available.
              {doc?.status === "FAILED" || doc?.status === "PENDING"
                ? " Try the Re-index button."
                : null}
            </div>
          ) : view === "combined" || chunks.length === 1 ? (
            isMarkdown ? (
              <Markdown>{combined}</Markdown>
            ) : (
              <pre className="whitespace-pre-wrap break-words font-sans text-sm leading-relaxed text-foreground">
                {combined}
              </pre>
            )
          ) : (
            <div className="space-y-4">
              {chunks.map((c) => (
                <div key={c.id} className="rounded-lg border bg-card p-3">
                  <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
                    <span className="font-mono">
                      chunk #{c.ordinal + 1}
                      {c.page ? ` · page ${c.page}` : ""}
                    </span>
                    <span>{c.content.length.toLocaleString()} chars</span>
                  </div>
                  {isMarkdown ? (
                    <Markdown>{c.content}</Markdown>
                  ) : (
                    <pre className="whitespace-pre-wrap break-words font-sans text-sm leading-relaxed">
                      {c.content}
                    </pre>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <DialogFooter className="border-t px-6 py-3">
          {doc && !doc.isSynthetic ? (
            <Button asChild variant="outline" size="sm">
              <a href={`/api/documents/${doc.id}/download`} download>
                <Download className="h-3.5 w-3.5" /> Download original
              </a>
            </Button>
          ) : null}
          <Button size="sm" variant="ghost" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
