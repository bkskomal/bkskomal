"use client";

// Images tab inside the KB document viewer.
//
// Two surfaces wired into this component:
//   1) The thumbnail grid for the current document — fed by GET
//      /api/documents/:id/images. Renders 4 cols on lg+, 2 on smaller
//      screens, with caption + page badge + OCR snippet on hover.
//   2) A KB-wide image search box (text query → CLIP retrieval) above the
//      grid. Hits replace the per-document grid until the user clears the
//      search; clearing brings the document's own images back.
//
// Selecting a thumbnail opens a modal that surfaces full-size image, full
// OCR text, caption, and a "Find similar" button that POSTs to
// /api/indexes/:id/images/similar and replaces the modal contents with the
// resulting hits inline.
//
// We intentionally use a plain <img> instead of next/image: image bytes are
// served by our own /api/images route (org-gated) and we don't want next to
// proxy them through its own loader / cache.

import { useCallback, useEffect, useState } from "react";
import { Loader2, Image as ImageIcon, Search, Sparkles, X, ExternalLink } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "@/components/ui/use-toast";

interface ImageRow {
  id: string;
  imagePath: string;
  mimeType: string;
  caption: string | null;
  ocrText: string | null;
  page: number | null;
  width: number | null;
  height: number | null;
  chunkId: string | null;
}

interface SearchHit extends ImageRow {
  score?: number;
}

export function ImagesTab({
  documentId,
  indexId,
}: {
  documentId: string;
  /**
   * The index this document belongs to. Required to drive the KB-wide
   * search box (it POSTs to /api/indexes/:id/images/search). Optional in
   * the type so the component can degrade gracefully if a caller hasn't
   * piped the indexId through yet — we just hide the search box.
   */
  indexId?: string | null;
}) {
  const [images, setImages] = useState<ImageRow[] | null>(null);
  const [loading, setLoading] = useState(false);

  // Search state. `searchHits` is null when no search is active; an empty
  // array means "search ran but returned nothing" (renders the empty
  // search-state UI instead of falling back to the document grid).
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [searchHits, setSearchHits] = useState<SearchHit[] | null>(null);

  const [openImage, setOpenImage] = useState<ImageRow | SearchHit | null>(null);

  const loadDocImages = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/documents/${documentId}/images`);
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Couldn't load images", description: err.error });
        setImages([]);
        return;
      }
      const body = await res.json();
      setImages(body.images ?? []);
    } finally {
      setLoading(false);
    }
  }, [documentId]);

  useEffect(() => {
    void loadDocImages();
  }, [loadDocImages]);

  async function runSearch() {
    if (!indexId || !query.trim()) return;
    setSearching(true);
    try {
      const res = await fetch(`/api/indexes/${indexId}/images/search`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ query: query.trim(), topK: 12 }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Image search failed", description: err.error });
        return;
      }
      const body = await res.json();
      setSearchHits(body.hits ?? []);
    } finally {
      setSearching(false);
    }
  }

  function clearSearch() {
    setQuery("");
    setSearchHits(null);
  }

  const grid = searchHits ?? images ?? [];
  const showingSearch = searchHits !== null;

  return (
    <div className="space-y-4">
      {indexId ? (
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") runSearch();
              }}
              placeholder="Search images by description (e.g. 'architecture diagram for HA failover')"
              className="pl-7 text-xs"
            />
          </div>
          <Button size="sm" onClick={runSearch} disabled={searching || !query.trim()}>
            {searching ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <Search className="h-3.5 w-3.5" />
            )}
            Search
          </Button>
          {showingSearch ? (
            <Button size="sm" variant="ghost" onClick={clearSearch}>
              <X className="h-3.5 w-3.5" /> Clear
            </Button>
          ) : null}
        </div>
      ) : null}

      {loading && !showingSearch ? (
        <div className="grid place-items-center py-16">
          <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
        </div>
      ) : grid.length === 0 ? (
        <div className="grid place-items-center rounded-lg border-2 border-dashed py-12 text-center text-sm text-muted-foreground">
          <ImageIcon className="mb-2 h-6 w-6 opacity-50" />
          {showingSearch
            ? "No images matched that description."
            : "No images extracted from this document"}
        </div>
      ) : (
        <div
          data-testid="image-gallery-grid"
          className="grid grid-cols-2 gap-3 lg:grid-cols-4"
        >
          {grid.map((img) => (
            <ImageThumbnail
              key={img.id}
              image={img}
              showScore={showingSearch}
              onClick={() => setOpenImage(img)}
            />
          ))}
        </div>
      )}

      {openImage ? (
        <ImageModal
          image={openImage}
          indexId={indexId ?? null}
          open={!!openImage}
          onOpenChange={(open) => !open && setOpenImage(null)}
        />
      ) : null}
    </div>
  );
}

function ImageThumbnail({
  image,
  showScore,
  onClick,
}: {
  image: ImageRow | SearchHit;
  showScore: boolean;
  onClick: () => void;
}) {
  const url = imageUrlFor(image.imagePath);
  const [loadError, setLoadError] = useState(false);
  return (
    <button
      onClick={onClick}
      className="group relative block overflow-hidden rounded-lg border bg-muted/30 text-left transition-colors hover:border-primary"
      title={loadError ? image.imagePath : (image.ocrText ?? image.caption ?? "")}
    >
      <div className="aspect-square w-full overflow-hidden bg-muted">
        {loadError ? (
          // Image bytes are gone (file missing on disk, mime mismatch,
          // route rejection). Show a diagnostic block so the user can
          // tell broken thumbnails apart from genuinely empty ones.
          <div className="flex h-full w-full flex-col items-center justify-center gap-1 p-3 text-center">
            <ImageIcon className="h-6 w-6 text-muted-foreground/60" />
            <div className="text-[10px] font-medium text-muted-foreground">
              Image unavailable
            </div>
            <div className="line-clamp-2 break-all text-[9px] text-muted-foreground/70">
              {image.imagePath}
            </div>
          </div>
        ) : (
          /* eslint-disable-next-line @next/next/no-img-element */
          <img
            src={url}
            alt={image.caption ?? "Extracted image"}
            loading="lazy"
            onError={() => setLoadError(true)}
            className="h-full w-full object-cover"
          />
        )}
      </div>
      <div className="space-y-1 p-2">
        {image.caption ? (
          <div className="line-clamp-1 text-xs font-medium">{image.caption}</div>
        ) : null}
        <div className="flex items-center justify-between text-[10px] text-muted-foreground">
          {image.page != null ? <Badge variant="outline">p.{image.page}</Badge> : <span />}
          {showScore && "score" in image && typeof image.score === "number" ? (
            <Badge variant="info">{Math.round(image.score * 100)}%</Badge>
          ) : null}
        </div>
      </div>
      {image.ocrText ? (
        <div
          className="pointer-events-none absolute inset-x-0 bottom-0 line-clamp-3 bg-background/85 p-2 text-[10px] opacity-0 backdrop-blur-sm transition-opacity group-hover:opacity-100"
          aria-hidden
        >
          {image.ocrText}
        </div>
      ) : null}
    </button>
  );
}

function ImageModal({
  image,
  indexId,
  open,
  onOpenChange,
}: {
  image: ImageRow | SearchHit;
  indexId: string | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [similar, setSimilar] = useState<SearchHit[] | null>(null);
  const [loading, setLoading] = useState(false);

  async function findSimilar() {
    if (!indexId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/indexes/${indexId}/images/similar`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ imageId: image.id, topK: 8 }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast({ title: "Find similar failed", description: err.error });
        return;
      }
      const body = await res.json();
      setSimilar(body.hits ?? []);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <ImageIcon className="h-4 w-4" />
            {image.caption ?? "Image"}
            {image.page != null ? (
              <Badge variant="outline">page {image.page}</Badge>
            ) : null}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={imageUrlFor(image.imagePath)}
            alt={image.caption ?? "Extracted image"}
            className="max-h-[60vh] w-full rounded-lg border bg-muted object-contain"
          />
          {image.ocrText ? (
            <div>
              <div className="text-xs font-semibold text-muted-foreground">OCR text</div>
              <pre className="mt-1 max-h-48 overflow-auto whitespace-pre-wrap rounded-lg border bg-muted/30 p-3 text-xs">
                {image.ocrText}
              </pre>
            </div>
          ) : null}
          {similar !== null ? (
            <div>
              <div className="text-xs font-semibold text-muted-foreground">
                Similar images ({similar.length})
              </div>
              {similar.length === 0 ? (
                <div className="mt-1 text-xs text-muted-foreground">
                  No similar images in this index.
                </div>
              ) : (
                <div className="mt-2 grid grid-cols-3 gap-2 lg:grid-cols-4">
                  {similar.map((s) => (
                    <a
                      key={s.id}
                      href={imageUrlFor(s.imagePath)}
                      target="_blank"
                      rel="noreferrer"
                      className="relative block overflow-hidden rounded-lg border"
                      title={s.caption ?? ""}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={imageUrlFor(s.imagePath)}
                        alt={s.caption ?? "Similar image"}
                        loading="lazy"
                        className="aspect-square h-full w-full object-cover"
                      />
                      {typeof s.score === "number" ? (
                        <Badge
                          variant="info"
                          className="absolute right-1 top-1 text-[10px]"
                        >
                          {Math.round(s.score * 100)}%
                        </Badge>
                      ) : null}
                    </a>
                  ))}
                </div>
              )}
            </div>
          ) : null}
        </div>
        <DialogFooter className="flex-row items-center justify-between gap-2">
          <Button asChild variant="outline" size="sm">
            <a href={imageUrlFor(image.imagePath)} target="_blank" rel="noreferrer">
              <ExternalLink className="h-3.5 w-3.5" /> Open original
            </a>
          </Button>
          <div className="flex items-center gap-2">
            {indexId ? (
              <Button size="sm" variant="gradient" onClick={findSimilar} disabled={loading}>
                {loading ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Sparkles className="h-3.5 w-3.5" />
                )}
                Find similar
              </Button>
            ) : null}
            <Button size="sm" variant="ghost" onClick={() => onOpenChange(false)}>
              Close
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/**
 * Translate a stored `imagePath` ("images/<sha>.<ext>") into the server
 * route that streams it. The catch-all route accepts both the bare hash
 * filename and the full canonical path so we strip the prefix here for a
 * cleaner URL.
 */
export function imageUrlFor(imagePath: string): string {
  const trimmed = imagePath.replace(/^images\//, "");
  return `/api/images/${trimmed}`;
}
