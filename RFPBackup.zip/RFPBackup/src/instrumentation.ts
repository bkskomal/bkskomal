// Runs once at server startup. Use this to validate config and fail fast on
// missing/bad env, rather than letting the first request throw a confusing
// error. Next.js calls register() automatically (see next.config.ts has
// serverActions.bodySizeLimit which already opts into the instrumentation API
// since 15.0).

export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  const { env } = await import("@/lib/env");

  const log = (level: "info" | "warn" | "error", msg: string) => {
    const tag = level === "error" ? "✗" : level === "warn" ? "!" : "✓";
    console.log(`[autorfp] ${tag} ${msg}`);
  };

  console.log("\n[autorfp] startup checks");

  try {
    new URL(env.DATABASE_URL);
    log("info", `database: ${maskUrl(env.DATABASE_URL)}`);
  } catch {
    log("error", `DATABASE_URL is not a valid URL`);
  }

  if (env.AUTH_SECRET.length < 32) {
    log("warn", `AUTH_SECRET is ${env.AUTH_SECRET.length} chars — generate a 32+ byte secret with: openssl rand -base64 32`);
  } else {
    log("info", `auth secret loaded (${env.AUTH_SECRET.length} chars)`);
  }

  const detectedProvider = detectProvider(env.LLM_BASE_URL);
  log("info", `LLM endpoint: ${env.LLM_BASE_URL}  (${detectedProvider})`);
  log("info", `LLM model: ${env.LLM_MODEL}`);

  if (env.LLM_API_KEY === "REPLACE_WITH_YOUR_OPENROUTER_KEY" || !env.LLM_API_KEY) {
    log("error", `LLM_API_KEY looks unset — generation will fail until this is configured`);
  }

  // For Ollama, probe the daemon so devs immediately see whether the local
  // server is up. We swallow errors and surface them as a clear, actionable
  // warning rather than failing startup — the user might be configuring an
  // org-level override that points elsewhere.
  if (detectedProvider === "Ollama") {
    try {
      const { pingOllama } = await import("@/lib/ai/ollama");
      const ping = await pingOllama(env.LLM_BASE_URL, 1500);
      if (ping.ok) {
        log("info", `Ollama reachable: v${ping.version}`);
      } else {
        log(
          "warn",
          `Ollama not running at ${env.LLM_BASE_URL} (${ping.error}) — install from https://ollama.com and run \`ollama serve\``,
        );
      }
    } catch (e) {
      log("warn", `Ollama probe failed: ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  if (env.EMBEDDING_BASE_URL === env.LLM_BASE_URL && env.LLM_BASE_URL.includes("openrouter")) {
    log("warn", `EMBEDDING_BASE_URL points at OpenRouter, which doesn't serve embeddings — knowledge-base indexing will fail. Point it at Ollama (http://localhost:11434/v1) or OpenAI.`);
  } else {
    log("info", `embedding endpoint: ${env.EMBEDDING_BASE_URL}  (model: ${env.EMBEDDING_MODEL})`);
  }

  if (env.LLAMA_CLOUD_API_KEY) {
    log("info", `LlamaParse enabled — PDF/Word/PPT will use cloud extraction`);
  } else {
    log("info", `LlamaParse disabled — using local parsers`);
  }

  // Rate-limit backend selection. The check is cheap and the answer drives
  // behavior across every API call — worth surfacing on startup. We eagerly
  // build the configured backend here so the very first request doesn't fall
  // back to in-memory while Redis is still discovering.
  if (env.RATE_LIMIT_BACKEND === "redis") {
    if (!env.REDIS_URL) {
      log(
        "error",
        `RATE_LIMIT_BACKEND=redis but REDIS_URL is unset — falling back to in-process memory backend`,
      );
    } else {
      try {
        // webpackIgnore: don't trace ioredis through the edge runtime bundle.
        // ioredis depends on Node "stream", "net", and "tls" builtins that
        // webpack refuses to polyfill, so even though this code path is
        // gated by NEXT_RUNTIME === "nodejs", the static analyzer would
        // otherwise still try to bundle it and fail the build.
        const ioredisMod = await import(/* webpackIgnore: true */ "ioredis");
        const Client = (ioredisMod as unknown as { default?: typeof ioredisMod.Redis }).default ??
          ioredisMod.Redis;
        // A short, bounded probe — never block startup for more than a couple
        // of seconds on a flaky Redis.
        const probe = new Client(env.REDIS_URL, {
          maxRetriesPerRequest: 1,
          lazyConnect: true,
          enableOfflineQueue: false,
          connectTimeout: 2_000,
        });
        try {
          await probe.connect();
          const pong = await probe.ping();
          log("info", `rate-limit backend: redis (${maskUrl(env.REDIS_URL)}) — ping=${pong}`);
        } finally {
          probe.disconnect();
        }
      } catch (e) {
        const msg = e instanceof Error ? e.message : String(e);
        log("error", `rate-limit backend: redis configured but ping failed — ${msg}`);
      }
    }
  } else {
    log(
      "info",
      `rate-limit backend: memory (single-instance — set RATE_LIMIT_BACKEND=redis + REDIS_URL for multi-replica deployments)`,
    );
  }

  // Eagerly construct the rate-limit backend + log the OAuth providers used
  // to live here, but webpack's static analyser pulls the whole import graph
  // (rate-limit → pino → node:crypto, auth → next-auth → nodemailer) into the
  // edge-runtime bundle even though these branches only ever run under the
  // Node runtime. Both are cosmetic (the first request initialises the
  // backend lazily; OAuth keys are visible via env), so we skip them here.

  if (process.env.NODE_TLS_REJECT_UNAUTHORIZED === "0") {
    log("warn", `NODE_TLS_REJECT_UNAUTHORIZED=0 — TLS certificate validation is OFF. OK for local dev behind a corporate proxy; never use in production.`);
  } else if (process.env.NODE_EXTRA_CA_CERTS) {
    log("info", `NODE_EXTRA_CA_CERTS=${process.env.NODE_EXTRA_CA_CERTS}`);
  }

  const devAuthOn = process.env.NODE_ENV === "development" || process.env.ENABLE_DEV_AUTH === "1";
  if (devAuthOn) {
    const reason = process.env.ENABLE_DEV_AUTH === "1" ? "ENABLE_DEV_AUTH=1" : "NODE_ENV=development";
    log("warn", `dev sign-in shortcut is enabled at /auth/dev (${reason}) — never expose this build on the public internet`);
  }

  console.log("");
}

function maskUrl(url: string): string {
  try {
    const u = new URL(url);
    if (u.password) u.password = "***";
    return u.toString();
  } catch {
    return url.replace(/:[^@/]+@/, ":***@");
  }
}

function detectProvider(baseUrl: string): string {
  const u = baseUrl.toLowerCase();
  if (u.includes("openrouter.ai")) return "OpenRouter";
  if (u.includes("api.openai.com")) return "OpenAI";
  if (u.includes("11434")) return "Ollama";
  if (u.includes("1234")) return "LM Studio";
  if (u.includes("localai")) return "LocalAI";
  return "self-hosted";
}
