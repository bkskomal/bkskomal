# Commits — chronological with narrative

Every commit that landed on `origin/main` this session, in the order it
was pushed. Read this if you're trying to understand why a specific
piece of code exists.

## Tip of `main` = `3e16b9c`

## The list

### `3e16b9c chore(brand): simplify icon to single 'O' ring`

The prior iOm-wordmark didn't survive downscaling to 48×48 marketplace
tiles. Replaced with a single "O" ring (white outer, amber accent dot
dead-center) on the indigo→teal gradient. Reads clean at every size.
Files: `assets/activity.svg`, `assets/icon.svg`, `assets/icon.png`.

### `48b1d70 fix(providers): endpoint probe treats 405 on chat/completions as a completions-fallback signal`

Real-world case from a K2.7 Code gateway: Test Connection passed
(GET `/v1/models` → 200) but every message failed with HTTP 405
Method Not Allowed. The gateway is a bare-vLLM where only
`/v1/completions` accepts POST. The previous probe only auto-fell
back on the specific "chat_template missing" error string; a 405
didn't match that pattern → probe left it alone → every request
failed.

Fix: on 405 at `/v1/chat/completions`, probe `/v1/completions` too.
If completions accepts POST (or errors with something other than
405/404), auto-flip to fallback. Extra probe cost is ~200-500ms
one-time on gateways where chat doesn't work; every other gateway
still takes exactly one probe. 4 new tests.

### `7a11b06 chore(brand): extension name → oati-code, VSIX now oati-code.vsix`

Renamed extension `name` field from `iomcode` to `oati-code` so vsce
packages the artifact as `dist/oati-code.vsix`. Matches the "OATI
Code" display brand set by ed2ba93. Before this, users saw "OATI
Code" in VS Code but had to install `iomcode.vsix`, which was jarring.

Preserved as-is: publisher (`iom`), command IDs (`iom.*`), workspace
folder (`.iom/`), CSS classes (`iom-*`), npm packages (`@iom/*`),
internal state markers. Only extension name + VSIX filename moved.

### `ed2ba93 chore(brand): user-visible default renamed to 'OATI Code'`

Product policy: shipped default display name is now "OATI Code" (the
company brand users recognize). Internal technical identity stays as
"iomcode" so the previous rebrand commits don't need to be undone.

Changed `DEFAULT_DISPLAY_NAME` in shared/config.ts to "OATI Code";
updated all package.json user-visible strings (displayName, activity-
bar title, sidebar name, command categories, capabilities description,
etc.); swept extension-host source (toast messages, code-lens titles,
diff titles, output channel, status-bar tooltip); swept webview
(welcome fallback, onboarding ARIA label, Settings placeholder text).

Internal state markers stay `[iOm image memory]`, `[iOm shrink: …]`,
`[iOmCode inlined …]` — emitter/checker paired constants; changing
them would break string-startsWith matching. They're opaque tech,
users don't parse them.

### `b7df622 chore(brand): iOm Code → iOmCode + configurable displayName in Settings`

Three sub-changes:

1. **Display name normalized** — "iOm Code" (with space) → "iOmCode"
   (one word) across 111 files.
2. **Extension `name`** → `iomcode` (from `iom-coding-assistant`).
   VSIX becomes `iomcode.vsix`. Marketplace itemName becomes
   `iom.iomcode`.
3. **Configurable branding** — new `BrandingConfig` block on
   `RootConfig` with `displayName`, `shortName`, `tagline`. Three
   shared helpers: `resolveDisplayName`, `resolveShortName`,
   `resolveTagline`. New "🏷 Branding" tab in Settings. Chat panel
   title + welcome hero read through helpers so users can rebrand
   per-workspace.

**What can't be changed at runtime**: VS Code metadata (activity-bar
title, marketplace listing, uninstall dialog, command palette prefix)
— baked in at package time.

### `2ff9241 feat(agent): JIT retry safety net + concurrency queue UI chip`

Polish on the Tier-2 features shipped in e608a6d.

**JIT retry safety net**: aggressive contextBudget drops tool schemas
whose names haven't recently been used. If the model tries to call a
dropped tool, strict providers (Anthropic native, some vLLM chat
endpoints) reject with an "unknown/undefined tool" error. Fix:
extract the tool name from the error via regex, add to a session-
lifetime `jitAlwaysInclude` set that promotes it to the effective
core-set on all future turns.

**Concurrency queue UI chip**: new `provider_queue_status` RPC message
(host → webview). ProviderManager exposes `onQueueEvent(listener)`
API; chat-panel subscribes + forwards to webview. Webview shows
subtle dashed-border chip: "⏳ Waiting for a slot on <providerId> —
2 requests ahead…" Vanishes when the "started" event arrives.
Respects `prefers-reduced-motion`.

9 new tests.

### `e608a6d feat(agent): Tier-2 throughput features — dedup + JIT tools + concurrency cap + adaptive`

The bulk of the throughput-optimization stack. Five features, all
opt-in per-mode or per-provider:

1. **Per-provider concurrency cap** (`ProviderConfig.maxConcurrentRequests`).
   Client-side FIFO queue on requests. Prevents sub-agent fan-out
   from self-DoSing shared-KV-cache gateways.
2. **Duplicate-read dedup** — pure transform: same-content re-reads
   of the same file (detected by FNV-1a hash) collapse to reference
   stubs. Preserves the FIRST read and the LAST read verbatim.
3. **JIT tool schemas** — CORE ∪ RECENT (last 5 turns) ∪ MENTIONED.
   Only pruned when tool count ≥ 12.
4. **Skill auto-unload** — noted as covered by the existing
   context-shrink transform (load_skill results ARE large tool_results;
   the same rolling-truncation rule drops them at 5 turns of non-use).
5. **Adaptive load-aware auto-switching** — per-(providerId, modelId)
   `LoadMonitor` classifies each request by TTFT + generation TPS.
   Enters "loaded" state when 3 of last 5 are degraded. Exits after
   3 consecutive healthy. `Conductor.setLoadStateResolver()` hook
   lets extension-host wire in the monitor lookup; when
   `mode.adaptiveContextBudget: true` and state is "loaded",
   contextBudget is overridden to "aggressive" for this turn.

Timing captured in ProviderManager's `wrapWithLoadMeter` layer
(measures INSIDE the concurrency limiter so queue-wait time doesn't
pollute the "gateway is slow" signal). 37 new tests.

### `aa11c0a feat(agent): Tier-1 aggressive context budget + /wire-audit`

Ships the first layer of the throughput-mode plan.

**Tier 1**:
- New `ModeConfig.contextBudget: "aggressive" | "normal" | "generous"`
  (default "normal")
- When aggressive: rolling `tool_result` truncation
  (`packages/agent-core/src/context-shrink.ts`), auto-compact
  threshold moves to 25% of window
- Session history on disk stays verbatim; only the outgoing request
  shrinks. Preserves tool_call_id linkage. Small results (<1000 chars)
  left alone.

**/wire-audit slash command**:
- Bounded ring buffer (last 8 turns) of wire snapshots in
  `packages/agent-core/src/wire-audit.ts`
- Emitter side: agent-core emits `wire_audit` AgentEvent before
  each `provider.stream()`
- Consumer side: `WireAuditRecorder` in chat-panel drains on-demand
  when user types `/wire-audit`
- Renders per-turn breakdown: system_prompt, tool schemas, user,
  assistant, tool_calls, tool_results, images. Flags tool_results
  as "🔥 hot spot" when >50%. Names top 5 offenders with turn +
  preview.

Privacy: audit stays LOCAL — never sent to the model, never logged.
Obvious credential patterns redacted defensively. 23 new tests.

### `8fca600 feat(agent-ux): capability probe + batched clarification + anchored todos`

Three UX improvements built in sequence. Delivered as one commit
because they share touchpoints.

**Endpoint capability probe** — on first use of (providerId, modelId,
baseUrl), ProviderManager probes `${baseUrl}/chat/completions` and
classifies:
- 200 → chatCompletionsWorks
- 4xx + `/chat[_\s-]?template/i` body → needsCompletionsFallback
- 401 / 404 / 5xx / network → NOT cached; real error surfaces

Result cached in `vscode.Memento` keyed by (providerId, modelId), tied
to baseUrl so URL edits auto-invalidate. Stale after 24h.

**`ask_user_batch`** — new tool. Model calls this at the START of
ambiguous "build me X" requests to ask 2-4 disambiguating questions
in one paginated card. Companion to `ask_user`, not a replacement.
Card is `packages/webview-ui/src/components/ask-user-batch-card.tsx`
(~240 lines). Respects same `ModeConfig.allowAskUser` policy
(always / auto-pick-first / never). Dismiss returns
`{answers: [], dismissed: true}`.

**Anchored todo checklist** — `TodoListPanel` moved from top-of-chat
to just above the composer (Cursor / OpenCode pattern). Compact by
default — one-line summary "X of Y todos completed" + chevron. User
clicks to expand into full list. Resume + auto-resume affordances
relocated from header-inline to an actions row inside the expanded
body. List scrolls internally at 260px max-height. In-progress
marker changed from ◐ to ◉ (filled radio-dot).

### `ef4294e chore(brand): rebrand OATI Code → iOm Code + ship deferred session work`

The rebrand commit + a milestone commit that consolidated ~1 month
of accumulated uncommitted work.

**Rebrand** — full breaking rebrand from "OATI Code" to "iOm Code":
- Extension publisher: oati → iom
- npm package names: @oati/* → @iom/*
- Command IDs / setting keys: oati.* → iom.*
- Workspace folder: .oati/ → .iom/
- Project memory file: OATI.md → IOM.md
- CSS class prefix: oati-* → iom-*
- View container IDs: oatiActivity/oatiSessions → iom*
- VS extension DPAPI entropy: OATI.v1.entropy → iOm.v1.entropy
- Marketplace itemName: oati.oati-coding-assistant → iom.iom-coding-assistant
- Icon: sparkle ✦ → text-based "iOm" wordmark (later replaced by
  single-O ring in 3e16b9c)

References to "OATI" the COMPANY (gateway URLs *.oati.com, "OATI
Compatible" provider preset, "OATI branded PPTX" template, Copyright
OATI Technology, `branded-pptx` skill triggers) preserved.

**Deferred work landed alongside**:
- Opus 4.7/Claude family fixes (`omitTemperature` quirk)
- Plan-mode V2 (Phase 5) + Phase 3.3 LCS-based hunk diff
- js-yaml → 200-line mini-parser (-84 KB bundle)
- MCP HTTP/SSE transport in Settings UI + YAML frontmatter for
  slash commands
- OATI Compatible + Moonshot Kimi (direct) provider presets
- `/v1/completions` fallback for gateways without chat templates
- Test Connection now validates the configured model is in
  the served list (not just "200 OK")
- Loop-guard uses user-role messages (not synthetic tool_result)
- VSIX packaging reliably ships webview/dist
- Context-fill chip moved to LEFT of mode picker in composer
- Settings panel no longer leaves phantom session in sidebar
- Budget Guardrails UI with master toggle
