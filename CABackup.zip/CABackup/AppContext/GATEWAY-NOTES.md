# Gateway Notes — the K2.7 diagnosis story

Everything learned this session about the OATI LLM gateway topology
and the various failure modes we hit. Read this if you're setting up
OATICode against the K2.7 Code gateway or hitting HTTP 405 errors.

## The topology (as best we understand it)

Two services live on `genieappn10` (10.100.226.246):

| Port | What | Firewall | Access |
|---|---|---|---|
| **8080** | Direct model server (bare vLLM or similar, OpenAI-compatible) | Open on internal LAN | Any machine on corp LAN |
| **7300** | OATI LLM gateway (fronting the model with auth/logging/quotas) | VPN-only or restricted subnet | Machines inside the "app tier" subnet only |

There's also a **remote/RDP machine** the user works from that CAN
reach both ports (it lives inside the app-tier subnet). Their local
dev machine sits in a "user tier" subnet where port 7300 is filtered.

## The three failure modes we diagnosed

### Failure mode 1 — 405 Method Not Allowed on `/v1/chat/completions`

**Symptom**: Test Connection through the gateway passes
(`GET /v1/models → 200 OK`), but every real message fails with:

> Agent error: Kimi K2.7 Code HTTP 405 Method Not Allowed: Method Not Allowed

**Cause**: Bare-vLLM style gateway where only `/v1/completions` accepts
POST — `/v1/chat/completions` is closed off entirely, not just missing
a chat_template.

**Fix (48b1d70)**: Endpoint capability probe widened. On 405 at
`/v1/chat/completions`, the probe now also tries `/v1/completions`.
If completions accepts POST (or errors with anything other than
405/404), auto-flips to fallback path. Fully transparent to users
after install.

### Failure mode 2 — 405 through gateway, works direct

**Symptom**: Same error as above, but the direct URL
(`http://genieappn10:8080/v1`) works when tested manually.

**Cause**: The gateway blocks POST to `/v1/chat/completions`.
Everyone else in the org is presumably using `/v1/completions` and
the gateway was never configured to forward chat completions.

**Fix**: Two options —
1. **Bypass** — point OATICode at the direct URL
   (`http://genieappn10:8080/v1`) which has a proper chat_template
   loaded. Works today, zero VPN dependency.
2. **File a ticket** — ask ops to enable POST forwarding for
   `/v1/chat/completions` at the gateway. Draft below:

> **Gateway blocks POST to `/v1/chat/completions` on port 7300**
>
> GET `/v1/models` returns 200 OK through the gateway
> (`http://genieappn10:7300/v1/models`) but POST to
> `/v1/chat/completions` returns 405 Method Not Allowed. Direct
> model access on port 8080 (`http://genieappn10:8080/v1/chat/completions`)
> accepts POST and returns proper chat responses, confirming the
> model server is fine — the gateway is blocking the METHOD. Please
> check gateway routing rules (nginx/traefik/API-gateway config) to
> enable POST forwarding for `/v1/chat/completions`, not just GET
> `/v1/models`.

### Failure mode 3 — Port 7300 unreachable from local dev machine

**Symptom**: `Test-NetConnection genieappn10 7300` **hangs ~10-20
seconds** then returns `TcpTestSucceeded : False`. Port 8080 on same
host succeeds fast. Same test on the remote/RDP machine succeeds on
both.

**Cause**: Corporate LAN firewall between the user's dev subnet and
the app-tier subnet drops port 7300 packets silently while allowing
8080. The slow-fail (SYN silently dropped, no RST) is the fingerprint
of a firewall vs a nothing-listening situation.

**Fix**: Three options —
1. **Use 8080 direct** — recommended for individual dev use.
2. **VPN** — connect GlobalProtect. Once the PANGP virtual adapter
   appears in `Get-NetAdapter`, port 7300 routes through the tunnel
   and works.
3. **SSH tunnel through the remote machine** —
   `ssh -L 7300:genieappn10:7300 <you>@<remote-machine>` then point
   OATICode at `http://localhost:7300/v1`.

## VPN status vs GP process status — the sneaky one

We hit this: GlobalProtect processes (PanGPA + PanGPS) running,
tray icon may show "connected", but the ACTUAL VPN tunnel is NOT
up. Diagnosis:

```powershell
Get-NetAdapter | Where-Object { $_.Name -match "PANGP" }
# If empty: tunnel is NOT actually up (GP app is running but not
# connected). Also check:
Find-NetRoute -RemoteIPAddress 10.100.226.246
# If it routes via your regular LAN interface (Ethernet 3, WiFi):
# tunnel not routing that IP. If it routes via a PANGP interface:
# tunnel is up.
```

Fix: Right-click GP tray icon → Show Panel → confirm state → click
Connect. Or use the `_gp_login` Personal Assistant skill to automate
the login (handles UIA field-position quirks reliably).

## The `Test-NetConnection` timing tell

Learned this session — use it for future diagnoses:

| Elapsed | Likely cause |
|---|---|
| < 1 second, `TcpTestSucceeded: False` | Nothing listening on port (server RST'd immediately) |
| ~10-20 seconds, `TcpTestSucceeded: False` | Firewall silently dropping packets (SYN sent, no reply, client times out) |
| ~3-5 seconds, `TcpTestSucceeded: True` | Normal handshake — port is open |

Combine this with `Find-NetRoute` and `Get-NetAdapter` for a
complete picture of "why isn't this connecting".

## Recommendation

For individual dev use on the current machine: **use the direct URL
`http://genieappn10:8080/v1`**. It works today, doesn't need VPN,
doesn't depend on the gateway. Configuration steps in
`CONFIGURATION.md`.

Only revisit the 7300 gateway if:
- Your team introduces quotas that only track through the gateway
- Auth logging / cost attribution requires gateway routing
- Compliance requires it

Then choose from the three fixes in "Failure mode 3" above.
