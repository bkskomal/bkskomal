# Features added this session — quick reference

Punch-list of every capability that appeared in `origin/main` during
the session. Grouped by area. Each item lists the commit(s) that
introduced it and where the code lives.

## Throughput / context management (the big new axis)

### Aggressive context budget

**What**: Per-mode setting that trims the wire body sent to the model.
Combines three transforms + a lower auto-compact threshold.

**Commits**: aa11c0a (Tier 1), e608a6d (Tier 2), 2ff9241 (polish)

**Files**:
- `packages/agent-core/src/context-shrink.ts` — rolling truncation
- `packages/agent-core/src/read-dedup.ts` — duplicate-read collapse
- `packages/agent-core/src/jit-tools.ts` — JIT schema filtering
- `packages/agent-core/src/agent.ts` — auto-compact threshold override,
  wire-build orchestration

**Enable via**: Settings → Agent Behavior → Context budget → `Aggressive`

**Result**: Typical wire body shrinks 60-80% on turns with big prior
tool_results. Auto-compact at 25% of window (vs 60-90% normal).

### Adaptive context budget

**What**: Monitor TTFT + generation TPS per (provider, model). When
3 of last 5 requests are degraded, temporarily override contextBudget
to "aggressive". Revert after 3 consecutive healthy.

**Commits**: e608a6d

**Files**:
- `packages/agent-core/src/load-monitor.ts` — pure state machine
- `packages/agent-core/src/conductor.ts` — `setLoadStateResolver` hook
- `packages/extension-host/src/provider-manager.ts` —
  `wrapWithLoadMeter` layer

**Enable via**: Settings → Agent Behavior → Adaptive context budget → ☑

### Per-provider concurrency cap

**What**: Client-side FIFO queue on requests. Prevents sub-agent
fan-out (spawn_agent × 4 × nested → 12+ concurrent streams) from
self-DoSing shared-KV-cache gateways.

**Commits**: e608a6d, 2ff9241 (UI chip)

**Files**:
- `packages/providers/src/concurrency-limiter.ts`
- `packages/webview-ui/src/app.tsx` — waiting-for-slot chip

**Enable via**: Settings → API Configuration → <provider> →
Max concurrent requests (integer; 0 = unlimited default)

### `/wire-audit` slash command

**What**: Per-request breakdown of what OATICode sent to the model.
Categorized (system_prompt / tool schemas / user / assistant /
tool_calls / tool_results / images) with token counts + percentages.
Flags tool_results as "🔥 hot spot" when >50%. Names top 5 biggest
tool_results with turn + preview.

**Commits**: aa11c0a

**Files**:
- `packages/agent-core/src/wire-audit.ts` (`WireAuditRecorder` +
  `renderAuditText`)
- `packages/extension-host/src/chat-panel.ts` (recorder wire-up)
- `packages/webview-ui/src/app.tsx` (slash command)

**Enable via**: Type `/wire-audit` in the chat after a few turns

### JIT retry safety net

**What**: When a strict provider (Anthropic native, some vLLM chat)
rejects a tool call because its schema was JIT-dropped, extract the
tool name from the error and add it to a session-lifetime
"always-include" set.

**Commits**: 2ff9241

**Files**:
- `packages/agent-core/src/agent.ts` (`jitAlwaysInclude` set,
  `extractUnknownToolNames` helper, error-path integration)

**Enable via**: Automatic when aggressive contextBudget is on

## Provider integration

### Endpoint capability probe

**What**: On first use of (providerId, modelId, baseUrl), probe
`${baseUrl}/chat/completions` to decide whether the provider needs
`/v1/completions` fallback (raw text-in / text-out).

**Commits**: 8fca600 (initial), 48b1d70 (widened for 405)

**Files**:
- `packages/providers/src/endpoint-probe.ts` — pure probe function
- `packages/extension-host/src/endpoint-capability.ts` —
  `EndpointCapabilityCache` (Memento-backed)
- `packages/extension-host/src/provider-manager.ts` — wrap providers

**Auto-detected**:
- 200 → chatCompletionsWorks
- 4xx + chat_template-style body → fallback
- 405 + `/v1/completions` accepts POST → fallback (48b1d70)
- Everything else → no fallback (real error surfaces)

**Cached**: 24h in `vscode.Memento` keyed by (providerId, modelId).
Base URL edits auto-invalidate.

## Agent UX

### `ask_user_batch` tool

**What**: Model calls this at the START of ambiguous "build me X"
requests to ask 2-4 disambiguating questions in one paginated card.
Companion to `ask_user`.

**Commits**: 8fca600

**Files**:
- `packages/tools/src/ask-user-batch.ts` — tool definition
- `packages/webview-ui/src/components/ask-user-batch-card.tsx` —
  paginated card UI (radio buttons, "Type your own answer"
  reveal, Dismiss / Next / Submit)
- `packages/shared/src/messages.ts` — RPC message types

**Behavior**:
- Same `ModeConfig.allowAskUser` policy as `ask_user`
- Dismiss returns `{answers: [], dismissed: true}`

### Anchored todo checklist

**What**: `TodoListPanel` moved from top-of-chat to just above the
composer (Cursor / OpenCode pattern). Collapsed by default with
one-line "X of Y todos completed" summary. Click to expand.

**Commits**: 8fca600

**Files**:
- `packages/webview-ui/src/app.tsx` — mount site
- `packages/webview-ui/src/components/todo-list.tsx` — redesigned
- `packages/webview-ui/src/styles.css` — `.iom-todo-*` restyled

**UX details**:
- Compact bar always visible while chat scrolls
- Expanded body scrolls internally at 260px max-height
- Resume + auto-resume affordances live inside expanded body,
  not squeezed into header
- In-progress marker: ◉ (filled radio-dot)

## Branding

### Configurable displayName / shortName / tagline

**What**: `RootConfig.branding` block lets users override the shipped
default product name at runtime for personal/team branding.

**Commits**: b7df622, ed2ba93 (default changed to "OATI Code")

**Files**:
- `packages/shared/src/config.ts` — `BrandingConfig` +
  `resolveDisplayName` / `resolveShortName` / `resolveTagline` helpers
- `packages/extension-host/src/chat-panel.ts` — panel title reads
  through helper
- `packages/webview-ui/src/components/welcome.tsx` — hero + tagline
  read through helper
- `packages/webview-ui/src/components/settings-panel.tsx` —
  Branding tab

**Enable via**: Settings → Branding → Display name / Short name /
Tagline

**Constraint**: VS Code metadata (activity-bar title, marketplace
listing, uninstall dialog, command palette prefix) is baked in at
package time and can't be overridden by runtime config.

## Icons / Chrome

### Single "O" ring icon

**What**: Simpler icon that survives downscale to 48×48 marketplace
tiles.

**Commits**: 3e16b9c (final version). Prior iterations in earlier
rebrand commits.

**Files**:
- `packages/extension-host/assets/activity.svg` — activity bar,
  currentColor
- `packages/extension-host/assets/icon.svg` — marketplace, gradient
  background + white ring + amber center dot
- `packages/extension-host/assets/icon.png` — regenerated via
  System.Drawing to match SVG geometry
