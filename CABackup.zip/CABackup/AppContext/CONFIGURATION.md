# Configuration Guide

How to configure OATICode against the providers we've validated this
session. Focus on Kimi K2.7 Code — that's the specific gateway we
diagnosed in depth.

## First-time provider setup — Kimi K2.7 Code (direct)

The tested-working configuration:

1. **Ctrl+Shift+P** → **OATI Code: Open Settings**
2. Sidebar → **⚙ API Configuration**
3. Click **+** to add a new provider (or edit existing)
4. Fill in:

| Field | Value |
|---|---|
| Display Name | `Kimi K2.7 Code` (or anything you like) |
| API Provider | `OpenAI Compatible` |
| Base URL | `http://genieappn10:8080/v1` |
| API Key | *paste directly in the field — never in chat* |
| Model ID | `kimi-k2.7-code` (NOT `openai/kimi-k2.7-code` — no prefix) |

5. Click **Test Connection** — should show
   `✓ http://genieappn10:8080/v1/models → 200 OK · "kimi-k2.7-code" is loaded`
6. Set as active provider (star icon)

## Verify it works end-to-end

Send a simple message like "hi". Watch the chat for:

- **✅ Normal streaming response** — you're set
- **❌ HTTP 405 Method Not Allowed** — see `GATEWAY-NOTES.md`; you
  may be pointing at the gateway URL (`gry5qaapps3:7300`) instead of
  the direct URL (`genieappn10:8080`)

## Turn on the throughput features

Since this is a shared-KV-cache gateway (K2.7 Code 424B on 4× H200),
the aggressive-mode features earn their keep:

### Settings → Agent Behavior (for the mode you're using)

| Setting | Recommended | Why |
|---|---|---|
| **Context budget** | `Aggressive` | Rolling tool_result shrink + duplicate-read dedup + JIT tool schemas. Typical wire body drops 60-80% on turns with big prior file reads |
| **Adaptive context budget** | ☑ (checked) | Auto-flips to aggressive when the gateway shows load (TTFT × 3 or TPS ÷ 2 in 3 of last 5 requests). Reverts on 3 consecutive healthy requests |
| **Max iterations per agent run** | 30-50 | Higher than default 25 for large codebases |

### Settings → API Configuration → Kimi K2.7 Code

| Setting | Recommended | Why |
|---|---|---|
| **Max concurrent requests** | `3` | 4× H200 has ~140 GB KV cache; capping at 3 concurrent leaves headroom for other users on the same box. Prevents self-DoS when sub-agents fan out |

## Measure your context spend

After a few turns, type `/wire-audit` in the chat. You'll get a
breakdown like:

```
Turn 12 @ 14:22:03 → 247,394 tokens · model=kimi-k2.7-code
├─ system_prompt        14,203  (5.7%)
├─ tool schemas          8,441  (3.4%)
├─ user messages           892  (0.4%)
├─ assistant text        3,204  (1.3%)
├─ tool_call blocks      1,127  (0.5%)
├─ tool_result blocks  219,527  (88.7%)  🔥 hot spot
│  ↳ Biggest tool_results (candidates for shrink):
│     • turn 8, 42,847 tokens: "// packages/agent-core/src/agent.ts..."
│     • turn 5, 38,204 tokens: "{...} large exec output..."
```

Anywhere `tool_result blocks` shows 🔥 (>50% of total), aggressive
mode will help.

## Other provider presets available

OATICode ships with curated presets for these providers:

| Preset | Base URL | Notes |
|---|---|---|
| **OpenAI Compatible** | user-supplied | Generic OpenAI-compatible gateway (vLLM, SGLang, LiteLLM, unillm, custom) |
| **OpenAI** | `https://api.openai.com/v1` | Official OpenAI (GPT-4o, o3, o3-mini) |
| **OpenRouter** | `https://openrouter.ai/api/v1` | Aggregator with 300+ models |
| **Kimi K2.6 (recommended)** | OpenRouter | Kimi K2 family via OpenRouter |
| **Moonshot Kimi (direct)** | `https://api.moonshot.ai/v1` | Direct Moonshot API |
| **Anthropic** | `https://api.anthropic.com` | Native Anthropic API (Claude Opus/Sonnet/Haiku) |
| **LiteLLM** | user-supplied | Any LiteLLM gateway |
| **unillm** | user-supplied | User's own unillm gateway (E:\AI\Self\LLMLite) |
| **Ollama** | `http://localhost:11434` | Local Ollama |
| **OATI Compatible** | `https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1` (OATI Genie) | OATI's internal LLM gateway with curated models |

## Model quirks are auto-detected

For any model you type in, `packages/shared/src/model-quirks.ts` maps
the model id → per-model settings via regex:

- **Kimi K2.x** → 256K context, thinking-mode aware, native tool-call
  parser, terseness reminder
- **Claude Opus 4.7+** → temperature omitted (deprecated by API)
- **Qwen 3 Coder** → 32K context (gateway-capped), inline-XML tool
  format, arg-format reminder
- **Gemma 4** → completions-fallback hint (bare OATI gateway)
- **gpt-oss** → 128K context, openai-tools format
- **DeepSeek** → 128K context, arg-format reminder

The quirks are HINTS. The endpoint capability probe (see below) can
override them at runtime based on what the actual gateway accepts.

## API keys — where they're stored

Never in chat. Never in `IOM.md`. Never in `.iom/` files. Only in
**VS Code's SecretStorage** (OS keychain — Windows Credential Manager
on Windows, Keychain on macOS, libsecret on Linux). Managed by the
`SettingsStore` via `vscode.SecretStorage`.

To rotate a key: Settings → API Configuration → <provider> → paste
new value in the API Key field → save. Old value is overwritten in
SecretStorage.

## Workspace-level config (`.iom/`)

Per-workspace files that OATICode reads (if present):

| File | Purpose |
|---|---|
| `IOM.md` at workspace root | Project memory — always injected into system prompt |
| `.iom/policy.yaml` | Per-workspace tighter budget limits (never wider) |
| `.iom/skills/*.md` | User-defined skills with YAML frontmatter |
| `.iom/hooks.yaml` | Lifecycle hooks (PreToolUse, PostToolUse, etc.) |
| `.iom/slash-commands/*.md` | User-defined slash commands with frontmatter |
| `.iom/mcp-servers.yaml` | MCP servers to auto-connect |
| `.iom/facts.json` | Auto-promoted project facts (from `remember_fact` tool) |
| `.iom/budget-day-YYYYMMDD.json` | Daily-budget tracking |
| `.iom/audit.log` | Append-only audit log |

Everything under `.iom/` is optional. The extension works fine
without any of it.
