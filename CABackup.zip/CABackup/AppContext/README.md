# AppContext — Session Narrative for OATICode

This folder captures everything of substance from the multi-day
Claude Code session that produced the OATICode extension currently
sitting in the paired `repo/` and `artifacts/` folders. It's meant
to be a **portable memory** — someone (a teammate, a fresh Claude
session on a different machine, or you six months from now) can read
this and pick up where things left off without having to reconstruct
the reasoning.

## What's in here

| File | Read when |
|---|---|
| **README.md** (this file) | Orientation. Start here. |
| **SESSION-SUMMARY.md** | You want the 30-second overview of what got built |
| **COMMITS.md** | You want the git log with narrative context per commit |
| **FEATURES-ADDED.md** | You want a punch-list of every capability added |
| **CONFIGURATION.md** | You're setting up OATICode against a Kimi K2.7 / OATI LLM / Anthropic / OpenRouter gateway |
| **GATEWAY-NOTES.md** | You hit a 405 / VPN / firewall issue with the K2.7 gateway. All the diagnostics we ran are here. |
| **INSTALL-INSTRUCTIONS.md** | You're installing on a fresh machine from the `artifacts/oati-code.vsix` |
| **KNOWN-ISSUES.md** | Something isn't working the way you expected — check here before assuming it's a bug |
| **TROUBLESHOOTING.md** | Common errors + their causes + fixes |

## The one-paragraph summary

OATICode (technically identified as `iom.oati-code` in the marketplace)
is a VS Code extension providing a configurable agentic coding
assistant. It's built clean-room from scratch, licensed MIT, and lives
in a TypeScript monorepo at `E:\AI\Self\OATICodingAssistantReal`. The
user-visible product name is **OATI Code** (with a space); the
technical identity (extension name, publisher, npm packages, workspace
folder) is `iom` / `iomcode` / `oati-code` / `.iom/` / `@iom/*` / `IOM.md`.
The default display name is overridable per-workspace via
Settings → Branding.

## Architecture at a glance

```
packages/
├── shared/          Types, config, RPC messages, model-quirks registry
├── agent-core/      Pure agent loop (no VS Code deps) — planner/executor/critic,
│                    tool registry, context-shrink, load-monitor, jit-tools,
│                    wire-audit
├── agent-service/   Headless agent service (for CLI / VS extensions)
├── providers/       OpenAI-compatible + Anthropic native + Ollama +
│                    endpoint-probe + concurrency-limiter
├── tools/           60+ built-in tools (read_file, write_file, exec,
│                    ask_user, ask_user_batch, load_skill, etc.)
├── mcp-client/      Model Context Protocol client
├── codebase-index/  Semantic + lexical + RRF-merged code search
├── rpc/             Typed webview ↔ host messaging
├── webview-ui/      Preact chat UI, settings panel, todo panel, ask_user
│                    prompts, ask_user_batch card
├── extension-host/  VS Code extension entry, panel management, provider
│                    manager, session storage, wire-audit recorder
└── bench/           Task-suite for measured pass-rate + SWE-bench ingester
```

## Where the interesting features live

- **Aggressive context budget** (60-80% wire-body shrink) →
  `packages/agent-core/src/context-shrink.ts` +
  `packages/agent-core/src/read-dedup.ts` +
  `packages/agent-core/src/jit-tools.ts`

- **Adaptive load-aware auto-switching** →
  `packages/agent-core/src/load-monitor.ts` (TTFT + generation TPS
  baselines) consulted by `Conductor.spawn()` in `conductor.ts`

- **Endpoint capability probe** (auto-detects `/v1/chat/completions`
  vs `/v1/completions` fallback) →
  `packages/providers/src/endpoint-probe.ts` +
  `packages/extension-host/src/endpoint-capability.ts`

- **Per-provider concurrency cap** (FIFO client-side queue) →
  `packages/providers/src/concurrency-limiter.ts`

- **`/wire-audit` slash command** → measures per-turn token
  breakdown → `packages/agent-core/src/wire-audit.ts`

- **`ask_user_batch` tool** → paginated clarifying-question card →
  `packages/tools/src/ask-user-batch.ts` +
  `packages/webview-ui/src/components/ask-user-batch-card.tsx`

- **Configurable branding** (users override displayName) →
  `packages/shared/src/config.ts` (`BrandingConfig`,
  `resolveDisplayName`) + Settings → Branding tab

## How this backup was assembled

- Fresh copy of the source tree at commit `3e16b9c` (single-O icon)
- All build outputs excluded (`node_modules`, `dist`, `.git`, `bin`, `obj`)
- Latest built VSIX in `artifacts/` with sha256
- Narrative context in this folder (self-contained; doesn't refer to
  external files you might not have)

To restore + build on another machine: read `INSTALL-INSTRUCTIONS.md`.
