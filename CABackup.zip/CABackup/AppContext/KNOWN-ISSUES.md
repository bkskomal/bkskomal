# Known Issues

Things that don't quite work the way you might expect, with the
workaround if any. Check here before assuming something is a bug.

## Adaptive-mode thresholds are estimates, not measured

The `LoadMonitor` uses TTFT × 3 and TPS ÷ 2 as degradation
thresholds. These are reasonable defaults but haven't been calibrated
against real K2.7 traffic yet. If adaptive mode is over- or
under-triggering:

- **Over-triggering** (flipping to aggressive too eagerly) → raise
  `ttfMultiplier` (default 3.0) or lower `tpsMultiplier` (default 0.5)
  in `packages/agent-core/src/load-monitor.ts`
- **Under-triggering** (staying normal when the gateway is slow) →
  inverse

Once you have a week of `/wire-audit` data, tune to real numbers.

## `/wire-audit` output can be misleading on the first few turns

The `WireAuditRecorder` ring buffer holds the last 8 snapshots. If
you invoke `/wire-audit` after only 2-3 turns, the "average per-request"
number is skewed by the small sample. Wait for at least 5 turns of
real work before drawing conclusions.

## VS Code metadata can't be rebranded at runtime

Even with Settings → Branding → Display name = "MyBot", these still
show the built-in name ("OATI Code"):

- Extensions view (uninstall / details dialog)
- Activity-bar icon tooltip on hover
- Marketplace listing
- Command palette prefix ("OATI Code: Open Chat")
- Output channel name

Only the chat panel tab title, welcome screen hero, welcome tagline,
and any programmatically-rendered brand strings honor the setting.
This is a VS Code architectural constraint — extension metadata is
baked in at package time.

To customize the baked-in strings for a team install, you'd need to
rebuild the VSIX with modified `packages/extension-host/package.json`.

## JIT tool schema retry uses regex heuristics

`extractUnknownToolNames` in `agent.ts` matches provider error strings
against known tool names via regex. If a provider uses novel error
phrasing (e.g. "the tool 'X' does not exist in the current session"),
the regex might miss it and we won't auto-promote. Add the tool name
to your mode's `contextBudget.forceIncludeTools` if this bites you
(actually — that setting doesn't exist yet; it'd need to be added).

Current regex pattern: `/unknown|undefined|not found|not defined|invalid tool/i`.

## Read-dedup won't dedup across separate `read_file` variants

`dedupDuplicateReads` looks for tools matching
`["read_file", "read_lines", "readfile", "read"]`. If you (or another
extension) adds a custom read-tool with a different name, it won't
be considered for dedup. Pass a custom `readToolNames` array to
`dedupDuplicateReads()` if this matters — but that requires source
edits, not a config setting.

## MCP server auth (claude.ai connectors) can't be done from a
   non-interactive session

Three claude.ai MCP servers (Canva, Gmail, Google Drive) require
OAuth. If they show as "needs authentication", authorize via your
**claude.ai connector settings** (not from within OATICode). This
is a limitation of the interaction model, not a bug.

## First message after a provider config change may take extra ~500ms

The endpoint capability probe runs on the first request per
(providerId, modelId, baseUrl) tuple. Result is cached in
`vscode.Memento` for 24 hours. Subsequent requests skip the probe.

Editing the provider config in Settings triggers `ProviderManager.rebuild()`
which invalidates the probe cache — so a Settings edit costs one
extra probe on the next message.

## Gateway routing issues aren't OATICode's fault

If messages fail on the gateway URL (`gry5qaapps3:7300` or
`genieappn10:7300`) but work on the direct URL (`genieappn10:8080`),
the gateway has a routing/firewall issue that OATICode can't fix
client-side. See `GATEWAY-NOTES.md` for the full diagnosis and three
possible fixes.

## Old extension installs may linger

VS Code identifies extensions by `publisher.name`. This project's
identifier moved twice this session:
- `oati.oati-coding-assistant` (long-stale, pre-rebrand)
- `iom.iom-coding-assistant` (rebrand)
- `iom.iomcode` (after b7df622)
- `iom.oati-code` (current, after 7a11b06)

Each is treated as a SEPARATE extension by VS Code. Installing the
new one doesn't auto-remove the older ones. Uninstall each manually
(safe to run against non-existent ones — errors are just noise):

```powershell
code --uninstall-extension oati.oati-coding-assistant
code --uninstall-extension iom.iom-coding-assistant
code --uninstall-extension iom.iomcode
code --uninstall-extension iom.oati-code
code --install-extension "path\to\oati-code.vsix" --force
```

## Concurrency queue chip isn't fully wired everywhere

The chip appears when the client-side concurrency limiter queues a
request. It works fine for the main chat panel path, but sub-agent
spawns going through a different code path (composer, inline-edit)
may queue without surfacing the chip. Bug — not a security issue,
just missing UX polish.

## VSIX cannot be shipped to Open VSX without changes

`scripts/publish-openvsx.mjs` references `ovsx create-namespace iom`
which requires an OVSX PAT (personal access token). Not set up in
this repo. If you want to publish to Open VSX for wider distribution,
create the namespace and configure the token first. See the
top-of-file comment in `publish-openvsx.mjs` for details.

## `.iom/` workspace folder migration

If you're upgrading from an old install that used `.oati/` for
workspace data (skills, hooks, MCP servers), those files won't
auto-migrate. Manual steps:

```powershell
# In your workspace root
if (Test-Path .oati) {
    Rename-Item .oati .iom
}
# Rename OATI.md → IOM.md if present
if (Test-Path OATI.md) {
    Rename-Item OATI.md IOM.md
}
```

## `--force` install can leave the extension in a weird state

Rare, but possible: `code --install-extension --force` sometimes
leaves a stale extension in the ".obsolete" state. Fix:

```powershell
# Close VS Code first, then:
$obsolete = Join-Path $env:USERPROFILE ".vscode\extensions\.obsolete"
if (Test-Path $obsolete) {
    Get-Content $obsolete | Write-Output "  will be removed on next VS Code start"
    # VS Code cleans these up automatically on next start
}
```
