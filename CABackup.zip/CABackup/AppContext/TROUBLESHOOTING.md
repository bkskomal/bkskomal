# Troubleshooting

Quick-reference for common errors. If your issue isn't here, check
`KNOWN-ISSUES.md` for design-level limitations, or `GATEWAY-NOTES.md`
for gateway-specific problems.

## Extension symptoms

### "OATI Code" still showing when I expected a rebrand

You have an old copy still installed. VS Code side-by-sides different
extension identifiers as separate installs. Nuke all prior copies:

```powershell
code --uninstall-extension oati.oati-coding-assistant
code --uninstall-extension iom.iom-coding-assistant
code --uninstall-extension iom.iomcode
code --uninstall-extension iom.oati-code
code --install-extension "path\to\oati-code.vsix" --force
```

Then Ctrl+Shift+P → Developer: Reload Window.

### Chat panel is blank after install

Usually a webview-dist packaging issue that was fixed in ef4294e via
`packages/extension-host/scripts/copy-webview-dist.mjs`. Verify the
VSIX you installed has webview assets:

```powershell
Expand-Archive -Path "path\to\oati-code.vsix" -DestinationPath "$env:TEMP\vsix-check" -Force
Get-ChildItem "$env:TEMP\vsix-check\extension\dist\webview" -Recurse | Measure-Object
# Should show 6+ files
```

If dist/webview/ is empty in the VSIX, rebuild from source
(`INSTALL-INSTRUCTIONS.md` Path B).

### Activity-bar icon doesn't appear

Check the Extensions view (Ctrl+Shift+X). If OATI Code shows as
"Disabled", click Enable. If not present at all, the install failed
silently — try Path A step 3-4 again.

### Extension activates but produces no output

Check the Output panel (View → Output → dropdown = "OATI Code").
Error messages there are usually more descriptive than the generic
"agent error" toast.

## Provider / gateway symptoms

### "HTTP 405 Method Not Allowed" on every message

Gateway blocks POST to `/v1/chat/completions`. Full diagnosis in
`GATEWAY-NOTES.md`. TL;DR:
1. Confirm direct URL works — `curl -X POST <direct>/v1/chat/completions ...`
2. If direct works, point OATICode at the direct URL
3. If direct doesn't work either, escalate to gateway ops team

### "HTTP 401 Unauthorized"

API key is wrong or expired. Settings → API Configuration → your
provider → paste new key. Rotate the old one on the model server admin
panel if it was compromised.

### "HTTP 404 Not Found" on the base URL

The Base URL is missing `/v1` (or the path segment your gateway
expects). Common shapes:

| Gateway | Base URL |
|---|---|
| Bare vLLM | `http://host:port/v1` |
| OpenAI | `https://api.openai.com/v1` |
| OpenRouter | `https://openrouter.ai/api/v1` |
| Anthropic native | `https://api.anthropic.com` (no `/v1`) |
| OATI Genie | `https://llm.dev.genie.oati.com/oatigenie/gpt_oss/v1` |

### "HTTP 429 Too Many Requests"

You hit the provider's rate limit. Two mitigations:
1. Set `maxConcurrentRequests` to a lower number in the provider
   config (Settings → API Configuration → <provider>)
2. Turn on adaptive context budget so aggressive mode kicks in
   during pileups

### Model returns empty / hangs on tool calls

Common with older or reasoning-only models. Try:
1. Set contextBudget to Normal (aggressive-mode auto-compact at 25%
   can occasionally over-shrink important context on small models)
2. Check if the model has native tool-call support — some models
   (Gemma 3, small variants) can't tool-call at all and need to
   route through `inline-xml` format (auto-detected via
   `model-quirks.ts` but not perfect)
3. Use `/wire-audit` to inspect what was sent

### Test Connection passes but messages fail

Two different endpoints. Test Connection hits GET `/v1/models`;
messages hit POST `/v1/chat/completions`. A gateway may allow one
and not the other. See `GATEWAY-NOTES.md`.

## Network / VPN symptoms

### `Test-NetConnection` hangs ~20 seconds

Firewall silently dropping packets. If port 8080 succeeds fast on
the same host but 7300 hangs, that's a per-port firewall rule.
`GATEWAY-NOTES.md` has the full playbook.

### `TcpTestSucceeded : False` in <1 second

Fast refuse. Either nothing listening on that port, or service bound
to `127.0.0.1` only (localhost). On the server:

```powershell
netstat -an | findstr ":<port>"
```

- `0.0.0.0:<port>` or `[::]:<port>` → listening on all interfaces
- `127.0.0.1:<port>` → localhost only; rebind service to `0.0.0.0`
- Empty → service not running

### GlobalProtect app is running but VPN doesn't work

Check for the virtual adapter:

```powershell
Get-NetAdapter | Where-Object { $_.Name -match "PANGP" }
```

- Adapter exists AND Status = "Up" → VPN is truly connected
- Empty result → app is running but tunnel is NOT up

If the tunnel is down: right-click GP tray icon → Show Panel →
Connect. Or use the `_gp_login` PA skill.

## Test / build symptoms (development-time)

### `npm install` fails with "windows-specific optional dependency"

Cross-platform optional binaries; safe to ignore. `npm install --no-optional`
usually works. If a specific dep is required (like `screenshot-desktop`),
install it manually.

### `node-gyp` errors during npm install

Native build tooling missing. On Windows: install Visual Studio Build
Tools 2022 + Python 3. On Linux: `apt install build-essential python3`.
On macOS: `xcode-select --install`.

### Husky pre-commit hook fails

`.husky/install.sh` didn't run. `npx husky install` then retry.

### Biome lint errors during commit

Biome is the linter. To auto-fix:

```powershell
npx biome check --write
```

If a specific error is marked "unsafe", the auto-fix might change
semantics — read the suggestion carefully before applying with
`--write --unsafe`.

### Tests hang on `packages/extension-host/tests/background-processes.test.ts`

That test does real process spawns and takes ~6 seconds. If it hangs
longer, check for stuck child processes:

```powershell
Get-Process | Where-Object { $_.StartTime -gt (Get-Date).AddMinutes(-5) -and $_.ProcessName -match "node|iom|test" }
```

Kill any zombies with `Stop-Process`.

### Typecheck error "Cannot find module '@iom/shared'"

You skipped `npm install` or workspaces aren't linked. Run:

```powershell
npm install
```

At the repo root. Should auto-symlink `@iom/*` packages.

## Session-recovery symptoms

### Old session has "wrapped-args" corruption

Model previously sent double-escaped tool args. Session storage may
have the corrupt entries. Fix in ef4294e via `history-sanitizer`.
Load an old session and if the model returns empty:

- Click **+ New Session** in the sidebar (safest — start fresh)
- OR type `/compact` in the chat (attempts to summarize the middle
  and discard corrupt turns)

### `.iom/audit.log` has grown huge

Append-only log; safe to truncate at any time. Just delete it:

```powershell
Remove-Item .iom\audit.log -Force
```

The extension will recreate it on next write.
