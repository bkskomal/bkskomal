# OATICodingAssistant — engineering notes for future Claude / contributors

This file is the orientation document for anyone (or any AI assistant) joining this codebase. Read it first before exploring or making changes.

## What this project is

A configurable, modular, agentic coding assistant. Ships as:

- A **VS Code / Antigravity extension** (primary IDE shell)
- A **standalone HTTP+SSE service** that wraps the same agent core
- A **Visual Studio (Microsoft IDE) skeleton** that talks to the service
- (Future) JetBrains and CLI shells over the same service

**Clean-room build.** No code copied from Cline / Continue / any other project. The Cline source tree at `E:\AI\Self\OATICodingAssistant\` (a sibling directory) is reference reading only — never copy from it.

## Architecture in one paragraph

`agent-core` is pure TypeScript with **zero IDE dependencies**. It owns the Agent loop, the Conductor (multi-agent coordinator), and the registries for tools and providers. Every IDE shell is a thin layer that constructs a `HostContext` (fs, exec, approval, diff), registers tools and providers, instantiates a Conductor, and bridges its UI to agent events. The same Conductor can be wrapped as an HTTP+SSE service (`@iom/agent-service`) so non-Node IDEs can consume it.

## Repository layout

```
OATICodingAssistantReal/
├── packages/                          (npm workspaces)
│   ├── shared/                        Types + presets + ui-message converter.
│   │                                  ZERO runtime code aside from preset data.
│   ├── rpc/                           Typed Bus<In, Out> for host ↔ webview.
│   ├── agent-core/                    Agent, Conductor, ToolRegistry, ProviderRegistry,
│   │                                  stages.ts (planner/critic). ZERO VS Code deps.
│   ├── providers/                     openai-compatible + anthropic native + factory.
│   ├── tools/                         read_file, write_file (with diff-preview),
│   │                                  exec, spawn_agent, list_dir, grep_search,
│   │                                  fetch_url. Each is a single-file plugin.
│   ├── mcp-client/                    Model Context Protocol client (stdio +
│   │                                  JSON-RPC) and helper to register MCP tools.
│   ├── webview-ui/                    Preact + signals chat UI. Markdown rendering,
│   │                                  inline diff in approvals, MCP/provider/mode UI.
│   ├── extension-host/                The VS Code shell: ChatPanel, SettingsStore,
│   │                                  SessionStore, ProviderManager, McpManager,
│   │                                  diff-provider, host-context.
│   └── agent-service/                 Standalone HTTP+SSE wrapper around agent-core.
│                                      Powers the Visual Studio path and any future
│                                      non-Node shell.
└── ide/
    └── visual-studio/                 C# VSIX skeleton. WebView2 hosts the chat UI,
                                       OatiServiceClient streams events from agent-service.
```

## Architectural rules — hold the line on these

1. **`agent-core` has zero IDE imports.** Verified by typecheck. If you're tempted to `import * as vscode` in agent-core, you're solving the wrong problem.
2. **`webview-ui` only talks to host via `@iom/rpc`.** No direct file system, no direct provider calls, no fetch. This is what makes the security model auditable.
3. **`shared/` is types-only** with the single exception of preset data and the conversation→UiMessage converter. No business logic.
4. **Tools are single-file plugins** in `packages/tools/src/*.ts`. To add one: write the file, add it to `registry.ts`. No central switch statement to edit. `ToolSpec` carries an optional `prepareApprovalPreview` for richer approval dialogs (see `write-file.ts`).
5. **Providers are single-file plugins** in `packages/providers/src/*.ts`, dispatched through `factory.ts` by `ProviderType`. Add a new type by extending the union in `shared/config.ts` and the switch in `factory.ts`.
6. **Every feature is configurable on/off.** Planner stage, critic stage, parallel agents, MCP servers — all gated by config flags. Defaults err on the side of off / safe.
7. **API keys live in VS Code SecretStorage** (`extension-host/settings-store.ts`). The webview never sees raw key values — only `hasApiKey: boolean` flags.
8. **Approval policy on tools:** `auto` (silent), `prompt` (asks user), `deny` (always refuse). Set per-tool.

## Where the differentiation lives

The OSS reference (Cline) gives us a working agent shell. Our differentiation:

- **Configurable agent loop** with optional planner/critic stages (light v1 in `agent-core/stages.ts` — system-prompt injection).
- **Parallel agents** via `spawn_agent` tool + `Conductor.maxParallelAgents`. Sub-agents have their own loop and history, parent gets the final summary.
- **Multi-provider with rich presets** (OpenAI, OpenRouter, Anthropic native, LiteLLM, unillm, Ollama, OpenAI-compatible, custom). Presets carry `providerType` so switching them drives the right adapter.
- **Inline approval diff** AND native VS Code diff editor — both fire on `write_file`.
- **MCP support** with a UI for configuring servers.
- **Service boundary** so the same agent runs in VS Code, Visual Studio, and any future IDE shell.

## Stack

- TypeScript 5.7 strict, ESM source, `moduleResolution: "bundler"`.
- esbuild for bundles (extension-host, webview-ui, agent-service). No webpack/rollup.
- Biome for lint + format (tabs, double quotes, semis, 100-col).
- Preact 10 + `@preact/signals` for the webview UI. snarkdown for markdown rendering. ~70 KB total UI bundle.
- Native `fetch` (Node 22) for all HTTP. No axios.
- `npm workspaces`. Not pnpm — fewer moving parts.

## Build / run

```powershell
npm install
npm run build           # builds all workspaces
npm run typecheck       # tsc --noEmit per workspace
npx biome check .       # lint + format check
npx biome check --write .  # auto-fix
```

To run the VS Code extension: open the repo in VS Code, press **F5**. Then in the extension-dev host, **iOmCode: Open Chat**, configure a provider in Settings (⚙), send a message.

To run the standalone service:
```powershell
npm run build --workspace=@iom/agent-service
$env:OATI_WORKSPACE_ROOT="E:\some\project"
node packages\agent-service\dist\cli.js
```

## When making changes

- **Update typecheck + biome before declaring done.** They run in seconds.
- **Add to `tools/registry.ts`** when introducing a new built-in tool — otherwise it won't load.
- **Update presets in `shared/presets.ts`** when adding a new provider type — the SettingsPanel reads from there to populate the dropdown.
- **Don't put runtime code in `shared/`** unless it's pure data (presets) or a stateless conversion function (ui-message). If it has side effects, it belongs in a runtime package.
- **Settings UI changes go through `SettingsUpdate`** (in `shared/messages.ts`). Add the field, update `SettingsStore.updateConfig`, then surface it in `SettingsPanel`.
- **Visual Studio code is not built by `npm run build`** — it's pure C# under `ide/visual-studio/`. Open the `.csproj` in Visual Studio 2022 with the VS extension workload.

## What's intentionally NOT here yet

- Real markdown sanitization (relies on CSP — fine for the model output context, not enough if untrusted HTML is ever embedded).
- Token / cost tracking.
- Session export/import.
- Workspace context auto-injection (file tree, current file).
- True planner/executor/critic pipeline with separate model calls (current planner/critic is system-prompt injection only).
- Test suite. Zero unit/integration tests at the moment.
- VSIX publication / marketplace metadata polish.
- Visual Studio extension: actually embeds the webview-ui bundle (currently shows a placeholder).
