# Changelog

All notable changes to iOmCode are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] — 2026-05-21

Initial preview release. Full feature set assembled across rounds R1–R6, hardened in R7.

### Agentic loop

- Configurable per-mode agent loop with optional **planner** and **critic** stages (system-prompt injection, toggleable per mode).
- Five built-in modes (Ask, Plan, Code, Auto Edit, Auto) with independent tool surfaces, iteration limits, and approval policies.
- **Plan v2** — structured plans with steps, exit criteria, and abort signals via `propose_plan`.
- **Parallel sub-agents** via `spawn_agent` (single) and `spawn_parallel_agents` (fan-out); up to 8 concurrent in Auto.
- **Test-driven loop** — Auto modes rerun the workspace test suite and self-correct on regression.
- **Auto-revert safety net** — rolls back file writes when post-turn tests newly fail (opt-in, `iom.autoRevert.enabled`).
- **History compaction** — `/compact` trims middle history to stay focused under the token budget.
- **Memory consolidation** — `/consolidate-memory` promotes lessons from old sessions to `.iom/facts.json`.

### Providers

- **OpenAI-compatible provider** — works for OpenAI direct, OpenRouter, LiteLLM, unillm, Ollama, LM Studio, any OpenAI-shaped gateway.
- **Anthropic native provider** — full `/v1/messages` SSE parsing with `x-api-key` + `anthropic-version`.
- **Ollama** preset ships pre-configured for `http://localhost:11434/v1`.
- 8 ready-to-use **presets** (OpenAI Compatible, OpenAI, OpenRouter, LiteLLM, unillm, Ollama, Anthropic, Custom).
- Per-provider Base URL, model id, and extra headers; **API keys stored in SecretStorage (VS Code) / DPAPI (Visual Studio)**.
- **Multi-model routing** (R3-B) — classify upcoming turns and route to different providers/models by difficulty.
- **Per-model budgets** — daily / monthly USD caps per `(provider, model)` pair.

### Built-in tools (58 total)

- **Reading & navigation**: `read_file`, `list_dir`, `get_workspace_context`, `read_shared_notes`, `read_notebook`, `read_notebook_cell`.
- **Writing & editing**: `write_file` (with diff approval), `smart_apply_patch` (three-way merge).
- **Shell & background**: `exec`, `run_tests`, `start_background_task`.
- **Network**: `fetch_url` (SSRF-protected), `web_search` (DuckDuckGo HTML, no key).
- **Search**: `grep_search` (ripgrep when available), `code_semantic_search` (embeddings → TF-IDF fallback).
- **Symbol intelligence**: `find_definition`, `find_references`, `symbols_in_file` (LSP-backed).
- **Diagnostics**: `get_diagnostics`.
- **Git & GitHub**: `git_status`, `git_diff`, `git_commit`, `git_open_pr`, `gh_issue_read`, `gh_issue_comment`, `suggest_commit_message`.
- **Browser**: `browser_open`, `browser_navigate`, `browser_screenshot`, `browser_eval`, `browser_close`.
- **Debug bridge**: `debug_stack_frames`, `debug_evaluate`, `debug_scopes`, `debug_variables`, `debug_set_breakpoint`, `debug_remove_breakpoint`, `debug_list_breakpoints`.
- **Notebooks**: `edit_notebook_cell`, `insert_notebook_cell`, `delete_notebook_cell`, `run_notebook_cell`.
- **Sub-agents**: `spawn_agent`, `spawn_parallel_agents`.
- **Memory & facts**: `remember_fact`, `recall_facts`, `consolidate_memory`.
- **Scratchpad**: `write_shared_note`, `read_shared_notes`.
- **Snippets**: `save_snippet`, `list_snippets`.
- **Knowledge RAG**: `list_knowledge`, `search_knowledge`.
- **Conversation search**: `search_conversations`.
- **Personas & recipes**: `set_persona`, `run_recipe`.
- **Plan v2**: `propose_plan`.
- **Diagrams**: `render_diagram` (Mermaid).
- **Telemetry**: `inline_completion_stats`.

Per-tool **approval policy** (`auto` / `prompt` / `deny`). Inline +/- diff in the approval dialog plus native VS Code diff editor for `write_file`.

### MCP

- Full **Model Context Protocol** client (stdio JSON-RPC transport, `tools/list` + `tools/call`, capability negotiation).
- **Curated marketplace** with 10 vetted servers: Filesystem, Git, GitHub, Brave Search, Puppeteer, SQLite, Postgres, Slack, Memory, Time.
- One-click install (disabled by default), per-server approval policy, env-var prompts for secret-dependent servers.
- Tool merging: MCP tools show up alongside built-ins with the configured server's approval policy.

### Slash commands (17 built-in + custom)

`/new`, `/clear`, `/settings`, `/attach`, `/split`, `/rename`, `/cost`, `/compact`, `/reindex`, `/stop`, `/share`, `/help`, `/composer`, `/from-issue`, `/compare`, `/review-pr`, `/marketplace`, `/perf`, `/save`, `/snippets`, `/init`, `/knowledge`, `/search`, `/diagram`, `/persona`, `/personas`, `/recipe`, `/recipes`, `/diff`. Custom commands via `<workspace>/.iom/commands/<name>.md`.

### Personas (6 built-in)

`junior-dev`, `senior-reviewer`, `security-auditor`, `perf-optimizer`, `doc-writer`, `refactorer`. System-prompt addenda; switch mid-task without changing mode.

### Recipes

- Multi-step workflows in `<workspace>/.iom/recipes/<name>.md` (YAML front-matter + free-form context).
- Sequenced as back-to-back conductor spawns with conversation continuity between steps.

### Project templates (5 built-in)

`react-ts`, `node-cli`, `fastapi`, `express-api`, `rust-cli`. Apply with `/init <name>`.

### Codebase intelligence

- **Tree-sitter chunker** for TypeScript, JavaScript, Python, Go, Rust, Java, C/C++, C#.
- **Semantic-search index** in `<workspace>/.iom/code-index.sqlite` (embeddings or TF-IDF).
- **Knowledge RAG** in `<workspace>/.iom/knowledge.sqlite` over `.iom/knowledge/**/*.md`.
- **Symbol-aware retrieval** via the editor's LSP.
- **Cross-session conversation search** (`/search`, `search_conversations` tool).

### Chat experience

- Markdown rendering for assistant messages (code blocks, lists, links, blockquotes), CSP-safe.
- Streaming token-by-token with a blinking cursor.
- **Session persistence** per workspace; **Export / Import** to portable JSON; **Markdown export** via `/share`.
- **Conversation branching** — fork any turn into a new session.
- **Side-by-side compare** (`/compare`) — two providers/models in parallel.
- **Multi-file composer** (`/composer`) — generate N files at once with a unified diff overlay.
- **Inline diff review** — Accept / Reject / Modify code lenses for per-hunk gating.
- **Token + USD cost** badge with per-model rate lookup.

### Settings UI

- Multi-provider editing with Add / Delete / Make Active.
- Agent behavior section (planner, critic, max parallel agents, max iterations, retries, temperature).
- MCP servers section with custom add, preset dropdown, and marketplace browser.
- Test Connection button hits `/models` on the configured provider.
- Hook configuration (`PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `SessionStart`, `Stop`) with matcher + timeout + blocking flags.

### Inline & predictive completion

- **Inline completion** — Copilot-style ghost text, debounced (200 ms default), language-scoped.
- **Hover explain** — 2-sentence model explanation on function hover (cached 30 min).
- **Predictive next-edit** (experimental) — ghost-text predictions after you pause.
- **Inline edit** — `Ctrl+K Ctrl+I` opens an inline edit prompt against the current selection.

### Safety, audit, policy

- **Secret scanner** — AWS / GitHub / OpenAI / Anthropic / Slack / JWT / PEM patterns redacted on outbound dispatch.
- **Audit log** — append-only `.iom/audit.log` for tool calls, messages, and inline-completion telemetry.
- **Budget caps** — per-session alert / hard cap, per-day cap, per-(provider, model) daily/monthly caps.
- **Workspace policy** (`.iom/policy.yaml`) — provider / model / tool / mode allow-deny lists. Tightens, never widens.
- **Hooks** — user-defined commands invoked at lifecycle events; can block PreToolUse / UserPromptSubmit.
- **Auto-revert** — rolls back writes when post-turn tests regress.

### Performance HUD

- **`/perf`** — recent-turn latency, slow-tool heatmap, per-provider P50/P90.
- Cost badge + per-model token usage in the header.
- Bundle-size budgets enforced in CI (`scripts/check-bundle-size.mjs`).

### Visual Studio extension

- C# VSIX hosting the same Preact webview in a WebView2 control.
- `OatiSettingsStore` mirrors the VS Code SettingsStore with **DPAPI-encrypted** secret storage.
- `OatiRpcBridge` handles every `WebviewToHost` message type and round-trips agent events from `@iom/agent-service`.
- MSBuild target auto-bundles `webview-ui` on rebuild.

### Standalone service

- `@iom/agent-service` — Node HTTP+SSE server wrapping the agent core.
- Endpoints: `GET /v1/health`, `GET /v1/tools`, `POST /v1/agent/run` (SSE stream).
- Bearer-token auth via `OATI_SERVICE_TOKEN`.
- Workspace root pinned via `OATI_WORKSPACE_ROOT`.

### Engineering

- 9 TypeScript workspaces, 1 C# project, monorepo via npm workspaces.
- **798 tests** across **84 files** (vitest).
- Strict TypeScript, Biome for lint + format.
- Build with esbuild; bundle sizes verified per release.
- Auto-generated tools reference (`scripts/gen-tools-doc.mjs` → `docs/TOOLS.md`).

### Docs (R7)

- Polished marketplace-ready README, CHANGELOG, and a `docs/` set covering configuration, tools, personas, recipes, MCP, policy, security, and architecture.
- Auto-generator for `docs/TOOLS.md` so the catalog stays in sync with `registry.ts`.

[0.1.0]: https://github.com/sbkkomal/codeassistant/releases/tag/v0.1.0
