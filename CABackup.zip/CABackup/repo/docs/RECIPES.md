# Recipes

Recipes are saved multi-step workflows that drive the agent through a sequence of related user turns. Stored as YAML-front-matter markdown under `<workspace>/.iom/recipes/<name>.md`, they're versionable, human-editable, and live alongside the codebase.

Run a recipe with `/recipe <name>`. List the catalog with `/recipes`. The `run_recipe` tool exposes the same flow to the agent itself, so a planning step can chain into a recipe.

## File format

```markdown
---
name: ship-feature
description: Implement, test, commit, open PR
steps:
  - "Generate implementation based on the user's brief"
  - "Run the test suite with run_tests"
  - "If green: stage, commit with suggest_commit_message, push, and open a PR with git_open_pr"
---

# Optional free-form context

Any markdown below the front-matter is passed to the model on every step. Use this for:

- Conventions specific to this workflow (e.g. "always update CHANGELOG.md alongside src/")
- Lists of files or directories the agent should NOT touch
- Templated boilerplate to inject (PR body templates, commit-message conventions)
```

### Front-matter schema

| Field | Required | Type | Meaning |
|---|---|---|---|
| `name` | ✓ | string | Must equal the filename without `.md`. Letters, digits, `_`, `-` only. |
| `description` | ✓ | string | One-line description shown in `/recipes` and the picker. |
| `steps` | ✓ | string[] | Ordered list of step prompts. Each step is dispatched as a fresh user turn. |

The free-form body below the front-matter is appended to every step as a "context block" so the model has continuity without re-reading the recipe file.

## How execution works

`runRecipe` sequences the steps as N back-to-back conductor spawns:

1. **Step 1** runs as a normal user turn with the step prompt + free-form context.
2. **Step 2** is dispatched with the prior step's full conversation history pre-loaded, so the model has memory.
3. Each step goes through the existing instrumentation pipeline (audit log, perf collector, secret scanner, hooks).
4. If any step fails (tool error, abort, budget cap), the recipe stops and the user is notified.

This is why steps work better as *task descriptions* than as raw tool calls — the agent will pick the right tool for each step.

## Slug rules

- Filename must match `^[a-zA-Z0-9_-]+$` — no spaces, no dots, no slashes.
- The `name` field in front-matter must equal the filename minus `.md`.
- Recipes with invalid front-matter are skipped silently in `/recipes` so a single broken recipe can't take down the picker.

## Example recipes

### `ship-feature.md`

```markdown
---
name: ship-feature
description: Implement → test → commit → PR
steps:
  - "Read the user's feature brief and outline the changes you'll make."
  - "Implement the changes. Update tests and docs as you go."
  - "Run `run_tests`. If anything fails, fix it before continuing."
  - "Stage changes with `git_status` + `git_diff`, generate a commit message with `suggest_commit_message`, and commit."
  - "Push the branch and open a PR with `git_open_pr`. Use the PR body template below."
---

# PR body template

## Summary
<one-liner>

## Changes
- <bullet list>

## Test plan
- [ ] Local tests pass
- [ ] Manual smoke test of <X>
```

### `triage-bug.md`

```markdown
---
name: triage-bug
description: Investigate a bug report; produce a findings doc
steps:
  - "Read the user's bug description and the relevant files. Use code_semantic_search if you're not sure where to start."
  - "Reproduce the bug locally if possible (use exec / run_tests)."
  - "Identify the root cause. List two possible fixes with tradeoffs — DO NOT write code yet."
  - "Write your findings to `docs/triage/<short-name>.md` using write_file."
---

# Output format for the findings doc

- **Summary**: 1-2 sentence statement of the bug
- **Reproduction**: minimal steps
- **Root cause**: file + line + why
- **Fix options**: at least two, with tradeoffs
- **Recommendation**: which option, and why
```

### `security-sweep.md`

```markdown
---
name: security-sweep
description: Persona-driven security audit of a directory
steps:
  - "Switch to the security-auditor persona with set_persona."
  - "List the files in the target directory (the user will specify it in the prompt)."
  - "For each file, identify potential injection / authN / authZ / secret-handling issues. Use grep_search to find string interpolation in SQL/shell contexts."
  - "Produce a findings report grouped by Must-fix / Should-fix / Nit."
  - "Clear the persona with set_persona (empty)."
---
```

## Combining recipes with personas

Recipes pair well with the `set_persona` tool: step 1 sets the persona, step N clears it. This keeps the active persona scoped to the recipe even when run from a chat that's already mid-task.

```markdown
steps:
  - "set_persona refactorer"
  - "Read the target file and identify the longest function."
  - "Extract sub-functions; commit each extraction independently."
  - "set_persona (clear)"
```

## Limits

- **No conditional branching.** Steps run in order; there is no `if green/else` syntax. Encode branching as instructions ("If tests fail, fix and continue; otherwise commit").
- **No parameters.** A recipe runs as-is; there's no `/recipe ship-feature foo=bar` parameter syntax. Use free-form input in the chat before the `/recipe` call, or hard-code the configuration.
- **No nested recipes** in the current release. (Coming soon.)
- **No scheduled recipes** in the current release; see `.iom/schedule.json` (coming soon).

## See also

- [TOOLS.md](TOOLS.md) — every tool a recipe step can invoke.
- [PERSONAS.md](PERSONAS.md) — personas to layer into recipe steps.
- `packages/extension-host/src/recipes.ts` — implementation.
