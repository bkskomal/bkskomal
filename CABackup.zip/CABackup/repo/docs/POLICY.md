# Workspace policy

`<workspace>/.iom/policy.yaml` is a YAML file that pins team-wide guardrails for iOmCode. It's meant to be committed to git so every contributor on a project gets the same rules without reconfiguring their VS Code settings.

The file is loaded by `loadPolicy()` in `packages/extension-host/src/policy.ts` on extension activation and on every save of `.iom/policy.yaml`.

**Failure mode:** a missing file, an empty file, or invalid YAML resolves to an empty (permissive) policy with a warning logged to the iOmCode output channel. We deliberately fail open — failing closed would lock everyone out the moment a typo slipped in.

## Schema

```yaml
providers:
  allow: [openai, anthropic]      # only these provider ids are usable
  deny: [openrouter]              # ...except this one (deny wins)

models:
  allow: ["gpt-4o*", "claude-3-*"]
  deny: ["*-preview", "*-experimental"]

tools:
  allow: ["read_file", "grep_search", "code_semantic_search", "git_*"]
  deny: ["exec", "fetch_url"]

modes:
  allow: ["ask", "plan", "code"]
  deny: ["auto"]

budget:
  perSessionAlertUsd: 2
  perSessionHardCapUsd: 10
  perDayHardCapUsd: 100
```

All sections are optional. A section that's absent (or `{}`) is treated as permissive — nothing is allowed or denied beyond what the user's own settings already say.

### Section semantics

For each section:

- `deny` matches → blocked (deny always wins).
- `allow` is set and the value doesn't match → blocked.
- `allow` is unset → everything is allowed unless explicitly denied.

Patterns support a basic `*` glob (zero-or-more characters). Anything without `*` is matched as a literal string. Case-insensitive.

### What each section gates

| Section | Matches against | Effect when blocked |
|---|---|---|
| `providers` | `provider.id` (settings panel ids) | Activating that provider fails; agent run refuses to dispatch. |
| `models` | The resolved model id at dispatch time | Dispatch refused; user sees a "model blocked by policy" banner. |
| `tools` | The tool's `name` (e.g. `exec`, `read_file`) | Tool is hidden from the registry the agent sees — the model is told the tool doesn't exist. |
| `modes` | `mode.id` | Mode picker hides it; switching to it via RPC errors out. |
| `budget.*` | Same fields as `BudgetConfig` | Policy values are taken as the **floor** — they tighten but never widen `RootConfig.budget`. |

## Budget tightening

The budget section can only tighten the user's caps. For each field, the effective value is `min(userConfig, policy)`:

| Field | Effect |
|---|---|
| `perSessionAlertUsd` | Lower of the two; alert fires earlier. |
| `perSessionHardCapUsd` | Lower of the two; dispatch refused earlier. |
| `perDayHardCapUsd` | Lower of the two. |

If the user has `perSessionHardCapUsd: 50` and policy has `perSessionHardCapUsd: 10`, the effective cap is `$10`. The user can't widen back to `$50` while the policy file is in place.

## Example: read-only review-only profile

`.iom/policy.yaml` for a repo where contractors should only be able to read code and propose plans, never write or exec:

```yaml
providers:
  allow: [anthropic, openai]

models:
  deny: ["*-preview"]

tools:
  deny:
    - write_file
    - smart_apply_patch
    - exec
    - start_background_task
    - browser_*
    - debug_*
    - git_commit
    - git_open_pr

modes:
  allow: [ask, plan]

budget:
  perSessionHardCapUsd: 2
  perDayHardCapUsd: 20
```

## Example: local-only / no-cloud

For a team that wants to enforce offline operation:

```yaml
providers:
  allow: [ollama, unillm, litellm]

tools:
  deny:
    - fetch_url
    - web_search
    - browser_*
    - gh_*
```

Combined with provider configuration pointing only at local endpoints, this guarantees the agent never makes an outbound network call.

## Example: tightening Auto modes

```yaml
modes:
  deny: [auto]                # disable the most aggressive mode

budget:
  perSessionHardCapUsd: 5     # don't let a single auto-edit session burn more than $5
```

## Reload

Policy reloads when `.iom/policy.yaml` is saved (file watcher in the extension-host). No window reload needed. Active agent runs that started before the reload finish under the old policy; the next dispatch picks up the new values.

## What policy doesn't do

- **It is not a security boundary.** A user who controls the workspace can always edit `policy.yaml` itself. Policy is for guardrails, not adversarial defense. For adversarial scenarios, use OS-level controls (file ACLs, container isolation).
- **It does not cover MCP servers.** Enabled MCP servers are governed by their own approval policy in `mcpServers[].approval`. To deny an MCP-exposed tool, prefix it: `tools: { deny: ["<serverid>:*"] }`.
- **It does not store secrets.** API keys remain in SecretStorage / DPAPI; the policy file is plain YAML and safe to commit.

## See also

- [SECURITY.md](SECURITY.md) — threat model and audit log.
- [CONFIGURATION.md](CONFIGURATION.md) — user-level configuration shape.
- `packages/extension-host/src/policy.ts` — implementation.
