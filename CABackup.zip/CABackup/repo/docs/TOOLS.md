# Tools reference

Auto-generated from `packages/tools/src/registry.ts` by `scripts/gen-tools-doc.mjs`.
Do not edit by hand — run `node scripts/gen-tools-doc.mjs` to refresh.

The iOmCode agent ships with 58 built-in tools, grouped here by domain.
Required arguments are marked with `*`; everything else is optional.

**Approval policies**

- `auto` — runs silently. Used for read-only / idempotent tools.
- `prompt` — pops the approval dialog with a diff or summary; user must confirm.
- `deny` — disabled at the registry; kept for parity with config but never used by built-ins.

Modes can override the per-tool default with `autoApprove: true` (Auto / Auto Edit modes
do this) or restrict the tool surface with `enabledTools: ["read_file", ...]` (Ask, Plan).

## Reading & navigation

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `get_workspace_context` | `auto` | — | Get the user's current IDE state: workspace root, the file they're actively viewing, any selected text, and the list of open editor tabs. Useful at the start of a task to ground the conversation in what the user is looking at. |
| `read_file` | `auto` | — | Read the full contents of a file from the user's workspace. Paths are relative to the workspace root unless absolute. |
| `list_dir` | `auto` | — | List entries in a directory. Returns file/directory names and types. Optionally recursive (capped to prevent huge dumps). |
| `read_shared_notes` | `auto` | — | Read all notes from the shared scratchpad for this sub-agent batch (notes written by your siblings via write_shared_note). Returns the notes in the order they were written. |
| `read_notebook` | `auto` | — | Read a Jupyter notebook (.ipynb) and return its cells as a structured list. Use this instead of read_file for notebooks so you see cell boundaries, cell kinds (code/markdown), and (optionally) execution outputs. Returns a JSON object {cells: [{index, kind, language, source, outputs?}]}. |
| `read_notebook_cell` | `auto` | — | Read a single cell from a Jupyter notebook (.ipynb) by 0-based index. Returns {index, kind, language, source, outputs}. Outputs are always included since the caller has explicitly asked for one cell. |

## Writing & editing

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `write_file` | `prompt` | — | Write file contents to the user's workspace. Shows a diff preview and requires user approval before applying. |
| `smart_apply_patch` | `prompt` | — | Three-way merge an agent-authored `before` → `after` change against the current on-disk content of `path`. Returns { status: 'clean' \| 'merged' \| 'conflict', merged, conflictHunks? }. |

## Search

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `grep_search` | `auto` | — | Regex search across workspace files. Returns file:line:text for each match (capped). Uses ripgrep if available, otherwise falls back to a Node scan. |
| `code_semantic_search` | `auto` | — | Semantic code search over the local workspace index. Returns file paths plus the most relevant snippets for the query. Use this BEFORE reading lots of files when you're not sure exactly where the relevant code lives. Falls back to a deterministic TF-IDF index when the active provider doesn't offer embeddings, so it's always available once `/reindex` has been run. |

## Shell & background

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `exec` | `prompt` | — | Run a shell command in the user's workspace. Requires explicit approval. Returns stdout, stderr, and the exit code. Streams stdout live to the chat when the host wires emitToolProgress. |
| `run_tests` | `auto` | — | Detect and run the workspace's test suite (vitest/jest/mocha/pytest). Returns exit code, a summary line, and a parsed list of failures with snippets. Streams output progressively to the chat. |
| `start_background_task` | `prompt` | — | Hand off a long-running task to the background runner. Returns immediately with a task id. The task survives panel close / window blur, and its final result lands in `.iom/tasks/<id>.json` plus a status-bar notification. Prefer this over spawn_agent when you want the user to keep working while the task chugs along. |

## Network

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `fetch_url` | `prompt` | — | HTTP GET a URL and return the body as text. Approval-gated to prevent SSRF / unintended outbound calls. Body is truncated past max_bytes. |
| `web_search` | `prompt` | — | Search the web via DuckDuckGo's HTML endpoint and return ranked results (title, URL, snippet). No API key required. Use for fresh facts, docs, and quick lookups. |

## Sub-agents

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `spawn_agent` | `auto` | — | Spawn an isolated sub-agent to handle a self-contained sub-task. The sub-agent runs with the same tool set but a fresh conversation. Use for parallelizable research/refactoring chunks. Returns the sub-agent's final answer plus stats. |
| `spawn_parallel_agents` | `auto` | — | Spawn multiple isolated sub-agents concurrently to handle independent sub-tasks in parallel. Each sub-agent runs the full tool loop with a fresh conversation. Use when you have N self-contained chunks of research/refactoring that don't depend on each other. Returns a joined summary of every agent's final answer plus stats. |

## Memory & facts

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `remember_fact` | `auto` | — | Persist a fact about this project to `<workspace>/.iom/facts.json` so it carries across sessions. Use for stable knowledge: naming conventions, file locations, project rules. Idempotent — duplicate facts (case-insensitive) are silently skipped. |
| `recall_facts` | `auto` | — | Retrieve persistent facts stored for this project (loaded from `<workspace>/.iom/facts.json`). Pass an optional `query` to filter by substring; omit it to list everything. |
| `consolidate_memory` | `prompt` | — | 'Walk older sessions (older than `daysOld`, default 30) and promote 1-3 "lessons learned" per session to `<workspace>/.iom/facts.json`. Existing facts are deduped (case-insensitive). Use this when the user wants to compress long-term project knowledge from past chats into the persistent facts store.' |

## Scratchpad

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `write_shared_note` | `auto` | — | Append a short note (≤500 chars) to the shared scratchpad visible to your sibling sub-agents in this batch. Notes are dropped when the parent run completes. Use to surface findings other sub-agents should know. |

## Git & GitHub

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `git_status` | `auto` | — | Report the workspace git status — staged, unstaged, and untracked file lists plus the current branch. Read-only. |
| `git_diff` | `auto` | — | Show a unified git diff for the workspace. Optionally narrow to specific paths or show only staged changes. Output is truncated to 200 KB with a tail marker. |
| `git_commit` | `prompt` | — | Create a git commit with the given message. Optionally stage specific paths first. Requires user approval because it mutates repo state. |
| `git_open_pr` | `prompt` | — | Open a GitHub pull request for the current branch using the `gh` CLI. Requires user approval and `gh` installed on PATH. |
| `gh_issue_read` | `auto` | — | Read a GitHub issue (title, body, labels, assignees, comments) via the `gh` CLI. Accepts either a full issue URL or owner+repo+number. |
| `gh_issue_comment` | `prompt` | — | Post a comment on a GitHub issue via the `gh` CLI. Requires user approval (visible side effect) and `gh` installed on PATH. |
| `suggest_commit_message` | `auto` | — | Read the staged git diff and return it alongside guidance for crafting a Conventional Commits-style message. Read-only — does NOT create a commit. Use after staging changes; pair with `git_commit` to actually record the commit. |

## Browser

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `browser_open` | `prompt` | — | Open a URL in a Puppeteer-controlled Chromium window so the agent can see a running web app. Reuses one shared window across all browser_* calls. Requires `puppeteer-core` (optional dep); set OATI_CHROME_PATH to point at a system Chrome binary if no bundled Chromium is available. Approval-gated because it spawns a visible window on the user's machine. |
| `browser_navigate` | `auto` | — | Navigate the existing browser session to a new URL. The session must already be open via browser_open. No approval required because the user already consented to the browser window. |
| `browser_screenshot` | `auto` | — | Capture a PNG screenshot of the current browser page (or a single element via CSS selector) and return it as a base64 data URL. Capped at 4MB; oversize captures are retried at 1280x800 with fullPage disabled. |
| `browser_eval` | `prompt` | — | DANGEROUS: runs arbitrary JavaScript inside the active browser page via page.evaluate. The expression executes in the page's origin and can read cookies, localStorage, DOM, etc. Approval required on every call. Result is JSON-serialized and truncated to 64KB. |
| `browser_close` | `auto` | — | Close the shared Puppeteer browser window if one is open. No-op when no session is active. Useful for explicit cleanup at the end of a debugging session. |

## Symbol intelligence

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `find_references` | `auto` | — | Find all references to the symbol at a given file position using the editor's language server. Use this when you need to know where a function/class/variable is used before refactoring. Returns up to N {path, line, snippet} entries. Falls back gracefully when no language server is attached. |
| `find_definition` | `auto` | — | Find the declaration site for the symbol at a given file position using the editor's language server. Use this when the agent needs to read a function's source after seeing it called. Returns up to N {path, line, snippet} entries. Falls back gracefully when no language server is attached. |
| `symbols_in_file` | `auto` | — | List the symbols (functions, classes, methods, variables) declared in a file using the editor's language server. Useful for getting an outline before reading a large file. Returns a flat list with `parent` set on nested symbols. Falls back gracefully when no language server is attached. |

## Diagrams

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `render_diagram` | `auto` | — | Render a Mermaid diagram in the chat. Pass valid mermaid source (e.g. 'flowchart TD; A-->B'); the webview renders it inline. |

## Diagnostics

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `get_diagnostics` | `auto` | — | Read the editor's current LSP diagnostics (errors, warnings, info, hints) — the same squiggles you'd see in the gutter. Optionally filter by workspace-relative path and/or severity. Use this before refactoring to ground decisions in real compiler/linter output rather than guessing. Returns a JSON object {count, items, truncated}; items are 1-based line/column. |

## Snippets

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `list_snippets` | `auto` | — | List user-defined snippets stored under `<workspace>/.iom/snippets/*.md`. Returns name + description per snippet. Optional `query` substring filter (case-insensitive). |
| `save_snippet` | `prompt` | — | Save a markdown snippet to `<workspace>/.iom/snippets/<name>.md`. The first H1 line is the description; everything else is the snippet body. Overwrites an existing file with the same name. |

## Telemetry

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `inline_completion_stats` | `auto` | — | R5-A: read the rolling acceptance counters of the inline-completion (ghost-text) provider. Returns {accepted, rejected, shown, acceptanceRate, lastUpdatedIso}. Useful for the agent to self-report user signal — e.g., 'your last 50 suggestions were accepted 42% of the time'. Read-only and zero-cost. |

## Knowledge RAG

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `list_knowledge` | `auto` | — | List all knowledge docs under `<workspace>/.iom/knowledge/**/*.md`. Returns the workspace-relative path, the first H1 as the title (filename fallback), and the file's modification time. Use this before `search_knowledge` to discover what's available. |
| `search_knowledge` | `auto` | — | Semantic search over the project knowledge base (`<workspace>/.iom/knowledge/**/*.md`). Returns the top-k chunks with file path + snippet + score. Use this before reading whole docs when you're not sure where the relevant note lives. Falls back to an empty result when the knowledge index hasn't been built yet. |

## Conversation search

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `search_conversations` | `auto` | — | Semantic search over the message bodies of every past chat session in this workspace. Returns the top matches with session/message ids, role, snippet, and similarity score. Use this when you need to recall what was decided in an earlier conversation. |

## Personas & recipes

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `set_persona` | `auto` | — | Switch the active built-in persona for the current session. Pass null (or empty string) to clear. Personas layer a small system-prompt addendum onto the active mode's prompt; they do not change the mode itself. Use when the task would benefit from a different lens (e.g. `security-auditor` for a review pass) and switch back afterwards. |
| `run_recipe` | `prompt` | — | Run a saved multi-step workflow from `<workspace>/.iom/recipes/<name>.md`. Each step is dispatched as a separate agent turn, with the prior step's history fed into the next. Use this when the user has authored a recipe (e.g. `ship-feature`) and wants the agent to execute it end-to-end. |

## Plan v2

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `propose_plan` | `auto` | — | Produce a structured plan (PlanV2) for the given task: 3-8 steps with title + acceptance criterion + optional dependsOn edges. Useful when the user wants a plan upfront without switching to Plan mode. The host surfaces the resulting plan in the editor side panel; the agent only needs to call this once per request. |

## Notebook

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `edit_notebook_cell` | `prompt` | — | Replace the source of a single cell in a Jupyter notebook (.ipynb). Identified by 0-based index. Shows a diff preview and requires user approval. Outputs are preserved (only the source changes). Use insert_notebook_cell / delete_notebook_cell to add or remove cells. |
| `insert_notebook_cell` | `prompt` | — | Insert a new cell into a Jupyter notebook (.ipynb) at a specific 0-based index. Existing cells at or after this index shift down by one. Use index = current cell count to append. `kind` is 'code' or 'markdown'; `language` is the language id (e.g. 'python'); defaults to the notebook's primary language. |
| `delete_notebook_cell` | `prompt` | — | Delete a cell from a Jupyter notebook (.ipynb) by 0-based index. Cells after `index` shift up by one. Shows a preview of the cell that will be removed and requires user approval. |
| `run_notebook_cell` | `prompt` | — | Execute a single cell in a Jupyter notebook (.ipynb) using the notebook's attached kernel and return its outputs. Identified by 0-based index. Requires approval since this runs arbitrary code. Returns a JSON object {outputs: [{mime, text}]}. |

## Debug bridge

| Tool | Approval | Required args | Description |
|---|---|---|---|
| `debug_stack_frames` | `auto` | — | List the call stack for a thread in the active debug session. Returns a JSON array of {id, name, path?, line?} entries (1-based lines). Omit threadId to use whichever thread is currently stopped. Use this to inspect where execution paused before evaluating expressions or reading variables. |
| `debug_evaluate` | `prompt` | — | Evaluate an expression in the active debug session. The expression is run as if typed into the debug console (REPL context). Returns the formatted result string. Omit frameId to evaluate against the top of the active stack. Approval-gated because this runs arbitrary code inside the user's process. |
| `debug_scopes` | `auto` | — | List variable scopes for a stack frame in the active debug session. Returns a JSON array of {name, variablesReference}. Use this after debug_stack_frames to learn which `variablesReference`s to pass to debug_variables. |
| `debug_variables` | `auto` | — | Expand a `variablesReference` (from debug_scopes or a previous debug_variables call) into its named values. Returns a JSON array of {name, value, type?}. Use this to inspect locals/arguments at a paused frame. |
| `debug_list_breakpoints` | `auto` | — | List every source breakpoint currently registered with the editor. Returns a JSON array of {uri, line, condition?, enabled} entries (1-based lines). Useful before calling debug_set_breakpoint to avoid duplicates. |
| `debug_set_breakpoint` | `prompt` | — | Add a source breakpoint at the given path:line (1-based). Optionally make it conditional by passing a `condition` expression — execution will only halt when the expression is truthy. Returns 'ok' or a friendly error message. Approval-gated because this affects the user's debug session behavior. |
| `debug_remove_breakpoint` | `prompt` | — | Remove any source breakpoint anchored at the given path:line (1-based). Returns 'ok' on success, even when no matching breakpoint was registered (idempotent). |

## MCP tools

Anything an enabled MCP server exposes via `tools/list` becomes a regular tool
from the agent's perspective. The approval policy is the per-server `approval`
field in `mcpServers[]` (default `prompt`). See [MCP.md](MCP.md).

## Adding a tool

1. Drop a new file under `packages/tools/src/<name>.ts` exporting a `ToolSpec`.
2. Append the import + the spec to `packages/tools/src/registry.ts`.
3. `node scripts/gen-tools-doc.mjs` to refresh this file.

Tools are single-file plugins — no central switch to edit, no codegen step.
