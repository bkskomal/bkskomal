# Security model

This document describes how iOmCode defends against accidental and adversarial harm. For *reporting* a vulnerability, see [SECURITY.md](../SECURITY.md) at the repo root.

## Threat model

iOmCode's primary security posture is **don't surprise the user**. The user trusts:

- The LLM provider they configured.
- The MCP servers they enabled.
- The code in this extension.

Everything else (network, filesystem, shell, model output) is treated as potentially hostile or buggy.

### What we defend

| Surface | Defense |
|---|---|
| **Outbound prompt leakage** | Secret scanner redacts `[REDACTED:KIND]` placeholders before dispatch (see below). |
| **Unintended writes / shell** | Per-tool approval policy; `write_file` and `exec` default to `prompt`. Diff preview shown before approval. |
| **Runaway autonomous loops** | Per-mode `maxIterations` cap; per-session and per-day USD caps refuse dispatch past the hard ceiling. |
| **Test-regressing edits** | Auto-revert rolls back writes when post-turn `run_tests` reports new failures (opt-in). |
| **Provider key leakage to the webview** | Keys live in SecretStorage (VS Code) or DPAPI (Visual Studio). The webview only sees `hasApiKey: boolean`. |
| **CSP escape in chat UI** | Strict CSP; only the bundled `main.js` runs. No remote scripts, no inline scripts. |
| **SSRF via `fetch_url`** | Blocks `localhost`, RFC1918, link-local, and metadata-service IPs unless the host is an explicit allowlist. |
| **MCP server tampering** | One-time third-party-code approval banner on first enable. Per-server approval policy applies to every tool the server exposes. |
| **Workspace overreach by the agent service** | `OATI_WORKSPACE_ROOT` pins the allowed root; paths outside are refused. Bearer-token auth required. |
| **Audit trail** | Append-only `.iom/audit.log` records every tool call (with hashed args), every message, and inline-completion telemetry. |

### What we don't defend

- **LLM jailbreaks.** If you tell the model to do bad things and approve every prompt, it will do bad things. Approval gates exist precisely so the human stays in the loop on irreversible actions.
- **Hostile workspaces.** Once you open a workspace in VS Code, you're trusting its contents. A repo could ship a `.iom/policy.yaml` that disables the secret scanner, a `.iom/recipes/` step that calls `exec`, or an `.iom/commands/` slash command that crafts a malicious prompt.
- **Compromised dependencies.** We pin via `package-lock.json` and target Node 22+. Run `npm audit` periodically.
- **Adversarial users in shared workspaces.** Policy is a guardrail, not a sandbox; a user with write access to `.iom/policy.yaml` can edit it.

## Secret scanner

Every outbound message (user prompts, system prompts with project memory, recipe contexts) is scanned for high-confidence secret patterns before being handed to the provider. Implementation: `packages/extension-host/src/secret-scanner.ts`.

### Detected patterns

| Kind | Pattern | Notes |
|---|---|---|
| `AWS access key` | `AKIA[0-9A-Z]{16}` | Unambiguous; no validator needed. |
| `AWS secret access key` | 40-char base64ish | Requires upper + lower + digit to avoid matching hex digests. |
| `GitHub PAT` | `gh[pousr]_[A-Za-z0-9]{30,}` | Covers `ghp_`, `gho_`, `ghu_`, `ghs_`, `ghr_`. |
| `Anthropic key` | `sk-ant-[A-Za-z0-9_-]{20,}` | Disambiguated from OpenAI by the `-ant-` infix. |
| `OpenAI key` | `sk-(?!ant-)[A-Za-z0-9_-]{40,}` | Negative lookahead avoids double-classifying Anthropic. |
| `Slack token` | `xox[baprs]-[A-Za-z0-9-]{10,}` | Bot/user/app tokens. |
| `JWT` | three base64url segments | Header almost always starts with `eyJ`. |
| `Private key` | PEM header | Catches RSA / DSA / EC / OPENSSH / generic. |

### Behavior

- **Match → redact.** The match is replaced with `[REDACTED:KIND]` before dispatch.
- **Notify.** A `secret_warning` RPC fires so the webview can show a banner.
- **Audit.** The redacted message is logged to `.iom/audit.log` with the kind list; the raw secret is never logged.
- **False positives.** Use `[REDACTED:OPT-OUT]` in the message yourself to suppress a specific scan (the scanner deliberately doesn't catch every base64 blob — only patterns specific enough to be unambiguous).

The scanner is deliberately **not** a replacement for `trufflehog` or the like. It's a tripwire for the obvious cases: keys pasted by mistake, env files dragged into the chat, etc.

## Audit log

`<workspace>/.iom/audit.log` is an append-only newline-delimited JSON file. One record per event:

```json
{"ts":"2026-05-21T14:33:21.041Z","kind":"tool","tool":"write_file","argsHash":"a1b2c3d4","sessionId":"s_...","agentId":"root","verdict":"approved","durationMs":42}
{"ts":"2026-05-21T14:33:25.110Z","kind":"message","direction":"out","sessionId":"s_...","tokensIn":420,"tokensOut":80,"secretsRedacted":["AWS access key"]}
{"ts":"2026-05-21T14:34:01.220Z","kind":"inline_completion","event":"accept","sessionId":"s_...","language":"typescript","latencyMs":280}
```

### Record kinds

- `tool` — every tool call. Args are SHA-256-hashed (first 8 hex chars) so the log is safe to share without leaking content. `verdict` is `auto` | `approved` | `denied` | `error`.
- `message` — every outbound model dispatch with token counts. Lists `secretsRedacted` kinds when the scanner fired.
- `inline_completion` — telemetry events: `shown`, `accepted`, `dismissed`. No suggestion text is stored.

### Disabling

`{"auditLog": false}` in your RootConfig disables the log entirely. Use for tests and short-lived experiments. Keep it on for production work — it's the single best forensic tool when something goes wrong.

### Rotation

The log is not auto-rotated. Add it to `.gitignore`; truncate or rotate it yourself when it grows large.

## Approval flow

Every tool with `approval: "prompt"` triggers the approval dialog. The dialog shows:

- **Tool name** + a one-line description.
- **Args summary** — file path, command string, URL, etc.
- **Diff preview** for `write_file` (inline +/-) **and** opens VS Code's native side-by-side diff editor.
- **Sub-agent attribution** — when the call comes from a sub-agent, the parent task is named.

Decisions:

- **Approve** — call proceeds; audit log records `approved`.
- **Approve all (this turn)** — every subsequent prompt in the current turn is auto-approved. Resets on the next user turn.
- **Deny** — call fails with a `User denied tool` error; the agent sees the failure and continues.

Modes with `autoApprove: true` (Auto Edit, Auto) skip the dialog entirely. The audit log still records every call.

## Auto-revert safety net

When `iom.autoRevert.enabled` is on and an Auto* turn writes files:

1. Pre-turn snapshots of every soon-to-be-written file are captured.
2. After the turn, `run_tests` results are compared against the pre-turn baseline.
3. If **new** failures appear (test names that were passing before, failing after), the snapshots are restored via `vscode.workspace.applyEdit`.
4. The user sees a "Auto-reverted N files due to N new test failures" notification.

Tests that were already failing before the turn don't trigger a revert — only regressions. Files created during the turn are NOT deleted; we only restore files we actually snapshotted.

## Provider key storage

| Shell | Where keys live |
|---|---|
| VS Code | `vscode.SecretStorage` (Keychain on macOS, DPAPI on Windows, libsecret on Linux). |
| Visual Studio | `System.Security.Cryptography.ProtectedData.Protect` with `CurrentUser` scope (DPAPI). |
| Agent service | Passed in via `Authorization: Bearer <OATI_SERVICE_TOKEN>`; provider keys are never written to disk by the service. |

The webview never sees raw key values — only `hasApiKey: boolean` flags. Test Connection calls happen in the host, with the key staying host-side.

## Hooks as enforcement

User-defined hooks (`PreToolUse`, `UserPromptSubmit`, etc.) can act as guards when `blocking: true`. Example — block any `exec` whose command starts with `rm -rf`:

```js
// hooks/guard-rm.js
const payload = JSON.parse(require("fs").readFileSync(0, "utf-8"));
if (payload.tool === "exec" && /^\s*rm\s+-rf/.test(payload.args.command ?? "")) {
  process.stdout.write(JSON.stringify({ allow: false, reason: "rm -rf blocked by hook" }));
} else {
  process.stdout.write(JSON.stringify({ allow: true }));
}
```

Hooks live alongside the agent's approval policy — both must pass before a tool runs.

## Reporting

Found something? See [SECURITY.md](../SECURITY.md) at the repo root for the private disclosure flow.
