# Model Context Protocol (MCP)

iOmCode ships a full MCP client: stdio JSON-RPC transport, `tools/list` + `tools/call`, capability negotiation, and per-server approval policy. Every tool an enabled MCP server exposes appears alongside the built-ins from the agent's perspective.

There are two ways to add a server:

1. **Marketplace** — `/marketplace` opens a curated catalog of 10 vetted servers. One-click install.
2. **Manual** — paste a `McpServerConfig` into the Settings panel.

## Curated marketplace

The registry lives in `packages/extension-host/src/mcp-registry.ts`. All servers are first-party `@modelcontextprotocol/server-*` packages launched via `npx -y` so nothing needs to be installed globally.

| Server | Category | What it does | Required env |
|---|---|---|---|
| **Filesystem** | filesystem | Read/write files in allowed directories. Pass each allowed dir as an extra arg. | — |
| **Git** | git | Inspect a local repo (status, log, diff, blame, show). | — |
| **GitHub** | git | Search repos, read/create issues + PRs, file ops on GitHub. | `GITHUB_PERSONAL_ACCESS_TOKEN` |
| **Brave Search** | search | Web search via Brave's API (free tier available). | `BRAVE_API_KEY` |
| **Puppeteer** | search | Headless Chromium for screenshots, scraping, dynamic interaction. | — |
| **SQLite** | database | Query/modify a local `.db` file (edit args to point at it). | — |
| **Postgres** | database | Read-only access; pass connection URL as the last arg. | — |
| **Slack** | misc | Read messages and post to channels. | `SLACK_BOT_TOKEN`, `SLACK_TEAM_ID` |
| **Memory** | ai | Persist arbitrary facts in a knowledge-graph store; recall across sessions. | — |
| **Time** | misc | Current time, time-zone conversion, time arithmetic — useful for scheduling-aware agents. | — |

### Workflow

1. `/marketplace` — opens the overlay.
2. Click **Install** on the server you want. This appends an entry to `mcpServers[]` in your settings with `enabled: false`. The subprocess does NOT start yet.
3. (If the server needs env vars) Open Settings → MCP servers → fill in the values.
4. Toggle **Enabled** on. The third-party-code approval banner appears; confirm to start the subprocess.
5. The server's `tools/list` is fetched and merged into the agent's tool registry. Tool names get prefixed with the server id to avoid collisions.

The MCP subprocess runs as a child of the extension-host with stdio piped through `McpManager`. On extension reload (`Developer: Reload Window`), every enabled server is respawned.

## Manual server config

```ts
interface McpServerConfig {
  id: string;                                  // stable id, used internally
  displayName: string;
  command: string;                             // e.g. "npx"
  args?: string[];                             // e.g. ["-y", "my-mcp-server"]
  env?: Record<string, string>;                // merged with process.env
  enabled: boolean;
  approval?: "auto" | "prompt" | "deny";       // default "prompt"
}
```

Example — a local Python MCP server:

```jsonc
{
  "id": "my-python-server",
  "displayName": "My Python MCP",
  "command": "python",
  "args": ["-m", "my_mcp_server", "--port", "stdio"],
  "env": { "PYTHONPATH": "./src" },
  "enabled": true,
  "approval": "prompt"
}
```

## Writing a custom MCP server

The MCP spec is at [modelcontextprotocol.io](https://modelcontextprotocol.io). The short version:

1. **Speak JSON-RPC 2.0** over stdio. One JSON object per line (the `Content-Length` framing from the spec is optional in stdio; iOmCode accepts both).
2. **Respond to `initialize`** with your capabilities. Minimum capability for iOmCode: `tools`.
3. **Respond to `tools/list`** with `{ tools: [{ name, description, inputSchema }] }`. `inputSchema` is JSON Schema.
4. **Respond to `tools/call`** with `{ content: [{ type: "text", text: "..." }] }`. iOmCode only reads `text` blocks today.
5. **Log to stderr**, never stdout (stdout is reserved for JSON-RPC).

### Minimal Node example

```js
// my-mcp-server.js
const { stdin, stdout } = process;

function send(msg) {
  stdout.write(JSON.stringify(msg) + "\n");
}

let buf = "";
stdin.setEncoding("utf-8");
stdin.on("data", (chunk) => {
  buf += chunk;
  let nl;
  while ((nl = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, nl);
    buf = buf.slice(nl + 1);
    if (!line.trim()) continue;
    const req = JSON.parse(line);
    handle(req);
  }
});

function handle(req) {
  if (req.method === "initialize") {
    send({ jsonrpc: "2.0", id: req.id, result: {
      protocolVersion: "2024-11-05",
      capabilities: { tools: {} },
      serverInfo: { name: "my-server", version: "0.1.0" }
    }});
    return;
  }
  if (req.method === "tools/list") {
    send({ jsonrpc: "2.0", id: req.id, result: { tools: [{
      name: "echo",
      description: "Echo a string back.",
      inputSchema: { type: "object", properties: { text: { type: "string" } }, required: ["text"] }
    }]}});
    return;
  }
  if (req.method === "tools/call" && req.params?.name === "echo") {
    const text = String(req.params?.arguments?.text ?? "");
    send({ jsonrpc: "2.0", id: req.id, result: {
      content: [{ type: "text", text: `echo: ${text}` }]
    }});
    return;
  }
  send({ jsonrpc: "2.0", id: req.id, error: { code: -32601, message: "Method not found" }});
}
```

Settings entry:

```jsonc
{
  "id": "echo",
  "displayName": "Echo (demo)",
  "command": "node",
  "args": ["./my-mcp-server.js"],
  "enabled": true,
  "approval": "auto"
}
```

## Approval policies

The server's `approval` field applies to **every** tool the server exposes. There is no per-tool override per server (yet) — if you want one tool gated and another silent, run them under two server entries or use the `prompt` policy and quick-approve repeatedly.

The host always shows a one-time confirmation when you enable a server for the first time ("This is third-party code"). After that, the per-tool policy controls per-call behavior.

## Tool-name collisions

If two enabled servers expose a tool named `read`, iOmCode prefixes the second occurrence with `<serverid>:` so both remain callable. Built-in tools always win on a bare name collision; an MCP server's `read_file` will be addressable as `<serverid>:read_file`.

## Debugging

- **`iOmCode: Show Output`** — extension-host log channel; every MCP request/response is logged.
- **Set `OATI_DEBUG=1`** in your env before launching VS Code for verbose logs.
- **stderr** from MCP processes is captured and surfaced on tool failure.
- **Process status**: the settings panel shows live `running` / `stopped` / `failed` per server, with the last exit code.

## Limits

- **Resources and prompts (MCP concepts)** are not yet consumed by iOmCode; only `tools` is wired up. (Coming soon.)
- **No sampling / completions over MCP** — providers stay native. (Out of scope for the foreseeable future.)
- **Stdio transport only.** No HTTP, no SSE, no WebSocket. The spec allows others; we don't ship them.
