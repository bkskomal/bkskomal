// Tests for the capability probe that decides whether a gateway needs
// the `/v1/completions` fallback. Mocks `global.fetch` to simulate each
// gateway behaviour and asserts the classification.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { probeChatEndpoint } from "../src/endpoint-probe";

describe("probeChatEndpoint", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("returns chatCompletionsWorks=true when the gateway responds 200", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				JSON.stringify({
					id: "x",
					choices: [{ message: { role: "assistant", content: "ok" }, finish_reason: "stop" }],
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			),
		);
		const r = await probeChatEndpoint({
			baseUrl: "https://api.openrouter.ai/api/v1",
			modelId: "qwen/qwen3-coder",
		});
		expect(r.chatCompletionsWorks).toBe(true);
		expect(r.needsCompletionsFallback).toBe(false);
		expect(r.summary).toMatch(/OK \(HTTP 200\)/);
	});

	it("classifies a vLLM 'chat_template is required' rejection as needsCompletionsFallback", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				JSON.stringify({
					object: "error",
					message:
						"As of transformers v4.44, default chat_template is no longer allowed. Please set chat_template on the tokenizer or pass it via --chat-template.",
					type: "BadRequestError",
				}),
				{ status: 400, headers: { "content-type": "application/json" } },
			),
		);
		const r = await probeChatEndpoint({
			baseUrl: "http://vllm.dev.services.oati.com/qwen3_coder/v1",
			modelId: "Qwen/Qwen3-Coder-30B-A3B-Instruct",
		});
		expect(r.chatCompletionsWorks).toBe(false);
		expect(r.needsCompletionsFallback).toBe(true);
		expect(r.summary).toMatch(/chat_template/i);
	});

	it("classifies vLLM's --trust-request-chat-template guard as needsCompletionsFallback", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				JSON.stringify({
					message:
						"Specifying a chat_template via the request body is disallowed. Restart the server with --trust-request-chat-template to allow.",
				}),
				{ status: 400 },
			),
		);
		const r = await probeChatEndpoint({
			baseUrl: "http://vllm.example/v1",
			modelId: "google/gemma-4",
		});
		expect(r.needsCompletionsFallback).toBe(true);
	});

	it("does NOT force fallback on a 401 (auth) — auth is the user's problem to fix", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(JSON.stringify({ error: { message: "Invalid API key" } }), { status: 401 }),
		);
		const r = await probeChatEndpoint({
			baseUrl: "https://api.openrouter.ai/api/v1",
			modelId: "qwen/qwen3-coder",
			apiKey: "bad-key",
		});
		expect(r.chatCompletionsWorks).toBe(false);
		expect(r.needsCompletionsFallback).toBe(false);
		expect(r.summary).toMatch(/HTTP 401/);
	});

	it("does NOT force fallback on a 404 — wrong URL means user should fix the base URL, not silently fall back", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response("Not Found", { status: 404 }),
		);
		const r = await probeChatEndpoint({
			baseUrl: "https://api.example.com/wrong/v1",
			modelId: "qwen/qwen3-coder",
		});
		expect(r.needsCompletionsFallback).toBe(false);
	});

	it("405 on /v1/chat/completions → probes /v1/completions, marks needsCompletionsFallback if it accepts POST (the K2.7 gateway case)", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch
			.mockImplementationOnce(async (url: string) => {
				// First call — chat/completions → 405 Method Not Allowed
				expect(url).toBe("http://gry5qaapps3:7300/v1/chat/completions");
				return new Response("Method Not Allowed", { status: 405 });
			})
			.mockImplementationOnce(async (url: string) => {
				// Second call — /completions → accepts POST, returns something
				expect(url).toBe("http://gry5qaapps3:7300/v1/completions");
				return new Response(JSON.stringify({ choices: [{ text: "hi" }] }), { status: 200 });
			});
		const r = await probeChatEndpoint({
			baseUrl: "http://gry5qaapps3:7300/v1",
			modelId: "kimi-k2.7-code",
		});
		expect(r.chatCompletionsWorks).toBe(false);
		expect(r.needsCompletionsFallback).toBe(true);
		expect(r.summary).toMatch(/405.*completions.*accepts POST/i);
		expect(mockFetch).toHaveBeenCalledTimes(2);
	});

	it("405 on BOTH endpoints → surfaces the original 405 (gateway blocks POST entirely, not our problem to paper over)", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch
			.mockResolvedValueOnce(new Response("Method Not Allowed", { status: 405 }))
			.mockResolvedValueOnce(new Response("Method Not Allowed", { status: 405 }));
		const r = await probeChatEndpoint({
			baseUrl: "http://locked-gateway/v1",
			modelId: "test-model",
		});
		expect(r.chatCompletionsWorks).toBe(false);
		expect(r.needsCompletionsFallback).toBe(false);
		expect(r.summary).toMatch(/HTTP 405/);
	});

	it("405 on chat + 404 on completions → no fallback (completions not served either)", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch
			.mockResolvedValueOnce(new Response("Method Not Allowed", { status: 405 }))
			.mockResolvedValueOnce(new Response("Not Found", { status: 404 }));
		const r = await probeChatEndpoint({
			baseUrl: "http://weird-gateway/v1",
			modelId: "test-model",
		});
		expect(r.needsCompletionsFallback).toBe(false);
	});

	it("405 on chat + completions returns a chat_template-style 400 → still marks fallback (completions accepted the POST even if it errored)", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch
			.mockResolvedValueOnce(new Response("Method Not Allowed", { status: 405 }))
			.mockResolvedValueOnce(
				new Response(JSON.stringify({ error: "some model config issue" }), { status: 400 }),
			);
		const r = await probeChatEndpoint({
			baseUrl: "http://mixed-gateway/v1",
			modelId: "test-model",
		});
		// completions endpoint accepted the POST method — that's the signal.
		expect(r.needsCompletionsFallback).toBe(true);
	});

	it("handles network errors gracefully (returns false/false, never throws)", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockRejectedValue(
			new Error("ECONNREFUSED 127.0.0.1:1"),
		);
		const r = await probeChatEndpoint({
			baseUrl: "http://nothing-here:1/v1",
			modelId: "x",
		});
		expect(r.chatCompletionsWorks).toBe(false);
		expect(r.needsCompletionsFallback).toBe(false);
		expect(r.summary).toMatch(/network|ECONNREFUSED/);
	});

	it("sends the correct shape: model, single message, max_tokens=1, stream=false", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch.mockResolvedValue(new Response(JSON.stringify({}), { status: 200 }));
		await probeChatEndpoint({
			baseUrl: "https://api.example/v1",
			modelId: "test-model",
			apiKey: "sk-test",
		});
		expect(mockFetch).toHaveBeenCalledOnce();
		const [url, init] = mockFetch.mock.calls[0] as [string, RequestInit];
		expect(url).toBe("https://api.example/v1/chat/completions");
		expect(init.method).toBe("POST");
		expect((init.headers as Record<string, string>).Authorization).toBe("Bearer sk-test");
		const body = JSON.parse(init.body as string);
		expect(body).toMatchObject({
			model: "test-model",
			max_tokens: 1,
			stream: false,
		});
		expect(body.messages).toEqual([{ role: "user", content: "hi" }]);
	});

	it("strips trailing slashes from the base URL so user-typed URLs work", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch.mockResolvedValue(new Response("{}", { status: 200 }));
		await probeChatEndpoint({
			baseUrl: "https://api.example/v1///",
			modelId: "x",
		});
		const [url] = mockFetch.mock.calls[0] as [string, RequestInit];
		expect(url).toBe("https://api.example/v1/chat/completions");
	});

	it("forwards extraHeaders (so OpenRouter's HTTP-Referer + X-Title get through)", async () => {
		const mockFetch = global.fetch as ReturnType<typeof vi.fn>;
		mockFetch.mockResolvedValue(new Response("{}", { status: 200 }));
		await probeChatEndpoint({
			baseUrl: "https://openrouter.ai/api/v1",
			modelId: "qwen/qwen3-coder",
			apiKey: "sk-or",
			extraHeaders: { "HTTP-Referer": "https://example.test", "X-Title": "iOmCode" },
		});
		const [, init] = mockFetch.mock.calls[0] as [string, RequestInit];
		const h = init.headers as Record<string, string>;
		expect(h["HTTP-Referer"]).toBe("https://example.test");
		expect(h["X-Title"]).toBe("iOmCode");
		expect(h.Authorization).toBe("Bearer sk-or");
	});
});
