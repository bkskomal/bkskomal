import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
	createOpenAICompatibleProvider,
	extractUpstreamErrorMessage,
	formatStructuredErrorBody,
	parseToolArgsLenient,
	resolveOpenRouterProviderBlock,
} from "../src/openai-compatible";

function mkSseStream(lines: readonly string[]): ReadableStream<Uint8Array> {
	const encoder = new TextEncoder();
	return new ReadableStream({
		start(controller) {
			for (const line of lines) controller.enqueue(encoder.encode(`${line}\n`));
			controller.close();
		},
	});
}

describe("openai-compatible provider", () => {
	const originalFetch = global.fetch;

	beforeEach(() => {
		global.fetch = vi.fn();
	});

	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("yields text_delta events and a clean message_end on a text-only response", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"Hel"}}]}',
					"",
					'data: {"choices":[{"delta":{"content":"lo"}}]}',
					"",
					'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const events: unknown[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "m",
		})) {
			events.push(ev);
		}

		const texts = events
			.filter(
				(e): e is { type: "text_delta"; text: string } => (e as { type: string }).type === "text_delta",
			)
			.map((e) => e.text)
			.join("");
		expect(texts).toBe("Hello");

		const last = events[events.length - 1] as { type: string; stopReason: string };
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("end");
	});

	it("emits a tool_call from a streaming tool_calls delta", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"tc_1","function":{"name":"read_file","arguments":"{\\"pa"}}]}}]}',
					"",
					'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"th\\":\\"x.ts\\"}"}}]}}]}',
					"",
					'data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
		});
		const events: Array<{ type: string; [k: string]: unknown }> = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "m",
		})) {
			events.push(ev as { type: string });
		}

		const call = events.find((e) => e.type === "tool_call");
		expect(call).toBeDefined();
		expect(call?.name).toBe("read_file");
		expect(call?.args).toEqual({ path: "x.ts" });

		const last = events[events.length - 1];
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("tool_use");
	});

	it("yields an error event when the HTTP request fails", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockRejectedValue(new Error("ECONNREFUSED"));

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://nowhere/v1",
		});
		const events: Array<{ type: string; [k: string]: unknown }> = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "m",
		})) {
			events.push(ev as { type: string });
		}

		expect(events[0].type).toBe("error");
		expect(events[events.length - 1].type).toBe("message_end");
		expect(events[events.length - 1].stopReason).toBe("error");
	});

	it("sends the configured extra headers", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: minimal content delta so the provider-level
					// empty-stream retry doesn't fire.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "sk-1",
			extraHeaders: { "HTTP-Referer": "https://example", "X-Custom": "yes" },
		});
		// Drain
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "m",
		})) {
			// no-op
		}

		expect(fetchMock).toHaveBeenCalledOnce();
		const callArgs = fetchMock.mock.calls[0];
		const init = callArgs[1] as RequestInit;
		const headers = init.headers as Record<string, string>;
		expect(headers["HTTP-Referer"]).toBe("https://example");
		expect(headers["X-Custom"]).toBe("yes");
		expect(headers.Authorization).toBe("Bearer sk-1");
	});

	it("maps user image parts to OpenAI image_url content blocks", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					// 2026-05-27: minimal content delta so the provider-level
					// empty-stream retry doesn't fire.
					'data: {"choices":[{"delta":{"content":"ok"}}]}',
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ev of provider.stream({
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "describe" },
						{
							kind: "image",
							mimeType: "image/png",
							dataUrl: "data:image/png;base64,AAAA",
						},
					],
				},
			],
			modelId: "gpt-4o",
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			messages: Array<{ role: string; content: unknown }>;
		};
		const userTurn = body.messages.find((m) => m.role === "user");
		expect(Array.isArray(userTurn?.content)).toBe(true);
		const blocks = userTurn?.content as Array<{
			type: string;
			image_url?: { url: string };
			text?: string;
		}>;
		const image = blocks.find((b) => b.type === "image_url");
		expect(image?.image_url?.url).toBe("data:image/png;base64,AAAA");
		const text = blocks.find((b) => b.type === "text");
		expect(text?.text).toBe("describe");
	});

	// 2026-05-27: provider-level empty-stream retry. When the gateway
	// returns 200 OK + valid SSE envelope but no useful events (no
	// content / tool_calls / reasoning_content), retry the fetch once.
	it("retries the fetch once when the first stream yields no useful content", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock
			.mockResolvedValueOnce(
				new Response(mkSseStream(["data: [DONE]"]), {
					status: 200,
					headers: { "content-type": "text/event-stream" },
				}),
			)
			.mockResolvedValueOnce(
				new Response(
					mkSseStream(['data: {"choices":[{"delta":{"content":"recovered"}}]}', "data: [DONE]"]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});

		const events: { type: string; text?: string }[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "m",
		})) {
			events.push(ev as { type: string; text?: string });
		}

		expect(fetchMock).toHaveBeenCalledTimes(2);
		const texts = events.filter((e) => e.type === "text_delta").map((e) => e.text);
		expect(texts.join("")).toContain("recovered");
	});

	// Caps at ONE retry. If both attempts are empty, message_end fires
	// with the empty result rather than looping forever.
	it("caps at one empty-stream retry; second empty surfaces as empty turn", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(mkSseStream(["data: [DONE]"]), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});

		const events: { type: string }[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "m",
		})) {
			events.push(ev as { type: string });
		}

		expect(fetchMock).toHaveBeenCalledTimes(2);
		expect(events.find((e) => e.type === "message_end")).toBeDefined();
	});
});

describe("parseToolArgsLenient", () => {
	it("parses well-formed JSON strictly", () => {
		expect(parseToolArgsLenient('{"path":"foo.ts"}')).toEqual({ path: "foo.ts" });
	});

	it("repairs literal newlines inside string values", () => {
		// Model emitted a raw \n byte inside the JSON string — strict parse rejects.
		const raw = '{"content":"line1\nline2"}';
		expect(parseToolArgsLenient(raw)).toEqual({ content: "line1\nline2" });
	});

	it("repairs literal tabs and carriage returns inside string values", () => {
		const raw = '{"content":"col1\tcol2\rrow2"}';
		expect(parseToolArgsLenient(raw)).toEqual({ content: "col1\tcol2\rrow2" });
	});

	it("does not touch escaped characters outside strings", () => {
		// Whitespace between tokens is legal — we should not alter it.
		const raw = '{\n  "path": "foo.ts"\n}';
		expect(parseToolArgsLenient(raw)).toEqual({ path: "foo.ts" });
	});

	it("falls back to {_raw} when nothing parses", () => {
		const garbage = "this is not json at all }";
		expect(parseToolArgsLenient(garbage)).toEqual({ _raw: garbage });
	});

	it("respects backslash escapes when deciding whether we are inside a string", () => {
		// Embedded escaped quote should NOT exit string mode mid-repair.
		const raw = '{"content":"he said \\"hi\\"\nnewline"}';
		expect(parseToolArgsLenient(raw)).toEqual({ content: 'he said "hi"\nnewline' });
	});
});

// 2026-05-25 Phase B: integration tests for the inline-XML branch.
// These exercise the full per-request decision: when the model is in
// the inline-xml class, the provider must (a) suppress the `tools`
// array on the wire, (b) inject the XML format description into the
// system prompt, (c) parse `<tool_name>` blocks from the streamed
// text into `tool_call` events.
describe("openai-compatible provider — inline-XML branch (Kimi-class models)", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	function fakeToolSpec(name: string): import("@iom/shared").ToolSpec {
		return {
			name,
			description: `Test tool ${name}`,
			schema: {
				type: "object",
				properties: { path: { type: "string", description: "the path" } },
				required: ["path"],
				additionalProperties: false,
			},
			approval: "auto",
			async handler() {
				return null;
			},
		};
	}

	it("uses inline-XML for an open-weight model (Qwen) — parses tool calls out of text channel", async () => {
		// Single text delta carries a complete tool block.
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream([
						'data: {"choices":[{"delta":{"content":"Reading the file now.\\n<read_file><path>index.html</path></read_file>"}}]}',
						"",
						'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
						"",
						"data: [DONE]",
					]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const events: import("@iom/shared").ProviderStreamEvent[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "look" }] }],
			modelId: "deepseek-coder",
			tools: [fakeToolSpec("read_file")],
			systemPrompt: "You are helpful.",
		})) {
			events.push(ev);
		}
		// Tool call parsed out of the text channel.
		const toolEvents = events.filter((e) => e.type === "tool_call");
		expect(toolEvents).toHaveLength(1);
		expect((toolEvents[0] as { name: string }).name).toBe("read_file");
		expect((toolEvents[0] as { args: Record<string, string> }).args).toEqual({
			path: "index.html",
		});
		// The XML markup is stripped from the user-visible text.
		const textEvents = events.filter((e) => e.type === "text_delta");
		const allText = textEvents.map((e) => (e as { text: string }).text).join("");
		expect(allText).not.toContain("<read_file>");
		expect(allText).toContain("Reading the file now.");
	});

	it("suppresses the wire `tools` array and injects XML prompt for inline-xml models", async () => {
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream([
						'data: {"choices":[{"delta":{"content":"ok"}}]}',
						"",
						'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
						"",
						"data: [DONE]",
					]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "deepseek-coder",
			tools: [fakeToolSpec("read_file"), fakeToolSpec("write_file")],
			systemPrompt: "BASE_PROMPT",
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			tools?: unknown;
			messages: Array<{ role: string; content: unknown }>;
		};
		// `tools` array MUST NOT be present in the wire body for inline-xml.
		expect(body.tools).toBeUndefined();
		// XML format block MUST be injected into the system prompt.
		const sys = body.messages.find((m) => m.role === "system");
		expect(typeof sys?.content).toBe("string");
		expect(sys?.content as string).toContain("BASE_PROMPT");
		expect(sys?.content as string).toContain("Tool use (inline XML format)");
		expect(sys?.content as string).toContain("<read_file>");
		expect(sys?.content as string).toContain("<write_file>");
	});

	it("frontier models (Claude) still use the OpenAI `tools` envelope, NOT inline-xml", async () => {
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream([
						'data: {"choices":[{"delta":{"content":"ok"}}]}',
						"",
						'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
						"",
						"data: [DONE]",
					]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "claude-sonnet-4-6",
			tools: [fakeToolSpec("read_file")],
			systemPrompt: "BASE",
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			tools?: unknown[];
			messages: Array<{ role: string; content: unknown }>;
		};
		// `tools` is present, system prompt does NOT carry the inline-xml block.
		expect(Array.isArray(body.tools)).toBe(true);
		expect((body.tools as unknown[]).length).toBe(1);
		const sys = body.messages.find((m) => m.role === "system");
		expect(sys?.content as string).not.toContain("Tool use (inline XML format)");
	});

	// ---------------------------------------------------------------
	// Kimi-native marker path: Kimi K2 / K2.6 emit `<|tool_call_begin|>`
	// instead of inline-XML or the OpenAI envelope. Public gateways leak
	// those tokens as raw text — we parse them client-side.
	// ---------------------------------------------------------------
	it("parses Kimi-native tool markers from the text channel (full block in one delta)", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					// Tool block split across two deltas to also exercise streaming.
					'data: {"choices":[{"delta":{"content":"Now I will write the file.\\n<|tool_call_begin|>functions.write_file:1<|tool_call_argument_begin|>{\\"path\\":\\"a.ts\\",\\"content\\":\\"x\\"}"}}]}',
					"",
					'data: {"choices":[{"delta":{"content":"<|tool_call_end|><|tool_calls_section_end|>"}}]}',
					"",
					'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const events: import("@iom/shared").ProviderStreamEvent[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "do it" }] }],
			modelId: "moonshotai/kimi-k2",
			tools: [
				{
					name: "write_file",
					description: "write file",
					schema: { type: "object", properties: { path: { type: "string" } } },
					approval: "auto",
					handler: async () => null,
				},
			],
		})) {
			events.push(ev);
		}
		const toolCalls = events.filter((e) => e.type === "tool_call");
		expect(toolCalls).toHaveLength(1);
		expect((toolCalls[0] as { name: string }).name).toBe("write_file");
		expect((toolCalls[0] as { args: Record<string, string> }).args).toEqual({
			path: "a.ts",
			content: "x",
		});
		// Markers must NOT leak through as text.
		const text = events
			.filter((e): e is { type: "text_delta"; text: string } => e.type === "text_delta")
			.map((e) => e.text)
			.join("");
		expect(text).not.toContain("<|tool_call_begin|>");
		expect(text).not.toContain("<|tool_call_end|>");
		expect(text).toContain("Now I will write the file.");
		// stopReason flipped to tool_use so the agent loop knows to execute.
		const last = events[events.length - 1] as { type: string; stopReason: string };
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("tool_use");
	});

	it("Kimi-native path: KEEPS the wire `tools` array (Kimi needs the schema) AND skips the inline-XML prompt addendum", async () => {
		const fetchMock = vi.fn().mockResolvedValue(
			new Response(
				mkSseStream(['data: {"choices":[{"delta":{},"finish_reason":"stop"}]}', "", "data: [DONE]"]),
				{
					status: 200,
					headers: { "content-type": "text/event-stream" },
				},
			),
		);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "moonshotai/kimi-k2",
			tools: [
				{
					name: "write_file",
					description: "write file",
					schema: { type: "object", properties: {} },
					approval: "auto",
					handler: async () => null,
				},
			],
			systemPrompt: "BASE",
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			tools?: unknown;
			messages: Array<{ role: string; content: unknown }>;
		};
		// Wire `tools` array IS present — Kimi was trained on OpenAI-style
		// function schemas and needs them to know what's callable. The
		// kimi-native PARSER (in the agent core) handles the response side
		// for the case where the gateway leaks `<|tool_call_begin|>`
		// markers as text instead of structured tool_calls.
		expect(Array.isArray(body.tools)).toBe(true);
		expect((body.tools as Array<{ function: { name: string } }>)[0].function.name).toBe("write_file");
		// System prompt stays BASE — no inline-XML addendum on the
		// kimi-native path (that's an inline-XML-only thing).
		const sys = body.messages.find((m) => m.role === "system");
		expect(sys?.content as string).toBe("BASE");
		expect(sys?.content as string).not.toContain("Tool use (inline XML format)");
	});

	it("inline-XML tool tags split across SSE chunks still parse cleanly", async () => {
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream([
						'data: {"choices":[{"delta":{"content":"Let me check: <read_fi"}}]}',
						"",
						'data: {"choices":[{"delta":{"content":"le><path>foo.ts</path></read_fi"}}]}',
						"",
						'data: {"choices":[{"delta":{"content":"le></read_file>"}}]}',
						"",
						'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
						"",
						"data: [DONE]",
					]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const toolCalls: Array<{ name: string; args: unknown }> = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "look" }] }],
			modelId: "deepseek-coder",
			tools: [fakeToolSpec("read_file")],
		})) {
			if (ev.type === "tool_call") toolCalls.push({ name: ev.name, args: ev.args });
		}
		expect(toolCalls).toHaveLength(1);
		expect(toolCalls[0].name).toBe("read_file");
		expect(toolCalls[0].args).toEqual({ path: "foo.ts" });
	});

	// ---------------------------------------------------------------
	// Reasoning-model support: DeepSeek-R1 / GPT-o1 / Kimi K2.6 thinking
	// stream their tokens through `delta.reasoning_content` (or
	// `delta.reasoning`) instead of `delta.content`. Without explicit
	// handling, the agent would see zero output and surface the misleading
	// "model returned no output" diagnostic.
	// ---------------------------------------------------------------
	it("surfaces reasoning_content as a dedicated reasoning_delta channel (separate from text_delta)", async () => {
		// 2026-06-01: split from the prior 💭-prefix shape. Provider now emits
		// raw reasoning_delta events so the agent loop can BOTH render them
		// with a 💭 marker AND record a ReasoningPart on the assistant
		// history. Moonshot K2.6 refuses subsequent tool-call turns when the
		// original reasoning_content isn't replayed verbatim.
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"reasoning_content":"Hmm, "}}]}',
					"",
					'data: {"choices":[{"delta":{"reasoning_content":"let me think."}}]}',
					"",
					'data: {"choices":[{"delta":{"content":"42"}}]}',
					"",
					'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);

		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const events: import("@iom/shared").ProviderStreamEvent[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "what is 6×7?" }] }],
			modelId: "deepseek-reasoner",
		})) {
			events.push(ev);
		}
		const reasoning = events
			.filter((e): e is { type: "reasoning_delta"; text: string } => e.type === "reasoning_delta")
			.map((e) => e.text)
			.join("");
		const text = events
			.filter((e): e is { type: "text_delta"; text: string } => e.type === "text_delta")
			.map((e) => e.text)
			.join("");
		expect(reasoning).toBe("Hmm, let me think.");
		// Provider still emits the blank-line separator on the text channel
		// when transitioning from reasoning to answer content.
		expect(text).toBe("\n\n42");
	});

	it("also accepts the `reasoning` field name (some gateways prefer it over `reasoning_content`)", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"reasoning":"thinking..."}}]}',
					"",
					'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const reasoning: string[] = [];
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "go" }] }],
			modelId: "qwen-reasoning",
		})) {
			if (ev.type === "reasoning_delta") reasoning.push(ev.text);
		}
		expect(reasoning.join("")).toBe("thinking...");
	});

	// 2026-05-30: pin the Kimi K2.6 thinking-mode-plus-tool-call interaction.
	// K2.6 has thinking on by default; per Moonshot docs, the response stream
	// can interleave `reasoning_content` (the model thinking aloud) with
	// `<|tool_call_begin|>...` markers in `content` (the model deciding to
	// call a tool). We need: reasoning surfaces on its own reasoning_delta
	// channel AND the Kimi-native parser still catches the tool call from
	// content. Verifying that combo means both paths cooperate cleanly in
	// the same stream.
	it("Kimi K2.6: thinking + native tool call in the same stream — reasoning surfaces, tool call is extracted", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"reasoning_content":"Let me pick a tool."}}]}',
					"",
					'data: {"choices":[{"delta":{"content":"<|tool_call_begin|>functions.write_file:1<|tool_call_argument_begin|>{\\"path\\":\\"x.ts\\",\\"content\\":\\"hi\\"}<|tool_call_end|>"}}]}',
					"",
					'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const texts: string[] = [];
		const reasoning: string[] = [];
		const calls: Array<{ name: string; args: unknown }> = [];
		let stopReason: string | undefined;
		for await (const ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "go" }] }],
			modelId: "moonshotai/kimi-k2", // matches /kimi[-_./]?k2/i → kimi-native toolCallFormat
			tools: [
				{
					name: "write_file",
					description: "writer",
					schema: {
						type: "object",
						properties: { path: { type: "string" }, content: { type: "string" } },
					},
					approval: "auto",
					async handler() {
						return "ok";
					},
				},
			],
		})) {
			if (ev.type === "text_delta") texts.push(ev.text);
			else if (ev.type === "reasoning_delta") reasoning.push(ev.text);
			else if (ev.type === "tool_call") calls.push({ name: ev.name, args: ev.args });
			else if (ev.type === "message_end") stopReason = ev.stopReason;
		}
		// Reasoning surfaced on its own channel; tool-call markers never
		// leaked into either reasoning or text.
		expect(reasoning.join("")).toBe("Let me pick a tool.");
		expect(texts.join("")).not.toContain("<|tool_call_begin|>");
		expect(reasoning.join("")).not.toContain("<|tool_call_begin|>");
		// Kimi-native parser extracted the tool call from content.
		expect(calls).toHaveLength(1);
		expect(calls[0].name).toBe("write_file");
		expect(calls[0].args).toMatchObject({ path: "x.ts", content: "hi" });
		// stopReason must NOT downgrade to "end" just because the gateway
		// reported finish_reason="stop" — the inline parser's tool_use wins.
		expect(stopReason).toBe("tool_use");
	});

	it("Kimi K2.6: never sends tool_choice in the request body (must default to 'auto' for thinking mode)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"hi"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "go" }] }],
			modelId: "moonshotai/kimi-k2",
			tools: [
				{
					name: "write_file",
					description: "writer",
					schema: { type: "object", properties: { path: { type: "string" } } },
					approval: "auto",
					async handler() {
						return "ok";
					},
				},
			],
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		// Per Moonshot K2.6 docs: when thinking mode is enabled (default),
		// tool_choice MUST be "auto" or "none". The safest path is to never
		// send the field at all so the server applies its default. This
		// regression test fails if anyone later adds tool_choice: "required"
		// or similar.
		expect(body.tool_choice).toBeUndefined();
	});

	// 2026-06-01: Moonshot K2.6 thinking mode is stateful. If the assistant
	// emitted reasoning_content on turn N and we replay that turn's history
	// on turn N+1 without echoing the same reasoning_content back, the API
	// refuses with `thinking is enabled but reasoning_content is missing
	// in assistant tool call message at index N [stream_failed]`. The
	// ReasoningPart on the conversation history is the round-trip vehicle;
	// this test pins that toWireMessages emits the field.
	it("round-trips ReasoningPart as `reasoning_content` on assistant wire messages (Kimi K2.6 thinking-mode replay)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "go" }] },
				{
					role: "assistant",
					parts: [
						{ kind: "reasoning", text: "Hmm, " },
						{ kind: "reasoning", text: "let me check the file." },
						{ kind: "tool_call", id: "call_1", name: "read_file", args: { path: "a.ts" } },
					],
				},
				{ role: "tool", parts: [{ kind: "tool_result", id: "call_1", output: "x", isError: false }] },
				{ role: "user", parts: [{ kind: "text", text: "thanks" }] },
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const assistantMsg = body.messages.find((m: { role: string }) => m.role === "assistant");
		expect(assistantMsg).toBeDefined();
		// All reasoning chunks concatenated into one reasoning_content string.
		expect(assistantMsg.reasoning_content).toBe("Hmm, let me check the file.");
		// Tool call still present on the same message (reasoning rides alongside).
		expect(assistantMsg.tool_calls).toHaveLength(1);
		expect(assistantMsg.tool_calls[0].function.name).toBe("read_file");
		// Reasoning text MUST NOT leak into content — that would be visible to
		// the model as if it were the assistant's spoken answer.
		expect(assistantMsg.content == null || assistantMsg.content === "").toBe(true);
	});

	// 2026-06-01 live-bug: an upstream tool_call event arrived with an
	// empty id; that empty string propagated to a tool_result; the next
	// turn's wire request failed with `tool_call_id  is not found`. The
	// agent-core layer synthesizes a fallback id at ingestion, but
	// toWireMessages also filters empty ids as defense in depth (for
	// sessions loaded from disk that already contain corruption).
	it("drops tool_results with empty ids before serializing (defense in depth)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "go" }] },
				{
					role: "assistant",
					parts: [{ kind: "tool_call", id: "call_real", name: "echo", args: {} }],
				},
				{
					role: "tool",
					parts: [
						// Empty-id tool_result — must be dropped before send.
						{ kind: "tool_result", id: "", output: "stale", isError: false },
						// Valid one — must survive.
						{ kind: "tool_result", id: "call_real", output: "ok", isError: false },
					],
				},
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const toolMsgs = body.messages.filter((m: { role: string }) => m.role === "tool");
		// Only the valid tool message survives.
		expect(toolMsgs).toHaveLength(1);
		expect(toolMsgs[0].tool_call_id).toBe("call_real");
	});

	it("drops assistant tool_calls with empty ids (matching filter on the other side of the pair)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "go" }] },
				{
					role: "assistant",
					parts: [
						{ kind: "tool_call", id: "", name: "broken", args: {} },
						{ kind: "tool_call", id: "real_call", name: "echo", args: {} },
					],
				},
				{
					role: "tool",
					parts: [{ kind: "tool_result", id: "real_call", output: "ok", isError: false }],
				},
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const assistantMsg = body.messages.find((m: { role: string }) => m.role === "assistant");
		// Only the valid tool_call rides on the wire.
		expect(assistantMsg.tool_calls).toHaveLength(1);
		expect(assistantMsg.tool_calls[0].id).toBe("real_call");
	});

	// 2026-06-03 live-bug: a long session got stuck on `tool_call_id  is
	// not found` (note empty id rendering in the upstream error). Root
	// cause was a model-emitted tool_call with empty FUNCTION NAME — the
	// prior wire filter only checked id, not name. The upstream's
	// validator either rejects the empty-name call or fails to register
	// the id, then the paired tool_result looks orphan-on-the-wire.
	it("drops assistant tool_calls with empty function names (treats them as malformed)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "go" }] },
				{
					role: "assistant",
					parts: [
						// Empty function name — upstream considers this malformed.
						{ kind: "tool_call", id: ":0", name: "", args: {} },
						{ kind: "tool_call", id: "real_call", name: "echo", args: {} },
					],
				},
				{
					role: "tool",
					parts: [
						{ kind: "tool_result", id: ":0", output: "stale", isError: false },
						{ kind: "tool_result", id: "real_call", output: "ok", isError: false },
					],
				},
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const assistantMsg = body.messages.find((m: { role: string }) => m.role === "assistant");
		expect(assistantMsg.tool_calls).toHaveLength(1);
		expect(assistantMsg.tool_calls[0].id).toBe("real_call");
	});

	it("drops orphan tool_results when their matching assistant tool_call was filtered out", async () => {
		// This pins the wire-side coordination: if an assistant tool_call
		// gets dropped for ANY reason (empty id, empty name), the paired
		// tool_result must also drop. Otherwise the wire body ships with
		// an orphan tool_call_id that the upstream can't match.
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "go" }] },
				{
					role: "assistant",
					parts: [
						// Both calls have non-empty id+name BUT the FIRST gets dropped
						// by the empty-name guard; the assistant survives with only
						// the second. The first tool_result must NOT ship on the wire.
						{ kind: "tool_call", id: "drop_me", name: "", args: {} },
						{ kind: "tool_call", id: "keep_me", name: "echo", args: {} },
					],
				},
				{
					role: "tool",
					parts: [
						{ kind: "tool_result", id: "drop_me", output: "x", isError: false },
						{ kind: "tool_result", id: "keep_me", output: "ok", isError: false },
					],
				},
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const toolMsgs = body.messages.filter((m: { role: string }) => m.role === "tool");
		// Only the kept tool_result survives — orphan filtered out.
		expect(toolMsgs).toHaveLength(1);
		expect(toolMsgs[0].tool_call_id).toBe("keep_me");
	});

	it("omits reasoning_content on assistant wire messages when the history has no ReasoningPart", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "go" }] },
				{ role: "assistant", parts: [{ kind: "text", text: "done" }] },
				{ role: "user", parts: [{ kind: "text", text: "thanks" }] },
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const assistantMsg = body.messages.find((m: { role: string }) => m.role === "assistant");
		expect(assistantMsg.reasoning_content).toBeUndefined();
	});

	// 2026-06-01: image-history pruning. Live-bug — a fullPage screenshot
	// hit 950k requested tokens vs 262k cap because every prior screenshot
	// replayed on every turn. The wire-serializer keeps only the MOST
	// recent image-bearing user message; earlier images get a breadcrumb.
	// The stored history is untouched so the chat-bubble UX still shows
	// every screenshot the user took.
	it("prunes stale ImageParts: only the most-recent image-bearing user message rides on the wire", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const tinyPng = "data:image/png;base64,AAAA";
		for await (const _ of provider.stream({
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "first screenshot" },
						{ kind: "image", mimeType: "image/png", dataUrl: tinyPng },
					],
				},
				{ role: "assistant", parts: [{ kind: "text", text: "ok" }] },
				{
					role: "user",
					parts: [
						{ kind: "text", text: "second screenshot" },
						{ kind: "image", mimeType: "image/png", dataUrl: tinyPng },
					],
				},
				{ role: "assistant", parts: [{ kind: "text", text: "ok" }] },
				{
					role: "user",
					parts: [
						{ kind: "text", text: "third screenshot" },
						{ kind: "image", mimeType: "image/png", dataUrl: tinyPng },
					],
				},
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const userMsgs = body.messages.filter((m: { role: string }) => m.role === "user");
		expect(userMsgs).toHaveLength(3);
		// First two messages get the breadcrumb; their image_url payloads
		// are stripped. Content shape collapses back to a plain string.
		expect(typeof userMsgs[0].content).toBe("string");
		expect(userMsgs[0].content).toContain("first screenshot");
		expect(userMsgs[0].content).toContain("earlier screenshot");
		expect(userMsgs[0].content).toContain("hidden");
		expect(typeof userMsgs[1].content).toBe("string");
		expect(userMsgs[1].content).toContain("second screenshot");
		expect(userMsgs[1].content).toContain("earlier screenshot");
		// Last message keeps the image as a multi-part content array.
		expect(Array.isArray(userMsgs[2].content)).toBe(true);
		const imageBlocks = (userMsgs[2].content as Array<{ type: string }>).filter(
			(b) => b.type === "image_url",
		);
		expect(imageBlocks).toHaveLength(1);
	});

	it("leaves a single image-bearing message untouched (no pruning when there's only one)", async () => {
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "only screenshot" },
						{ kind: "image", mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" },
					],
				},
			],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const [, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		const body = JSON.parse((init.body as string) ?? "{}");
		const userMsg = body.messages.find((m: { role: string }) => m.role === "user");
		expect(Array.isArray(userMsg.content)).toBe(true);
		const imageBlocks = (userMsg.content as Array<{ type: string }>).filter(
			(b) => b.type === "image_url",
		);
		expect(imageBlocks).toHaveLength(1);
	});
});

describe("resolveOpenRouterProviderBlock", () => {
	it("injects default routing for OpenRouter + Kimi K2 (moonshotai first for K2.6 vision support, lowercase slugs)", () => {
		expect(
			resolveOpenRouterProviderBlock("https://openrouter.ai/api/v1", "moonshotai/kimi-k2", undefined),
		).toEqual({
			order: ["moonshotai", "fireworks", "together", "novita", "siliconflow"],
			require_parameters: true,
			allow_fallbacks: true,
		});
	});

	it("moonshotai is the FIRST preference — fixes K2.6 vision empty-stream fallout from third-party providers that haven't shipped vision yet", () => {
		// 2026-06-01 regression guard: live trace showed image-bearing
		// requests returning empty SSE because the OR router landed on a
		// non-vision K2.6 endpoint. moonshotai (Moonshot's own first-
		// party provider on OR) supports everything its model can do, so
		// it MUST stay first in the order. OR provider slugs are
		// lowercase per their API docs.
		const block = resolveOpenRouterProviderBlock(
			"https://openrouter.ai/api/v1",
			"moonshotai/kimi-k2-instruct-0925",
			undefined,
		);
		expect(block?.order?.[0]).toBe("moonshotai");
		// And the other tool-F1-optimized providers stay as fallbacks so
		// text-only turns still get the original routing benefits when
		// moonshotai is unavailable.
		expect(block?.allow_fallbacks).toBe(true);
		expect(block?.order).toContain("fireworks");
	});

	it("HARD-PINS to moonshotai with no fallbacks when the request has image input", () => {
		// 2026-06-01: image-bearing requests can't tolerate silent fallback
		// to a provider that doesn't ship K2.6 vision. Using `only` + no
		// fallback makes any vision failure surface as an explicit error
		// instead of empty SSE.
		const block = resolveOpenRouterProviderBlock(
			"https://openrouter.ai/api/v1",
			"moonshotai/kimi-k2",
			undefined,
			{ hasImageInput: true },
		);
		expect(block?.only).toEqual(["moonshotai"]);
		expect(block?.allow_fallbacks).toBe(false);
		expect(block?.order).toBeUndefined();
	});

	it("text-only requests keep the soft `order` routing (no `only` pin)", () => {
		const block = resolveOpenRouterProviderBlock(
			"https://openrouter.ai/api/v1",
			"moonshotai/kimi-k2",
			undefined,
			{ hasImageInput: false },
		);
		expect(block?.only).toBeUndefined();
		expect(block?.order?.[0]).toBe("moonshotai");
		expect(block?.allow_fallbacks).toBe(true);
	});

	it("returns undefined for non-OpenRouter endpoints (self-hosted vLLM, Moonshot direct)", () => {
		expect(
			resolveOpenRouterProviderBlock("https://vllm.internal/v1", "moonshotai/kimi-k2", undefined),
		).toBeUndefined();
		expect(
			resolveOpenRouterProviderBlock("https://api.moonshot.cn/v1", "kimi-k2", undefined),
		).toBeUndefined();
	});

	it("returns undefined for non-Kimi models on OpenRouter (Claude, GPT, Gemini routed elsewhere)", () => {
		expect(
			resolveOpenRouterProviderBlock(
				"https://openrouter.ai/api/v1",
				"anthropic/claude-sonnet-4-6",
				undefined,
			),
		).toBeUndefined();
	});

	it("respects an explicit override block", () => {
		const custom = { only: ["Fireworks"], allow_fallbacks: false };
		expect(
			resolveOpenRouterProviderBlock("https://openrouter.ai/api/v1", "moonshotai/kimi-k2", custom),
		).toEqual(custom);
	});

	it("returns undefined when routing is explicitly disabled (null)", () => {
		expect(
			resolveOpenRouterProviderBlock("https://openrouter.ai/api/v1", "moonshotai/kimi-k2", null),
		).toBeUndefined();
	});

	it("matches all Kimi K2 model id variants (k2, k2-instruct, k2-0905, K2.6, etc.)", () => {
		const ids = [
			"moonshotai/kimi-k2",
			"moonshotai/kimi-k2-instruct",
			"moonshotai/kimi-k2-0905",
			"moonshotai/kimi-k2.6",
			"Kimi-K2-Thinking",
			"kimi_k2",
		];
		for (const id of ids) {
			const block = resolveOpenRouterProviderBlock("https://openrouter.ai/api/v1", id, undefined);
			expect(block, `expected routing for ${id}`).toBeDefined();
		}
	});

	it("end-to-end: provider block lands in the wire body for OpenRouter + Kimi K2", async () => {
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream(['data: {"choices":[{"delta":{},"finish_reason":"stop"}]}', "", "data: [DONE]"]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "or",
			displayName: "OpenRouter",
			baseUrl: "https://openrouter.ai/api/v1",
			apiKey: "k",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			provider?: { order?: string[]; require_parameters?: boolean };
		};
		expect(body.provider).toBeDefined();
		expect(body.provider?.order).toContain("fireworks");
		expect(body.provider?.order?.[0]).toBe("moonshotai");
		expect(body.provider?.require_parameters).toBe(true);
	});

	it("end-to-end: no provider block injected for self-hosted vLLM (non-OR baseUrl)", async () => {
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream(['data: {"choices":[{"delta":{},"finish_reason":"stop"}]}', "", "data: [DONE]"]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "vllm",
			displayName: "Self-hosted vLLM",
			baseUrl: "https://vllm.internal/v1",
			apiKey: "k",
		});
		for await (const _ev of provider.stream({
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
			modelId: "moonshotai/kimi-k2",
		})) {
			// drain
		}
		const body = JSON.parse(fetchMock.mock.calls[0][1]?.body as string) as {
			provider?: unknown;
		};
		expect(body.provider).toBeUndefined();
	});
});

// 2026-06-01: end-to-end image-bearing K2.6 request verification.
// User reported continued empty-stream symptom after the lowercase + only:[moonshotai] commit.
// This suite EXERCISES the full request pipeline an image paste would hit and asserts
// the wire body matches what we believe Kimi K2.6 expects:
//   - messages contain a user role whose content is an array with {type:"image_url",image_url:{url:"data:..."}}
//   - provider block has only:["moonshotai"] + allow_fallbacks:false
//   - the routing diagnostic is yielded with the correct provider name
//
// If any of these assertions fail the user's runtime trace is explained without needing
// another reload-and-paste cycle from them.
describe("end-to-end image-bearing K2.6 request (live-bug verification)", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	const TINY_PNG =
		"iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
	const TINY_PNG_DATA_URL = `data:image/png;base64,${TINY_PNG}`;

	it("builds the wire body Kimi K2.6 on OpenRouter MoonshotAI expects when the user attaches an image", async () => {
		const fetchMock = vi.fn().mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"I see a screenshot of a settings panel."},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{
					status: 200,
					headers: {
						"content-type": "text/event-stream",
						"openrouter-provider-name": "MoonshotAI",
						"openrouter-cost": "0.0023",
						"openrouter-generation-id": "gen-abc123",
					},
				},
			),
		);
		global.fetch = fetchMock;

		const provider = createOpenAICompatibleProvider({
			id: "or",
			displayName: "OpenRouter",
			baseUrl: "https://openrouter.ai/api/v1",
			apiKey: "k",
		});

		const diagnostics: string[] = [];
		const texts: string[] = [];
		for await (const ev of provider.stream({
			modelId: "moonshotai/kimi-k2",
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "what are you seeing in screen shot?" },
						{ kind: "image", mimeType: "image/png", dataUrl: TINY_PNG_DATA_URL },
					],
				},
			],
		})) {
			if (ev.type === "text_delta") texts.push(ev.text);
			else if (ev.type === "error") diagnostics.push(ev.message);
		}

		// 1. The request was sent.
		expect(fetchMock).toHaveBeenCalledTimes(1);
		const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];

		// 2. Hit OpenRouter's chat/completions endpoint.
		expect(url).toBe("https://openrouter.ai/api/v1/chat/completions");

		const body = JSON.parse((init.body as string) ?? "{}") as {
			model: string;
			messages: Array<{ role: string; content: unknown }>;
			provider?: {
				only?: string[];
				order?: string[];
				allow_fallbacks?: boolean;
				require_parameters?: boolean;
			};
		};

		// 3. Model id was preserved (no rewriting downstream).
		expect(body.model).toBe("moonshotai/kimi-k2");

		// 4. The user message landed as a content ARRAY (not a string) — that's how
		//    OpenAI-compatible APIs (and OR's MoonshotAI adapter) recognise multimodal input.
		const userMsg = body.messages.find((m) => m.role === "user");
		expect(userMsg).toBeDefined();
		expect(Array.isArray(userMsg?.content)).toBe(true);
		const blocks = userMsg?.content as Array<{
			type: string;
			image_url?: { url: string };
			text?: string;
		}>;

		// 5. The image is present as {type:"image_url", image_url:{url:"data:image/png;base64,..."}}.
		//    Per Moonshot's K2.6 docs: "URL-formatted images are not supported, currently only
		//    base64-encoded image content is supported" — a data: URL with base64 IS the
		//    base64-encoded form. The OpenAI envelope is the standard wrapper.
		const imageBlock = blocks.find((b) => b.type === "image_url");
		expect(imageBlock).toBeDefined();
		expect(imageBlock?.image_url?.url).toBe(TINY_PNG_DATA_URL);
		expect(imageBlock?.image_url?.url).toMatch(/^data:image\/png;base64,/);

		// 6. The text part also rides as a text block (not lost).
		const textBlock = blocks.find((b) => b.type === "text");
		expect(textBlock?.text).toContain("what are you seeing");

		// 7. The provider block hard-pins to moonshotai for image-bearing requests.
		expect(body.provider).toBeDefined();
		expect(body.provider?.only).toEqual(["moonshotai"]);
		expect(body.provider?.allow_fallbacks).toBe(false);
		expect(body.provider?.order).toBeUndefined();
		expect(body.provider?.require_parameters).toBe(true);

		// 8. The provider-routing diagnostic was emitted with the correct content.
		// Universal format (2026-06-01): fires for every endpoint, prefixed
		// `[provider-routing] host=... model=... status=... ...`.
		const routingDiag = diagnostics.find((d) => d.startsWith("[provider-routing]"));
		expect(routingDiag).toBeDefined();
		expect(routingDiag).toContain("host=openrouter.ai");
		expect(routingDiag).toContain("model=moonshotai/kimi-k2");
		expect(routingDiag).toContain("status=200");
		expect(routingDiag).toContain("image-bearing");
		expect(routingDiag).toContain("or-provider=MoonshotAI");
		expect(routingDiag).toContain("or-gen=gen-abc123");

		// 9. The actual response content was decoded and yielded.
		expect(texts.join("")).toContain("I see a screenshot of a settings panel");
	});

	it("DOES NOT pin to moonshotai when the SAME model is used for a text-only turn (preserves throughput for the common case)", async () => {
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream([
						'data: {"choices":[{"delta":{"content":"ok"},"finish_reason":"stop"}]}',
						"",
						"data: [DONE]",
					]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "or",
			displayName: "OpenRouter",
			baseUrl: "https://openrouter.ai/api/v1",
			apiKey: "k",
		});
		for await (const _ of provider.stream({
			modelId: "moonshotai/kimi-k2",
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
		})) {
			// drain
		}
		const body = JSON.parse((fetchMock.mock.calls[0][1] as RequestInit).body as string) as {
			provider?: { only?: string[]; order?: string[]; allow_fallbacks?: boolean };
		};
		// Soft routing — order list, fallbacks allowed.
		expect(body.provider?.only).toBeUndefined();
		expect(body.provider?.order?.[0]).toBe("moonshotai");
		expect(body.provider?.allow_fallbacks).toBe(true);
	});
});

// 2026-06-01: upstream-error-envelope detection. When a gateway returns
// HTTP 200 + a `{"error": ...}` SSE payload (LiteLLM stream_failed,
// Moonshot direct error, etc.), surface the actual message instead of
// retrying twice and showing the generic "empty-response" diagnostic.
describe("extractUpstreamErrorMessage", () => {
	it("returns undefined when the error object is missing or malformed", () => {
		expect(extractUpstreamErrorMessage(undefined)).toBeUndefined();
		expect(extractUpstreamErrorMessage(null)).toBeUndefined();
		expect(extractUpstreamErrorMessage("not an object")).toBeUndefined();
		expect(extractUpstreamErrorMessage({})).toBeUndefined();
	});

	it("returns a plain Moonshot-style error message + code", () => {
		const out = extractUpstreamErrorMessage({
			message: "Rate limit exceeded",
			code: 429,
		});
		expect(out).toBe("Rate limit exceeded (code=429)");
	});

	it("unwraps the LiteLLM nested envelope and returns the inner message + both codes", () => {
		// The EXACT shape from the user's live trace (2026-06-01): LiteLLM
		// wrapped Moonshot's "No endpoints" error in stream_failed.
		const out = extractUpstreamErrorMessage({
			code: "stream_failed",
			message: JSON.stringify({
				error: { message: "No endpoints found that support image input", code: 404 },
			}),
		});
		expect(out).toBe("No endpoints found that support image input (code=404) [stream_failed]");
	});

	it("falls back to the outer message when JSON unwrap fails", () => {
		const out = extractUpstreamErrorMessage({
			code: "internal_error",
			message: "{not actually JSON",
		});
		expect(out).toContain("{not actually JSON");
		expect(out).toContain("code=internal_error");
	});

	it("truncates extremely long outer messages so the chat surface stays readable", () => {
		const longMessage = "x".repeat(2000);
		const out = extractUpstreamErrorMessage({ message: longMessage });
		expect(out?.length).toBeLessThanOrEqual(550);
		expect(out).toMatch(/…$/);
	});

	it("omits the code suffix when no code is present", () => {
		const out = extractUpstreamErrorMessage({ message: "Something went wrong" });
		expect(out).toBe("Something went wrong");
	});

	it("unwraps shape C — iOmCode LLM Gateway 2026-06-01 incompatible_route with hint + missing_capabilities", () => {
		// The new structured pre-flight envelope from the iOmCode LLM Gateway.
		// The `hint` field is the most actionable thing we can show — surface
		// it on its own line with a 💡 marker so the user sees the fix path.
		const err = {
			type: "incompatible_route",
			code: 400,
			message: "Model 'moonshotai/kimi-k2.6' doesn't support: ['vision']",
			virtual_model: "moonshotai/kimi-k2.6",
			missing_capabilities: ["vision"],
			hint:
				"Add `capabilities: [vision]` to the route's YAML entry AND ensure its `litellm_params.model` points at an actual vision-capable backend.",
		};
		const out = extractUpstreamErrorMessage(err);
		expect(out).toBeDefined();
		// Headline (message) is present.
		expect(out).toContain("doesn't support: ['vision']");
		// Missing capabilities listed.
		expect(out).toContain("Missing capabilities: vision");
		// Hint surfaced with the 💡 marker.
		expect(out).toContain("💡");
		expect(out).toContain("Add `capabilities: [vision]`");
		// Code suffix at the end.
		expect(out).toContain("(code=400)");
	});

	it("shape C: includes the hint even when the message field is empty", () => {
		const out = extractUpstreamErrorMessage({
			type: "incompatible_route",
			missing_capabilities: ["vision"],
			hint: "Fix your gateway config",
		});
		expect(out).toContain("Missing capabilities: vision");
		expect(out).toContain("💡 Fix your gateway config");
	});

	it("shape C with a JSON-stringified message unwraps the inner headline AND keeps the hint", () => {
		// If a gateway sends a shape-B-style nested envelope inside a shape-C
		// wrapper (some older versions might), we unwrap the inner message
		// for a clean headline AND surface the hint. Both signals appear,
		// neither one is buried in raw JSON.
		const out = extractUpstreamErrorMessage({
			type: "incompatible_route",
			code: 400,
			message: '{"error":{"message":"inner stuff","code":404}}',
			hint: "Do the thing",
		});
		expect(out).toContain("inner stuff");
		expect(out).toContain("💡 Do the thing");
		// Critically the RAW JSON string is NOT in the output — we unwrapped it.
		expect(out).not.toContain('{"error":');
	});
});

describe("formatStructuredErrorBody", () => {
	it("returns undefined for empty body or non-JSON body", () => {
		expect(formatStructuredErrorBody("")).toBeUndefined();
		expect(formatStructuredErrorBody("plain text body")).toBeUndefined();
		expect(formatStructuredErrorBody("404 Not Found")).toBeUndefined();
	});

	it("returns undefined for JSON without an `error` field", () => {
		expect(formatStructuredErrorBody('{"ok":true}')).toBeUndefined();
		expect(formatStructuredErrorBody("[1,2,3]")).toBeUndefined();
	});

	it("formats the iOmCode Gateway incompatible_route HTTP 400 body", () => {
		const body = JSON.stringify({
			error: {
				type: "incompatible_route",
				code: 400,
				message: "Model 'moonshotai/kimi-k2.6' doesn't support: ['vision']",
				virtual_model: "moonshotai/kimi-k2.6",
				missing_capabilities: ["vision"],
				hint: "Add `capabilities: [vision]` to the route's YAML.",
			},
		});
		const out = formatStructuredErrorBody(body);
		expect(out).toBeDefined();
		expect(out).toContain("doesn't support: ['vision']");
		expect(out).toContain("Missing capabilities: vision");
		expect(out).toContain("💡");
	});

	it("returns undefined when JSON.parse throws", () => {
		expect(formatStructuredErrorBody("{not valid json")).toBeUndefined();
	});
});

describe("openai-compatible provider — HTTP 4xx structured-error body (pre-flight refusals)", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("renders the gateway's hint when an HTTP 400 incompatible_route is returned", async () => {
		// 2026-06-01: iOmCode LLM Gateway pre-flight refusal. The body carries
		// the structured envelope with `hint`; we must surface the hint
		// instead of dumping the raw JSON into the chat as a stringified body.
		const errBody = JSON.stringify({
			error: {
				type: "incompatible_route",
				code: 400,
				message: "Model 'moonshotai/kimi-k2.6' doesn't support: ['vision']",
				virtual_model: "moonshotai/kimi-k2.6",
				missing_capabilities: ["vision"],
				hint:
					"Add `capabilities: [vision]` to the route's YAML entry AND ensure its `litellm_params.model` points at an actual vision-capable backend.",
			},
		});
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(errBody, { status: 400, headers: { "content-type": "application/json" } }),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "iom-gateway",
			displayName: "iOmCode Gateway",
			baseUrl: "http://localhost:4000/v1",
			apiKey: "sk-test",
		});
		const events: Array<{ type: string; message?: string; stopReason?: string }> = [];
		for await (const ev of provider.stream({
			modelId: "moonshotai/kimi-k2.6",
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "describe this image" },
						{ kind: "image", mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" },
					],
				},
			],
		})) {
			events.push(ev as { type: string });
		}
		expect(fetchMock).toHaveBeenCalledTimes(1);
		const errEv = events.find((e) => e.type === "error");
		expect(errEv).toBeDefined();
		// The hint with 💡 marker is present.
		expect(errEv?.message).toContain("💡");
		expect(errEv?.message).toContain("Add `capabilities: [vision]`");
		// Missing capabilities listed.
		expect(errEv?.message).toContain("Missing capabilities: vision");
		// The raw stringified body should NOT be present — we formatted it nicely.
		expect(errEv?.message).not.toMatch(/^iOmCode Gateway HTTP 400/);
		// Terminal event.
		const last = events[events.length - 1];
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("error");
	});

	it("falls back to the legacy HTTP error format for non-structured 4xx bodies", async () => {
		// A plain text body or unstructured JSON should keep the existing
		// "DisplayName HTTP <status>: <body>" format.
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response("Unauthorized", { status: 401, headers: { "content-type": "text/plain" } }),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
			apiKey: "k",
		});
		const events: Array<{ type: string; message?: string }> = [];
		for await (const ev of provider.stream({
			modelId: "m",
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
		})) {
			events.push(ev as { type: string });
		}
		const errEv = events.find((e) => e.type === "error");
		expect(errEv?.message).toContain("X HTTP 401");
		expect(errEv?.message).toContain("Unauthorized");
	});
});

describe("openai-compatible provider — SSE error-envelope short-circuit", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("yields a clear error event and STOPS retrying when the upstream embeds a stream_failed envelope (LiteLLM live-bug)", async () => {
		// Replays the EXACT 213-byte payload from the user's trace.
		// Previously we treated this as "no useful content" and retried
		// twice before giving up with a generic empty-response message.
		// New behavior: see the error, yield it, stop. ZERO retries.
		const errorPayload =
			'{"error": {"code": "stream_failed", "message": "{\\"error\\":{\\"message\\":\\"No endpoints found that support image input\\",\\"code\\":404}}", "request_id": "653f9da6-..."}}';
		const fetchMock = vi.fn().mockResolvedValue(
			new Response(mkSseStream([`data: ${errorPayload}`, "", "data: [DONE]"]), {
				status: 200,
				headers: { "content-type": "text/event-stream" },
			}),
		);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "litellm",
			displayName: "LiteLLM Gateway",
			baseUrl: "http://localhost:4000/v1",
			apiKey: "sk-test",
		});
		const events: Array<{ type: string; message?: string; stopReason?: string }> = [];
		for await (const ev of provider.stream({
			modelId: "moonshotai/kimi-k2.6",
			messages: [
				{
					role: "user",
					parts: [
						{ kind: "text", text: "describe" },
						{ kind: "image", mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" },
					],
				},
			],
		})) {
			events.push(ev as { type: string });
		}
		// Exactly ONE fetch — no retries on upstream error.
		expect(fetchMock).toHaveBeenCalledTimes(1);
		// The terminal error event surfaces the unwrapped human message.
		const errorEv = events.find(
			(e) => e.type === "error" && e.message?.startsWith("Upstream provider error:"),
		);
		expect(errorEv).toBeDefined();
		expect(errorEv?.message).toContain("No endpoints found that support image input");
		expect(errorEv?.message).toContain("code=404");
		expect(errorEv?.message).toContain("[stream_failed]");
		// And the stream ends with error stopReason.
		const last = events[events.length - 1];
		expect(last.type).toBe("message_end");
		expect(last.stopReason).toBe("error");
	});

	it("does NOT short-circuit on normal SSE content that happens to include an `error` substring", async () => {
		// Defensive case: a regular content delta that contains the word
		// "error" or even an error-shaped JSON inside the message text
		// must NOT trigger the short-circuit — only top-level
		// `{"error":{...}}` SSE payloads do.
		const fetchMock = vi
			.fn()
			.mockResolvedValue(
				new Response(
					mkSseStream([
						'data: {"choices":[{"delta":{"content":"Hi! There was no error."},"finish_reason":"stop"}]}',
						"",
						"data: [DONE]",
					]),
					{ status: 200, headers: { "content-type": "text/event-stream" } },
				),
			);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "x",
			displayName: "X",
			baseUrl: "http://test/v1",
		});
		const texts: string[] = [];
		for await (const ev of provider.stream({
			modelId: "m",
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
		})) {
			if (ev.type === "text_delta") texts.push(ev.text);
		}
		expect(texts.join("")).toContain("There was no error");
	});
});

// 2026-06-16: Gemma 4 and Qwen 3 Coder on the iOmCode vLLM gateway route
// through /v1/completions (raw text-in / text-out) instead of
// /v1/chat/completions. The gateway has no tokenizer chat_template AND
// blocks request-side templates via `--trust-request-chat-template`,
// so the completions endpoint is the only path that doesn't need
// gateway-side changes. Kimi/Claude/GPT/gpt-oss continue to use
// /v1/chat/completions — that codepath MUST stay untouched.
describe("useCompletionsFallback quirk — Gemma + Qwen vLLM workaround", () => {
	beforeEach(() => {
		const fetchMock = vi.fn();
		// text_completion stream shape (different from chat.completion delta shape).
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"text":"ok","finish_reason":null}]}',
					"",
					'data: {"choices":[{"text":" then","finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		global.fetch = fetchMock;
	});

	it("Gemma 4 — POSTs to /v1/completions with a rendered Gemma-shaped prompt", async () => {
		const provider = createOpenAICompatibleProvider({
			id: "g",
			displayName: "G",
			baseUrl: "http://test/v1",
		});
		const chunks: string[] = [];
		for await (const ev of provider.stream({
			modelId: "google/gemma-4-26B-A4B",
			systemPrompt: "you are coding assistant",
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "list .ts files" }] },
				{
					role: "assistant",
					parts: [
						{ kind: "text", text: "calling list_dir" },
						{ kind: "tool_call", id: "c1", name: "list_dir", args: { path: "." } },
					],
				},
				{
					role: "tool",
					parts: [{ kind: "tool_result", id: "c1", output: "a.ts\nb.ts", isError: false }],
				},
				{ role: "user", parts: [{ kind: "text", text: "thanks" }] },
			],
		})) {
			if (ev.type === "text_delta") chunks.push(ev.text);
		}
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		// Endpoint switched.
		expect(url).toBe("http://test/v1/completions");
		const body = JSON.parse((init.body as string) ?? "{}");
		// Raw prompt string, no messages array.
		expect(body.messages).toBeUndefined();
		expect(typeof body.prompt).toBe("string");
		// Gemma turn markers present in the rendered prompt.
		expect(body.prompt).toContain("<start_of_turn>user");
		expect(body.prompt).toContain("<start_of_turn>model");
		expect(body.prompt).toContain("<end_of_turn>");
		// System prompt folds into the first user turn.
		expect(body.prompt).toContain("you are coding assistant");
		// Tool result + assistant tool-call survived as inline text within
		// the prompt (because flatten ran upstream).
		expect(body.prompt).toContain("[Calling tool list_dir");
		expect(body.prompt).toContain("Tool result");
		expect(body.prompt).toContain("a.ts");
		// Stop sequence includes the Gemma end-of-turn marker.
		expect(body.stop).toContain("<end_of_turn>");
		// chat_template field is NOT sent (would trip the trust-request guard).
		expect(body.chat_template).toBeUndefined();
		// Streamed text decoded.
		expect(chunks.join("")).toBe("ok then");
	});

	it("Qwen 3 Coder — POSTs to /v1/completions with a ChatML-shaped prompt", async () => {
		const provider = createOpenAICompatibleProvider({
			id: "q",
			displayName: "Q",
			baseUrl: "http://test/v1",
		});
		for await (const _ of provider.stream({
			modelId: "Qwen/Qwen3-Coder-30B-A3B-Instruct",
			systemPrompt: "you are helpful",
			messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
		})) {
			// drain
		}
		const fetchMock = global.fetch as ReturnType<typeof vi.fn>;
		const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		expect(url).toBe("http://test/v1/completions");
		const body = JSON.parse((init.body as string) ?? "{}");
		expect(typeof body.prompt).toBe("string");
		expect(body.prompt).toContain("<|im_start|>");
		expect(body.prompt).toContain("<|im_end|>");
		expect(body.stop).toContain("<|im_end|>");
		expect(body.chat_template).toBeUndefined();
	});

	it("Kimi K2.6 — completions-fallback is NOT engaged (preserves the working codepath)", async () => {
		// Switch the mock to the chat-completion shape Kimi expects.
		const fetchMock = vi.fn();
		fetchMock.mockResolvedValue(
			new Response(
				mkSseStream([
					'data: {"choices":[{"delta":{"content":"hi"},"finish_reason":"stop"}]}',
					"",
					"data: [DONE]",
				]),
				{ status: 200, headers: { "content-type": "text/event-stream" } },
			),
		);
		global.fetch = fetchMock;
		const provider = createOpenAICompatibleProvider({
			id: "k",
			displayName: "K",
			baseUrl: "http://test/v1",
		});
		for await (const _ of provider.stream({
			modelId: "moonshotai/kimi-k2",
			messages: [
				{ role: "user", parts: [{ kind: "text", text: "hi" }] },
				{
					role: "assistant",
					parts: [{ kind: "tool_call", id: "c1", name: "read_file", args: { path: "a.ts" } }],
				},
				{ role: "tool", parts: [{ kind: "tool_result", id: "c1", output: "x", isError: false }] },
				{ role: "user", parts: [{ kind: "text", text: "thanks" }] },
			],
		})) {
			// drain
		}
		const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit];
		// Kimi still goes through /v1/chat/completions (NOT the
		// fallback endpoint). Critical: this is the regression guard
		// that the OATI gateway workaround did not interfere with Kimi.
		expect(url).toBe("http://test/v1/chat/completions");
		const body = JSON.parse((init.body as string) ?? "{}");
		// Messages array is intact (no flattening to prompt string).
		expect(Array.isArray(body.messages)).toBe(true);
		expect(body.prompt).toBeUndefined();
		expect(body.chat_template).toBeUndefined();
		// Tool role survives — Kimi's wire body is unchanged.
		const toolMsg = body.messages.find((m: { role: string }) => m.role === "tool");
		expect(toolMsg).toBeDefined();
		expect(toolMsg.tool_call_id).toBe("c1");
		// Assistant tool_calls array still present.
		const asstMsg = body.messages.find(
			(m: { role: string; tool_calls?: unknown[] }) =>
				m.role === "assistant" && Array.isArray(m.tool_calls) && m.tool_calls.length > 0,
		);
		expect(asstMsg).toBeDefined();
	});
});
