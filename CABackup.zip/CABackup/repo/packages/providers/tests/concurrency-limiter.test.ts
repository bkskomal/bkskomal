// Tests for the client-side concurrency limiter wrapper.

import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@iom/shared";
import { describe, expect, it, vi } from "vitest";
import { limitProviderConcurrency } from "../src/concurrency-limiter";

function makeMockProvider(
	streamImpl: (req: ProviderRequest) => AsyncIterable<ProviderStreamEvent>,
): ProviderSpec {
	return {
		id: "mock",
		displayName: "Mock",
		stream: streamImpl,
	};
}

function delayedStream(ms: number, events: readonly ProviderStreamEvent[]) {
	return async function* (_req: ProviderRequest) {
		await new Promise((r) => setTimeout(r, ms));
		for (const ev of events) yield ev;
	};
}

async function consume(stream: AsyncIterable<ProviderStreamEvent>): Promise<ProviderStreamEvent[]> {
	const out: ProviderStreamEvent[] = [];
	for await (const ev of stream) out.push(ev);
	return out;
}

const anyReq: ProviderRequest = { modelId: "test", messages: [] };

describe("limitProviderConcurrency", () => {
	it("returns the raw provider unchanged when no cap is set", () => {
		const raw = makeMockProvider(delayedStream(0, []));
		const wrapped = limitProviderConcurrency(raw, {});
		expect(wrapped).toBe(raw);
	});

	it("returns the raw provider when cap is 0 (equiv to unlimited)", () => {
		const raw = makeMockProvider(delayedStream(0, []));
		const wrapped = limitProviderConcurrency(raw, { maxConcurrent: 0 });
		expect(wrapped).toBe(raw);
	});

	it("allows up to N concurrent streams", async () => {
		let active = 0;
		let maxActive = 0;
		const raw = makeMockProvider(async function* () {
			active += 1;
			maxActive = Math.max(maxActive, active);
			await new Promise((r) => setTimeout(r, 30));
			active -= 1;
		});
		const wrapped = limitProviderConcurrency(raw, { maxConcurrent: 3 });
		await Promise.all([
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
		]);
		expect(maxActive).toBe(3);
	});

	it("emits queued/started events when requests wait for a slot", async () => {
		const events: string[] = [];
		const raw = makeMockProvider(async function* () {
			await new Promise((r) => setTimeout(r, 20));
		});
		const wrapped = limitProviderConcurrency(raw, {
			maxConcurrent: 1,
			onQueueEvent: (e) => events.push(e.kind),
		});
		// First doesn't queue; second and third do.
		await Promise.all([
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
		]);
		// Should see 2 queued events + 2 started events (only for the ones that waited).
		expect(events.filter((e) => e === "queued")).toHaveLength(2);
		expect(events.filter((e) => e === "started")).toHaveLength(2);
	});

	it("releases the slot even when the caller aborts mid-stream", async () => {
		let slotReleased = false;
		const raw = makeMockProvider(async function* () {
			try {
				yield { type: "text_delta", text: "a" };
				await new Promise((r) => setTimeout(r, 50));
				yield { type: "text_delta", text: "b" };
			} finally {
				slotReleased = true;
			}
		});
		const wrapped = limitProviderConcurrency(raw, { maxConcurrent: 1 });
		const it = wrapped.stream(anyReq)[Symbol.asyncIterator]();
		await it.next(); // consume "a"
		await it.return?.(); // simulate early abort
		expect(slotReleased).toBe(true);
		// After release, a new request should acquire the slot immediately.
		await consume(wrapped.stream(anyReq));
	});

	it("preserves FIFO order for waiting requests", async () => {
		const startOrder: number[] = [];
		let counter = 0;
		const raw = makeMockProvider(async function* () {
			const my = ++counter;
			startOrder.push(my);
			await new Promise((r) => setTimeout(r, 10));
		});
		const wrapped = limitProviderConcurrency(raw, { maxConcurrent: 1 });
		// Launch 4 in order — with cap=1, they must run 1, 2, 3, 4.
		await Promise.all([
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
			consume(wrapped.stream(anyReq)),
		]);
		expect(startOrder).toEqual([1, 2, 3, 4]);
	});
});
