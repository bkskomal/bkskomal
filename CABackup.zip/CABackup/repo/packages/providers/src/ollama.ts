// R3-B: Ollama provider — a thin wrapper around the OpenAI-compatible client
// that points at a local Ollama server (default http://localhost:11434/v1) and
// streams chat completions via SSE. Ollama exposes an OpenAI-compatible REST
// surface so this re-uses the existing transport instead of duplicating SSE
// parsing logic. Costs are treated as zero because the model runs locally.
//
// Differences from a hosted OpenAI-compatible provider:
//   - `apiKey` is OPTIONAL; Ollama doesn't authenticate by default. We still
//     forward `Authorization: Bearer ...` when set so users running ollama
//     behind a reverse proxy that adds auth can still authenticate.
//   - The default `baseUrl` is `http://localhost:11434/v1` so a bare config
//     `{ id: "ollama", model: "llama3.1:8b" }` works without further setup.
//   - Pricing is intentionally not registered for ollama model ids — the
//     pricing table in `@iom/shared` uses substring matching, so ollama
//     models like `llama3.1:8b` simply have no entry and the cost surface
//     reports "unknown / free" (effectively zero) throughout the UI.

import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@iom/shared";
import { createOpenAICompatibleProvider } from "./openai-compatible";

export interface OllamaConfig {
	readonly id?: string;
	readonly displayName?: string;
	/** Override the Ollama endpoint. Defaults to `http://localhost:11434/v1`. */
	readonly baseUrl?: string;
	/** Optional bearer token for proxies that wrap ollama in auth. */
	readonly apiKey?: string;
	/** Default model id used when a request omits `modelId`. */
	readonly model?: string;
	/** Forwarded to every request unless the caller overrides per-request. */
	readonly temperature?: number;
	/** Forwarded to every request unless the caller overrides per-request. */
	readonly maxTokens?: number;
	readonly extraHeaders?: Readonly<Record<string, string>>;
}

export const OLLAMA_DEFAULT_BASE_URL = "http://localhost:11434/v1";
export const OLLAMA_DEFAULT_MODEL = "llama3.1:8b";

export function createOllamaProvider(config: OllamaConfig = {}): ProviderSpec {
	const baseUrl = config.baseUrl?.trim() || OLLAMA_DEFAULT_BASE_URL;
	const id = config.id ?? "ollama";
	const displayName = config.displayName ?? "Ollama (local)";
	const defaultModel = config.model ?? OLLAMA_DEFAULT_MODEL;

	const inner = createOpenAICompatibleProvider({
		id,
		displayName,
		baseUrl,
		// `apiKey` is intentionally optional — ollama itself doesn't require one,
		// but we still pass it through so users behind a custom reverse proxy can
		// authenticate if they need to.
		...(config.apiKey ? { apiKey: config.apiKey } : {}),
		...(config.extraHeaders ? { extraHeaders: config.extraHeaders } : {}),
	});

	return {
		id,
		displayName,
		async *stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			// Fill in defaults from the provider config when the caller didn't
			// specify them on the request. We don't override caller-provided
			// values so per-turn temperature / model overrides still win.
			const effective: ProviderRequest = {
				...req,
				modelId: req.modelId || defaultModel,
				temperature: req.temperature ?? config.temperature,
				maxTokens: req.maxTokens ?? config.maxTokens,
			};
			yield* inner.stream(effective);
		},
	};
}
