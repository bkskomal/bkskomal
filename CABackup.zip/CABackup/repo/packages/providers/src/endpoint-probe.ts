// 2026-06-29: capability probe for OpenAI-compatible gateways. Sends one
// minimal `/v1/chat/completions` request and classifies the response so
// the caller can decide whether to use the chat endpoint or fall back to
// `/v1/completions` (raw text-in/text-out).
//
// Why this exists: the OATI internal vLLM gateway ships without a tokenizer
// chat_template and rejects `/v1/chat/completions` with a "chat_template is
// required" error. The previous workaround was a per-model quirk
// (`useCompletionsFallback: true` on Qwen 3 Coder / Gemma 4) — but that
// over-matched: the same model id (`qwen3-coder`, `qwen/qwen3-coder`) on
// OpenRouter / DashScope / Together / Fireworks DOES have a working
// chat_template, and forcing `/v1/completions` on those gateways breaks
// agent iteration (no role separation → model stops after one tool call).
//
// This probe asks the actual gateway "does chat_completions work?" once,
// and the answer overrides the quirk hint.

export interface ProbeResult {
	/** True if `/chat/completions` accepted a minimal request. */
	readonly chatCompletionsWorks: boolean;
	/**
	 * True if the request was rejected SPECIFICALLY because the gateway has
	 * no chat_template (the only condition under which `/v1/completions` is
	 * the right fallback). For 4xx/5xx errors unrelated to templates, this
	 * is false — those should surface as normal errors, not be papered over.
	 */
	readonly needsCompletionsFallback: boolean;
	/** Short human-readable summary for Settings panel display. */
	readonly summary: string;
}

export interface ProbeRequest {
	/** Provider base URL — e.g. `https://api.openrouter.ai/api/v1` or
	 *  `http://vllm.dev.services.oati.com/qwen3_coder/v1`. The probe POSTs
	 *  to `${baseUrl}/chat/completions` after trimming any trailing slash.
	 */
	readonly baseUrl: string;
	readonly modelId: string;
	readonly apiKey?: string;
	readonly extraHeaders?: Readonly<Record<string, string>>;
	/** Timeout in ms. Defaults to 10s. */
	readonly timeoutMs?: number;
}

/**
 * Run the probe. Resolves to a ProbeResult; never throws (network/timeout
 * errors are reported as `chatCompletionsWorks: false`, `needsCompletionsFallback: false`).
 *
 * The probe is intentionally cheap: `max_tokens: 1`, `stream: false`, the
 * shortest possible message. Most gateways respond in 200-800ms.
 */
export async function probeChatEndpoint(req: ProbeRequest): Promise<ProbeResult> {
	const base = req.baseUrl.replace(/\/+$/, "");
	const timeoutMs = req.timeoutMs ?? 10_000;
	const headers: Record<string, string> = {
		"Content-Type": "application/json",
		Accept: "application/json",
		...(req.apiKey ? { Authorization: `Bearer ${req.apiKey}` } : {}),
		...(req.extraHeaders ?? {}),
	};

	// Probe 1: /v1/chat/completions.
	const chatResult = await tryPost(
		`${base}/chat/completions`,
		{
			model: req.modelId,
			messages: [{ role: "user" as const, content: "hi" }],
			max_tokens: 1,
			stream: false,
		},
		headers,
		timeoutMs,
	);
	if (chatResult.ok) {
		return {
			chatCompletionsWorks: true,
			needsCompletionsFallback: false,
			summary: `OK (HTTP ${chatResult.status})`,
		};
	}
	if (chatResult.status >= 400 && chatResult.status < 600 && isChatTemplateError(chatResult.text)) {
		return {
			chatCompletionsWorks: false,
			needsCompletionsFallback: true,
			summary: `HTTP ${chatResult.status}: missing chat_template — using /v1/completions fallback`,
		};
	}

	// 2026-06-29: 405 Method Not Allowed on /v1/chat/completions is the
	// signal we get from OATI-style bare vLLM/SGLang gateways where only
	// the raw /v1/completions endpoint is exposed. Verify by probing the
	// completions endpoint too — if it accepts our POST (even with a
	// non-2xx error like a chat_template one), that's the path we want.
	//   - 405 chat + 200 completions → use completions fallback
	//   - 405 chat + 405 completions → gateway blocks POST entirely; return
	//     the chat 405 unchanged so the user sees the real error
	// The extra ~200-500ms one-time probe cost is only paid on gateways
	// where chat DOESN'T work — every other case still takes only one probe.
	if (chatResult.status === 405) {
		const compResult = await tryPost(
			`${base}/completions`,
			{
				model: req.modelId,
				prompt: "hi",
				max_tokens: 1,
				stream: false,
			},
			headers,
			timeoutMs,
		);
		if (compResult.ok || (compResult.status !== 405 && compResult.status !== 404)) {
			// completions accepted the POST (or at least didn't reject
			// the METHOD). Some completions endpoints still return a
			// non-2xx if the model/args have issues, but the fact that
			// the gateway didn't say "method not allowed" is enough
			// signal that this is the right path.
			return {
				chatCompletionsWorks: false,
				needsCompletionsFallback: true,
				summary:
					"chat/completions returned 405; /v1/completions accepts POST — using completions fallback",
			};
		}
	}

	if (chatResult.errorKind === "network") {
		return {
			chatCompletionsWorks: false,
			needsCompletionsFallback: false,
			summary: chatResult.summary,
		};
	}
	return {
		chatCompletionsWorks: false,
		needsCompletionsFallback: false,
		summary: `HTTP ${chatResult.status}: ${truncate(chatResult.text, 160)}`,
	};
}

/**
 * Internal helper: POST + parse. Returns a discriminated result so the
 * caller can distinguish HTTP responses (any status) from network
 * failures (fetch throw / abort). Never throws.
 */
interface PostResult {
	readonly ok: boolean;
	readonly status: number;
	readonly text: string;
	readonly errorKind?: "network";
	readonly summary: string;
}

async function tryPost(
	url: string,
	body: unknown,
	headers: Record<string, string>,
	timeoutMs: number,
): Promise<PostResult> {
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), timeoutMs);
	try {
		const res = await fetch(url, {
			method: "POST",
			headers,
			body: JSON.stringify(body),
			signal: controller.signal,
		});
		const text = res.ok ? "" : await safeReadText(res);
		return {
			ok: res.ok,
			status: res.status,
			text,
			summary: res.ok ? `OK (HTTP ${res.status})` : `HTTP ${res.status}`,
		};
	} catch (e) {
		const msg = e instanceof Error ? e.message : String(e);
		const isTimeout = msg.includes("abort") || msg.includes("timeout");
		return {
			ok: false,
			status: 0,
			text: "",
			errorKind: "network",
			summary: isTimeout ? "timeout (>10s)" : `network error: ${truncate(msg, 160)}`,
		};
	} finally {
		clearTimeout(timer);
	}
}

const TEMPLATE_ERROR_PATTERNS = [
	/chat[_\s-]?template/i,
	/no chat template/i,
	/tokenizer.+template/i,
	/missing.+template/i,
	/trust[_\s-]?request[_\s-]?chat[_\s-]?template/i,
];

/**
 * Returns true when the response body looks like a "missing chat_template"
 * error. vLLM's `--trust-request-chat-template` guard rejects with messages
 * like:
 *   "As of transformers v4.44, default chat template is no longer allowed"
 *   "Chat template is required for this model"
 *   "Model has no chat template"
 *
 * Status code is usually 400 in that case; we accept any 4xx since some
 * gateways wrap the error in different envelopes.
 */
function isChatTemplateError(body: string): boolean {
	return TEMPLATE_ERROR_PATTERNS.some((p) => p.test(body));
}

async function safeReadText(res: Response): Promise<string> {
	try {
		return await res.text();
	} catch {
		return "";
	}
}

function truncate(s: string, n: number): string {
	return s.length > n ? `${s.slice(0, n)}…` : s;
}
