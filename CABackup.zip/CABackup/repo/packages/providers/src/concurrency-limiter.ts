// 2026-06-29: bounded-concurrency wrapper for provider.stream(). When
// N > cap requests are in flight, excess requests QUEUE at the iOm side
// (in-process) instead of piling up on the gateway. Rationale: on
// shared-KV-cache gateways (K2.7 Code on 4× H200, Qwen on OATI vLLM),
// unbounded parallelism from sub-agents (spawn_agent × 4 × 3 nested
// levels = 12 concurrent streams) can self-DoS the gateway — each
// request eats KV cache that others need. Client-side queueing is
// preferable to gateway timeouts because we control the fairness policy
// (FIFO here) and can surface a "waiting for slot…" event to the user
// instead of a mysterious pause.
//
// The wrapper is transparent — same ProviderSpec interface, so callers
// don't need to know they're rate-limited. The recorded provider
// registry can hold either the raw provider or the wrapped one.

import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@iom/shared";

export interface ConcurrencyLimitOptions {
	/** Maximum in-flight requests. Undefined / <=0 = unlimited (default). */
	readonly maxConcurrent?: number;
	/**
	 * Optional callback for observability — fires when a request has to
	 * queue (and when it eventually gets its slot). Lets the extension
	 * host surface a "waiting for slot…" chip while the stream is stuck
	 * in the queue.
	 */
	readonly onQueueEvent?: (event: QueueEvent) => void;
}

export type QueueEvent =
	| { readonly kind: "queued"; readonly providerId: string; readonly queueDepth: number }
	| { readonly kind: "started"; readonly providerId: string; readonly waitedMs: number };

/**
 * Wrap a ProviderSpec so its `stream()` obeys a max-in-flight cap.
 * When cap is not set (or <=0), returns the original provider unchanged
 * so we pay no runtime overhead on providers without a limit.
 */
export function limitProviderConcurrency(
	spec: ProviderSpec,
	opts: ConcurrencyLimitOptions,
): ProviderSpec {
	if (!opts.maxConcurrent || opts.maxConcurrent <= 0) return spec;
	const cap: number = opts.maxConcurrent;

	// FIFO waiter queue. Each waiter is a resolver we call when a slot
	// frees. Using an array + shift() is fine at these cardinalities
	// (< 100 pending); no need for a linked list.
	const waiters: Array<() => void> = [];
	let inFlight = 0;

	async function acquireSlot(): Promise<{ waitedMs: number }> {
		if (inFlight < cap) {
			inFlight += 1;
			return { waitedMs: 0 };
		}
		const start = performance.now();
		opts.onQueueEvent?.({ kind: "queued", providerId: spec.id, queueDepth: waiters.length + 1 });
		await new Promise<void>((resolve) => waiters.push(resolve));
		inFlight += 1;
		return { waitedMs: performance.now() - start };
	}

	function releaseSlot(): void {
		inFlight -= 1;
		const next = waiters.shift();
		if (next) next();
	}

	return {
		id: spec.id,
		displayName: spec.displayName,
		async *stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			const { waitedMs } = await acquireSlot();
			if (waitedMs > 0) {
				opts.onQueueEvent?.({ kind: "started", providerId: spec.id, waitedMs });
			}
			try {
				yield* spec.stream(req);
			} finally {
				releaseSlot();
			}
		},
	};
}
