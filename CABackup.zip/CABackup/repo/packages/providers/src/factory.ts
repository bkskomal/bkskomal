import type { ProviderConfig, ProviderSpec } from "@iom/shared";
import { createAnthropicProvider } from "./anthropic";
// R3-B: route preset "ollama" through the dedicated local-provider wrapper so
// it gets the cost-zero defaults + optional apiKey behavior. Other
// openai-compatible presets continue to go through the generic factory branch.
import { createOllamaProvider } from "./ollama";
import { createOpenAICompatibleProvider } from "./openai-compatible";

export function createProviderFromConfig(
	config: ProviderConfig,
	apiKey: string | undefined,
): ProviderSpec {
	switch (config.type) {
		case "openai-compatible":
			// R3-B: Ollama gets its own wrapper (apiKey-optional, default model).
			if (config.preset === "ollama") {
				return createOllamaProvider({
					id: config.id,
					displayName: config.displayName,
					baseUrl: config.baseUrl,
					...(apiKey ? { apiKey } : {}),
					model: config.defaultModel,
					...(config.extraHeaders ? { extraHeaders: config.extraHeaders } : {}),
				});
			}
			return createOpenAICompatibleProvider({
				id: config.id,
				displayName: config.displayName,
				baseUrl: config.baseUrl,
				apiKey,
				extraHeaders: config.extraHeaders,
			});
		case "anthropic":
			return createAnthropicProvider({
				id: config.id,
				displayName: config.displayName,
				baseUrl: config.baseUrl || undefined,
				apiKey,
				extraHeaders: config.extraHeaders,
			});
		default: {
			const exhaustive: never = config.type;
			throw new Error(`Unknown provider type: ${exhaustive as string}`);
		}
	}
}
