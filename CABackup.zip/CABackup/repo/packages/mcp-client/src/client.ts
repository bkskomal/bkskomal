import {
	type JsonRpcRequest,
	type JsonRpcResponse,
	MCP_PROTOCOL_VERSION,
	type McpCallToolResult,
	type McpClientInfo,
	type McpInitializeResult,
	type McpListToolsResult,
	type McpTool,
} from "./protocol";
import type { IncomingMessage, McpTransport } from "./transport";
import { StdioTransport, type StdioTransportOptions } from "./transport-stdio";

export interface McpClientOptions {
	readonly clientInfo?: McpClientInfo;
	readonly initTimeoutMs?: number;
	readonly requestTimeoutMs?: number;
}

export class McpClient {
	private readonly transport: McpTransport;
	private nextId = 1;
	private readonly pending = new Map<
		number | string,
		{
			resolve(value: unknown): void;
			reject(err: Error): void;
			timer?: NodeJS.Timeout;
		}
	>();
	private initialized = false;
	private serverInfo: McpInitializeResult | undefined;

	constructor(
		transportOrOpts: McpTransport | StdioTransportOptions,
		private readonly opts: McpClientOptions = {},
	) {
		this.transport = isMcpTransport(transportOrOpts)
			? transportOrOpts
			: new StdioTransport(transportOrOpts);
		this.transport.on("message", (msg: IncomingMessage) => this.onMessage(msg));
		this.transport.on("error", (err: Error) => {
			for (const p of this.pending.values()) p.reject(err);
			this.pending.clear();
		});
		this.transport.on("exit", () => {
			for (const p of this.pending.values()) p.reject(new Error("MCP server exited"));
			this.pending.clear();
		});
	}

	async start(): Promise<McpInitializeResult> {
		await this.transport.start();
		const initResult = await this.request<McpInitializeResult>(
			"initialize",
			{
				protocolVersion: MCP_PROTOCOL_VERSION,
				capabilities: { tools: {} },
				clientInfo: this.opts.clientInfo ?? {
					name: "@iom/mcp-client",
					version: "0.0.1",
				},
			},
			this.opts.initTimeoutMs ?? 10_000,
		);
		this.serverInfo = initResult;
		this.transport.send({
			jsonrpc: "2.0",
			method: "notifications/initialized",
		});
		this.initialized = true;
		return initResult;
	}

	getServerInfo(): McpInitializeResult | undefined {
		return this.serverInfo;
	}

	async listTools(): Promise<readonly McpTool[]> {
		this.ensureInitialized();
		const r = await this.request<McpListToolsResult>("tools/list", {});
		return r.tools;
	}

	async callTool(name: string, args: unknown): Promise<McpCallToolResult> {
		this.ensureInitialized();
		return this.request<McpCallToolResult>("tools/call", {
			name,
			arguments: args,
		});
	}

	close(): void {
		for (const p of this.pending.values()) {
			if (p.timer) clearTimeout(p.timer);
			p.reject(new Error("MCP client closing"));
		}
		this.pending.clear();
		this.transport.close();
	}

	private ensureInitialized(): void {
		if (!this.initialized) throw new Error("MCP client not initialized; call start() first");
	}

	private request<T>(method: string, params: unknown, timeoutMs?: number): Promise<T> {
		const id = this.nextId++;
		const req: JsonRpcRequest = {
			jsonrpc: "2.0",
			id,
			method,
			params,
		};
		return new Promise<T>((resolve, reject) => {
			const timeout = timeoutMs ?? this.opts.requestTimeoutMs ?? 30_000;
			const timer = setTimeout(() => {
				this.pending.delete(id);
				reject(new Error(`MCP request '${method}' timed out after ${timeout}ms`));
			}, timeout);
			this.pending.set(id, {
				resolve: (v) => resolve(v as T),
				reject,
				timer,
			});
			this.transport.send(req);
		});
	}

	private onMessage(msg: IncomingMessage): void {
		if ("id" in msg) {
			const response = msg as JsonRpcResponse;
			const pending = this.pending.get(response.id);
			if (!pending) return;
			this.pending.delete(response.id);
			if (pending.timer) clearTimeout(pending.timer);
			if (response.error) {
				pending.reject(new Error(`MCP error ${response.error.code}: ${response.error.message}`));
			} else {
				pending.resolve(response.result);
			}
		}
	}
}

function isMcpTransport(v: unknown): v is McpTransport {
	return (
		typeof v === "object" &&
		v !== null &&
		typeof (v as McpTransport).start === "function" &&
		typeof (v as McpTransport).send === "function" &&
		typeof (v as McpTransport).on === "function"
	);
}
