import type { ToolRegistry } from "@iom/agent-core";
import type { JsonSchema, ToolSpec } from "@iom/shared";
import type { McpClient } from "./client";
import type { McpContentBlock, McpTool } from "./protocol";

export interface McpToolRegistrationOptions {
	/** Prefix added to each tool's name to avoid collision with builtins / other servers. */
	readonly namePrefix?: string;
	/** Approval policy applied to all tools from this server. Default: "prompt". */
	readonly approval?: "auto" | "prompt" | "deny";
}

/**
 * Pull tools/list from an MCP client and register each tool with the agent's
 * ToolRegistry. Returns the registered tool names so callers can later
 * unregister them on shutdown.
 */
export async function registerMcpTools(
	client: McpClient,
	registry: ToolRegistry,
	opts: McpToolRegistrationOptions = {},
): Promise<string[]> {
	const prefix = opts.namePrefix ?? "";
	const approval = opts.approval ?? "prompt";
	const tools = await client.listTools();
	const registered: string[] = [];
	for (const mcpTool of tools) {
		const fullName = `${prefix}${mcpTool.name}`;
		try {
			registry.register(buildSpec(client, mcpTool, fullName, approval));
			registered.push(fullName);
		} catch (err) {
			// Skip duplicates rather than aborting the whole server registration
			console.warn(`[mcp] failed to register tool ${fullName}:`, err);
		}
	}
	return registered;
}

function buildSpec(
	client: McpClient,
	mcpTool: McpTool,
	exposedName: string,
	approval: "auto" | "prompt" | "deny",
): ToolSpec {
	return {
		name: exposedName,
		description: mcpTool.description ?? `MCP tool: ${mcpTool.name}`,
		schema: normalizeSchema(mcpTool.inputSchema),
		approval,
		async handler(args) {
			const result = await client.callTool(mcpTool.name, args);
			if (result.isError) {
				throw new Error(blocksToText(result.content));
			}
			return blocksToText(result.content);
		},
	};
}

function blocksToText(blocks: readonly McpContentBlock[]): string {
	const out: string[] = [];
	for (const b of blocks) {
		if (b.type === "text" && b.text) out.push(b.text);
		else if (b.type === "image") out.push(`[image: ${b.mimeType ?? "unknown"}]`);
		else if (b.type === "resource") out.push(`[resource: ${b.mimeType ?? "unknown"}]`);
	}
	return out.join("\n");
}

function normalizeSchema(schema: McpTool["inputSchema"]): JsonSchema {
	const properties = (schema.properties ?? {}) as Record<string, unknown>;
	const normalized: Record<string, import("@iom/shared").JsonSchemaProperty> = {};
	for (const [key, raw] of Object.entries(properties)) {
		if (typeof raw === "object" && raw !== null) {
			const r = raw as { type?: string; description?: string };
			normalized[key] = {
				type: (r.type as import("@iom/shared").JsonSchemaProperty["type"]) ?? "string",
				description: r.description,
			};
		} else {
			normalized[key] = { type: "string" };
		}
	}
	return {
		type: "object",
		properties: normalized,
		required: schema.required ?? [],
		additionalProperties: false,
	};
}
