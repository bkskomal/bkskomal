/**
 * R5-C: fact-promoter heuristic + end-to-end promotion tests.
 */
import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { FACTS_RELATIVE_PATH, loadFacts } from "../src/agent-facts";
import { extractInsight, promoteFactIfAny } from "../src/fact-promoter";

async function makeTempWorkspace(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-fact-promoter-"));
}

describe("extractInsight", () => {
	it('catches "Note that …"', () => {
		expect(extractInsight("Note that the auth middleware lives in src/auth.ts.")).toBe(
			"the auth middleware lives in src/auth.ts",
		);
	});

	it('catches "Important: …"', () => {
		expect(extractInsight("Important: never commit the .env file.")).toBe(
			"never commit the .env file",
		);
	});

	it('catches "Important — …" (em-dash variant)', () => {
		expect(extractInsight("Important — run npm install first.")).toBe("run npm install first");
	});

	it('catches "Remember to …"', () => {
		expect(extractInsight("Remember to clear the cache after edits.")).toBe(
			"to clear the cache after edits",
		);
	});

	it('catches "Remember that …"', () => {
		expect(extractInsight("Remember that tests run on every save.")).toBe("tests run on every save");
	});

	it('catches "Key takeaway: …"', () => {
		expect(extractInsight("Key takeaway: prefer composition over inheritance.")).toBe(
			"prefer composition over inheritance",
		);
	});

	it('catches markdown-bolded "**Note:** …"', () => {
		expect(extractInsight("**Note:** the project uses pnpm workspaces.")).toBe(
			"the project uses pnpm workspaces",
		);
	});

	it("skips ordinary prose with no insight marker", () => {
		expect(extractInsight("Here is some normal explanation about the code.")).toBeUndefined();
		expect(extractInsight("I'll add a function and then call it from main.")).toBeUndefined();
	});

	it("scans line by line and returns the first match", () => {
		const reply = [
			"First I'll modify the file.",
			"Then run the tests.",
			"Note that the test runner is vitest.",
			"Important: don't forget to commit.",
		].join("\n");
		expect(extractInsight(reply)).toBe("the test runner is vitest");
	});

	it("rejects matches that are too short to be useful", () => {
		// "Note that foo." → "foo" → only 3 chars, below MIN_FACT_CHARS (8).
		expect(extractInsight("Note that foo.")).toBeUndefined();
	});

	it("rejects matches that are too long", () => {
		const huge = `Note that ${"x".repeat(500)}.`;
		expect(extractInsight(huge)).toBeUndefined();
	});

	it("handles empty / null-ish input gracefully", () => {
		expect(extractInsight("")).toBeUndefined();
		expect(extractInsight("   ")).toBeUndefined();
	});

	it('matches "Note that" case-insensitively', () => {
		expect(extractInsight("NOTE THAT the file is generated.")).toBe("the file is generated");
		expect(extractInsight("note that this is auto-formatted.")).toBe("this is auto-formatted");
	});
});

describe("promoteFactIfAny (E2E)", () => {
	let workspace: string;

	beforeEach(async () => {
		workspace = await makeTempWorkspace();
	});

	afterEach(async () => {
		await fs.rm(workspace, { recursive: true, force: true });
	});

	it("appends an insight to .iom/facts.json", async () => {
		const fact = await promoteFactIfAny({
			workspaceRoot: workspace,
			reply: "Important: the build script lives in scripts/build.mjs.",
		});
		expect(fact).toBeDefined();
		expect(fact?.fact).toBe("the build script lives in scripts/build.mjs");
		expect(fact?.source).toBe("agent-auto");
		const facts = await loadFacts(workspace);
		expect(facts).toHaveLength(1);
	});

	it("returns undefined when no insight pattern matches", async () => {
		const fact = await promoteFactIfAny({
			workspaceRoot: workspace,
			reply: "Here is some ordinary explanation of the code.",
		});
		expect(fact).toBeUndefined();
		const abs = path.join(workspace, FACTS_RELATIVE_PATH);
		await expect(fs.stat(abs)).rejects.toThrow();
	});

	it("returns undefined when the same insight is promoted twice (dedupe)", async () => {
		const first = await promoteFactIfAny({
			workspaceRoot: workspace,
			reply: "Important: always run lint before pushing.",
		});
		expect(first).toBeDefined();
		const second = await promoteFactIfAny({
			workspaceRoot: workspace,
			reply: "Important: always run lint before pushing.",
		});
		// Dedupe in addFact means no NEW fact, so promoteFactIfAny reports
		// undefined the second time around.
		expect(second).toBeUndefined();
		const facts = await loadFacts(workspace);
		expect(facts).toHaveLength(1);
	});

	it("returns undefined for an empty workspaceRoot", async () => {
		const fact = await promoteFactIfAny({
			workspaceRoot: "",
			reply: "Important: anything.",
		});
		expect(fact).toBeUndefined();
	});

	it("custom source tag is persisted", async () => {
		const fact = await promoteFactIfAny({
			workspaceRoot: workspace,
			reply: "Note that the agent prefers vitest over jest.",
			source: "agent-r5c",
		});
		expect(fact?.source).toBe("agent-r5c");
	});
});
