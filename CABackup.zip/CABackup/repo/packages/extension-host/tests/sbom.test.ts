import { describe, expect, it } from "vitest";
import { runSbom } from "../src/sbom";

describe("runSbom", () => {
	it("reports 'no manifests' when input is empty", async () => {
		const result = await runSbom({
			cfg: { enabled: true, useOsv: false },
			manifests: [],
		});
		expect(result.components).toHaveLength(0);
		expect(result.summary).toMatch(/No supported manifest/i);
	});

	it("parses dependencies + devDependencies from package.json", async () => {
		const pkg = JSON.stringify({
			name: "x",
			dependencies: { lodash: "^4.17.21", express: "4.18.2" },
			devDependencies: { vitest: "~2.1.0" },
		});
		const result = await runSbom({
			cfg: { enabled: true, useOsv: false },
			manifests: [{ path: "package.json", content: pkg }],
		});
		expect(result.components).toHaveLength(3);
		const names = result.components.map((c) => `${c.name}@${c.version}`);
		expect(names).toContain("lodash@4.17.21");
		expect(names).toContain("express@4.18.2");
		expect(names).toContain("vitest@2.1.0");
	});

	it("skips workspace:* / file:* / git+ssh:* specifiers", async () => {
		const pkg = JSON.stringify({
			dependencies: {
				"@iom/shared": "workspace:*",
				"local-thing": "file:../sibling",
				"forked-pkg": "git+ssh://git@github.com/foo/bar.git",
				lodash: "^4.17.21",
			},
		});
		const result = await runSbom({
			cfg: { enabled: true, useOsv: false },
			manifests: [{ path: "package.json", content: pkg }],
		});
		// Only lodash should make it through — others have no concrete version.
		expect(result.components.map((c) => c.name)).toEqual(["lodash"]);
	});

	it("records skipped manifests with a reason when JSON is invalid", async () => {
		const result = await runSbom({
			cfg: { enabled: true, useOsv: false },
			manifests: [{ path: "broken/package.json", content: "{ this isn't json" }],
		});
		expect(result.components).toHaveLength(0);
		expect(result.skipped).toHaveLength(1);
		expect(result.skipped[0]?.path).toBe("broken/package.json");
		expect(result.skipped[0]?.reason).toMatch(/json/i);
	});

	it("attaches OSV vulnerabilities to matching components", async () => {
		const pkg = JSON.stringify({
			dependencies: { minimist: "1.2.0" },
		});
		// Mock OSV.dev: batch returns one id; vuln-detail returns a full record.
		const osvFetch = async (url: string) => {
			if (url.endsWith("/v1/querybatch")) {
				return new Response(JSON.stringify({ results: [{ vulns: [{ id: "GHSA-xvch-5gv4-984h" }] }] }), {
					status: 200,
					headers: { "content-type": "application/json" },
				});
			}
			// per-id vuln fetch
			return new Response(
				JSON.stringify({
					id: "GHSA-xvch-5gv4-984h",
					summary: "Prototype pollution in minimist",
					database_specific: { severity: "CRITICAL" },
					affected: [{ ranges: [{ events: [{ introduced: "0" }, { fixed: "1.2.6" }] }] }],
					references: [{ url: "https://github.com/advisories/GHSA-xvch-5gv4-984h" }],
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			);
		};
		const result = await runSbom({
			cfg: { enabled: true, useOsv: true },
			manifests: [{ path: "package.json", content: pkg }],
			osvFetch: osvFetch as unknown as typeof fetch,
		});
		expect(result.components).toHaveLength(1);
		const c = result.components[0];
		expect(c.vulnerabilities).toHaveLength(1);
		const v = c.vulnerabilities[0];
		expect(v.id).toBe("GHSA-xvch-5gv4-984h");
		expect(v.severity).toBe("critical");
		expect(v.fixedIn).toBe("1.2.6");
	});

	it("filters chat summary by chatThreshold", async () => {
		const pkg = JSON.stringify({
			dependencies: { lowsev: "1.0.0", criticalsev: "1.0.0" },
		});
		const osvFetch = async (url: string) => {
			if (url.endsWith("/v1/querybatch")) {
				return new Response(
					JSON.stringify({
						results: [{ vulns: [{ id: "LOW-1" }] }, { vulns: [{ id: "CRIT-1" }] }],
					}),
					{ status: 200, headers: { "content-type": "application/json" } },
				);
			}
			const id = decodeURIComponent(url.split("/").pop() ?? "");
			const severity = id.startsWith("LOW") ? "LOW" : "CRITICAL";
			return new Response(
				JSON.stringify({
					id,
					summary: `${id} summary`,
					database_specific: { severity },
				}),
				{ status: 200, headers: { "content-type": "application/json" } },
			);
		};
		const result = await runSbom({
			cfg: { enabled: true, useOsv: true, chatThreshold: "high" },
			manifests: [{ path: "package.json", content: pkg }],
			osvFetch: osvFetch as unknown as typeof fetch,
		});
		// Low severity should be hidden from the summary, critical kept.
		expect(result.summary).not.toContain("LOW-1");
		expect(result.summary).toContain("CRIT-1");
	});
});
