// Tests for the Memento-backed EndpointCapabilityCache. Covers cache
// hits, staleness invalidation, base-URL invalidation, and persistence
// round-trip.

import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import type * as vscode from "vscode";
import { EndpointCapabilityCache } from "../src/endpoint-capability";

function mkMemento(): vscode.Memento & { _peek: () => Map<string, unknown> } {
	const store = new Map<string, unknown>();
	return {
		get: (k: string, dflt?: unknown) => (store.has(k) ? store.get(k) : dflt),
		update: async (k: string, v: unknown) => {
			if (v === undefined) store.delete(k);
			else store.set(k, v);
		},
		keys: () => [...store.keys()],
		_peek: () => store,
		// biome-ignore lint/suspicious/noExplicitAny: vscode.Memento has methods we don't use here
	} as any;
}

describe("EndpointCapabilityCache", () => {
	const originalFetch = global.fetch;
	beforeEach(() => {
		global.fetch = vi.fn();
	});
	afterEach(() => {
		global.fetch = originalFetch;
	});

	it("get() returns null before any probe has run", () => {
		const cache = new EndpointCapabilityCache(mkMemento());
		expect(cache.get("p1", "qwen/qwen3-coder", "https://openrouter.ai/api/v1")).toBeNull();
	});

	it("probe() runs the network call, stores the result, and persists to Memento", async () => {
		const mem = mkMemento();
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(new Response("{}", { status: 200 }));
		const cache = new EndpointCapabilityCache(mem);
		const cap = await cache.probe("p1", "https://openrouter.ai/api/v1", "qwen/qwen3-coder");
		expect(cap.chatCompletionsWorks).toBe(true);
		expect(cap.needsCompletionsFallback).toBe(false);
		// Persisted under the storage key — survives reload by hydrating from Memento.
		const persisted = mem.get("iom.endpointCapability.v1") as Record<string, unknown>;
		expect(persisted).toBeTruthy();
		expect(Object.keys(persisted).length).toBe(1);
	});

	it("get() returns the cached result after probe()", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(new Response("{}", { status: 200 }));
		const cache = new EndpointCapabilityCache(mkMemento());
		await cache.probe("p1", "https://openrouter.ai/api/v1", "qwen/qwen3-coder");
		const cap = cache.get("p1", "qwen/qwen3-coder", "https://openrouter.ai/api/v1");
		expect(cap).not.toBeNull();
		expect(cap?.needsCompletionsFallback).toBe(false);
	});

	it("get() returns null when the base URL has changed since the probe (forces re-probe)", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(new Response("{}", { status: 200 }));
		const cache = new EndpointCapabilityCache(mkMemento());
		await cache.probe("p1", "https://openrouter.ai/api/v1", "qwen/qwen3-coder");
		// User edited the base URL — old probe is stale by configuration.
		expect(cache.get("p1", "qwen/qwen3-coder", "http://vllm.example/v1")).toBeNull();
	});

	it("invalidate() drops all entries for a given providerId", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(new Response("{}", { status: 200 }));
		const cache = new EndpointCapabilityCache(mkMemento());
		await cache.probe("p1", "https://api.example/v1", "model-a");
		await cache.probe("p1", "https://api.example/v1", "model-b");
		await cache.probe("p2", "https://other.example/v1", "model-c");
		expect(cache.snapshot().length).toBe(3);
		cache.invalidate("p1");
		expect(cache.snapshot().length).toBe(1);
		expect(cache.snapshot()[0].modelId).toBe("model-c");
	});

	it("hydrate() restores entries from Memento on construction", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(new Response("{}", { status: 200 }));
		const mem = mkMemento();
		const cache1 = new EndpointCapabilityCache(mem);
		await cache1.probe("p1", "https://api.example/v1", "qwen/qwen3-coder");
		// Simulate VS Code reload — new instance reads from the same Memento.
		const cache2 = new EndpointCapabilityCache(mem);
		expect(cache2.get("p1", "qwen/qwen3-coder", "https://api.example/v1")).not.toBeNull();
	});

	it("hydrate() discards entries older than 24h", async () => {
		const mem = mkMemento();
		// Pre-populate Memento with a stale entry (probedAt = 25h ago).
		const stale = {
			"p1 qwen/qwen3-coder": {
				baseUrl: "https://api.example/v1",
				modelId: "qwen/qwen3-coder",
				probedAt: Date.now() - 25 * 60 * 60 * 1000,
				chatCompletionsWorks: true,
				needsCompletionsFallback: false,
				summary: "OK",
			},
		};
		await mem.update("iom.endpointCapability.v1", stale);
		const cache = new EndpointCapabilityCache(mem);
		// Stale entry was discarded during hydrate.
		expect(cache.get("p1", "qwen/qwen3-coder", "https://api.example/v1")).toBeNull();
	});

	it("classifies an OATI bare-vLLM chat_template error correctly", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(
				JSON.stringify({
					message: "default chat_template is no longer allowed; pass --chat-template",
				}),
				{ status: 400 },
			),
		);
		const cache = new EndpointCapabilityCache(mkMemento());
		const cap = await cache.probe(
			"oati-genie",
			"http://vllm.dev.services.oati.com/qwen3_coder/v1",
			"Qwen/Qwen3-Coder-30B-A3B-Instruct",
		);
		expect(cap.needsCompletionsFallback).toBe(true);
	});

	it("classifies OpenRouter (200 OK) as not needing fallback", async () => {
		(global.fetch as ReturnType<typeof vi.fn>).mockResolvedValue(
			new Response(JSON.stringify({ id: "x", choices: [] }), { status: 200 }),
		);
		const cache = new EndpointCapabilityCache(mkMemento());
		const cap = await cache.probe("openrouter", "https://openrouter.ai/api/v1", "qwen/qwen3-coder");
		expect(cap.chatCompletionsWorks).toBe(true);
		expect(cap.needsCompletionsFallback).toBe(false);
	});
});
