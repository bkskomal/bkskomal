import type { ChildProcess } from "node:child_process";
import { EventEmitter } from "node:events";
import { PassThrough, Writable } from "node:stream";
import type { HookConfig } from "@iom/shared";
import { describe, expect, it, vi } from "vitest";
import { HookRunner, type SpawnFn, matcherApplies } from "../src/hook-runner";

/** Build a fake ChildProcess that we can drive in tests. */
function fakeChild(opts: {
	stdout?: string;
	stderr?: string;
	exitCode?: number;
	delayMs?: number;
	errorOnSpawn?: Error;
}): ChildProcess {
	const ee = new EventEmitter() as ChildProcess;
	const stdout = new PassThrough();
	const stderr = new PassThrough();
	const stdinChunks: string[] = [];
	const stdin = new Writable({
		write(chunk, _enc, cb) {
			stdinChunks.push(chunk.toString());
			cb();
		},
	});
	Object.assign(ee, {
		stdout,
		stderr,
		stdin,
		kill: vi.fn(),
		stdinChunks,
	});

	if (opts.errorOnSpawn) {
		// Defer so listeners can attach first.
		setImmediate(() => ee.emit("error", opts.errorOnSpawn));
		return ee;
	}

	const finish = () => {
		if (opts.stdout) stdout.write(opts.stdout);
		if (opts.stderr) stderr.write(opts.stderr);
		stdout.end();
		stderr.end();
		ee.emit("close", opts.exitCode ?? 0);
	};
	if (opts.delayMs && opts.delayMs > 0) setTimeout(finish, opts.delayMs);
	else setImmediate(finish);

	return ee;
}

function makeSpawn(plan: ((cmd: string) => ChildProcess) | ChildProcess): {
	spawnFn: SpawnFn;
	calls: { command: string }[];
} {
	const calls: { command: string }[] = [];
	const spawnFn = ((command: string) => {
		calls.push({ command });
		return typeof plan === "function" ? plan(command) : plan;
	}) as unknown as SpawnFn;
	return { spawnFn, calls };
}

describe("matcherApplies", () => {
	it("matches everything when matcher is undefined", () => {
		expect(matcherApplies(undefined, "anything")).toBe(true);
	});

	it("does a substring check by default", () => {
		expect(matcherApplies("write", "write_file")).toBe(true);
		expect(matcherApplies("read", "write_file")).toBe(false);
	});

	it("treats matchers with * or ? as globs anchored to the full string", () => {
		expect(matcherApplies("write_*", "write_file")).toBe(true);
		expect(matcherApplies("write_*", "read_file")).toBe(false);
		expect(matcherApplies("?ead_file", "read_file")).toBe(true);
		expect(matcherApplies("?ead_file", "head_file")).toBe(true);
		expect(matcherApplies("?ead_file", "bread_file")).toBe(false);
	});
});

describe("HookRunner", () => {
	const baseHook: HookConfig = {
		event: "PreToolUse",
		command: "noop",
	};

	it("returns allow:true when no hooks match", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: "" }));
		const runner = new HookRunner([], { spawnFn });
		const result = await runner.runPreToolUse("write_file", { path: "/x" });
		expect(result.allow).toBe(true);
	});

	it("treats non-JSON stdout as allow:true (passive logger)", async () => {
		const { spawnFn, calls } = makeSpawn(() => fakeChild({ stdout: "logging this tool call\n" }));
		const runner = new HookRunner([{ ...baseHook }], { spawnFn });
		const result = await runner.runPreToolUse("write_file", { path: "/x" });
		expect(result.allow).toBe(true);
		expect(calls).toHaveLength(1);
	});

	it("blocks when a hook returns allow:false JSON", async () => {
		const { spawnFn } = makeSpawn(() =>
			fakeChild({ stdout: '{"allow": false, "reason": "policy"}' }),
		);
		const runner = new HookRunner([{ ...baseHook }], { spawnFn });
		const result = await runner.runPreToolUse("write_file", { path: "/x" });
		expect(result.allow).toBe(false);
		expect(result.reason).toBe("policy");
	});

	it("returns the first blocking verdict's reason when multiple hooks match", async () => {
		const stdoutByCommand: Record<string, string> = {
			first: '{"allow": true}',
			second: '{"allow": false, "reason": "second hook"}',
			third: '{"allow": false, "reason": "never reached"}',
		};
		const { spawnFn } = makeSpawn((cmd) => fakeChild({ stdout: stdoutByCommand[cmd] ?? "" }));
		const runner = new HookRunner(
			[
				{ ...baseHook, command: "first" },
				{ ...baseHook, command: "second" },
				{ ...baseHook, command: "third" },
			],
			{ spawnFn },
		);
		const result = await runner.runPreToolUse("write_file", { path: "/x" });
		expect(result.allow).toBe(false);
		expect(result.reason).toBe("second hook");
	});

	it("honors the matcher field", async () => {
		const { spawnFn, calls } = makeSpawn(() => fakeChild({ stdout: '{"allow": false}' }));
		const runner = new HookRunner([{ ...baseHook, matcher: "write_*", command: "blocker" }], {
			spawnFn,
		});

		// Doesn't match → hook should not run.
		const allowed = await runner.runPreToolUse("read_file", {});
		expect(allowed.allow).toBe(true);
		expect(calls).toHaveLength(0);

		// Matches → hook should run and block.
		const blocked = await runner.runPreToolUse("write_file", {});
		expect(blocked.allow).toBe(false);
		expect(calls).toHaveLength(1);
	});

	it("pipes the event payload to the child's stdin as JSON", async () => {
		const children: ChildProcess[] = [];
		const { spawnFn } = makeSpawn(() => {
			const c = fakeChild({ stdout: "" });
			children.push(c);
			return c;
		});
		const runner = new HookRunner([{ ...baseHook }], { spawnFn });
		await runner.runPreToolUse("write_file", { path: "/tmp/x" });
		const stdinChunks = (children[0] as unknown as { stdinChunks: string[] }).stdinChunks.join("");
		const parsed = JSON.parse(stdinChunks.trim());
		expect(parsed).toEqual({ toolName: "write_file", args: { path: "/tmp/x" } });
	});

	it("enforces the timeout and treats a slow hook as allow:true", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: '{"allow":false}', delayMs: 100 }));
		const runner = new HookRunner([{ ...baseHook, timeout: 10 }], { spawnFn });
		const start = Date.now();
		const result = await runner.runPreToolUse("write_file", {});
		const elapsed = Date.now() - start;
		expect(result.allow).toBe(true);
		expect(elapsed).toBeLessThan(80);
	});

	it("recovers from a spawn that emits 'error' (missing binary) by allowing the action", async () => {
		const { spawnFn } = makeSpawn(() =>
			fakeChild({ errorOnSpawn: new Error("ENOENT: no such file") }),
		);
		const runner = new HookRunner([{ ...baseHook, command: "no-such-bin" }], { spawnFn });
		const result = await runner.runPreToolUse("write_file", {});
		expect(result.allow).toBe(true);
	});

	it("recovers from a synchronous spawn throw by allowing the action", async () => {
		const spawnFn = (() => {
			throw new Error("spawn EACCES");
		}) as unknown as SpawnFn;
		const runner = new HookRunner([{ ...baseHook, command: "no-such-bin" }], { spawnFn });
		const result = await runner.runPreToolUse("write_file", {});
		expect(result.allow).toBe(true);
	});

	it("runStop applies its tighter cap on top of the per-hook timeout", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: "", delayMs: 50 }));
		const runner = new HookRunner([{ event: "Stop", command: "slow", timeout: 60_000 }], {
			spawnFn,
			stopTimeoutMs: 10,
		});
		const start = Date.now();
		const result = await runner.runStop();
		const elapsed = Date.now() - start;
		expect(result.allow).toBe(true);
		// Loose upper bound — leaves plenty of headroom for CI variance.
		expect(elapsed).toBeLessThan(100);
	});

	it("forwards a modifiedPayload from the verdict", async () => {
		const { spawnFn } = makeSpawn(() =>
			fakeChild({ stdout: '{"allow": true, "modifiedPayload": {"path": "/safe"}}' }),
		);
		const runner = new HookRunner([{ ...baseHook }], { spawnFn });
		const result = await runner.runPreToolUse("write_file", { path: "/danger" });
		expect(result.allow).toBe(true);
		expect(result.modifiedPayload).toEqual({ path: "/safe" });
	});

	it("dispatches each event to hooks of the matching event type only", async () => {
		const { spawnFn, calls } = makeSpawn(() => fakeChild({ stdout: "" }));
		const runner = new HookRunner(
			[
				{ event: "PreToolUse", command: "pre" },
				{ event: "PostToolUse", command: "post" },
				{ event: "UserPromptSubmit", command: "prompt" },
				{ event: "SessionStart", command: "start" },
				{ event: "Stop", command: "stop" },
			],
			{ spawnFn },
		);
		await runner.runPreToolUse("write_file", {});
		await runner.runPostToolUse("write_file", "ok");
		await runner.runUserPromptSubmit("hello");
		await runner.runSessionStart();
		await runner.runStop();
		expect(calls.map((c) => c.command)).toEqual(["pre", "post", "prompt", "start", "stop"]);
	});
});
