import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	type AuditEntry,
	AuditLog,
	estimateTokens,
	hashArgs,
	nowIso,
	shortHash,
} from "../src/audit-log";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-audit-"));
}

function toolEntry(over: Partial<AuditEntry> = {}): AuditEntry {
	return {
		kind: "tool",
		ts: nowIso(),
		sessionId: "sess-1",
		mode: "code",
		modelId: "claude-sonnet-4-6",
		toolName: "read_file",
		argsHash: shortHash("args"),
		resultBytes: 1024,
		isError: false,
		durationMs: 12,
		...(over as object),
	} as AuditEntry;
}

function messageEntry(over: Partial<AuditEntry> = {}): AuditEntry {
	return {
		kind: "message",
		ts: nowIso(),
		sessionId: "sess-1",
		role: "user",
		contentHash: shortHash("hello"),
		contentBytes: 5,
		tokenCount: estimateTokens("hello"),
		...(over as object),
	} as AuditEntry;
}

describe("AuditLog.record / tail", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("creates the .iom directory on first write", async () => {
		const log = new AuditLog(dir);
		await log.record(toolEntry());
		const stat = await fs.stat(path.join(dir, ".iom", "audit.log"));
		expect(stat.isFile()).toBe(true);
	});

	it("appends each entry as a single JSON line", async () => {
		const log = new AuditLog(dir);
		await log.record(toolEntry({ toolName: "a" }));
		await log.record(toolEntry({ toolName: "b" }));
		await log.record(messageEntry({ role: "assistant" }));
		const raw = await fs.readFile(log.getPath(), "utf-8");
		const lines = raw.split("\n").filter((l) => l.length > 0);
		expect(lines).toHaveLength(3);
		for (const l of lines) {
			// Each line must round-trip JSON cleanly.
			expect(() => JSON.parse(l)).not.toThrow();
		}
	});

	it("tail() returns recent entries in chronological order", async () => {
		const log = new AuditLog(dir);
		for (let i = 0; i < 5; i++) await log.record(toolEntry({ toolName: `t${i}` }));
		const all = await log.tail(10);
		expect(all).toHaveLength(5);
		// Order preserved.
		expect((all[0] as { toolName: string }).toolName).toBe("t0");
		expect((all[4] as { toolName: string }).toolName).toBe("t4");
	});

	it("tail(n) returns at most n entries (the last n)", async () => {
		const log = new AuditLog(dir);
		for (let i = 0; i < 5; i++) await log.record(toolEntry({ toolName: `t${i}` }));
		const tail2 = await log.tail(2);
		expect(tail2).toHaveLength(2);
		expect((tail2[0] as { toolName: string }).toolName).toBe("t3");
		expect((tail2[1] as { toolName: string }).toolName).toBe("t4");
	});

	it("tail() returns [] when no log exists yet", async () => {
		const log = new AuditLog(dir);
		expect(await log.tail()).toEqual([]);
	});

	it("skips corrupt lines silently", async () => {
		const log = new AuditLog(dir);
		await log.record(toolEntry({ toolName: "ok-1" }));
		await fs.appendFile(log.getPath(), "this is not json\n", "utf-8");
		await fs.appendFile(log.getPath(), '{"truncated": \n', "utf-8");
		await log.record(toolEntry({ toolName: "ok-2" }));
		const entries = await log.tail(10);
		expect(entries).toHaveLength(2);
		expect((entries[0] as { toolName: string }).toolName).toBe("ok-1");
		expect((entries[1] as { toolName: string }).toolName).toBe("ok-2");
	});

	it("respects enabled:false — no file written, tail still works", async () => {
		const log = new AuditLog(dir, { enabled: false });
		await log.record(toolEntry());
		await log.record(messageEntry());
		// Nothing written.
		await expect(fs.stat(log.getPath())).rejects.toBeTruthy();
		expect(log.isEnabled()).toBe(false);
		expect(await log.tail()).toEqual([]);
	});

	it("serializes concurrent writes (no interleaved bytes)", async () => {
		const log = new AuditLog(dir);
		const writes = [];
		for (let i = 0; i < 20; i++) {
			writes.push(log.record(toolEntry({ toolName: `c${i}` })));
		}
		await Promise.all(writes);
		const entries = await log.tail(50);
		expect(entries).toHaveLength(20);
		// Every line must parse cleanly — no mid-line corruption.
		for (const e of entries) {
			expect(e.kind === "tool" || e.kind === "message").toBe(true);
		}
	});
});

describe("hash helpers", () => {
	it("shortHash returns 16 hex chars and is deterministic", () => {
		const a = shortHash("hello");
		const b = shortHash("hello");
		expect(a).toBe(b);
		expect(a).toHaveLength(16);
		expect(/^[0-9a-f]{16}$/.test(a)).toBe(true);
	});

	it("shortHash differs between inputs", () => {
		expect(shortHash("a")).not.toBe(shortHash("b"));
	});

	it("hashArgs handles objects and undefined", () => {
		expect(hashArgs({ a: 1 })).toHaveLength(16);
		expect(hashArgs(undefined)).toHaveLength(16);
	});

	it("estimateTokens scales with length", () => {
		expect(estimateTokens("")).toBe(0);
		expect(estimateTokens("a")).toBe(1);
		expect(estimateTokens("a".repeat(40))).toBe(10);
	});
});
