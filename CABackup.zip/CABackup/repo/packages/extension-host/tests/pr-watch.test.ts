import { describe, expect, it } from "vitest";
import { type PrSummary, PrWatcher, computeNewPrs, parsePrList } from "../src/pr-watch";

describe("parsePrList", () => {
	it("parses a typical `gh pr list --json` payload", () => {
		const stdout = JSON.stringify([
			{
				number: 12,
				headRefName: "feature/x",
				createdAt: "2026-05-21T10:00:00Z",
				author: { login: "octocat" },
				title: "Add X",
				url: "https://github.com/o/r/pull/12",
			},
			{
				number: 13,
				headRefName: "feature/y",
				createdAt: "2026-05-21T11:00:00Z",
				author: { login: "hubot" },
			},
		]);
		const parsed = parsePrList(stdout);
		expect(parsed).toHaveLength(2);
		expect(parsed[0]).toMatchObject({
			number: 12,
			headRefName: "feature/x",
			author: { login: "octocat" },
			title: "Add X",
			url: "https://github.com/o/r/pull/12",
		});
		expect(parsed[1]).toMatchObject({ number: 13, author: { login: "hubot" } });
	});

	it("returns [] for empty/whitespace input", () => {
		expect(parsePrList("")).toEqual([]);
		expect(parsePrList("   \n  ")).toEqual([]);
	});

	it("returns [] for malformed JSON", () => {
		expect(parsePrList("{not json}")).toEqual([]);
	});

	it("drops rows with missing/invalid number or createdAt", () => {
		const stdout = JSON.stringify([
			{ headRefName: "x", createdAt: "2026-05-21T00:00:00Z", author: { login: "a" } },
			{ number: 0, headRefName: "x", createdAt: "2026-05-21T00:00:00Z", author: { login: "a" } },
			{ number: 5, headRefName: "x", createdAt: "", author: { login: "a" } },
			{ number: 7, headRefName: "x", createdAt: "2026-05-21T00:00:00Z", author: { login: "a" } },
		]);
		const parsed = parsePrList(stdout);
		expect(parsed).toHaveLength(1);
		expect(parsed[0].number).toBe(7);
	});

	it("handles null author gracefully", () => {
		const stdout = JSON.stringify([
			{
				number: 1,
				headRefName: "x",
				createdAt: "2026-05-21T00:00:00Z",
				author: null,
			},
		]);
		const parsed = parsePrList(stdout);
		expect(parsed[0].author.login).toBe("");
	});
});

describe("computeNewPrs", () => {
	const prA: PrSummary = {
		number: 1,
		headRefName: "a",
		createdAt: "2026-05-21T10:00:00Z",
		author: { login: "alice" },
	};
	const prB: PrSummary = {
		number: 2,
		headRefName: "b",
		createdAt: "2026-05-21T11:00:00Z",
		author: { login: "bob" },
	};
	const prMe: PrSummary = {
		number: 3,
		headRefName: "me",
		createdAt: "2026-05-21T12:00:00Z",
		author: { login: "alice" },
	};

	it("returns nothing on the baseline poll (lastPollAt undefined)", () => {
		const out = computeNewPrs([prA, prB], { lastPollAt: undefined, seenNumbers: new Set() }, "alice");
		expect(out).toEqual([]);
	});

	it("returns PRs newer than lastPollAt, skipping ones authored by me", () => {
		const out = computeNewPrs(
			[prA, prB, prMe],
			{ lastPollAt: "2026-05-21T09:30:00Z", seenNumbers: new Set() },
			"alice",
		);
		// prA from alice (me) → skipped; prB from bob → kept; prMe from alice → skipped.
		expect(out).toHaveLength(1);
		expect(out[0].number).toBe(2);
	});

	it("filters PRs already in seenNumbers even when older than baseline change", () => {
		const out = computeNewPrs(
			[prB],
			{ lastPollAt: "2026-05-21T09:00:00Z", seenNumbers: new Set([2]) },
			"alice",
		);
		expect(out).toEqual([]);
	});

	it("treats the author match case-insensitively", () => {
		const pr: PrSummary = { ...prA, author: { login: "ALICE" } };
		const out = computeNewPrs(
			[pr],
			{ lastPollAt: "2026-05-21T09:00:00Z", seenNumbers: new Set() },
			"alice",
		);
		expect(out).toEqual([]);
	});

	it("drops PRs with an empty author login (defensive)", () => {
		const pr: PrSummary = { ...prA, author: { login: "" } };
		const out = computeNewPrs(
			[pr],
			{ lastPollAt: "2026-05-21T09:00:00Z", seenNumbers: new Set() },
			"alice",
		);
		expect(out).toEqual([]);
	});
});

describe("PrWatcher.pollOnce — last-poll bookkeeping", () => {
	it("first poll is baseline: returns nothing AND seeds lastPollAt", async () => {
		const exec = makeExecMock([
			{ exitCode: 0, stdout: prListJson([mk(1, "alice", "2026-05-21T10:00:00Z")]), stderr: "" },
		]);
		const w = new PrWatcher({
			repo: "o/r",
			host: { exec } as unknown as import("@iom/shared").HostContext,
			intervalMs: 60_000,
			currentUser: "bob",
		});
		const seen: PrSummary[] = [];
		w.onNewPr((pr) => seen.push(pr));
		const fresh = await w.pollOnce();
		expect(fresh).toEqual([]);
		expect(seen).toEqual([]);
	});

	it("second poll emits PRs strictly newer than the recorded lastPollAt", async () => {
		// 1st poll: just PR #1 from 10:00, baseline.
		// 2nd poll: PR #1 still present + PR #2 created after baseline.
		const exec = makeExecMock([
			{
				exitCode: 0,
				stdout: prListJson([mk(1, "alice", "2026-05-21T10:00:00Z")]),
				stderr: "",
			},
			{
				exitCode: 0,
				stdout: prListJson([
					mk(1, "alice", "2026-05-21T10:00:00Z"),
					mk(2, "carol", "2050-01-01T00:00:00Z"),
				]),
				stderr: "",
			},
		]);
		const w = new PrWatcher({
			repo: "o/r",
			host: { exec } as unknown as import("@iom/shared").HostContext,
			intervalMs: 60_000,
			currentUser: "bob",
		});
		const seen: PrSummary[] = [];
		w.onNewPr((pr) => seen.push(pr));
		await w.pollOnce();
		const fresh = await w.pollOnce();
		expect(fresh.map((p) => p.number)).toEqual([2]);
		expect(seen.map((p) => p.number)).toEqual([2]);
	});

	it("dedupes by PR number across polls", async () => {
		const exec = makeExecMock([
			{ exitCode: 0, stdout: prListJson([mk(1, "alice", "2026-05-21T10:00:00Z")]), stderr: "" },
			{
				exitCode: 0,
				stdout: prListJson([
					mk(1, "alice", "2026-05-21T10:00:00Z"),
					mk(2, "carol", "2050-01-01T00:00:00Z"),
				]),
				stderr: "",
			},
			{
				exitCode: 0,
				stdout: prListJson([mk(2, "carol", "2050-01-01T00:00:00Z")]),
				stderr: "",
			},
		]);
		const w = new PrWatcher({
			repo: "o/r",
			host: { exec } as unknown as import("@iom/shared").HostContext,
			intervalMs: 60_000,
			currentUser: "bob",
		});
		const seen: PrSummary[] = [];
		w.onNewPr((pr) => seen.push(pr));
		await w.pollOnce(); // baseline
		const a = await w.pollOnce(); // sees #2 once
		const b = await w.pollOnce(); // #2 already seen → empty
		expect(a.map((p) => p.number)).toEqual([2]);
		expect(b).toEqual([]);
		expect(seen.map((p) => p.number)).toEqual([2]);
	});

	it("skips PRs the current user authored", async () => {
		const exec = makeExecMock([
			{ exitCode: 0, stdout: prListJson([mk(1, "bob", "2026-05-21T10:00:00Z")]), stderr: "" },
			{
				exitCode: 0,
				stdout: prListJson([
					mk(1, "bob", "2026-05-21T10:00:00Z"),
					mk(2, "bob", "2050-01-01T00:00:00Z"),
					mk(3, "carol", "2050-01-01T00:00:01Z"),
				]),
				stderr: "",
			},
		]);
		const w = new PrWatcher({
			repo: "o/r",
			host: { exec } as unknown as import("@iom/shared").HostContext,
			intervalMs: 60_000,
			currentUser: "bob",
		});
		const seen: PrSummary[] = [];
		w.onNewPr((pr) => seen.push(pr));
		await w.pollOnce();
		const fresh = await w.pollOnce();
		expect(fresh.map((p) => p.number)).toEqual([3]);
		expect(seen.map((p) => p.author.login)).toEqual(["carol"]);
	});

	it("stop() prevents further polls from emitting", async () => {
		const exec = makeExecMock([
			{ exitCode: 0, stdout: prListJson([mk(1, "alice", "2026-05-21T10:00:00Z")]), stderr: "" },
		]);
		const w = new PrWatcher({
			repo: "o/r",
			host: { exec } as unknown as import("@iom/shared").HostContext,
			intervalMs: 60_000,
			currentUser: "bob",
		});
		w.stop();
		const fresh = await w.pollOnce();
		expect(fresh).toEqual([]);
	});

	// R7-C regression test: in a high-velocity repo the watcher used to add
	// every PR number it ever saw to `seenNumbers` and never evicted them.
	// Over a long-running session this is a slow memory leak. The cap should
	// keep the set bounded.
	it("caps the internal seenNumbers set so it can't grow forever (R7-C)", async () => {
		const rows: unknown[] = [];
		for (let i = 1; i <= 2500; i++) {
			rows.push(mk(i, "alice", `2026-05-21T${String(i % 24).padStart(2, "0")}:00:00Z`));
		}
		const exec = makeExecMock([{ exitCode: 0, stdout: prListJson(rows), stderr: "" }]);
		const w = new PrWatcher({
			repo: "o/r",
			host: { exec } as unknown as import("@iom/shared").HostContext,
			intervalMs: 60_000,
			currentUser: "bob",
		});
		await w.pollOnce();
		const internal = w as unknown as { seenNumbers: Set<number> };
		// Cap is 2000 in the source; result should be at or below the cap.
		expect(internal.seenNumbers.size).toBeLessThanOrEqual(2000);
	});
});

// ---- helpers ----

function mk(number: number, login: string, createdAt: string): unknown {
	return {
		number,
		headRefName: `branch-${number}`,
		createdAt,
		author: { login },
	};
}

function prListJson(rows: unknown[]): string {
	return JSON.stringify(rows);
}

function makeExecMock(
	results: { exitCode: number; stdout: string; stderr: string }[],
): (cmd: string) => Promise<import("@iom/shared").ExecResult> {
	let i = 0;
	return async () => {
		const r = results[Math.min(i, results.length - 1)];
		i++;
		return r;
	};
}
