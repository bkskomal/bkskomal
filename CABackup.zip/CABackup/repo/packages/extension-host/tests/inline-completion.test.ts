import type { ProviderSpec, ProviderStreamEvent } from "@iom/shared";
// R5-A: unit tests for the inline-completion module. Covers the pure helpers
// (FIM prompt builder, cache-key derivation, debouncer, stop-sequence trim)
// plus the cancellation behaviour of `fetchInlineCompletion` driven by a
// fake provider stream.
import { describe, expect, it, vi } from "vitest";
import {
	_resetInlineCompletionStats,
	applyStopSequences,
	buildCacheKey,
	buildFimPrompt,
	createDebouncer,
	createInlineCompletionCache,
	fetchInlineCompletion,
	getInlineCompletionStats,
	resolveCompletionTarget,
	stripFences,
} from "../src/inline-completion";

function fakeProvider(events: ProviderStreamEvent[], onAbort?: () => void): ProviderSpec {
	return {
		id: "fake",
		displayName: "Fake",
		async *stream(req) {
			for (const ev of events) {
				if (req.signal?.aborted) {
					onAbort?.();
					return;
				}
				yield ev;
			}
		},
	};
}

describe("buildFimPrompt", () => {
	it("splits prefix and suffix at the cursor offset", () => {
		const text = "line1\nline2\nline3\n";
		const cursorOffset = "line1\nline".length; // mid-word in line2
		const out = buildFimPrompt({
			documentText: text,
			offset: cursorOffset,
			languageId: "typescript",
		});
		expect(out.prefix).toBe("line1\nline");
		expect(out.suffix).toBe("2\nline3\n");
	});

	it("includes a language-aware comment hint", () => {
		const py = buildFimPrompt({ documentText: "", offset: 0, languageId: "python" });
		expect(py.user).toContain("# Python code:");
		const ts = buildFimPrompt({ documentText: "", offset: 0, languageId: "typescript" });
		expect(ts.user).toContain("// TypeScript code:");
		const go = buildFimPrompt({ documentText: "", offset: 0, languageId: "go" });
		expect(go.user).toContain("// Go code:");
	});

	it("clamps the window to N lines on each side", () => {
		const lines: string[] = [];
		for (let i = 0; i < 200; i++) lines.push(`L${i}`);
		const text = lines.join("\n");
		const mid = text.indexOf("L100");
		const out = buildFimPrompt({
			documentText: text,
			offset: mid,
			languageId: "typescript",
			windowLines: 3,
		});
		// 3 newlines back from the start of L100 lands at the start of L98.
		expect(out.prefix).toContain("L98");
		expect(out.prefix).not.toContain("L97");
		expect(out.suffix).toContain("L100");
		expect(out.suffix).toContain("L102");
		expect(out.suffix).not.toContain("L103");
	});

	it("includes the FIM markers in the prompt", () => {
		const out = buildFimPrompt({
			documentText: "a\nb\nc",
			offset: 2,
			languageId: "javascript",
		});
		expect(out.user).toContain("<prefix>");
		expect(out.user).toContain("<cursor/>");
		expect(out.user).toContain("<suffix>");
		expect(out.system).toContain("code-completion engine");
	});

	it("splices the recent-edits block in BEFORE the prefix/suffix when provided", () => {
		const out = buildFimPrompt({
			documentText: "current = 1",
			offset: 5,
			languageId: "typescript",
			recentEditsBlock:
				'<recent_edits>\n<edit path="other.ts" lang="typescript">\nrenamed thing\n</edit>\n</recent_edits>',
		});
		expect(out.user).toContain("<recent_edits>");
		expect(out.user).toContain("renamed thing");
		// Order: language hint → recent-edits → prefix.
		const hintIdx = out.user.indexOf("// TypeScript code:");
		const recentIdx = out.user.indexOf("<recent_edits>");
		const prefixIdx = out.user.indexOf("<prefix>");
		expect(hintIdx).toBeGreaterThanOrEqual(0);
		expect(recentIdx).toBeGreaterThan(hintIdx);
		expect(prefixIdx).toBeGreaterThan(recentIdx);
	});

	it("omits the recent-edits region when the block is empty (default behavior preserved)", () => {
		const out = buildFimPrompt({
			documentText: "x",
			offset: 0,
			languageId: "typescript",
			recentEditsBlock: "",
		});
		expect(out.user).not.toContain("<recent_edits>");
	});
});

describe("buildCacheKey", () => {
	it("is stable for identical inputs", () => {
		const k1 = buildCacheKey({
			uri: "file:///a.ts",
			version: 7,
			line: 3,
			character: 12,
			lineText: "  return 1;",
		});
		const k2 = buildCacheKey({
			uri: "file:///a.ts",
			version: 7,
			line: 3,
			character: 12,
			lineText: "  return 1;",
		});
		expect(k1).toBe(k2);
	});

	it("differs when version changes (the key invariant)", () => {
		const k1 = buildCacheKey({
			uri: "f",
			version: 1,
			line: 0,
			character: 0,
			lineText: "x",
		});
		const k2 = buildCacheKey({
			uri: "f",
			version: 2,
			line: 0,
			character: 0,
			lineText: "x",
		});
		expect(k1).not.toBe(k2);
	});

	it("differs when line text changes (even at same position)", () => {
		const k1 = buildCacheKey({
			uri: "f",
			version: 1,
			line: 0,
			character: 0,
			lineText: "foo",
		});
		const k2 = buildCacheKey({
			uri: "f",
			version: 1,
			line: 0,
			character: 0,
			lineText: "bar",
		});
		expect(k1).not.toBe(k2);
	});
});

describe("createInlineCompletionCache", () => {
	it("returns stored values within TTL", () => {
		let now = 1000;
		const cache = createInlineCompletionCache(() => now);
		cache.set("k", "v");
		expect(cache.get("k")).toBe("v");
		now += 29_000;
		expect(cache.get("k")).toBe("v");
	});

	it("evicts after TTL expiry", () => {
		let now = 1000;
		const cache = createInlineCompletionCache(() => now);
		cache.set("k", "v");
		now += 31_000;
		expect(cache.get("k")).toBeUndefined();
	});

	it("returns undefined for missing keys", () => {
		const cache = createInlineCompletionCache();
		expect(cache.get("nope")).toBeUndefined();
	});
});

describe("applyStopSequences", () => {
	it("truncates at the first stop sequence", () => {
		// R8-A: default stop list is now ["\n\n\n", "</code>", "```"].
		expect(applyStopSequences("abc\n\n\ndef")).toBe("abc");
		expect(applyStopSequences("abc</code>def")).toBe("abc");
	});

	it("returns input unchanged when no stop appears", () => {
		expect(applyStopSequences("just code")).toBe("just code");
	});

	it("picks the earliest of multiple matching stops", () => {
		expect(applyStopSequences("a</code>b\n\n\nc")).toBe("a");
	});

	it("accepts a custom stop list", () => {
		expect(applyStopSequences("x|y|z", ["|"])).toBe("x");
	});
});

describe("stripFences", () => {
	it("strips opening and closing triple-backtick fences", () => {
		expect(stripFences("```ts\nconst x = 1;\n```")).toBe("const x = 1;");
	});

	it("strips fences without a language tag", () => {
		expect(stripFences("```\nhi\n```")).toBe("hi");
	});

	it("returns plain text unchanged", () => {
		expect(stripFences("plain")).toBe("plain");
	});
});

describe("createDebouncer", () => {
	it("coalesces back-to-back invocations and resolves only the latest", async () => {
		vi.useFakeTimers();
		try {
			const debounce = createDebouncer<number>(50);
			const calls: number[] = [];
			const p1 = debounce(async () => {
				calls.push(1);
				return 1;
			});
			const p2 = debounce(async () => {
				calls.push(2);
				return 2;
			});
			const p3 = debounce(async () => {
				calls.push(3);
				return 3;
			});
			await vi.advanceTimersByTimeAsync(100);
			const [r1, r2, r3] = await Promise.all([p1, p2, p3]);
			expect(calls).toEqual([3]);
			expect(r1).toBeUndefined();
			expect(r2).toBeUndefined();
			expect(r3).toBe(3);
		} finally {
			vi.useRealTimers();
		}
	});
});

describe("fetchInlineCompletion", () => {
	it("collects text_delta events and stops at message_end", async () => {
		const provider = fakeProvider([
			{ type: "text_delta", text: "const " },
			{ type: "text_delta", text: "x = 1;" },
			{ type: "message_end", stopReason: "end" },
		]);
		const ctrl = new AbortController();
		const out = await fetchInlineCompletion({
			provider,
			modelId: "m",
			system: "s",
			user: "u",
			maxTokens: 64,
			signal: ctrl.signal,
		});
		expect(out).toBe("const x = 1;");
	});

	it("returns undefined on provider error events", async () => {
		const provider = fakeProvider([{ type: "error", message: "boom" }]);
		const ctrl = new AbortController();
		const out = await fetchInlineCompletion({
			provider,
			modelId: "m",
			system: "s",
			user: "u",
			maxTokens: 64,
			signal: ctrl.signal,
		});
		expect(out).toBeUndefined();
	});

	it("aborts when the signal is fired before iteration", async () => {
		const aborted = vi.fn();
		const provider = fakeProvider(
			[
				{ type: "text_delta", text: "a" },
				{ type: "text_delta", text: "b" },
				{ type: "message_end", stopReason: "end" },
			],
			aborted,
		);
		const ctrl = new AbortController();
		ctrl.abort();
		const out = await fetchInlineCompletion({
			provider,
			modelId: "m",
			system: "s",
			user: "u",
			maxTokens: 64,
			signal: ctrl.signal,
		});
		expect(out).toBeUndefined();
		expect(aborted).toHaveBeenCalledTimes(1);
	});

	it("truncates at a stop sequence emitted in the stream", async () => {
		// R8-A: triple-newline is the new \n\n boundary.
		const provider = fakeProvider([
			{ type: "text_delta", text: "code1\n" },
			{ type: "text_delta", text: "\n\nmore" },
			{ type: "message_end", stopReason: "end" },
		]);
		const ctrl = new AbortController();
		const out = await fetchInlineCompletion({
			provider,
			modelId: "m",
			system: "s",
			user: "u",
			maxTokens: 64,
			signal: ctrl.signal,
		});
		expect(out).toBe("code1");
	});

	it("strips a model-added code fence", async () => {
		const provider = fakeProvider([
			{ type: "text_delta", text: "```ts\nconsole.log(1);\n```" },
			{ type: "message_end", stopReason: "end" },
		]);
		const ctrl = new AbortController();
		const out = await fetchInlineCompletion({
			provider,
			modelId: "m",
			system: "s",
			user: "u",
			maxTokens: 64,
			signal: ctrl.signal,
		});
		expect(out).toBe("console.log(1);");
	});
});

describe("getInlineCompletionStats", () => {
	it("starts at zero after reset", () => {
		_resetInlineCompletionStats();
		const s = getInlineCompletionStats();
		expect(s.accepted).toBe(0);
		expect(s.rejected).toBe(0);
		expect(s.shown).toBe(0);
	});
});

describe("resolveCompletionTarget (2026-06-02: separate autocomplete model lane)", () => {
	const dummyProvider = {
		id: "p",
		displayName: "P",
		stream: async function* () {},
	} as unknown as ProviderSpec;
	const altProvider = {
		id: "alt",
		displayName: "Alt",
		stream: async function* () {},
	} as unknown as ProviderSpec;
	const registry: Record<string, ProviderSpec> = { chat: dummyProvider, fast: altProvider };
	const lookup = (id: string) => registry[id];

	it("falls back to chat provider + chat model when both completion overrides are empty", () => {
		const t = resolveCompletionTarget({
			completionModel: "",
			completionProviderId: "",
			chatModelId: "claude-sonnet",
			chatProviderId: "chat",
			providerLookup: lookup,
		});
		expect(t?.provider).toBe(dummyProvider);
		expect(t?.modelId).toBe("claude-sonnet");
	});

	it("uses chat provider + override model when only completionModel is set", () => {
		const t = resolveCompletionTarget({
			completionModel: "qwen2.5-coder:7b",
			completionProviderId: "",
			chatModelId: "claude-sonnet",
			chatProviderId: "chat",
			providerLookup: lookup,
		});
		expect(t?.provider).toBe(dummyProvider);
		expect(t?.modelId).toBe("qwen2.5-coder:7b");
	});

	it("uses BOTH overrides when both are set (separate-lane setup)", () => {
		const t = resolveCompletionTarget({
			completionModel: "codestral-22b",
			completionProviderId: "fast",
			chatModelId: "claude-sonnet",
			chatProviderId: "chat",
			providerLookup: lookup,
		});
		expect(t?.provider).toBe(altProvider);
		expect(t?.modelId).toBe("codestral-22b");
	});

	it("returns undefined when the resolved provider isn't registered (graceful no-suggestion path)", () => {
		const t = resolveCompletionTarget({
			completionModel: "x",
			completionProviderId: "missing",
			chatModelId: "claude-sonnet",
			chatProviderId: "chat",
			providerLookup: lookup,
		});
		expect(t).toBeUndefined();
	});

	it("returns undefined when chat model id is missing (no fallback exists)", () => {
		const t = resolveCompletionTarget({
			completionModel: "",
			completionProviderId: "",
			chatModelId: "",
			chatProviderId: "chat",
			providerLookup: lookup,
		});
		expect(t).toBeUndefined();
	});
});
