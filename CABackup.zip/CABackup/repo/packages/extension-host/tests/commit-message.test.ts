import { describe, expect, it } from "vitest";
import {
	COMMIT_MESSAGE_SYSTEM_PROMPT,
	EmptyDiffError,
	buildCommitPrompt,
	fetchStagedDiff,
	formatCommitMessage,
	parseCommitMessage,
	pickPrimaryRepo,
} from "../src/commit-message";

describe("buildCommitPrompt", () => {
	it("embeds the diff inside a fenced block", () => {
		const out = buildCommitPrompt("diff --git a/x b/x\n+hi");
		expect(out).toContain("```diff");
		expect(out).toContain("diff --git a/x b/x");
		expect(out).toContain("+hi");
	});

	it("truncates oversized diffs with a marker", () => {
		const big = "x".repeat(200);
		const out = buildCommitPrompt(big, 50);
		expect(out).toContain("diff truncated");
		expect(out).toContain("150 more chars");
	});

	it("does not truncate small diffs", () => {
		const out = buildCommitPrompt("tiny", 100);
		expect(out).not.toContain("diff truncated");
	});
});

describe("parseCommitMessage", () => {
	it("splits subject and bullet body on a blank line", () => {
		const raw = ["feat: add login screen", "", "- introduce OAuth flow", "- wire SettingsStore"].join(
			"\n",
		);
		expect(parseCommitMessage(raw)).toEqual({
			subject: "feat: add login screen",
			body: "- introduce OAuth flow\n- wire SettingsStore",
		});
	});

	it("returns subject only when there's no body", () => {
		expect(parseCommitMessage("chore: bump deps")).toEqual({ subject: "chore: bump deps" });
		expect(parseCommitMessage("fix: thing\n\n")).toEqual({ subject: "fix: thing" });
	});

	it("strips surrounding code fences", () => {
		const raw = "```\nfeat: hello\n\n- bullet one\n```";
		expect(parseCommitMessage(raw)).toEqual({
			subject: "feat: hello",
			body: "- bullet one",
		});
	});

	it("caps subject at 72 characters", () => {
		const long = "feat: ".concat("a".repeat(200));
		const result = parseCommitMessage(long);
		expect(result.subject.length).toBe(72);
	});

	it("tolerates leading blank lines", () => {
		const raw = "\n\nrefactor: tidy\n\n- bullet";
		expect(parseCommitMessage(raw)).toEqual({
			subject: "refactor: tidy",
			body: "- bullet",
		});
	});

	it("returns empty subject for non-string input", () => {
		// @ts-expect-error: exercising runtime guard.
		expect(parseCommitMessage(null)).toEqual({ subject: "" });
		// @ts-expect-error: exercising runtime guard.
		expect(parseCommitMessage(undefined)).toEqual({ subject: "" });
	});
});

describe("formatCommitMessage", () => {
	it("joins subject and body with a blank line", () => {
		expect(formatCommitMessage({ subject: "feat: x", body: "- y" })).toBe("feat: x\n\n- y");
	});
	it("returns just the subject when body is absent", () => {
		expect(formatCommitMessage({ subject: "fix: x" })).toBe("fix: x");
		expect(formatCommitMessage({ subject: "fix: x", body: "   " })).toBe("fix: x");
	});
});

describe("COMMIT_MESSAGE_SYSTEM_PROMPT", () => {
	it("mentions the Conventional Commits prefixes", () => {
		expect(COMMIT_MESSAGE_SYSTEM_PROMPT).toContain("feat:");
		expect(COMMIT_MESSAGE_SYSTEM_PROMPT).toContain("fix:");
	});
	it("requires the 72-char subject cap", () => {
		expect(COMMIT_MESSAGE_SYSTEM_PROMPT).toContain("72");
	});
});

describe("fetchStagedDiff", () => {
	it("returns stdout when git diff succeeds (exit 0)", async () => {
		const host = makeHost({ exitCode: 0, stdout: "diff --git a/x b/x\n+hi", stderr: "" });
		await expect(fetchStagedDiff(host)).resolves.toBe("diff --git a/x b/x\n+hi");
	});

	it("returns stdout when git diff exits 1 (diff present, legacy)", async () => {
		const host = makeHost({ exitCode: 1, stdout: "+hi", stderr: "" });
		await expect(fetchStagedDiff(host)).resolves.toBe("+hi");
	});

	it("throws on real failure (exit >= 2)", async () => {
		const host = makeHost({ exitCode: 128, stdout: "", stderr: "not a git repository" });
		await expect(fetchStagedDiff(host)).rejects.toThrow(/git diff --staged failed/);
	});
});

describe("EmptyDiffError", () => {
	it("is a named subclass of Error", () => {
		const err = new EmptyDiffError();
		expect(err).toBeInstanceOf(Error);
		expect(err.name).toBe("EmptyDiffError");
		expect(err.message).toMatch(/stage some changes/i);
	});
});

describe("pickPrimaryRepo", () => {
	const r1 = { inputBox: { value: "" }, rootUri: { fsPath: "/a" } };
	const r2 = { inputBox: { value: "" }, rootUri: { fsPath: "/b" } };

	it("returns undefined when api is missing or empty", () => {
		expect(pickPrimaryRepo(undefined)).toBeUndefined();
		expect(pickPrimaryRepo({ repositories: [] })).toBeUndefined();
	});

	it("prefers a repo matching the workspace folder path", () => {
		expect(pickPrimaryRepo({ repositories: [r1, r2] }, "/b")).toBe(r2);
	});

	it("falls back to the first repo when no folder matches", () => {
		expect(pickPrimaryRepo({ repositories: [r1, r2] }, "/zzz")).toBe(r1);
	});

	it("falls back to the first repo when no folder is supplied", () => {
		expect(pickPrimaryRepo({ repositories: [r1, r2] })).toBe(r1);
	});
});

// ---- helpers ----

function makeHost(execResult: {
	exitCode: number;
	stdout: string;
	stderr: string;
}): import("@iom/shared").HostContext {
	return {
		readFile: async () => "",
		writeFile: async () => undefined,
		fileExists: async () => false,
		exec: async () => execResult,
		workspaceRoot: () => undefined,
		requestApproval: async () => false,
		showDiff: async () => undefined,
		log: () => undefined,
	};
}
