import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { KnowledgeStore, listKnowledgeDocs } from "../src/knowledge";

async function mkTempWorkspace(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-knowledge-"));
}

async function writeDoc(workspace: string, rel: string, body: string): Promise<void> {
	const abs = path.join(workspace, ".iom", "knowledge", rel);
	await fs.mkdir(path.dirname(abs), { recursive: true });
	await fs.writeFile(abs, body, "utf-8");
}

describe("knowledge host module (R5-B)", () => {
	let workspace: string;

	beforeEach(async () => {
		workspace = await mkTempWorkspace();
	});

	afterEach(async () => {
		await fs.rm(workspace, { recursive: true, force: true });
	});

	it("listKnowledgeDocs returns [] when the dir does not exist", async () => {
		expect(await listKnowledgeDocs(workspace)).toEqual([]);
	});

	it("listKnowledgeDocs surfaces every nested markdown file with its H1 title", async () => {
		await writeDoc(workspace, "alpha.md", "# Alpha\n\nbody");
		await writeDoc(workspace, "nested/beta.md", "# Beta heading\n\nmore");
		const docs = await listKnowledgeDocs(workspace);
		const map = new Map(docs.map((d) => [d.path, d.title]));
		expect(map.get(".iom/knowledge/alpha.md")).toBe("Alpha");
		expect(map.get(".iom/knowledge/nested/beta.md")).toBe("Beta heading");
	});

	it("KnowledgeStore.rebuild indexes docs and reports the count", async () => {
		await writeDoc(workspace, "auth.md", "# Auth notes\n\nWe use JWT tokens for auth.");
		await writeDoc(workspace, "deploy.md", "# Deploy guide\n\nRun `make deploy` to ship.");
		const store = new KnowledgeStore({ workspaceRoot: workspace, dbPath: ":memory:" });
		try {
			const result = await store.rebuild();
			expect(result.docs).toBe(2);
			expect(store.docs()).toBe(2);
		} finally {
			store.dispose();
		}
	});

	it("KnowledgeStore.search returns an empty array before rebuild", async () => {
		const store = new KnowledgeStore({ workspaceRoot: workspace, dbPath: ":memory:" });
		try {
			expect(await store.search("anything")).toEqual([]);
		} finally {
			store.dispose();
		}
	});

	it("KnowledgeStore.search returns hits after rebuild", async () => {
		await writeDoc(workspace, "auth.md", "# Auth notes\n\nWe use JWT tokens for authentication.");
		const store = new KnowledgeStore({ workspaceRoot: workspace, dbPath: ":memory:" });
		try {
			await store.rebuild();
			const hits = await store.search("JWT authentication token", 2);
			expect(hits.length).toBeGreaterThan(0);
			expect(hits[0].path).toContain("auth.md");
		} finally {
			store.dispose();
		}
	});
});
