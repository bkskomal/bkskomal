import type { ConversationMessage } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { SessionStore } from "../src/session-store";
import { InMemoryKv } from "../src/storage";

function makeStore(workspaceId = "ws1") {
	const kv = new InMemoryKv();
	let n = 0;
	const store = new SessionStore(kv, {
		getWorkspaceId: () => workspaceId,
		now: () => new Date("2026-05-20T07:00:00.000Z"),
		makeId: () => `s_test_${++n}`,
	});
	return { kv, store };
}

const sampleHistory: ConversationMessage[] = [
	{ role: "user", parts: [{ kind: "text", text: "hi" }] },
	{ role: "assistant", parts: [{ kind: "text", text: "hello!" }] },
];

describe("SessionStore (multi-session)", () => {
	it("starts with no sessions", async () => {
		const { store } = makeStore();
		expect(await store.list()).toEqual([]);
	});

	it("create() adds a session to the index", async () => {
		const { store } = makeStore();
		const meta = await store.create();
		const list = await store.list();
		expect(list).toHaveLength(1);
		expect(list[0].id).toBe(meta.id);
		expect(list[0].title).toBe("New Session");
		expect(list[0].messageCount).toBe(0);
	});

	it("save() persists per-session history and updates index metadata", async () => {
		const { store } = makeStore();
		const meta = await store.create();
		await store.save(meta.id, sampleHistory);
		expect(await store.load(meta.id)).toHaveLength(2);
		const list = await store.list();
		expect(list[0].messageCount).toBe(2);
		expect(list[0].title).toBe("hi");
	});

	it("title derives from first user message and is preserved across saves once non-default", async () => {
		const { store } = makeStore();
		const meta = await store.create();
		await store.save(meta.id, sampleHistory);
		const more: ConversationMessage[] = [
			...sampleHistory,
			{ role: "user", parts: [{ kind: "text", text: "second turn" }] },
		];
		await store.save(meta.id, more);
		const list = await store.list();
		expect(list[0].title).toBe("hi");
	});

	it("rename() updates the title and is sticky across save()", async () => {
		const { store } = makeStore();
		const meta = await store.create();
		await store.save(meta.id, sampleHistory);
		await store.rename(meta.id, "Refactor planner");
		await store.save(meta.id, sampleHistory);
		const list = await store.list();
		expect(list[0].title).toBe("Refactor planner");
	});

	it("delete() removes the session entry and its data", async () => {
		const { store } = makeStore();
		const a = await store.create();
		const b = await store.create();
		await store.save(a.id, sampleHistory);
		await store.delete(a.id);
		const list = await store.list();
		expect(list).toHaveLength(1);
		expect(list[0].id).toBe(b.id);
		expect(await store.load(a.id)).toEqual([]);
	});

	it("clearOne() resets history but keeps the session in the index", async () => {
		const { store } = makeStore();
		const meta = await store.create();
		await store.save(meta.id, sampleHistory);
		await store.clearOne(meta.id);
		expect(await store.load(meta.id)).toEqual([]);
		const list = await store.list();
		expect(list).toHaveLength(1);
		expect(list[0].messageCount).toBe(0);
		expect(list[0].title).toBe("New Session");
	});

	it("keys per workspace — different workspaces have independent session lists", async () => {
		const kv = new InMemoryKv();
		const ws1 = new SessionStore(kv, { getWorkspaceId: () => "ws1" });
		const ws2 = new SessionStore(kv, { getWorkspaceId: () => "ws2" });
		const m = await ws1.create();
		await ws1.save(m.id, sampleHistory);
		expect(await ws2.list()).toEqual([]);
		expect(await ws1.list()).toHaveLength(1);
	});

	it("migrates legacy v1 single-session history into a v2 session", async () => {
		const kv = new InMemoryKv();
		await kv.update("iom.session.v1.ws1", sampleHistory);
		const store = new SessionStore(kv, { getWorkspaceId: () => "ws1" });
		const list = await store.list();
		expect(list).toHaveLength(1);
		expect(list[0].messageCount).toBe(2);
		expect(await store.load(list[0].id)).toHaveLength(2);
		// Legacy key should be cleared after migration
		expect(kv.get("iom.session.v1.ws1")).toBeUndefined();
	});

	it("serializeExport produces a versioned JSON envelope", () => {
		const { store } = makeStore();
		const text = store.serializeExport("s_x", sampleHistory, "Demo");
		const parsed = JSON.parse(text);
		expect(parsed.version).toBe(1);
		expect(parsed.exportedAt).toBe("2026-05-20T07:00:00.000Z");
		expect(parsed.history).toHaveLength(2);
		expect(parsed.workspaceHint).toBe("ws1");
		expect(parsed.title).toBe("Demo");
	});

	it("parseImport accepts a v1 envelope and returns the history + title", () => {
		const { store } = makeStore();
		const text = store.serializeExport("s_x", sampleHistory, "Demo");
		const { history, title } = store.parseImport(text);
		expect(history).toEqual(sampleHistory);
		expect(title).toBe("Demo");
	});

	it("parseImport rejects malformed input", () => {
		const { store } = makeStore();
		expect(() => store.parseImport("not json")).toThrow();
		expect(() => store.parseImport(JSON.stringify({ random: "shape" }))).toThrow(
			/Invalid session file/,
		);
	});

	it("parseImport rejects unsupported versions", () => {
		const { store } = makeStore();
		const bogus = JSON.stringify({ version: 99, history: [] });
		expect(() => store.parseImport(bogus)).toThrow(/Unsupported session version/);
	});

	it("trims oldest messages when exceeding the byte cap", async () => {
		const { store } = makeStore();
		const meta = await store.create();
		const huge: ConversationMessage[] = [];
		const bigText = "x".repeat(50_000);
		for (let i = 0; i < 40; i++) {
			huge.push({ role: "user", parts: [{ kind: "text", text: bigText }] });
			huge.push({ role: "assistant", parts: [{ kind: "text", text: bigText }] });
		}
		await store.save(meta.id, huge);
		const loaded = await store.load(meta.id);
		expect(loaded.length).toBeLessThan(huge.length);
		expect(loaded.length).toBeGreaterThan(0);
	});

	it("saveImported() creates a new session seeded with the provided history", async () => {
		const { store } = makeStore();
		const meta = await store.saveImported(sampleHistory, "Imported");
		expect(meta.title).toBe("Imported");
		expect(await store.load(meta.id)).toHaveLength(2);
		const list = await store.list();
		expect(list[0].id).toBe(meta.id);
	});

	// R7-C regression test: concurrent saves were dropping updates because
	// `save()` did read-index → write-data → read-index → write-index. Two
	// concurrent saves would both read the same baseline index, then each write
	// its own version, with the second overwriting the first. The fix funnels
	// all index-mutating methods through a single promise chain so they
	// serialize.
	it("serializes concurrent saves so neither update is lost (R7-C)", async () => {
		// Build a KV that yields the event loop on every update so the race
		// has time to manifest. The bug would cause either sessionA or
		// sessionB to drop out of the index.
		class AsyncKv {
			private readonly data = new Map<string, unknown>();
			get<T>(key: string): T | undefined {
				return this.data.get(key) as T | undefined;
			}
			async update(key: string, value: unknown): Promise<void> {
				// Force a microtask break so any interleaving caller can land in
				// between our read and write.
				await Promise.resolve();
				if (value === undefined) this.data.delete(key);
				else this.data.set(key, value);
			}
		}
		const kv = new AsyncKv();
		let n = 0;
		const store = new SessionStore(kv, {
			getWorkspaceId: () => "ws-race",
			now: () => new Date("2026-05-20T07:00:00.000Z"),
			makeId: () => `s_race_${++n}`,
		});
		const a = await store.create("a");
		const b = await store.create("b");

		// Fire two saves in parallel — pre-fix, one would be lost.
		await Promise.all([
			store.save(a.id, [{ role: "user", parts: [{ kind: "text", text: "for a" }] }]),
			store.save(b.id, [{ role: "user", parts: [{ kind: "text", text: "for b" }] }]),
		]);

		const list = await store.list();
		const ids = list.map((s) => s.id).sort();
		expect(ids).toEqual([a.id, b.id].sort());
		// Both histories should have been persisted as well.
		expect(await store.load(a.id)).toHaveLength(1);
		expect(await store.load(b.id)).toHaveLength(1);
	});

	// R7-C regression test: same race shape between rename and save. Before
	// the fix, a rename racing with a save could either lose the rename or
	// lose the message count update.
	it("serializes concurrent rename and save (R7-C)", async () => {
		class AsyncKv {
			private readonly data = new Map<string, unknown>();
			get<T>(key: string): T | undefined {
				return this.data.get(key) as T | undefined;
			}
			async update(key: string, value: unknown): Promise<void> {
				await Promise.resolve();
				if (value === undefined) this.data.delete(key);
				else this.data.set(key, value);
			}
		}
		const kv = new AsyncKv();
		let n = 0;
		const store = new SessionStore(kv, {
			getWorkspaceId: () => "ws-race2",
			now: () => new Date("2026-05-20T07:00:00.000Z"),
			makeId: () => `s_race_${++n}`,
		});
		const a = await store.create("a");

		await Promise.all([
			store.rename(a.id, "Renamed"),
			store.save(a.id, [
				{ role: "user", parts: [{ kind: "text", text: "user msg" }] },
				{ role: "assistant", parts: [{ kind: "text", text: "asst msg" }] },
			]),
		]);

		const list = await store.list();
		expect(list).toHaveLength(1);
		// Both operations should have landed: rename AND non-zero message count.
		expect(list[0].title).toBe("Renamed");
		expect(list[0].messageCount).toBe(2);
	});
});
