import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	applyCustomCommandTemplate,
	loadCustomSlashCommands,
	parseSlashCommandArgs,
} from "../src/custom-slash-commands";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-slash-"));
}

async function writeCommand(workspace: string, name: string, body: string): Promise<void> {
	const dir = path.join(workspace, ".iom", "commands");
	await fs.mkdir(dir, { recursive: true });
	await fs.writeFile(path.join(dir, name), body, "utf-8");
}

describe("loadCustomSlashCommands", () => {
	let dir: string;

	beforeEach(async () => {
		dir = await mkTempDir();
	});

	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("returns an empty array when the commands directory does not exist", async () => {
		const result = await loadCustomSlashCommands(dir);
		expect(result).toEqual([]);
	});

	it("returns an empty array for an empty commands directory", async () => {
		await fs.mkdir(path.join(dir, ".iom", "commands"), { recursive: true });
		const result = await loadCustomSlashCommands(dir);
		expect(result).toEqual([]);
	});

	it("returns an empty array for an empty workspace path", async () => {
		const result = await loadCustomSlashCommands("");
		expect(result).toEqual([]);
	});

	it("extracts the first H1 heading as the description", async () => {
		await writeCommand(
			dir,
			"review.md",
			"# Run a thorough code review\n\nReview the diff and report issues.\n",
		);
		const [cmd] = await loadCustomSlashCommands(dir);
		expect(cmd.name).toBe("review");
		expect(cmd.description).toBe("Run a thorough code review");
		expect(cmd.template.trim()).toBe("Review the diff and report issues.");
	});

	it("falls back to the command name when there is no leading heading", async () => {
		await writeCommand(dir, "ping.md", "Please respond with a single 'pong'.\n");
		const [cmd] = await loadCustomSlashCommands(dir);
		expect(cmd.name).toBe("ping");
		expect(cmd.description).toBe("ping");
		expect(cmd.template).toContain("pong");
	});

	it("skips non-.md files and files with invalid name characters", async () => {
		await writeCommand(dir, "ok.md", "# good\nbody");
		await writeCommand(dir, "not-a-command.txt", "# also good\nbody"); // wrong extension
		await writeCommand(dir, "bad name.md", "# spaces aren't allowed\nbody"); // space in name
		await writeCommand(dir, "bad@name.md", "# special chars\nbody"); // special char
		const result = await loadCustomSlashCommands(dir);
		expect(result.map((c) => c.name)).toEqual(["ok"]);
	});

	it("sorts results alphabetically by name", async () => {
		await writeCommand(dir, "zeta.md", "# z");
		await writeCommand(dir, "alpha.md", "# a");
		await writeCommand(dir, "mu.md", "# m");
		const result = await loadCustomSlashCommands(dir);
		expect(result.map((c) => c.name)).toEqual(["alpha", "mu", "zeta"]);
	});

	it("preserves {{input}} placeholders in the template", async () => {
		await writeCommand(dir, "echo.md", "# echo\nUser said: {{input}}");
		const [cmd] = await loadCustomSlashCommands(dir);
		expect(cmd.template).toContain("{{input}}");
	});

	it("handles CRLF line endings the same as LF", async () => {
		await writeCommand(dir, "crlf.md", "# windows\r\n\r\nbody line\r\n");
		const [cmd] = await loadCustomSlashCommands(dir);
		expect(cmd.description).toBe("windows");
		expect(cmd.template).toContain("body line");
	});

	// Phase 4 polish follow-through (2026-06-04): YAML frontmatter.
	describe("frontmatter metadata", () => {
		it("parses description from frontmatter (overrides the # heading)", async () => {
			const raw = [
				"---",
				"description: From frontmatter",
				"---",
				"",
				"# Heading instead",
				"body",
			].join("\n");
			await writeCommand(dir, "fm.md", raw);
			const [cmd] = await loadCustomSlashCommands(dir);
			expect(cmd.description).toBe("From frontmatter");
		});

		it("captures icon, category, and aliases", async () => {
			const raw = [
				"---",
				"description: Test",
				'icon: "🔧"',
				"category: dev",
				"aliases: [t, tst]",
				"---",
				"body",
			].join("\n");
			await writeCommand(dir, "fm-meta.md", raw);
			const [cmd] = await loadCustomSlashCommands(dir);
			expect(cmd.icon).toBe("🔧");
			expect(cmd.category).toBe("dev");
			expect(cmd.aliases).toEqual(["t", "tst"]);
		});

		it("ignores invalid alias entries (non-string or non-matching names)", async () => {
			const raw = ["---", "aliases: [valid, 'has space', 123]", "---", "body"].join("\n");
			await writeCommand(dir, "fm-bad-aliases.md", raw);
			const [cmd] = await loadCustomSlashCommands(dir);
			expect(cmd.aliases).toEqual(["valid"]);
		});

		it("falls back to the whole file when the frontmatter is malformed", async () => {
			const raw = ["---", 'description: "unterminated', "---", "# fallback", "body"].join("\n");
			await writeCommand(dir, "bad-fm.md", raw);
			const [cmd] = await loadCustomSlashCommands(dir);
			// Description from the heading because frontmatter parse failed.
			expect(cmd.description).toBe("fallback");
			expect(cmd.icon).toBeUndefined();
			expect(cmd.category).toBeUndefined();
		});

		it("commands without frontmatter still work unchanged", async () => {
			await writeCommand(dir, "no-fm.md", "# legacy\n\nbody");
			const [cmd] = await loadCustomSlashCommands(dir);
			expect(cmd.description).toBe("legacy");
			expect(cmd.icon).toBeUndefined();
			expect(cmd.aliases).toBeUndefined();
		});
	});
});

describe("applyCustomCommandTemplate", () => {
	it("substitutes {{input}} with the supplied text", () => {
		expect(applyCustomCommandTemplate("Hello {{input}}!", "world")).toBe("Hello world!");
	});

	it("replaces every occurrence", () => {
		expect(applyCustomCommandTemplate("{{input}} and {{input}}", "x")).toBe("x and x");
	});

	it("leaves templates without {{input}} unchanged", () => {
		expect(applyCustomCommandTemplate("just text", "ignored")).toBe("just text");
	});

	it("supports an empty input string", () => {
		expect(applyCustomCommandTemplate("before [{{input}}] after", "")).toBe("before [] after");
	});

	// Phase 4: argument substitution.
	describe("argument placeholders ({{argN}}, {{args}})", () => {
		it("substitutes {{arg0}} {{arg1}} ... with whitespace-separated tokens", () => {
			expect(applyCustomCommandTemplate("Refactor {{arg0}} using {{arg1}}", "fooFunc strategy")).toBe(
				"Refactor fooFunc using strategy",
			);
		});

		it("treats quoted spans as a single argument", () => {
			expect(applyCustomCommandTemplate("Greet {{arg0}}", '"hello world"')).toBe("Greet hello world");
		});

		it("supports {{args}} as a canonical join", () => {
			expect(applyCustomCommandTemplate("Use [{{args}}]", "  a   b  c ")).toBe("Use [a b c]");
		});

		it("substitutes missing {{argN}} positions with empty string", () => {
			expect(applyCustomCommandTemplate("[{{arg0}}][{{arg1}}][{{arg5}}]", "only-one")).toBe(
				"[only-one][][]",
			);
		});

		it("leaves {{input}} intact when combined with {{argN}}", () => {
			// {{input}} keeps the raw user input verbatim
			expect(applyCustomCommandTemplate("First={{arg0}}; Raw=[{{input}}]", "a b c")).toBe(
				"First=a; Raw=[a b c]",
			);
		});

		it("backslash escapes the next character (shell-style)", () => {
			expect(applyCustomCommandTemplate("{{arg0}}", "literal\\ space")).toBe("literal space");
		});

		it("ignores stray placeholder-like text outside the recognised forms", () => {
			// `{{ argN }}` with spaces is NOT replaced — opt-out for authors who
			// want a literal placeholder in their template.
			expect(applyCustomCommandTemplate("{{ arg0 }} stays literal", "x y")).toBe(
				"{{ arg0 }} stays literal",
			);
		});
	});
});

describe("parseSlashCommandArgs", () => {
	it("splits on whitespace by default", () => {
		expect(parseSlashCommandArgs("a b c")).toEqual(["a", "b", "c"]);
	});

	it("treats double-quoted spans as one arg", () => {
		expect(parseSlashCommandArgs('"hello world" foo')).toEqual(["hello world", "foo"]);
	});

	it("strips backslash escapes", () => {
		expect(parseSlashCommandArgs("a\\ b c")).toEqual(["a b", "c"]);
	});

	it("returns an empty array for empty / whitespace-only input", () => {
		expect(parseSlashCommandArgs("")).toEqual([]);
		expect(parseSlashCommandArgs("   \t  ")).toEqual([]);
	});

	it("collapses multiple internal spaces in the unquoted case", () => {
		expect(parseSlashCommandArgs("a   b\t\tc")).toEqual(["a", "b", "c"]);
	});
});
