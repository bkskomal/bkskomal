import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { Budget, currentDayString } from "../src/budget";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-budget-"));
}

// A model with a known rate so the math is deterministic.
const MODEL = "claude-sonnet-4-6"; // $3 in / $15 out per 1M tokens.

describe("currentDayString", () => {
	it("formats a UTC date as YYYYMMDD", () => {
		expect(currentDayString(new Date("2026-05-20T12:34:56Z"))).toBe("20260520");
	});
	it("rolls over at UTC midnight", () => {
		expect(currentDayString(new Date("2026-05-20T23:59:59Z"))).toBe("20260520");
		expect(currentDayString(new Date("2026-05-21T00:00:00Z"))).toBe("20260521");
	});
});

describe("Budget cost math", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("tallies per-session cost across multiple usage events", async () => {
		const b = new Budget(dir, { perSessionAlertUsd: 100, perDayHardCapUsd: 1000 });
		await b.recordUsage(MODEL, 1_000_000, 0); // $3
		await b.recordUsage(MODEL, 0, 1_000_000); // $15
		expect(b.getSessionCost()).toBeCloseTo(18, 5);
	});

	it("ignores models with no known rate (cost = $0)", async () => {
		const b = new Budget(dir);
		const r = await b.recordUsage("totally-made-up-model", 1_000_000, 1_000_000);
		expect(r.costThisCall).toBe(0);
		expect(b.getSessionCost()).toBe(0);
	});

	it("fires the soft alert exactly once per session", async () => {
		const b = new Budget(dir, { perSessionAlertUsd: 1, perDayHardCapUsd: 1000 });
		const r1 = await b.recordUsage(MODEL, 0, 100_000); // $1.50
		expect(r1.softAlertFired).toBe(true);
		const r2 = await b.recordUsage(MODEL, 0, 100_000); // total $3
		expect(r2.softAlertFired).toBe(false);
	});

	it("flags hardCapReached when session hard cap is crossed", async () => {
		const b = new Budget(dir, {
			perSessionAlertUsd: 0.5,
			perSessionHardCapUsd: 2,
			perDayHardCapUsd: 1000,
		});
		const r = await b.recordUsage(MODEL, 0, 1_000_000); // $15
		expect(r.hardCapReached).toBe(true);
	});

	it("checkDispatch blocks once session hard cap is reached", async () => {
		const b = new Budget(dir, {
			perSessionAlertUsd: 0.5,
			perSessionHardCapUsd: 2,
			perDayHardCapUsd: 1000,
		});
		await b.recordUsage(MODEL, 0, 1_000_000); // $15 → over cap
		const v = await b.checkDispatch();
		expect(v.kind).toBe("blocked");
		if (v.kind === "blocked") expect(v.reason).toContain("per-session");
	});

	it("checkDispatch allows dispatch when under cap", async () => {
		const b = new Budget(dir, { perSessionHardCapUsd: 100, perDayHardCapUsd: 1000 });
		expect((await b.checkDispatch()).kind).toBe("ok");
	});
});

describe("Budget — daily file persistence", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("writes .iom/budget-day-YYYYMMDD.json on first record", async () => {
		const fixedDate = new Date("2026-05-20T12:00:00Z");
		const b = new Budget(dir, undefined, () => fixedDate);
		await b.recordUsage(MODEL, 0, 100_000); // $1.50
		const file = path.join(dir, ".iom", "budget-day-20260520.json");
		const raw = JSON.parse(await fs.readFile(file, "utf-8"));
		expect(raw.day).toBe("20260520");
		expect(raw.totalUsd).toBeCloseTo(1.5, 5);
	});

	it("blocks new dispatch when per-day cap exceeded", async () => {
		const b = new Budget(dir, { perDayHardCapUsd: 5 }, () => new Date("2026-05-20T10:00:00Z"));
		await b._setDayCost(7);
		const v = await b.checkDispatch();
		expect(v.kind).toBe("blocked");
		if (v.kind === "blocked") expect(v.reason.toLowerCase()).toContain("daily");
	});

	it("rolls over at UTC midnight (mocked clock)", async () => {
		// Seed: day-1 file with $40 spent.
		let now = new Date("2026-05-20T23:30:00Z");
		const b = new Budget(dir, { perDayHardCapUsd: 50 }, () => now);
		await b._setDayCost(40);
		expect((await b.checkDispatch()).kind).toBe("ok");

		// Advance the clock past midnight UTC.
		now = new Date("2026-05-21T00:01:00Z");

		// Counter resets — new day file is created on next record.
		const r = await b.recordUsage(MODEL, 0, 100_000); // $1.50 on the new day
		expect(r.dayCostUsd).toBeCloseTo(1.5, 5);

		const newFile = path.join(dir, ".iom", "budget-day-20260521.json");
		const raw = JSON.parse(await fs.readFile(newFile, "utf-8"));
		expect(raw.day).toBe("20260521");
		expect(raw.totalUsd).toBeCloseTo(1.5, 5);
	});

	it("reads existing day file on construction (per-day total persists across panel reload)", async () => {
		const today = currentDayString(new Date());
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(
			path.join(dir, ".iom", `budget-day-${today}.json`),
			JSON.stringify({ day: today, totalUsd: 42 }),
			"utf-8",
		);
		const b = new Budget(dir, { perDayHardCapUsd: 40 });
		const v = await b.checkDispatch();
		expect(v.kind).toBe("blocked");
	});

	// 2026-06-06: sentinel — `0` means "no cap" from the Settings UI.
	// POSITIVE_INFINITY can't survive a JSON round-trip so the UI sends 0.
	it("treats perDayHardCapUsd=0 as unlimited (not 'block every dispatch')", async () => {
		const today = currentDayString(new Date());
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(
			path.join(dir, ".iom", `budget-day-${today}.json`),
			JSON.stringify({ day: today, totalUsd: 999 }),
			"utf-8",
		);
		const b = new Budget(dir, { perDayHardCapUsd: 0 });
		const v = await b.checkDispatch();
		expect(v.kind).toBe("ok");
	});

	// 2026-06-06: master toggle. When disabled, every cap is ignored —
	// dispatch always passes regardless of how much the day or session
	// counter shows. recordUsage still tallies so the chat usage chip + audit
	// log continue to work.
	it("master toggle off — checkDispatch always returns ok even when the daily file is over the cap", async () => {
		const today = currentDayString(new Date());
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(
			path.join(dir, ".iom", `budget-day-${today}.json`),
			JSON.stringify({ day: today, totalUsd: 9999 }),
			"utf-8",
		);
		const b = new Budget(dir, { enabled: false, perDayHardCapUsd: 50 });
		const v = await b.checkDispatch();
		expect(v.kind).toBe("ok");
	});

	it("master toggle off — recordUsage still tallies but no hardCapReached / softAlert fires", async () => {
		const b = new Budget(dir, {
			enabled: false,
			perSessionAlertUsd: 0.01,
			perSessionHardCapUsd: 0.02,
			perDayHardCapUsd: 0.03,
		});
		const r = await b.recordUsage(MODEL, 1_000_000, 1_000_000); // ~$18 — well past every cap
		expect(r.costThisCall).toBeGreaterThan(0); // still tallied
		expect(r.softAlertFired).toBe(false);
		expect(r.hardCapReached).toBe(false);
	});

	it("treats perSessionHardCapUsd=0 as unlimited", async () => {
		// Disable the daily cap too so this test is scoped to the per-session
		// path (default perDayHardCapUsd is $50 and would block before the
		// per-session check is even reached).
		const b = new Budget(dir, { perSessionHardCapUsd: 0, perDayHardCapUsd: 0 });
		// 30M tokens at the test model's rates puts us well past any
		// finite per-session cap; with 0=unlimited we should still dispatch.
		await b.recordUsage(MODEL, 30_000_000, 0);
		const v = await b.checkDispatch();
		expect(v.kind).toBe("ok");
	});
});
