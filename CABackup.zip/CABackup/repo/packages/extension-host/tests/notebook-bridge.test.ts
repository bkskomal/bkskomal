// R6-B: notebook bridge tests. Two layers:
//   1. The on-disk JSON parser exported from `@iom/tools/read-notebook` —
//      tests stay in this package since it's the most natural place to keep
//      the .ipynb fixture next to the bridge that consumes it.
//   2. The VS Code bridge from `notebook-bridge.ts`, exercised against a
//      hand-rolled fake `NotebookDocument` wired through the stub.
//
// We deliberately avoid touching the live VS Code runtime; everything below
// runs in pure Node under vitest.
import { beforeEach, describe, expect, it, vi } from "vitest";
import * as vscode from "vscode";
import { parseNotebookJson } from "../../tools/src/read-notebook";
import { createNotebookProvider } from "../src/notebook-bridge";

// A representative nbformat-v4 envelope with one markdown cell, one code cell,
// and a code cell carrying a `stream` output plus a `display_data` output. The
// JSON is intentionally hand-written (not pretty-printed) so the array-of-lines
// `source` shape is exercised on at least one cell.
const FIXTURE_IPYNB = JSON.stringify({
	cells: [
		{
			cell_type: "markdown",
			metadata: {},
			source: ["# Hello\n", "World"],
		},
		{
			cell_type: "code",
			execution_count: 1,
			metadata: { language: "python" },
			outputs: [],
			source: "print('hi')",
		},
		{
			cell_type: "code",
			execution_count: 2,
			metadata: {},
			outputs: [
				{ output_type: "stream", name: "stdout", text: ["1\n", "2\n"] },
				{
					output_type: "display_data",
					data: { "text/plain": "<img>", "image/png": "base64==" },
					metadata: {},
				},
			],
			source: ["import sys\n", "print(sys.version)"],
		},
	],
	metadata: { language_info: { name: "python" } },
	nbformat: 4,
	nbformat_minor: 5,
});

describe("parseNotebookJson (R6-B)", () => {
	it("returns one snapshot per cell, joining array sources", () => {
		const cells = parseNotebookJson(FIXTURE_IPYNB, false);
		expect(cells).toHaveLength(3);
		expect(cells[0]).toMatchObject({
			index: 0,
			kind: "markdown",
			language: "markdown",
			source: "# Hello\nWorld",
		});
		expect(cells[1]).toMatchObject({
			index: 1,
			kind: "code",
			language: "python",
			source: "print('hi')",
		});
		expect(cells[2].source).toBe("import sys\nprint(sys.version)");
	});

	it("omits outputs by default", () => {
		const cells = parseNotebookJson(FIXTURE_IPYNB, false);
		for (const c of cells) {
			expect(c.outputs).toBeUndefined();
		}
	});

	it("includes outputs when asked, flattening stream + display_data", () => {
		const cells = parseNotebookJson(FIXTURE_IPYNB, true);
		expect(cells[1].outputs).toEqual([]);
		expect(cells[2].outputs).toEqual([
			{ mime: "application/vnd.code.notebook.stdout", text: "1\n2\n" },
			{ mime: "text/plain", text: "<img>" },
			{ mime: "image/png", text: "base64==" },
		]);
	});

	it("throws on invalid JSON", () => {
		expect(() => parseNotebookJson("not json", false)).toThrowError(/not valid JSON/);
	});

	it("throws when the cells array is missing", () => {
		expect(() => parseNotebookJson("{}", false)).toThrowError(/cells/);
	});
});

// ---------------------------------------------------------------------------
// Bridge layer — exercise `createNotebookProvider()` against a fake notebook
// document plumbed through the vscode stub.

interface FakeCell {
	index: number;
	kind: number;
	document: { getText(): string; languageId: string };
	outputs: { items: { mime: string; data: Uint8Array }[] }[];
}

interface FakeNotebookDocument {
	uri: { toString(): string; fsPath: string };
	cellCount: number;
	cellAt(i: number): FakeCell;
	metadata?: { language_info?: { name?: string } };
}

function buildFakeNotebook(cells: FakeCell[]): FakeNotebookDocument {
	return {
		uri: { toString: () => "file:///fake.ipynb", fsPath: "/fake.ipynb" },
		cellCount: cells.length,
		cellAt: (i: number) => cells[i],
		metadata: { language_info: { name: "python" } },
	};
}

function makeCell(
	index: number,
	kind: number,
	source: string,
	languageId = "python",
	outputs: { mime: string; text: string }[] = [],
): FakeCell {
	return {
		index,
		kind,
		document: { getText: () => source, languageId },
		outputs: [
			{
				items: outputs.map((o) => ({ mime: o.mime, data: new TextEncoder().encode(o.text) })),
			},
		],
	};
}

describe("createNotebookProvider (R6-B)", () => {
	beforeEach(() => {
		// Reset stub state between tests so applyEdit calls from prior tests
		// don't leak.
		vi.restoreAllMocks();
		(vscode.workspace as { workspaceFolders?: unknown }).workspaceFolders = [
			{ uri: { fsPath: "/" } },
		];
	});

	it("read returns one snapshot per cell with outputs omitted by default", async () => {
		const nb = buildFakeNotebook([
			makeCell(0, vscode.NotebookCellKind.Markup, "# Hi", "markdown"),
			makeCell(1, vscode.NotebookCellKind.Code, "print(1)", "python", [
				{ mime: "text/plain", text: "1" },
			]),
		]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);

		const provider = createNotebookProvider();
		const cells = await provider.read("/fake.ipynb");
		expect(cells).toHaveLength(2);
		expect(cells[0]).toMatchObject({ index: 0, kind: "markdown", source: "# Hi" });
		expect(cells[1]).toMatchObject({ index: 1, kind: "code", source: "print(1)" });
		expect(cells[0].outputs).toBeUndefined();
		expect(cells[1].outputs).toBeUndefined();
	});

	it("read includes outputs when asked", async () => {
		const nb = buildFakeNotebook([
			makeCell(0, vscode.NotebookCellKind.Code, "1+1", "python", [{ mime: "text/plain", text: "2" }]),
		]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);

		const provider = createNotebookProvider();
		const cells = await provider.read("/fake.ipynb", true);
		expect(cells[0].outputs).toEqual([{ mime: "text/plain", text: "2" }]);
	});

	it("editCell applies a NotebookEdit.replaceCells against the right range", async () => {
		const nb = buildFakeNotebook([makeCell(0, vscode.NotebookCellKind.Code, "old", "python")]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);
		const apply = vi.spyOn(vscode.workspace, "applyEdit").mockResolvedValue(true);

		const provider = createNotebookProvider();
		await provider.editCell("/fake.ipynb", 0, "new source");

		expect(apply).toHaveBeenCalledOnce();
		const edit = apply.mock.calls[0][0] as { notebookEdits: Map<string, unknown[]> };
		const edits = edit.notebookEdits.get(nb.uri.toString());
		expect(edits).toBeDefined();
		expect(edits).toHaveLength(1);
		const e = edits?.[0] as {
			kind: string;
			payload: { range: { start: number; end: number }; cells: { value: string }[] };
		};
		expect(e.kind).toBe("replaceCells");
		expect(e.payload.range).toMatchObject({ start: 0, end: 1 });
		expect(e.payload.cells[0].value).toBe("new source");
	});

	it("editCell rejects out-of-range index", async () => {
		const nb = buildFakeNotebook([makeCell(0, vscode.NotebookCellKind.Code, "x", "python")]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);
		const provider = createNotebookProvider();
		await expect(provider.editCell("/fake.ipynb", 9, "x")).rejects.toThrow(/out of range/);
	});

	it("insertCell builds an insertCells edit at the requested index", async () => {
		const nb = buildFakeNotebook([makeCell(0, vscode.NotebookCellKind.Code, "first", "python")]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);
		const apply = vi.spyOn(vscode.workspace, "applyEdit").mockResolvedValue(true);

		const provider = createNotebookProvider();
		await provider.insertCell("/fake.ipynb", 1, "markdown", "# header");
		const edit = apply.mock.calls[0][0] as { notebookEdits: Map<string, unknown[]> };
		const edits = edit.notebookEdits.get(nb.uri.toString());
		const e = edits?.[0] as { kind: string; payload: { index: number; cells: { value: string }[] } };
		expect(e.kind).toBe("insertCells");
		expect(e.payload.index).toBe(1);
		expect(e.payload.cells[0].value).toBe("# header");
	});

	it("deleteCell builds a deleteCells edit covering one cell", async () => {
		const nb = buildFakeNotebook([
			makeCell(0, vscode.NotebookCellKind.Code, "a", "python"),
			makeCell(1, vscode.NotebookCellKind.Code, "b", "python"),
		]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);
		const apply = vi.spyOn(vscode.workspace, "applyEdit").mockResolvedValue(true);

		const provider = createNotebookProvider();
		await provider.deleteCell("/fake.ipynb", 1);
		const edit = apply.mock.calls[0][0] as { notebookEdits: Map<string, unknown[]> };
		const edits = edit.notebookEdits.get(nb.uri.toString());
		const e = edits?.[0] as { kind: string; payload: { range: { start: number; end: number } } };
		expect(e.kind).toBe("deleteCells");
		expect(e.payload.range).toMatchObject({ start: 1, end: 2 });
	});

	it("runCell calls notebook.cell.execute and returns the cell's outputs", async () => {
		const nb = buildFakeNotebook([
			makeCell(0, vscode.NotebookCellKind.Code, "print('hi')", "python", [
				{ mime: "application/vnd.code.notebook.stdout", text: "hi\n" },
			]),
		]);
		vi
			.spyOn(vscode.workspace, "openNotebookDocument")
			.mockResolvedValue(
				nb as unknown as Awaited<ReturnType<typeof vscode.workspace.openNotebookDocument>>,
			);
		const exec = vi.spyOn(vscode.commands, "executeCommand").mockResolvedValue(undefined);

		const provider = createNotebookProvider();
		const outputs = await provider.runCell("/fake.ipynb", 0);
		expect(exec).toHaveBeenCalledWith("notebook.cell.execute", {
			ranges: [{ start: 0, end: 1 }],
			document: nb.uri,
		});
		expect(outputs).toEqual([{ mime: "application/vnd.code.notebook.stdout", text: "hi\n" }]);
	});
});
