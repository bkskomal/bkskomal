import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	PROJECT_MEMORY_CANDIDATES,
	PROJECT_MEMORY_MAX_BYTES,
	PROJECT_MEMORY_TEMPLATE,
	appendToProjectMemory,
	initProjectMemory,
	loadProjectMemory,
} from "../src/project-memory";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-memory-"));
}

describe("loadProjectMemory", () => {
	let dir: string;

	beforeEach(async () => {
		dir = await mkTempDir();
	});

	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("returns undefined when no candidate file exists", async () => {
		const result = await loadProjectMemory(dir);
		expect(result).toBeUndefined();
	});

	it("returns undefined when the workspace path is empty", async () => {
		const result = await loadProjectMemory("");
		expect(result).toBeUndefined();
	});

	it("loads .iom/IOM.md when present", async () => {
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(path.join(dir, ".iom", "IOM.md"), "# project rules\n", "utf-8");
		const result = await loadProjectMemory(dir);
		expect(result).toBeDefined();
		expect(result?.content).toContain("project rules");
		expect(result?.path).toBe(path.join(dir, ".iom", "IOM.md"));
	});

	it("falls back through the lookup order: .iom/IOM.md > IOM.md > .claude/CLAUDE.md > CLAUDE.md", async () => {
		// Write the *last* candidate; it should be chosen.
		await fs.writeFile(path.join(dir, "CLAUDE.md"), "claude-root", "utf-8");
		let result = await loadProjectMemory(dir);
		expect(result?.content).toBe("claude-root");
		expect(result?.path.endsWith("CLAUDE.md")).toBe(true);

		// Add .claude/CLAUDE.md → wins over root CLAUDE.md.
		await fs.mkdir(path.join(dir, ".claude"), { recursive: true });
		await fs.writeFile(path.join(dir, ".claude", "CLAUDE.md"), "claude-dot", "utf-8");
		result = await loadProjectMemory(dir);
		expect(result?.content).toBe("claude-dot");

		// Add root IOM.md → wins over .claude/CLAUDE.md.
		await fs.writeFile(path.join(dir, "IOM.md"), "iom-root", "utf-8");
		result = await loadProjectMemory(dir);
		expect(result?.content).toBe("iom-root");

		// Add .iom/IOM.md → top of the precedence order.
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(path.join(dir, ".iom", "IOM.md"), "iom-dot", "utf-8");
		result = await loadProjectMemory(dir);
		expect(result?.content).toBe("iom-dot");
	});

	it("truncates oversized files and appends [truncated]", async () => {
		// One byte over the limit so we exercise the truncation branch.
		const huge = "x".repeat(PROJECT_MEMORY_MAX_BYTES + 1);
		await fs.writeFile(path.join(dir, "IOM.md"), huge, "utf-8");
		const result = await loadProjectMemory(dir);
		expect(result).toBeDefined();
		// Output keeps the first MAX_BYTES of input, then the marker.
		expect(result?.content.length).toBe(PROJECT_MEMORY_MAX_BYTES + "\n\n[truncated]".length);
		expect(result?.content.endsWith("[truncated]")).toBe(true);
	});

	it("returns undefined when the matching path is a directory, not a file", async () => {
		// `IOM.md` is a directory — should be skipped (no file in lookup order).
		await fs.mkdir(path.join(dir, "IOM.md"), { recursive: true });
		const result = await loadProjectMemory(dir);
		expect(result).toBeUndefined();
	});

	it("returns undefined for an entirely missing workspace", async () => {
		const result = await loadProjectMemory(path.join(dir, "does-not-exist"));
		expect(result).toBeUndefined();
	});

	it("PROJECT_MEMORY_CANDIDATES is in priority order", () => {
		// Sanity check so future edits don't accidentally reorder the precedence.
		expect(PROJECT_MEMORY_CANDIDATES[0]).toBe(".iom/IOM.md");
		expect(PROJECT_MEMORY_CANDIDATES[PROJECT_MEMORY_CANDIDATES.length - 1]).toBe("CLAUDE.md");
	});
});

describe("initProjectMemory (2026-06-03)", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("creates IOM.md at the workspace root when none exists", async () => {
		const result = await initProjectMemory(dir);
		expect(result.created).toBe(true);
		if (result.created) {
			expect(result.path).toBe(path.join(dir, "IOM.md"));
			const content = await fs.readFile(result.path, "utf-8");
			expect(content).toContain("# IOM.md");
			expect(content).toContain("## Stack");
		}
	});

	it("does NOT overwrite when IOM.md already exists", async () => {
		const existingPath = path.join(dir, "IOM.md");
		await fs.writeFile(existingPath, "# my custom memory", "utf-8");
		const result = await initProjectMemory(dir);
		expect(result.created).toBe(false);
		if (!result.created) {
			expect(result.existingPath).toBe(existingPath);
		}
		const after = await fs.readFile(existingPath, "utf-8");
		expect(after).toBe("# my custom memory"); // unchanged
	});

	it("does NOT overwrite when CLAUDE.md exists at the higher-priority location", async () => {
		const claudePath = path.join(dir, ".claude", "CLAUDE.md");
		await fs.mkdir(path.dirname(claudePath), { recursive: true });
		await fs.writeFile(claudePath, "# CLAUDE memory", "utf-8");
		const result = await initProjectMemory(dir);
		expect(result.created).toBe(false);
		if (!result.created) {
			expect(result.existingPath).toBe(claudePath);
		}
	});

	it("template includes the required orientation headers", () => {
		expect(PROJECT_MEMORY_TEMPLATE).toContain("# IOM.md");
		expect(PROJECT_MEMORY_TEMPLATE).toContain("auto-loaded");
		expect(PROJECT_MEMORY_TEMPLATE).toContain("## Stack");
		expect(PROJECT_MEMORY_TEMPLATE).toContain("## Conventions");
		expect(PROJECT_MEMORY_TEMPLATE).toContain("## Don't do");
	});
});

describe("appendToProjectMemory (2026-06-03)", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("creates IOM.md from the template when none exists, then appends the chunk", async () => {
		const result = await appendToProjectMemory(
			dir,
			"Port 5100 is the backend (5000 is taken by Docker)",
		);
		expect(result.path).toBe(path.join(dir, "IOM.md"));
		const content = await fs.readFile(result.path, "utf-8");
		expect(content).toContain("# IOM.md");
		expect(content).toContain("Suggested additions");
		expect(content).toContain("Port 5100 is the backend");
	});

	it("appends to an existing file WITHOUT rewriting (preserves bytes past the 32KB read cap)", async () => {
		// Pre-populate with content larger than PROJECT_MEMORY_MAX_BYTES so
		// that `loadProjectMemory` returns a truncated view. The append
		// MUST NOT use that view (which would lose the tail).
		const existingPath = path.join(dir, "IOM.md");
		const big = "x".repeat(PROJECT_MEMORY_MAX_BYTES + 5_000);
		await fs.writeFile(existingPath, big, "utf-8");
		const beforeSize = (await fs.stat(existingPath)).size;
		await appendToProjectMemory(dir, "new fact");
		const afterSize = (await fs.stat(existingPath)).size;
		// Size after = original full size + appended block.
		expect(afterSize).toBeGreaterThan(beforeSize);
		expect(afterSize).toBeGreaterThan(PROJECT_MEMORY_MAX_BYTES);
		const fullContent = await fs.readFile(existingPath, "utf-8");
		// The original tail (the last 100 x's) is still present —
		// proving the buggy "load-then-rewrite" path is gone.
		expect(fullContent).toContain(
			"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
		);
		expect(fullContent).toContain("new fact");
	});

	it("rejects empty chunks", async () => {
		await expect(appendToProjectMemory(dir, "")).rejects.toThrow(/empty/);
		await expect(appendToProjectMemory(dir, "   \n  ")).rejects.toThrow(/empty/);
	});

	it("requires a workspace path", async () => {
		await expect(appendToProjectMemory("", "some fact")).rejects.toThrow(/workspacePath/);
	});

	it("includes a date-stamped 'Suggested additions' header", async () => {
		await appendToProjectMemory(dir, "first fact");
		const content = await fs.readFile(path.join(dir, "IOM.md"), "utf-8");
		const today = new Date().toISOString().slice(0, 10);
		expect(content).toContain(`## Suggested additions — ${today}`);
	});

	it("appends to existing file with separate headers when called multiple times", async () => {
		await appendToProjectMemory(dir, "first");
		await appendToProjectMemory(dir, "second");
		const content = await fs.readFile(path.join(dir, "IOM.md"), "utf-8");
		// Both facts present.
		expect(content).toContain("first");
		expect(content).toContain("second");
		// Two Suggested-additions headers (one per call).
		const headerCount = (content.match(/## Suggested additions/g) ?? []).length;
		expect(headerCount).toBe(2);
	});
});
