/**
 * R5-C: SessionIndex tests. Uses a deterministic mock embedder so we can
 * assert ranking without depending on TF-IDF's hashing-trick collisions.
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { Embedder } from "@iom/codebase-index";
import type { ConversationMessage } from "@iom/shared";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import {
	type IndexableMessage,
	SessionIndex,
	historyToIndexable,
	uiMessagesToIndexable,
} from "../src/session-index";

/**
 * One-hot embedder keyed on `__TAG_n__` tokens. Mirrors the TagEmbedder used
 * in the codebase-index tests so the assertions don't depend on token
 * collision behavior.
 */
class TagEmbedder implements Embedder {
	readonly dim = 16;
	calls = 0;
	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		this.calls += texts.length;
		return texts.map((t) => {
			const vec = new Float32Array(this.dim);
			const matches = [...t.matchAll(/__TAG_(\d+)__/g)];
			if (matches.length === 0) {
				vec[0] = 0.1;
				return vec;
			}
			for (const m of matches) {
				const slot = Number.parseInt(m[1], 10) % this.dim;
				vec[slot] += 1;
			}
			let n = 0;
			for (let i = 0; i < this.dim; i++) n += vec[i] * vec[i];
			if (n > 0) {
				const inv = 1 / Math.sqrt(n);
				for (let i = 0; i < this.dim; i++) vec[i] *= inv;
			}
			return vec;
		});
	}
}

function tmpDb(): { path: string; cleanup: () => void } {
	const dir = fs.mkdtempSync(path.join(os.tmpdir(), "iom-session-index-"));
	return {
		path: path.join(dir, "conv.sqlite"),
		cleanup: () => {
			try {
				fs.rmSync(dir, { recursive: true, force: true });
			} catch {
				/* best-effort */
			}
		},
	};
}

const TURN_A: readonly IndexableMessage[] = [
	{ id: "m1", role: "user", text: "how do we handle login? __TAG_1__" },
	{ id: "m2", role: "assistant", text: "We validate via JWT __TAG_1__ in middleware/auth.ts" },
];
const TURN_B: readonly IndexableMessage[] = [
	{ id: "n1", role: "user", text: "where is billing? __TAG_2__" },
	{ id: "n2", role: "assistant", text: "Stripe integration lives in src/billing.ts __TAG_2__" },
];

describe("SessionIndex (R5-C)", () => {
	let db: ReturnType<typeof tmpDb>;
	let idx: SessionIndex;
	let embedder: TagEmbedder;

	beforeEach(() => {
		db = tmpDb();
		embedder = new TagEmbedder();
		idx = new SessionIndex({ dbPath: db.path, embedder });
	});

	afterEach(() => {
		idx.close();
		db.cleanup();
	});

	it("indexes a session and returns its messages on a matching query", async () => {
		const n = await idx.indexSession("sess_a", TURN_A);
		expect(n).toBe(2);
		const hits = await idx.search("about __TAG_1__", { k: 5 });
		expect(hits.length).toBeGreaterThan(0);
		expect(hits[0].sessionId).toBe("sess_a");
		expect(["m1", "m2"]).toContain(hits[0].messageId);
		expect(hits[0].score).toBeGreaterThan(0.9);
	});

	it("scopes results to a single session when sessionId is passed", async () => {
		await idx.indexSession("sess_a", TURN_A);
		await idx.indexSession("sess_b", TURN_B);
		const scoped = await idx.search("__TAG_1__", { sessionId: "sess_b" });
		// Scoped search against a session with no TAG_1 returns rows with low
		// score, but they must all belong to sess_b.
		for (const h of scoped) expect(h.sessionId).toBe("sess_b");
	});

	it("returns an empty result for an empty query", async () => {
		await idx.indexSession("sess_a", TURN_A);
		expect(await idx.search("")).toEqual([]);
		expect(await idx.search("   ")).toEqual([]);
	});

	it("incremental save: re-indexing a session replaces its rows", async () => {
		await idx.indexSession("sess_a", TURN_A);
		const before = idx.stats();
		expect(before.messages).toBe(2);
		// Replace the session contents with a single shorter conversation.
		await idx.indexSession("sess_a", [{ id: "m1", role: "user", text: "ping __TAG_3__" }]);
		const after = idx.stats();
		expect(after.messages).toBe(1);
		expect(after.sessions).toBe(1);
	});

	it("rebuildAll wipes and re-indexes every session", async () => {
		await idx.indexSession("sess_a", TURN_A);
		await idx.indexSession("sess_b", TURN_B);
		expect(idx.stats().messages).toBe(4);
		const rebuilt = await idx.rebuildAll([
			{ sessionId: "sess_a", messages: TURN_A },
			// Drop sess_b entirely on rebuild.
		]);
		expect(rebuilt).toBe(2);
		const stats = idx.stats();
		expect(stats.messages).toBe(2);
		expect(stats.sessions).toBe(1);
	});

	it("dropSession removes only the named session's rows", async () => {
		await idx.indexSession("sess_a", TURN_A);
		await idx.indexSession("sess_b", TURN_B);
		idx.dropSession("sess_a");
		const stats = idx.stats();
		expect(stats.messages).toBe(2);
		expect(stats.sessions).toBe(1);
		const hits = await idx.search("__TAG_2__");
		for (const h of hits) expect(h.sessionId).toBe("sess_b");
	});

	it("skips empty / trivially-short messages", async () => {
		await idx.indexSession("sess_a", [
			{ id: "m1", role: "user", text: "  " },
			{ id: "m2", role: "user", text: "ok" },
			{ id: "m3", role: "assistant", text: "real message __TAG_5__" },
		]);
		expect(idx.stats().messages).toBe(1);
	});

	it("snippet is truncated for long bodies", async () => {
		const huge = `${"x".repeat(1500)} __TAG_4__`;
		await idx.indexSession("sess_a", [{ id: "m1", role: "assistant", text: huge }]);
		const hits = await idx.search("__TAG_4__");
		expect(hits[0].snippet.length).toBeLessThanOrEqual(801);
		expect(hits[0].snippet.endsWith("…")).toBe(true);
	});

	it("survives a dimension mismatch by wiping rows", async () => {
		await idx.indexSession("sess_a", TURN_A);
		idx.close();
		class BiggerEmbedder implements Embedder {
			readonly dim = 32;
			async embed(texts: readonly string[]) {
				return texts.map(() => new Float32Array(this.dim));
			}
		}
		const reopened = new SessionIndex({ dbPath: db.path, embedder: new BiggerEmbedder() });
		// Old 16-dim rows should have been wiped by the dim guard.
		expect(reopened.stats().messages).toBe(0);
		reopened.close();
		// Re-open with the original embedder for the afterEach close.
		idx = new SessionIndex({ dbPath: db.path, embedder });
	});
});

describe("historyToIndexable / uiMessagesToIndexable", () => {
	it("maps ConversationMessage[] to indexable rows with synthetic ids", () => {
		const history: ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "hi" }] },
			{ role: "assistant", parts: [{ kind: "text", text: "hello" }] },
			{ role: "tool", parts: [{ kind: "text", text: "ignored" }] },
		];
		const out = historyToIndexable(history);
		expect(out).toHaveLength(2);
		expect(out[0].id).toBe("u_h0");
		expect(out[1].id).toBe("a_h1");
	});

	it("skips messages with no text parts", () => {
		const history: ConversationMessage[] = [
			{ role: "user", parts: [] },
			{ role: "assistant", parts: [{ kind: "text", text: "" }] },
		];
		expect(historyToIndexable(history)).toEqual([]);
	});

	it("uiMessagesToIndexable keeps user/assistant rows, drops tool/system", () => {
		const out = uiMessagesToIndexable([
			{ id: "u1", role: "user", text: "q" },
			{ id: "a1", role: "assistant", text: "a" },
			{ id: "t1", role: "tool", text: "tool blob" },
			{ id: "s1", role: "system", text: "sys" },
			{ id: "e1", role: "user", text: "" },
		]);
		expect(out.map((m) => m.id)).toEqual(["u1", "a1"]);
	});
});
