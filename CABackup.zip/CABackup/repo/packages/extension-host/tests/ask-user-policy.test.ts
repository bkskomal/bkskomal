// Pins the ask-user policy-resolution rules. The function itself is a
// module-private helper in chat-panel.ts; we re-implement it here so
// the contract is testable without exporting an internal symbol from
// the chat-panel module. If chat-panel'\''s copy drifts, this test fails
// loudly.
import type { ModeConfig } from "@iom/shared";
import { describe, expect, it } from "vitest";

// --- BEGIN copy-paste from chat-panel.ts (keep in sync) ---
function resolveAskUserPolicy(
	mode: ModeConfig | undefined,
): "always" | "auto-pick-first" | "never" {
	if (!mode) return "always";
	if (mode.allowAskUser) return mode.allowAskUser;
	return "always";
}
// --- END copy-paste ---

const BASE: ModeConfig = {
	id: "chat",
	displayName: "Chat",
	systemPrompt: "",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 5,
};

describe("resolveAskUserPolicy", () => {
	it("returns 'always' for undefined mode (safe default)", () => {
		expect(resolveAskUserPolicy(undefined)).toBe("always");
	});

	it("returns 'always' for a normal interactive mode (chat/code/plan)", () => {
		expect(resolveAskUserPolicy({ ...BASE, id: "chat" })).toBe("always");
		expect(resolveAskUserPolicy({ ...BASE, id: "code" })).toBe("always");
		expect(resolveAskUserPolicy({ ...BASE, id: "plan" })).toBe("always");
	});

	// 2026-06-06: Auto / Auto-Edit no longer silently auto-pick options[0].
	// Surprised users — the model believed it had asked, the chip strip never
	// rendered. Now defaults to "always" in every mode; users who want true
	// unattended autonomy set `allowAskUser: "auto-pick-first"` explicitly.
	it("returns 'always' for auto / auto-edit modes when allowAskUser is unset", () => {
		expect(resolveAskUserPolicy({ ...BASE, id: "auto" })).toBe("always");
		expect(resolveAskUserPolicy({ ...BASE, id: "auto-edit" })).toBe("always");
	});

	it("returns 'always' for autoApprove: true modes when allowAskUser is unset", () => {
		expect(resolveAskUserPolicy({ ...BASE, id: "custom-auto", autoApprove: true })).toBe("always");
	});

	it("explicit allowAskUser setting still wins — users opt back into auto-pick or never", () => {
		expect(resolveAskUserPolicy({ ...BASE, id: "auto", allowAskUser: "auto-pick-first" })).toBe(
			"auto-pick-first",
		);
		expect(resolveAskUserPolicy({ ...BASE, id: "auto", allowAskUser: "never" })).toBe("never");
		expect(resolveAskUserPolicy({ ...BASE, id: "chat", allowAskUser: "never" })).toBe("never");
	});
});
