import { describe, expect, it } from "vitest";
import { buildCIWorkflows } from "../src/ci-init";

describe("buildCIWorkflows", () => {
	it("defaults to github platform with all steps when no config", () => {
		const workflows = buildCIWorkflows({ cfg: undefined, qa: undefined, hints: [] });
		expect(workflows).toHaveLength(1);
		expect(workflows[0].path).toBe(".github/workflows/iom-qa.yml");
		expect(workflows[0].content).toContain("name: iOmCode QA");
		expect(workflows[0].content).toContain("actions/setup-node");
	});

	it("renders gitlab when platform=gitlab", () => {
		const workflows = buildCIWorkflows({
			cfg: { platform: "gitlab" },
			qa: undefined,
			hints: [],
		});
		expect(workflows[0].path).toBe(".gitlab-ci.yml");
		expect(workflows[0].content).toContain("image: node:");
	});

	it("renders circleci when platform=circleci", () => {
		const workflows = buildCIWorkflows({
			cfg: { platform: "circleci" },
			qa: undefined,
			hints: [],
		});
		expect(workflows[0].path).toBe(".circleci/config.yml");
		expect(workflows[0].content).toContain("version: 2.1");
	});

	it("renders azure-pipelines when platform=azure-pipelines", () => {
		const workflows = buildCIWorkflows({
			cfg: { platform: "azure-pipelines" },
			qa: undefined,
			hints: [],
		});
		expect(workflows[0].path).toBe("azure-pipelines.yml");
		expect(workflows[0].content).toContain("vmImage:");
	});

	it("detects Python project and emits setup-python", () => {
		const workflows = buildCIWorkflows({
			cfg: undefined,
			qa: { testFramework: "pytest" },
			hints: ["pyproject.toml content"],
		});
		expect(workflows[0].content).toContain("setup-python");
		expect(workflows[0].content).toContain("pytest");
	});

	it("uses configured node and python versions", () => {
		const workflows = buildCIWorkflows({
			cfg: { nodeVersion: "22", pythonVersion: "3.13" },
			qa: undefined,
			hints: [],
		});
		expect(workflows[0].content).toContain("22");
	});

	it("skips disabled steps", () => {
		const workflows = buildCIWorkflows({
			cfg: {
				includeTypecheck: false,
				includeLint: false,
				includeTests: false,
				includeCoverage: false,
			},
			qa: undefined,
			hints: [],
		});
		const text = workflows[0].content;
		expect(text).not.toContain("Typecheck");
		expect(text).not.toContain("Lint");
		expect(text).not.toContain("Tests");
		expect(text).not.toContain("Coverage");
	});

	it("includes coverage step with thresholds when enabled", () => {
		const workflows = buildCIWorkflows({
			cfg: { includeCoverage: true },
			qa: { coverageThresholds: { lines: 90, branches: 85, functions: 90 } },
			hints: ['"vitest":'],
		});
		expect(workflows[0].content).toContain("coverage");
		expect(workflows[0].content).toContain("90");
		expect(workflows[0].content).toContain("85");
	});

	it("detects biome when biome key is in hints", () => {
		const workflows = buildCIWorkflows({
			cfg: undefined,
			qa: undefined,
			hints: ['"biome":'],
		});
		expect(workflows[0].content).toContain("biome check");
	});

	it("detects eslint when biome is absent but eslint is present", () => {
		const workflows = buildCIWorkflows({
			cfg: undefined,
			qa: undefined,
			hints: ['"eslint":'],
		});
		expect(workflows[0].content).toContain("eslint");
	});

	it("detects vitest from package.json hint", () => {
		const workflows = buildCIWorkflows({
			cfg: undefined,
			qa: undefined,
			hints: ['"vitest":'],
		});
		expect(workflows[0].content).toContain("vitest run");
	});

	it("each generated workflow has a generator-comment header", () => {
		const platforms = ["github", "gitlab", "circleci", "azure-pipelines", "tfs"] as const;
		for (const platform of platforms) {
			const w = buildCIWorkflows({ cfg: { platform }, qa: undefined, hints: [] });
			expect(w[0].content).toContain("iOmCode");
			expect(w[0].content).toContain("/ci init");
		}
	});

	// 2026-05-27: TFS / Azure DevOps Server (on-prem) platform tests.
	it("renders TFS when platform=tfs — uses self-hosted pool not vmImage", () => {
		const w = buildCIWorkflows({
			cfg: { platform: "tfs" },
			qa: undefined,
			hints: [],
		});
		expect(w[0].path).toBe("azure-pipelines.yml");
		expect(w[0].content).toContain("pool:");
		expect(w[0].content).toContain("name: Default"); // self-hosted pool, not vmImage
		expect(w[0].content).not.toContain("vmImage: ubuntu-latest");
	});

	it("TFS uses pwsh: tasks instead of script:", () => {
		const w = buildCIWorkflows({
			cfg: { platform: "tfs" },
			qa: undefined,
			hints: ['"vitest":'],
		});
		expect(w[0].content).toMatch(/- pwsh:/);
		// Azure-pipelines cloud uses `script:` — TFS should NOT.
		expect(w[0].content).not.toContain("- script: vitest");
	});

	it("TFS respects custom agent pool", () => {
		const w = buildCIWorkflows({
			cfg: { platform: "tfs", tfsAgentPool: "BuildServer-Win2022" },
			qa: undefined,
			hints: [],
		});
		expect(w[0].content).toContain("name: BuildServer-Win2022");
	});

	it("TFS gated-check-in flag adds the integrator comment block", () => {
		const withGated = buildCIWorkflows({
			cfg: { platform: "tfs", tfsGatedCheckIn: true },
			qa: undefined,
			hints: [],
		});
		const withoutGated = buildCIWorkflows({
			cfg: { platform: "tfs" },
			qa: undefined,
			hints: [],
		});
		expect(withGated[0].content).toContain("gated check-in policy");
		expect(withGated[0].content).toContain("Build validation");
		expect(withoutGated[0].content).not.toContain("gated check-in policy");
	});

	it("TFS triggers cover main, master, develop, release/* branches", () => {
		const w = buildCIWorkflows({
			cfg: { platform: "tfs" },
			qa: undefined,
			hints: [],
		});
		expect(w[0].content).toContain("- main");
		expect(w[0].content).toContain("- master");
		expect(w[0].content).toContain("- develop");
		expect(w[0].content).toContain("- release/*");
	});

	it("TFS Python project uses UsePythonVersion task + pwsh install", () => {
		const w = buildCIWorkflows({
			cfg: { platform: "tfs" },
			qa: { testFramework: "pytest" },
			hints: ["pyproject.toml content"],
		});
		expect(w[0].content).toContain("UsePythonVersion@0");
		expect(w[0].content).toContain("pwsh: |");
		expect(w[0].content).toContain("Test-Path");
	});
});
