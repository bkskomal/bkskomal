import { DEFAULT_CONFIG, type ProviderConfig } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { SettingsStore } from "../src/settings-store";
import { InMemoryKv, InMemorySecrets } from "../src/storage";

function makeStore() {
	const kv = new InMemoryKv();
	const secrets = new InMemorySecrets();
	const store = new SettingsStore(kv, secrets);
	return { store, kv, secrets };
}

describe("SettingsStore", () => {
	it("returns DEFAULT_CONFIG on an empty store", () => {
		const { store } = makeStore();
		expect(store.config.activeProviderId).toBe(DEFAULT_CONFIG.activeProviderId);
		expect(store.config.providers.length).toBeGreaterThan(0);
	});

	it("persists an updated config and reads it back on reload", async () => {
		const { store, kv, secrets } = makeStore();
		const providers: ProviderConfig[] = [
			{
				id: "p1",
				type: "openai-compatible",
				displayName: "Test",
				preset: "custom",
				baseUrl: "http://example/v1",
				defaultModel: "x",
			},
		];
		await store.updateConfig({
			activeProviderId: "p1",
			activeModeId: "code",
			providers,
		});

		const reloaded = new SettingsStore(kv, secrets);
		expect(reloaded.config.activeProviderId).toBe("p1");
		expect(reloaded.config.providers).toHaveLength(1);
		expect(reloaded.config.providers[0].baseUrl).toBe("http://example/v1");
	});

	it("preserves existing modes when only providers are updated", async () => {
		const { store } = makeStore();
		const before = store.config.modes;
		await store.updateConfig({
			activeProviderId: store.config.activeProviderId,
			activeModeId: store.config.activeModeId,
			providers: [...store.config.providers],
		});
		expect(store.config.modes).toEqual(before);
	});

	it("preserves existing mcpServers when not updated", async () => {
		const { store, kv } = makeStore();
		// Seed the store with mcpServers
		await store.updateConfig({
			activeProviderId: store.config.activeProviderId,
			activeModeId: store.config.activeModeId,
			providers: [...store.config.providers],
			mcpServers: [{ id: "fs", displayName: "FS", command: "npx", enabled: true }],
		});
		// Update without specifying mcpServers
		await store.updateConfig({
			activeProviderId: store.config.activeProviderId,
			activeModeId: store.config.activeModeId,
			providers: [...store.config.providers],
		});
		expect(store.config.mcpServers).toHaveLength(1);
		expect(store.config.mcpServers?.[0].id).toBe("fs");
		// Underlying KV preserved it too
		const reloaded = new SettingsStore(kv, new InMemorySecrets());
		expect(reloaded.config.mcpServers).toHaveLength(1);
	});

	it("stores and retrieves an API key via SecretStorage", async () => {
		const { store } = makeStore();
		expect(await store.getApiKey("p1")).toBeUndefined();
		await store.setApiKey("p1", "sk-secret");
		expect(await store.getApiKey("p1")).toBe("sk-secret");
		await store.deleteApiKey("p1");
		expect(await store.getApiKey("p1")).toBeUndefined();
	});

	it("hasApiKeyMap reports booleans per configured provider", async () => {
		const { store } = makeStore();
		const providers: ProviderConfig[] = [
			{
				id: "p1",
				type: "openai-compatible",
				displayName: "A",
				preset: "custom",
				baseUrl: "",
				defaultModel: "",
			},
			{
				id: "p2",
				type: "openai-compatible",
				displayName: "B",
				preset: "custom",
				baseUrl: "",
				defaultModel: "",
			},
		];
		await store.updateConfig({
			activeProviderId: "p1",
			activeModeId: "code",
			providers,
		});
		await store.setApiKey("p1", "k1");

		const map = await store.hasApiKeyMap();
		expect(map.p1).toBe(true);
		expect(map.p2).toBe(false);
	});

	it("fires listeners on config update and on API key changes", async () => {
		const { store } = makeStore();
		let calls = 0;
		store.on(() => calls++);
		await store.updateConfig({
			activeProviderId: store.config.activeProviderId,
			activeModeId: store.config.activeModeId,
			providers: [...store.config.providers],
		});
		await store.setApiKey("p1", "x");
		await store.deleteApiKey("p1");
		expect(calls).toBe(3);
	});

	it("returns DEFAULT_CONFIG when the stored value fails the shape check", () => {
		const kv = new InMemoryKv();
		// Plant garbage
		void kv.update("iom.config.v1", { not: "a config" });
		const secrets = new InMemorySecrets();
		const store = new SettingsStore(kv, secrets);
		expect(store.config.activeProviderId).toBe(DEFAULT_CONFIG.activeProviderId);
	});

	it("never returns an empty modes list (falls back to DEFAULT_CONFIG.modes)", async () => {
		const kv = new InMemoryKv();
		const secrets = new InMemorySecrets();
		await kv.update("iom.config.v1", {
			activeProviderId: "p1",
			activeModeId: "x",
			providers: [],
			modes: [],
		});
		const store = new SettingsStore(kv, secrets);
		expect(store.config.modes.length).toBeGreaterThan(0);
	});
});
