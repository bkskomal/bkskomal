// R3-B: model router unit tests.
import type {
	ConversationMessage,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
	RoutingConfig,
} from "@iom/shared";
import { describe, expect, it, vi } from "vitest";
import {
	ModelRouter,
	classifyDifficulty,
	looksLikeRateLimit,
	parseRouteOverride,
	withRetryFallback,
} from "../src/model-router";

const EMPTY_HISTORY: readonly ConversationMessage[] = [];

describe("parseRouteOverride", () => {
	it("strips `/route fast` prefix and reports override", () => {
		const r = parseRouteOverride("/route fast write me a quicksort");
		expect(r.override).toBe("fast");
		expect(r.remainingPrompt).toBe("write me a quicksort");
	});
	it("strips `/route slow` prefix", () => {
		const r = parseRouteOverride("  /route SLOW  reason about this");
		expect(r.override).toBe("slow");
		expect(r.remainingPrompt).toBe("reason about this");
	});
	it("leaves non-override prompts untouched", () => {
		const r = parseRouteOverride("hello, world");
		expect(r.override).toBeUndefined();
		expect(r.remainingPrompt).toBe("hello, world");
	});
	it("does not match arbitrary slash commands", () => {
		const r = parseRouteOverride("/help me");
		expect(r.override).toBeUndefined();
	});
});

describe("classifyDifficulty", () => {
	it("returns trivial for very short prompts", () => {
		expect(classifyDifficulty("hi", EMPTY_HISTORY)).toBe("trivial");
	});
	it("returns easy for 200-1000 chars", () => {
		expect(classifyDifficulty("x".repeat(500), EMPTY_HISTORY)).toBe("easy");
	});
	it("returns medium for 1000-4000 chars", () => {
		expect(classifyDifficulty("x".repeat(1500), EMPTY_HISTORY)).toBe("medium");
	});
	it("returns hard for >4000 chars", () => {
		expect(classifyDifficulty("x".repeat(5000), EMPTY_HISTORY)).toBe("hard");
	});
	it("upgrades to hard when last assistant turn fired >5 tool calls", () => {
		const history: ConversationMessage[] = [
			{
				role: "assistant",
				parts: Array.from({ length: 7 }, (_, i) => ({
					kind: "tool_call" as const,
					id: `tc${i}`,
					name: "exec",
					args: {},
				})),
			},
		];
		// Short prompt but heavy recent tool use -> hard
		expect(classifyDifficulty("status?", history)).toBe("hard");
	});
});

describe("ModelRouter", () => {
	const baseRouting: RoutingConfig = {
		enabled: true,
		rules: [
			{ when: "trivial", providerId: "ollama", model: "llama3.1:8b" },
			{ when: "hard", providerId: "anthropic", model: "claude-opus-4-7" },
		],
		fallback: { providerId: "anthropic", model: "claude-haiku-4-5" },
	};

	it("returns default when routing is disabled", () => {
		const router = new ModelRouter(
			{ enabled: false, rules: [] },
			{ defaultProviderId: "primary", defaultModel: "m" },
		);
		const d = router.pick({ prompt: "hi", history: EMPTY_HISTORY });
		expect(d.providerId).toBe("primary");
		expect(d.model).toBe("m");
		expect(d.isDefault).toBe(true);
	});

	it("matches the trivial rule for short prompts", () => {
		const router = new ModelRouter(baseRouting, {
			defaultProviderId: "primary",
			defaultModel: "default-m",
		});
		const d = router.pick({ prompt: "hi", history: EMPTY_HISTORY });
		expect(d.providerId).toBe("ollama");
		expect(d.model).toBe("llama3.1:8b");
		expect(d.isDefault).toBe(false);
	});

	it("matches the hard rule when prompt is long", () => {
		const router = new ModelRouter(baseRouting, {
			defaultProviderId: "primary",
			defaultModel: "default-m",
		});
		const d = router.pick({ prompt: "x".repeat(5000), history: EMPTY_HISTORY });
		expect(d.providerId).toBe("anthropic");
		expect(d.model).toBe("claude-opus-4-7");
	});

	it("falls through to default when no rule matches the bucket", () => {
		const router = new ModelRouter(baseRouting, {
			defaultProviderId: "primary",
			defaultModel: "default-m",
		});
		// "easy" bucket has no rule
		const d = router.pick({ prompt: "x".repeat(500), history: EMPTY_HISTORY });
		expect(d.providerId).toBe("primary");
		expect(d.isDefault).toBe(true);
	});

	it("honors `/route fast` override to trivial", () => {
		const router = new ModelRouter(baseRouting, {
			defaultProviderId: "primary",
			defaultModel: "default-m",
		});
		// Long prompt that would normally be "hard"; override forces trivial -> ollama
		const d = router.pick({
			prompt: "x".repeat(5000),
			history: EMPTY_HISTORY,
			override: "fast",
		});
		expect(d.providerId).toBe("ollama");
		expect(d.bucket).toBe("trivial");
	});
});

describe("looksLikeRateLimit", () => {
	it.each([
		"HTTP 429 Too Many Requests",
		"rate_limit_exceeded",
		"Rate limit reached for gpt-4",
		"Too Many Requests",
	])("detects %s", (msg) => {
		expect(looksLikeRateLimit(msg)).toBe(true);
	});
	it("returns false for unrelated errors", () => {
		expect(looksLikeRateLimit("ECONNREFUSED")).toBe(false);
		expect(looksLikeRateLimit("")).toBe(false);
	});
});

describe("withRetryFallback", () => {
	function makeProvider(id: string, gen: () => AsyncIterable<ProviderStreamEvent>): ProviderSpec {
		return {
			id,
			displayName: id,
			stream: () => gen(),
		};
	}

	const baseReq: ProviderRequest = {
		messages: [{ role: "user", parts: [{ kind: "text", text: "hi" }] }],
		modelId: "m1",
	};

	it("returns primary stream events on success", async () => {
		const primary = makeProvider("p1", async function* () {
			yield { type: "text_delta", text: "ok" } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		});
		const events: ProviderStreamEvent[] = [];
		for await (const ev of withRetryFallback(
			{ providerId: "p1" },
			baseReq,
			(id) => (id === "p1" ? primary : undefined),
			undefined,
		)) {
			events.push(ev);
		}
		expect(events.some((e) => e.type === "text_delta")).toBe(true);
		expect(events[events.length - 1].type).toBe("message_end");
	});

	it("retries once then falls back on second 429", async () => {
		let attempts = 0;
		const primary = makeProvider("p1", async function* () {
			attempts++;
			yield { type: "error", message: "HTTP 429 rate_limit_exceeded" } as ProviderStreamEvent;
		});
		const fb = makeProvider("p2", async function* () {
			yield { type: "text_delta", text: "fb" } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		});
		const sleepSpy = vi.fn().mockResolvedValue(undefined);
		const switchSpy = vi.fn();
		const events: ProviderStreamEvent[] = [];
		for await (const ev of withRetryFallback(
			{ providerId: "p1" },
			baseReq,
			(id) => (id === "p1" ? primary : id === "p2" ? fb : undefined),
			{ providerId: "p2" },
			{ retryAfterMs: 10, sleep: sleepSpy, onSwitchToFallback: switchSpy },
		)) {
			events.push(ev);
		}
		expect(attempts).toBe(2);
		expect(sleepSpy).toHaveBeenCalled();
		expect(switchSpy).toHaveBeenCalled();
		const delta = events.find(
			(e): e is { type: "text_delta"; text: string } => e.type === "text_delta",
		);
		expect(delta?.text).toBe("fb");
	});

	it("emits error when rate-limited twice and no fallback", async () => {
		const primary = makeProvider("p1", async function* () {
			yield { type: "error", message: "429 too many requests" } as ProviderStreamEvent;
		});
		const sleepSpy = vi.fn().mockResolvedValue(undefined);
		const events: ProviderStreamEvent[] = [];
		for await (const ev of withRetryFallback(
			{ providerId: "p1" },
			baseReq,
			(id) => (id === "p1" ? primary : undefined),
			undefined,
			{ retryAfterMs: 10, sleep: sleepSpy },
		)) {
			events.push(ev);
		}
		expect(events[0].type).toBe("error");
		expect(events[events.length - 1].type).toBe("message_end");
	});
});
