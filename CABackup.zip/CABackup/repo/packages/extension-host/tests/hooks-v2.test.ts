// R8-E: tests for the v2 hook runner + the legacy migration shim.
//
// These exercise the 8-event surface, the `blockOnFailure` semantics
// (a non-blocking hook returning `allow:false` no longer cancels the action),
// payload mutation chains, and the fallback when no hooks are configured.
// Spawn is stubbed via `fakeChild` so the suite runs without external binaries.

import type { ChildProcess } from "node:child_process";
import { EventEmitter } from "node:events";
import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { PassThrough, Writable } from "node:stream";
import type { HookConfig } from "@iom/shared";
import { describe, expect, it, vi } from "vitest";
import {
	HOOKS_V2_FILE_REL,
	type HookV2Entry,
	HookV2Runner,
	loadHooksV2,
	matcherApplies,
	migrateLegacyHooks,
	normalizeHooksFile,
} from "../src/hooks-v2";

/** Build a fake ChildProcess identical to the one in hook-runner.test.ts. */
function fakeChild(opts: {
	stdout?: string;
	stderr?: string;
	exitCode?: number;
	delayMs?: number;
	errorOnSpawn?: Error;
}): ChildProcess {
	const ee = new EventEmitter() as ChildProcess;
	const stdout = new PassThrough();
	const stderr = new PassThrough();
	const stdinChunks: string[] = [];
	const stdin = new Writable({
		write(chunk, _enc, cb) {
			stdinChunks.push(chunk.toString());
			cb();
		},
	});
	Object.assign(ee, { stdout, stderr, stdin, kill: vi.fn(), stdinChunks });

	if (opts.errorOnSpawn) {
		setImmediate(() => ee.emit("error", opts.errorOnSpawn));
		return ee;
	}
	const finish = () => {
		if (opts.stdout) stdout.write(opts.stdout);
		if (opts.stderr) stderr.write(opts.stderr);
		stdout.end();
		stderr.end();
		ee.emit("close", opts.exitCode ?? 0);
	};
	if (opts.delayMs && opts.delayMs > 0) setTimeout(finish, opts.delayMs);
	else setImmediate(finish);
	return ee;
}

type SpawnFn = typeof import("node:child_process")["spawn"];

function makeSpawn(plan: ((cmd: string) => ChildProcess) | ChildProcess): {
	spawnFn: SpawnFn;
	calls: { command: string }[];
} {
	const calls: { command: string }[] = [];
	const spawnFn = ((command: string) => {
		calls.push({ command });
		return typeof plan === "function" ? plan(command) : plan;
	}) as unknown as SpawnFn;
	return { spawnFn, calls };
}

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-hooks-v2-"));
}

describe("hooks-v2 matcherApplies", () => {
	it("matches everything when matcher is undefined", () => {
		expect(matcherApplies(undefined, "anything")).toBe(true);
	});
	it("does substring matching by default", () => {
		expect(matcherApplies("write", "write_file")).toBe(true);
		expect(matcherApplies("read", "write_file")).toBe(false);
	});
	it("treats matchers with * as anchored globs", () => {
		expect(matcherApplies("write_*", "write_file")).toBe(true);
		expect(matcherApplies("write_*", "read_file")).toBe(false);
	});
});

describe("migrateLegacyHooks", () => {
	it("returns [] for undefined/empty input", () => {
		expect(migrateLegacyHooks(undefined)).toEqual([]);
		expect(migrateLegacyHooks([])).toEqual([]);
	});

	it("maps R1 `blocking` → v2 `blockOnFailure` and preserves the rest", () => {
		const legacy: HookConfig[] = [
			{ event: "PreToolUse", command: "lint", matcher: "write_*", blocking: true, timeout: 1234 },
			{ event: "PostToolUse", command: "log" },
		];
		const migrated = migrateLegacyHooks(legacy);
		expect(migrated).toEqual([
			{
				event: "PreToolUse",
				command: "lint",
				matcher: "write_*",
				blockOnFailure: true,
				timeout: 1234,
			},
			{ event: "PostToolUse", command: "log" },
		]);
	});
});

describe("normalizeHooksFile", () => {
	it("accepts a top-level array shape", () => {
		const parsed = normalizeHooksFile([
			{ event: "PreToolUse", command: "lint" },
			{ event: "Stop", command: "save" },
		]);
		expect(parsed).toHaveLength(2);
	});
	it("accepts the `{hooks: [...]}` wrapper shape", () => {
		const parsed = normalizeHooksFile({
			hooks: [{ event: "Notification", command: "notify" }],
		});
		expect(parsed).toEqual([{ event: "Notification", command: "notify" }]);
	});
	it("drops entries with an unknown event or missing command", () => {
		const parsed = normalizeHooksFile([
			{ event: "Bogus", command: "x" },
			{ event: "PreToolUse" },
			{ event: "PreToolUse", command: "" },
			{ event: "PreToolUse", command: "ok" },
		]);
		expect(parsed).toEqual([{ event: "PreToolUse", command: "ok" }]);
	});
	it("accepts both `blockOnFailure` and the legacy `blocking` alias", () => {
		const parsed = normalizeHooksFile([
			{ event: "PreToolUse", command: "a", blocking: true },
			{ event: "PreToolUse", command: "b", blockOnFailure: true },
		]);
		expect(parsed.every((e) => e.blockOnFailure === true)).toBe(true);
	});
});

describe("loadHooksV2", () => {
	it("falls back to legacy when .iom/hooks.json is missing", async () => {
		const dir = await mkTempDir();
		const res = await loadHooksV2(dir, [{ event: "PreToolUse", command: "legacy" }]);
		expect(res.source).toBe("legacy");
		expect(res.hooks).toEqual([{ event: "PreToolUse", command: "legacy" }]);
	});
	it("returns empty when neither v2 file nor legacy hooks exist", async () => {
		const dir = await mkTempDir();
		const res = await loadHooksV2(dir, undefined);
		expect(res.source).toBe("empty");
		expect(res.hooks).toEqual([]);
	});
	it("reads `.iom/hooks.json` when present", async () => {
		const dir = await mkTempDir();
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(
			path.join(dir, HOOKS_V2_FILE_REL),
			JSON.stringify({
				hooks: [
					{ event: "SessionEnd", command: "save-state" },
					{ event: "PreToolUse", command: "audit", blockOnFailure: true },
				],
			}),
		);
		const res = await loadHooksV2(dir, undefined);
		expect(res.source).toBe("file");
		expect(res.hooks).toEqual([
			{ event: "SessionEnd", command: "save-state" },
			{ event: "PreToolUse", command: "audit", blockOnFailure: true },
		]);
	});
	it("falls back to legacy + emits a warning when v2 file is malformed", async () => {
		const dir = await mkTempDir();
		await fs.mkdir(path.join(dir, ".iom"), { recursive: true });
		await fs.writeFile(path.join(dir, HOOKS_V2_FILE_REL), "{not json");
		const res = await loadHooksV2(dir, [{ event: "Stop", command: "save" }]);
		expect(res.source).toBe("legacy");
		expect(res.warning).toBeTruthy();
		expect(res.hooks).toEqual([{ event: "Stop", command: "save" }]);
	});
});

describe("HookV2Runner.fire", () => {
	const baseHook: HookV2Entry = { event: "PreToolUse", command: "noop" };

	it("returns allow:true when no hooks match", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: "" }));
		const runner = new HookV2Runner([], { spawnFn });
		const result = await runner.fire({
			kind: "PreToolUse",
			payload: { toolName: "write_file", args: { path: "/x" } },
		});
		expect(result.allow).toBe(true);
		expect(result.payload).toEqual({ toolName: "write_file", args: { path: "/x" } });
	});

	it("treats a non-JSON stdout as a passive observer (allow:true)", async () => {
		const { spawnFn, calls } = makeSpawn(() => fakeChild({ stdout: "noted\n" }));
		const runner = new HookV2Runner([baseHook], { spawnFn });
		const r = await runner.fire({
			kind: "PreToolUse",
			payload: { toolName: "write_file" },
		});
		expect(r.allow).toBe(true);
		expect(calls).toHaveLength(1);
	});

	it("does NOT block when `allow:false` arrives but blockOnFailure is unset", async () => {
		const { spawnFn } = makeSpawn(() =>
			fakeChild({ stdout: '{"allow": false, "reason": "advisory"}' }),
		);
		const runner = new HookV2Runner([baseHook], { spawnFn });
		const r = await runner.fire({
			kind: "PreToolUse",
			payload: { toolName: "write_file" },
		});
		expect(r.allow).toBe(true);
	});

	it("blocks when allow:false arrives AND blockOnFailure is true", async () => {
		const { spawnFn } = makeSpawn(() =>
			fakeChild({ stdout: '{"allow": false, "reason": "policy"}' }),
		);
		const runner = new HookV2Runner([{ ...baseHook, blockOnFailure: true }], { spawnFn });
		const r = await runner.fire({
			kind: "PreToolUse",
			payload: { toolName: "write_file" },
		});
		expect(r.allow).toBe(false);
		expect(r.reason).toBe("policy");
	});

	it("blocks when the child exits non-zero with blockOnFailure", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: "", exitCode: 17 }));
		const runner = new HookV2Runner([{ ...baseHook, blockOnFailure: true }], { spawnFn });
		const r = await runner.fire({
			kind: "PreToolUse",
			payload: { toolName: "write_file" },
		});
		expect(r.allow).toBe(false);
		expect(r.reason).toContain("17");
	});

	it("threads modifiedPayload through a chain of hooks", async () => {
		const stdoutByCommand: Record<string, string> = {
			first: '{"allow": true, "modifiedPayload": {"text": "step1"}}',
			second: '{"allow": true, "modifiedPayload": {"text": "step2"}}',
		};
		const { spawnFn } = makeSpawn((cmd) => fakeChild({ stdout: stdoutByCommand[cmd] ?? "" }));
		const runner = new HookV2Runner(
			[
				{ event: "UserPromptSubmit", command: "first" },
				{ event: "UserPromptSubmit", command: "second" },
			],
			{ spawnFn },
		);
		const r = await runner.fire({
			kind: "UserPromptSubmit",
			payload: { text: "hello" },
		});
		expect(r.allow).toBe(true);
		expect(r.payload).toEqual({ text: "step2" });
	});

	it("dispatches each event to hooks of the matching event type only", async () => {
		const { spawnFn, calls } = makeSpawn(() => fakeChild({ stdout: "" }));
		const runner = new HookV2Runner(
			[
				{ event: "UserPromptSubmit", command: "u" },
				{ event: "PreToolUse", command: "pre" },
				{ event: "PostToolUse", command: "post" },
				{ event: "Notification", command: "notify" },
				{ event: "Stop", command: "stop" },
				{ event: "SubagentStop", command: "substop" },
				{ event: "SessionStart", command: "start" },
				{ event: "SessionEnd", command: "end" },
			],
			{ spawnFn },
		);
		await runner.fire({ kind: "UserPromptSubmit", payload: { text: "x" } });
		await runner.fire({ kind: "PreToolUse", payload: { toolName: "a" } });
		await runner.fire({ kind: "PostToolUse", payload: { toolName: "a", result: "ok" } });
		await runner.fire({
			kind: "Notification",
			payload: { kind: "task_completed", title: "done" },
		});
		await runner.fire({ kind: "Stop", payload: { sessionId: "s1" } });
		await runner.fire({
			kind: "SubagentStop",
			payload: { agentId: "a1", status: "ok" },
		});
		await runner.fire({ kind: "SessionStart", payload: { sessionId: "s1" } });
		await runner.fire({ kind: "SessionEnd", payload: { sessionId: "s1" } });
		expect(calls.map((c) => c.command)).toEqual([
			"u",
			"pre",
			"post",
			"notify",
			"stop",
			"substop",
			"start",
			"end",
		]);
	});

	it("recovers from spawn error by allowing the action", async () => {
		const { spawnFn } = makeSpawn(() =>
			fakeChild({ errorOnSpawn: new Error("ENOENT: no such file") }),
		);
		const runner = new HookV2Runner([{ ...baseHook, command: "no-such-bin" }], { spawnFn });
		const r = await runner.fire({
			kind: "PreToolUse",
			payload: { toolName: "x" },
		});
		expect(r.allow).toBe(true);
	});

	it("enforces the per-hook timeout", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: '{"allow":false}', delayMs: 100 }));
		const runner = new HookV2Runner([{ ...baseHook, blockOnFailure: true, timeout: 10 }], {
			spawnFn,
		});
		const start = Date.now();
		const r = await runner.fire({ kind: "PreToolUse", payload: { toolName: "x" } });
		const elapsed = Date.now() - start;
		expect(r.allow).toBe(true);
		expect(elapsed).toBeLessThan(80);
	});

	it("caps Stop hooks at the tighter stopTimeoutMs", async () => {
		const { spawnFn } = makeSpawn(() => fakeChild({ stdout: "", delayMs: 50 }));
		const runner = new HookV2Runner([{ event: "Stop", command: "slow", timeout: 60_000 }], {
			spawnFn,
			stopTimeoutMs: 10,
		});
		const start = Date.now();
		const r = await runner.fire({ kind: "Stop", payload: { sessionId: "s1" } });
		expect(r.allow).toBe(true);
		expect(Date.now() - start).toBeLessThan(120);
	});

	it("exposes size and countByEvent for the /hooks UI", () => {
		const runner = new HookV2Runner([
			{ event: "PreToolUse", command: "a" },
			{ event: "PreToolUse", command: "b" },
			{ event: "PostToolUse", command: "c" },
		]);
		expect(runner.size).toBe(3);
		expect(runner.countByEvent("PreToolUse")).toBe(2);
		expect(runner.countByEvent("SessionEnd")).toBe(0);
	});
});
