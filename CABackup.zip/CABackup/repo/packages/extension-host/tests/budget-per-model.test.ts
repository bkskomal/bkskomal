// R5-E: per-model budget tests.

import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { ModelBudget } from "@iom/shared";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { PerModelBudget, currentMonthString, selectModelBudget } from "../src/budget";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-budget-pm-"));
}

const MODEL = "claude-sonnet-4-6"; // $3 in / $15 out per 1M tokens.

describe("selectModelBudget (deny-order / most-specific match)", () => {
	it("returns undefined when no rules match", () => {
		const rules: ModelBudget[] = [{ providerId: "openai", dailyUsd: 1 }];
		expect(selectModelBudget(rules, "anthropic", "claude-sonnet-4-6")).toBeUndefined();
	});

	it("matches a provider-only rule when there is no model-specific one", () => {
		const rules: ModelBudget[] = [{ providerId: "anthropic", dailyUsd: 5 }];
		const picked = selectModelBudget(rules, "anthropic", "claude-sonnet-4-6");
		expect(picked).toBeDefined();
		expect(picked?.modelId).toBeUndefined();
		expect(picked?.dailyUsd).toBe(5);
	});

	it("prefers a model-specific rule over a provider-only rule", () => {
		const rules: ModelBudget[] = [
			{ providerId: "anthropic", dailyUsd: 10 },
			{ providerId: "anthropic", modelId: "claude-sonnet-4-6", dailyUsd: 3 },
		];
		const picked = selectModelBudget(rules, "anthropic", "claude-sonnet-4-6");
		expect(picked?.modelId).toBe("claude-sonnet-4-6");
		expect(picked?.dailyUsd).toBe(3);
	});

	it("breaks ties between two model substrings by longest match", () => {
		const rules: ModelBudget[] = [
			{ providerId: "anthropic", modelId: "claude", dailyUsd: 100 },
			{ providerId: "anthropic", modelId: "claude-sonnet", dailyUsd: 7 },
		];
		const picked = selectModelBudget(rules, "anthropic", "claude-sonnet-4-6");
		expect(picked?.dailyUsd).toBe(7);
	});
});

describe("PerModelBudget — daily/month gating", () => {
	let dir: string;
	beforeEach(async () => {
		dir = await mkTempDir();
	});
	afterEach(async () => {
		await fs.rm(dir, { recursive: true, force: true });
	});

	it("allows when no matching rule exists", async () => {
		const b = new PerModelBudget(dir);
		const v = await b.checkPerModelBudget(
			[{ providerId: "openai", dailyUsd: 1 }],
			"anthropic",
			MODEL,
		);
		expect(v.allowed).toBe(true);
	});

	it("blocks when provider-only daily cap is exhausted", async () => {
		const b = new PerModelBudget(dir);
		const rules: ModelBudget[] = [{ providerId: "anthropic", dailyUsd: 2 }];
		await b._setDayCost("anthropic", undefined, 5);
		const v = await b.checkPerModelBudget(rules, "anthropic", MODEL);
		expect(v.allowed).toBe(false);
		expect(v.reason ?? "").toContain("daily");
	});

	it("blocks when model-specific daily cap is exhausted (overrides looser provider rule)", async () => {
		const b = new PerModelBudget(dir);
		const rules: ModelBudget[] = [
			{ providerId: "anthropic", dailyUsd: 100 },
			{ providerId: "anthropic", modelId: "claude-sonnet-4-6", dailyUsd: 1 },
		];
		// Spend goes to the model-specific bucket because that's the rule that fires.
		await b._setDayCost("anthropic", "claude-sonnet-4-6", 2);
		const v = await b.checkPerModelBudget(rules, "anthropic", MODEL);
		expect(v.allowed).toBe(false);
		expect(v.reason ?? "").toContain("daily");
		expect(v.reason ?? "").toContain("claude-sonnet-4-6");
	});

	it("blocks when monthly cap is exhausted even with daily room left", async () => {
		const b = new PerModelBudget(dir);
		const rules: ModelBudget[] = [
			{ providerId: "anthropic", modelId: "claude-sonnet-4-6", dailyUsd: 50, monthlyUsd: 10 },
		];
		await b._setDayCost("anthropic", "claude-sonnet-4-6", 1);
		await b._setMonthCost("anthropic", "claude-sonnet-4-6", 20);
		const v = await b.checkPerModelBudget(rules, "anthropic", MODEL);
		expect(v.allowed).toBe(false);
		expect(v.reason ?? "").toContain("monthly");
	});

	it("recordUsage tallies into both day and month files", async () => {
		const fixedDate = new Date("2026-05-21T12:00:00Z");
		const b = new PerModelBudget(dir, () => fixedDate);
		const r = await b.recordUsage("anthropic", MODEL, 0, 100_000); // $1.50
		expect(r.costThisCall).toBeCloseTo(1.5, 5);
		expect(r.dayUsd).toBeCloseTo(1.5, 5);
		expect(r.monthUsd).toBeCloseTo(1.5, 5);
		const dayFile = path.join(
			dir,
			".iom",
			"budget-model-anthropic-claude-sonnet-4-6-day-20260521.json",
		);
		const monthFile = path.join(
			dir,
			".iom",
			`budget-model-anthropic-claude-sonnet-4-6-month-${currentMonthString(fixedDate)}.json`,
		);
		const dayRaw = JSON.parse(await fs.readFile(dayFile, "utf-8"));
		expect(dayRaw.totalUsd).toBeCloseTo(1.5, 5);
		const monthRaw = JSON.parse(await fs.readFile(monthFile, "utf-8"));
		expect(monthRaw.totalUsd).toBeCloseTo(1.5, 5);
	});

	it("daily limit denies before monthly when both would deny (deny ordering)", async () => {
		const b = new PerModelBudget(dir);
		const rules: ModelBudget[] = [
			{ providerId: "anthropic", modelId: MODEL, dailyUsd: 1, monthlyUsd: 5 },
		];
		await b._setDayCost("anthropic", MODEL, 2);
		await b._setMonthCost("anthropic", MODEL, 10);
		const v = await b.checkPerModelBudget(rules, "anthropic", MODEL);
		expect(v.allowed).toBe(false);
		// Daily limit message wins because it's checked first.
		expect(v.reason ?? "").toContain("daily");
	});
});
