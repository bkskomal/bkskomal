// R8-E: tests for the skills loader, front-matter parser, trigger matching,
// and prelude assembly.

import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import { describe, expect, it } from "vitest";
import {
	SKILLS_DIR_REL,
	type Skill,
	assembleSkillsPrelude,
	loadSkill,
	loadSkills,
	matchSkills,
	parseSkill,
} from "../src/skills";

async function mkTempDir(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-skills-"));
}

async function writeSkill(root: string, filename: string, body: string): Promise<void> {
	const dir = path.join(root, SKILLS_DIR_REL);
	await fs.mkdir(dir, { recursive: true });
	await fs.writeFile(path.join(dir, filename), body, "utf-8");
}

describe("parseSkill", () => {
	it("extracts name, description, tools, triggers, and body", () => {
		const raw = `---
name: db-migration-writer
description: Author Knex/Prisma database migrations safely
tools: [read_file, write_file, run_tests]
triggers:
  - migration
  - schema change
---

# DB migration writer

Always read the previous migration first.
`;
		const skill = parseSkill("db-migration-writer", raw);
		expect(skill).toBeTruthy();
		expect(skill?.name).toBe("db-migration-writer");
		expect(skill?.description).toBe("Author Knex/Prisma database migrations safely");
		expect(skill?.tools).toEqual(["read_file", "write_file", "run_tests"]);
		expect(skill?.triggers).toEqual(["migration", "schema change"]);
		expect(skill?.body.trim().startsWith("# DB migration writer")).toBe(true);
	});

	it("falls back to the filename when name front-matter is missing", () => {
		const raw = `---
description: foo
---
body`;
		const skill = parseSkill("from-filename", raw);
		expect(skill?.name).toBe("from-filename");
		expect(skill?.description).toBe("foo");
	});

	it("treats the whole file as body when front-matter fence is absent", () => {
		const skill = parseSkill("no-fm", "plain markdown body");
		expect(skill?.name).toBe("no-fm");
		// Without a description in front-matter, the loader falls back to the name.
		expect(skill?.description).toBe("no-fm");
		expect(skill?.body).toBe("plain markdown body");
		expect(skill?.triggers).toEqual([]);
	});

	it("returns undefined when the front-matter is malformed YAML", () => {
		// Unterminated string + bad indent — js-yaml throws on this.
		const broken = `---
name: "ok
---
body`;
		expect(parseSkill("ok", broken)).toBeUndefined();
		// And a well-formed file still parses fine.
		const good = `---
name: ok
description: ok
---
body`;
		expect(parseSkill("ok", good)).toBeTruthy();
	});
});

describe("loadSkills", () => {
	it("returns an empty array when the workspace has no skills dir", async () => {
		const dir = await mkTempDir();
		const skills = await loadSkills(dir);
		expect(skills).toEqual([]);
	});

	it("returns [] when workspaceRoot is undefined", async () => {
		const skills = await loadSkills(undefined);
		expect(skills).toEqual([]);
	});

	it("loads every well-formed skill and sorts by name", async () => {
		const dir = await mkTempDir();
		await writeSkill(
			dir,
			"zebra.md",
			`---
name: zebra
description: Z
triggers: [stripe]
---
Z body`,
		);
		await writeSkill(
			dir,
			"alpha.md",
			`---
name: alpha
description: A
triggers: [start]
tools: [read_file]
---
A body`,
		);
		const skills = await loadSkills(dir);
		expect(skills.map((s) => s.name)).toEqual(["alpha", "zebra"]);
		expect(skills[0].tools).toEqual(["read_file"]);
	});

	it("ignores files with invalid filenames", async () => {
		const dir = await mkTempDir();
		await writeSkill(dir, "bad name with spaces.md", "no fm");
		await writeSkill(
			dir,
			"good-one.md",
			`---
name: good-one
description: ok
triggers: [x]
---
body`,
		);
		const skills = await loadSkills(dir);
		expect(skills.map((s) => s.name)).toEqual(["good-one"]);
	});
});

describe("loadSkill (single, by name)", () => {
	it("returns undefined when the skill file is missing", async () => {
		const dir = await mkTempDir();
		const s = await loadSkill(dir, "missing");
		expect(s).toBeUndefined();
	});
	it("returns the parsed skill when present", async () => {
		const dir = await mkTempDir();
		await writeSkill(
			dir,
			"foo.md",
			`---
name: foo
description: Foo skill
triggers: [foo]
---
foo body`,
		);
		const s = await loadSkill(dir, "foo");
		expect(s?.body).toBe("foo body");
	});
	it("refuses an out-of-shape skill name (no path traversal)", async () => {
		const dir = await mkTempDir();
		const s = await loadSkill(dir, "../etc/passwd");
		expect(s).toBeUndefined();
	});
});

describe("matchSkills", () => {
	const skills: Skill[] = [
		{
			name: "migration",
			description: "DB migrations",
			tools: [],
			triggers: ["migration", "schema change"],
			body: "",
		},
		{
			name: "deploy",
			description: "Deploys",
			tools: [],
			triggers: ["deploy", "release"],
			body: "",
		},
		{
			name: "noop",
			description: "Manual only",
			tools: [],
			triggers: [],
			body: "",
		},
	];

	it("returns skills whose triggers substring-match the prompt", () => {
		const m = matchSkills(skills, "Please add a database MIGRATION for users.");
		expect(m.map((s) => s.name)).toEqual(["migration"]);
	});

	it("returns [] when nothing matches", () => {
		expect(matchSkills(skills, "just write some code")).toEqual([]);
	});

	it("never matches a skill with no triggers (manual-only)", () => {
		expect(matchSkills(skills, "noop")).toEqual([]);
	});

	it("respects the limit argument", () => {
		const many: Skill[] = Array.from({ length: 5 }, (_, i) => ({
			name: `s${i}`,
			description: `desc ${i}`,
			tools: [],
			triggers: ["needle"],
			body: "",
		}));
		const m = matchSkills(many, "needle in the haystack", 2);
		expect(m).toHaveLength(2);
	});
});

describe("assembleSkillsPrelude", () => {
	it("returns the empty string when no skills match", () => {
		expect(assembleSkillsPrelude([])).toBe("");
	});

	it("builds a markdown block with `load_skill` instructions per skill", () => {
		const out = assembleSkillsPrelude([
			{
				name: "migration",
				description: "DB migrations",
				tools: ["read_file", "write_file"],
				triggers: ["migration"],
				body: "",
			},
		]);
		expect(out).toMatch(/Available skill: migration/);
		expect(out).toMatch(/load_skill/);
		expect(out).toMatch(/read_file, write_file/);
	});
});
