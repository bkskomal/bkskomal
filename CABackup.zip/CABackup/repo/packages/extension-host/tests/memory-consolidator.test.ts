// R6-A: memory-consolidator tests.

import { promises as fs } from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type {
	ConversationMessage,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
} from "@iom/shared";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { loadFacts } from "../src/agent-facts";
import { consolidateOldSessions, parseLessons } from "../src/memory-consolidator";
import { SessionStore } from "../src/session-store";
import { InMemoryKv } from "../src/storage";

async function makeTempWorkspace(): Promise<string> {
	return fs.mkdtemp(path.join(os.tmpdir(), "iom-memcon-"));
}

function fixedProvider(text: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			yield { type: "text_delta", text } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		},
	};
}

describe("parseLessons", () => {
	it("extracts a list of lessons", () => {
		const out = parseLessons(`<lessons>${JSON.stringify({ lessons: ["A", "B"] })}</lessons>`);
		expect(out).toEqual(["A", "B"]);
	});

	it("returns empty when tag is missing", () => {
		expect(parseLessons("nope")).toEqual([]);
	});

	it("returns empty on malformed JSON", () => {
		expect(parseLessons("<lessons>{nope}</lessons>")).toEqual([]);
	});

	it("filters non-string entries", () => {
		const out = parseLessons(`<lessons>${JSON.stringify({ lessons: ["ok", 7, ""] })}</lessons>`);
		expect(out).toEqual(["ok"]);
	});
});

describe("consolidateOldSessions", () => {
	let workspace: string;

	beforeEach(async () => {
		workspace = await makeTempWorkspace();
	});

	afterEach(async () => {
		await fs.rm(workspace, { recursive: true, force: true });
	});

	it("scans only sessions older than the cutoff and promotes lessons", async () => {
		const kv = new InMemoryKv();
		const baseDate = new Date("2026-05-21T00:00:00Z");
		const store = new SessionStore(kv, {
			getWorkspaceId: () => "ws1",
			now: () => baseDate,
		});

		// Create an old session by writing the index directly with a past
		// lastUpdatedAt.
		const oldMeta = await store.create();
		const old: ConversationMessage[] = [
			{ role: "user", parts: [{ kind: "text", text: "How does auth work?" }] },
			{
				role: "assistant",
				parts: [{ kind: "text", text: "Auth lives in middleware/auth.ts" }],
			},
		];
		await store.save(oldMeta.id, old);
		await kv.update("iom.session-index.v2.ws1", {
			version: 2,
			sessions: [
				{
					id: oldMeta.id,
					title: oldMeta.title,
					createdAt: "2026-01-01T00:00:00Z",
					lastUpdatedAt: "2026-01-01T00:00:00Z",
					messageCount: old.length,
				},
			],
		});

		const result = await consolidateOldSessions(store, {
			workspaceRoot: workspace,
			provider: fixedProvider(""), // not used because we stub extract
			modelId: "any",
			daysOld: 30,
			now: () => baseDate,
			extract: async () => ["Auth middleware lives in middleware/auth.ts"],
		});

		expect(result.scanned).toBe(1);
		expect(result.promoted).toBe(1);
		expect(result.newFacts[0].fact).toMatch(/auth middleware/i);

		const facts = await loadFacts(workspace);
		expect(facts).toHaveLength(1);
		expect(facts[0].source).toBe("memory-consolidator");
	});

	it("skips sessions younger than the cutoff", async () => {
		const kv = new InMemoryKv();
		const baseDate = new Date("2026-05-21T00:00:00Z");
		const store = new SessionStore(kv, {
			getWorkspaceId: () => "ws2",
			now: () => baseDate,
		});

		const fresh = await store.create();
		await store.save(fresh.id, [{ role: "user", parts: [{ kind: "text", text: "hi" }] }]);

		const result = await consolidateOldSessions(store, {
			workspaceRoot: workspace,
			provider: fixedProvider(""),
			modelId: "any",
			daysOld: 30,
			now: () => baseDate,
			extract: async () => ["should be ignored"],
		});
		expect(result.scanned).toBe(0);
		expect(result.promoted).toBe(0);
	});

	it("dedupes against existing facts", async () => {
		const kv = new InMemoryKv();
		const baseDate = new Date("2026-05-21T00:00:00Z");
		const store = new SessionStore(kv, {
			getWorkspaceId: () => "ws3",
			now: () => baseDate,
		});

		// Pre-populate a fact that matches a lesson the extractor will return.
		await fs.mkdir(path.join(workspace, ".iom"), { recursive: true });
		await fs.writeFile(
			path.join(workspace, ".iom", "facts.json"),
			JSON.stringify([
				{
					id: "f1",
					fact: "Auth middleware lives in middleware/auth.ts",
					addedAt: "2025-01-01",
					source: "user",
				},
			]),
			"utf-8",
		);

		const meta = await store.create();
		await store.save(meta.id, [{ role: "user", parts: [{ kind: "text", text: "x" }] }]);
		await kv.update("iom.session-index.v2.ws3", {
			version: 2,
			sessions: [
				{
					id: meta.id,
					title: meta.title,
					createdAt: "2026-01-01T00:00:00Z",
					lastUpdatedAt: "2026-01-01T00:00:00Z",
					messageCount: 1,
				},
			],
		});

		const result = await consolidateOldSessions(store, {
			workspaceRoot: workspace,
			provider: fixedProvider(""),
			modelId: "any",
			daysOld: 30,
			now: () => baseDate,
			extract: async () => ["auth middleware lives in middleware/auth.ts"],
		});
		expect(result.promoted).toBe(0);
		expect(result.skipped).toBe(1);
	});
});
