// R4-E: PerfCollector unit tests.

import type { AgentEvent } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { PerfCollector } from "../src/perf-collector";

function toolCall(id: string, name: string): AgentEvent {
	return {
		type: "tool_call",
		agentId: "a1",
		call: { kind: "tool_call", id, name, args: {} },
	};
}

function toolResult(id: string, isError = false): AgentEvent {
	return {
		type: "tool_result",
		agentId: "a1",
		result: { kind: "tool_result", id, output: "ok", isError },
	};
}

function usage(input: number, output: number): AgentEvent {
	return { type: "usage", agentId: "a1", inputTokens: input, outputTokens: output };
}

describe("PerfCollector", () => {
	it("captures a single turn: timing, tool count, tokens, cost", () => {
		const p = new PerfCollector();
		// Use a known-rate model so cost math is deterministic.
		// claude-sonnet-4-6: $3 in / $15 out per 1M tokens.
		p.markTurnStart("sess", "msg1", 1_000, "claude-sonnet-4-6");
		p.recordEvent("sess", { type: "iteration", agentId: "a1", n: 1 }, 1_010);
		p.recordEvent("sess", toolCall("c1", "read_file"), 1_020);
		p.recordEvent("sess", toolResult("c1"), 1_120); // 100ms
		p.recordEvent("sess", usage(1_000_000, 0), 1_200); // $3
		p.recordEvent("sess", usage(0, 100_000), 1_250); // $1.5
		const summary = p.markTurnEnd("sess", 1_300);
		expect(summary).toBeDefined();
		expect(summary?.msgId).toBe("msg1");
		expect(summary?.durationMs).toBe(300);
		expect(summary?.toolCalls).toBe(1);
		expect(summary?.inputTokens).toBe(1_000_000);
		expect(summary?.outputTokens).toBe(100_000);
		expect(summary?.cost).toBeCloseTo(4.5, 5);
		expect(summary?.iterations).toBe(1);
	});

	it("rolls per-session buffer at MAX_TURNS_PER_SESSION (20)", () => {
		const p = new PerfCollector();
		for (let i = 0; i < 25; i++) {
			p.markTurnStart("s", `m${i}`, i * 1000);
			p.markTurnEnd("s", i * 1000 + 10);
		}
		const recent = p.getRecent("s");
		expect(recent).toHaveLength(20);
		// Newest first
		expect(recent[0].msgId).toBe("m24");
		expect(recent[19].msgId).toBe("m5");
	});

	it("getTurn looks up by msgId", () => {
		const p = new PerfCollector();
		p.markTurnStart("s", "abc", 0);
		p.markTurnEnd("s", 50);
		expect(p.getTurn("s", "abc")?.durationMs).toBe(50);
		expect(p.getTurn("s", "missing")).toBeUndefined();
	});

	it("heatmap aggregates p50, p95, and error rate across turns", () => {
		const p = new PerfCollector();
		// 10 invocations of `read_file`: durations 10..100, no errors.
		p.markTurnStart("s", "m", 0);
		for (let i = 0; i < 10; i++) {
			const id = `c${i}`;
			p.recordEvent("s", toolCall(id, "read_file"), 0);
			p.recordEvent("s", toolResult(id, false), (i + 1) * 10);
		}
		// 5 invocations of `exec` with 1 error.
		for (let i = 0; i < 5; i++) {
			const id = `e${i}`;
			p.recordEvent("s", toolCall(id, "exec"), 0);
			p.recordEvent("s", toolResult(id, i === 0), 500);
		}
		p.markTurnEnd("s", 1000);

		const heat = p.getHeatmap();
		const exec = heat.find((h) => h.tool === "exec");
		const read = heat.find((h) => h.tool === "read_file");
		expect(read?.count).toBe(10);
		expect(read?.p50Ms).toBe(55); // midpoint of 10..100 with linear interp
		expect(read?.p95Ms).toBeCloseTo(95.5, 1);
		expect(read?.errorRate).toBe(0);
		expect(exec?.count).toBe(5);
		expect(exec?.errorRate).toBeCloseTo(0.2, 5);
		// Sort: exec (500ms) before read_file (≤100ms).
		expect(heat[0].tool).toBe("exec");
	});

	it("heatmap window is capped (older entries drop off)", () => {
		const p = new PerfCollector();
		p.markTurnStart("s", "m", 0);
		for (let i = 0; i < 150; i++) {
			const id = `c${i}`;
			p.recordEvent("s", toolCall(id, "ping"), 0);
			p.recordEvent("s", toolResult(id), 1);
		}
		const heat = p.getHeatmap();
		expect(heat[0].tool).toBe("ping");
		expect(heat[0].count).toBe(100);
	});

	it("closes inflight tools as errors when a turn ends mid-call", () => {
		const p = new PerfCollector();
		p.markTurnStart("s", "m", 0);
		p.recordEvent("s", toolCall("c1", "slow_tool"), 100);
		// No matching tool_result before turn ends.
		p.markTurnEnd("s", 500);
		const heat = p.getHeatmap();
		const slow = heat.find((h) => h.tool === "slow_tool");
		expect(slow?.count).toBe(1);
		expect(slow?.errorRate).toBe(1);
		expect(slow?.p50Ms).toBe(400);
	});

	it("abandonTurn drops the in-progress turn", () => {
		const p = new PerfCollector();
		p.markTurnStart("s", "m1", 0);
		p.abandonTurn("s");
		expect(p.markTurnEnd("s", 10)).toBeUndefined();
		expect(p.getRecent("s")).toHaveLength(0);
	});

	it("ignores events when no turn is active", () => {
		const p = new PerfCollector();
		// Should not throw.
		p.recordEvent("s", usage(10, 10));
		p.recordEvent("s", toolCall("c", "noop"));
		expect(p.getRecent("s")).toHaveLength(0);
	});
});
