import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { runReview } from "../src/review";

function mockProvider(responseText: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			yield { type: "text_delta", text: responseText };
			yield { type: "message_end", stopReason: "end" };
		},
	};
}

describe("runReview", () => {
	it("returns 'all disabled' when every category is off", async () => {
		const result = await runReview({
			provider: mockProvider("[]"),
			modelId: "any",
			cfg: {
				categories: {
					style: "off",
					documentation: "off",
					codingStandards: "off",
					correctness: "off",
					security: "off",
					performance: "off",
					maintainability: "off",
					testing: "off",
					typeSafety: "off",
					dependencies: "off",
					architecture: "off",
					accessibility: "off",
					i18n: "off",
					observability: "off",
				},
			},
			files: [{ path: "x.ts", content: "x" }],
		});
		expect(result.findings).toHaveLength(0);
		expect(result.summary).toMatch(/disabled/i);
	});

	it("returns 'no files' message when files is empty", async () => {
		const result = await runReview({
			provider: mockProvider("[]"),
			modelId: "any",
			cfg: undefined,
			files: [],
		});
		expect(result.summary).toMatch(/no files/i);
	});

	it("parses a clean JSON-array response", async () => {
		const response = JSON.stringify([
			{
				path: "src/foo.ts",
				line: 42,
				category: "security",
				severity: "blocking",
				title: "Hardcoded API key",
				detail: "An API key is hardcoded on line 42.",
				suggestion: "Move it to an environment variable.",
			},
			{
				path: "src/foo.ts",
				line: 10,
				category: "style",
				severity: "advisory",
				title: "Inconsistent indentation",
				detail: "Mixed tabs and spaces.",
			},
		]);
		const result = await runReview({
			provider: mockProvider(response),
			modelId: "any",
			// User explicitly elevated security to blocking. Without this,
			// the default config'\''s "advisory" would override the model'\''s
			// "blocking" severity — that user-wins behavior is tested
			// separately below.
			cfg: { categories: { security: "blocking", style: "advisory" } },
			files: [{ path: "src/foo.ts", content: "..." }],
		});
		expect(result.findings).toHaveLength(2);
		expect(result.counts.blocking).toBe(1);
		expect(result.counts.advisory).toBe(1);
		expect(result.summary).toContain("security");
		expect(result.summary).toContain("Hardcoded API key");
	});

	it("strips ```json``` fence wrapping", async () => {
		const response =
			'```json\n[{"path":"x.ts","category":"style","severity":"advisory","title":"t","detail":""}]\n```';
		const result = await runReview({
			provider: mockProvider(response),
			modelId: "any",
			cfg: undefined,
			files: [{ path: "x.ts", content: "" }],
		});
		expect(result.findings).toHaveLength(1);
	});

	it("drops findings whose category is 'off' in config", async () => {
		const response = JSON.stringify([
			{ path: "x.ts", category: "i18n", severity: "advisory", title: "Hardcoded string", detail: "" },
			{ path: "x.ts", category: "security", severity: "blocking", title: "Real issue", detail: "" },
		]);
		const result = await runReview({
			provider: mockProvider(response),
			modelId: "any",
			cfg: { categories: { i18n: "off", security: "blocking" } },
			files: [{ path: "x.ts", content: "" }],
		});
		expect(result.findings).toHaveLength(1);
		expect(result.findings[0].category).toBe("security");
	});

	it("user-config severity overrides model-emitted severity", async () => {
		// Model says blocking; user config says advisory.
		const response = JSON.stringify([
			{ path: "x.ts", category: "style", severity: "blocking", title: "t", detail: "" },
		]);
		const result = await runReview({
			provider: mockProvider(response),
			modelId: "any",
			cfg: { categories: { style: "advisory" } },
			files: [{ path: "x.ts", content: "" }],
		});
		expect(result.findings[0].severity).toBe("advisory");
	});

	it("handles unparseable model output gracefully (empty findings)", async () => {
		const result = await runReview({
			provider: mockProvider("not json"),
			modelId: "any",
			cfg: undefined,
			files: [{ path: "x.ts", content: "" }],
		});
		expect(result.findings).toHaveLength(0);
	});

	it("surfaces provider errors in summary", async () => {
		const errorProvider: ProviderSpec = {
			id: "err",
			displayName: "err",
			async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
				yield { type: "error", message: "rate limit" };
				yield { type: "message_end", stopReason: "error" };
			},
		};
		const result = await runReview({
			provider: errorProvider,
			modelId: "any",
			cfg: undefined,
			files: [{ path: "x.ts", content: "" }],
		});
		expect(result.summary).toMatch(/rate limit|provider error/i);
	});

	it("clean review (no findings) gets a ✅ summary", async () => {
		const result = await runReview({
			provider: mockProvider("[]"),
			modelId: "any",
			cfg: undefined,
			files: [{ path: "x.ts", content: "" }],
		});
		expect(result.summary).toMatch(/clean/i);
	});

	it("default categories enable style/docs/correctness/security and disable a11y/i18n/observability", async () => {
		// Use the empty cfg (relies on defaults). Spam findings for every category.
		const all = [
			"style",
			"documentation",
			"codingStandards",
			"correctness",
			"security",
			"performance",
			"maintainability",
			"testing",
			"typeSafety",
			"dependencies",
			"architecture",
			"accessibility",
			"i18n",
			"observability",
		];
		const response = JSON.stringify(
			all.map((c) => ({
				path: "x.ts",
				category: c,
				severity: "advisory",
				title: `${c} finding`,
				detail: "",
			})),
		);
		const result = await runReview({
			provider: mockProvider(response),
			modelId: "any",
			cfg: undefined,
			files: [{ path: "x.ts", content: "" }],
		});
		const cats = result.findings.map((f) => f.category);
		expect(cats).toContain("style");
		expect(cats).toContain("documentation");
		expect(cats).toContain("security");
		expect(cats).toContain("correctness");
		expect(cats).not.toContain("accessibility");
		expect(cats).not.toContain("i18n");
		expect(cats).not.toContain("observability");
	});

	// 2026-05-27: regression — when a /review @workspace run was cancelled
	// mid-flight, the next run inherited the still-aborted signal because
	// runUserTurn didn't reset `currentAbort` before dispatching the slash
	// command. The user saw "0 findings, 125 skipped (cancelled)".
	// runReview itself should at least treat each batch independently: if
	// the signal is FRESH, every file gets a real call.
	it("processes all batches when the signal starts un-aborted", async () => {
		let callCount = 0;
		const provider: ProviderSpec = {
			id: "mock",
			displayName: "mock",
			async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
				callCount++;
				yield { type: "text_delta", text: "[]" };
				yield { type: "message_end", stopReason: "end" };
			},
		};
		// 30 files → 2 batches of 15.
		const files = Array.from({ length: 30 }, (_, i) => ({
			path: `f${i}.ts`,
			content: "",
		}));
		const result = await runReview({
			provider,
			modelId: "any",
			cfg: undefined,
			files,
			signal: new AbortController().signal,
		});
		expect(callCount).toBe(2);
		expect(result.skipped).toHaveLength(0);
	});

	it("marks remaining batches as cancelled when the signal aborts mid-run", async () => {
		const ac = new AbortController();
		ac.abort();
		const files = Array.from({ length: 30 }, (_, i) => ({
			path: `f${i}.ts`,
			content: "",
		}));
		const result = await runReview({
			provider: mockProvider("[]"),
			modelId: "any",
			cfg: undefined,
			files,
			signal: ac.signal,
		});
		// Every file goes into skipped with reason "cancelled".
		expect(result.skipped).toHaveLength(30);
		expect(result.skipped[0]?.reason).toBe("cancelled");
	});

	it("emits onBatchProgress once per batch", async () => {
		const calls: number[] = [];
		const files = Array.from({ length: 35 }, (_, i) => ({
			path: `f${i}.ts`,
			content: "",
		}));
		await runReview({
			provider: mockProvider("[]"),
			modelId: "any",
			cfg: undefined,
			files,
			onBatchProgress: (info) => {
				calls.push(info.batchIndex);
			},
		});
		// 35 files → ceil(35/15) = 3 batches.
		expect(calls).toEqual([0, 1, 2]);
	});
});
