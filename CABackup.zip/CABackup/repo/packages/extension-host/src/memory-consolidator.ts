// R6-A: Memory consolidation.
//
// Walks the workspace's `SessionStore` for sessions older than `daysOld` and
// asks the model to extract 1-3 "lessons learned" per session. New lessons
// are deduped (case-insensitive) against the existing `<workspace>/.iom/facts.json`
// and promoted via `addFact()`. Returns counters so the caller can surface a
// "Promoted N lessons from M sessions" message.

import type { ConversationMessage, ProviderSpec, SessionMeta } from "@iom/shared";
import { type Fact, addFact, loadFacts } from "./agent-facts";
import type { SessionStore } from "./session-store";

const LESSONS_SYSTEM_PROMPT = `You are a memory consolidator. Given a past conversation, extract 1-3 short, project-specific "lessons learned" that would help a future agent doing similar work.

Constraints:
- Each lesson is a single sentence (under 200 chars).
- Lessons must be STABLE, REUSABLE facts about the project — naming conventions, file locations, recurring bugs, build/test commands.
- Skip ephemeral details ("today the user wanted X").
- Skip generic programming advice ("write tests").
- If the conversation has no project-specific insight, return an empty list.

Respond ONLY with JSON wrapped in <lessons>...</lessons> tags, in this exact shape:

<lessons>
{"lessons": ["fact 1", "fact 2"]}
</lessons>

Emit nothing outside the tags.`;

export interface ConsolidateOptions {
	readonly daysOld?: number;
	/** Workspace root used for fact persistence. */
	readonly workspaceRoot: string;
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly signal?: AbortSignal;
	/** Caps the number of sessions processed per call (defaults to 20). */
	readonly maxSessions?: number;
	/** Override `Date.now()` (tests). */
	readonly now?: () => Date;
	/** Override the consolidator's per-session call (tests). */
	readonly extract?: (history: readonly ConversationMessage[]) => Promise<readonly string[]>;
}

export interface ConsolidateResult {
	readonly scanned: number;
	readonly promoted: number;
	readonly skipped: number;
	/** Newly persisted facts (id + text). Useful for surfacing in a follow-up message. */
	readonly newFacts: readonly Fact[];
}

const DEFAULT_DAYS_OLD = 30;
const DEFAULT_MAX_SESSIONS = 20;

export async function consolidateOldSessions(
	sessionStore: SessionStore,
	opts: ConsolidateOptions,
): Promise<ConsolidateResult> {
	const now = (opts.now ?? (() => new Date()))();
	const cutoff = new Date(now.getTime() - (opts.daysOld ?? DEFAULT_DAYS_OLD) * 24 * 60 * 60 * 1000);
	const list = await sessionStore.list();
	const candidates = list
		.filter((s: SessionMeta) => {
			const last = Date.parse(s.lastUpdatedAt);
			return Number.isFinite(last) && last < cutoff.getTime() && s.messageCount > 0;
		})
		.slice(0, opts.maxSessions ?? DEFAULT_MAX_SESSIONS);

	let promoted = 0;
	let skipped = 0;
	const newFacts: Fact[] = [];

	const extract = opts.extract ?? makeExtractFn(opts);

	for (const meta of candidates) {
		if (opts.signal?.aborted) break;
		let history: readonly ConversationMessage[];
		try {
			history = await sessionStore.load(meta.id);
		} catch {
			continue;
		}
		if (history.length === 0) continue;

		let lessons: readonly string[] = [];
		try {
			lessons = await extract(history);
		} catch {
			continue;
		}
		if (lessons.length === 0) continue;

		// Dedupe against the live facts file (re-read every iteration so we don't
		// promote the same lesson twice across sessions in the same call).
		const existing = await loadFacts(opts.workspaceRoot);
		const normalize = (s: string) => s.replace(/\s+/g, " ").trim().toLowerCase();
		const known = new Set(existing.map((f) => normalize(f.fact)));
		for (const lessonRaw of lessons.slice(0, 3)) {
			const lesson = lessonRaw.trim();
			if (!lesson) continue;
			if (lesson.length > 280) continue;
			const n = normalize(lesson);
			if (known.has(n)) {
				skipped++;
				continue;
			}
			known.add(n);
			const before = await loadFacts(opts.workspaceRoot);
			const beforeIds = new Set(before.map((f) => f.id));
			const after = await addFact(opts.workspaceRoot, {
				fact: lesson,
				source: "memory-consolidator",
			});
			const created = after.find((f) => !beforeIds.has(f.id));
			if (created) {
				promoted++;
				newFacts.push(created);
			} else {
				skipped++;
			}
		}
	}

	return {
		scanned: candidates.length,
		promoted,
		skipped,
		newFacts,
	};
}

function makeExtractFn(
	opts: Pick<ConsolidateOptions, "provider" | "modelId" | "signal">,
): (history: readonly ConversationMessage[]) => Promise<readonly string[]> {
	return async (history) => {
		const transcript = renderTranscript(history);
		const chunks: string[] = [];
		const stream = opts.provider.stream({
			messages: [
				{
					role: "user",
					parts: [{ kind: "text", text: `Conversation transcript:\n\n${transcript}` }],
				},
			],
			modelId: opts.modelId,
			systemPrompt: LESSONS_SYSTEM_PROMPT,
			temperature: 0.1,
			...(opts.signal ? { signal: opts.signal } : {}),
		});
		for await (const ev of stream) {
			if (ev.type === "text_delta") chunks.push(ev.text);
		}
		return parseLessons(chunks.join(""));
	};
}

/** Extract the `lessons` array from an LLM reply; tolerant of malformed JSON. */
export function parseLessons(raw: string): readonly string[] {
	const match = /<lessons>([\s\S]*?)<\/lessons>/i.exec(raw);
	if (!match) return [];
	try {
		const parsed = JSON.parse(match[1].trim()) as { lessons?: unknown };
		if (!Array.isArray(parsed.lessons)) return [];
		return (parsed.lessons as unknown[])
			.filter((s): s is string => typeof s === "string")
			.map((s) => s.trim())
			.filter((s) => s.length > 0);
	} catch {
		return [];
	}
}

const MAX_TRANSCRIPT_CHARS = 8000;
function renderTranscript(history: readonly ConversationMessage[]): string {
	const lines: string[] = [];
	for (const msg of history) {
		const text: string[] = [];
		for (const p of msg.parts) {
			if (p.kind === "text") text.push(p.text);
			else if (p.kind === "tool_call") text.push(`(tool ${p.name})`);
			else if (p.kind === "tool_result") text.push("(tool result)");
		}
		const body = text.join(" ").trim();
		if (!body) continue;
		lines.push(`${msg.role.toUpperCase()}: ${body}`);
	}
	const joined = lines.join("\n");
	return joined.length > MAX_TRANSCRIPT_CHARS
		? `${joined.slice(0, MAX_TRANSCRIPT_CHARS)}\n[... transcript truncated]`
		: joined;
}
