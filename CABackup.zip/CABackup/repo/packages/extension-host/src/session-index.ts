/**
 * R5-C: SessionIndex — semantic search over the message bodies of every past
 * session in this workspace. Powered by the same embedder used by the
 * codebase index, but persisted in its own SQLite database under
 * `<workspace>/.iom/conversations.sqlite` so the conversation index can be
 * rebuilt / wiped without touching the code index.
 *
 * The store is intentionally minimal — it does not try to chunk long
 * messages; each `UiMessage` becomes one row keyed by `(sessionId,
 * messageId)`. Rows for a session are wiped on each `indexSession(...)` so
 * edits / regenerates don't leave ghost rows behind.
 *
 * Search returns the top-k rows by cosine similarity against the query
 * embedding, with a short snippet of the original message body for UI
 * display.
 */
import * as fs from "node:fs";
import * as path from "node:path";
import { type Embedder, TfIdfEmbedder, cosineSimilarity, l2Normalize } from "@iom/codebase-index";
import type { ConversationMessage, UiMessage } from "@iom/shared";
import Database, { type Database as DatabaseT } from "better-sqlite3";

/** Hits returned by `SessionIndex.search`. */
export interface ConversationHit {
	readonly sessionId: string;
	readonly messageId: string;
	readonly role: string;
	readonly snippet: string;
	readonly score: number;
	readonly createdAt: string;
}

export interface SessionIndexOptions {
	readonly dbPath: string;
	readonly embedder?: Embedder;
}

/** Hard cap on the snippet stored per row — full bodies live in SessionStore. */
const SNIPPET_CAP = 800;
/** Minimum char length for a message to be worth embedding (skip "ok"-style). */
const MIN_INDEXABLE_CHARS = 3;
/** Default top-k when caller doesn't override. */
const DEFAULT_K = 10;

interface ConversationRow {
	readonly id: number;
	readonly sessionId: string;
	readonly messageId: string;
	readonly role: string;
	readonly snippet: string;
	readonly createdAt: string;
	readonly vector: Float32Array;
}

/**
 * Message shape accepted by the indexer. Mirrors `UiMessage` but keeps a
 * loose contract so callers can pass `ConversationMessage[]` after a quick
 * map (see `indexSessionFromHistory` for the common case).
 */
export interface IndexableMessage {
	readonly id: string;
	readonly role: string;
	readonly text: string;
	readonly createdAt?: string;
}

export class SessionIndex {
	private readonly db: DatabaseT;
	private readonly embedder: Embedder;
	private readonly dim: number;

	constructor(opts: SessionIndexOptions) {
		this.embedder = opts.embedder ?? new TfIdfEmbedder();
		this.dim = this.embedder.dim;
		if (opts.dbPath !== ":memory:") {
			const dir = path.dirname(opts.dbPath);
			try {
				fs.mkdirSync(dir, { recursive: true });
			} catch {
				/* surfaces from Database constructor below */
			}
		}
		this.db = new Database(opts.dbPath);
		this.db.pragma("journal_mode = WAL");
		this.db.pragma("synchronous = NORMAL");
		this.db.exec(`
			CREATE TABLE IF NOT EXISTS conversations (
				id          INTEGER PRIMARY KEY AUTOINCREMENT,
				session_id  TEXT NOT NULL,
				message_id  TEXT NOT NULL,
				role        TEXT NOT NULL,
				snippet     TEXT NOT NULL,
				created_at  TEXT NOT NULL,
				dim         INTEGER NOT NULL,
				vec         BLOB NOT NULL,
				UNIQUE(session_id, message_id)
			);
			CREATE INDEX IF NOT EXISTS conv_by_session ON conversations(session_id);
			CREATE TABLE IF NOT EXISTS conv_meta (
				key   TEXT PRIMARY KEY,
				value TEXT NOT NULL
			);
		`);
		// Dimension guard: like IndexStore, wipe the rows on a mismatch rather
		// than serve nonsense cosine scores.
		const existingDim = (
			this.db.prepare("SELECT value FROM conv_meta WHERE key = ?").get("dim") as
				| { value: string }
				| undefined
		)?.value;
		if (existingDim === undefined) {
			this.db
				.prepare("INSERT OR REPLACE INTO conv_meta (key, value) VALUES (?, ?)")
				.run("dim", String(this.dim));
		} else if (Number.parseInt(existingDim, 10) !== this.dim) {
			this.db.exec("DELETE FROM conversations;");
			this.db
				.prepare("INSERT OR REPLACE INTO conv_meta (key, value) VALUES (?, ?)")
				.run("dim", String(this.dim));
		}
	}

	close(): void {
		this.db.close();
	}

	/**
	 * Re-index a single session. All previous rows for the session are dropped
	 * and replaced with the supplied messages. Empty / trivially-short
	 * messages are skipped — they bring no semantic signal and just bloat the
	 * vector table.
	 */
	async indexSession(sessionId: string, messages: readonly IndexableMessage[]): Promise<number> {
		const indexable: IndexableMessage[] = [];
		for (const m of messages) {
			const text = (m.text ?? "").trim();
			if (text.length < MIN_INDEXABLE_CHARS) continue;
			indexable.push(m);
		}
		// Wipe inside the same transaction-shaped pattern so a partial failure
		// can't leave the session with stale partial rows.
		this.db.prepare("DELETE FROM conversations WHERE session_id = ?").run(sessionId);
		if (indexable.length === 0) return 0;
		const vectors = await this.embedder.embed(indexable.map((m) => m.text));
		const insert = this.db.prepare(
			"INSERT OR REPLACE INTO conversations (session_id, message_id, role, snippet, created_at, dim, vec) VALUES (?, ?, ?, ?, ?, ?, ?)",
		);
		const tx = this.db.transaction((rows: IndexableMessage[], vecs: readonly Float32Array[]) => {
			for (let i = 0; i < rows.length; i++) {
				const r = rows[i];
				const v = vecs[i];
				if (!v) continue;
				// Defensive: re-normalize in case the embedder didn't. cosine
				// later assumes unit-length.
				const normed = new Float32Array(v);
				l2Normalize(normed);
				const snippet = r.text.length > SNIPPET_CAP ? `${r.text.slice(0, SNIPPET_CAP)}…` : r.text;
				const createdAt = r.createdAt ?? new Date().toISOString();
				insert.run(
					sessionId,
					r.id,
					r.role,
					snippet,
					createdAt,
					this.dim,
					Buffer.from(normed.buffer, normed.byteOffset, normed.byteLength),
				);
			}
		});
		tx(indexable, vectors);
		return indexable.length;
	}

	/**
	 * Drop every row for `sessionId`. Called when the user deletes a session
	 * so search results don't keep pointing at a vanished id.
	 */
	dropSession(sessionId: string): void {
		this.db.prepare("DELETE FROM conversations WHERE session_id = ?").run(sessionId);
	}

	/**
	 * Wipe every row and re-index from scratch. Used when the user runs
	 * `/reindex-conversations` (future) or when the embedder dimension changes.
	 */
	async rebuildAll(
		sessions: readonly {
			readonly sessionId: string;
			readonly messages: readonly IndexableMessage[];
		}[],
	): Promise<number> {
		this.db.exec("DELETE FROM conversations;");
		let total = 0;
		for (const s of sessions) {
			total += await this.indexSession(s.sessionId, s.messages);
		}
		return total;
	}

	/**
	 * Top-k semantic search. Brute force over every stored vector — fine at
	 * the message scale (typical workspaces have <10k messages even after
	 * months of use). Optional `sessionId` filter scopes the search to a
	 * single conversation when the UI wants "find this in the current chat".
	 */
	async search(
		query: string,
		opts: { k?: number; sessionId?: string } = {},
	): Promise<readonly ConversationHit[]> {
		const trimmed = (query ?? "").trim();
		if (trimmed.length === 0) return [];
		const k = Math.max(1, Math.min(opts.k ?? DEFAULT_K, 100));
		const [queryVec] = await this.embedder.embed([trimmed]);
		if (!queryVec) return [];
		// Re-normalize the query vector for the same reason as storage rows.
		const qNorm = new Float32Array(queryVec);
		l2Normalize(qNorm);
		const rows = this.fetchRows(opts.sessionId);
		if (rows.length === 0) return [];
		const scored: ConversationHit[] = [];
		for (const r of rows) {
			const score = cosineSimilarity(qNorm, r.vector);
			scored.push({
				sessionId: r.sessionId,
				messageId: r.messageId,
				role: r.role,
				snippet: r.snippet,
				createdAt: r.createdAt,
				score,
			});
		}
		scored.sort((a, b) => b.score - a.score);
		return scored.slice(0, k);
	}

	/** Total number of indexed conversation rows. Useful for diagnostics. */
	stats(): { messages: number; sessions: number } {
		const m = this.db.prepare("SELECT COUNT(*) AS n FROM conversations").get() as { n: number };
		const s = this.db.prepare("SELECT COUNT(DISTINCT session_id) AS n FROM conversations").get() as {
			n: number;
		};
		return { messages: m.n, sessions: s.n };
	}

	private fetchRows(sessionId?: string): ConversationRow[] {
		const sql = sessionId
			? "SELECT id, session_id AS sessionId, message_id AS messageId, role, snippet, created_at AS createdAt, vec FROM conversations WHERE session_id = ?"
			: "SELECT id, session_id AS sessionId, message_id AS messageId, role, snippet, created_at AS createdAt, vec FROM conversations";
		const raw = sessionId
			? (this.db.prepare(sql).all(sessionId) as {
					id: number;
					sessionId: string;
					messageId: string;
					role: string;
					snippet: string;
					createdAt: string;
					vec: Buffer;
				}[])
			: (this.db.prepare(sql).all() as {
					id: number;
					sessionId: string;
					messageId: string;
					role: string;
					snippet: string;
					createdAt: string;
					vec: Buffer;
				}[]);
		return raw.map((r) => ({
			id: r.id,
			sessionId: r.sessionId,
			messageId: r.messageId,
			role: r.role,
			snippet: r.snippet,
			createdAt: r.createdAt,
			vector: blobToVector(r.vec, this.dim),
		}));
	}
}

/**
 * Convenience: convert an in-memory `ConversationMessage[]` slice (the shape
 * SessionStore persists) into the `IndexableMessage[]` shape `indexSession`
 * expects, using `userMessageIdForIndex`-style synthetic ids so the result
 * matches what the webview displays.
 */
export function historyToIndexable(history: readonly ConversationMessage[]): IndexableMessage[] {
	const out: IndexableMessage[] = [];
	for (let i = 0; i < history.length; i++) {
		const msg = history[i];
		if (msg.role !== "user" && msg.role !== "assistant") continue;
		const text = collectText(msg.parts);
		if (text.length === 0) continue;
		const id = msg.role === "user" ? `u_h${i}` : `a_h${i}`;
		out.push({ id, role: msg.role, text });
	}
	return out;
}

/** Convert a webview-shape `UiMessage[]` directly to indexable rows. */
export function uiMessagesToIndexable(messages: readonly UiMessage[]): IndexableMessage[] {
	const out: IndexableMessage[] = [];
	for (const m of messages) {
		if (m.role !== "user" && m.role !== "assistant") continue;
		if (!m.text || m.text.trim().length === 0) continue;
		out.push({ id: m.id, role: m.role, text: m.text });
	}
	return out;
}

function collectText(parts: readonly { kind: string; text?: string }[]): string {
	const chunks: string[] = [];
	for (const p of parts) if (p.kind === "text" && typeof p.text === "string") chunks.push(p.text);
	return chunks.join("");
}

function blobToVector(blob: Buffer, dim: number): Float32Array {
	const arr = new Float32Array(dim);
	const view = new DataView(blob.buffer, blob.byteOffset, blob.byteLength);
	const limit = Math.min(dim, Math.floor(blob.byteLength / 4));
	for (let i = 0; i < limit; i++) arr[i] = view.getFloat32(i * 4, true);
	return arr;
}
