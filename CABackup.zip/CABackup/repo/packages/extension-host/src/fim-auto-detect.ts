import { detectModelQuirks } from "@iom/shared";
import * as vscode from "vscode";
import type { KvStorage } from "./storage";

/**
 * 2026-06-03: one-time toast that surfaces when the user's CHAT model
 * is heavy / expensive for autocomplete (K2.6, Claude, GPT-4o, Gemini)
 * AND they haven't configured a separate `iom.inlineCompletion.model`.
 *
 * Cursor's pattern: small fast model for autocomplete + frontier model
 * for chat. iOmCode supports the same split via the
 * `iom.inlineCompletion.model` setting, but most users don't know
 * the setting exists. This module nudges them once with a click-to-
 * open-settings action, then never bothers them again (dismiss state
 * persists in KV).
 */

const KV_DISMISSED_KEY = "iom.toast.fimSuggestionShown";

export interface FimSuggestionResult {
	readonly shouldShow: boolean;
	readonly reason: string;
}

/**
 * Pure decision function. Exported for testability. Returns the
 * conditions for showing the suggestion plus a one-line reason
 * suitable for the Output channel.
 */
export function shouldSuggestFimModel(args: {
	activeChatModelId: string | undefined;
	completionModelOverride: string;
	alreadyDismissed: boolean;
}): FimSuggestionResult {
	if (args.alreadyDismissed) {
		return { shouldShow: false, reason: "already dismissed" };
	}
	if (args.completionModelOverride.trim().length > 0) {
		return { shouldShow: false, reason: "user has already configured iom.inlineCompletion.model" };
	}
	const modelId = args.activeChatModelId;
	if (!modelId) {
		return { shouldShow: false, reason: "no active chat model yet" };
	}
	const quirks = detectModelQuirks(modelId);
	// Only nudge when the chat model is NOT a good fit for autocomplete.
	// fimCapable === true means "this model is fine for autocomplete too";
	// nothing to suggest. fimCapable === false means "user should split."
	if (quirks.fimCapable) {
		return { shouldShow: false, reason: "chat model already FIM-capable" };
	}
	return {
		shouldShow: true,
		reason: `chat model '${modelId}' is heavy for keystroke autocomplete — suggest configuring a smaller FIM-capable model`,
	};
}

export interface ShowSuggestionDeps {
	readonly kv: KvStorage;
	readonly log?: vscode.OutputChannel;
	/** Override for tests; defaults to vscode.window.showInformationMessage. */
	readonly showInfo?: typeof vscode.window.showInformationMessage;
	/** Override for tests; defaults to vscode.commands.executeCommand. */
	readonly executeCommand?: typeof vscode.commands.executeCommand;
}

/**
 * Show the FIM suggestion toast. Idempotent: if the user previously
 * dismissed (or clicked an action), this no-ops. Safe to call on every
 * extension activation.
 */
export async function maybeShowFimSuggestion(
	activeChatModelId: string | undefined,
	deps: ShowSuggestionDeps,
): Promise<void> {
	const cfg = vscode.workspace.getConfiguration("iom.inlineCompletion");
	const override = cfg.get<string>("model", "").trim();
	const dismissed = deps.kv.get<boolean>(KV_DISMISSED_KEY) === true;
	const decision = shouldSuggestFimModel({
		activeChatModelId,
		completionModelOverride: override,
		alreadyDismissed: dismissed,
	});
	if (!decision.shouldShow) {
		deps.log?.appendLine(`[fim-suggest] skipping: ${decision.reason}`);
		return;
	}
	deps.log?.appendLine(`[fim-suggest] showing: ${decision.reason}`);
	const showInfo = deps.showInfo ?? vscode.window.showInformationMessage.bind(vscode.window);
	const exec = deps.executeCommand ?? vscode.commands.executeCommand.bind(vscode.commands);
	const OPEN = "Open setting";
	const DISMISS = "Don't show again";
	const choice = await showInfo(
		`OATI Code: your chat model (${activeChatModelId}) is heavy for inline autocomplete. Configure a smaller code model (Qwen-Coder, Codestral, Gemma) via \`iom.inlineCompletion.model\` for snappier ghost-text suggestions — chat will still use your current model.`,
		OPEN,
		DISMISS,
	);
	if (choice === OPEN) {
		await exec("workbench.action.openSettings", "iom.inlineCompletion.model");
	}
	// Mark as shown so we don't nag again, whether they opened settings,
	// dismissed explicitly, or closed the toast (choice === undefined).
	await deps.kv.update(KV_DISMISSED_KEY, true);
}

/**
 * Test-only: reset the dismissed flag so the toast can re-fire.
 * Useful when changing the chat model and wanting to re-check.
 */
export async function resetFimSuggestion(kv: KvStorage): Promise<void> {
	await kv.update(KV_DISMISSED_KEY, undefined);
}
