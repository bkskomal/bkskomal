import type { DiffPreview } from "@iom/shared";
import * as vscode from "vscode";

export const OATI_DIFF_SCHEME = "iom-diff";

export class OatiDiffContentProvider implements vscode.TextDocumentContentProvider {
	private readonly cache = new Map<string, string>();
	private readonly onDidChangeEmitter = new vscode.EventEmitter<vscode.Uri>();
	readonly onDidChange = this.onDidChangeEmitter.event;

	setContent(uri: vscode.Uri, content: string): void {
		this.cache.set(uri.toString(), content);
		this.onDidChangeEmitter.fire(uri);
	}

	provideTextDocumentContent(uri: vscode.Uri): string {
		return this.cache.get(uri.toString()) ?? "";
	}

	dispose(): void {
		this.cache.clear();
		this.onDidChangeEmitter.dispose();
	}
}

export async function openDiffEditor(
	provider: OatiDiffContentProvider,
	diff: DiffPreview,
): Promise<void> {
	const stamp = Date.now().toString(36);
	const safePath = encodeURIComponent(diff.path);
	const beforeUri = vscode.Uri.parse(`${OATI_DIFF_SCHEME}:Before/${safePath}?${stamp}`);
	const afterUri = vscode.Uri.parse(`${OATI_DIFF_SCHEME}:Proposed/${safePath}?${stamp}`);
	provider.setContent(beforeUri, diff.before);
	provider.setContent(afterUri, diff.after);
	await vscode.commands.executeCommand(
		"vscode.diff",
		beforeUri,
		afterUri,
		`OATI Code: ${diff.path} (proposed change)`,
		{ preview: true, viewColumn: vscode.ViewColumn.One },
	);
}
