// R3-D: conversation branching.
//
// `forkConversation` clones a session's history up to (and including) the
// canonical turn that produced `atMessageId`, then mints a new session whose
// metadata records the parent linkage so the UI can display
// "Forked from X at message Y".
//
// UiMessage ids fall into a handful of shapes (see `conversationToUiMessages`
// in `@iom/shared/ui-message`):
//
//   - "u_h<n>"  — user turn at canonical history index n
//   - "a_<k>"   — assistant turn (counter-based; we walk forward to find it)
//   - "tc_<k>"  — tool call card
//   - "tr_<k>"  — orphan tool-result card
//
// Anything else falls through to the "fork everything" branch (defensive — a
// fork from an unknown id still produces a usable session rather than
// silently dropping the user's intent).

import {
	type ConversationMessage,
	type SessionMeta,
	conversationToUiMessages,
	deriveSessionTitle,
} from "@iom/shared";
import type { SessionStore } from "./session-store";

export interface ForkOptions {
	readonly sessionId: string;
	readonly atMessageId: string;
}

export interface ForkResult {
	readonly newSessionId: string;
	readonly meta: SessionMeta;
	/** Number of canonical messages cloned into the new session. */
	readonly clonedCount: number;
}

/**
 * Clone `sessionId` up to (and including) the canonical turn that produced
 * `atMessageId`, then create + persist a new forked session and return its id.
 *
 * The caller is responsible for opening a chat panel pointed at
 * `result.newSessionId`. This module only knows about the store.
 */
export async function forkConversation(
	store: SessionStore,
	opts: ForkOptions,
): Promise<ForkResult> {
	const history = await store.load(opts.sessionId);
	const cutoff = resolveCutoffIndex(history, opts.atMessageId);
	// Clone everything up to (and including) the cutoff. If the cutoff resolved
	// to -1 (unknown id), default to the whole conversation so a fork from an
	// unrecognised message still produces a usable child.
	const cloned: ConversationMessage[] = cutoff < 0 ? [...history] : history.slice(0, cutoff + 1);

	const firstUserText = extractFirstUserText(cloned);
	const baseTitle = deriveSessionTitle(firstUserText);
	const title =
		baseTitle === "New chat" || baseTitle === "New Session" ? "Forked chat" : `Fork: ${baseTitle}`;

	const meta = await store.createFork({
		parentSessionId: opts.sessionId,
		forkedAtMessageId: opts.atMessageId,
		title,
	});
	if (cloned.length > 0) {
		await store.save(meta.id, cloned);
	}
	return { newSessionId: meta.id, meta, clonedCount: cloned.length };
}

/**
 * Map a UiMessage id back to its canonical history index (inclusive cutoff).
 * Returns -1 when the id can't be matched — callers fall back to "clone all".
 */
export function resolveCutoffIndex(
	history: readonly ConversationMessage[],
	uiMessageId: string,
): number {
	// User turns carry their history index directly.
	const userMatch = /^u_h(\d+)$/.exec(uiMessageId);
	if (userMatch) {
		const n = Number.parseInt(userMatch[1], 10);
		if (Number.isFinite(n) && n >= 0 && n < history.length) return n;
		return -1;
	}

	// For non-user ids, re-derive the UiMessage list and find the matching id;
	// when found, walk back from the corresponding spot in canonical history
	// until we land on a non-tool turn (so the fork includes the full
	// assistant turn whose tool card the user clicked from).
	const ui = conversationToUiMessages(history);
	const uiIdx = ui.findIndex((m) => m.id === uiMessageId);
	if (uiIdx < 0) return -1;
	// Count assistant/user turns up to and including uiIdx; the cutoff index
	// in canonical history is the (count-1)-th non-tool message.
	const role = ui[uiIdx].role;
	if (role === "system") return -1;
	// Walk canonical history forward, counting how many UiMessages each turn
	// produces, until we cover the click target.
	let consumed = 0;
	for (let h = 0; h < history.length; h++) {
		const produced = uiMessagesProducedBy(history[h]);
		if (uiIdx < consumed + produced) {
			return h;
		}
		consumed += produced;
	}
	return -1;
}

/**
 * How many UiMessages a single canonical ConversationMessage produces. Mirrors
 * the logic of `conversationToUiMessages` so we can map back from the flat UI
 * list to the canonical history.
 */
function uiMessagesProducedBy(msg: ConversationMessage): number {
	if (msg.role === "user") {
		const hasText = msg.parts.some((p) => p.kind === "text" && p.text.length > 0);
		const hasImages = msg.parts.some((p) => p.kind === "image");
		return hasText || hasImages ? 1 : 0;
	}
	if (msg.role === "assistant") {
		let n = 0;
		const hasText = msg.parts.some((p) => p.kind === "text" && p.text.length > 0);
		if (hasText) n++;
		for (const p of msg.parts) if (p.kind === "tool_call") n++;
		return n;
	}
	if (msg.role === "tool") {
		// Tool results normally merge into a prior tool_call card (0 new cards);
		// orphan results spawn 1 — best effort here, count as 0 to match the
		// "everything before this assistant turn" intent of a fork.
		return 0;
	}
	return 0;
}

function extractFirstUserText(history: readonly ConversationMessage[]): string | undefined {
	for (const m of history) {
		if (m.role !== "user") continue;
		for (const p of m.parts) {
			if (p.kind === "text" && p.text.trim().length > 0) return p.text;
		}
	}
	return undefined;
}
