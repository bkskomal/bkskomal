// 2026-05-28: QA planning subsystem. Two phases:
//
//   discoverProject(workspace)         → ProjectMap (modules, flows, entry points)
//   generateFunctionalCases(map)       → FunctionalTestCase[]
//   generateUnitCases(map, file?)      → UnitTestCase[]
//
// Both phases use the active provider. Output is structured JSON the model
// returns inline; we parse + validate before handing back. Failures bubble
// up to the orchestrator so the user gets a clear error in the chat.

import type { ProviderSpec } from "@iom/shared";
import type { FunctionalTestCase, UnitTestCase } from "./qa-excel";

export interface ProjectMap {
	readonly summary: string;
	readonly modules: readonly { readonly name: string; readonly description: string }[];
	readonly userFlows: readonly { readonly name: string; readonly steps: string }[];
	readonly integrations: readonly string[];
	readonly testFramework: string;
}

export interface DiscoverOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	/** Tagged files the model sees as the project context (README, package.json, top entry files). */
	readonly contextFiles: readonly { readonly path: string; readonly content: string }[];
	readonly signal?: AbortSignal;
}

export async function discoverProject(opts: DiscoverOptions): Promise<ProjectMap> {
	const fileBlocks = opts.contextFiles
		.map((f) => `### ${f.path}\n\n\`\`\`\n${truncate(f.content, 8000)}\n\`\`\``)
		.join("\n\n");
	const prompt = `You are a senior QA lead reviewing a software project. Produce a functional understanding that a manual + automated test team can use to plan coverage.

Return ONLY a JSON object — no prose, no markdown wrapper — with this shape:

\`\`\`json
{
  "summary": "2-3 sentences. What the project does, who uses it, primary value.",
  "modules": [
    { "name": "Module name (use the user-facing or directory name)", "description": "1 sentence on its responsibility" }
  ],
  "userFlows": [
    { "name": "Short flow name (e.g. 'User login')", "steps": "1 line summary of the happy-path steps" }
  ],
  "integrations": ["3rd-party service or external system name"],
  "testFramework": "vitest | jest | mocha | pytest | unittest | junit | unknown"
}
\`\`\`

Guidelines:
- 3-10 modules. Group related code.
- 3-12 userFlows. Cover the main features end-to-end.
- integrations: databases, message queues, payment providers, OAuth providers, external APIs the project calls.
- testFramework: detect from package.json / pyproject.toml / pom.xml hints. Use "unknown" if you can't tell.

## Project files

${fileBlocks}

## Output

Return ONLY the JSON object. No text before or after.`;

	const raw = await callProvider(opts.provider, opts.modelId, prompt, opts.signal);
	const parsed = parseJson(raw);
	if (!parsed || typeof parsed !== "object") {
		throw new Error("discover: model did not return JSON");
	}
	const obj = parsed as Record<string, unknown>;
	return {
		summary: typeof obj.summary === "string" ? obj.summary : "(no summary)",
		modules: parseArray(obj.modules, (m) => ({
			name: pickString(m, "name") ?? "",
			description: pickString(m, "description") ?? "",
		})).filter((m) => m.name.length > 0),
		userFlows: parseArray(obj.userFlows, (f) => ({
			name: pickString(f, "name") ?? "",
			steps: pickString(f, "steps") ?? "",
		})).filter((f) => f.name.length > 0),
		integrations: parseArray(obj.integrations, (i) => (typeof i === "string" ? i : "")).filter(
			(s) => s.length > 0,
		),
		testFramework: pickString(obj, "testFramework") ?? "unknown",
	};
}

export interface FunctionalPlanOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly projectMap: ProjectMap;
	readonly signal?: AbortSignal;
}

export async function generateFunctionalCases(
	opts: FunctionalPlanOptions,
): Promise<FunctionalTestCase[]> {
	const mapJson = JSON.stringify(opts.projectMap, null, 2);
	const prompt = `You are a senior QA lead writing a functional test plan from a project map. Produce concrete, executable test cases — the kind a manual tester or an automation engineer could run.

Return ONLY a JSON array — no prose, no markdown wrapper. Each test case must be:

\`\`\`json
{
  "tcId": "TC-001",
  "module": "Module name from the project map",
  "feature": "Specific feature within the module",
  "title": "Short scenario name (e.g. 'Login with valid credentials')",
  "preconditions": "What must be true before the test (1-3 lines)",
  "steps": "Numbered steps to execute. Use \\n between lines. Be PRECISE — include URLs, button labels, field names.",
  "expected": "What should happen. Be observable: 'see X', 'redirected to Y', 'token cookie set'.",
  "priority": "Critical | High | Medium | Low",
  "type": "Smoke | Functional | Regression | Integration | Edge"
}
\`\`\`

Rules:
- Generate 15–40 test cases. Quality > quantity. Skip trivial getters/setters.
- Cover EVERY user flow in the map. At minimum: 1 happy-path + 1 sad-path per flow.
- For each module, include 1 Smoke test (the most basic must-work scenario).
- Edge cases: empty inputs, malformed inputs, boundaries, concurrent users, session expiry.
- Integrations: include at least 1 test per integration in the map (DB failure, OAuth timeout, etc.).
- TC-IDs must be sequential: TC-001, TC-002, … TC-NNN. No gaps.

## Project map

${mapJson}

## Output

Return ONLY the JSON array. No text before or after.`;

	const raw = await callProvider(opts.provider, opts.modelId, prompt, opts.signal);
	const parsed = parseJson(raw);
	if (!Array.isArray(parsed)) {
		throw new Error("functional plan: model did not return a JSON array");
	}
	return parsed
		.map((item, idx) => normalizeFunctionalCase(item, idx))
		.filter((c): c is FunctionalTestCase => c !== undefined);
}

export interface UnitPlanOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly projectMap: ProjectMap;
	/** Source files the unit plan should cover. Use the model to pick functions worth testing. */
	readonly sourceFiles: readonly { readonly path: string; readonly content: string }[];
	readonly signal?: AbortSignal;
}

export async function generateUnitCases(opts: UnitPlanOptions): Promise<UnitTestCase[]> {
	const fileBlocks = opts.sourceFiles
		.map((f) => `### ${f.path}\n\n\`\`\`\n${truncate(f.content, 6000)}\n\`\`\``)
		.join("\n\n");
	const prompt = `You are a senior test engineer writing a UNIT test plan from the source files below. Test cases here target individual functions/methods — NOT user flows, NOT integration scenarios. Pure functional contracts.

Return ONLY a JSON array. Each test case must be:

\`\`\`json
{
  "tcId": "UT-001",
  "file": "src/auth/login.ts",
  "function": "validateCredentials",
  "title": "Short test name (e.g. 'returns false for empty password')",
  "preconditions": "Any setup needed (mocked deps, fixture data). Use 'none' if pure.",
  "testData": "The inputs. Use \\n between fields. Be concrete: 'username=alice', 'password=\\"\\"'.",
  "expected": "Observable return value or side effect: 'returns false', 'throws ValidationError', 'calls db.users.update once with…'.",
  "notes": "Optional. Anything tricky: 'requires Date.now() to be frozen', 'must run in isolation'."
}
\`\`\`

Rules:
- 1–6 cases per public function. More if it has complex branching.
- Cover happy path AND every error path the function can produce.
- Edge cases: empty / null / undefined / wrong-type / boundary inputs.
- Pure functions FIRST — they're cheapest to test and catch most bugs.
- Skip getters/setters, trivial accessors, framework boilerplate.
- TC-IDs sequential: UT-001, UT-002, … No gaps.

## Source files

${fileBlocks}

## Output

Return ONLY the JSON array. No text before or after.`;

	const raw = await callProvider(opts.provider, opts.modelId, prompt, opts.signal);
	const parsed = parseJson(raw);
	if (!Array.isArray(parsed)) {
		throw new Error("unit plan: model did not return a JSON array");
	}
	return parsed
		.map((item, idx) => normalizeUnitCase(item, idx))
		.filter((c): c is UnitTestCase => c !== undefined);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

async function callProvider(
	provider: ProviderSpec,
	modelId: string,
	prompt: string,
	signal: AbortSignal | undefined,
): Promise<string> {
	let raw = "";
	for await (const ev of provider.stream({
		messages: [{ role: "user", parts: [{ kind: "text", text: prompt }] }],
		modelId,
		temperature: 0.1,
		...(signal ? { signal } : {}),
	})) {
		if (ev.type === "text_delta") raw += ev.text;
		if (ev.type === "error") throw new Error(`provider: ${ev.message}`);
	}
	return raw;
}

function parseJson(raw: string): unknown {
	let t = raw.trim();
	// Strip ```json fences if present.
	const fence = t.match(/```(?:json)?\s*\n([\s\S]*?)\n```/);
	if (fence) t = fence[1].trim();
	try {
		return JSON.parse(t);
	} catch {
		return undefined;
	}
}

function pickString(obj: unknown, key: string): string | undefined {
	if (!obj || typeof obj !== "object") return undefined;
	const v = (obj as Record<string, unknown>)[key];
	return typeof v === "string" ? v : undefined;
}

function parseArray<T>(v: unknown, mapItem: (raw: unknown) => T): T[] {
	if (!Array.isArray(v)) return [];
	return v.map(mapItem);
}

function truncate(s: string, max: number): string {
	if (s.length <= max) return s;
	return `${s.slice(0, max)}\n\n…[truncated for prompt budget]`;
}

function normalizeFunctionalCase(item: unknown, idx: number): FunctionalTestCase | undefined {
	if (!item || typeof item !== "object") return undefined;
	const o = item as Record<string, unknown>;
	const title = pickString(o, "title");
	if (!title) return undefined;
	const allowedPriority = new Set(["Critical", "High", "Medium", "Low"]);
	const allowedType = new Set(["Smoke", "Functional", "Regression", "Integration", "Edge"]);
	const priority = pickString(o, "priority");
	const type = pickString(o, "type");
	const tcId = pickString(o, "tcId") ?? `TC-${String(idx + 1).padStart(3, "0")}`;
	return {
		tcId,
		module: pickString(o, "module") ?? "",
		feature: pickString(o, "feature") ?? "",
		title,
		preconditions: pickString(o, "preconditions") ?? "",
		steps: pickString(o, "steps") ?? "",
		expected: pickString(o, "expected") ?? "",
		priority:
			priority && allowedPriority.has(priority)
				? (priority as FunctionalTestCase["priority"])
				: "Medium",
		type: type && allowedType.has(type) ? (type as FunctionalTestCase["type"]) : "Functional",
	};
}

function normalizeUnitCase(item: unknown, idx: number): UnitTestCase | undefined {
	if (!item || typeof item !== "object") return undefined;
	const o = item as Record<string, unknown>;
	const title = pickString(o, "title");
	const file = pickString(o, "file");
	if (!title || !file) return undefined;
	const tcId = pickString(o, "tcId") ?? `UT-${String(idx + 1).padStart(3, "0")}`;
	const base: UnitTestCase = {
		tcId,
		file,
		function: pickString(o, "function") ?? "",
		title,
		preconditions: pickString(o, "preconditions") ?? "none",
		testData: pickString(o, "testData") ?? "",
		expected: pickString(o, "expected") ?? "",
	};
	const notes = pickString(o, "notes");
	return notes ? { ...base, notes } : base;
}

// ---------------------------------------------------------------------------
// Chat-side discover-map formatting
// ---------------------------------------------------------------------------

export function formatProjectMapMarkdown(map: ProjectMap): string {
	const lines: string[] = [];
	lines.push("## /qa discover");
	lines.push("");
	lines.push(map.summary);
	lines.push("");
	if (map.modules.length > 0) {
		lines.push("### Modules");
		for (const m of map.modules) {
			lines.push(`- **${m.name}** — ${m.description}`);
		}
		lines.push("");
	}
	if (map.userFlows.length > 0) {
		lines.push("### User flows");
		for (const f of map.userFlows) {
			lines.push(`- **${f.name}** — ${f.steps}`);
		}
		lines.push("");
	}
	if (map.integrations.length > 0) {
		lines.push("### Integrations");
		for (const i of map.integrations) {
			lines.push(`- ${i}`);
		}
		lines.push("");
	}
	lines.push(`_Test framework:_ \`${map.testFramework}\``);
	return lines.join("\n");
}
