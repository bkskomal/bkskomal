// 2026-05-26: Workspace change tracker — keeps a rolling snapshot of files
// that changed on disk OUTSIDE the agent (manual edits, `git pull`, external
// formatters, other editors) so the next agent turn can be told about them.
// Without this, the agent's mental model goes stale silently — e.g. the user
// pulls a branch, then asks "fix the failing test" and the agent reads back
// a stale view of the codebase and makes wrong assumptions.
//
// What we DO track:
//   - Document saves (vscode.workspace.onDidSaveTextDocument)
//   - File create/delete/rename (workspace.onDidCreateFiles / Delete / Rename)
//
// What we DON'T track here:
//   - In-memory edits to dirty buffers (too noisy — fires on every keystroke).
//   - Agent-written paths (caller-supplied via `excludeAgentWrites` — those
//     ARE intentional and already represented in the chat as tool cards).
//
// The agent consumes the snapshot at the start of each new user turn via
// `drainSinceLastTurn()`; the call returns whatever has accumulated and
// resets the buffer. If the buffer is empty, the agent gets no extra context
// (zero overhead in the common case where nothing changed).

import * as vscode from "vscode";

export type ExternalChangeKind = "created" | "modified" | "deleted";

export interface ExternalChange {
	readonly path: string;
	readonly kind: ExternalChangeKind;
	readonly at: number;
}

interface InternalRecord {
	kind: ExternalChangeKind;
	at: number;
}

const EXCLUDE_PREFIXES = [".git/", "node_modules/", ".iom/", "dist/", "build/", "out/"];
const MAX_TRACKED = 200;

function shouldIgnore(relPath: string): boolean {
	const norm = relPath.replace(/\\/g, "/");
	return EXCLUDE_PREFIXES.some((p) => norm.startsWith(p));
}

export class WorkspaceChangeTracker {
	private readonly buffer = new Map<string, InternalRecord>();
	private readonly disposables: vscode.Disposable[] = [];
	private agentWriteWindow = new Set<string>();

	start(): void {
		this.disposables.push(
			vscode.workspace.onDidSaveTextDocument((doc) => {
				const rel = vscode.workspace.asRelativePath(doc.uri);
				this.record(rel, "modified");
			}),
			vscode.workspace.onDidCreateFiles((ev) => {
				for (const uri of ev.files) {
					this.record(vscode.workspace.asRelativePath(uri), "created");
				}
			}),
			vscode.workspace.onDidDeleteFiles((ev) => {
				for (const uri of ev.files) {
					this.record(vscode.workspace.asRelativePath(uri), "deleted");
				}
			}),
			vscode.workspace.onDidRenameFiles((ev) => {
				for (const f of ev.files) {
					this.record(vscode.workspace.asRelativePath(f.oldUri), "deleted");
					this.record(vscode.workspace.asRelativePath(f.newUri), "created");
				}
			}),
		);
	}

	stop(): void {
		for (const d of this.disposables) d.dispose();
		this.disposables.length = 0;
	}

	/**
	 * Caller (chat-panel) announces the set of paths the agent itself wrote
	 * during the just-completed turn so subsequent saves of those paths are
	 * not flagged as "external" changes. Window is reset on each turn.
	 */
	markAgentWrites(paths: readonly string[]): void {
		this.agentWriteWindow = new Set(paths.map((p) => p.replace(/\\/g, "/")));
	}

	private record(relPath: string, kind: ExternalChangeKind): void {
		if (shouldIgnore(relPath)) return;
		const norm = relPath.replace(/\\/g, "/");
		// If this path was just written by the agent, suppress it — the
		// agent already knows. The first external save AFTER the agent's
		// turn is the one that matters, so we don't permanently exclude.
		if (this.agentWriteWindow.has(norm)) return;
		// Coalesce: most recent record wins for the same path.
		this.buffer.set(norm, { kind, at: Date.now() });
		// Bound the buffer so a runaway watcher doesn't blow memory.
		if (this.buffer.size > MAX_TRACKED) {
			const oldest = this.buffer.keys().next();
			if (!oldest.done) this.buffer.delete(oldest.value);
		}
	}

	/**
	 * Returns the current buffer and clears it. Idempotent on an empty buffer.
	 * Callers should drain right before a new turn dispatches.
	 */
	drainSinceLastTurn(): readonly ExternalChange[] {
		if (this.buffer.size === 0) return [];
		const out: ExternalChange[] = [];
		for (const [path, rec] of this.buffer) {
			out.push({ path, kind: rec.kind, at: rec.at });
		}
		this.buffer.clear();
		return out;
	}

	/** Snapshot WITHOUT clearing — useful for diagnostics / status views. */
	peek(): readonly ExternalChange[] {
		return [...this.buffer.entries()].map(([path, rec]) => ({
			path,
			kind: rec.kind,
			at: rec.at,
		}));
	}
}

/**
 * Render a change list as a compact system note that gets prepended to the
 * next user turn. Caller is free to substitute their own formatter; this is
 * the default. Returns an empty string when the list is empty so the caller
 * can just `if (note) prepend(note)` without a length check.
 */
export function formatChangesAsSystemNote(changes: readonly ExternalChange[]): string {
	if (changes.length === 0) return "";
	const grouped = { created: [] as string[], modified: [] as string[], deleted: [] as string[] };
	for (const c of changes) grouped[c.kind].push(c.path);
	const lines: string[] = [
		"[Workspace heads-up] Files changed on disk OUTSIDE the agent since the previous turn ended. Your prior view of these files may be stale — re-read before assuming.",
	];
	if (grouped.modified.length > 0) {
		lines.push(
			`  Modified: ${grouped.modified.slice(0, 12).join(", ")}${grouped.modified.length > 12 ? ` (+${grouped.modified.length - 12} more)` : ""}`,
		);
	}
	if (grouped.created.length > 0) {
		lines.push(
			`  Created:  ${grouped.created.slice(0, 12).join(", ")}${grouped.created.length > 12 ? ` (+${grouped.created.length - 12} more)` : ""}`,
		);
	}
	if (grouped.deleted.length > 0) {
		lines.push(
			`  Deleted:  ${grouped.deleted.slice(0, 12).join(", ")}${grouped.deleted.length > 12 ? ` (+${grouped.deleted.length - 12} more)` : ""}`,
		);
	}
	return lines.join("\n");
}
