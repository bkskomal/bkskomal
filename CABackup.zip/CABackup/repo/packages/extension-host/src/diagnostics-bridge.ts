// R4-B: diagnostics bridge — wraps VS Code's workspace-wide LSP diagnostic
// stream so the agent (via `ctx.diagnostics`) can read a snapshot or subscribe
// to changes. Coordinates are 1-based on both axes on the way out (matching
// the rest of our index types); VS Code's `vscode.Range` is 0-based, so we
// add one on the boundary.
import * as path from "node:path";
import type { DiagnosticEntry, DiagnosticsProvider } from "@iom/shared";
import * as vscode from "vscode";

type Severity = DiagnosticEntry["severity"];

function severityFromVscode(s: vscode.DiagnosticSeverity): Severity {
	switch (s) {
		case vscode.DiagnosticSeverity.Error:
			return "error";
		case vscode.DiagnosticSeverity.Warning:
			return "warning";
		case vscode.DiagnosticSeverity.Information:
			return "info";
		default:
			return "hint";
	}
}

function relativize(absPath: string, root: string | undefined): string {
	if (!root) return absPath;
	const rel = path.relative(root, absPath);
	if (rel.startsWith("..") || path.isAbsolute(rel)) return absPath;
	return rel.replace(/\\/g, "/");
}

function resolveUri(p: string): vscode.Uri {
	if (path.isAbsolute(p)) return vscode.Uri.file(p);
	const root = vscode.workspace.workspaceFolders?.[0]?.uri;
	if (!root) throw new Error("No workspace folder open");
	return vscode.Uri.joinPath(root, p);
}

function entryFromDiagnostic(
	uri: vscode.Uri,
	d: vscode.Diagnostic,
	root: string | undefined,
): DiagnosticEntry {
	const codeStr =
		d.code === undefined || d.code === null
			? undefined
			: typeof d.code === "object" && "value" in d.code
				? String(d.code.value)
				: String(d.code);
	const entry: DiagnosticEntry = {
		path: relativize(uri.fsPath, root),
		line: d.range.start.line + 1,
		column: d.range.start.character + 1,
		endLine: d.range.end.line + 1,
		endColumn: d.range.end.character + 1,
		severity: severityFromVscode(d.severity),
		message: d.message,
		...(d.source ? { source: d.source } : {}),
		...(codeStr ? { code: codeStr } : {}),
	};
	return entry;
}

export function createDiagnosticsProvider(): DiagnosticsProvider {
	return {
		async all(opts) {
			const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
			const severityFilter = opts?.severity ? new Set(opts.severity) : undefined;
			const result: DiagnosticEntry[] = [];
			if (opts?.path) {
				const uri = resolveUri(opts.path);
				const diags = vscode.languages.getDiagnostics(uri);
				for (const d of diags) {
					const entry = entryFromDiagnostic(uri, d, root);
					if (severityFilter && !severityFilter.has(entry.severity)) continue;
					result.push(entry);
				}
				return result;
			}
			const all = vscode.languages.getDiagnostics();
			for (const [uri, diags] of all) {
				for (const d of diags) {
					const entry = entryFromDiagnostic(uri, d, root);
					if (severityFilter && !severityFilter.has(entry.severity)) continue;
					result.push(entry);
				}
			}
			return result;
		},
		onChange(listener) {
			const sub = vscode.languages.onDidChangeDiagnostics((ev) => {
				const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
				const paths = ev.uris.map((u) => relativize(u.fsPath, root));
				try {
					listener(paths);
				} catch {
					// listeners must not break the bridge — swallow.
				}
			});
			return () => sub.dispose();
		},
	};
}

/**
 * Tally errors and warnings across the entire workspace. Used by the
 * extension-level diagnostics-pill broadcaster so it doesn't have to allocate
 * a full DiagnosticEntry[] just to count.
 */
export function tallyDiagnostics(): { errors: number; warnings: number } {
	let errors = 0;
	let warnings = 0;
	for (const [, diags] of vscode.languages.getDiagnostics()) {
		for (const d of diags) {
			if (d.severity === vscode.DiagnosticSeverity.Error) errors++;
			else if (d.severity === vscode.DiagnosticSeverity.Warning) warnings++;
		}
	}
	return { errors, warnings };
}
