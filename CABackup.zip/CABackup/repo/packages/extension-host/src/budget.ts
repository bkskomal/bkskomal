import { promises as fs } from "node:fs";
import * as path from "node:path";
import { type ModelBudget, estimateCost } from "@iom/shared";

/**
 * User-configurable budget thresholds. All values are USD. Any field can be
 * omitted to disable that particular guardrail.
 */
export interface BudgetConfig {
	/**
	 * 2026-06-06: master toggle. When `false`, every cap is bypassed —
	 * `checkDispatch` always returns "ok" and `recordUsage` still tallies
	 * spend for the cost-display chip but never fires soft/hard signals.
	 * Mirrors the field on `@iom/shared`'s `BudgetConfig` so the two
	 * stay shape-compatible.
	 */
	readonly enabled?: boolean;
	/** Soft alert threshold — fires once per session when crossed. Default $5. */
	readonly perSessionAlertUsd?: number;
	/**
	 * Hard cap per session. When set and crossed, the budget controller
	 * refuses further dispatches with a blocking error. Default: unset
	 * (soft-only).
	 */
	readonly perSessionHardCapUsd?: number;
	/**
	 * Org-wide daily cap, tracked in `.iom/budget-day-YYYYMMDD.json`. Default
	 * $50. The day boundary is UTC midnight (so it rolls over consistently
	 * across geographically distributed teams sharing a repo).
	 */
	readonly perDayHardCapUsd?: number;
}

export const DEFAULT_BUDGET: Required<BudgetConfig> = {
	enabled: true,
	perSessionAlertUsd: 5,
	perSessionHardCapUsd: Number.POSITIVE_INFINITY,
	perDayHardCapUsd: 50,
};

/** A function that returns the current time. Injected so tests can mock it. */
export type ClockFn = () => Date;

/** Result of a `checkDispatch` call. */
export type DispatchVerdict =
	| { readonly kind: "ok" }
	| { readonly kind: "blocked"; readonly reason: string };

/** Result of incrementing usage — surfaces alert/cap transitions. */
export interface RecordUsageResult {
	readonly sessionCostUsd: number;
	readonly dayCostUsd: number;
	readonly softAlertFired: boolean;
	readonly hardCapReached: boolean;
	readonly costThisCall: number;
}

interface DayCounter {
	readonly day: string;
	totalUsd: number;
}

/**
 * Tracks per-session and per-day spend and enforces soft alerts + hard caps.
 *
 * - Per-session counters live in memory only (one instance per chat panel).
 * - Per-day counters are persisted to `.iom/budget-day-YYYYMMDD.json` so all
 *   panels sharing a workspace share a single org-wide pot. The file is read
 *   on demand and rewritten after each increment; concurrent writers may
 *   under-count by a small fraction of a cent, which is acceptable for a
 *   guardrail.
 * - Day rollover happens at UTC midnight: `2026-05-20T23:59:59Z` lives in
 *   `2026-05-20`, `2026-05-21T00:00:00Z` lives in `2026-05-21`. The current
 *   day is recomputed every check, so a long-running panel naturally crosses
 *   the boundary without needing a timer.
 */
export class Budget {
	private readonly cfg: Required<BudgetConfig>;
	private readonly workspaceRoot: string;
	private readonly clock: ClockFn;
	private sessionCostUsd = 0;
	private softAlertFired = false;
	private dayCache: DayCounter | undefined;

	constructor(workspaceRoot: string, cfg?: BudgetConfig, clock: ClockFn = () => new Date()) {
		this.workspaceRoot = workspaceRoot;
		this.clock = clock;
		// 2026-06-06: treat a configured cap of `0` as "unlimited" — that's
		// the sentinel the Budget Guardrails settings UI uses for "no cap".
		// Without this, a value of 0 would compare `>= 0` and block every
		// single dispatch. POSITIVE_INFINITY can't survive JSON round-trips
		// so we can't ask the UI to send it directly.
		const orInfinity = (n: number | undefined, fallback: number): number =>
			n === undefined ? fallback : n === 0 ? Number.POSITIVE_INFINITY : n;
		this.cfg = {
			enabled: cfg?.enabled ?? DEFAULT_BUDGET.enabled,
			perSessionAlertUsd: cfg?.perSessionAlertUsd ?? DEFAULT_BUDGET.perSessionAlertUsd,
			perSessionHardCapUsd: orInfinity(cfg?.perSessionHardCapUsd, DEFAULT_BUDGET.perSessionHardCapUsd),
			perDayHardCapUsd: orInfinity(cfg?.perDayHardCapUsd, DEFAULT_BUDGET.perDayHardCapUsd),
		};
	}

	getSessionCost(): number {
		return this.sessionCostUsd;
	}

	getConfig(): Required<BudgetConfig> {
		return this.cfg;
	}

	hasSoftAlertFired(): boolean {
		return this.softAlertFired;
	}

	/**
	 * Compute a cost from a usage event and tally it. Returns transition flags
	 * so the chat-panel can post a banner the first time we cross the alert
	 * threshold (without re-firing on every subsequent usage event).
	 */
	async recordUsage(
		modelId: string,
		inputTokens: number,
		outputTokens: number,
	): Promise<RecordUsageResult> {
		const est = estimateCost(modelId, inputTokens, outputTokens);
		const costThisCall = est?.totalUsd ?? 0;
		this.sessionCostUsd += costThisCall;

		const day = await this.loadDay();
		day.totalUsd += costThisCall;
		await this.saveDay(day);

		// 2026-06-06: master toggle. When disabled, we still tally spend
		// (so cost display + audit log keep working) but skip every alert
		// / cap signal. Callers see softAlertFired=false / hardCapReached=
		// false and never gate dispatch on this instance.
		const softAlertJustCrossed =
			this.cfg.enabled && !this.softAlertFired && this.sessionCostUsd >= this.cfg.perSessionAlertUsd;
		if (softAlertJustCrossed) this.softAlertFired = true;

		const hardCapReached =
			this.cfg.enabled &&
			(this.sessionCostUsd >= this.cfg.perSessionHardCapUsd ||
				day.totalUsd >= this.cfg.perDayHardCapUsd);

		return {
			sessionCostUsd: this.sessionCostUsd,
			dayCostUsd: day.totalUsd,
			softAlertFired: softAlertJustCrossed,
			hardCapReached,
			costThisCall,
		};
	}

	/**
	 * Gate a new `user_message` dispatch. Returns "blocked" when either the
	 * per-session hard cap OR the per-day cap is already exhausted.
	 */
	async checkDispatch(): Promise<DispatchVerdict> {
		// 2026-06-06: master toggle. When disabled, dispatch is always
		// allowed regardless of the configured caps.
		if (!this.cfg.enabled) return { kind: "ok" };
		if (this.sessionCostUsd >= this.cfg.perSessionHardCapUsd) {
			return {
				kind: "blocked",
				reason: `Session cost ${fmt(this.sessionCostUsd)} has reached the per-session hard cap of ${fmt(this.cfg.perSessionHardCapUsd)}. Start a new chat or raise the budget.`,
			};
		}
		const day = await this.loadDay();
		if (day.totalUsd >= this.cfg.perDayHardCapUsd) {
			return {
				kind: "blocked",
				reason: `Daily org budget ${fmt(day.totalUsd)} has reached the cap of ${fmt(this.cfg.perDayHardCapUsd)}. Try again after midnight UTC.`,
			};
		}
		return { kind: "ok" };
	}

	/** Manually overwrite the day counter — exposed for test setup. */
	async _setDayCost(usd: number): Promise<void> {
		const day = await this.loadDay();
		day.totalUsd = usd;
		await this.saveDay(day);
		this.dayCache = day;
	}

	private async loadDay(): Promise<DayCounter> {
		const today = currentDayString(this.clock());
		// Cached for the right day? Use it.
		if (this.dayCache && this.dayCache.day === today) return this.dayCache;
		// Day rolled over (or first read) — refresh from disk.
		const filePath = this.dayFilePath(today);
		let totalUsd = 0;
		try {
			const raw = await fs.readFile(filePath, "utf-8");
			const parsed = JSON.parse(raw) as { day?: string; totalUsd?: number };
			if (parsed.day === today && typeof parsed.totalUsd === "number") {
				totalUsd = parsed.totalUsd;
			}
		} catch {
			// File missing / corrupt / new day — start at zero.
		}
		this.dayCache = { day: today, totalUsd };
		return this.dayCache;
	}

	private async saveDay(day: DayCounter): Promise<void> {
		const filePath = this.dayFilePath(day.day);
		try {
			await fs.mkdir(path.dirname(filePath), { recursive: true });
			await fs.writeFile(
				filePath,
				JSON.stringify({ day: day.day, totalUsd: day.totalUsd }, null, 2),
				"utf-8",
			);
		} catch {
			// Budget tracking is advisory; don't break the chat on a write failure.
		}
	}

	private dayFilePath(day: string): string {
		return path.join(this.workspaceRoot, ".iom", `budget-day-${day}.json`);
	}
}

/** YYYYMMDD UTC for `d`. */
export function currentDayString(d: Date): string {
	const y = d.getUTCFullYear();
	const m = String(d.getUTCMonth() + 1).padStart(2, "0");
	const day = String(d.getUTCDate()).padStart(2, "0");
	return `${y}${m}${day}`;
}

function fmt(v: number): string {
	if (!Number.isFinite(v)) return "∞";
	if (v < 0.01) return `$${v.toFixed(4)}`;
	if (v < 1) return `$${v.toFixed(3)}`;
	return `$${v.toFixed(2)}`;
}

// R5-E: per-model budget — APPENDED below.
//
// `modelBudgets` lets the user cap spend on a specific (provider, model) pair
// in addition to the global session/day caps. Daily and month-to-date counters
// are tracked in `.iom/budget-model-<providerId>-<modelKey>-day-YYYYMMDD.json`
// and `.iom/budget-model-<providerId>-<modelKey>-month-YYYYMM.json` so each
// pair has its own pot. `modelKey` is `*` when the rule omits `modelId`.

export interface PerModelVerdict {
	readonly allowed: boolean;
	readonly reason?: string;
}

interface MonthCounter {
	readonly month: string;
	totalUsd: number;
}

/** Append-only helper that knows how to find the most-specific matching rule. */
export function selectModelBudget(
	rules: readonly ModelBudget[] | undefined,
	providerId: string,
	modelId: string | undefined,
): ModelBudget | undefined {
	if (!rules || rules.length === 0) return undefined;
	const provMatches = rules.filter((r) => r.providerId === providerId);
	if (provMatches.length === 0) return undefined;
	// Prefer rules with a model substring match; among those the longest match wins.
	if (modelId) {
		const matched = provMatches
			.filter((r) => typeof r.modelId === "string" && r.modelId.length > 0)
			.filter((r) => modelId.includes(r.modelId as string))
			.sort((a, b) => (b.modelId as string).length - (a.modelId as string).length);
		if (matched.length > 0) return matched[0];
	}
	// Fallback to the provider-wide rule (modelId omitted).
	return provMatches.find((r) => !r.modelId);
}

/** YYYYMM UTC for `d`. */
export function currentMonthString(d: Date): string {
	const y = d.getUTCFullYear();
	const m = String(d.getUTCMonth() + 1).padStart(2, "0");
	return `${y}${m}`;
}

function modelKey(modelId: string | undefined): string {
	if (!modelId) return "_all";
	return modelId.replace(/[^A-Za-z0-9_.-]/g, "_");
}

/**
 * R5-E: tracks per-(provider, model) spend on disk under `.iom/`.
 *
 * Lives next to the per-day `Budget` controller above. We keep it as a
 * sibling class so the existing `Budget` API (and all its tests) stay
 * unchanged. The chat-panel constructs one of each and consults both before
 * dispatch.
 */
export class PerModelBudget {
	private readonly workspaceRoot: string;
	private readonly clock: ClockFn;
	private readonly dayCache = new Map<string, DayCounter>();
	private readonly monthCache = new Map<string, MonthCounter>();

	constructor(workspaceRoot: string, clock: ClockFn = () => new Date()) {
		this.workspaceRoot = workspaceRoot;
		this.clock = clock;
	}

	/**
	 * Tally a usage event against the (provider, model) pair. Updates both the
	 * model-specific bucket AND the provider-wide bucket (so a provider-only
	 * rule can sum spend across every model). Cost is computed via
	 * `estimateCost`; models with no known rate contribute $0 (mirrors
	 * `Budget.recordUsage`).
	 */
	async recordUsage(
		providerId: string,
		modelId: string,
		inputTokens: number,
		outputTokens: number,
	): Promise<{ dayUsd: number; monthUsd: number; costThisCall: number }> {
		const est = estimateCost(modelId, inputTokens, outputTokens);
		const cost = est?.totalUsd ?? 0;
		const day = await this.loadDay(providerId, modelId);
		const month = await this.loadMonth(providerId, modelId);
		day.totalUsd += cost;
		month.totalUsd += cost;
		await this.saveDay(providerId, modelId, day);
		await this.saveMonth(providerId, modelId, month);
		// Mirror into the provider-wide pot so provider-only rules see the spend.
		const provDay = await this.loadDay(providerId, undefined);
		const provMonth = await this.loadMonth(providerId, undefined);
		provDay.totalUsd += cost;
		provMonth.totalUsd += cost;
		await this.saveDay(providerId, undefined, provDay);
		await this.saveMonth(providerId, undefined, provMonth);
		return { dayUsd: day.totalUsd, monthUsd: month.totalUsd, costThisCall: cost };
	}

	/**
	 * Verdict for dispatching a turn under `(providerId, modelId)`. Loads the
	 * most-specific matching rule from `rules`, compares against today's spend
	 * and the month-to-date spend, and returns `{ allowed: false, reason }`
	 * when either cap is already exhausted. Daily limit is checked first so
	 * the user sees the most immediate problem.
	 *
	 * The bucket inspected depends on the rule shape: model-specific rules
	 * read the (provider, model) bucket; provider-only rules read the
	 * provider-wide bucket which aggregates spend across every model.
	 */
	async checkPerModelBudget(
		rules: readonly ModelBudget[] | undefined,
		providerId: string,
		modelId: string | undefined,
	): Promise<PerModelVerdict> {
		const rule = selectModelBudget(rules, providerId, modelId);
		if (!rule) return { allowed: true };
		// Provider-only rules check the provider-wide pot (undefined modelId);
		// model-specific rules check their own bucket.
		const bucketModelId = rule.modelId ? modelId : undefined;
		const day = await this.loadDay(providerId, bucketModelId);
		if (typeof rule.dailyUsd === "number" && day.totalUsd >= rule.dailyUsd) {
			return {
				allowed: false,
				reason: `Per-model daily cap reached for ${providerId}${
					rule.modelId ? `:${rule.modelId}` : ""
				}: spent ${fmt(day.totalUsd)} of ${fmt(rule.dailyUsd)}.`,
			};
		}
		const month = await this.loadMonth(providerId, bucketModelId);
		if (typeof rule.monthlyUsd === "number" && month.totalUsd >= rule.monthlyUsd) {
			return {
				allowed: false,
				reason: `Per-model monthly cap reached for ${providerId}${
					rule.modelId ? `:${rule.modelId}` : ""
				}: spent ${fmt(month.totalUsd)} of ${fmt(rule.monthlyUsd)}.`,
			};
		}
		return { allowed: true };
	}

	/** Test helper: overwrite today's spend for a (provider, model) pair. */
	async _setDayCost(providerId: string, modelId: string | undefined, usd: number): Promise<void> {
		const day = await this.loadDay(providerId, modelId);
		day.totalUsd = usd;
		await this.saveDay(providerId, modelId, day);
	}

	/** Test helper: overwrite month-to-date spend for a (provider, model) pair. */
	async _setMonthCost(providerId: string, modelId: string | undefined, usd: number): Promise<void> {
		const month = await this.loadMonth(providerId, modelId);
		month.totalUsd = usd;
		await this.saveMonth(providerId, modelId, month);
	}

	private dayKey(providerId: string, modelId: string | undefined): string {
		return `${providerId}::${modelKey(modelId)}::${currentDayString(this.clock())}`;
	}
	private monthCacheKey(providerId: string, modelId: string | undefined): string {
		return `${providerId}::${modelKey(modelId)}::${currentMonthString(this.clock())}`;
	}

	private dayFile(providerId: string, modelId: string | undefined): string {
		const today = currentDayString(this.clock());
		return path.join(
			this.workspaceRoot,
			".iom",
			`budget-model-${providerId}-${modelKey(modelId)}-day-${today}.json`,
		);
	}
	private monthFile(providerId: string, modelId: string | undefined): string {
		const m = currentMonthString(this.clock());
		return path.join(
			this.workspaceRoot,
			".iom",
			`budget-model-${providerId}-${modelKey(modelId)}-month-${m}.json`,
		);
	}

	private async loadDay(providerId: string, modelId: string | undefined): Promise<DayCounter> {
		const key = this.dayKey(providerId, modelId);
		const cached = this.dayCache.get(key);
		if (cached) return cached;
		const today = currentDayString(this.clock());
		const file = this.dayFile(providerId, modelId);
		let totalUsd = 0;
		try {
			const raw = await fs.readFile(file, "utf-8");
			const parsed = JSON.parse(raw) as { day?: string; totalUsd?: number };
			if (parsed.day === today && typeof parsed.totalUsd === "number") {
				totalUsd = parsed.totalUsd;
			}
		} catch {
			// Missing/corrupt → start fresh.
		}
		const next: DayCounter = { day: today, totalUsd };
		this.dayCache.set(key, next);
		return next;
	}

	private async loadMonth(providerId: string, modelId: string | undefined): Promise<MonthCounter> {
		const key = this.monthCacheKey(providerId, modelId);
		const cached = this.monthCache.get(key);
		if (cached) return cached;
		const month = currentMonthString(this.clock());
		const file = this.monthFile(providerId, modelId);
		let totalUsd = 0;
		try {
			const raw = await fs.readFile(file, "utf-8");
			const parsed = JSON.parse(raw) as { month?: string; totalUsd?: number };
			if (parsed.month === month && typeof parsed.totalUsd === "number") {
				totalUsd = parsed.totalUsd;
			}
		} catch {
			// Missing/corrupt → start fresh.
		}
		const next: MonthCounter = { month, totalUsd };
		this.monthCache.set(key, next);
		return next;
	}

	private async saveDay(
		providerId: string,
		modelId: string | undefined,
		day: DayCounter,
	): Promise<void> {
		const file = this.dayFile(providerId, modelId);
		try {
			await fs.mkdir(path.dirname(file), { recursive: true });
			await fs.writeFile(
				file,
				JSON.stringify({ day: day.day, totalUsd: day.totalUsd }, null, 2),
				"utf-8",
			);
		} catch {
			// Tracking is advisory; never break dispatch on a write failure.
		}
	}

	private async saveMonth(
		providerId: string,
		modelId: string | undefined,
		month: MonthCounter,
	): Promise<void> {
		const file = this.monthFile(providerId, modelId);
		try {
			await fs.mkdir(path.dirname(file), { recursive: true });
			await fs.writeFile(
				file,
				JSON.stringify({ month: month.month, totalUsd: month.totalUsd }, null, 2),
				"utf-8",
			);
		} catch {
			// Tracking is advisory; never break dispatch on a write failure.
		}
	}
}
