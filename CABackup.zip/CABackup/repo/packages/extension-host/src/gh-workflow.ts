// R3-E: issue → branch → PR scaffold workflow.
//
// Wires `gh_issue_read` (R3-E tool) into a higher-level "start from issue"
// flow used by the `/from-issue <url>` slash command and the
// `start_from_issue` webview RPC arm.
//
// The flow is deliberately conservative: every step that touches the
// repository (branch checkout, push, PR creation) is gated behind a user
// confirmation via VS Code's quick-input UI. The agent itself runs unattended
// against the issue body once the user approves the branch name.

import type { Conductor } from "@iom/agent-core";
import type { ConversationMessage, HostContext, ModeConfig } from "@iom/shared";
import { ghIssueReadTool } from "@iom/tools/gh-issue-read";
import * as vscode from "vscode";

export interface StartFromIssueDeps {
	readonly conductor: Conductor;
	readonly host: HostContext;
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly history?: readonly ConversationMessage[];
	readonly log?: { appendLine(msg: string): void };
}

export interface StartFromIssueResult {
	readonly status: "ok" | "cancelled" | "error";
	readonly message: string;
	readonly branch?: string;
	readonly prUrl?: string;
}

/**
 * Slug an issue title into a branch-safe segment. Lowercases, replaces any
 * run of non-alnum chars with `-`, trims leading/trailing dashes, and caps
 * length so the final branch name (`feature/<num>-<slug>`) stays under 60
 * chars. The slug itself is never empty — if the title produces nothing
 * useful we fall back to `issue`.
 */
export function slugifyTitle(title: string, maxLen = 50): string {
	const slug = title
		.toLowerCase()
		.replace(/[^a-z0-9]+/g, "-")
		.replace(/^-+|-+$/g, "");
	const trimmed = slug.slice(0, maxLen).replace(/-+$/g, "");
	return trimmed.length > 0 ? trimmed : "issue";
}

export function buildBranchName(issueNumber: number, title: string, maxTotal = 60): string {
	const prefix = `feature/${issueNumber}-`;
	const remaining = Math.max(8, maxTotal - prefix.length);
	const slug = slugifyTitle(title, remaining);
	return `${prefix}${slug}`;
}

interface IssueReadOutput {
	readonly ok: boolean;
	readonly title?: string;
	readonly body?: string;
	readonly labels?: readonly string[];
	readonly assignees?: readonly string[];
	readonly message?: string;
}

/**
 * Drive the issue → branch → PR scaffold workflow.
 *
 *   1. Read the issue via `gh_issue_read`.
 *   2. Compute a branch name slug (capped at 60 chars).
 *   3. Confirm the branch name with the user, then `git checkout -b`.
 *   4. Spawn an Agent with the issue body as initial instruction.
 *   5. On success, prompt to push and open a PR via `gh pr create`.
 */
export async function startFromIssue(
	issueUrl: string,
	deps: StartFromIssueDeps,
): Promise<StartFromIssueResult> {
	const log = (msg: string) => deps.log?.appendLine(`[gh-workflow] ${msg}`);

	if (!/github\.com\/.+\/issues\/\d+/.test(issueUrl)) {
		return {
			status: "error",
			message: `Not a recognized issue URL: ${issueUrl}`,
		};
	}

	// --- Step 1: read the issue ----------------------------------------------
	let issue: IssueReadOutput;
	try {
		issue = (await ghIssueReadTool.handler({ url: issueUrl }, deps.host)) as IssueReadOutput;
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		log(`gh_issue_read threw: ${message}`);
		return { status: "error", message: `Failed to read issue: ${message}` };
	}
	if (!issue.ok || !issue.title) {
		return {
			status: "error",
			message: issue.message ?? "gh_issue_read returned no title.",
		};
	}

	// --- Step 2: compute branch name ----------------------------------------
	const m = issueUrl.match(/\/issues\/(\d+)/);
	const issueNumber = m ? Number.parseInt(m[1], 10) : 0;
	const proposed = buildBranchName(issueNumber, issue.title);

	// --- Step 3: confirm branch + checkout ----------------------------------
	const branch = await vscode.window.showInputBox({
		prompt: `Create branch for issue #${issueNumber}: ${issue.title}`,
		value: proposed,
		validateInput: (v) =>
			v.trim().length === 0
				? "Branch name cannot be empty"
				: /[\s~^:?*\[\]\\]/.test(v)
					? "Branch name contains invalid characters"
					: undefined,
	});
	if (!branch) {
		return { status: "cancelled", message: "User cancelled at branch selection." };
	}

	const checkoutRes = await deps.host.exec(`git checkout -b ${quoteArg(branch)}`, {
		timeoutMs: 15_000,
	});
	if (checkoutRes.exitCode !== 0) {
		// Branch might already exist — try plain checkout as a fallback.
		const fallback = await deps.host.exec(`git checkout ${quoteArg(branch)}`, {
			timeoutMs: 15_000,
		});
		if (fallback.exitCode !== 0) {
			return {
				status: "error",
				message: `git checkout failed: ${(checkoutRes.stderr || checkoutRes.stdout).trim()}`,
				branch,
			};
		}
	}
	log(`checked out branch ${branch}`);

	// --- Step 4: spawn agent --------------------------------------------------
	const instruction = buildAgentInstruction(issue, issueUrl);
	try {
		await deps.conductor.spawn({
			mode: deps.mode,
			modelId: deps.modelId,
			userMessage: instruction,
			...(deps.history ? { history: deps.history } : {}),
		});
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		log(`agent run failed: ${message}`);
		return { status: "error", message: `Agent run failed: ${message}`, branch };
	}

	// --- Step 5: offer push + PR ---------------------------------------------
	const choice = await vscode.window.showInformationMessage(
		`Push branch "${branch}" and open a PR?`,
		"Push & open PR",
		"Push only",
		"Skip",
	);
	if (choice !== "Push & open PR" && choice !== "Push only") {
		return {
			status: "ok",
			message: "Agent finished. Branch left local — no push.",
			branch,
		};
	}

	const pushRes = await deps.host.exec(`git push -u origin ${quoteArg(branch)}`, {
		timeoutMs: 60_000,
	});
	if (pushRes.exitCode !== 0) {
		return {
			status: "error",
			message: `git push failed: ${(pushRes.stderr || pushRes.stdout).trim()}`,
			branch,
		};
	}
	if (choice === "Push only") {
		return { status: "ok", message: `Pushed ${branch}.`, branch };
	}

	const prTitle = `Fix #${issueNumber}: ${issue.title}`;
	const prBody = `Closes #${issueNumber}\n\n${issue.body ?? ""}`.trim();
	const prRes = await deps.host.exec(
		["gh", "pr", "create", "--title", quoteArg(prTitle), "--body", quoteArg(prBody)].join(" "),
		{ timeoutMs: 60_000 },
	);
	if (prRes.exitCode !== 0) {
		return {
			status: "error",
			message: `gh pr create failed: ${(prRes.stderr || prRes.stdout).trim()}`,
			branch,
		};
	}
	const prUrl = extractUrl(prRes.stdout);
	return {
		status: "ok",
		message: prUrl ? `Opened PR: ${prUrl}` : "PR opened.",
		branch,
		...(prUrl ? { prUrl } : {}),
	};
}

function buildAgentInstruction(issue: IssueReadOutput, url: string): string {
	const lines: string[] = [];
	lines.push(`# Issue: ${issue.title ?? "(no title)"}`);
	lines.push("");
	lines.push(`Source: ${url}`);
	if (issue.labels && issue.labels.length > 0) {
		lines.push(`Labels: ${issue.labels.join(", ")}`);
	}
	if (issue.assignees && issue.assignees.length > 0) {
		lines.push(`Assignees: ${issue.assignees.join(", ")}`);
	}
	lines.push("");
	lines.push("## Issue body");
	lines.push(issue.body ?? "(no body)");
	lines.push("");
	lines.push("## Task");
	lines.push(
		"Scaffold an initial implementation that addresses this issue. Read relevant files first to understand the existing code, then make the smallest reasonable change set. Run tests, commit the change with a clear message, and prepare to open a PR. If the issue is unclear or seems out of scope, summarize what you would do and stop — do not guess.",
	);
	return lines.join("\n");
}

function quoteArg(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

function extractUrl(stdout: string): string | undefined {
	const m = stdout.match(/https?:\/\/\S+/);
	return m ? m[0] : undefined;
}

// Re-exports for tests.
export const __test = { slugifyTitle, buildBranchName, buildAgentInstruction };
