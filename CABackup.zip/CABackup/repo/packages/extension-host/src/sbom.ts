// 2026-05-28: SBOM + vulnerability scanning subsystem. Drives `/sbom`.
//
// This file holds the orchestration (workspace walk, parse, query, format)
// plus inline manifest parsers and an OSV.dev client. Kept in one module
// for the initial commit; commit 2 will split parsers + the local-audit
// fallback into their own files.
//
// Flow:
//   1. Walk the workspace for known manifest files
//   2. Parse each into a flat list of Components
//   3. POST the components to OSV.dev /v1/querybatch in one shot
//   4. Merge vuln data back onto each Component
//   5. Format a chat summary (filtered by chatThreshold)
//
// Off by default (`iom.sbom.enabled` = false). The chat-panel dispatcher
// gates the call; this module assumes the caller already checked.

import type { SBOMConfig } from "@iom/shared";

export interface SBOMVulnerability {
	/** CVE id or GHSA id. */
	readonly id: string;
	readonly summary: string;
	/** "low" | "medium" | "high" | "critical" — derived from OSV severity score. */
	readonly severity: "low" | "medium" | "high" | "critical";
	/** First version that contains the fix, when OSV reports one. */
	readonly fixedIn?: string;
	/** Outbound links (advisory pages, CVE entries, …). */
	readonly references: readonly string[];
}

export interface SBOMComponent {
	readonly name: string;
	readonly version: string;
	readonly ecosystem: string;
	readonly manifest: string;
	readonly vulnerabilities: readonly SBOMVulnerability[];
}

export interface SBOMResult {
	readonly components: readonly SBOMComponent[];
	readonly summary: string;
	readonly counts: {
		readonly components: number;
		readonly vulnerable: number;
		readonly critical: number;
		readonly high: number;
		readonly medium: number;
		readonly low: number;
	};
	/** Files we tried to parse but couldn't (with reason). */
	readonly skipped: readonly { readonly path: string; readonly reason: string }[];
}

export interface RunSbomOptions {
	readonly cfg: SBOMConfig | undefined;
	/** Workspace-relative paths to all manifest files we found. */
	readonly manifests: readonly { readonly path: string; readonly content: string }[];
	readonly signal?: AbortSignal;
	/**
	 * Override for the OSV.dev fetcher. Defaults to a real fetch against
	 * https://api.osv.dev/v1/querybatch. Tests inject a stub.
	 */
	readonly osvFetch?: typeof fetchOsv;
}

const SEVERITY_RANK: Record<SBOMVulnerability["severity"], number> = {
	low: 0,
	medium: 1,
	high: 2,
	critical: 3,
};

export async function runSbom(opts: RunSbomOptions): Promise<SBOMResult> {
	const components: SBOMComponent[] = [];
	const skipped: { path: string; reason: string }[] = [];

	// Parse manifests one at a time so a single bad file doesn't tank the whole run.
	for (const m of opts.manifests) {
		try {
			const parsed = parseManifest(m.path, m.content);
			for (const c of parsed) {
				components.push({ ...c, manifest: m.path, vulnerabilities: [] });
			}
		} catch (err) {
			skipped.push({
				path: m.path,
				reason: err instanceof Error ? err.message : String(err),
			});
		}
	}

	if (components.length === 0) {
		return {
			components: [],
			summary: "No supported manifest files found in the workspace.",
			counts: { components: 0, vulnerable: 0, critical: 0, high: 0, medium: 0, low: 0 },
			skipped,
		};
	}

	// Query OSV.dev. If it fails AND useLocalFallback is true, commit 2
	// will branch here. For now we surface the failure and continue with
	// an empty vuln list rather than blowing the run away.
	const useOsv = opts.cfg?.useOsv !== false;
	let withVulns = components;
	if (useOsv) {
		try {
			const fetcher = opts.osvFetch ?? fetchOsv;
			const vulnsPerComponent = await batchQuery(components, fetcher, opts.signal);
			withVulns = components.map((c, i) => ({
				...c,
				vulnerabilities: vulnsPerComponent[i] ?? [],
			}));
		} catch (err) {
			const msg = err instanceof Error ? err.message : String(err);
			skipped.push({ path: "osv.dev", reason: msg });
		}
	}

	const counts = countSeverities(withVulns);
	const threshold = opts.cfg?.chatThreshold ?? "medium";
	const summary = formatSummary(withVulns, counts, threshold, skipped);

	return { components: withVulns, summary, counts, skipped };
}

// ---------------------------------------------------------------------------
// Manifest parsers
// ---------------------------------------------------------------------------

/**
 * Map a path to its ecosystem + dispatch to the right parser. Returns a
 * flat list of components (no vulns attached yet). Throws on parse errors;
 * the orchestrator catches and reports.
 */
function parseManifest(
	path: string,
	content: string,
): Omit<SBOMComponent, "manifest" | "vulnerabilities">[] {
	const lower = path.toLowerCase();
	if (lower.endsWith("package.json")) {
		return parsePackageJson(content);
	}
	// Commit 2: pyproject.toml, requirements.txt, *.csproj, pom.xml, go.mod, Cargo.toml.
	throw new Error(`unsupported manifest type: ${path}`);
}

interface PackageJsonShape {
	readonly dependencies?: Record<string, string>;
	readonly devDependencies?: Record<string, string>;
	readonly peerDependencies?: Record<string, string>;
	readonly optionalDependencies?: Record<string, string>;
}

function parsePackageJson(content: string): Omit<SBOMComponent, "manifest" | "vulnerabilities">[] {
	let parsed: PackageJsonShape;
	try {
		parsed = JSON.parse(content) as PackageJsonShape;
	} catch (err) {
		throw new Error(`invalid JSON: ${err instanceof Error ? err.message : String(err)}`);
	}
	const seen = new Set<string>();
	const out: Omit<SBOMComponent, "manifest" | "vulnerabilities">[] = [];
	for (const bucket of [
		parsed.dependencies,
		parsed.devDependencies,
		parsed.peerDependencies,
		parsed.optionalDependencies,
	]) {
		if (!bucket) continue;
		for (const [name, rawVersion] of Object.entries(bucket)) {
			if (typeof rawVersion !== "string") continue;
			const version = normalizeNpmVersion(rawVersion);
			if (!version) continue; // workspace:* / file:… / git+ssh:… — skip, no CVE to look up
			const key = `${name}@${version}`;
			if (seen.has(key)) continue;
			seen.add(key);
			out.push({ name, version, ecosystem: "npm" });
		}
	}
	return out;
}

/**
 * Strip semver range operators so OSV.dev sees a concrete version. We
 * intentionally pick the lower bound — vuln presence is about "could
 * resolve to a vulnerable version", and the lower bound is the most
 * conservative assumption when the lockfile isn't available.
 *
 * Returns undefined for non-version specifiers (workspace:*, file:…,
 * git+…, npm:alias@…) — those have no version OSV can match against.
 */
function normalizeNpmVersion(raw: string): string | undefined {
	const trimmed = raw.trim();
	if (
		trimmed.startsWith("workspace:") ||
		trimmed.startsWith("file:") ||
		trimmed.startsWith("link:") ||
		trimmed.startsWith("git+") ||
		trimmed.startsWith("github:") ||
		trimmed.startsWith("npm:") ||
		trimmed.includes("://")
	) {
		return undefined;
	}
	// Strip ^ ~ >= > <= < = and surrounding whitespace; take the first version.
	const match = trimmed.match(/(\d+(?:\.\d+){0,2}(?:[-+][0-9A-Za-z.-]+)?)/);
	return match?.[1];
}

// ---------------------------------------------------------------------------
// OSV.dev client
// ---------------------------------------------------------------------------

interface OsvQuery {
	readonly package: { readonly name: string; readonly ecosystem: string };
	readonly version: string;
}

interface OsvBatchResponse {
	readonly results: readonly { readonly vulns?: readonly { readonly id: string }[] }[];
}

interface OsvVuln {
	readonly id: string;
	readonly summary?: string;
	readonly details?: string;
	readonly severity?: readonly { readonly type: string; readonly score: string }[];
	readonly affected?: readonly {
		readonly ranges?: readonly {
			readonly events?: readonly { readonly fixed?: string; readonly introduced?: string }[];
		}[];
	}[];
	readonly references?: readonly { readonly url: string }[];
	readonly database_specific?: { readonly severity?: string };
}

const OSV_BATCH_URL = "https://api.osv.dev/v1/querybatch";
const OSV_VULN_URL = "https://api.osv.dev/v1/vulns/";

export async function fetchOsv(url: string, init: RequestInit): Promise<Response> {
	return fetch(url, init);
}

async function batchQuery(
	components: readonly SBOMComponent[],
	fetcher: typeof fetchOsv,
	signal: AbortSignal | undefined,
): Promise<SBOMVulnerability[][]> {
	if (components.length === 0) return [];
	const queries: OsvQuery[] = components.map((c) => ({
		package: { name: c.name, ecosystem: ecosystemToOsv(c.ecosystem) },
		version: c.version,
	}));

	const res = await fetcher(OSV_BATCH_URL, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify({ queries }),
		...(signal ? { signal } : {}),
	});
	if (!res.ok) {
		throw new Error(`OSV.dev returned ${res.status} ${res.statusText}`);
	}
	const body = (await res.json()) as OsvBatchResponse;

	// Resolve each vuln id to its full record so we get severity + fix info.
	// OSV's batch endpoint only returns ids; full data needs a per-id GET.
	// We do those in parallel but bounded so we don't fire 1000 requests at once.
	const idsPerComponent: string[][] = body.results.map((r) => (r.vulns ?? []).map((v) => v.id));
	const allIds = Array.from(new Set(idsPerComponent.flat()));
	const idToVuln = new Map<string, SBOMVulnerability>();
	const CONCURRENCY = 10;
	for (let i = 0; i < allIds.length; i += CONCURRENCY) {
		const slice = allIds.slice(i, i + CONCURRENCY);
		const rows = await Promise.all(
			slice.map(async (id) => {
				try {
					const r = await fetcher(OSV_VULN_URL + encodeURIComponent(id), {
						method: "GET",
						...(signal ? { signal } : {}),
					});
					if (!r.ok) return undefined;
					const v = (await r.json()) as OsvVuln;
					return [id, normalizeOsvVuln(id, v)] as const;
				} catch {
					return undefined;
				}
			}),
		);
		for (const r of rows) {
			if (r) idToVuln.set(r[0], r[1]);
		}
	}

	return idsPerComponent.map((ids) =>
		ids.map((id) => idToVuln.get(id)).filter((v): v is SBOMVulnerability => !!v),
	);
}

function normalizeOsvVuln(id: string, v: OsvVuln): SBOMVulnerability {
	return {
		id,
		summary: v.summary ?? v.details?.slice(0, 200) ?? "(no summary)",
		severity: deriveSeverity(v),
		...(extractFixedIn(v) ? { fixedIn: extractFixedIn(v) } : {}),
		references: (v.references ?? []).map((r) => r.url).slice(0, 5),
	};
}

function deriveSeverity(v: OsvVuln): SBOMVulnerability["severity"] {
	// OSV's `database_specific.severity` is a free-text "CRITICAL"/"HIGH"/… on
	// GHSA-sourced records. Trust that first; fall back to CVSS parsing.
	const dbSev = v.database_specific?.severity?.toUpperCase();
	if (dbSev === "CRITICAL") return "critical";
	if (dbSev === "HIGH") return "high";
	if (dbSev === "MODERATE" || dbSev === "MEDIUM") return "medium";
	if (dbSev === "LOW") return "low";

	const cvssEntry = v.severity?.find((s) => s.type.startsWith("CVSS"));
	if (cvssEntry) {
		// Score string is like "CVSS:3.1/AV:N/...". Pull the base-score number
		// from the legitimate parser would be ideal, but for now we use the
		// well-known CVSS->qualitative mapping cutoffs.
		const match = cvssEntry.score.match(
			/\/(?:CR|IR|AR|MAV|MAC|MPR|MUI|MS|MC|MI|MA):[A-Z]+|CVSS:[\d.]+/,
		);
		// If we can't parse the numeric score reliably, default to medium.
		// Commit 2 swaps in a proper CVSS parser.
		void match;
		return "medium";
	}
	return "medium";
}

function extractFixedIn(v: OsvVuln): string | undefined {
	for (const a of v.affected ?? []) {
		for (const r of a.ranges ?? []) {
			for (const e of r.events ?? []) {
				if (e.fixed) return e.fixed;
			}
		}
	}
	return undefined;
}

function ecosystemToOsv(eco: string): string {
	switch (eco) {
		case "npm":
			return "npm";
		case "pypi":
			return "PyPI";
		case "maven":
			return "Maven";
		case "nuget":
			return "NuGet";
		case "go":
			return "Go";
		case "cargo":
			return "crates.io";
		default:
			return eco;
	}
}

// ---------------------------------------------------------------------------
// Result formatting
// ---------------------------------------------------------------------------

function countSeverities(components: readonly SBOMComponent[]): SBOMResult["counts"] {
	let critical = 0;
	let high = 0;
	let medium = 0;
	let low = 0;
	let vulnerable = 0;
	for (const c of components) {
		if (c.vulnerabilities.length > 0) vulnerable++;
		for (const v of c.vulnerabilities) {
			if (v.severity === "critical") critical++;
			else if (v.severity === "high") high++;
			else if (v.severity === "medium") medium++;
			else low++;
		}
	}
	return { components: components.length, vulnerable, critical, high, medium, low };
}

function formatSummary(
	components: readonly SBOMComponent[],
	counts: SBOMResult["counts"],
	threshold: NonNullable<SBOMConfig["chatThreshold"]>,
	skipped: readonly { path: string; reason: string }[],
): string {
	const lines: string[] = [];
	lines.push(`## SBOM — ${counts.components} component${counts.components === 1 ? "" : "s"}`);
	lines.push("");
	const sevLine = `**Vulnerabilities:** 🔴 ${counts.critical} critical · 🟠 ${counts.high} high · 🟡 ${counts.medium} medium · ⚪ ${counts.low} low`;
	lines.push(sevLine);
	lines.push("");

	const minRank = SEVERITY_RANK[threshold];
	const filtered = components
		.filter((c) => c.vulnerabilities.some((v) => SEVERITY_RANK[v.severity] >= minRank))
		.sort((a, b) => maxRank(b) - maxRank(a));

	if (filtered.length === 0) {
		lines.push(`No vulnerabilities at \`${threshold}\` or higher.`);
	} else {
		lines.push(`### Findings (≥ ${threshold})`);
		lines.push("");
		for (const c of filtered) {
			const relevant = c.vulnerabilities
				.filter((v) => SEVERITY_RANK[v.severity] >= minRank)
				.sort((a, b) => SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity]);
			lines.push(`- **${c.name}@${c.version}** (${c.ecosystem}) — ${c.manifest}`);
			for (const v of relevant) {
				const icon =
					v.severity === "critical"
						? "🔴"
						: v.severity === "high"
							? "🟠"
							: v.severity === "medium"
								? "🟡"
								: "⚪";
				const fixHint = v.fixedIn ? ` → fix: \`${v.fixedIn}\`` : "";
				lines.push(`  - ${icon} ${v.id} — ${v.summary}${fixHint}`);
			}
		}
	}

	if (skipped.length > 0) {
		lines.push("");
		lines.push(`**Skipped ${skipped.length}:**`);
		for (const s of skipped.slice(0, 5)) {
			lines.push(`- \`${s.path}\` — ${s.reason.slice(0, 160)}`);
		}
		if (skipped.length > 5) lines.push(`- (+${skipped.length - 5} more)`);
	}

	return lines.join("\n");
}

function maxRank(c: SBOMComponent): number {
	let best = -1;
	for (const v of c.vulnerabilities) {
		const r = SEVERITY_RANK[v.severity];
		if (r > best) best = r;
	}
	return best;
}
