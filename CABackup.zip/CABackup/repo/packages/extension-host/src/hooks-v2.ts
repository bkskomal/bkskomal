// R8-E: Hook system v2.
//
// Extends R1's narrow `HookRunner` (PreToolUse / PostToolUse / UserPromptSubmit /
// SessionStart / Stop) into Claude Code's full 8-event surface and makes every
// event uniformly observable AND mutable. The legacy `HookRunner` keeps working
// — `migrateLegacyHooks` upgrades a `HookConfig[]` (R1 shape) into the v2
// `HookV2Entry[]` shape with zero behavior change, and the chat-panel wires
// v2 first then falls back to legacy when the panel's runner is not the new
// one. The two coexist so existing tests + saved `.iom/iom.json` configs
// keep working through the migration window.
//
// Configuration on disk (preferred location: `.iom/hooks.json`, falls back
// to `RootConfig.hooks`):
//
// ```json
// {
//   "hooks": [
//     {
//       "event": "PreToolUse",
//       "matcher": "write_*",
//       "command": "node tools/audit-write.js",
//       "blockOnFailure": true,
//       "timeout": 5000
//     }
//   ]
// }
// ```
//
// The hook command receives the event payload as JSON on stdin. If it prints
// a JSON object on stdout, that object is parsed as a verdict
// (`{allow, reason?, modifiedPayload?}`) and threaded through. Non-JSON stdout
// is treated as a passive observer (allow:true). When `blockOnFailure` is true,
// a non-zero exit code OR an `allow:false` verdict cancels the upstream action.

import { type ChildProcess, spawn } from "node:child_process";
import { promises as fs } from "node:fs";
import * as path from "node:path";
import type { HookConfig } from "@iom/shared";

/** Discriminated union of every hook event the host fires. */
export type HookEventKind =
	| "UserPromptSubmit"
	| "PreToolUse"
	| "PostToolUse"
	| "Notification"
	| "Stop"
	| "SubagentStop"
	| "SessionStart"
	| "SessionEnd";

export interface UserPromptSubmitPayload {
	readonly text: string;
}

export interface PreToolUsePayload {
	readonly toolName: string;
	readonly args?: unknown;
}

export interface PostToolUsePayload {
	readonly toolName: string;
	readonly result?: unknown;
	readonly isError?: boolean;
	readonly durationMs?: number;
}

export interface NotificationPayload {
	readonly kind: string;
	readonly title: string;
	readonly body?: string;
}

export interface StopPayload {
	readonly sessionId: string;
	readonly reason?: string;
}

export interface SubagentStopPayload {
	readonly agentId: string;
	readonly parentAgentId?: string;
	readonly status: "ok" | "error";
	readonly summary?: string;
}

export interface SessionStartPayload {
	readonly sessionId: string;
}

export interface SessionEndPayload {
	readonly sessionId: string;
}

export type HookEvent =
	| { readonly kind: "UserPromptSubmit"; readonly payload: UserPromptSubmitPayload }
	| { readonly kind: "PreToolUse"; readonly payload: PreToolUsePayload }
	| { readonly kind: "PostToolUse"; readonly payload: PostToolUsePayload }
	| { readonly kind: "Notification"; readonly payload: NotificationPayload }
	| { readonly kind: "Stop"; readonly payload: StopPayload }
	| { readonly kind: "SubagentStop"; readonly payload: SubagentStopPayload }
	| { readonly kind: "SessionStart"; readonly payload: SessionStartPayload }
	| { readonly kind: "SessionEnd"; readonly payload: SessionEndPayload };

/** A hook entry — the v2 shape stored in `.iom/hooks.json`. */
export interface HookV2Entry {
	readonly event: HookEventKind;
	/**
	 * Optional matcher applied to the event's primary string field. For
	 * `PreToolUse` / `PostToolUse` this is the tool name; for
	 * `UserPromptSubmit` it's the prompt text; for `Notification` it's the
	 * notification kind; for the other events the matcher is ignored (the hook
	 * runs unconditionally).
	 */
	readonly matcher?: string;
	/**
	 * Shell command to spawn. The event payload is piped to stdin as JSON; the
	 * stdout, if parseable as a JSON object with an `allow` boolean, becomes
	 * the verdict.
	 */
	readonly command: string;
	/** Max time the hook is allowed to run, in milliseconds. Defaults to 5000. */
	readonly timeout?: number;
	/**
	 * When true and the hook either exits non-zero OR returns
	 * `{"allow": false}`, the upstream action is cancelled. When false
	 * (default), the runner still threads through `modifiedPayload` but a
	 * failure does not block.
	 */
	readonly blockOnFailure?: boolean;
}

export interface HookV2Result<P = unknown> {
	readonly allow: boolean;
	readonly reason?: string;
	/** Payload after every hook in the chain has had a chance to mutate it. */
	readonly payload: P;
}

export interface HookV2RunnerOptions {
	readonly log?: { appendLine(line: string): void };
	readonly spawnFn?: typeof spawn;
	readonly defaultTimeoutMs?: number;
	readonly stopTimeoutMs?: number;
}

const DEFAULT_TIMEOUT_MS = 5000;
const DEFAULT_STOP_TIMEOUT_MS = 1000;

/**
 * Hook v2 runner. Replaces R1's narrower `HookRunner` while staying
 * source-compatible — `fromLegacy(...)` builds one from a `HookConfig[]`.
 *
 * Design notes:
 * - All events are uniformly mutable: every hook may return a `modifiedPayload`
 *   which is threaded through to the next hook (and ultimately to the caller).
 *   For pure observers like `PostToolUse` or `SessionEnd` the caller can ignore
 *   it.
 * - Hooks for one event run sequentially in registration order. The common
 *   case is 0-1 hooks per event; the predictability is worth the lost
 *   parallelism.
 * - A hook that crashes (spawn error, non-zero exit without `blockOnFailure`,
 *   timeout) is treated as `allow:true` so a broken `.iom/hooks.json` doesn't
 *   wedge the user's workflow.
 */
export class HookV2Runner {
	private readonly entries: readonly HookV2Entry[];
	private readonly log?: { appendLine(line: string): void };
	private readonly spawnFn: typeof spawn;
	private readonly defaultTimeoutMs: number;
	private readonly stopTimeoutMs: number;

	constructor(entries: readonly HookV2Entry[] | undefined, options: HookV2RunnerOptions = {}) {
		this.entries = entries ?? [];
		this.log = options.log;
		this.spawnFn = options.spawnFn ?? spawn;
		this.defaultTimeoutMs = options.defaultTimeoutMs ?? DEFAULT_TIMEOUT_MS;
		this.stopTimeoutMs = options.stopTimeoutMs ?? DEFAULT_STOP_TIMEOUT_MS;
	}

	/** Total number of registered hooks across all events. */
	get size(): number {
		return this.entries.length;
	}

	/** Number of registered hooks for a single event. Used by `/hooks`. */
	countByEvent(event: HookEventKind): number {
		return this.entries.filter((e) => e.event === event).length;
	}

	/** Snapshot of registered entries (for `/hooks` listing). */
	list(): readonly HookV2Entry[] {
		return this.entries;
	}

	/**
	 * Fire every hook matching `event.kind`. Returns the (possibly mutated)
	 * payload plus an allow/deny verdict. The caller is responsible for
	 * respecting `allow:false` — the runner does NOT throw on block.
	 */
	async fire<E extends HookEvent>(event: E): Promise<HookV2Result<E["payload"]>> {
		const matchTarget = matchTargetFor(event);
		const matches = this.entries.filter(
			(h) => h.event === event.kind && matcherApplies(h.matcher, matchTarget),
		);
		const stopLike = event.kind === "Stop" || event.kind === "SessionEnd";
		let payload: unknown = event.payload;
		if (matches.length === 0) {
			return { allow: true, payload: payload as E["payload"] };
		}
		for (const hook of matches) {
			const baseTimeout = hook.timeout ?? this.defaultTimeoutMs;
			const timeoutMs = stopLike ? Math.min(baseTimeout, this.stopTimeoutMs) : baseTimeout;
			const verdict = await this.runOne(hook, payload, timeoutMs);
			if (verdict.modifiedPayload !== undefined) payload = verdict.modifiedPayload;
			if (!verdict.allow && hook.blockOnFailure) {
				return {
					allow: false,
					reason: verdict.reason ?? `Blocked by ${event.kind} hook`,
					payload: payload as E["payload"],
				};
			}
		}
		return { allow: true, payload: payload as E["payload"] };
	}

	private async runOne(
		hook: HookV2Entry,
		payload: unknown,
		timeoutMs: number,
	): Promise<{ allow: boolean; reason?: string; modifiedPayload?: unknown }> {
		const payloadJson = `${JSON.stringify(payload)}\n`;
		let child: ChildProcess;
		try {
			child = this.spawnFn(hook.command, {
				shell: true,
				stdio: ["pipe", "pipe", "pipe"],
			});
		} catch (err) {
			this.log?.appendLine(
				`[hooks-v2] failed to spawn '${hook.command}': ${err instanceof Error ? err.message : String(err)}`,
			);
			return { allow: true };
		}

		return new Promise((resolve) => {
			let stdout = "";
			let stderr = "";
			let settled = false;
			const timer = setTimeout(() => {
				if (settled) return;
				settled = true;
				this.log?.appendLine(`[hooks-v2] '${hook.command}' timed out after ${timeoutMs}ms`);
				try {
					child.kill();
				} catch {
					/* best-effort */
				}
				resolve({ allow: true });
			}, timeoutMs);

			child.stdout?.on("data", (chunk: Buffer | string) => {
				stdout += typeof chunk === "string" ? chunk : chunk.toString("utf-8");
			});
			child.stderr?.on("data", (chunk: Buffer | string) => {
				stderr += typeof chunk === "string" ? chunk : chunk.toString("utf-8");
			});

			child.on("error", (err) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				this.log?.appendLine(
					`[hooks-v2] '${hook.command}' errored: ${err instanceof Error ? err.message : String(err)}`,
				);
				resolve({ allow: true });
			});

			child.on("close", (code) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				if (stderr) this.log?.appendLine(`[hooks-v2] '${hook.command}' stderr: ${stderr.trim()}`);
				const parsed = tryParseVerdict(stdout);
				if (parsed) {
					// A blocking verdict only blocks when the hook is marked
					// `blockOnFailure`. Otherwise we still propagate
					// `modifiedPayload` but allow the action.
					if (!parsed.allow && !hook.blockOnFailure) {
						resolve({
							allow: true,
							modifiedPayload: parsed.modifiedPayload,
						});
						return;
					}
					resolve(parsed);
					return;
				}
				if (code !== 0 && code !== null && hook.blockOnFailure) {
					this.log?.appendLine(
						`[hooks-v2] '${hook.command}' exited with non-zero code ${code} (blockOnFailure=true)`,
					);
					resolve({ allow: false, reason: `Hook exited with code ${code}` });
					return;
				}
				if (code !== 0 && code !== null) {
					this.log?.appendLine(`[hooks-v2] '${hook.command}' exited with code ${code}`);
				}
				resolve({ allow: true });
			});

			try {
				child.stdin?.end(payloadJson);
			} catch {
				/* stdin may already be closed if spawn failed asynchronously */
			}
		});
	}
}

/** Substring-or-glob matcher. Empty/undefined matcher = match everything. */
export function matcherApplies(matcher: string | undefined, target: string): boolean {
	if (!matcher) return true;
	if (matcher.includes("*") || matcher.includes("?")) {
		return globToRegex(matcher).test(target);
	}
	return target.includes(matcher);
}

function matchTargetFor(event: HookEvent): string {
	switch (event.kind) {
		case "UserPromptSubmit":
			return event.payload.text;
		case "PreToolUse":
		case "PostToolUse":
			return event.payload.toolName;
		case "Notification":
			return event.payload.kind;
		default:
			return "";
	}
}

function globToRegex(glob: string): RegExp {
	let out = "";
	for (const ch of glob) {
		if (ch === "*") out += ".*";
		else if (ch === "?") out += ".";
		else out += escapeRegex(ch);
	}
	return new RegExp(`^${out}$`);
}

function escapeRegex(ch: string): string {
	return /[.+^${}()|[\]\\]/.test(ch) ? `\\${ch}` : ch;
}

function tryParseVerdict(
	stdout: string,
): { allow: boolean; reason?: string; modifiedPayload?: unknown } | undefined {
	const trimmed = stdout.trim();
	if (!trimmed) return undefined;
	if (trimmed[0] !== "{" && trimmed[0] !== "[") return undefined;
	let value: unknown;
	try {
		value = JSON.parse(trimmed);
	} catch {
		return undefined;
	}
	if (!value || typeof value !== "object") return undefined;
	const obj = value as Record<string, unknown>;
	if (typeof obj.allow !== "boolean") return undefined;
	const out: { allow: boolean; reason?: string; modifiedPayload?: unknown } = {
		allow: obj.allow,
	};
	if (typeof obj.reason === "string") out.reason = obj.reason;
	if ("modifiedPayload" in obj) out.modifiedPayload = obj.modifiedPayload;
	return out;
}

/**
 * Backward-compat shim: convert an R1 `HookConfig[]` (from `RootConfig.hooks`)
 * into the v2 entry shape. R1's `blocking` flag maps directly to v2's
 * `blockOnFailure` — same semantics, friendlier name.
 *
 * Three legacy events (R1 only knew about PreToolUse / PostToolUse /
 * UserPromptSubmit / SessionStart / Stop) pass through unchanged; v2 adds
 * Notification / SubagentStop / SessionEnd on top.
 */
export function migrateLegacyHooks(legacy: readonly HookConfig[] | undefined): HookV2Entry[] {
	if (!legacy || legacy.length === 0) return [];
	return legacy.map((h) => {
		const out: HookV2Entry = {
			event: h.event,
			command: h.command,
			...(h.matcher !== undefined ? { matcher: h.matcher } : {}),
			...(h.timeout !== undefined ? { timeout: h.timeout } : {}),
			...(h.blocking ? { blockOnFailure: true } : {}),
		};
		return out;
	});
}

/** Path (relative to the workspace) where v2 hooks live. */
export const HOOKS_V2_FILE_REL = ".iom/hooks.json";

export interface LoadHooksV2Result {
	readonly hooks: readonly HookV2Entry[];
	readonly source: "file" | "legacy" | "empty";
	readonly warning?: string;
}

/**
 * Load `<workspace>/.iom/hooks.json` if present; otherwise fall back to the
 * R1 `legacy` array (typically `RootConfig.hooks`). Always resolves — a
 * missing file or malformed JSON falls back to `legacy` and produces a warning
 * the caller can log.
 */
export async function loadHooksV2(
	workspaceRoot: string | undefined,
	legacy: readonly HookConfig[] | undefined,
): Promise<LoadHooksV2Result> {
	if (workspaceRoot) {
		const filePath = path.join(workspaceRoot, HOOKS_V2_FILE_REL);
		try {
			const raw = await fs.readFile(filePath, "utf-8");
			try {
				const parsed = JSON.parse(raw) as unknown;
				const hooks = normalizeHooksFile(parsed);
				if (hooks.length > 0) return { hooks, source: "file" };
			} catch (err) {
				const message = err instanceof Error ? err.message : String(err);
				return {
					hooks: migrateLegacyHooks(legacy),
					source: legacy && legacy.length > 0 ? "legacy" : "empty",
					warning: `Failed to parse ${HOOKS_V2_FILE_REL}: ${message}. Falling back to legacy hooks.`,
				};
			}
		} catch {
			/* no file → fall through to legacy */
		}
	}
	const migrated = migrateLegacyHooks(legacy);
	return {
		hooks: migrated,
		source: migrated.length > 0 ? "legacy" : "empty",
	};
}

/**
 * Validate + filter a parsed `hooks.json`. Accepts either a top-level array of
 * entries OR `{ "hooks": [...] }` (both common in the wild). Entries with a
 * malformed `event` or missing `command` are dropped silently — corrupted
 * configs should degrade, not crash.
 */
export function normalizeHooksFile(parsed: unknown): HookV2Entry[] {
	const list = Array.isArray(parsed)
		? (parsed as unknown[])
		: parsed && typeof parsed === "object" && Array.isArray((parsed as { hooks?: unknown }).hooks)
			? (parsed as { hooks: unknown[] }).hooks
			: [];
	const validEvents: ReadonlySet<HookEventKind> = new Set<HookEventKind>([
		"UserPromptSubmit",
		"PreToolUse",
		"PostToolUse",
		"Notification",
		"Stop",
		"SubagentStop",
		"SessionStart",
		"SessionEnd",
	]);
	const out: HookV2Entry[] = [];
	for (const raw of list) {
		if (!raw || typeof raw !== "object") continue;
		const r = raw as Record<string, unknown>;
		if (typeof r.event !== "string" || !validEvents.has(r.event as HookEventKind)) continue;
		if (typeof r.command !== "string" || r.command.length === 0) continue;
		const entry: HookV2Entry = {
			event: r.event as HookEventKind,
			command: r.command,
			...(typeof r.matcher === "string" ? { matcher: r.matcher } : {}),
			...(typeof r.timeout === "number" && Number.isFinite(r.timeout) ? { timeout: r.timeout } : {}),
			...(r.blockOnFailure === true || r.blocking === true ? { blockOnFailure: true } : {}),
		};
		out.push(entry);
	}
	return out;
}
