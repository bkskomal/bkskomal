import { type ChildProcess, spawn } from "node:child_process";
import type { HookConfig } from "@iom/shared";

/** Verdict returned by `HookRunner` after running all hooks for one event. */
export interface HookResult {
	/**
	 * `true` if every blocking hook approved (or none were blocking). When `false`
	 * the caller should abort the action; `reason` carries a human-readable
	 * explanation suitable for an error banner.
	 */
	readonly allow: boolean;
	readonly reason?: string;
	/**
	 * If a PreToolUse / UserPromptSubmit hook returned a `modifiedPayload`, the
	 * runner forwards it here so the caller can swap in the new args/text before
	 * continuing. Currently advisory — callers may ignore it.
	 */
	readonly modifiedPayload?: unknown;
}

/**
 * Minimal logging surface the runner uses (matches `vscode.OutputChannel` so the
 * extension can wire its existing channel straight in without an adapter).
 */
export interface HookLogger {
	appendLine(line: string): void;
}

/** Spawn dependency, injected so tests can stub `child_process.spawn`. */
export type SpawnFn = typeof spawn;

export interface HookRunnerOptions {
	readonly log?: HookLogger;
	readonly spawnFn?: SpawnFn;
	readonly defaultTimeoutMs?: number;
	/**
	 * Used by `runStop` so disposal can pre-empt longer hook timeouts. The chat
	 * panel passes `1000` here to keep teardown snappy.
	 */
	readonly stopTimeoutMs?: number;
}

const DEFAULT_TIMEOUT_MS = 5000;
const DEFAULT_STOP_TIMEOUT_MS = 1000;

type HookEvent = HookConfig["event"];

interface ToolUsePayload {
	readonly toolName: string;
	readonly args?: unknown;
	readonly result?: unknown;
}

interface PromptPayload {
	readonly text: string;
}

/**
 * Runs lifecycle hooks declared in `RootConfig.hooks`. Hooks are spawned as
 * child processes; the event payload is piped to stdin as JSON, the child's
 * stdout (parsed as JSON when possible) becomes the verdict, and a configurable
 * timeout enforces an upper bound on wall time.
 *
 * Design notes:
 * - Hooks for one event run *sequentially* — easier to reason about than parallel
 *   races and the common case is 0-1 hooks per event anyway.
 * - A hook that prints non-JSON stdout is treated as `allow:true` (passive
 *   logger). Explicit `{"allow": false}` blocks the action.
 * - Missing-command / spawn errors are caught and logged; the hook is treated as
 *   `allow:true` rather than failing the user's request because their config
 *   references a binary that isn't installed.
 */
export class HookRunner {
	private readonly hooks: readonly HookConfig[];
	private readonly log?: HookLogger;
	private readonly spawnFn: SpawnFn;
	private readonly defaultTimeoutMs: number;
	private readonly stopTimeoutMs: number;

	constructor(hooks: readonly HookConfig[] | undefined, options: HookRunnerOptions = {}) {
		this.hooks = hooks ?? [];
		this.log = options.log;
		this.spawnFn = options.spawnFn ?? spawn;
		this.defaultTimeoutMs = options.defaultTimeoutMs ?? DEFAULT_TIMEOUT_MS;
		this.stopTimeoutMs = options.stopTimeoutMs ?? DEFAULT_STOP_TIMEOUT_MS;
	}

	async runPreToolUse(toolName: string, args: unknown): Promise<HookResult> {
		return this.runEvent("PreToolUse", { toolName, args }, toolName);
	}

	async runPostToolUse(toolName: string, result: unknown): Promise<HookResult> {
		return this.runEvent("PostToolUse", { toolName, result }, toolName);
	}

	async runUserPromptSubmit(text: string): Promise<HookResult> {
		return this.runEvent("UserPromptSubmit", { text }, text);
	}

	async runSessionStart(): Promise<HookResult> {
		return this.runEvent("SessionStart", {}, "");
	}

	async runStop(): Promise<HookResult> {
		// Stop hooks run during dispose, so cap them tightly regardless of the
		// configured timeout. We still respect a lower per-hook value.
		return this.runEvent("Stop", {}, "", this.stopTimeoutMs);
	}

	private async runEvent(
		event: HookEvent,
		payload: ToolUsePayload | PromptPayload | Record<string, never>,
		matchTarget: string,
		timeoutCap?: number,
	): Promise<HookResult> {
		const matches = this.hooks.filter(
			(h) => h.event === event && matcherApplies(h.matcher, matchTarget),
		);
		if (matches.length === 0) return { allow: true };

		let modifiedPayload: unknown;
		for (const hook of matches) {
			const baseTimeout = hook.timeout ?? this.defaultTimeoutMs;
			const timeoutMs = timeoutCap !== undefined ? Math.min(baseTimeout, timeoutCap) : baseTimeout;
			const verdict = await this.runOne(hook, payload, timeoutMs);
			if (verdict.modifiedPayload !== undefined) modifiedPayload = verdict.modifiedPayload;
			if (!verdict.allow) {
				return {
					allow: false,
					reason: verdict.reason ?? `Blocked by ${event} hook`,
					modifiedPayload,
				};
			}
		}
		return { allow: true, modifiedPayload };
	}

	private async runOne(hook: HookConfig, payload: unknown, timeoutMs: number): Promise<HookResult> {
		const payloadJson = `${JSON.stringify(payload)}\n`;
		let child: ChildProcess;
		try {
			child = this.spawnFn(hook.command, {
				shell: true,
				stdio: ["pipe", "pipe", "pipe"],
			});
		} catch (err) {
			this.log?.appendLine(
				`[hook] failed to spawn '${hook.command}': ${err instanceof Error ? err.message : String(err)}`,
			);
			return { allow: true };
		}

		return new Promise<HookResult>((resolve) => {
			let stdout = "";
			let stderr = "";
			let settled = false;
			const timer = setTimeout(() => {
				if (settled) return;
				settled = true;
				this.log?.appendLine(`[hook] '${hook.command}' timed out after ${timeoutMs}ms`);
				try {
					child.kill();
				} catch {
					/* best-effort */
				}
				resolve({ allow: true });
			}, timeoutMs);

			child.stdout?.on("data", (chunk: Buffer | string) => {
				stdout += typeof chunk === "string" ? chunk : chunk.toString("utf-8");
			});
			child.stderr?.on("data", (chunk: Buffer | string) => {
				stderr += typeof chunk === "string" ? chunk : chunk.toString("utf-8");
			});

			child.on("error", (err) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				this.log?.appendLine(
					`[hook] '${hook.command}' errored: ${err instanceof Error ? err.message : String(err)}`,
				);
				resolve({ allow: true });
			});

			child.on("close", (code) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				if (stderr) {
					this.log?.appendLine(`[hook] '${hook.command}' stderr: ${stderr.trim()}`);
				}
				const parsed = tryParseVerdict(stdout);
				if (parsed) {
					resolve(parsed);
					return;
				}
				if (code !== 0 && code !== null) {
					this.log?.appendLine(`[hook] '${hook.command}' exited with code ${code}`);
				}
				resolve({ allow: true });
			});

			// Write payload via stdin so hook authors don't have to deal with quoting.
			try {
				child.stdin?.end(payloadJson);
			} catch {
				/* stdin may already be closed if spawn failed asynchronously */
			}
		});
	}
}

/** Substring-or-glob matcher. Empty/undefined matcher = match everything. */
export function matcherApplies(matcher: string | undefined, target: string): boolean {
	if (!matcher) return true;
	if (matcher.includes("*") || matcher.includes("?")) {
		return globToRegex(matcher).test(target);
	}
	return target.includes(matcher);
}

function globToRegex(glob: string): RegExp {
	let out = "";
	for (const ch of glob) {
		if (ch === "*") out += ".*";
		else if (ch === "?") out += ".";
		else out += escapeRegex(ch);
	}
	return new RegExp(`^${out}$`);
}

function escapeRegex(ch: string): string {
	return /[.+^${}()|[\]\\]/.test(ch) ? `\\${ch}` : ch;
}

function tryParseVerdict(stdout: string): HookResult | undefined {
	const trimmed = stdout.trim();
	if (!trimmed) return undefined;
	if (trimmed[0] !== "{" && trimmed[0] !== "[") return undefined;
	let value: unknown;
	try {
		value = JSON.parse(trimmed);
	} catch {
		return undefined;
	}
	if (!value || typeof value !== "object") return undefined;
	const obj = value as Record<string, unknown>;
	if (typeof obj.allow !== "boolean") return undefined;
	return {
		allow: obj.allow,
		reason: typeof obj.reason === "string" ? obj.reason : undefined,
		modifiedPayload: "modifiedPayload" in obj ? obj.modifiedPayload : undefined,
	};
}
