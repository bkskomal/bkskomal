import type { ScratchpadNote } from "@iom/shared";

/**
 * Per-parent-agent shared scratchpad store. Sub-agents spawned via
 * `spawn_parallel_agents` get a wrapped HostContext that routes
 * `scratchpadWrite("", note)` into their parent's bucket. The parent run is
 * responsible for clearing its bucket via `dropScratchpad` once the batch
 * completes, so we don't accumulate per-run state across the extension's
 * lifetime.
 *
 * Pulled out of host-context.ts so unit tests can exercise it without dragging
 * `vscode` into the test runtime.
 */

const buckets = new Map<string, ScratchpadNote[]>();

export function ensureScratchpad(parentAgentId: string): void {
	if (!parentAgentId) return;
	if (!buckets.has(parentAgentId)) buckets.set(parentAgentId, []);
}

export function scratchpadWrite(parentAgentId: string, note: string, author?: string): void {
	if (!parentAgentId) return;
	const bucket = buckets.get(parentAgentId);
	if (!bucket) return;
	bucket.push({ note, author: author ?? parentAgentId, at: new Date().toISOString() });
}

export function scratchpadRead(parentAgentId: string): readonly ScratchpadNote[] {
	if (!parentAgentId) return [];
	return buckets.get(parentAgentId) ?? [];
}

export function dropScratchpad(parentAgentId: string): void {
	if (!parentAgentId) return;
	buckets.delete(parentAgentId);
}

export function _resetScratchpadsForTest(): void {
	buckets.clear();
}
