import * as vscode from "vscode";

/**
 * AI Code Lens provider.
 *
 * Emits "Explain · Test · Refactor" lenses above every detected function /
 * class header in supported languages. The detection is a deliberately
 * coarse regex pass — tree-sitter / LSP integration comes in a later round.
 * The goal is "useful 90% of the time, never crashes" — false positives are
 * fine, false negatives are fine, and the lenses do nothing harmful when
 * the user clicks one on an iffy boundary (they just trigger a chat
 * prompt).
 */

/** Supported language ids — matched against `document.languageId`. */
export const SUPPORTED_LANGUAGES = new Set([
	"typescript",
	"typescriptreact",
	"javascript",
	"javascriptreact",
	"python",
	"go",
	"rust",
]);

/** A symbol the heuristic detector pulled out of a file. */
export interface DetectedSymbol {
	readonly kind: "function" | "class";
	readonly name: string;
	/** 0-based line where the declaration starts. */
	readonly line: number;
}

/**
 * Heuristic detector. Pure / testable.
 *
 * Each language gets one regex applied per line. Anything that smells like
 * the start of a top-level function or class header gets surfaced. We
 * intentionally do NOT try to be airtight — false positives are cheap and
 * false negatives just mean "no lens for that one", which is recoverable
 * via the command palette.
 */
export function detectSymbols(text: string, languageId: string): DetectedSymbol[] {
	const lines = text.split(/\r?\n/);
	const detectors = DETECTORS[languageId];
	if (!detectors) return [];
	const out: DetectedSymbol[] = [];
	const seen = new Set<string>();
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		// Skip obviously-comment-only lines so doc lines don't accidentally match.
		if (/^\s*(\/\/|#|--)/.test(line)) continue;
		for (const det of detectors) {
			const m = det.regex.exec(line);
			if (m?.[1]) {
				const key = `${i}:${m[1]}`;
				if (seen.has(key)) continue;
				seen.add(key);
				out.push({ kind: det.kind, name: m[1], line: i });
				break; // one match per line is plenty
			}
		}
	}
	return out;
}

interface SymbolDetector {
	readonly kind: "function" | "class";
	readonly regex: RegExp;
}

/**
 * Per-language detectors. Stateless — every call clones the matcher index
 * via `exec` on a fresh string, so a shared regex constant is safe.
 *
 * Keep these conservative: we'd rather miss a few than litter the gutter
 * with spurious lenses on every `if` / loop / object literal.
 */
const DETECTORS: Record<string, readonly SymbolDetector[]> = {
	typescript: [
		// `function foo(` and `export [async] function foo(`
		{
			kind: "function",
			regex: /^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*[<(]/,
		},
		// `class Foo {` (with optional generics / extends / implements)
		{ kind: "class", regex: /^\s*(?:export\s+)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)/ },
		// Arrow / function expression assigned at module scope: `const foo = (` or `const foo = async (`
		{
			kind: "function",
			regex:
				/^\s*(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*(?::[^=]+)?=\s*(?:async\s+)?(?:function\b|\()/,
		},
		// Class methods: `foo(args) {` or `private foo(`. Common on its own line.
		{
			kind: "function",
			regex:
				/^\s+(?:public\s+|private\s+|protected\s+|static\s+|async\s+|readonly\s+)*([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*[:{]/,
		},
	],
	python: [
		{ kind: "function", regex: /^\s*(?:async\s+)?def\s+([A-Za-z_][\w]*)\s*\(/ },
		{ kind: "class", regex: /^\s*class\s+([A-Za-z_][\w]*)\s*[(:]/ },
	],
	go: [
		// `func foo(` and `func (r *Recv) foo(`
		{ kind: "function", regex: /^\s*func\s+(?:\([^)]+\)\s+)?([A-Za-z_][\w]*)\s*\(/ },
		// Go uses `type Foo struct` / `type Foo interface` — surface as class-y.
		{ kind: "class", regex: /^\s*type\s+([A-Za-z_][\w]*)\s+(?:struct|interface)\b/ },
	],
	rust: [
		// `fn foo(` plus optional pub / async / unsafe / const modifiers
		{
			kind: "function",
			regex:
				/^\s*(?:pub(?:\([^)]+\))?\s+)?(?:const\s+|async\s+|unsafe\s+)*fn\s+([A-Za-z_][\w]*)\s*[<(]/,
		},
		// `impl Foo` / `impl<T> Foo` / `impl Trait for Foo`
		{
			kind: "class",
			regex: /^\s*impl(?:<[^>]*>)?\s+(?:[A-Za-z_:][\w<>]*\s+for\s+)?([A-Za-z_][\w]*)/,
		},
		// `struct Foo`, `enum Foo`, `trait Foo`
		{ kind: "class", regex: /^\s*(?:pub(?:\([^)]+\))?\s+)?(?:struct|enum|trait)\s+([A-Za-z_][\w]*)/ },
	],
};
// JS and JSX share TS detectors (the syntax overlap is more than complete enough).
DETECTORS.javascript = DETECTORS.typescript;
DETECTORS.javascriptreact = DETECTORS.typescript;
DETECTORS.typescriptreact = DETECTORS.typescript;

/**
 * Extract a function's body so the chat command has something meaningful to
 * paste into its prompt. We grab `bodyMaxLines` lines starting at the
 * declaration; for languages with explicit braces we try to match the
 * closing brace; for Python we use indentation.
 */
export function extractSymbolBody(
	text: string,
	startLine: number,
	languageId: string,
	bodyMaxLines = 200,
): string {
	const lines = text.split(/\r?\n/);
	if (startLine < 0 || startLine >= lines.length) return "";

	if (languageId === "python") {
		// Indentation-based: keep lines that are blank OR more indented than the def line.
		const headerIndent = (/^(\s*)/.exec(lines[startLine]) ?? ["", ""])[1].length;
		const collected: string[] = [lines[startLine]];
		for (let i = startLine + 1; i < lines.length && collected.length < bodyMaxLines; i++) {
			const line = lines[i];
			if (line.trim().length === 0) {
				collected.push(line);
				continue;
			}
			const indent = (/^(\s*)/.exec(line) ?? ["", ""])[1].length;
			if (indent <= headerIndent) break;
			collected.push(line);
		}
		return collected.join("\n");
	}

	// Brace-matching for TS/JS/Go/Rust. Scan forward counting `{` and `}`.
	const collected: string[] = [];
	let depth = 0;
	let openedYet = false;
	for (let i = startLine; i < lines.length && collected.length < bodyMaxLines; i++) {
		const line = lines[i];
		collected.push(line);
		for (const ch of line) {
			if (ch === "{") {
				depth++;
				openedYet = true;
			} else if (ch === "}") {
				depth--;
				if (openedYet && depth <= 0) return collected.join("\n");
			}
		}
	}
	return collected.join("\n");
}

/**
 * The actual VS Code provider. Hooked up by extension.ts via
 * `vscode.languages.registerCodeLensProvider`.
 */
export class AiCodeLensProvider implements vscode.CodeLensProvider {
	private readonly emitter = new vscode.EventEmitter<void>();
	readonly onDidChangeCodeLenses = this.emitter.event;

	provideCodeLenses(document: vscode.TextDocument): vscode.CodeLens[] {
		if (!SUPPORTED_LANGUAGES.has(document.languageId)) return [];
		const symbols = detectSymbols(document.getText(), document.languageId);
		const lenses: vscode.CodeLens[] = [];
		for (const sym of symbols) {
			const range = new vscode.Range(sym.line, 0, sym.line, 0);
			const args = [document.uri.toString(), sym.line];
			lenses.push(
				new vscode.CodeLens(range, {
					title: "OATI Code: Explain",
					command: "iom.explainSymbol",
					arguments: args,
				}),
				new vscode.CodeLens(range, {
					title: "Test",
					command: "iom.testSymbol",
					arguments: args,
				}),
				new vscode.CodeLens(range, {
					title: "Refactor",
					command: "iom.refactorSymbol",
					arguments: args,
				}),
			);
		}
		return lenses;
	}

	refresh(): void {
		this.emitter.fire();
	}

	dispose(): void {
		this.emitter.dispose();
	}
}
