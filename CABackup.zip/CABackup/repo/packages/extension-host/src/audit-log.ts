import { createHash } from "node:crypto";
import { promises as fs } from "node:fs";
import * as path from "node:path";

/**
 * Tool-call audit entry. Recorded for every conductor `tool_call` +
 * `tool_result` pair so we can reconstruct "this session made N calls to
 * tool X" without ever persisting the raw arguments.
 */
export interface ToolAuditEntry {
	readonly kind: "tool";
	readonly ts: string;
	readonly sessionId: string;
	readonly mode: string;
	readonly modelId: string;
	readonly toolName: string;
	/** SHA-256 of the JSON-stringified args, truncated to 16 hex chars. */
	readonly argsHash: string;
	readonly resultBytes: number;
	readonly isError: boolean;
	readonly durationMs: number;
}

/**
 * User-message / agent-response audit entry. Records the role, hash of the
 * content (NOT the content itself), byte length, and a rough token count so
 * the audit log can answer "did the model see this prompt?" without leaking
 * the prompt to anyone with read access to `.iom/audit.log`.
 */
export interface MessageAuditEntry {
	readonly kind: "message";
	readonly ts: string;
	readonly sessionId: string;
	readonly role: "user" | "assistant" | "system" | "tool";
	readonly contentHash: string;
	readonly contentBytes: number;
	readonly tokenCount: number;
}

// R5-A: inline-completion telemetry event. Recorded each time a suggestion is
// shown, accepted, or dismissed. We don't store the suggestion text — just the
// byte length and the language id, enough to compute acceptance rates by
// language without leaking source code into the audit trail.
export interface InlineCompletionAuditEntry {
	readonly kind: "inline_completion";
	readonly ts: string;
	readonly event: "shown" | "accepted" | "rejected";
	readonly languageId: string;
	readonly suggestionBytes: number;
	readonly latencyMs: number;
}

export type AuditEntry = ToolAuditEntry | MessageAuditEntry | InlineCompletionAuditEntry;

export interface AuditLogOptions {
	/** When false, all writes are no-ops. Reads still work on a pre-existing file. */
	readonly enabled?: boolean;
}

/**
 * Append-only JSON-Lines audit log at `<workspace>/.iom/audit.log`.
 *
 * Design notes:
 * - Writes are serialized through a single promise chain so concurrent calls
 *   to `record()` don't interleave bytes mid-line (Node's `fs.appendFile`
 *   isn't guaranteed atomic for arbitrary sizes).
 * - `tail()` parses the entire file each call; that's fine because the log is
 *   bounded by audit retention rather than streamed at high rates. If a line
 *   is malformed (e.g. interrupted write) it's silently skipped — the audit
 *   trail is best-effort, not load-bearing for correctness.
 * - We deliberately don't store raw prompts or tool args. Hashes give "did X
 *   happen?" attestation without turning the audit log into a secret store.
 */
export class AuditLog {
	private readonly logPath: string;
	private readonly enabled: boolean;
	private writeChain: Promise<void> = Promise.resolve();

	constructor(workspaceRoot: string, opts: AuditLogOptions = {}) {
		this.logPath = path.join(workspaceRoot, ".iom", "audit.log");
		this.enabled = opts.enabled !== false;
	}

	/** Absolute path of the audit log file. */
	getPath(): string {
		return this.logPath;
	}

	/** True iff `record()` will actually write. */
	isEnabled(): boolean {
		return this.enabled;
	}

	/**
	 * Append a single JSON line. Fire-and-forget at the API level: the caller
	 * doesn't have to await, but doing so guarantees the line is on disk.
	 * Errors are swallowed — the audit log must not break the chat flow.
	 */
	async record(entry: AuditEntry): Promise<void> {
		if (!this.enabled) return;
		const line = `${JSON.stringify(entry)}\n`;
		const prev = this.writeChain;
		this.writeChain = prev
			.catch(() => undefined)
			.then(async () => {
				try {
					await fs.mkdir(path.dirname(this.logPath), { recursive: true });
					await fs.appendFile(this.logPath, line, "utf-8");
				} catch {
					// Best-effort; missing workspace, permission denied, etc. are
					// all "audit log isn't available" rather than fatal errors.
				}
			});
		return this.writeChain;
	}

	/**
	 * Return the last `n` entries (default 100). Corrupt / partial lines are
	 * skipped. If the file doesn't exist yet, returns an empty array.
	 */
	async tail(n = 100): Promise<readonly AuditEntry[]> {
		let raw: string;
		try {
			raw = await fs.readFile(this.logPath, "utf-8");
		} catch {
			return [];
		}
		// JSONL: split on \n, keep non-empty lines, parse each, skip bad ones.
		const out: AuditEntry[] = [];
		const lines = raw.split("\n");
		// Iterate from the end so we can stop once we have `n` valid entries —
		// avoids parsing a multi-GB log when the caller only wants the tail.
		for (let i = lines.length - 1; i >= 0 && out.length < n; i--) {
			const line = lines[i];
			if (!line) continue;
			const parsed = safeParse(line);
			if (parsed) out.unshift(parsed);
		}
		return out;
	}
}

/**
 * SHA-256 the input and return the first 16 hex chars. Truncated digests are
 * fine here because we only need collision-resistance over a single session
 * (a few thousand records), not cryptographic uniqueness across the world.
 */
export function shortHash(input: string): string {
	return createHash("sha256").update(input).digest("hex").slice(0, 16);
}

/** Hash a tool-call arguments object — JSON-stringified, key order preserved. */
export function hashArgs(args: unknown): string {
	let s: string;
	try {
		s = JSON.stringify(args);
	} catch {
		s = String(args);
	}
	return shortHash(s ?? "");
}

/**
 * Rough token estimate — 4 chars per token. Good enough for "did this message
 * exceed N tokens?" filtering in audit reports. Not a billing-grade tokenizer.
 */
export function estimateTokens(text: string): number {
	if (!text) return 0;
	return Math.max(1, Math.ceil(text.length / 4));
}

/** Helper to construct a `ts` value with millisecond resolution. */
export function nowIso(): string {
	return new Date().toISOString();
}

function safeParse(line: string): AuditEntry | undefined {
	try {
		const obj = JSON.parse(line);
		if (!obj || typeof obj !== "object") return undefined;
		// R5-A: include `inline_completion` in the accepted kinds.
		if (obj.kind !== "tool" && obj.kind !== "message" && obj.kind !== "inline_completion")
			return undefined;
		return obj as AuditEntry;
	} catch {
		return undefined;
	}
}
