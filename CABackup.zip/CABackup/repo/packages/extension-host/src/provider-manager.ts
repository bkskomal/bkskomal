import { LoadMonitor, ProviderRegistry } from "@iom/agent-core";
import { createProviderFromConfig, limitProviderConcurrency } from "@iom/providers";
import type {
	ProviderConfig,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
	RootConfig,
} from "@iom/shared";
import { EndpointCapabilityCache } from "./endpoint-capability";
import type { SettingsStore } from "./settings-store";

export class ProviderManager {
	readonly registry = new ProviderRegistry();
	readonly capabilityCache: EndpointCapabilityCache;
	/**
	 * 2026-06-29: per-(providerId, modelId) load monitor. Populated
	 * lazily on first request to a combo. Consulted by chat-panel /
	 * conductor when a mode has `adaptiveContextBudget: true`.
	 */
	readonly loadMonitors = new Map<string, LoadMonitor>();
	/**
	 * 2026-06-29: callback fired when a provider's client-side concurrency
	 * limiter queues a request or grants it a slot. Extension host wires
	 * this to a webview `provider_queue_status` message so users see a
	 * "waiting for slot" chip during pileups. Optional — providers still
	 * work without a listener; only observability is disabled.
	 */
	private queueListeners = new Set<
		(e: {
			providerId: string;
			state: "queued" | "started";
			queueDepth?: number;
			waitedMs?: number;
		}) => void
	>();
	onQueueEvent(
		listener: (e: {
			providerId: string;
			state: "queued" | "started";
			queueDepth?: number;
			waitedMs?: number;
		}) => void,
	): () => void {
		this.queueListeners.add(listener);
		return () => this.queueListeners.delete(listener);
	}

	constructor(
		private readonly settings: SettingsStore,
		globalState: import("vscode").Memento,
	) {
		this.capabilityCache = new EndpointCapabilityCache(globalState);
	}

	/**
	 * Lookup / lazy-create a LoadMonitor for a (providerId, modelId).
	 * Public so the conductor + chat-panel can read the current load
	 * snapshot when deciding whether to override contextBudget.
	 */
	getLoadMonitor(providerId: string, modelId: string): LoadMonitor {
		const key = `${providerId}:${modelId}`;
		let mon = this.loadMonitors.get(key);
		if (!mon) {
			mon = new LoadMonitor();
			this.loadMonitors.set(key, mon);
		}
		return mon;
	}

	async rebuild(): Promise<void> {
		const config = this.settings.config;
		for (const p of this.registry.list()) this.registry.unregister(p.id);
		for (const cfg of config.providers) {
			// Re-probe on every rebuild — base URL / API key / extra headers
			// may have changed and the prior probe result is no longer valid.
			this.capabilityCache.invalidate(cfg.id);
			const apiKey = await this.settings.getApiKey(cfg.id);
			const raw = createProviderFromConfig(cfg, apiKey);
			// Layered wrappers, outer → inner:
			//   1. concurrency limiter (client-side queue if cap set)
			//   2. endpoint capability probe (OpenAI-compat only)
			//   3. raw provider
			// Layering matters: the concurrency limiter must be OUTER so
			// probes and streams share the same slot budget.
			const withProbe = cfg.type === "openai-compatible" ? this.wrapWithProbe(raw, cfg, apiKey) : raw;
			// 2026-06-29: wrap with load-metering so TTFT + effective TPS
			// feed the per-(provider, model) LoadMonitor. Measured INSIDE
			// the concurrency limiter so queue-wait time doesn't pollute
			// the "gateway is slow" signal.
			const withLoadMeter = this.wrapWithLoadMeter(withProbe, cfg.id);
			const withConcurrency = limitProviderConcurrency(withLoadMeter, {
				maxConcurrent: cfg.maxConcurrentRequests,
				onQueueEvent: (e) => {
					// 2026-06-29: fan out to any host-registered listeners
					// (chat-panel forwards to webview so users see a chip).
					// Also keep a debug log for out-of-panel diagnostics.
					if (e.kind === "queued") {
						console.debug(
							`[iom-provider:${cfg.id}] concurrency cap reached, queued (depth=${e.queueDepth})`,
						);
						for (const l of this.queueListeners) {
							l({ providerId: cfg.id, state: "queued", queueDepth: e.queueDepth });
						}
					} else {
						for (const l of this.queueListeners) {
							l({ providerId: cfg.id, state: "started", waitedMs: e.waitedMs });
						}
					}
				},
			});
			this.registry.register(withConcurrency);
		}
	}

	/**
	 * Wrap a provider so its `stream(req)` method consults the capability
	 * cache before forwarding. If no probe result is cached yet for the
	 * (providerId, modelId, baseUrl) tuple, runs the probe synchronously
	 * (~200-800ms one-time cost) and caches the result. Future requests
	 * with the same combo skip the probe entirely.
	 *
	 * When `req.endpointCapability` is already set by the caller, the
	 * wrapper passes through unchanged — useful for forced-mode testing
	 * and for the chat-panel's "Force /v1/completions" debug toggle.
	 */
	/**
	 * 2026-06-29: measure TTFT + generation TPS from provider stream
	 * events and feed the (providerId, modelId) LoadMonitor. Non-
	 * invasive — passes every event through unchanged. Signals
	 * captured:
	 *   - ttfMs: from stream start until the first text_delta /
	 *     reasoning_delta / tool_call event
	 *   - genTps: output tokens per second, from first-token → done,
	 *     using the provider's usage.outputTokens when reported,
	 *     otherwise a char-count fallback.
	 *   - status: "error" when the stream emits any type: "error"
	 *     event, otherwise "ok".
	 */
	private wrapWithLoadMeter(spec: ProviderSpec, providerId: string): ProviderSpec {
		const getMonitor = (modelId: string) => this.getLoadMonitor(providerId, modelId);
		return {
			id: spec.id,
			displayName: spec.displayName,
			async *stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
				const monitor = getMonitor(req.modelId);
				const startedAt = performance.now();
				let firstTokenAt: number | null = null;
				let outputTokens = 0;
				let outputChars = 0;
				let hadError = false;
				try {
					for await (const ev of spec.stream(req)) {
						if (
							firstTokenAt === null &&
							(ev.type === "text_delta" || ev.type === "reasoning_delta" || ev.type === "tool_call")
						) {
							firstTokenAt = performance.now();
						}
						if (ev.type === "text_delta" || ev.type === "reasoning_delta") {
							outputChars += ev.text.length;
						} else if (ev.type === "usage") {
							outputTokens = Math.max(outputTokens, ev.usage.outputTokens);
						} else if (ev.type === "error") {
							hadError = true;
						}
						yield ev;
					}
				} finally {
					const endedAt = performance.now();
					const ttfMs = firstTokenAt !== null ? firstTokenAt - startedAt : 0;
					const genMs = firstTokenAt !== null ? endedAt - firstTokenAt : 0;
					// Prefer provider-reported tokens when available; fall back
					// to chars/4 estimate. Skip TPS calc when no gen time.
					const tokens = outputTokens > 0 ? outputTokens : Math.ceil(outputChars / 4);
					const genTps = genMs > 0 ? (tokens / genMs) * 1000 : 0;
					monitor.record({
						capturedAt: Date.now(),
						ttfMs,
						genTps,
						status: hadError ? "error" : "ok",
					});
				}
			},
		};
	}

	private wrapWithProbe(spec: ProviderSpec, cfg: ProviderConfig, apiKey?: string): ProviderSpec {
		const cache = this.capabilityCache;
		const providerId = cfg.id;
		const baseUrl = cfg.baseUrl;
		const extraHeaders = cfg.extraHeaders;
		return {
			id: spec.id,
			displayName: spec.displayName,
			async *stream(req: ProviderRequest) {
				// Caller-supplied override always wins.
				if (req.endpointCapability) {
					yield* spec.stream(req);
					return;
				}
				let cap = cache.get(providerId, req.modelId, baseUrl);
				if (!cap) {
					cap = await cache.probe(providerId, baseUrl, req.modelId, apiKey, extraHeaders);
				}
				yield* spec.stream({
					...req,
					endpointCapability: { needsCompletionsFallback: cap.needsCompletionsFallback },
				});
			},
		};
	}

	async testConnection(providerId: string): Promise<{ ok: boolean; message?: string }> {
		const cfg = this.settings.config.providers.find((p) => p.id === providerId);
		if (!cfg) return { ok: false, message: "Provider not found" };
		if (!cfg.baseUrl || cfg.baseUrl.trim().length === 0) {
			return { ok: false, message: "Base URL is empty — set it in Settings first." };
		}

		const apiKey = await this.settings.getApiKey(providerId);
		const headers: Record<string, string> = {};
		// Anthropic uses x-api-key + anthropic-version, not Bearer auth.
		if (cfg.type === "anthropic") {
			headers["anthropic-version"] = "2023-06-01";
			if (apiKey) headers["x-api-key"] = apiKey;
		} else if (apiKey) {
			headers.Authorization = `Bearer ${apiKey}`;
		}
		if (cfg.extraHeaders) Object.assign(headers, cfg.extraHeaders);

		const url = `${cfg.baseUrl.replace(/\/$/, "")}/models`;
		try {
			const ctrl = new AbortController();
			const timer = setTimeout(() => ctrl.abort(), 10_000);
			let res: Response;
			try {
				res = await fetch(url, { method: "GET", headers, signal: ctrl.signal });
			} finally {
				clearTimeout(timer);
			}
			if (res.ok) {
				// 2026-06-16: HTTP 200 alone isn't enough — vLLM gateways
				// return 200 + an empty `data: []` array when no model is
				// loaded, and chat requests then 404 with "Model X not
				// found". Parse the body and check that the configured
				// model id is actually in the served list. If anything
				// about parsing fails, fall back to the old "200 = OK"
				// behaviour so non-OpenAI-compatible servers still pass.
				const wantModel = cfg.defaultModel?.trim() ?? "";
				let parsedBody: unknown;
				try {
					parsedBody = await res.json();
				} catch {
					return { ok: true, message: `${url} → ${res.status} ${res.statusText}` };
				}
				const servedIds = extractServedModelIds(parsedBody);
				if (servedIds === undefined) {
					// Non-standard body shape — accept the 200 since we
					// can't responsibly enforce.
					return { ok: true, message: `${url} → ${res.status} ${res.statusText}` };
				}
				if (servedIds.length === 0) {
					return {
						ok: false,
						message: `${url} → 200 OK but the gateway has NO models loaded. vLLM is running but nothing is served. Ask whoever runs the gateway to load the model (e.g. \`vllm serve ${wantModel || "<model-id>"}\`).`,
					};
				}
				if (wantModel && !servedIds.includes(wantModel)) {
					const sample = servedIds.slice(0, 4).join(", ");
					const more = servedIds.length > 4 ? ` (+${servedIds.length - 4} more)` : "";
					return {
						ok: false,
						message: `${url} → 200 OK but "${wantModel}" is NOT in the served model list. Loaded models: ${sample}${more}. Update Model ID to one of these, or ask the gateway operator to load ${wantModel}.`,
					};
				}
				return {
					ok: true,
					message:
						wantModel === ""
							? `${url} → ${res.status} ${res.statusText} (${servedIds.length} model${servedIds.length === 1 ? "" : "s"} available)`
							: `${url} → ${res.status} ${res.statusText} · "${wantModel}" is loaded`,
				};
			}
			let detail = "";
			try {
				const text = await res.text();
				detail = text ? ` — ${text.slice(0, 200).replace(/\s+/g, " ").trim()}` : "";
			} catch {
				// ignore
			}
			return {
				ok: false,
				message: `HTTP ${res.status} ${res.statusText} at ${url}${detail}`,
			};
		} catch (err) {
			return { ok: false, message: formatFetchError(err, url) };
		}
	}

	resolveActiveModelId(config: RootConfig): string {
		const mode = config.modes.find((m) => m.id === config.activeModeId);
		if (mode?.modelId) return mode.modelId;
		const providerId = mode?.providerId ?? config.activeProviderId;
		const provider = config.providers.find((p) => p.id === providerId);
		return provider?.defaultModel ?? "";
	}
}

/**
 * Node's fetch always throws `TypeError: fetch failed` for any network-level
 * problem and stashes the real reason on `err.cause`. Without unpacking that,
 * users see "fetch failed" and have no idea whether it's DNS, proxy, TLS, or
 * a firewall. This helper turns it into something diagnosable, including the
 * per-address failures inside an AggregateError (Happy Eyeballs returns one
 * Error per IP tried).
 */
function formatFetchError(err: unknown, url: string): string {
	if (!(err instanceof Error)) return String(err);
	if (err.name === "AbortError") return `Request timed out hitting ${url} (10s)`;

	const lines: string[] = [];
	const cause = (err as { cause?: unknown }).cause;
	let primaryCode: string | undefined;

	// undici returns AggregateError when it tried multiple addresses (IPv4 + IPv6)
	// and every attempt failed. Each inner error carries .address and .port.
	if (isAggregateError(cause)) {
		lines.push(`${err.message}: ${cause.message || "all connection attempts failed"}`);
		for (const inner of cause.errors) {
			if (!(inner instanceof Error)) continue;
			const code = (inner as { code?: string }).code;
			const address = (inner as { address?: string }).address;
			const port = (inner as { port?: number }).port;
			primaryCode = primaryCode ?? code;
			const where = address ? `${address}${port ? `:${port}` : ""}` : "(unknown address)";
			lines.push(`  ↳ ${code ?? inner.name}: ${where} — ${inner.message}`);
		}
	} else if (cause instanceof Error) {
		primaryCode = (cause as { code?: string }).code;
		const codeSuffix = primaryCode ? ` [${primaryCode}]` : "";
		lines.push(`${err.message}${codeSuffix}: ${cause.message || String(cause)}`);
	} else {
		lines.push(err.message);
	}

	const hint = hintForCode(primaryCode);
	if (hint) lines.push(hint);

	const envNote = describeProxyEnv();
	if (envNote) lines.push(envNote);

	return lines.join("\n");
}

/**
 * 2026-06-16: pull model ids out of an OpenAI-compatible `/v1/models`
 * response. Returns:
 *   - the array of string ids when the body matches the OpenAI shape
 *     (`{object: "list", data: [{id: "..."}, ...]}`)
 *   - `[]` when the body matches the shape but no models are loaded
 *     (vLLM returns this when the process is up but nothing is served)
 *   - `undefined` when the body doesn't look like the standard shape
 *     at all — caller falls back to "200 = OK" rather than reject
 *     valid responses from unusual servers (Ollama, custom gateways).
 */
function extractServedModelIds(body: unknown): readonly string[] | undefined {
	if (typeof body !== "object" || body === null) return undefined;
	const obj = body as { data?: unknown; object?: unknown };
	if (!Array.isArray(obj.data)) return undefined;
	const ids: string[] = [];
	for (const entry of obj.data) {
		if (typeof entry !== "object" || entry === null) continue;
		const id = (entry as { id?: unknown }).id;
		if (typeof id === "string" && id.length > 0) ids.push(id);
	}
	// Return [] (not undefined) when the shape is right but the list is
	// empty — that's the actionable failure case the caller wants to
	// distinguish from "non-standard server".
	if (ids.length === 0 && obj.object === "list") return [];
	if (ids.length === 0) return undefined;
	return ids;
}

function isAggregateError(v: unknown): v is AggregateError {
	return (
		typeof AggregateError !== "undefined" &&
		v instanceof Error &&
		Array.isArray((v as { errors?: unknown }).errors)
	);
}

function describeProxyEnv(): string {
	const proxy =
		process.env.HTTPS_PROXY ??
		process.env.https_proxy ??
		process.env.HTTP_PROXY ??
		process.env.http_proxy ??
		process.env.ALL_PROXY ??
		process.env.all_proxy;
	if (proxy) {
		return `Note: a proxy is configured via env (${proxy}). If that proxy isn't actually running, every outbound connection will be refused. Verify it's reachable, or unset the env var.`;
	}
	return "";
}

function hintForCode(code: string | undefined): string {
	switch (code) {
		case "ENOTFOUND":
			return "DNS lookup failed — check the Base URL hostname, your internet connection, or DNS settings.";
		case "ECONNREFUSED":
			return [
				"Connection refused — the address responded but rejected the TCP connection. Common causes:",
				"  • Your local DNS or hosts file is mapping this host to localhost or another non-listening IP.",
				"    Run `nslookup openrouter.ai` (or whichever host) — if you see 127.0.0.1 or ::1, that's the problem.",
				"  • A proxy/web-shield/AV is intercepting the connection but the local listener isn't active.",
				"  • If HTTPS_PROXY is set to a local proxy, make sure that proxy is actually running.",
				"  • Quick sanity check from any terminal: `curl -I https://openrouter.ai/api/v1/models`",
			].join("\n");
		case "ECONNRESET":
		case "UND_ERR_SOCKET":
			return "Connection was reset mid-handshake — often a firewall, VPN, or proxy interrupting TLS.";
		case "ETIMEDOUT":
		case "UND_ERR_CONNECT_TIMEOUT":
			return "Connection timed out — likely a firewall or VPN. If you're behind a corporate proxy, set HTTPS_PROXY before launching VS Code.";
		case "DEPTH_ZERO_SELF_SIGNED_CERT":
		case "SELF_SIGNED_CERT_IN_CHAIN":
		case "UNABLE_TO_VERIFY_LEAF_SIGNATURE":
			return "TLS certificate could not be verified. If you're behind a corporate proxy that rewrites TLS, you may need to set NODE_EXTRA_CA_CERTS.";
		case "EPROTO":
			return "TLS protocol error — version mismatch between client and server.";
		default:
			return "";
	}
}
