// R6-B: notebook bridge — implements the `NotebookProvider` contract from
// `@iom/shared` against VS Code's notebook API. Read/edit operations open the
// notebook document (so live editor instances stay in sync); execute uses
// `notebook.cell.execute` which delegates to whichever kernel is attached.
//
// Coordinate conventions:
//   - cell indices are 0-based, matching VS Code's `NotebookCell.index`.
//   - `path` follows the same rules as the rest of the host context: absolute
//     or relative to the first workspace folder.
import * as path from "node:path";
import type { NotebookCellSnapshot, NotebookProvider } from "@iom/shared";
import * as vscode from "vscode";

function resolveUri(p: string): vscode.Uri {
	if (path.isAbsolute(p)) return vscode.Uri.file(p);
	const root = vscode.workspace.workspaceFolders?.[0]?.uri;
	if (!root) throw new Error("notebook-bridge: no workspace folder open");
	return vscode.Uri.joinPath(root, p);
}

/**
 * Convert a `vscode.NotebookCell` into a transport-friendly snapshot.
 *
 * `outputs` is omitted entirely when `includeOutputs=false` so the read tool
 * can keep payloads tight by default. When included, each VS Code output item
 * is decoded once (best-effort utf-8) and emitted as `{mime, text}`.
 */
function toSnapshot(cell: vscode.NotebookCell, includeOutputs: boolean): NotebookCellSnapshot {
	const kind: "code" | "markdown" =
		cell.kind === vscode.NotebookCellKind.Markup ? "markdown" : "code";
	const language = cell.document.languageId;
	const source = cell.document.getText();
	if (!includeOutputs) {
		return { index: cell.index, kind, language, source };
	}
	const outputs: { mime: string; text: string }[] = [];
	for (const out of cell.outputs) {
		for (const item of out.items) {
			outputs.push({
				mime: item.mime,
				text: decodeOutput(item.data),
			});
		}
	}
	return { index: cell.index, kind, language, source, outputs };
}

const decoder = new TextDecoder("utf-8", { fatal: false });

function decodeOutput(data: Uint8Array): string {
	try {
		return decoder.decode(data);
	} catch {
		return "";
	}
}

/**
 * Open a notebook document for the given path. We deliberately use
 * `openNotebookDocument(uri)` rather than re-using the active editor so the
 * bridge works the same way whether or not the user has the notebook focused.
 */
async function openNotebook(p: string): Promise<vscode.NotebookDocument> {
	const uri = resolveUri(p);
	return vscode.workspace.openNotebookDocument(uri);
}

export function createNotebookProvider(): NotebookProvider {
	return {
		async read(p: string, includeOutputs?: boolean): Promise<readonly NotebookCellSnapshot[]> {
			const nb = await openNotebook(p);
			const want = includeOutputs === true;
			const out: NotebookCellSnapshot[] = [];
			for (let i = 0; i < nb.cellCount; i++) {
				out.push(toSnapshot(nb.cellAt(i), want));
			}
			return out;
		},

		async editCell(p: string, index: number, source: string): Promise<void> {
			const nb = await openNotebook(p);
			if (index < 0 || index >= nb.cellCount) {
				throw new Error(
					`edit_notebook_cell: index ${index} out of range (notebook has ${nb.cellCount} cells)`,
				);
			}
			const existing = nb.cellAt(index);
			const replacement = new vscode.NotebookCellData(
				existing.kind,
				source,
				existing.document.languageId,
			);
			// Preserve outputs — replacing only the source shouldn't blow away the
			// last execution's results. Metadata is left at defaults; the live cell
			// keeps whatever VS Code already had attached.
			replacement.outputs = [...existing.outputs];
			const edit = new vscode.WorkspaceEdit();
			edit.set(nb.uri, [
				vscode.NotebookEdit.replaceCells(new vscode.NotebookRange(index, index + 1), [replacement]),
			]);
			const ok = await vscode.workspace.applyEdit(edit);
			if (!ok) throw new Error("edit_notebook_cell: VS Code refused to apply the edit");
		},

		async insertCell(
			p: string,
			index: number,
			kind: "code" | "markdown",
			source: string,
			language?: string,
		): Promise<void> {
			const nb = await openNotebook(p);
			if (index < 0 || index > nb.cellCount) {
				throw new Error(
					`insert_notebook_cell: index ${index} out of range (0..${nb.cellCount} inclusive)`,
				);
			}
			const cellKind =
				kind === "markdown" ? vscode.NotebookCellKind.Markup : vscode.NotebookCellKind.Code;
			const lang =
				kind === "markdown"
					? "markdown"
					: (language ?? nb.metadata?.language_info?.name ?? nb.cellCount > 0)
						? nb.cellAt(Math.min(index, nb.cellCount - 1)).document.languageId
						: "python";
			const data = new vscode.NotebookCellData(cellKind, source, lang as string);
			const edit = new vscode.WorkspaceEdit();
			edit.set(nb.uri, [vscode.NotebookEdit.insertCells(index, [data])]);
			const ok = await vscode.workspace.applyEdit(edit);
			if (!ok) throw new Error("insert_notebook_cell: VS Code refused to apply the edit");
		},

		async deleteCell(p: string, index: number): Promise<void> {
			const nb = await openNotebook(p);
			if (index < 0 || index >= nb.cellCount) {
				throw new Error(
					`delete_notebook_cell: index ${index} out of range (notebook has ${nb.cellCount} cells)`,
				);
			}
			const edit = new vscode.WorkspaceEdit();
			edit.set(nb.uri, [vscode.NotebookEdit.deleteCells(new vscode.NotebookRange(index, index + 1))]);
			const ok = await vscode.workspace.applyEdit(edit);
			if (!ok) throw new Error("delete_notebook_cell: VS Code refused to apply the edit");
		},

		async runCell(
			p: string,
			index: number,
		): Promise<readonly { readonly mime: string; readonly text: string }[]> {
			const nb = await openNotebook(p);
			if (index < 0 || index >= nb.cellCount) {
				throw new Error(
					`run_notebook_cell: index ${index} out of range (notebook has ${nb.cellCount} cells)`,
				);
			}
			await vscode.commands.executeCommand("notebook.cell.execute", {
				ranges: [{ start: index, end: index + 1 }],
				document: nb.uri,
			});
			// After execute resolves, re-read the cell so we surface freshly-attached
			// outputs. VS Code's execute command awaits the kernel by default, so by
			// the time we're here the outputs map should be populated.
			const snap = toSnapshot(nb.cellAt(index), true);
			return snap.outputs ?? [];
		},
	};
}
