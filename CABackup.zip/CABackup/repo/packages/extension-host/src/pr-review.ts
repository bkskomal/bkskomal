// R3-C: PR review mode.
//
// Drives a one-shot agent turn that produces a structured code review for a
// GitHub pull request. Metadata + the unified diff are fetched via the `gh`
// CLI (so we inherit the user's existing auth) and folded into a tailored
// system prompt. Streaming uses the same `Conductor.spawn` path as a normal
// chat turn, which means the webview renders the review identically to any
// other assistant reply.
//
// Optionally posts the review back to GitHub as a PR comment via
// `gh pr review --comment`. The post step is gated behind a HostContext
// approval prompt so the user always has the final say.

import type { Conductor } from "@iom/agent-core";
import type { ConversationMessage, HostContext, ModeConfig, ProviderConfig } from "@iom/shared";

/** Parsed GitHub PR coordinate. */
export interface ParsedPrUrl {
	readonly owner: string;
	readonly repo: string;
	readonly number: number;
}

/**
 * Parse a GitHub PR URL like `https://github.com/owner/repo/pull/123` (with or
 * without trailing path/query). Returns undefined if the URL doesn't match the
 * expected shape so callers can surface a friendly error.
 */
export function parsePrUrl(raw: string): ParsedPrUrl | undefined {
	const trimmed = raw.trim();
	const m =
		/^https?:\/\/(?:www\.)?github\.com\/([^/]+)\/([^/]+)\/pull\/(\d+)\b/i.exec(trimmed) ??
		/^([^/\s]+)\/([^/\s#]+)#(\d+)$/.exec(trimmed);
	if (!m) return undefined;
	const owner = m[1];
	const repo = m[2].replace(/\.git$/i, "");
	const number = Number.parseInt(m[3], 10);
	if (!Number.isFinite(number) || number <= 0) return undefined;
	return { owner, repo, number };
}

/** Best-effort GitHub PR metadata pulled from `gh pr view --json …`. */
export interface PrMetadata {
	readonly title: string;
	readonly body: string;
	readonly files: readonly {
		readonly path: string;
		readonly additions: number;
		readonly deletions: number;
	}[];
	readonly additions: number;
	readonly deletions: number;
	readonly headRefName: string;
	readonly baseRefName: string;
}

interface GhJsonFile {
	readonly path?: unknown;
	readonly additions?: unknown;
	readonly deletions?: unknown;
}

interface GhJsonResult {
	readonly title?: unknown;
	readonly body?: unknown;
	readonly files?: unknown;
	readonly additions?: unknown;
	readonly deletions?: unknown;
	readonly headRefName?: unknown;
	readonly baseRefName?: unknown;
}

/** Bag of callbacks the chat-panel passes in so we don't reach into private state. */
export interface PrReviewDeps {
	readonly host: HostContext;
	readonly conductor: Conductor;
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly providerId: ProviderConfig["id"];
	readonly history: readonly ConversationMessage[];
	readonly signal?: AbortSignal;
	/**
	 * Captures the final assistant text emitted during the agent turn so the
	 * caller can post it as a GitHub comment after the user approves.
	 */
	captureSummary?(text: string): void;
}

export interface PrReviewResult {
	readonly status: "ok" | "error" | "cancelled";
	readonly message?: string;
	readonly summary?: string;
	readonly history: readonly ConversationMessage[];
}

/**
 * System prompt used for the review agent turn. Exported so tests can pin the
 * wording — the structure is what the webview's downstream rendering depends
 * on (3 numbered sections).
 */
export const PR_REVIEW_SYSTEM_PROMPT = [
	"You are a senior engineer doing a code review.",
	"",
	"Read the PR title, description, and the unified diff that follow, then",
	"produce a review with exactly three sections:",
	"",
	"  (1) **High-level summary** — what the PR is doing in 2-4 sentences.",
	"  (2) **Per-file issues** — for each touched file, call out concrete",
	"      problems with `path:line` references. Use a bullet per issue.",
	"  (3) **Blocking concerns vs nitpicks** — split the issues from (2) into",
	"      two short lists. Be honest about what would actually block merging.",
	"",
	"Be concise. Don't restate the diff. Don't praise without specifics. If",
	"the PR looks clean, say so and skip empty sections.",
].join("\n");

/**
 * Run a PR review. Resolves once the agent turn has streamed to completion.
 * Caller is responsible for showing the streamed events (they arrive on the
 * conductor listener attached by the chat-panel).
 */
export async function reviewPullRequest(
	opts: {
		readonly url: string;
		readonly postComments?: boolean;
	},
	deps: PrReviewDeps,
): Promise<PrReviewResult> {
	const parsed = parsePrUrl(opts.url);
	if (!parsed) {
		return {
			status: "error",
			message: `Could not parse PR URL: ${opts.url}. Expected https://github.com/owner/repo/pull/NN.`,
			history: deps.history,
		};
	}

	// Detect `gh` first so we can surface a friendly install hint rather than
	// a raw "command not found" buried in a tool result.
	const probeCmd = process.platform === "win32" ? "where gh" : "command -v gh";
	const probe = await deps.host.exec(probeCmd, { timeoutMs: 10_000 });
	if (probe.exitCode !== 0) {
		return {
			status: "error",
			message:
				"GitHub CLI (`gh`) is not installed or not on PATH. Install from https://cli.github.com/ and run `gh auth login`, then retry.",
			history: deps.history,
		};
	}

	const repoSpec = `${parsed.owner}/${parsed.repo}`;
	const metaCmd = [
		"gh",
		"pr",
		"view",
		String(parsed.number),
		"--json",
		"title,body,files,additions,deletions,headRefName,baseRefName",
		"-R",
		quoteArg(repoSpec),
	].join(" ");
	const metaRes = await deps.host.exec(metaCmd, { timeoutMs: 30_000 });
	if (metaRes.exitCode !== 0) {
		const stderr = metaRes.stderr.trim();
		let hint = "";
		if (/not.*authenticated|gh auth login/i.test(stderr)) {
			hint = " Tip: run `gh auth login` first.";
		} else if (/could not resolve to a PullRequest/i.test(stderr) || /not found/i.test(stderr)) {
			hint = " Tip: check the PR URL and that you have access to the repo.";
		}
		return {
			status: "error",
			message: `gh pr view failed (exit ${metaRes.exitCode}).${hint}\n${stderr || metaRes.stdout}`,
			history: deps.history,
		};
	}

	let metadata: PrMetadata;
	try {
		metadata = parseGhJson(metaRes.stdout);
	} catch (err) {
		return {
			status: "error",
			message: `gh pr view returned malformed JSON: ${err instanceof Error ? err.message : String(err)}`,
			history: deps.history,
		};
	}

	const diffCmd = ["gh", "pr", "diff", String(parsed.number), "-R", quoteArg(repoSpec)].join(" ");
	const diffRes = await deps.host.exec(diffCmd, { timeoutMs: 60_000 });
	if (diffRes.exitCode !== 0) {
		return {
			status: "error",
			message: `gh pr diff failed (exit ${diffRes.exitCode}). ${diffRes.stderr.trim() || diffRes.stdout}`,
			history: deps.history,
		};
	}

	const reviewPrompt = buildReviewPrompt(parsed, metadata, diffRes.stdout);

	// Run the agent with a tailored system prompt. We override the active
	// mode's prompt but keep its tools/iteration cap so the model can use
	// `read_file` etc. if it wants to dig deeper than the diff alone.
	const reviewMode: ModeConfig = {
		...deps.mode,
		systemPrompt: PR_REVIEW_SYSTEM_PROMPT,
		enablePlanner: false,
		enableCritic: false,
	};

	try {
		const updated = await deps.conductor.spawn({
			mode: { ...reviewMode, providerId: deps.providerId },
			modelId: deps.modelId,
			userMessage: reviewPrompt,
			history: deps.history,
			...(deps.signal ? { signal: deps.signal } : {}),
		});
		const summary = extractFinalAssistantText(updated);
		deps.captureSummary?.(summary);

		if (opts.postComments) {
			const approved = await deps.host.requestApproval({
				toolName: "gh pr review",
				args: { url: opts.url, number: parsed.number },
				summary: `Post review as a PR comment on ${repoSpec}#${parsed.number}?`,
				preview: {
					note: [
						`Posting to: ${repoSpec}#${parsed.number}`,
						"",
						summary.length > 600 ? `${summary.slice(0, 600)}…` : summary,
					].join("\n"),
				},
			});
			if (!approved) {
				return {
					status: "ok",
					summary,
					message: "Review generated. User declined to post the comment.",
					history: updated,
				};
			}
			const tmpFile = await writeTempBody(deps.host, summary);
			const postCmd = [
				"gh",
				"pr",
				"review",
				String(parsed.number),
				"--comment",
				"-b",
				`@${quoteArg(tmpFile)}`,
				"-R",
				quoteArg(repoSpec),
			].join(" ");
			const postRes = await deps.host.exec(postCmd, { timeoutMs: 30_000 });
			if (postRes.exitCode !== 0) {
				return {
					status: "error",
					summary,
					message: `Posting comment failed: ${postRes.stderr.trim() || postRes.stdout}`,
					history: updated,
				};
			}
		}

		return { status: "ok", summary, history: updated };
	} catch (err) {
		if (deps.signal?.aborted) {
			return { status: "cancelled", history: deps.history };
		}
		const message = err instanceof Error ? err.message : String(err);
		return { status: "error", message, history: deps.history };
	}
}

function buildReviewPrompt(parsed: ParsedPrUrl, meta: PrMetadata, diff: string): string {
	const fileLines = meta.files
		.slice(0, 50)
		.map((f) => `- ${f.path} (+${f.additions}/-${f.deletions})`)
		.join("\n");
	const truncatedFiles =
		meta.files.length > 50 ? `\n…and ${meta.files.length - 50} more files.` : "";
	// Cap the diff at ~120 KB so we don't blow up the provider context on
	// monster PRs. The model still gets the file list above for context.
	const MAX_DIFF_CHARS = 120_000;
	const diffBody =
		diff.length > MAX_DIFF_CHARS
			? `${diff.slice(0, MAX_DIFF_CHARS)}\n\n…diff truncated (${diff.length - MAX_DIFF_CHARS} more chars elided)…`
			: diff;
	return [
		`# PR ${parsed.owner}/${parsed.repo}#${parsed.number}`,
		`Title: ${meta.title}`,
		`Base: ${meta.baseRefName}  ←  Head: ${meta.headRefName}`,
		`Totals: +${meta.additions}/-${meta.deletions}`,
		"",
		"## Description",
		meta.body.trim().length > 0 ? meta.body.trim() : "_(no description)_",
		"",
		"## Files touched",
		fileLines.length > 0 ? fileLines : "_(no files)_",
		truncatedFiles,
		"",
		"## Unified diff",
		"```diff",
		diffBody,
		"```",
		"",
		"Now produce the review per the instructions in the system prompt.",
	].join("\n");
}

function parseGhJson(raw: string): PrMetadata {
	const obj = JSON.parse(raw) as GhJsonResult;
	const filesRaw = Array.isArray(obj.files) ? (obj.files as GhJsonFile[]) : [];
	const files = filesRaw
		.map((f) => ({
			path: typeof f.path === "string" ? f.path : "",
			additions: typeof f.additions === "number" ? f.additions : 0,
			deletions: typeof f.deletions === "number" ? f.deletions : 0,
		}))
		.filter((f) => f.path.length > 0);
	return {
		title: typeof obj.title === "string" ? obj.title : "",
		body: typeof obj.body === "string" ? obj.body : "",
		files,
		additions: typeof obj.additions === "number" ? obj.additions : 0,
		deletions: typeof obj.deletions === "number" ? obj.deletions : 0,
		headRefName: typeof obj.headRefName === "string" ? obj.headRefName : "",
		baseRefName: typeof obj.baseRefName === "string" ? obj.baseRefName : "",
	};
}

function extractFinalAssistantText(history: readonly ConversationMessage[]): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const chunks: string[] = [];
		for (const p of msg.parts) if (p.kind === "text") chunks.push(p.text);
		const text = chunks.join("");
		if (text.trim().length > 0) return text;
	}
	return "";
}

function quoteArg(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

/**
 * Write the review body to a temp file under the workspace's `.iom/` dir so we
 * can hand it to `gh pr review -b @<file>` without shell-quoting issues on
 * multiline markdown. Falls back to inlining (with best-effort escaping) when
 * there's no workspace folder available.
 */
async function writeTempBody(host: HostContext, body: string): Promise<string> {
	const root = host.workspaceRoot();
	if (!root) {
		// No workspace — caller will end up passing the raw body via @-file path
		// that doesn't exist. We tolerate that by inlining via a sentinel that the
		// shell will treat as "string starting with @": the body just gets posted
		// as the literal contents. Acceptable fallback since the no-workspace
		// case is rare and the alternative is a failed exec.
		return body;
	}
	const rel = `.iom/pr-review-${Date.now()}.md`;
	await host.writeFile(rel, body);
	// Return an absolute path so the @-file path resolves regardless of the
	// shell's cwd at the time `gh` runs.
	const sep = process.platform === "win32" ? "\\" : "/";
	return `${root}${sep}${rel.replace(/\//g, sep)}`;
}
