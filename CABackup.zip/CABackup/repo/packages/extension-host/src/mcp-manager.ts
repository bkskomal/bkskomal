import type { ToolRegistry } from "@iom/agent-core";
import { HttpTransport, McpClient, registerMcpTools } from "@iom/mcp-client";
import type { McpServerConfig } from "@iom/shared";
import type * as vscode from "vscode";

interface ActiveServer {
	readonly id: string;
	readonly client: McpClient;
	readonly toolNames: readonly string[];
}

export class McpManager {
	private active = new Map<string, ActiveServer>();

	constructor(
		private readonly tools: ToolRegistry,
		private readonly output: vscode.OutputChannel,
	) {}

	async syncWith(servers: readonly McpServerConfig[]): Promise<void> {
		const wantedIds = new Set(servers.filter((s) => s.enabled).map((s) => s.id));

		// Stop servers that should no longer run
		for (const [id, srv] of this.active.entries()) {
			if (!wantedIds.has(id)) {
				this.stopServer(srv);
				this.active.delete(id);
			}
		}

		// Start new ones
		for (const cfg of servers) {
			if (!cfg.enabled) continue;
			if (this.active.has(cfg.id)) continue;
			try {
				await this.startServer(cfg);
			} catch (err) {
				this.output.appendLine(
					`[mcp] server '${cfg.id}' failed to start: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
	}

	dispose(): void {
		for (const srv of this.active.values()) this.stopServer(srv);
		this.active.clear();
	}

	private async startServer(cfg: McpServerConfig): Promise<void> {
		// 2026-05-25 (Phase 4 polish): select transport based on the
		// new `transport` discriminator on McpServerConfig. Default
		// stays "stdio" when the field is omitted, so every existing
		// config keeps working without migration.
		const transport = cfg.transport ?? "stdio";
		let client: McpClient;
		if (transport === "http") {
			if (!cfg.url) {
				throw new Error(`[mcp] '${cfg.id}': transport=http requires 'url' to be set`);
			}
			this.output.appendLine(`[mcp] starting '${cfg.id}' (http): ${cfg.url}`);
			client = new McpClient(
				new HttpTransport({
					url: cfg.url,
					...(cfg.headers ? { headers: cfg.headers } : {}),
				}),
			);
		} else {
			if (!cfg.command) {
				throw new Error(`[mcp] '${cfg.id}': transport=stdio requires 'command' to be set`);
			}
			this.output.appendLine(
				`[mcp] starting '${cfg.id}' (stdio): ${cfg.command} ${(cfg.args ?? []).join(" ")}`,
			);
			client = new McpClient({
				command: cfg.command,
				args: cfg.args ? [...cfg.args] : undefined,
				env: cfg.env,
			});
		}
		const info = await client.start();
		this.output.appendLine(
			`[mcp] connected to '${cfg.id}' (${info.serverInfo.name} ${info.serverInfo.version})`,
		);
		const toolNames = await registerMcpTools(client, this.tools, {
			namePrefix: `mcp_${cfg.id}_`,
			approval: cfg.approval ?? "prompt",
		});
		this.output.appendLine(
			`[mcp] '${cfg.id}' registered ${toolNames.length} tool(s): ${toolNames.join(", ")}`,
		);
		this.active.set(cfg.id, { id: cfg.id, client, toolNames });
	}

	private stopServer(srv: ActiveServer): void {
		this.output.appendLine(`[mcp] stopping '${srv.id}'`);
		for (const name of srv.toolNames) this.tools.unregister(name);
		srv.client.close();
	}
}
