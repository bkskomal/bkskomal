/**
 * Cross-IDE-host session import.
 *
 * OATI persists its session index + per-session history in `KvStorage`, which
 * the VS Code shell backs with `context.globalState`. Under the hood, VS Code
 * (and every fork — Antigravity, Cursor, VS Code Insiders, VSCodium) keeps
 * Memento state in a SQLite file at:
 *
 *   <userDataDir>/User/globalStorage/state.vscdb
 *
 * with one row per extension keyed by `<publisher>.<name>` ("ItemTable",
 * value = JSON blob of every kv pair the extension has written).
 *
 * Because each IDE host has its own `userDataDir`, sessions written while
 * running in one host don't appear when the extension activates in another.
 * This module reads peer hosts' `state.vscdb` files directly and produces an
 * importable catalog. Imports go through `SessionStore.saveImported(...)` so
 * sessions are minted with fresh ids in the current host (no overwrite, no
 * conflict).
 */
import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";
import type { ConversationMessage, SessionMeta } from "@iom/shared";
import Database from "better-sqlite3";

/** Extension id key under which OATI's globalState rows live in ItemTable. */
const OATI_EXTENSION_KEY = "oati.oati-coding-assistant";
const SESSION_INDEX_PREFIX = "oati.session-index.v2.";
const SESSION_DATA_PREFIX = "oati.session-data.v2.";

export interface PeerHostCandidate {
	/** Human label shown in the QuickPick ("VS Code", "Antigravity", ...). */
	readonly label: string;
	/** Absolute path to the host's `User/globalStorage/state.vscdb`. */
	readonly dbPath: string;
}

export interface PeerWorkspaceSessions {
	/** The raw workspaceId key suffix (URI string from `vscode.workspaceFolders[0].uri.toString()`). */
	readonly workspaceId: string;
	/** Best-effort human label derived from the workspaceId (basename of the file: URI, or "_global"). */
	readonly workspaceLabel: string;
	readonly sessions: readonly SessionMeta[];
}

export interface PeerCatalog {
	readonly candidate: PeerHostCandidate;
	readonly workspaces: readonly PeerWorkspaceSessions[];
	/** Total session count across all workspaces in this host. */
	readonly totalSessions: number;
}

/**
 * Per-platform list of (label, userDataDir) for every VS Code-family IDE we
 * know how to peek into. We don't probe arbitrary paths — keeping the list
 * explicit means the UI gets stable, recognizable labels and we don't accidentally
 * read unrelated SQLite databases.
 */
function candidateUserDataDirs(): readonly { label: string; userDataDir: string }[] {
	const home = os.homedir();
	if (process.platform === "win32") {
		const appdata = process.env.APPDATA ?? path.join(home, "AppData", "Roaming");
		return [
			{ label: "VS Code", userDataDir: path.join(appdata, "Code") },
			{ label: "VS Code Insiders", userDataDir: path.join(appdata, "Code - Insiders") },
			{ label: "Cursor", userDataDir: path.join(appdata, "Cursor") },
			{ label: "Antigravity", userDataDir: path.join(appdata, "Antigravity") },
			{ label: "VSCodium", userDataDir: path.join(appdata, "VSCodium") },
			{ label: "Windsurf", userDataDir: path.join(appdata, "Windsurf") },
		];
	}
	if (process.platform === "darwin") {
		const appSupport = path.join(home, "Library", "Application Support");
		return [
			{ label: "VS Code", userDataDir: path.join(appSupport, "Code") },
			{ label: "VS Code Insiders", userDataDir: path.join(appSupport, "Code - Insiders") },
			{ label: "Cursor", userDataDir: path.join(appSupport, "Cursor") },
			{ label: "Antigravity", userDataDir: path.join(appSupport, "Antigravity") },
			{ label: "VSCodium", userDataDir: path.join(appSupport, "VSCodium") },
			{ label: "Windsurf", userDataDir: path.join(appSupport, "Windsurf") },
		];
	}
	const xdg = process.env.XDG_CONFIG_HOME ?? path.join(home, ".config");
	return [
		{ label: "VS Code", userDataDir: path.join(xdg, "Code") },
		{ label: "VS Code Insiders", userDataDir: path.join(xdg, "Code - Insiders") },
		{ label: "Cursor", userDataDir: path.join(xdg, "Cursor") },
		{ label: "Antigravity", userDataDir: path.join(xdg, "Antigravity") },
		{ label: "VSCodium", userDataDir: path.join(xdg, "VSCodium") },
		{ label: "Windsurf", userDataDir: path.join(xdg, "Windsurf") },
	];
}

/**
 * List every peer host on this machine whose `state.vscdb` exists. The
 * `excludeUserDataDir` argument lets the caller filter out the host the
 * current process is running in (so users don't accidentally import their
 * own sessions on top of themselves).
 */
export function discoverPeerHosts(excludeUserDataDir?: string): readonly PeerHostCandidate[] {
	const exclude = excludeUserDataDir ? path.resolve(excludeUserDataDir) : undefined;
	const out: PeerHostCandidate[] = [];
	for (const c of candidateUserDataDirs()) {
		if (exclude && path.resolve(c.userDataDir) === exclude) continue;
		const dbPath = path.join(c.userDataDir, "User", "globalStorage", "state.vscdb");
		if (!fs.existsSync(dbPath)) continue;
		out.push({ label: c.label, dbPath });
	}
	return out;
}

/**
 * Open the peer host's globalState SQLite, pull the OATI extension's row,
 * and slice it into per-workspace session lists. Returns `undefined` if the
 * host has no OATI data at all. Throws if the database can't be opened
 * (locked, corrupt, etc.); callers should surface that to the user.
 */
export function readPeerCatalog(candidate: PeerHostCandidate): PeerCatalog | undefined {
	const db = new Database(candidate.dbPath, { readonly: true, fileMustExist: true });
	try {
		const row = db.prepare("SELECT value FROM ItemTable WHERE key = ?").get(OATI_EXTENSION_KEY) as
			| { value: Buffer | string }
			| undefined;
		if (!row) return undefined;
		const text = typeof row.value === "string" ? row.value : Buffer.from(row.value).toString("utf-8");
		const parsed = JSON.parse(text) as Record<string, unknown>;
		const workspaces: PeerWorkspaceSessions[] = [];
		let total = 0;
		for (const [key, value] of Object.entries(parsed)) {
			if (!key.startsWith(SESSION_INDEX_PREFIX)) continue;
			const workspaceId = key.slice(SESSION_INDEX_PREFIX.length);
			const idx = value as { sessions?: readonly SessionMeta[] } | undefined;
			const sessions = Array.isArray(idx?.sessions) ? idx.sessions : [];
			if (sessions.length === 0) continue;
			workspaces.push({
				workspaceId,
				workspaceLabel: workspaceLabelFromId(workspaceId),
				sessions,
			});
			total += sessions.length;
		}
		workspaces.sort((a, b) => a.workspaceLabel.localeCompare(b.workspaceLabel));
		return { candidate, workspaces, totalSessions: total };
	} finally {
		db.close();
	}
}

/**
 * Pull the conversation history for a specific (workspaceId, sessionId) out
 * of the same OATI extension row. Returns `[]` if the data key isn't present
 * (orphaned index entry — rare but possible if the user nuked the data key
 * manually).
 */
export function readPeerSessionHistory(
	candidate: PeerHostCandidate,
	workspaceId: string,
	sessionId: string,
): ConversationMessage[] {
	const db = new Database(candidate.dbPath, { readonly: true, fileMustExist: true });
	try {
		const row = db.prepare("SELECT value FROM ItemTable WHERE key = ?").get(OATI_EXTENSION_KEY) as
			| { value: Buffer | string }
			| undefined;
		if (!row) return [];
		const text = typeof row.value === "string" ? row.value : Buffer.from(row.value).toString("utf-8");
		const parsed = JSON.parse(text) as Record<string, unknown>;
		const dataKey = `${SESSION_DATA_PREFIX}${workspaceId}.${sessionId}`;
		const history = parsed[dataKey];
		return Array.isArray(history) ? (history as ConversationMessage[]) : [];
	} finally {
		db.close();
	}
}

/**
 * Derive a friendly label for a workspaceId. The id is typically a `file:`
 * URI; we extract the trailing path segment so users see "OATICode" rather
 * than `file:///e%3A/OATICode`. `_global` (the fallback when no workspace is
 * open) is shown as "(no workspace)".
 */
export function workspaceLabelFromId(workspaceId: string): string {
	if (workspaceId === "_global") return "(no workspace)";
	try {
		const decoded = decodeURIComponent(workspaceId);
		const noScheme = decoded.replace(/^file:\/\/+/, "");
		const last = noScheme.split(/[/\\]/).filter(Boolean).pop();
		return last && last.length > 0 ? last : workspaceId;
	} catch {
		return workspaceId;
	}
}
