// R6-C: AI commit message generation.
//
// Reads the staged diff via `git diff --staged`, asks the active model for a
// Conventional Commits-style message, and returns a parsed `{ subject, body }`
// pair. Wired into VS Code via the `iom.generateCommitMessage` command (see
// `extension.ts`), which populates the SCM input box with the result.
//
// The host-side helpers here are deliberately framework-agnostic (no
// `vscode` import) so they're easy to unit-test. The command wiring that
// actually pokes at the git extension lives at the bottom and is the only
// part that depends on VS Code's runtime.

import type { Conductor } from "@iom/agent-core";
import type { HostContext, ModeConfig, ProviderConfig } from "@iom/shared";

/** Result of `generateCommitMessage`. */
export interface CommitMessage {
	readonly subject: string;
	readonly body?: string;
}

/** Dependencies the host injects so the helper stays unit-testable. */
export interface CommitMessageDeps {
	readonly host: HostContext;
	readonly conductor: Conductor;
	readonly mode: ModeConfig;
	readonly modelId: string;
	readonly providerId: ProviderConfig["id"];
	readonly signal?: AbortSignal;
}

export interface CommitMessageOptions {
	/** Optional pre-fetched diff. When omitted we run `git diff --staged`. */
	readonly diff?: string;
	/** Soft cap on the diff size sent to the model. Defaults to 80 KB. */
	readonly maxDiffChars?: number;
}

/**
 * System prompt for the commit-message agent turn. Exported so tests can pin
 * the wording — output parsing depends on the model honoring the structure
 * (subject on line 1, blank line, then bullets).
 */
export const COMMIT_MESSAGE_SYSTEM_PROMPT = [
	"You write Conventional Commits-style git commit messages.",
	"",
	"Output rules — follow these EXACTLY:",
	"  1. Line 1: subject line, <= 72 characters, no trailing period.",
	"     Use a Conventional Commits prefix when appropriate (feat:, fix:,",
	"     refactor:, docs:, test:, chore:, perf:, build:, ci:, style:).",
	"  2. Line 2: blank.",
	"  3. Lines 3+: optional bullet body. Each bullet starts with '- '.",
	"     Use bullets to call out non-obvious decisions, breaking changes,",
	"     or grouped changes. Do NOT wrap prose across multiple lines —",
	"     one self-contained bullet per line.",
	"",
	"Do not include any commentary, markdown headers, code fences, or",
	"trailing notes. Output ONLY the commit message.",
].join("\n");

/**
 * Build the user message handed to the model. Exposed for tests.
 *
 * The diff is hard-capped to keep the prompt under provider context limits on
 * massive staged changes; truncation is signaled to the model so it doesn't
 * pretend it saw the rest.
 */
export function buildCommitPrompt(diff: string, maxDiffChars = 80_000): string {
	const truncated = diff.length > maxDiffChars;
	const body = truncated
		? `${diff.slice(0, maxDiffChars)}\n\n…diff truncated (${diff.length - maxDiffChars} more chars elided)…`
		: diff;
	return [
		"Generate a commit message for the following staged diff.",
		"",
		"```diff",
		body,
		"```",
		"",
		"Reply with ONLY the commit message, formatted per the system prompt.",
	].join("\n");
}

/**
 * Parse the model's reply into `{ subject, body? }`.
 *
 * - Strips surrounding code fences if the model wrapped its output in them.
 * - Subject is the first non-empty line, capped at 72 chars.
 * - Body is everything after the first blank line, joined back together. If
 *   the body is empty after trim, it's omitted.
 *
 * Exposed for unit tests.
 */
export function parseCommitMessage(raw: string): CommitMessage {
	if (typeof raw !== "string") return { subject: "" };
	// Strip fences. We don't care which language tag (if any) the model used.
	let text = raw.trim();
	const fenceMatch = text.match(/^```[a-zA-Z0-9_-]*\n([\s\S]*?)\n```$/);
	if (fenceMatch) text = fenceMatch[1].trim();

	const lines = text.split(/\r?\n/);
	let subject = "";
	let bodyStart = 1;
	// Skip any leading blank lines.
	let i = 0;
	while (i < lines.length && lines[i].trim().length === 0) i++;
	if (i < lines.length) {
		subject = lines[i].trim();
		bodyStart = i + 1;
	}
	// Truncate subject to 72 chars per spec.
	if (subject.length > 72) subject = subject.slice(0, 72).trimEnd();

	// Skip blank separator line(s) between subject and body.
	while (bodyStart < lines.length && lines[bodyStart].trim().length === 0) bodyStart++;
	const bodyLines = lines.slice(bodyStart);
	const body = bodyLines.join("\n").trimEnd();
	if (body.length === 0) return { subject };
	return { subject, body };
}

/**
 * Fetch the staged diff via `git diff --staged`. Empty string means "no
 * staged changes" (`git diff` exits 0 with no output).
 */
export async function fetchStagedDiff(host: HostContext): Promise<string> {
	const res = await host.exec("git diff --staged --no-color", { timeoutMs: 30_000 });
	if (res.exitCode !== 0 && res.exitCode !== 1) {
		throw new Error(
			`git diff --staged failed (exit ${res.exitCode}): ${res.stderr.trim() || res.stdout.trim() || "no output"}`,
		);
	}
	return res.stdout;
}

/** Sentinel error so callers can branch on "nothing staged" cleanly. */
export class EmptyDiffError extends Error {
	constructor() {
		super("Nothing is staged. Stage some changes first, then try again.");
		this.name = "EmptyDiffError";
	}
}

/**
 * Run an agent turn against the staged diff and return the parsed commit
 * message. Throws `EmptyDiffError` when nothing is staged.
 */
export async function generateCommitMessage(
	deps: CommitMessageDeps,
	opts: CommitMessageOptions = {},
): Promise<CommitMessage> {
	const diff = opts.diff ?? (await fetchStagedDiff(deps.host));
	if (diff.trim().length === 0) {
		throw new EmptyDiffError();
	}

	const prompt = buildCommitPrompt(diff, opts.maxDiffChars ?? 80_000);

	// Tailor a one-shot mode: borrow the active mode's tools/iteration cap so
	// `read_file` etc. are available if the model wants to peek at the broader
	// codebase, but disable planner/critic — this is a single-turn job.
	const commitMode: ModeConfig = {
		...deps.mode,
		systemPrompt: COMMIT_MESSAGE_SYSTEM_PROMPT,
		enablePlanner: false,
		enableCritic: false,
		providerId: deps.providerId,
	};

	const updated = await deps.conductor.spawn({
		mode: commitMode,
		modelId: deps.modelId,
		userMessage: prompt,
		history: [],
		...(deps.signal ? { signal: deps.signal } : {}),
	});

	const text = extractFinalAssistantText(updated);
	const parsed = parseCommitMessage(text);
	if (parsed.subject.length === 0) {
		throw new Error("Model returned no commit message text.");
	}
	return parsed;
}

function extractFinalAssistantText(
	history: readonly import("@iom/shared").ConversationMessage[],
): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const chunks: string[] = [];
		for (const p of msg.parts) if (p.kind === "text") chunks.push(p.text);
		const text = chunks.join("");
		if (text.trim().length > 0) return text;
	}
	return "";
}

// ---------------------------------------------------------------------------
// VS Code wiring — kept at the bottom so the unit-testable helpers above can
// be imported without dragging in vscode.git typings.
// ---------------------------------------------------------------------------

/**
 * Format a `{subject, body?}` pair back into a single commit message string
 * suitable for the SCM input box. Exposed for tests.
 */
export function formatCommitMessage(msg: CommitMessage): string {
	if (!msg.body || msg.body.trim().length === 0) return msg.subject;
	return `${msg.subject}\n\n${msg.body}`;
}

/**
 * Resolve the active git repository through VS Code's built-in `vscode.git`
 * extension. Returns `undefined` when the extension isn't installed, isn't
 * activated yet (callers can `await getExtension(...)?.activate()`), or has
 * no repositories.
 *
 * The returned shape is a structural subset of the git extension API so we
 * don't take a hard typing dependency on `@types/vscode-git` (which isn't in
 * our devDeps). Only `inputBox.value` is touched.
 */
export interface GitInputBoxRepo {
	readonly inputBox: { value: string };
	readonly rootUri?: { fsPath: string };
}

export interface GitExtensionApiLike {
	readonly repositories: readonly GitInputBoxRepo[];
}

export function pickPrimaryRepo(
	api: GitExtensionApiLike | undefined,
	workspaceFolderFsPath?: string,
): GitInputBoxRepo | undefined {
	if (!api || api.repositories.length === 0) return undefined;
	if (workspaceFolderFsPath) {
		const match = api.repositories.find((r) => r.rootUri?.fsPath === workspaceFolderFsPath);
		if (match) return match;
	}
	return api.repositories[0];
}
