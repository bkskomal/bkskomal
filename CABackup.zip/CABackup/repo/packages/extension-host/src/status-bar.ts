import type { AgentEvent } from "@iom/shared";
import * as vscode from "vscode";

/**
 * Status-bar widget.
 *
 * Lives at the right side of the status bar (priority 100) and shows
 * three pieces of state at a glance:
 *   - the "$(robot) iOmCode" prefix as an entry point + activation indicator
 *   - the running task count, prefixed with `⟳` when > 0
 *   - rolling session cost + token usage, updated from agent `usage` events
 *
 * Clicking the item runs `iom.openOrFocusPanel` (registered by
 * extension.ts) which behaves like "/new chat" if no panel exists, or
 * reveals the most-recently focused one otherwise.
 */

export interface StatusBarManagerOptions {
	/** Initial running-task count, useful when tasks were rehydrated before activation. */
	readonly initialRunningTasks?: number;
	/** Command id wired to the status-bar click. */
	readonly command?: string;
}

const DEFAULT_COMMAND = "iom.openOrFocusPanel";

export class StatusBarManager {
	private readonly item: vscode.StatusBarItem;
	private cost = 0;
	private tokens = 0;
	private runningTasks: number;

	constructor(opts: StatusBarManagerOptions = {}) {
		this.runningTasks = opts.initialRunningTasks ?? 0;
		this.item = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
		this.item.command = opts.command ?? DEFAULT_COMMAND;
		this.item.tooltip = "OATI Code — click to open the chat panel";
		this.render();
		this.item.show();
	}

	/**
	 * Feed an agent event to keep the cost/token counters up to date. Only
	 * `usage` events mutate state; everything else is ignored.
	 */
	handleAgentEvent(ev: AgentEvent, costDelta = 0): void {
		if (ev.type !== "usage") return;
		this.tokens += ev.inputTokens + ev.outputTokens;
		this.cost += costDelta;
		this.render();
	}

	/** Set the number of currently-running background tasks. Pass 0 to clear. */
	setRunningTasks(n: number): void {
		const next = Math.max(0, Math.floor(n));
		if (next === this.runningTasks) return;
		this.runningTasks = next;
		this.render();
	}

	/** Reset the rolling cost/token totals (e.g. on /clear or session swap). */
	resetUsage(): void {
		this.cost = 0;
		this.tokens = 0;
		this.render();
	}

	dispose(): void {
		this.item.dispose();
	}

	private render(): void {
		const parts: string[] = [];
		if (this.runningTasks > 0) parts.push(`⟳ ${this.runningTasks}`);
		parts.push("$(robot) iOmCode:");
		if (this.cost <= 0 && this.tokens <= 0) {
			parts.push("idle");
		} else {
			parts.push(`$${this.cost.toFixed(4)} · ${formatTokens(this.tokens)} tok`);
		}
		this.item.text = parts.join(" ");
	}
}

function formatTokens(n: number): string {
	if (n < 1000) return String(n);
	if (n < 1_000_000) return `${(n / 1000).toFixed(1)}k`;
	return `${(n / 1_000_000).toFixed(2)}M`;
}
