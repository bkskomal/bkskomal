// R8-C: @web:<query> — run a web search and return the top 3 snippets. Uses
// the same DuckDuckGo HTML scrape R1's `web_search` tool relies on. The
// parser is duplicated locally because the tool's `parseDuckDuckGoHtml` is
// not exported from `@iom/tools/index.ts`, and R8-C cannot modify that file.
import type { ContextProvider } from "./registry";

const TIMEOUT_MS = 10_000;
const TOP_K = 3;

interface SearchResult {
	readonly title: string;
	readonly url: string;
	readonly snippet: string;
}

function decodeEntities(text: string): string {
	return text
		.replace(/&#(\d+);/g, (_m, n: string) => {
			const code = Number.parseInt(n, 10);
			if (!Number.isFinite(code) || code < 0 || code > 0x10ffff) return _m;
			try {
				return String.fromCodePoint(code);
			} catch {
				return _m;
			}
		})
		.replace(/&amp;/g, "&")
		.replace(/&lt;/g, "<")
		.replace(/&gt;/g, ">")
		.replace(/&quot;/g, '"')
		.replace(/&#39;/g, "'")
		.replace(/&nbsp;/g, " ");
}

function stripTags(html: string): string {
	return html.replace(/<[^>]*>/g, "");
}

function clean(raw: string): string {
	return decodeEntities(stripTags(raw)).replace(/\s+/g, " ").trim();
}

function unwrapDdgUrl(href: string): string {
	try {
		const abs = href.startsWith("//") ? `https:${href}` : href;
		const u = new URL(abs, "https://html.duckduckgo.com");
		if (u.pathname === "/l/" || u.pathname.endsWith("/l/")) {
			const target = u.searchParams.get("uddg");
			if (target) return decodeURIComponent(target);
		}
		return u.toString();
	} catch {
		return href;
	}
}

export function parseDuckDuckGoHtml(html: string, limit: number): SearchResult[] {
	const results: SearchResult[] = [];
	const titleRegex =
		/<a[^>]*class="[^"]*\bresult__a\b[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
	const snippetRegex = /<a[^>]*class="[^"]*\bresult__snippet\b[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
	const titleMatches: { url: string; title: string }[] = [];
	let m: RegExpExecArray | null;
	// biome-ignore lint/suspicious/noAssignInExpressions: standard regex.exec loop
	while ((m = titleRegex.exec(html)) !== null) {
		const url = unwrapDdgUrl(m[1]);
		const title = clean(m[2]);
		if (title && url) titleMatches.push({ url, title });
	}
	const snippetMatches: string[] = [];
	// biome-ignore lint/suspicious/noAssignInExpressions: standard regex.exec loop
	while ((m = snippetRegex.exec(html)) !== null) {
		snippetMatches.push(clean(m[1]));
	}
	const n = Math.min(titleMatches.length, limit);
	for (let i = 0; i < n; i++) {
		results.push({
			title: titleMatches[i].title,
			url: titleMatches[i].url,
			snippet: snippetMatches[i] ?? "",
		});
	}
	return results;
}

export const webProvider: ContextProvider = {
	id: "web",
	mention: "@web",
	description: "Run a web search and return the top 3 snippets.",
	async resolve(arg) {
		const query = arg.trim();
		if (!query) {
			return "_Usage: `@web:<query>`._";
		}
		const encoded = encodeURIComponent(query);
		const url = `https://html.duckduckgo.com/html/?q=${encoded}`;
		const ctrl = new AbortController();
		const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
		try {
			const response = await fetch(url, {
				method: "GET",
				signal: ctrl.signal,
				redirect: "follow",
				headers: {
					"User-Agent": "Mozilla/5.0 (compatible; iOm-Code/1.0; +https://github.com/)",
					Accept: "text/html,application/xhtml+xml",
				},
			});
			const html = await response.text();
			const results = parseDuckDuckGoHtml(html, TOP_K);
			if (results.length === 0) {
				return `_No results for "${query}"._`;
			}
			const blocks = results.map((r, i) => `${i + 1}. **${r.title}**\n   ${r.url}\n   ${r.snippet}`);
			return `**Web search:** \`${query}\`\n\n${blocks.join("\n\n")}`;
		} catch (err) {
			if (err instanceof Error && err.name === "AbortError") {
				return `_@web search timed out: ${query}._`;
			}
			return `_@web failed: ${err instanceof Error ? err.message : String(err)}._`;
		} finally {
			clearTimeout(timer);
		}
	},
};
