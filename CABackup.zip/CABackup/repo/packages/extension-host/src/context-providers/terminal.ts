// R8-C: @terminal — last 200 lines of the active terminal's contents.
//
// VS Code doesn't expose terminal buffer contents directly. We try two paths:
//   1. A host-attached `terminalBuffer` snapshot (populated by the extension
//      via `vscode.window.onDidWriteTerminalData` when the API is available
//      under the proposed `terminalDataWriteEvent` flag).
//   2. Fall back to a friendly hint when no tracked buffer exists.
import type { HostContext } from "@iom/shared";
import type { ContextProvider } from "./registry";

/** How many trailing lines to surface. */
export const TERMINAL_TAIL_LINES = 200;

/**
 * Optional capability the extension host can attach onto its HostContext so
 * the terminal provider can render real captured output. The webview registers
 * this lazily; tests can stub it directly. We deliberately don't widen
 * `HostContext` for this — keeping the dependency direction one-way means R8-C
 * stays a pure append on the shared package.
 */
export interface TerminalSnapshotProvider {
	getActiveTerminalText(): string | undefined;
}

interface HostWithTerminal extends HostContext {
	readonly terminalSnapshot?: TerminalSnapshotProvider;
}

export const terminalProvider: ContextProvider = {
	id: "terminal",
	mention: "@terminal",
	description: `Last ${TERMINAL_TAIL_LINES} lines of the active terminal. Requires a tracked terminal.`,
	async resolve(_arg, host) {
		const snap = (host as HostWithTerminal).terminalSnapshot;
		const raw = snap?.getActiveTerminalText();
		if (!raw) {
			return "_No active terminal captured. Open a tracked terminal (View → Terminal) and re-run a command before using @terminal._";
		}
		const lines = raw.split(/\r?\n/);
		const tail = lines.slice(Math.max(0, lines.length - TERMINAL_TAIL_LINES));
		return ["**Active terminal (tail):**", "```", ...tail, "```"].join("\n");
	},
};
