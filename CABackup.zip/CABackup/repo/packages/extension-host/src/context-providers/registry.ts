// R8-C: Pluggable context-provider registry.
//
// A context provider resolves a `@`-mention into a markdown block that the
// chat composer can splice into the outgoing user message. Built-in providers
// live alongside this file (one per mention); user-supplied providers can be
// dropped into `<workspace>/.iom/context-providers/*.js` and registered at
// activation (see `loadUserProviders`).
//
// Wire as follows from the extension host:
//
//   import { registerBuiltinContextProviders } from "./context-providers";
//   registerBuiltinContextProviders();          // once at activation
//   await loadUserProviders(workspaceRoot, log); // safe to call when missing
//
// Mentions are matched literally (so `@problems` not `@Problems`); arguments
// follow `:`, e.g. `@docs:https://example.com`.
import type { HostContext } from "@iom/shared";

/**
 * A single context provider. `id` is the stable identifier used for registry
 * lookups and tool calls; `mention` is the literal `@...` token the user
 * types in the composer. `resolve` returns a markdown-flavoured context block
 * suitable for splicing into an outgoing message.
 */
export interface ContextProvider {
	readonly id: string;
	readonly mention: string;
	readonly description: string;
	resolve(arg: string, host: HostContext): Promise<string>;
}

const providers = new Map<string, ContextProvider>();
/** Tracks how many user-provided plugins are registered per workspace. */
const userProviderCount = new Map<string, number>();

/** Hard cap on user-provided providers per workspace. */
export const MAX_USER_PROVIDERS = 10;

/** Register a provider. Last one wins for the same id (overrides built-ins). */
export function registerContextProvider(provider: ContextProvider): void {
	if (!provider.id) throw new Error("registerContextProvider: id is required");
	if (!provider.mention.startsWith("@")) {
		throw new Error(`registerContextProvider: mention must start with '@' (got ${provider.mention})`);
	}
	providers.set(provider.id, provider);
}

/** Look up a provider by id. */
export function getContextProvider(id: string): ContextProvider | undefined {
	return providers.get(id);
}

/** Look up a provider by its `@mention` token. The leading `@` may be omitted. */
export function getContextProviderByMention(mention: string): ContextProvider | undefined {
	const norm = mention.startsWith("@") ? mention : `@${mention}`;
	for (const p of providers.values()) {
		if (p.mention === norm) return p;
	}
	return undefined;
}

/** Return every registered provider, sorted by mention for stable UI. */
export function listContextProviders(): readonly ContextProvider[] {
	return [...providers.values()].sort((a, b) => a.mention.localeCompare(b.mention));
}

/** Remove every registered provider. Test-only — production code should not call this. */
export function _resetContextProviders(): void {
	providers.clear();
	userProviderCount.clear();
}

/**
 * Returns true when this workspace has reached the user-provider cap. The
 * caller is expected to log + skip rather than throw so a noisy plugin dir
 * doesn't crash activation.
 */
export function userProviderCapReached(workspaceRoot: string): boolean {
	return (userProviderCount.get(workspaceRoot) ?? 0) >= MAX_USER_PROVIDERS;
}

/**
 * Internal: bump the workspace's user-provider counter. Returns false when the
 * cap has already been hit (registration should be skipped).
 */
export function tryAcceptUserProvider(workspaceRoot: string): boolean {
	const current = userProviderCount.get(workspaceRoot) ?? 0;
	if (current >= MAX_USER_PROVIDERS) return false;
	userProviderCount.set(workspaceRoot, current + 1);
	return true;
}
