// R8-E: Skills loader.
//
// Skills are markdown files under `<workspace>/.iom/skills/*.md` with a
// YAML-ish front-matter block. The agent picks them up lazily — when the
// user's message matches any skill's `triggers` (case-insensitive substring),
// the panel injects a one-liner into the system-prompt prelude telling the
// agent the skill is available. The agent then calls the `load_skill` tool
// to fetch the full body when (and only when) it decides to use it.
//
// Example skill file `.iom/skills/db-migration-writer.md`:
//
// ```markdown
// ---
// name: db-migration-writer
// description: Author Knex/Prisma database migrations safely
// tools: [read_file, write_file, run_tests]
// triggers:
//   - migration
//   - schema change
// ---
//
// When writing a database migration:
// 1. Read the previous migration to learn the table conventions.
// 2. ...
// ```
//
// We deliberately keep the front-matter parser minimal — no full YAML
// dependency — because we already paid the `js-yaml` cost in policy.ts and
// would rather not couple skills loading to that. The shape is small and
// stable: name (string), description (string), tools (string array),
// triggers (string array). Anything malformed is silently dropped.

import { promises as fs } from "node:fs";
import * as path from "node:path";
import { parseYaml } from "@iom/shared";
// Phase 0.5 follow-through (2026-06-04): swapped js-yaml for the shared
// hand-rolled mini-parser. Frontmatter shapes (name + description strings
// + tools/triggers string arrays) are well within its supported feature
// set; malformed input still throws and we drop the skill silently.

export interface Skill {
	/** Skill identifier. Must match `[a-zA-Z0-9_-]+`. */
	readonly name: string;
	/** One-line description shown in the system-prompt prelude. */
	readonly description: string;
	/** Tools the skill expects to have available (advisory). */
	readonly tools: readonly string[];
	/** Substrings (case-insensitive) that activate this skill on user prompts. */
	readonly triggers: readonly string[];
	/** Full markdown body, returned by `load_skill`. Excludes the front-matter. */
	readonly body: string;
}

const VALID_NAME = /^[a-zA-Z0-9_-]+$/;
export const SKILLS_DIR_REL = ".iom/skills";

/**
 * Scan `<workspaceRoot>/.iom/skills/*.md` (workspace skills) and the
 * extension's `<bundledSkillsDir>` (built-in playbooks shipped with iOmCode
 * Code) and return every well-formed skill. Workspace skills shadow bundled
 * ones with the same name so a project can override the default playbook.
 *
 * Missing directories / unreadable files / malformed front-matter all degrade
 * gracefully — a broken skill file can't wedge the panel.
 */
export async function loadSkills(
	workspaceRoot: string | undefined,
	bundledDir?: string,
): Promise<Skill[]> {
	const byName = new Map<string, Skill>();
	if (bundledDir) {
		for (const skill of await scanSkillsDir(bundledDir)) byName.set(skill.name, skill);
	}
	if (workspaceRoot) {
		const dir = path.join(workspaceRoot, SKILLS_DIR_REL);
		for (const skill of await scanSkillsDir(dir)) byName.set(skill.name, skill);
	}
	return [...byName.values()].sort((a, b) => a.name.localeCompare(b.name));
}

async function scanSkillsDir(dir: string): Promise<Skill[]> {
	let entries: string[];
	try {
		entries = await fs.readdir(dir);
	} catch {
		return [];
	}
	const out: Skill[] = [];
	for (const entry of entries) {
		if (!entry.toLowerCase().endsWith(".md")) continue;
		const filenameName = entry.slice(0, -3);
		if (!VALID_NAME.test(filenameName)) continue;
		const abs = path.join(dir, entry);
		let raw: string;
		try {
			const stat = await fs.stat(abs);
			if (!stat.isFile()) continue;
			raw = await fs.readFile(abs, "utf-8");
		} catch {
			continue;
		}
		const parsed = parseSkill(filenameName, raw);
		if (parsed) out.push(parsed);
	}
	return out;
}

/**
 * Read and parse a single skill file. Workspace skills shadow bundled ones, so
 * we look in `<workspace>/.iom/skills/<name>.md` first and fall back to the
 * bundled-skills directory when supplied.
 */
export async function loadSkill(
	workspaceRoot: string | undefined,
	name: string,
	bundledDir?: string,
): Promise<Skill | undefined> {
	if (!VALID_NAME.test(name)) return undefined;
	const candidates: string[] = [];
	if (workspaceRoot) candidates.push(path.join(workspaceRoot, SKILLS_DIR_REL, `${name}.md`));
	if (bundledDir) candidates.push(path.join(bundledDir, `${name}.md`));
	for (const abs of candidates) {
		try {
			const raw = await fs.readFile(abs, "utf-8");
			const parsed = parseSkill(name, raw);
			if (parsed) return parsed;
		} catch {
			/* fall through to the next candidate */
		}
	}
	return undefined;
}

/**
 * Parse one skill file. Front-matter is fenced by `---` on its own line. If
 * the fence is missing we treat the whole file as the body and synthesize a
 * minimal Skill (no triggers — it won't auto-activate but can still be loaded
 * explicitly by name).
 */
export function parseSkill(filenameName: string, raw: string): Skill | undefined {
	const fmMatch = /^---\s*\r?\n([\s\S]*?)\r?\n---\s*\r?\n([\s\S]*)$/m.exec(raw);
	let frontMatterRaw = "";
	let body = raw;
	if (fmMatch) {
		frontMatterRaw = fmMatch[1] ?? "";
		body = (fmMatch[2] ?? "").replace(/^\s*\n/, "");
	}
	let parsed: unknown = {};
	if (frontMatterRaw.length > 0) {
		try {
			parsed = parseYaml(frontMatterRaw) ?? {};
		} catch {
			return undefined;
		}
	}
	if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return undefined;
	const fm = parsed as Record<string, unknown>;
	const name = typeof fm.name === "string" && VALID_NAME.test(fm.name) ? fm.name : filenameName;
	if (!VALID_NAME.test(name)) return undefined;
	const description =
		typeof fm.description === "string" && fm.description.trim().length > 0
			? fm.description.trim()
			: name;
	const tools = Array.isArray(fm.tools)
		? fm.tools.filter((t): t is string => typeof t === "string")
		: [];
	const triggers = Array.isArray(fm.triggers)
		? fm.triggers.filter((t): t is string => typeof t === "string")
		: [];
	return { name, description, tools, triggers, body };
}

/**
 * Find every skill whose `triggers` substring-match (case-insensitive) the
 * user's prompt. Used by the chat-panel prelude assembly to nudge the agent
 * toward calling `load_skill`. Returns at most `limit` skills (default 3) to
 * keep the prelude small.
 */
export function matchSkills(skills: readonly Skill[], prompt: string, limit = 3): readonly Skill[] {
	const lower = prompt.toLowerCase();
	const matched: Skill[] = [];
	for (const skill of skills) {
		if (skill.triggers.length === 0) continue;
		const hit = skill.triggers.some((t) => t.length > 0 && lower.includes(t.toLowerCase()));
		if (hit) matched.push(skill);
		if (matched.length >= limit) break;
	}
	return matched;
}

/**
 * Build the prelude snippet to inject into the system prompt when one or more
 * skills match the user's turn. Empty string when `matched` is empty so the
 * caller can safely concatenate.
 */
export function assembleSkillsPrelude(matched: readonly Skill[]): string {
	if (matched.length === 0) return "";
	const lines = matched.map((s) => {
		const toolsHint = s.tools.length > 0 ? ` (tools: ${s.tools.join(", ")})` : "";
		return `- Available skill: ${s.name} — ${s.description}${toolsHint}. Activate by calling \`load_skill\` with \`{"name": "${s.name}"}\` when relevant.`;
	});
	return ["## Available skills", ...lines].join("\n");
}
