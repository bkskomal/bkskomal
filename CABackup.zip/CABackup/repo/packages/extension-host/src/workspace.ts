/*
 * Workspace-path resolver.
 *
 * Single source of truth for "what project is iOmCode working in?" Used
 * by every host-side caller that needs a workspace root: tools, hooks,
 * memory loader, supervisor, exports, checkpoints.
 *
 * Resolution order:
 *   1. If a text editor is focused, prefer the workspace folder that
 *      contains its file. Matters for multi-root workspaces where the
 *      user has, say, `apps/web/` + `apps/api/` and is actively editing
 *      `api/server.ts` — the agent should treat `apps/api/` as the
 *      project, not blindly use `apps/web/` because it's index 0.
 *   2. Otherwise the first workspace folder.
 *   3. Otherwise undefined (no folder open — only floating files).
 *
 * The exported helpers are intentionally thin so callers don't drift apart.
 */
import * as path from "node:path";
import * as vscode from "vscode";

export interface WorkspaceInfo {
	/** Absolute fsPath of the project root. */
	readonly path: string;
	/** Last path segment — useful for status displays. */
	readonly name: string;
	/** True when there is more than one folder in the workspace. */
	readonly isMultiRoot: boolean;
	/** Total number of folders in the workspace. */
	readonly folderCount: number;
}

/** Active-editor-aware primary workspace path. See module doc for ordering. */
export function resolvePrimaryWorkspacePath(): string | undefined {
	const folders = vscode.workspace.workspaceFolders;
	if (!folders || folders.length === 0) return undefined;
	const active = vscode.window.activeTextEditor?.document.uri;
	if (active && folders.length > 1) {
		const owning = vscode.workspace.getWorkspaceFolder(active);
		if (owning) return owning.uri.fsPath;
	}
	return folders[0].uri.fsPath;
}

/** Same selection rule, but returns the surrounding metadata too. */
export function resolveWorkspaceInfo(): WorkspaceInfo | undefined {
	const fsPath = resolvePrimaryWorkspacePath();
	if (!fsPath) return undefined;
	const folders = vscode.workspace.workspaceFolders ?? [];
	return {
		path: fsPath,
		name: path.basename(fsPath) || fsPath,
		isMultiRoot: folders.length > 1,
		folderCount: folders.length,
	};
}

/**
 * Subscribe to "the primary workspace path may have changed" events. Fires
 * when:
 *   - A folder is added or removed from the workspace.
 *   - The user focuses a different editor (only matters in multi-root, but
 *     we don't try to be clever — the listener is cheap and the consumer
 *     can dedupe via `resolvePrimaryWorkspacePath()`).
 */
export function onWorkspaceChanged(
	listener: (info: WorkspaceInfo | undefined) => void,
): vscode.Disposable {
	const fire = () => listener(resolveWorkspaceInfo());
	const subs: vscode.Disposable[] = [
		vscode.workspace.onDidChangeWorkspaceFolders(fire),
		vscode.window.onDidChangeActiveTextEditor(fire),
	];
	return {
		dispose() {
			for (const s of subs) {
				try {
					s.dispose();
				} catch {
					/* best-effort */
				}
			}
		},
	};
}
