/*
 * R2-E hover-explain — when the user hovers over a function declaration in
 * a supported language, ask the active provider for a 2-sentence summary and
 * surface it via the standard VS Code hover popup. Results are cached for
 * 30 minutes per (file, line, function-name) so a quick scroll-through
 * doesn't repeatedly re-spawn the same one-shot call.
 *
 * Function detection is intentionally coarse — we don't ship a parser per
 * language. A regex per language picks out the most common declaration
 * shapes; anything fancier (decorators, generics, multiline signatures)
 * just falls through to "no hover" which is the right failure mode.
 */

import type { ConversationMessage, ProviderSpec } from "@iom/shared";
import * as vscode from "vscode";
import type { ProviderManager } from "./provider-manager";
import type { SettingsStore } from "./settings-store";

export interface HoverExplainDeps {
	readonly settings: SettingsStore;
	readonly providerManager: ProviderManager;
	readonly log?: vscode.OutputChannel;
}

const SUPPORTED_LANGUAGES = ["typescript", "javascript", "python", "go", "rust"] as const;
const CACHE_TTL_MS = 30 * 60 * 1000;
const HOVER_DEBOUNCE_MS = 350;
const MAX_BODY_CHARS = 1800;

interface CacheEntry {
	readonly text: string;
	readonly expiresAt: number;
}

/**
 * Per-language regex that captures a function name from a single line. These
 * are deliberately permissive — false positives just produce an unused cache
 * miss, which is cheap, while a missed declaration means no hover at all
 * (visibly worse to the user).
 */
const FUNCTION_PATTERNS: Record<string, RegExp> = {
	typescript: /^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/,
	javascript: /^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/,
	python: /^\s*(?:async\s+)?def\s+([A-Za-z_][\w]*)\s*\(/,
	go: /^\s*func\s+(?:\([^)]*\)\s+)?([A-Za-z_][\w]*)\s*\(/,
	rust: /^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+([A-Za-z_][\w]*)\s*[<(]/,
};

export function registerHoverExplain(
	context: vscode.ExtensionContext,
	deps: HoverExplainDeps,
): vscode.Disposable {
	const cache = new Map<string, CacheEntry>();
	// Single in-flight request per cache-key, keyed by the same string so a
	// burst of hover events on the same function only spawns one call.
	const inflight = new Map<string, Promise<string | undefined>>();
	// Debounce timer per document so racing hover events don't fan out into
	// duplicate provider calls when the user is just scrubbing the mouse.
	let lastHoverAt = 0;

	const provider: vscode.HoverProvider = {
		async provideHover(document, position, token) {
			if (!isEnabled(deps.settings)) return undefined;

			// Cheap debounce — drop hover events that arrive too close together.
			const now = Date.now();
			if (now - lastHoverAt < HOVER_DEBOUNCE_MS) return undefined;
			lastHoverAt = now;

			const lang = document.languageId;
			if (!(SUPPORTED_LANGUAGES as readonly string[]).includes(lang)) return undefined;

			const lineText = document.lineAt(position.line).text;
			const fnName = extractFunctionName(lineText, lang);
			if (!fnName) return undefined;

			const cacheKey = `${document.uri.toString()}::${position.line}::${fnName}`;

			const cached = cache.get(cacheKey);
			if (cached && cached.expiresAt > now) {
				return buildHover(fnName, cached.text);
			}

			// Coalesce concurrent hovers on the same key onto a single promise.
			let task = inflight.get(cacheKey);
			if (!task) {
				const body = extractFunctionBody(document, position.line, lang);
				task = explainOnce(deps, lang, fnName, body, token)
					.then((text) => {
						if (text) {
							cache.set(cacheKey, { text, expiresAt: Date.now() + CACHE_TTL_MS });
						}
						return text;
					})
					.finally(() => {
						inflight.delete(cacheKey);
					});
				inflight.set(cacheKey, task);
			}

			try {
				const text = await task;
				if (!text || token.isCancellationRequested) return undefined;
				return buildHover(fnName, text);
			} catch (err) {
				deps.log?.appendLine(
					`[hover-explain] failed for ${fnName}: ${err instanceof Error ? err.message : String(err)}`,
				);
				return undefined;
			}
		},
	};

	const selector = SUPPORTED_LANGUAGES.map((language) => ({ scheme: "file", language }));
	const reg = vscode.languages.registerHoverProvider(selector, provider);
	context.subscriptions.push(reg);
	return reg;
}

function isEnabled(_settings: SettingsStore): boolean {
	// VS Code workspace configuration owns the on/off switch — exposed in
	// the package.json `contributes.configuration` block so users can flip it
	// without round-tripping through our settings UI.
	const cfg = vscode.workspace.getConfiguration("iom.hoverExplain");
	return cfg.get<boolean>("enabled", true);
}

export function extractFunctionName(line: string, language: string): string | undefined {
	const pattern = FUNCTION_PATTERNS[language];
	if (!pattern) return undefined;
	const m = pattern.exec(line);
	return m ? m[1] : undefined;
}

/**
 * Pull a coarse function body for the prompt: from the declaration line down
 * to either a blank-line gap or a closing brace at column 0 (whichever comes
 * first). Capped at MAX_BODY_CHARS so a 2000-line monster doesn't blow the
 * context window — the explainer only needs a representative slice anyway.
 */
function extractFunctionBody(
	doc: vscode.TextDocument,
	startLine: number,
	language: string,
): string {
	const lines: string[] = [];
	let total = 0;
	const usesBraces = language !== "python";
	let sawOpen = false;
	for (let i = startLine; i < doc.lineCount; i++) {
		const text = doc.lineAt(i).text;
		lines.push(text);
		total += text.length + 1;
		if (total > MAX_BODY_CHARS) break;
		if (usesBraces) {
			if (text.includes("{")) sawOpen = true;
			if (sawOpen && /^\}/.test(text)) break;
		} else if (i > startLine && text.length > 0 && !/^\s/.test(text)) {
			// Python: next top-level definition starts a new function — stop.
			break;
		}
	}
	return lines.join("\n");
}

function buildHover(fnName: string, explanation: string): vscode.Hover {
	const md = new vscode.MarkdownString();
	md.isTrusted = false;
	md.appendMarkdown(`**iOmCode · explain \`${fnName}\`**\n\n${explanation}`);
	return new vscode.Hover(md);
}

async function explainOnce(
	deps: HoverExplainDeps,
	language: string,
	fnName: string,
	body: string,
	token: vscode.CancellationToken,
): Promise<string | undefined> {
	const config = deps.settings.config;
	const modelId = deps.providerManager.resolveActiveModelId(config);
	if (!modelId) return undefined;
	const providerId =
		config.modes.find((m) => m.id === config.activeModeId)?.providerId ?? config.activeProviderId;
	const provider = deps.providerManager.registry.get(providerId);
	if (!provider) return undefined;

	const userPrompt = `Explain what the function \`${fnName}\` does in 2 sentences. Be concrete; mention inputs, outputs, and any non-obvious side effects. No code, no markdown, just prose.\n\n\`\`\`${language}\n${body}\n\`\`\``;

	const messages: ConversationMessage[] = [
		{ role: "user", parts: [{ kind: "text", text: userPrompt }] },
	];

	let out = "";
	const stream = provider.stream({
		messages,
		modelId,
		systemPrompt: "You are a terse code-explainer. Reply with at most 2 sentences of prose.",
		temperature: 0.2,
	});
	for await (const ev of stream) {
		if (token.isCancellationRequested) return undefined;
		if (ev.type === "text_delta") out += ev.text;
		else if (ev.type === "error") return undefined;
		else if (ev.type === "message_end") break;
	}
	return out.trim() || undefined;
}

// Suppress unused-import lint on ProviderSpec — kept here so the file
// documents the shape we expect from `provider-manager.registry.get`.
export type _HoverExplainProviderShape = ProviderSpec;
