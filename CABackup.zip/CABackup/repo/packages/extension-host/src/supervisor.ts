/*
 * Background supervisor agent.
 *
 * Sits behind the chat UI and watches the developer's workspace edits. On a
 * configurable interval (`iom.supervisor.intervalSeconds`, default 120s),
 * when at least one edit has happened since the last run, it dispatches a
 * short read-only sub-agent that returns up to three actionable suggestions
 * — "this function has no test", "you removed the only caller of foo()",
 * "this branch is 2 weeks stale", etc.
 *
 * Opt-in via `iom.supervisor.enabled` — defaults to off because every run
 * issues a model call. When enabled it never blocks the user; suggestions
 * stream into the webview's supervisor side panel and the user reviews on
 * their own time.
 */
import type { Conductor } from "@iom/agent-core";
import type { ModeConfig } from "@iom/shared";
import * as vscode from "vscode";
import type { ProviderManager } from "./provider-manager";
import type { SettingsStore } from "./settings-store";

export interface SupervisorSuggestion {
	readonly id: string;
	/** Short, actionable line — what the user should consider doing. */
	readonly message: string;
	/** Optional workspace-relative file the suggestion is about. */
	readonly path?: string;
	/** Optional 1-based line number to jump to. */
	readonly line?: number;
	/** Severity hint to drive UI color. */
	readonly severity: "info" | "warn" | "suggest";
	/** ISO timestamp when the supervisor emitted this. */
	readonly emittedAt: string;
}

export type SupervisorListener = (snapshot: readonly SupervisorSuggestion[]) => void;

export interface SupervisorOptions {
	readonly conductor: Conductor;
	readonly providerManager: ProviderManager;
	readonly settings: SettingsStore;
	readonly log?: vscode.OutputChannel;
}

const MAX_EDITS_TRACKED = 30;
const MAX_SUGGESTIONS = 12;
const SUPERVISOR_SYSTEM_PROMPT = [
	"You are a background code-review supervisor watching a developer's recent edits.",
	"Goal: surface AT MOST 3 short, actionable suggestions per cycle.",
	"",
	"Strict output rules — return ONLY a JSON array of objects with this shape:",
	'  [{"message": "string under 140 chars", "path": "optional/file/path", "line": 42, "severity": "info|warn|suggest"}]',
	"",
	"Guidelines:",
	"- Be concrete. 'Add a test for parseDate' beats 'add tests'.",
	"- Stay non-blocking — these are suggestions, not stop-the-world warnings.",
	"- Don't repeat the same point twice. Don't list trivia (formatting).",
	"- Empty array `[]` is fine when nothing is worth raising.",
	"- No prose. No markdown. No code fences. JSON ONLY.",
].join("\n");

export class SupervisorAgent {
	private suggestions: SupervisorSuggestion[] = [];
	private readonly listeners = new Set<SupervisorListener>();
	private readonly editsBuffer = new Map<string, { lastEditAt: string; changeCount: number }>();
	private interval: NodeJS.Timeout | undefined;
	private inFlight = false;
	private currentAbort: AbortController | undefined;
	private disposables: vscode.Disposable[] = [];
	private nextId = 1;

	constructor(private readonly opts: SupervisorOptions) {}

	start(): void {
		const cfg = vscode.workspace.getConfiguration("iom.supervisor");
		if (!cfg.get<boolean>("enabled", false)) {
			this.opts.log?.appendLine("[supervisor] disabled — supervisor.enabled is false");
			return;
		}
		this.opts.log?.appendLine("[supervisor] starting");

		// Track every save as a "recent edit" — debounced into a per-file
		// entry so a tight save loop doesn't blow the buffer.
		this.disposables.push(
			vscode.workspace.onDidSaveTextDocument((doc) => {
				const rel = vscode.workspace.asRelativePath(doc.uri);
				if (rel.startsWith(".git/") || rel.startsWith("node_modules/")) return;
				const prev = this.editsBuffer.get(rel);
				this.editsBuffer.set(rel, {
					lastEditAt: new Date().toISOString(),
					changeCount: (prev?.changeCount ?? 0) + 1,
				});
				if (this.editsBuffer.size > MAX_EDITS_TRACKED) {
					// Drop the oldest entry (insertion order).
					const first = this.editsBuffer.keys().next();
					if (!first.done) this.editsBuffer.delete(first.value);
				}
			}),
		);

		// Periodic tick — reads the latest interval from config every cycle so
		// changing it doesn't require a reload.
		const tick = (): void => {
			const intervalSec = vscode.workspace
				.getConfiguration("iom.supervisor")
				.get<number>("intervalSeconds", 120);
			const ms = Math.max(30, Math.min(1800, intervalSec)) * 1000;
			this.interval = setTimeout(() => {
				void this.runOnce().finally(tick);
			}, ms);
		};
		tick();
	}

	/** Imperatively trigger a supervisor pass — exposed for the /supervise slash command. */
	async triggerNow(): Promise<void> {
		await this.runOnce(true);
	}

	stop(): void {
		this.opts.log?.appendLine("[supervisor] stopping");
		if (this.interval) clearTimeout(this.interval);
		this.interval = undefined;
		this.currentAbort?.abort();
		this.currentAbort = undefined;
		for (const d of this.disposables) {
			try {
				d.dispose();
			} catch {
				/* ignore */
			}
		}
		this.disposables = [];
	}

	/** Live snapshot. */
	getSuggestions(): readonly SupervisorSuggestion[] {
		return this.suggestions;
	}

	dismiss(id: string): void {
		const before = this.suggestions.length;
		this.suggestions = this.suggestions.filter((s) => s.id !== id);
		if (this.suggestions.length !== before) this.notify();
	}

	clear(): void {
		this.suggestions = [];
		this.notify();
	}

	onChange(listener: SupervisorListener): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	private notify(): void {
		const snap = [...this.suggestions];
		for (const l of this.listeners) {
			try {
				l(snap);
			} catch {
				/* listener best-effort */
			}
		}
	}

	private async runOnce(force = false): Promise<void> {
		if (this.inFlight) return;
		if (!force && this.editsBuffer.size === 0) return;
		const cfg = vscode.workspace.getConfiguration("iom.supervisor");
		if (!cfg.get<boolean>("enabled", false) && !force) return;

		const config = this.opts.settings.config;
		const baseMode = config.modes.find((m) => m.id === config.activeModeId) ?? config.modes[0];
		if (!baseMode) {
			this.opts.log?.appendLine("[supervisor] no active mode — skipping");
			return;
		}
		const overrideModel = cfg.get<string>("modelId", "");
		const modelId = overrideModel || this.opts.providerManager.resolveActiveModelId(config);
		if (!modelId) {
			this.opts.log?.appendLine("[supervisor] no model configured — skipping");
			return;
		}

		const editsSnapshot = [...this.editsBuffer.entries()].map(([path, meta]) => ({
			path,
			lastEditAt: meta.lastEditAt,
			changes: meta.changeCount,
		}));
		if (!force && editsSnapshot.length === 0) return;
		// Reset the buffer so the NEXT cycle only sees fresh edits.
		this.editsBuffer.clear();

		const userMessage = [
			"Recent edits in this workspace:",
			"",
			...editsSnapshot.map((e) => `- ${e.path} (${e.changes} save(s), last @ ${e.lastEditAt})`),
			"",
			"Inspect at most 3 of these files (use read_file / get_diagnostics / grep_search).",
			"Then return your JSON array of suggestions following the system rules.",
		].join("\n");

		const supervisorMode: ModeConfig = {
			...baseMode,
			systemPrompt: SUPERVISOR_SYSTEM_PROMPT,
			enablePlanner: false,
			enableCritic: false,
			autoApprove: false, // read-only; no edits should ever fire
			// Restrict to a read-only tool set so the supervisor can't surprise
			// the user with file writes.
			enabledTools: [
				"read_file",
				"list_dir",
				"grep_search",
				"get_diagnostics",
				"find_references",
				"find_definition",
				"get_workspace_context",
			],
			maxIterations: 6,
		};

		this.inFlight = true;
		this.currentAbort = new AbortController();
		try {
			const history = await this.opts.conductor.spawn({
				mode: supervisorMode,
				modelId,
				userMessage,
				signal: this.currentAbort.signal,
			});
			const finalText = extractFinalAssistantText(history);
			const parsed = parseSupervisorJson(finalText);
			this.appendSuggestions(parsed);
			this.opts.log?.appendLine(
				`[supervisor] ${parsed.length} suggestion(s) from ${editsSnapshot.length} file(s)`,
			);
		} catch (err) {
			this.opts.log?.appendLine(
				`[supervisor] run failed: ${err instanceof Error ? err.message : String(err)}`,
			);
		} finally {
			this.inFlight = false;
			this.currentAbort = undefined;
		}
	}

	private appendSuggestions(
		items: ReadonlyArray<Omit<SupervisorSuggestion, "id" | "emittedAt">>,
	): void {
		if (items.length === 0) return;
		const now = new Date().toISOString();
		for (const it of items) {
			const id = `sv_${Date.now().toString(36)}_${(this.nextId++).toString(36)}`;
			this.suggestions = [
				{
					id,
					message: it.message,
					...(it.path ? { path: it.path } : {}),
					...(typeof it.line === "number" ? { line: it.line } : {}),
					severity: it.severity ?? "info",
					emittedAt: now,
				},
				...this.suggestions,
			];
		}
		// Cap retention so the panel never balloons.
		if (this.suggestions.length > MAX_SUGGESTIONS) {
			this.suggestions = this.suggestions.slice(0, MAX_SUGGESTIONS);
		}
		this.notify();
	}
}

function extractFinalAssistantText(
	history: readonly import("@iom/shared").ConversationMessage[],
): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const m = history[i];
		if (m.role !== "assistant") continue;
		const text = m.parts
			.filter((p) => p.kind === "text")
			.map((p) => (p as { text: string }).text)
			.join("");
		if (text.trim().length > 0) return text;
	}
	return "";
}

/**
 * Parse the supervisor's JSON output. Tolerant of stray prose / markdown
 * fences because models leak those even with explicit "JSON only" prompts.
 * Returns an empty array on any failure — the supervisor must never throw
 * into the agent loop.
 */
export function parseSupervisorJson(
	raw: string,
): ReadonlyArray<Omit<SupervisorSuggestion, "id" | "emittedAt">> {
	const trimmed = raw.trim();
	if (trimmed.length === 0) return [];
	// Strip a code fence if present.
	const noFence = trimmed
		.replace(/^```(?:json)?\s*/i, "")
		.replace(/```\s*$/, "")
		.trim();
	// Find the first `[` and matching `]` — defensive against leading prose.
	const firstBracket = noFence.indexOf("[");
	const lastBracket = noFence.lastIndexOf("]");
	if (firstBracket < 0 || lastBracket < firstBracket) return [];
	const sliced = noFence.slice(firstBracket, lastBracket + 1);
	let arr: unknown;
	try {
		arr = JSON.parse(sliced);
	} catch {
		return [];
	}
	if (!Array.isArray(arr)) return [];
	const out: Array<Omit<SupervisorSuggestion, "id" | "emittedAt">> = [];
	for (const item of arr) {
		if (typeof item !== "object" || item === null) continue;
		const o = item as Record<string, unknown>;
		const message = typeof o.message === "string" ? o.message.trim() : "";
		if (message.length === 0 || message.length > 240) continue;
		const severity =
			o.severity === "warn" || o.severity === "suggest" || o.severity === "info" ? o.severity : "info";
		const path = typeof o.path === "string" ? o.path : undefined;
		const line = typeof o.line === "number" && o.line > 0 ? Math.floor(o.line) : undefined;
		const entry: Omit<SupervisorSuggestion, "id" | "emittedAt"> = {
			message,
			severity,
			...(path ? { path } : {}),
			...(line !== undefined ? { line } : {}),
		};
		out.push(entry);
		if (out.length >= 3) break;
	}
	return out;
}
