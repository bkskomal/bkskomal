import { promises as fs } from "node:fs";
import * as path from "node:path";
import { parseYaml } from "@iom/shared";
// Phase 0.5 follow-through (2026-06-04): replaced js-yaml with a 200-line
// hand-rolled mini-parser (see @iom/shared/yaml-mini). Saves ~86 KB of
// bundle weight at activation. The policy.yaml shape only uses key:value,
// nested mappings, allow/deny string arrays, and numeric budget values —
// well within the mini-parser's supported feature set.

/**
 * Workspace-level lockdown loaded from `.iom/policy.yaml`. The file is meant
 * to be committed to git so a team can pin its guardrails uniformly:
 *
 * ```yaml
 * providers:
 *   allow: [openrouter, anthropic]
 * models:
 *   deny: ["*-preview"]
 * tools:
 *   deny: ["exec"]
 * modes:
 *   deny: ["full-auto"]
 * budget:
 *   perSessionHardCapUsd: 10
 *   perDayHardCapUsd: 100
 * ```
 *
 * All sections are optional. A missing file, an empty file, or a file with
 * invalid YAML resolves to an empty (permissive) policy with a warning logged
 * by the caller — failing closed would lock everyone out the moment a typo
 * slipped in, so we deliberately fail open.
 */
export interface Policy {
	readonly providers: { readonly allow?: readonly string[]; readonly deny?: readonly string[] };
	readonly models: { readonly allow?: readonly string[]; readonly deny?: readonly string[] };
	readonly tools: { readonly allow?: readonly string[]; readonly deny?: readonly string[] };
	readonly modes: { readonly allow?: readonly string[]; readonly deny?: readonly string[] };
	readonly budget?: {
		readonly perSessionAlertUsd?: number;
		readonly perSessionHardCapUsd?: number;
		readonly perDayHardCapUsd?: number;
	};
}

export const EMPTY_POLICY: Policy = {
	providers: {},
	models: {},
	tools: {},
	modes: {},
} as const;

export const POLICY_FILE_REL = ".iom/policy.yaml";

export interface PolicyLoadResult {
	readonly policy: Policy;
	readonly source: "file" | "empty";
	/** Warning message, populated when the YAML was malformed or unreadable. */
	readonly warning?: string;
}

/**
 * Load and validate `<workspace>/.iom/policy.yaml`. The result is always a
 * concrete `Policy` object — even if the file is missing or invalid — so
 * callers don't need to special-case `undefined`.
 */
export async function loadPolicy(workspaceRoot: string): Promise<PolicyLoadResult> {
	if (!workspaceRoot) return { policy: EMPTY_POLICY, source: "empty" };
	const filePath = path.join(workspaceRoot, POLICY_FILE_REL);
	let raw: string;
	try {
		raw = await fs.readFile(filePath, "utf-8");
	} catch {
		return { policy: EMPTY_POLICY, source: "empty" };
	}
	try {
		const parsed = parseYaml(raw);
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
			return { policy: EMPTY_POLICY, source: "empty" };
		}
		const policy = normalize(parsed as Record<string, unknown>);
		return { policy, source: "file" };
	} catch (err) {
		const message = err instanceof Error ? err.message : String(err);
		return {
			policy: EMPTY_POLICY,
			source: "empty",
			warning: `Failed to parse ${POLICY_FILE_REL}: ${message}. Falling back to empty policy.`,
		};
	}
}

/**
 * Check whether a single value (provider id, model id, tool name, mode id)
 * passes a `{allow?, deny?}` section. Rules:
 *
 * - When `deny` matches → blocked (deny wins).
 * - When `allow` is set and `value` doesn't match → blocked.
 * - Otherwise → allowed.
 *
 * Patterns support a basic `*` glob (zero-or-more characters); anything
 * without `*` is matched as a literal string. Case-insensitive.
 */
export function isAllowed(
	value: string,
	section: { readonly allow?: readonly string[]; readonly deny?: readonly string[] },
): boolean {
	const v = value.toLowerCase();
	if (section.deny?.some((p) => matchPattern(p, v))) return false;
	if (section.allow && section.allow.length > 0) {
		return section.allow.some((p) => matchPattern(p, v));
	}
	return true;
}

/** Convenience wrappers, semantically identical to `isAllowed(value, policy.X)`. */
export function isProviderAllowed(policy: Policy, providerId: string): boolean {
	return isAllowed(providerId, policy.providers);
}
export function isModelAllowed(policy: Policy, modelId: string): boolean {
	return isAllowed(modelId, policy.models);
}
export function isToolAllowed(policy: Policy, toolName: string): boolean {
	return isAllowed(toolName, policy.tools);
}
export function isModeAllowed(policy: Policy, modeId: string): boolean {
	return isAllowed(modeId, policy.modes);
}

/**
 * Filter a modes list by the policy's mode deny/allow rules. Used by the
 * chat-panel `init` payload so denied modes are hidden from the mode picker
 * entirely.
 */
export function filterModes<T extends { readonly id: string }>(
	policy: Policy,
	modes: readonly T[],
): readonly T[] {
	return modes.filter((m) => isModeAllowed(policy, m.id));
}

/** Match a `*`-glob (or literal) pattern against `value` (already lowercased). */
function matchPattern(pattern: string, value: string): boolean {
	const p = pattern.toLowerCase();
	if (!p.includes("*")) return p === value;
	// Convert glob to regex: escape regex specials except `*`, then map `*` → `.*`.
	const re = new RegExp(`^${p.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*")}$`);
	return re.test(value);
}

function normalize(obj: Record<string, unknown>): Policy {
	return {
		providers: normalizeSection(obj.providers),
		models: normalizeSection(obj.models),
		tools: normalizeSection(obj.tools),
		modes: normalizeSection(obj.modes),
		budget: normalizeBudget(obj.budget),
	};
}

function normalizeSection(v: unknown): {
	readonly allow?: readonly string[];
	readonly deny?: readonly string[];
} {
	if (!v || typeof v !== "object") return {};
	const o = v as Record<string, unknown>;
	const out: { allow?: string[]; deny?: string[] } = {};
	if (Array.isArray(o.allow)) out.allow = o.allow.filter((x) => typeof x === "string");
	if (Array.isArray(o.deny)) out.deny = o.deny.filter((x) => typeof x === "string");
	return out;
}

function normalizeBudget(v: unknown): Policy["budget"] {
	if (!v || typeof v !== "object") return undefined;
	const o = v as Record<string, unknown>;
	const out: {
		perSessionAlertUsd?: number;
		perSessionHardCapUsd?: number;
		perDayHardCapUsd?: number;
	} = {};
	if (typeof o.perSessionAlertUsd === "number") out.perSessionAlertUsd = o.perSessionAlertUsd;
	if (typeof o.perSessionHardCapUsd === "number") out.perSessionHardCapUsd = o.perSessionHardCapUsd;
	if (typeof o.perDayHardCapUsd === "number") out.perDayHardCapUsd = o.perDayHardCapUsd;
	return Object.keys(out).length > 0 ? out : undefined;
}
