// R4-E: per-turn performance HUD + profiling.
//
// Subscribes to a Conductor's event stream and records per-turn timings:
//   - turnStart / turnEnd
//   - per-tool-call timing (start, end, duration, error flag)
//   - per-iteration latency (LLM streaming wall time)
//   - usage (input tokens, output tokens, cost) — derived from the
//     `usage` event combined with the active model id (for cost lookup).
//
// Rolling buffer of the last 20 turns per session, keyed by message id. The
// host owns mapping the agent's lifecycle to user-message ids; we expose a
// minimal `markTurnStart` / `markTurnEnd` API for that.
//
// A tiny in-memory aggregator produces a "slow tool heatmap": for each tool
// name, count + p50 + p95 latency (and error rate) over the last 100
// invocations across all turns.
//
// Pure module — no VS Code, no async I/O, no other extension-host imports.
// Cheap to instantiate and trivially testable.

import type { AgentEvent } from "@iom/shared";
import { estimateCost } from "@iom/shared";

/** Per-turn rolled-up summary, returned to the webview. */
export interface TurnSummary {
	readonly msgId: string;
	readonly sessionId: string;
	readonly turnStart: number;
	readonly turnEnd?: number;
	readonly durationMs: number;
	readonly toolCalls: number;
	readonly inputTokens: number;
	readonly outputTokens: number;
	readonly cost: number;
	readonly iterations: number;
}

/** Per-tool aggregate over the last N invocations across all turns. */
export interface ToolHeatmapEntry {
	readonly tool: string;
	readonly count: number;
	readonly p50Ms: number;
	readonly p95Ms: number;
	readonly errorRate: number;
}

interface ToolCallRecord {
	readonly tool: string;
	readonly start: number;
	end?: number;
	durationMs?: number;
	isError?: boolean;
}

interface TurnInProgress {
	readonly msgId: string;
	readonly sessionId: string;
	readonly turnStart: number;
	turnEnd?: number;
	toolCalls: number;
	inputTokens: number;
	outputTokens: number;
	cost: number;
	iterations: number;
	modelId?: string;
	/** call id -> record, for matching tool_result back to its tool_call. */
	readonly inflightTools: Map<string, ToolCallRecord>;
	/** Wall-clock start of the current iteration; cleared on `done`. */
	currentIterStart?: number;
}

const MAX_TURNS_PER_SESSION = 20;
const HEATMAP_WINDOW = 100;

/**
 * In-memory collector. One instance per ChatPanel (or one shared, keyed by
 * sessionId). Public methods are sync and inexpensive — safe to call from
 * the conductor's `on` callback without awaiting.
 */
export class PerfCollector {
	/** sessionId -> ordered list (oldest first) of completed turns. */
	private readonly turnsBySession = new Map<string, TurnSummary[]>();
	/** sessionId -> the in-progress turn, keyed by user-msg id. */
	private readonly active = new Map<string, TurnInProgress>();
	/** Recent tool invocations across all turns/sessions, for the heatmap. */
	private readonly recentToolCalls: Array<{
		readonly tool: string;
		readonly durationMs: number;
		readonly isError: boolean;
	}> = [];

	/** Start (or replace) the in-progress turn for `sessionId`. */
	markTurnStart(sessionId: string, msgId: string, now: number = Date.now(), modelId?: string): void {
		const turn: TurnInProgress = {
			msgId,
			sessionId,
			turnStart: now,
			toolCalls: 0,
			inputTokens: 0,
			outputTokens: 0,
			cost: 0,
			iterations: 0,
			inflightTools: new Map(),
			...(modelId ? { modelId } : {}),
		};
		this.active.set(sessionId, turn);
	}

	/** Mark the in-progress turn done. Roll it into the per-session buffer. */
	markTurnEnd(sessionId: string, now: number = Date.now()): TurnSummary | undefined {
		const turn = this.active.get(sessionId);
		if (!turn) return undefined;
		turn.turnEnd = now;
		// Any still-inflight tool calls at turn-end are best-effort closed as
		// errors so a hung tool doesn't silently disappear from the heatmap.
		for (const [, rec] of turn.inflightTools) {
			if (rec.end === undefined) {
				rec.end = now;
				rec.durationMs = now - rec.start;
				rec.isError = true;
				this.pushHeatmap(rec.tool, rec.durationMs, true);
			}
		}
		const summary = summarizeTurn(turn);
		this.active.delete(sessionId);
		const list = this.turnsBySession.get(sessionId) ?? [];
		list.push(summary);
		if (list.length > MAX_TURNS_PER_SESSION) list.shift();
		this.turnsBySession.set(sessionId, list);
		return summary;
	}

	/** Forward an AgentEvent into the in-progress turn (no-op when none). */
	recordEvent(sessionId: string, event: AgentEvent, now: number = Date.now()): void {
		const turn = this.active.get(sessionId);
		if (!turn) return;
		switch (event.type) {
			case "iteration": {
				turn.iterations = Math.max(turn.iterations, event.n);
				turn.currentIterStart = now;
				return;
			}
			case "tool_call": {
				turn.toolCalls += 1;
				turn.inflightTools.set(event.call.id, {
					tool: event.call.name,
					start: now,
				});
				return;
			}
			case "tool_result": {
				const rec = turn.inflightTools.get(event.result.id);
				if (!rec) return;
				rec.end = now;
				rec.durationMs = now - rec.start;
				rec.isError = event.result.isError;
				turn.inflightTools.delete(event.result.id);
				this.pushHeatmap(rec.tool, rec.durationMs, event.result.isError);
				return;
			}
			case "usage": {
				turn.inputTokens += event.inputTokens;
				turn.outputTokens += event.outputTokens;
				if (turn.modelId) {
					const c = estimateCost(turn.modelId, event.inputTokens, event.outputTokens);
					if (c) turn.cost += c.totalUsd;
				}
				return;
			}
			case "done": {
				turn.currentIterStart = undefined;
				return;
			}
			default:
				return;
		}
	}

	/** Lookup a single completed turn by msgId within a session. */
	getTurn(sessionId: string, msgId: string): TurnSummary | undefined {
		const list = this.turnsBySession.get(sessionId);
		if (!list) return undefined;
		return list.find((t) => t.msgId === msgId);
	}

	/** Newest first — most recent up to `count` turns for the session. */
	getRecent(sessionId: string, count: number = MAX_TURNS_PER_SESSION): TurnSummary[] {
		const list = this.turnsBySession.get(sessionId) ?? [];
		// Slice from the tail and reverse for newest-first display.
		const slice = list.slice(-count);
		return slice.slice().reverse();
	}

	/** p50/p95/errorRate per tool over the last HEATMAP_WINDOW invocations. */
	getHeatmap(): ToolHeatmapEntry[] {
		const byTool = new Map<string, { durations: number[]; errors: number }>();
		for (const r of this.recentToolCalls) {
			let bucket = byTool.get(r.tool);
			if (!bucket) {
				bucket = { durations: [], errors: 0 };
				byTool.set(r.tool, bucket);
			}
			bucket.durations.push(r.durationMs);
			if (r.isError) bucket.errors += 1;
		}
		const out: ToolHeatmapEntry[] = [];
		for (const [tool, bucket] of byTool) {
			const sorted = bucket.durations.slice().sort((a, b) => a - b);
			const p50 = quantile(sorted, 0.5);
			const p95 = quantile(sorted, 0.95);
			out.push({
				tool,
				count: bucket.durations.length,
				p50Ms: p50,
				p95Ms: p95,
				errorRate: bucket.durations.length === 0 ? 0 : bucket.errors / bucket.durations.length,
			});
		}
		// Sort by p95 desc by default — slowest tools surface first.
		out.sort((a, b) => b.p95Ms - a.p95Ms);
		return out;
	}

	/** Reset the in-process turn for `sessionId` without recording it (e.g. on cancel). */
	abandonTurn(sessionId: string): void {
		this.active.delete(sessionId);
	}

	private pushHeatmap(tool: string, durationMs: number, isError: boolean): void {
		this.recentToolCalls.push({ tool, durationMs, isError });
		if (this.recentToolCalls.length > HEATMAP_WINDOW) {
			// Drop oldest entries until we're at the cap.
			this.recentToolCalls.splice(0, this.recentToolCalls.length - HEATMAP_WINDOW);
		}
	}
}

function summarizeTurn(t: TurnInProgress): TurnSummary {
	const turnEnd = t.turnEnd ?? t.turnStart;
	return {
		msgId: t.msgId,
		sessionId: t.sessionId,
		turnStart: t.turnStart,
		turnEnd,
		durationMs: Math.max(0, turnEnd - t.turnStart),
		toolCalls: t.toolCalls,
		inputTokens: t.inputTokens,
		outputTokens: t.outputTokens,
		cost: t.cost,
		iterations: t.iterations,
	};
}

/** Linear-interpolation quantile on an already-sorted array. */
function quantile(sorted: readonly number[], q: number): number {
	if (sorted.length === 0) return 0;
	if (sorted.length === 1) return sorted[0];
	const pos = (sorted.length - 1) * q;
	const lo = Math.floor(pos);
	const hi = Math.ceil(pos);
	if (lo === hi) return sorted[lo];
	const frac = pos - lo;
	return sorted[lo] * (1 - frac) + sorted[hi] * frac;
}
