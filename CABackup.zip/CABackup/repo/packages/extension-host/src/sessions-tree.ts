import type { SessionMeta } from "@iom/shared";
import * as vscode from "vscode";
import type { SessionStore } from "./session-store";

/**
 * Custom sidebar webview that replaces the default TreeView with a Claude-style
 * panel: a "+ New session" button at the top, a search input, then a flat
 * list of sessions with hover-revealed rename/delete actions.
 *
 * The "tree" name on the class is kept for backward compat with existing
 * extension.ts imports (it used to be a TreeDataProvider); behavior is now
 * pure WebviewViewProvider.
 */
export class SessionsTreeProvider implements vscode.WebviewViewProvider {
	private view: vscode.WebviewView | undefined;
	private activeSessionId: string | undefined;
	private onOpenCallback: ((id: string) => void) | undefined;
	private onNewCallback: (() => void) | undefined;
	private onRenameCallback: ((id: string, newTitle: string) => Promise<void>) | undefined;
	private onDeleteCallback: ((id: string) => Promise<void>) | undefined;
	/**
	 * 2026-06-16: optional filter that returns the set of session ids that
	 * should NOT show in the sidebar. Used to hide Settings-tab sessions —
	 * they exist in `session.list()` for the underlying ChatPanel's
	 * machinery but they're not chats the user authored, so showing them
	 * in the history list is noise (one new row every time Settings opens).
	 * When unset, no filtering happens.
	 */
	private getHiddenSessionIds: (() => ReadonlySet<string>) | undefined;

	constructor(private readonly session: SessionStore) {}

	/**
	 * Wire up handlers from extension.ts. Splitting the constructor and the
	 * binder keeps the activation-time order issue avoidable (extension.ts
	 * instantiates this early, then sets the callbacks once `panels` exists).
	 */
	bind(handlers: {
		onOpen(id: string): void;
		onNew(): void;
		onRename(id: string, newTitle: string): Promise<void>;
		onDelete(id: string): Promise<void>;
		getHiddenSessionIds?(): ReadonlySet<string>;
	}): void {
		this.onOpenCallback = handlers.onOpen;
		this.onNewCallback = handlers.onNew;
		this.onRenameCallback = handlers.onRename;
		this.onDeleteCallback = handlers.onDelete;
		this.getHiddenSessionIds = handlers.getHiddenSessionIds;
	}

	/** Re-render the session list. Called on session save/rename/delete. */
	refresh(): void {
		void this.broadcast();
	}

	/** Mark a session as active so the row gets highlighted. */
	setActive(sessionId: string | undefined): void {
		this.activeSessionId = sessionId;
		void this.broadcast();
	}

	resolveWebviewView(
		webviewView: vscode.WebviewView,
		_context: vscode.WebviewViewResolveContext,
		_token: vscode.CancellationToken,
	): void {
		this.view = webviewView;
		webviewView.webview.options = { enableScripts: true };
		webviewView.webview.html = this.renderHtml();

		webviewView.webview.onDidReceiveMessage((msg: unknown) => {
			void this.handleMessage(msg);
		});
		webviewView.onDidDispose(() => {
			if (this.view === webviewView) this.view = undefined;
		});
		// First paint after the webview's `ready` handshake — see handleMessage.
	}

	private async handleMessage(raw: unknown): Promise<void> {
		if (typeof raw !== "object" || raw === null) return;
		const msg = raw as { type?: string };
		switch (msg.type) {
			case "ready":
				await this.broadcast();
				return;
			case "new":
				this.onNewCallback?.();
				return;
			case "open": {
				const id = (raw as { id?: string }).id;
				if (id) this.onOpenCallback?.(id);
				return;
			}
			case "rename": {
				const { id, title } = raw as { id?: string; title?: string };
				if (id && title !== undefined && this.onRenameCallback) {
					await this.onRenameCallback(id, title);
				}
				await this.broadcast();
				return;
			}
			case "delete": {
				const id = (raw as { id?: string }).id;
				if (id && this.onDeleteCallback) {
					const confirm = await vscode.window.showWarningMessage(
						"Delete this chat? This cannot be undone.",
						{ modal: true },
						"Delete",
					);
					if (confirm === "Delete") {
						await this.onDeleteCallback(id);
					}
				}
				await this.broadcast();
				return;
			}
			case "delete_many": {
				const ids = (raw as { ids?: readonly string[] }).ids ?? [];
				if (ids.length > 0 && this.onDeleteCallback) {
					const confirm = await vscode.window.showWarningMessage(
						`Delete ${ids.length} selected chat${ids.length === 1 ? "" : "s"}? This cannot be undone.`,
						{ modal: true },
						"Delete",
					);
					if (confirm === "Delete") {
						const cb = this.onDeleteCallback;
						for (const id of ids) {
							try {
								await cb(id);
							} catch {
								/* keep going on individual failure */
							}
						}
					}
				}
				await this.broadcast();
				return;
			}
			case "delete_all": {
				if (this.onDeleteCallback) {
					const list = await this.session.list();
					if (list.length === 0) {
						await this.broadcast();
						return;
					}
					const confirm = await vscode.window.showWarningMessage(
						`Delete ALL ${list.length} chats? This cannot be undone.`,
						{ modal: true, detail: "Every chat in this workspace will be removed." },
						"Delete All",
					);
					if (confirm === "Delete All") {
						const cb = this.onDeleteCallback;
						for (const s of list) {
							try {
								await cb(s.id);
							} catch {
								/* keep going */
							}
						}
					}
				}
				await this.broadcast();
				return;
			}
			default:
				return;
		}
	}

	private async broadcast(): Promise<void> {
		if (!this.view) return;
		const list = await this.session.list();
		// 2026-06-16: filter out hidden sessions (Settings tabs). They live
		// in the SessionStore so the ChatPanel can render, but they're not
		// chats the user authored, so the sidebar should treat them as
		// invisible. When `getHiddenSessionIds` is unset (older callers,
		// tests), no filtering happens — preserves existing behaviour.
		const hidden = this.getHiddenSessionIds?.() ?? new Set<string>();
		const items = list
			.filter((s: SessionMeta) => !hidden.has(s.id))
			.map((s: SessionMeta) => ({
				id: s.id,
				title: s.title,
				messageCount: s.messageCount,
				lastUpdatedAt: s.lastUpdatedAt,
				active: s.id === this.activeSessionId,
			}));
		void this.view.webview.postMessage({ type: "sessions", items });
	}

	private renderHtml(): string {
		// Inline CSS + JS — small enough that an external bundle would be
		// overkill. The webview lives in the Activity Bar so layout is fixed
		// to a single narrow column.
		const csp = `default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';`;
		return `<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Security-Policy" content="${csp}" />
<style>
  :root {
    --bg: var(--vscode-sideBar-background);
    --fg: var(--vscode-sideBar-foreground, var(--vscode-foreground));
    --muted: var(--vscode-descriptionForeground, #888);
    --border: var(--vscode-panel-border, #333);
    --row-hover: var(--vscode-list-hoverBackground, rgba(255,255,255,0.06));
    --row-active: var(--vscode-list-activeSelectionBackground, #094771);
    --row-active-fg: var(--vscode-list-activeSelectionForeground, #fff);
    --input-bg: var(--vscode-input-background);
    --input-border: var(--vscode-input-border, #3c3c3c);
    --accent: var(--vscode-button-background, #0e639c);
    --accent-fg: var(--vscode-button-foreground, #fff);
  }
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; height: 100vh; }
  body {
    background: var(--bg);
    color: var(--fg);
    font-family: var(--vscode-font-family, system-ui, sans-serif);
    font-size: 13px;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .header {
    margin: 8px;
    display: flex;
    align-items: stretch;
    gap: 4px;
  }
  .new-btn {
    flex: 1;
    padding: 6px 10px;
    background: transparent;
    color: var(--fg);
    border: 1px solid var(--input-border);
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-family: inherit;
  }
  .new-btn:hover { background: var(--row-hover); }
  .new-btn .plus { font-weight: 600; font-size: 14px; line-height: 1; }
  .header-icon-btn {
    padding: 6px 8px;
    background: transparent;
    color: var(--fg);
    border: 1px solid var(--input-border);
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0.7;
  }
  .header-icon-btn:hover { opacity: 1; background: var(--row-hover); color: var(--vscode-errorForeground, #f48771); }
  .header-icon-btn:disabled { opacity: 0.3; cursor: not-allowed; }
  .header-icon-btn:disabled:hover { background: transparent; color: var(--fg); }
  /* --- Multi-select action bar (sticky bottom when ≥1 row selected) --- */
  .selection-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px;
    background: var(--accent);
    color: var(--accent-fg);
    border-radius: 4px;
    margin: 0 8px 8px 8px;
    font-size: 12px;
  }
  .selection-bar .count { flex: 1; }
  .selection-bar button {
    background: transparent;
    border: 1px solid rgba(255,255,255,0.4);
    color: inherit;
    padding: 3px 10px;
    border-radius: 3px;
    cursor: pointer;
    font-family: inherit;
    font-size: 12px;
  }
  .selection-bar button:hover { background: rgba(255,255,255,0.15); }
  /* --- Row checkbox (hover-visible) --- */
  .row .checkbox {
    flex-shrink: 0;
    width: 14px;
    height: 14px;
    border: 1.5px solid var(--muted);
    border-radius: 3px;
    display: none;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    background: transparent;
  }
  .row:hover .checkbox,
  .row.selected .checkbox { display: flex; }
  .row.selected .checkbox {
    background: var(--accent);
    border-color: var(--accent);
  }
  .row.selected .checkbox::after {
    content: "✓";
    color: var(--accent-fg);
    font-size: 10px;
    line-height: 1;
    font-weight: 700;
  }
  .row.selected { background: rgba(14, 99, 156, 0.18); }
  .search-wrap {
    margin: 0 8px 8px 8px;
    position: relative;
  }
  .search-wrap .icon {
    position: absolute;
    left: 8px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--muted);
    pointer-events: none;
  }
  .search-input {
    width: 100%;
    padding: 4px 8px 4px 26px;
    background: var(--input-bg);
    color: var(--fg);
    border: 1px solid var(--input-border);
    border-radius: 4px;
    font-family: inherit;
    font-size: 12px;
  }
  .search-input:focus { outline: 1px solid var(--accent); }
  .list { flex: 1; overflow-y: auto; padding: 0 4px 8px 4px; }
  .row {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 8px;
    border-radius: 4px;
    cursor: pointer;
    position: relative;
  }
  .row:hover { background: var(--row-hover); }
  .row.active { background: var(--row-active); color: var(--row-active-fg); }
  .row .title {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .row .time { color: var(--muted); font-size: 11px; flex-shrink: 0; }
  .row.active .time { color: var(--row-active-fg); opacity: 0.85; }
  .row .actions {
    display: none;
    align-items: center;
    gap: 2px;
    flex-shrink: 0;
  }
  .row:hover .actions { display: flex; }
  .row:hover .time { display: none; }
  .row .action {
    background: transparent;
    border: none;
    color: inherit;
    cursor: pointer;
    padding: 2px 4px;
    border-radius: 2px;
    opacity: 0.7;
  }
  .row .action:hover { opacity: 1; background: rgba(255,255,255,0.1); }
  .row .action svg { display: block; }
  .empty { padding: 16px 12px; color: var(--muted); font-size: 12px; text-align: center; }
  .row input.rename-input {
    flex: 1;
    background: var(--input-bg);
    color: var(--fg);
    border: 1px solid var(--accent);
    border-radius: 3px;
    padding: 2px 6px;
    font-family: inherit;
    font-size: 13px;
    outline: none;
  }
</style>
</head>
<body>
<div class="header">
  <button class="new-btn" id="new-btn" title="New Session">
    <span class="plus">+</span><span>New Session</span>
  </button>
  <button class="header-icon-btn" id="delete-all-btn" title="Delete all chats" aria-label="Delete all chats">
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">
      <path d="M3 4 L13 4 M6 4 V2 H10 V4 M5 4 L5.5 14 H10.5 L11 4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  </button>
</div>
<div id="selection-bar-slot"></div>
<div class="search-wrap">
  <svg class="icon" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5">
    <circle cx="7" cy="7" r="4.5" />
    <path d="M10.5 10.5 L13 13" stroke-linecap="round" />
  </svg>
  <input class="search-input" id="search" type="text" placeholder="Search chats..." autocomplete="off" />
</div>
<div class="list" id="list">
  <div class="empty">No chats yet.</div>
</div>
<script>
(function() {
  const vscode = acquireVsCodeApi();
  const listEl = document.getElementById('list');
  const searchEl = document.getElementById('search');
  const newBtn = document.getElementById('new-btn');
  const deleteAllBtn = document.getElementById('delete-all-btn');
  const selectionBarSlot = document.getElementById('selection-bar-slot');
  let sessions = [];
  let renamingId = null;
  // 2026-06-01: multi-select state. A Set of session ids the user has
  // ticked via the row checkboxes. When non-empty, a sticky action bar
  // surfaces a "Delete (N)" button + Clear. Survives across re-renders
  // (we only drop ids that disappear from the session list).
  const selectedIds = new Set();

  function relTime(iso) {
    try {
      const d = new Date(iso);
      const diff = Date.now() - d.getTime();
      const mins = Math.floor(diff / 60000);
      if (mins < 1) return 'now';
      if (mins < 60) return mins + 'm';
      const hours = Math.floor(mins / 60);
      if (hours < 24) return hours + 'h';
      const days = Math.floor(hours / 24);
      if (days < 30) return days + 'd';
      const months = Math.floor(days / 30);
      if (months < 12) return months + 'mo';
      return Math.floor(months / 12) + 'y';
    } catch { return ''; }
  }

  function escapeHtml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function pruneSelectionAgainstSessions() {
    // Drop selected ids that no longer exist in the session list (e.g.
    // because a delete just landed). Keeps selectedIds an accurate
    // subset of the rendered set.
    const liveIds = new Set(sessions.map(s => s.id));
    for (const id of [...selectedIds]) {
      if (!liveIds.has(id)) selectedIds.delete(id);
    }
  }

  function renderSelectionBar() {
    if (selectedIds.size === 0) {
      selectionBarSlot.innerHTML = '';
      return;
    }
    const n = selectedIds.size;
    selectionBarSlot.innerHTML =
      '<div class="selection-bar">' +
        '<span class="count">' + n + ' selected</span>' +
        '<button id="bar-delete" type="button">Delete</button>' +
        '<button id="bar-clear" type="button">Clear</button>' +
      '</div>';
    const delBtn = document.getElementById('bar-delete');
    const clrBtn = document.getElementById('bar-clear');
    if (delBtn) delBtn.addEventListener('click', () => {
      vscode.postMessage({ type: 'delete_many', ids: [...selectedIds] });
    });
    if (clrBtn) clrBtn.addEventListener('click', () => {
      selectedIds.clear();
      render();
    });
  }

  function render() {
    pruneSelectionAgainstSessions();
    renderSelectionBar();
    // The delete-all button is meaningless on an empty session list.
    if (deleteAllBtn) deleteAllBtn.disabled = sessions.length === 0;
    const q = searchEl.value.trim().toLowerCase();
    const filtered = q
      ? sessions.filter(s => s.title.toLowerCase().includes(q))
      : sessions;
    if (filtered.length === 0) {
      listEl.innerHTML = '<div class="empty">' +
        (sessions.length === 0 ? 'No chats yet.' : 'No chats match.') +
        '</div>';
      return;
    }
    listEl.innerHTML = filtered.map(s => {
      const isRenaming = s.id === renamingId;
      if (isRenaming) {
        return '<div class="row" data-id="' + s.id + '">' +
          '<input class="rename-input" type="text" value="' + escapeHtml(s.title) + '" />' +
          '</div>';
      }
      const isSelected = selectedIds.has(s.id);
      const rowClasses = [
        'row',
        s.active ? 'active' : '',
        isSelected ? 'selected' : '',
      ].filter(Boolean).join(' ');
      return '<div class="' + rowClasses + '" data-id="' + s.id + '">' +
        '<span class="checkbox" data-act="toggle-select" role="checkbox" aria-checked="' + isSelected + '" tabindex="-1" title="Select"></span>' +
        '<span class="title">' + escapeHtml(s.title) + '</span>' +
        '<span class="time">' + relTime(s.lastUpdatedAt) + '</span>' +
        '<span class="actions">' +
          '<button class="action" data-act="rename" title="Rename">' +
            '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M11 2 L14 5 L5 14 L2 14 L2 11 Z" stroke-linejoin="round"/></svg>' +
          '</button>' +
          '<button class="action" data-act="delete" title="Delete">' +
            '<svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 4 L13 4 M6 4 V2 H10 V4 M5 4 L5.5 14 H10.5 L11 4" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
          '</button>' +
        '</span>' +
        '</div>';
    }).join('');
  }

  function commitRename(id, value) {
    const trimmed = value.trim();
    renamingId = null;
    if (trimmed.length > 0) {
      vscode.postMessage({ type: 'rename', id, title: trimmed });
    } else {
      render();
    }
  }

  listEl.addEventListener('click', e => {
    const row = e.target.closest('.row');
    if (!row) return;
    const id = row.getAttribute('data-id');
    if (!id) return;
    // Checkbox click → toggle in selection set, no row open.
    const cb = e.target.closest('.checkbox');
    if (cb) {
      e.stopPropagation();
      if (selectedIds.has(id)) selectedIds.delete(id);
      else selectedIds.add(id);
      render();
      return;
    }
    const actBtn = e.target.closest('.action');
    if (actBtn) {
      const act = actBtn.getAttribute('data-act');
      if (act === 'rename') {
        renamingId = id;
        render();
        const input = listEl.querySelector('.rename-input');
        if (input) { input.focus(); input.select(); }
      } else if (act === 'delete') {
        vscode.postMessage({ type: 'delete', id });
      }
      return;
    }
    if (renamingId) return;
    vscode.postMessage({ type: 'open', id });
  });

  listEl.addEventListener('keydown', e => {
    const input = e.target.closest('.rename-input');
    if (!input) return;
    const row = input.closest('.row');
    const id = row && row.getAttribute('data-id');
    if (!id) return;
    if (e.key === 'Enter') { e.preventDefault(); commitRename(id, input.value); }
    if (e.key === 'Escape') { e.preventDefault(); renamingId = null; render(); }
  });
  listEl.addEventListener('blur', e => {
    const input = e.target.closest && e.target.closest('.rename-input');
    if (!input) return;
    const row = input.closest('.row');
    const id = row && row.getAttribute('data-id');
    if (id && renamingId === id) commitRename(id, input.value);
  }, true);

  searchEl.addEventListener('input', render);
  newBtn.addEventListener('click', () => vscode.postMessage({ type: 'new' }));
  if (deleteAllBtn) {
    deleteAllBtn.addEventListener('click', () => {
      if (sessions.length === 0) return;
      vscode.postMessage({ type: 'delete_all' });
    });
  }

  window.addEventListener('message', e => {
    const msg = e.data;
    if (msg && msg.type === 'sessions') {
      sessions = msg.items || [];
      render();
    }
  });

  vscode.postMessage({ type: 'ready' });
})();
</script>
</body>
</html>`;
	}
}
