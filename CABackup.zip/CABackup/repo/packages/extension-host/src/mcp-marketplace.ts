// R4-D: MCP server marketplace manager.
//
// Thin orchestration layer that mediates between the curated registry
// (`MCP_REGISTRY`), the persisted user settings (`SettingsStore`) and the
// live MCP process lifecycle (`McpManager`). The webview's marketplace view
// talks to this via the chat-panel RPC arms.
//
// "Installed" means a row exists in `settings.config.mcpServers` whose id
// matches the registry entry id. "Enabled" means that row has
// `enabled: true` and the McpManager is keeping a live subprocess for it.

import type { McpServerConfig } from "@iom/shared";
import type { McpManager } from "./mcp-manager";
import { MCP_REGISTRY, type McpRegistryEntry, getMcpRegistryEntry } from "./mcp-registry";
import type { SettingsStore } from "./settings-store";

export interface MarketplaceItem {
	readonly entry: McpRegistryEntry;
	readonly installed: boolean;
	readonly enabled: boolean;
}

export class MarketplaceManager {
	constructor(
		private readonly settings: SettingsStore,
		private readonly mcpManager: McpManager,
	) {}

	/** Snapshot of every registry entry with its current installed/enabled state. */
	list(): MarketplaceItem[] {
		const servers = this.settings.config.mcpServers ?? [];
		return MCP_REGISTRY.map((entry) => {
			const existing = servers.find((s) => s.id === entry.id);
			return {
				entry,
				installed: !!existing,
				enabled: !!existing?.enabled,
			};
		});
	}

	/**
	 * Append a fresh `McpServerConfig` for the given registry id. Disabled by
	 * default — the user must explicitly enable it (which surfaces the
	 * third-party-code approval banner) before the subprocess actually starts.
	 * No-ops if already installed.
	 */
	async install(id: string): Promise<void> {
		const entry = getMcpRegistryEntry(id);
		if (!entry) throw new Error(`Unknown marketplace entry: ${id}`);
		const current = this.settings.config.mcpServers ?? [];
		if (current.some((s) => s.id === entry.id)) {
			// Already installed; nothing to do. Still resync to make sure the
			// live process state matches the persisted enabled flag.
			await this.mcpManager.syncWith(current);
			return;
		}
		const cfg: McpServerConfig = {
			id: entry.id,
			displayName: entry.displayName,
			command: entry.install.command,
			...(entry.install.args ? { args: [...entry.install.args] } : {}),
			...(entry.install.env ? { env: { ...entry.install.env } } : {}),
			enabled: false,
			approval: "prompt",
		};
		const next = [...current, cfg];
		await this.persist(next);
		await this.mcpManager.syncWith(next);
	}

	/**
	 * Flip the `enabled` flag on the matching row. Toggling on starts the
	 * subprocess; toggling off stops it. Throws if the entry hasn't been
	 * installed yet — the UI should call `install` first.
	 */
	async setEnabled(id: string, enabled: boolean): Promise<void> {
		const current = this.settings.config.mcpServers ?? [];
		const idx = current.findIndex((s) => s.id === id);
		if (idx < 0) throw new Error(`Marketplace entry not installed: ${id}`);
		if (current[idx].enabled === enabled) {
			// No-op; nothing to persist. Still resync defensively so a missed
			// previous sync doesn't strand the process in a stale state.
			await this.mcpManager.syncWith(current);
			return;
		}
		const next = [...current];
		next[idx] = { ...next[idx], enabled };
		await this.persist(next);
		await this.mcpManager.syncWith(next);
	}

	/**
	 * Remove the entry from settings entirely. The McpManager.syncWith call
	 * stops any matching live subprocess as a side-effect.
	 */
	async uninstall(id: string): Promise<void> {
		const current = this.settings.config.mcpServers ?? [];
		if (!current.some((s) => s.id === id)) return;
		const next = current.filter((s) => s.id !== id);
		await this.persist(next);
		await this.mcpManager.syncWith(next);
	}

	private async persist(mcpServers: readonly McpServerConfig[]): Promise<void> {
		const cfg = this.settings.config;
		await this.settings.updateConfig({
			activeProviderId: cfg.activeProviderId,
			activeModeId: cfg.activeModeId,
			providers: [...cfg.providers],
			modes: [...cfg.modes],
			mcpServers,
		});
	}
}
