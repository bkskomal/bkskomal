import type { ConversationMessage, ProviderSpec } from "@iom/shared";

/**
 * Trim the middle of a long conversation to keep the agent's working context
 * focused. Keeps the first 2 turns (task framing) and the last 10 turns
 * (recent context), and asks the provider to replace the dropped middle with
 * a 2-paragraph summary so the agent retains the gist of what happened.
 *
 * When no `summarize` callback is supplied (e.g. tests, or when no provider is
 * configured), falls back to a placeholder system marker noting how many turns
 * were dropped — matching the previous behavior.
 *
 * Lives in its own module (rather than chat-panel.ts) so tests can pull it
 * in without bringing the `vscode` module along.
 */

export const COMPACTION_HEAD = 2;
export const COMPACTION_TAIL = 10;

export interface CompactHistoryOptions {
	/**
	 * Async summarizer hook. Receives the dropped middle segment and returns a
	 * 2-paragraph summary string. When omitted, a placeholder marker is used.
	 */
	readonly summarize?: (segment: readonly ConversationMessage[]) => Promise<string>;
}

export async function compactHistory(
	history: readonly ConversationMessage[],
	opts: CompactHistoryOptions = {},
): Promise<ConversationMessage[]> {
	if (history.length <= COMPACTION_HEAD + COMPACTION_TAIL) return [...history];
	const head = history.slice(0, COMPACTION_HEAD);
	const tail = history.slice(history.length - COMPACTION_TAIL);
	const middle = history.slice(COMPACTION_HEAD, history.length - COMPACTION_TAIL);
	const droppedCount = middle.length;

	let summaryText: string;
	if (opts.summarize) {
		try {
			const generated = (await opts.summarize(middle)).trim();
			summaryText =
				generated.length > 0
					? `[Summary of ${droppedCount} compacted messages]\n\n${generated}`
					: `[${droppedCount} messages compacted — agent context trimmed to keep it focused]`;
		} catch {
			// Summarizer failures (provider down, signal aborted, etc.) shouldn't
			// brick /compact — fall back to the marker.
			summaryText = `[${droppedCount} messages compacted — agent context trimmed to keep it focused]`;
		}
	} else {
		summaryText = `[${droppedCount} messages compacted — agent context trimmed to keep it focused]`;
	}

	const marker: ConversationMessage = {
		role: "system",
		parts: [{ kind: "text", text: summaryText }],
	};
	return [...head, marker, ...tail];
}

/**
 * Convenience factory: wires `summarizeHistorySegment` (in @iom/agent-core) to
 * the `summarize` callback shape `compactHistory` expects. Kept here so
 * chat-panel.ts doesn't have to know the rendering glue.
 */
export function makeProviderSummarizer(
	provider: ProviderSpec,
	modelId: string,
	signal?: AbortSignal,
): (segment: readonly ConversationMessage[]) => Promise<string> {
	return async (segment) => {
		const { summarizeHistorySegment } = await import("@iom/agent-core");
		return summarizeHistorySegment(segment, provider, modelId, { signal });
	};
}
