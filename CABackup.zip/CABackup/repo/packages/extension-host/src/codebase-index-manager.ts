import * as path from "node:path";
import {
	CodebaseIndex,
	type EmbedderId,
	type EmbedderProvider,
	type IndexProgress,
	TfIdfEmbedder,
	createEmbedder,
} from "@iom/codebase-index";
import type { CodebaseSearchProvider } from "@iom/shared";
import * as vscode from "vscode";

// R8-B: per-provider secret-storage keys exposed for the host's
// "Set Codebase Embedder API Key" command. Re-exported from the index package
// so the rest of the host doesn't have to import that package directly.
export { SECRET_KEYS as CODEBASE_EMBEDDER_SECRET_KEYS } from "@iom/codebase-index";

/**
 * Process-wide owner of the workspace's codebase index. Singleton at the
 * extension-host level so multiple chat panels share one SQLite handle and
 * one set of embeddings — opening a second panel doesn't pay the indexing
 * cost twice.
 *
 * Lazy: we never touch the disk until the first `code_semantic_search` call
 * or `/reindex` request. Activation cost matters for cold-start latency.
 */
export class CodebaseIndexManager {
	private index: CodebaseIndex | undefined;
	private indexing = false;
	// R8-B: cached active embedder + the SecretStorage handle the host gave us.
	// `secrets` is set via `setSecretStorage()` at activation time; until then
	// we fall back to TF-IDF (no API key needed) so behavior degrades gracefully
	// in test harnesses.
	private secrets: vscode.SecretStorage | undefined;
	private activeEmbedder: EmbedderProvider | undefined;

	// R8-B: wire the host's `vscode.SecretStorage` so remote embedders can
	// fetch their API keys. Idempotent.
	setSecretStorage(secrets: vscode.SecretStorage): void {
		this.secrets = secrets;
	}

	// R8-B: read the user's chosen embedder from `iom.codebaseIndex.embedder`.
	// Falls back to "tfidf" when unset or unrecognized.
	private readEmbedderId(): EmbedderId {
		const cfg = vscode.workspace.getConfiguration("iom.codebaseIndex");
		const raw = cfg.get<string>("embedder") ?? "tfidf";
		if (raw === "openai" || raw === "voyage" || raw === "cohere" || raw === "tfidf") return raw;
		return "tfidf";
	}

	// R8-B: build the active embedder. Remote providers receive a `getSecret`
	// callback that delegates to `vscode.SecretStorage`; when no storage is
	// wired we silently fall back to TF-IDF rather than throwing — better to
	// produce *some* index than block activation.
	private buildEmbedder(): EmbedderProvider {
		const id = this.readEmbedderId();
		if (id === "tfidf" || !this.secrets) {
			return {
				id: "tfidf",
				displayName: "Local TF-IDF (offline)",
				dimensions: 256,
				dim: 256,
				embed: (texts) => new TfIdfEmbedder().embed(texts),
			};
		}
		const secrets = this.secrets;
		return createEmbedder({
			id,
			getSecret: async (key) => {
				try {
					return await secrets.get(key);
				} catch {
					return undefined;
				}
			},
		});
	}

	getOrCreate(): CodebaseIndex | undefined {
		if (this.index) return this.index;
		const root = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
		if (!root) return undefined;
		const dbPath = path.join(root, ".iom", "index.sqlite");
		// R8-B: pick the active embedder from `iom.codebaseIndex.embedder`.
		// Defaults to TF-IDF (offline) so first-launch never blocks on an API
		// key. The IndexStore will wipe the SQLite tables on a dimension or
		// embedder-id mismatch so we never mix vector spaces.
		this.activeEmbedder = this.buildEmbedder();
		this.index = new CodebaseIndex({
			workspaceRoot: root,
			dbPath,
			embedder: this.activeEmbedder,
		});
		return this.index;
	}

	// R8-B: surface the active embedder so the chat-panel can emit the
	// `embedder_state` event for the webview header pill. Returns `undefined`
	// before `getOrCreate()` has been called.
	getActiveEmbedderInfo():
		| { readonly id: string; readonly displayName: string; readonly dimensions: number }
		| undefined {
		const e = this.activeEmbedder;
		if (!e) return undefined;
		return { id: e.id, displayName: e.displayName, dimensions: e.dimensions };
	}

	// R8-B: caller (extension.ts) invokes this after the user picks a new
	// embedder so the next reindex builds with the new provider. Closes the
	// current index handle; the next `getOrCreate()` re-opens against the same
	// SQLite file (the store wipes on id mismatch).
	resetForEmbedderChange(): void {
		this.index?.close();
		this.index = undefined;
		this.activeEmbedder = undefined;
	}

	/** Returns a `CodebaseSearchProvider` view for HostContext consumers. */
	asSearchProvider(): CodebaseSearchProvider | undefined {
		const idx = this.getOrCreate();
		if (!idx) return undefined;
		return {
			query: (text, opts) => idx.query(text, opts),
		};
	}

	/**
	 * Kick off a full reindex. Concurrent calls are merged: a second call
	 * while one is in flight just waits for the first to finish. We don't
	 * cancel mid-run because the indexer is mostly I/O and tearing it down
	 * leaves the SQLite in an inconsistent (but recoverable) state.
	 */
	async reindex(onProgress?: (p: IndexProgress) => void): Promise<{
		ok: boolean;
		chunks: number;
		files: number;
		message?: string;
	}> {
		const idx = this.getOrCreate();
		if (!idx) {
			return { ok: false, chunks: 0, files: 0, message: "No workspace folder open." };
		}
		if (this.indexing) {
			return { ok: false, chunks: 0, files: 0, message: "Indexing already in progress." };
		}
		this.indexing = true;
		try {
			await idx.indexAll({ onProgress });
			const stats = idx.stats();
			return { ok: true, chunks: stats.chunks, files: stats.files };
		} finally {
			this.indexing = false;
		}
	}

	dispose(): void {
		this.index?.close();
		this.index = undefined;
	}
}
