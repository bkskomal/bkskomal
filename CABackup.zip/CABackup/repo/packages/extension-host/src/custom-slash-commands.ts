import { promises as fs } from "node:fs";
import * as path from "node:path";
import { parseYaml } from "@iom/shared";

export interface CustomSlashCommand {
	/** Slash command name (filename minus `.md`). */
	readonly name: string;
	/** Short description, derived from frontmatter `description:` or the first `# title` heading. */
	readonly description: string;
	/** Template body — `{{input}}` is substituted with the user's text at run-time. */
	readonly template: string;
	/**
	 * Phase 4 polish follow-through (2026-06-04): optional metadata from
	 * the file's YAML frontmatter. None of these are required — commands
	 * without frontmatter keep working unchanged.
	 */
	readonly icon?: string;
	readonly category?: string;
	readonly aliases?: readonly string[];
}

/** Slash command names follow the same shape as a CLI flag: word chars + dashes. */
const VALID_NAME = /^[a-zA-Z0-9_-]+$/;

/**
 * Scan `<workspacePath>/.iom/commands/*.md` for user-defined slash commands.
 *
 * Each file is parsed as:
 *   - filename (without `.md`) → command name (must match `[a-zA-Z0-9_-]+`)
 *   - first `# heading` line → description (falls back to the name if absent)
 *   - everything else → template body; `{{input}}` is replaced at run-time with
 *     whatever the user typed after the command.
 *
 * Returns an empty list if the directory doesn't exist or is unreadable — callers
 * treat any failure as "no custom commands available" rather than surfacing errors.
 */
export async function loadCustomSlashCommands(
	workspacePath: string,
): Promise<CustomSlashCommand[]> {
	if (!workspacePath) return [];
	const dir = path.join(workspacePath, ".iom", "commands");
	let entries: string[];
	try {
		entries = await fs.readdir(dir);
	} catch {
		return [];
	}
	const out: CustomSlashCommand[] = [];
	for (const entry of entries) {
		if (!entry.toLowerCase().endsWith(".md")) continue;
		const name = entry.slice(0, -3);
		if (!VALID_NAME.test(name)) continue;
		const abs = path.join(dir, entry);
		let raw: string;
		try {
			const stat = await fs.stat(abs);
			if (!stat.isFile()) continue;
			raw = await fs.readFile(abs, "utf-8");
		} catch {
			continue;
		}
		out.push(parseCommand(name, raw));
	}
	out.sort((a, b) => a.name.localeCompare(b.name));
	return out;
}

function parseCommand(name: string, raw: string): CustomSlashCommand {
	// Phase 4 polish follow-through (2026-06-04): parse optional YAML
	// frontmatter (---\n...\n---\n) at the top of the file. Recognised
	// keys: description, icon, category, aliases. Anything we don't
	// recognise is silently ignored so future fields can land
	// non-breakingly.
	const fmMatch = /^---\s*\r?\n([\s\S]*?)\r?\n---\s*\r?\n([\s\S]*)$/m.exec(raw);
	let frontMatter: Record<string, unknown> | undefined;
	let body = raw;
	if (fmMatch) {
		const fmRaw = fmMatch[1] ?? "";
		body = (fmMatch[2] ?? "").replace(/^\s*\n/, "");
		try {
			const parsed = parseYaml(fmRaw);
			if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
				frontMatter = parsed as Record<string, unknown>;
			}
		} catch {
			// Malformed frontmatter — drop the metadata but KEEP the
			// after-frontmatter body. Resetting `body = raw` would put the
			// `---...---` block back in front of the heading parser and
			// the description would fall back to the filename.
		}
	}

	const lines = body.split(/\r?\n/);
	let description = name;
	let bodyStart = 0;
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		if (line.trim().length === 0) continue;
		const match = /^#\s+(.+?)\s*$/.exec(line);
		if (match) {
			description = match[1];
			bodyStart = i + 1;
		}
		break;
	}
	// Strip a single leading blank line after the heading so templates look clean
	// without forcing authors to remove it.
	if (bodyStart > 0 && lines[bodyStart]?.trim().length === 0) bodyStart++;
	const template = lines.slice(bodyStart).join("\n");

	if (frontMatter) {
		const fmDescription =
			typeof frontMatter.description === "string" && frontMatter.description.trim().length > 0
				? frontMatter.description.trim()
				: undefined;
		const fmIcon =
			typeof frontMatter.icon === "string" && frontMatter.icon.trim().length > 0
				? frontMatter.icon.trim()
				: undefined;
		const fmCategory =
			typeof frontMatter.category === "string" && frontMatter.category.trim().length > 0
				? frontMatter.category.trim()
				: undefined;
		const fmAliases = Array.isArray(frontMatter.aliases)
			? (frontMatter.aliases as unknown[]).filter(
					(a): a is string => typeof a === "string" && VALID_NAME.test(a),
				)
			: undefined;
		return {
			name,
			description: fmDescription ?? description,
			template,
			...(fmIcon ? { icon: fmIcon } : {}),
			...(fmCategory ? { category: fmCategory } : {}),
			...(fmAliases && fmAliases.length > 0 ? { aliases: fmAliases } : {}),
		};
	}

	return { name, description, template };
}

/**
 * Apply a command's template to user input. Supports three placeholder
 * styles, all backward-compatible:
 *
 *   - `{{input}}`  — the full input string verbatim. Original behaviour.
 *   - `{{argN}}`   — the Nth whitespace-separated token (0-indexed).
 *                    Replaced with an empty string when N is past the end.
 *                    Quoted strings count as one arg, so
 *                    `/cmd "hello world" foo` yields arg0='hello world',
 *                    arg1='foo'.
 *   - `{{args}}`   — every arg joined with single spaces (i.e. the
 *                    canonicalized form of `{{input}}`).
 *
 * Phase 4 (2026-05-23): added arg-substitution so commands can write
 * structured prompts like
 *   `Refactor function {{arg0}} to use the {{arg1}} pattern.`
 *
 * Authors who want a literal `{{argN}}` in their template can opt out
 * by writing `{{ argN }}` with surrounding spaces (we only match the
 * tight form). Unrecognised placeholders pass through untouched —
 * `{{ "{{model}}" }}` etc. are not replaced.
 */
export function applyCustomCommandTemplate(template: string, input: string): string {
	const args = parseSlashCommandArgs(input);
	// {{input}} keeps the user's text verbatim — quoting, whitespace,
	// everything. Replace this BEFORE the per-arg substitution so
	// {{input}} inside an arg context still gets the raw string.
	let out = template.split("{{input}}").join(input);
	out = out.split("{{args}}").join(args.join(" "));
	// Substitute {{argN}} for N up to the arg count. Any {{argN}} past
	// the end becomes empty so templates don't blurt placeholder text.
	out = out.replace(/\{\{arg(\d+)\}\}/g, (_match, idxStr: string) => {
		const idx = Number.parseInt(idxStr, 10);
		if (!Number.isFinite(idx) || idx < 0) return "";
		return args[idx] ?? "";
	});
	return out;
}

/**
 * Tokenize a user-supplied input string into arguments the same way a
 * shell would: whitespace-separated, with double quotes grouping a
 * span and a backslash escaping the next character. Exported so tests
 * (and any future RPC consumers) can verify the parse without going
 * through the template applier.
 */
export function parseSlashCommandArgs(input: string): string[] {
	const args: string[] = [];
	let buf = "";
	let inQuote = false;
	let i = 0;
	while (i < input.length) {
		const ch = input[i];
		if (ch === "\\" && i + 1 < input.length) {
			buf += input[i + 1];
			i += 2;
			continue;
		}
		if (ch === '"') {
			inQuote = !inQuote;
			i++;
			continue;
		}
		if (!inQuote && /\s/.test(ch)) {
			if (buf.length > 0) {
				args.push(buf);
				buf = "";
			}
			i++;
			continue;
		}
		buf += ch;
		i++;
	}
	if (buf.length > 0) args.push(buf);
	return args;
}
