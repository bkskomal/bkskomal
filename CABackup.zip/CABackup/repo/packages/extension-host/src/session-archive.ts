import { promises as fs } from "node:fs";
import * as path from "node:path";

/**
 * 2026-06-03: per-session archive for iOmCode. When the agent's
 * predictive auto-compact fires and drops the middle of history, the
 * dropped segment gets appended to a markdown file on disk under
 * `<workspace>/.iom/sessions/<sessionId>/archive.md`. The model can
 * read it back later via the `read_session_archive` tool when it
 * needs detail the in-memory summary doesn't carry.
 *
 * Format is intentionally a markdown append-log so a human can also
 * scroll through it after the fact ("what did the agent and I work
 * on in turn 8 of that long session?").
 *
 * Safety:
 *   - Path is anchored under the workspace root; sessionId is sanitized.
 *   - Append-only — never overwrites.
 *   - Best-effort — failures are swallowed by the host so the agent
 *     loop never breaks because the disk filled up or perms are wrong.
 *   - Per-file cap so a runaway compact-storm doesn't fill the disk.
 */

const ARCHIVE_DIR_RELATIVE = ".iom/sessions";
const MAX_ARCHIVE_BYTES = 5 * 1024 * 1024; // 5MB — generous for a single session

export async function appendToSessionArchive(
	workspaceRoot: string,
	sessionId: string,
	content: string,
): Promise<void> {
	const archivePath = resolveArchivePath(workspaceRoot, sessionId);
	if (!archivePath) return;
	// Ensure the per-session directory exists.
	await fs.mkdir(path.dirname(archivePath), { recursive: true });
	// Bound the file size — if we'd cross the cap, truncate the head
	// instead of appending forever. The tail is more relevant for
	// "what just happened" recall.
	try {
		const stat = await fs.stat(archivePath);
		if (stat.size + content.length > MAX_ARCHIVE_BYTES) {
			const existing = await fs.readFile(archivePath, "utf-8");
			const keepFromOffset = Math.max(0, existing.length - (MAX_ARCHIVE_BYTES - content.length - 200));
			const truncated = `[iOmCode session-archive: trimmed ${keepFromOffset.toLocaleString()} chars from the head to keep the archive under ${(MAX_ARCHIVE_BYTES / 1024 / 1024).toFixed(0)}MB. Tail follows.]\n\n${existing.slice(keepFromOffset)}`;
			await fs.writeFile(archivePath, truncated + content, "utf-8");
			return;
		}
	} catch {
		// File didn't exist yet — first write below.
	}
	await fs.appendFile(archivePath, content, "utf-8");
}

export async function readSessionArchive(
	workspaceRoot: string,
	sessionId: string,
): Promise<string | undefined> {
	const archivePath = resolveArchivePath(workspaceRoot, sessionId);
	if (!archivePath) return undefined;
	try {
		return await fs.readFile(archivePath, "utf-8");
	} catch {
		return undefined;
	}
}

/**
 * Resolve the absolute archive path, sanitizing sessionId to prevent
 * directory traversal. Returns undefined when inputs are invalid.
 * Exported pure for testability.
 */
export function resolveArchivePath(workspaceRoot: string, sessionId: string): string | undefined {
	if (!workspaceRoot || !sessionId) return undefined;
	// Sanitize sessionId — drop dots and slashes entirely, replace any
	// remaining non-safe chars with underscore. Reject the result if it
	// has no alphanumerics left (e.g. ".", "..", "/", "///" all
	// collapse to empty). Defensive layering on top of node's
	// path.join, which already neutralizes traversal — we want the
	// final segment to also be unambiguous in logs and audits.
	const safe = sessionId.replace(/[./\\]+/g, "").replace(/[^A-Za-z0-9_-]/g, "_");
	if (safe.length === 0) return undefined;
	if (!/[A-Za-z0-9]/.test(safe)) return undefined;
	return path.join(workspaceRoot, ARCHIVE_DIR_RELATIVE, safe, "archive.md");
}
