// R5-E: offline-mode badge helper.
//
// "Offline mode" is true when every configured provider is a *local* engine
// (currently only the `ollama` preset). The header badge in the webview uses
// this signal to reassure the user that no remote call will leave their box.
//
// Rules:
//   - Zero configured providers → NOT offline (you can't run anything yet).
//   - Mixed (any non-local provider present) → NOT offline.
//   - All providers carry a local preset → offline.
//
// The set of "local" provider presets is centralized here so future locals
// (e.g. a future `llama-cpp` or `lm-studio` preset) need only be added once.

import type { ProviderPresetId, RootConfig } from "@iom/shared";

/** Provider presets considered local (no network egress). */
export const LOCAL_PROVIDER_PRESETS: readonly ProviderPresetId[] = ["ollama"];

/**
 * Returns true when every provider in `config.providers` uses a local preset.
 * Returns false when the list is empty so the badge doesn't lie about an
 * unconfigured workspace.
 */
export function isOfflineMode(config: Pick<RootConfig, "providers">): boolean {
	const providers = config.providers ?? [];
	if (providers.length === 0) return false;
	const localSet = new Set<ProviderPresetId>(LOCAL_PROVIDER_PRESETS);
	for (const p of providers) {
		if (!localSet.has(p.preset)) return false;
	}
	return true;
}

/**
 * Returns the subset of providers that are local. Useful for the webview
 * badge tooltip ("Local providers: ollama").
 */
export function localProviderIds(config: Pick<RootConfig, "providers">): readonly string[] {
	const providers = config.providers ?? [];
	const localSet = new Set<ProviderPresetId>(LOCAL_PROVIDER_PRESETS);
	return providers.filter((p) => localSet.has(p.preset)).map((p) => p.id);
}
