// 2026-06-05: copy the built webview assets into the extension's own
// dist folder so they ship inside the VSIX. vsce only packages files
// from within the extension root; without this step the webview JS/CSS
// referenced by `../webview-ui/dist/...` is missing in the installed
// extension and the chat panel renders blank.
//
// Runs at the start of `npm run package`. Idempotent: clears the target
// first so a stale stylesheet from a previous build doesn't linger.

import { promises as fs } from "node:fs";
import * as path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EXTENSION_ROOT = path.resolve(__dirname, "..");
const SRC = path.resolve(EXTENSION_ROOT, "..", "webview-ui", "dist");
const DEST = path.join(EXTENSION_ROOT, "dist", "webview");

async function exists(p) {
	try {
		await fs.stat(p);
		return true;
	} catch {
		return false;
	}
}

async function main() {
	if (!(await exists(SRC))) {
		console.error(
			`[copy-webview-dist] source not found: ${SRC}\n  Did you run \`npm run build\` first? The package script does this automatically; this only fires when called directly.`,
		);
		process.exit(1);
	}
	if (await exists(DEST)) {
		await fs.rm(DEST, { recursive: true, force: true });
	}
	await fs.mkdir(DEST, { recursive: true });
	// Node 18+ supports cp with recursive — match Node 20 target.
	await fs.cp(SRC, DEST, { recursive: true });
	const files = await fs.readdir(DEST);
	let totalBytes = 0;
	for (const name of files) {
		const stat = await fs.stat(path.join(DEST, name));
		totalBytes += stat.size;
	}
	console.log(
		`[copy-webview-dist] copied ${files.length} files from webview-ui/dist → extension-host/dist/webview (${(
			totalBytes / 1024
		).toFixed(0)} KB)`,
	);
}

main().catch((err) => {
	console.error(`[copy-webview-dist] failed: ${err.message ?? err}`);
	process.exit(1);
});
