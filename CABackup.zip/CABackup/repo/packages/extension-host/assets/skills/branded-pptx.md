---
name: branded-pptx
description: Generate a polished, branded PowerPoint deck using the OATI brand template (navy header bar + brand sparkle + light cards + chip strips + comparison tables). Use when the user wants a "professional", "branded", "polished", or "custom-styled" deck rather than the plain default `python-pptx` output.
tools: [write_file, exec, read_file, list_dir, get_workspace_context]
triggers:
  - branded ppt
  - branded pptx
  - branded deck
  - branded presentation
  - polished ppt
  - polished pptx
  - polished deck
  - polished presentation
  - professional ppt
  - professional pptx
  - professional deck
  - professional presentation
  - custom template ppt
  - custom template pptx
  - custom template deck
  - oati template
  - oati deck
  - oati ppt
  - oati pptx
  - oati style ppt
  - oati style pptx
  - similar style ppt
  - similar pptx
  - same template ppt
  - same template pptx
  - styled ppt
  - styled pptx
  - styled deck
  - corporate ppt
  - corporate pptx
  - corporate deck
  - executive deck
  - investor deck
  - pitch deck
  - keynote deck
  # Template-driven phrasings
  - use template
  - using template
  - from template
  - based on template
  - this template
  - my template
  - our template
  - corporate template
  - company template
  - use this pptx
  - based on this pptx
  - extend this pptx
  - add slides to
  - append slides to
  - new slides from
  - generate slides from template
  # Specific file references — these are the phrasings users actually type
  - as the base
  - as base
  - as a base
  - using .pptx
  - using a .pptx
  - using the .pptx
  - based on .pptx
  - from .pptx
  - .pptx as base
  - .pptx as the base
  - .pptx as template
  - .pptx as the template
  - extend the deck
  - extend the presentation
  - add to the deck
  - update deck
  - update the deck
  - update presentation
  - update the presentation
---

# Skill: Branded PPTX (OATI custom template)

You produce a polished branded deck — navy header bar, brand sparkle,
light cards, chip strips, comparison tables, two-tone closing — by
copying the bundled `branded-pptx-template.py`, customizing its
slide-builder calls for the user's content, and running it through the
same `write_file → exec → verify` spine as every other code-driven
artifact.

This is NOT a separate tool. You ARE the engine. The template provides
the chrome + widgets; you fill in the content.

## ⚠️ Anti-patterns (read first)

1. **NEVER `read_file` on a binary template (`.pptx`, `.pdf`, `.docx`,
   `.png`, etc.).** `read_file` will refuse with an error pointing
   you at the right library. Reading a binary as text returns garbled
   bytes that poison the conversation history — Kimi (and other
   models) see thousands of replacement characters on every later
   turn and return empty. To INSPECT a `.pptx` template, use `exec`:
   ```bash
   python -c "from pptx import Presentation; p=Presentation('path/to/template.pptx'); print('slides=', len(p.slides)); print('layouts=', [(i, l.name) for i, l in enumerate(p.slide_layouts)])"
   ```
   That gives you the slide count + layout names without consuming
   any binary content in the context. To USE the template, your
   generator script opens it directly via `Presentation('path')`.
2. **Don't emit JSON specs.** No `ppt-creation { slides: [...] }`. The
   skill is a workflow with two real tools: `write_file` (for the
   script) and `exec` (to run it).
3. **Don't claim "✅ Done" before verifying.** After `exec`, confirm
   the `.pptx` exists with a non-trivial size AND the slide count
   matches what you wrote. A turn that ONLY ran `read_file` /
   `list_dir` / `get_workspace_context` has NOT produced an artifact —
   never end such a turn with "Done".
4. **Don't generate filler.** Pull content from the user's prompt,
   workspace files, git history, or whatever data source the user
   pointed at. If you genuinely lack the content, ask.
5. **Don't reinvent the chrome.** The bundled template solves the
   palette, header bar, footer band, sparkle mark, and widget set
   already. Copy it; edit only the slide builders + brand strings.

## When the user supplies their own template

If the user references a template file at a specific path (in the
prompt, attachment, or open editor), **use THEIR template, not the
bundled one**. Two distinct cases:

### Case A — user supplies a `.pptx` template

This is the most common corporate scenario: they have a branded deck
with their logo, fonts, color theme, slide masters. python-pptx
inherits all of that automatically when you open the file:

```python
from pptx import Presentation
from pptx.util import Inches, Pt

prs = Presentation("path/to/user-template.pptx")   # opens AS base; theme preserved

# Add a new slide using one of the template's layouts. Slide layout
# indices vary per template — use `prs.slide_layouts` to discover them
# before assuming index 6 is blank.
for i, layout in enumerate(prs.slide_layouts):
    print(i, layout.name)

# Then pick the right layout:
title_layout = prs.slide_layouts[0]   # usually "Title Slide"
blank_layout = prs.slide_layouts[6]   # usually "Blank" — but verify

slide = prs.slides.add_slide(blank_layout)
# ... add textboxes/shapes — but DO NOT override colors/fonts arbitrarily,
# let the master theme drive the look unless the user said otherwise ...

prs.save("path/to/output.pptx")
```

**Key rules for this case:**

- **Open with `Presentation(path)`, not `Presentation()`.** That's the
  whole trick — the template'\''s theme, slide masters, fonts, and
  branded colors come along automatically.
- **Discover layouts before picking.** `prs.slide_layouts[6]` is "Blank"
  in the default theme but corporate templates often reshuffle. Print
  them once, pick the right one, hard-code the index after that.
- **Use placeholders where the template defines them.** A slide layout
  with a "Title" placeholder is meant to be filled via
  `slide.placeholders[0].text = "..."` — that picks up the template'\''s
  title font/color/position. Adding your own textbox over the top
  defeats the template.
- **Don'\''t replace the chrome.** If the user'\''s template has a header
  bar in its master, don'\''t add another one. The master draws it on
  every slide automatically.
- **Save to a NEW file by default.** Never overwrite the template
  itself unless the user explicitly said "edit in place".

### Case B — user supplies a `.py` template

A Python script that builds decks (like the bundled
`branded-pptx-template.py`). Workflow:

1. `read_file` the user'\''s template to learn its:
   - Palette constants (colors at top)
   - Chrome helpers (`_header`, `_footer`, `_canvas`, brand mark)
   - Reusable widgets (chips, cards, bullet lists)
   - Slide builders (`build_title_slide`, etc.)
2. Write a NEW script (`out/generate_<slug>.py`) that imports from
   their template OR inlines the helpers you need, then adds new
   slide-builder calls for the user'\''s content.
3. Run it and verify.

Example — importing from the user'\''s template:

```python
# out/generate_q4_deck.py
import sys
sys.path.insert(0, ".iom/templates")  # or wherever theirs lives
from corporate_template import (
    BRAND_NAME, FOOTER_TEXT, CHIP_BLUE, CHIP_PURPLE,
    build_title_slide, build_grid_slide, build_table_slide,
)
from pptx import Presentation
from pptx.util import Inches

prs = Presentation()
prs.slide_width, prs.slide_height = Inches(10), Inches(5.625)

build_title_slide(prs, title="Q4 Roadmap", subtitle="What ships next",
                  chips=[("Search", CHIP_BLUE), ("Pricing", CHIP_PURPLE)],
                  at_a_glance=["12 features", "3 cohorts", "Jan launch"])
build_grid_slide(prs, title="Features", eyebrow="Six headline items",
                 cards=[...])

prs.save("out/q4.pptx")
```

**Key rules for this case:**

- **Read the whole template once, then reference it.** Don'\''t guess at
  function signatures — `read_file` to confirm the names + parameters.
- **Prefer import over copy.** If the user'\''s template is a clean
  module, import its helpers rather than duplicating code into your
  output script. The user can re-skin by editing the template and
  re-running.
- **Match their palette names.** If they call it `BRAND_RED` and
  `BRAND_INK`, use those — don'\''t introduce `ACCENT_RED` and `INK`
  alongside. The point of a template is one source of truth.

### Case C — no template supplied (the default)

Fall through to the bundled `branded-pptx-template.py` patterns
documented below in this skill.

## Workflow (three steps, no more)

### Step 1 — Copy the template into the workspace

The canonical template ships with iOmCode at:

```
<iom-extension>/assets/templates/branded-pptx-template.py
```

You usually don't need to read it byte-for-byte — the structure is
documented in this skill below. If the user wants a verbatim copy of
the bundled template to customize, suggest they ask you to write it
into `.iom/templates/branded-pptx.py` and you'll mirror the bundled
file from your context.

For most decks: write a new file (e.g. `out/generate_<slug>.py`) that
imports nothing from the template — just inline the helpers you need
straight from the patterns below. This keeps the script standalone and
shippable.

### Step 2 — Build the script

Structure every branded deck the same way:

```python
"""Generate <one-line deck description>."""
from pathlib import Path
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Emu, Inches, Pt

# --- PALETTE (edit to re-skin) ---
HEADER_NAVY = RGBColor(0x1A, 0x2B, 0x4A)
ACCENT_RED  = RGBColor(0xCC, 0x00, 0x00)
WHITE       = RGBColor(0xFF, 0xFF, 0xFF)
INK         = RGBColor(0x1F, 0x2A, 0x3D)
SUBTLE_INK  = RGBColor(0x4A, 0x5A, 0x70)
LIGHT_GRAY  = RGBColor(0xE7, 0xE6, 0xE6)
MUTED_DARK  = RGBColor(0x8C, 0x9B, 0xAB)
BG_LIGHT    = RGBColor(0xF8, 0xF9, 0xFA)
BG_MAIN_DARK= RGBColor(0x1A, 0x2B, 0x4A)
BG_PANEL_DARK=RGBColor(0x16, 0x20, 0x38)
SOFT_BORDER = RGBColor(0xE0, 0xE4, 0xEA)
CARD_BG     = RGBColor(0xFF, 0xFF, 0xFF)
CARD_BG_ALT = RGBColor(0xF1, 0xF3, 0xF6)
CHIP_BLUE   = RGBColor(0x25, 0x63, 0xEB)
CHIP_PURPLE = RGBColor(0x7C, 0x3A, 0xED)
CHIP_ORANGE = RGBColor(0xD9, 0x77, 0x06)
CHIP_TEAL   = RGBColor(0x0D, 0x94, 0x88)
CHIP_GREEN  = RGBColor(0x2E, 0xA0, 0x43)
CHIP_INDIGO = RGBColor(0x31, 0x2E, 0x81)
SOFT_BLUE   = RGBColor(0x5B, 0x9B, 0xD5)

# --- CANVAS (10 × 5.625 in, 16:9) ---
SLIDE_W, SLIDE_H = Inches(10), Inches(5.625)
HEADER_H = Inches(0.75)
FOOTER_H = Inches(0.21)
FOOTER_Y = SLIDE_H - FOOTER_H
BODY_TOP = HEADER_H + Inches(0.15)
BODY_LEFT = Inches(0.5)
BODY_W   = SLIDE_W - Inches(1.0)

# --- BRANDING (one place) ---
BRAND_NAME  = "Your Brand"          # edit
FOOTER_TEXT = "PROPRIETARY AND CONFIDENTIAL  |  Your Org  |  2026"

# [paste helpers here — see section "Helpers" below]

def main():
    prs = Presentation(); prs.slide_width, prs.slide_height = SLIDE_W, SLIDE_H
    build_title_slide(prs, ...)
    build_content_slide(prs, ...)
    # more slides
    out = Path(__file__).parent / "deck.pptx"
    prs.save(out)
    print(f"wrote {out} ({out.stat().st_size:,} bytes, {len(prs.slides)} slides)")

if __name__ == "__main__":
    main()
```

### Step 3 — Run and verify

```bash
python out/generate_<slug>.py
python -c "from pptx import Presentation; p=Presentation('out/deck.pptx'); print(len(p.slides), 'slides,', sum(len(s.shapes) for s in p.slides), 'shapes')"
```

The verifier should report the same slide count you generated AND a
shape count well above 20 (the chrome alone adds ~6 shapes per slide).
If shape count is unexpectedly low, a header/footer call was skipped —
investigate before claiming success.

## Helpers (paste these into the script — they're the chrome)

```python
def _kill_outline(s): s.line.fill.background()
def _solid(s, c): s.fill.solid(); s.fill.fore_color.rgb = c; _kill_outline(s)
def _outline(s, c, w=0.75): s.line.color.rgb = c; s.line.width = Pt(w)

def _rect(slide, x, y, w, h, color, *, outline=None):
    s = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, x, y, w, h)
    _solid(s, color)
    if outline is not None: _outline(s, outline)
    return s

def _text(slide, x, y, w, h, text, *, size=12, bold=False, italic=False,
          color=INK, font="Calibri Light", align=PP_ALIGN.LEFT,
          anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = anchor
    p = tf.paragraphs[0]; p.alignment = align
    r = p.add_run(); r.text = text
    r.font.name = font; r.font.size = Pt(size); r.font.bold = bold
    r.font.italic = italic; r.font.color.rgb = color
    return tb

def _sparkle(slide, x, y, size=Inches(0.34), color=WHITE):
    s = slide.shapes.add_shape(MSO_SHAPE.STAR_4_POINT, x, y, size, size)
    _solid(s, color); return s

def _header(slide, title, eyebrow=None):
    _rect(slide, Emu(0), Emu(0), SLIDE_W, HEADER_H, HEADER_NAVY)
    _sparkle(slide, Inches(0.30), Inches(0.21))
    _text(slide, Inches(0.72), Inches(0.20), Inches(1.6), Inches(0.36),
          BRAND_NAME, size=11, bold=True, color=LIGHT_GRAY,
          anchor=MSO_ANCHOR.MIDDLE)
    _text(slide, Inches(2.45), Inches(0.06), Inches(7.2), Inches(0.64),
          title, size=19, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    if eyebrow:
        _text(slide, Inches(2.45), Inches(0.45), Inches(7.2), Inches(0.25),
              eyebrow, size=9.5, italic=True, color=MUTED_DARK)

def _footer(slide):
    _rect(slide, Emu(0), FOOTER_Y, SLIDE_W, FOOTER_H, HEADER_NAVY)
    _text(slide, Inches(0.2), FOOTER_Y, Inches(9.6), FOOTER_H,
          FOOTER_TEXT, size=7, color=LIGHT_GRAY, font="Calibri",
          anchor=MSO_ANCHOR.MIDDLE)

def _canvas_light(slide):
    _rect(slide, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_LIGHT)

def _chip(slide, x, y, w, h, label, color, size=9):
    _rect(slide, x, y, w, h, color)
    tb = slide.shapes.add_textbox(x, y, w, h)
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(0)
    tf.margin_top = tf.margin_bottom = Emu(0)
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
    r = p.add_run(); r.text = label
    r.font.name = "Calibri Light"; r.font.size = Pt(size)
    r.font.bold = True; r.font.color.rgb = WHITE

def _light_card(slide, x, y, w, h, accent):
    _rect(slide, x, y, w, Inches(0.10), accent)
    _rect(slide, x, y + Inches(0.10), w, h - Inches(0.10),
          CARD_BG, outline=SOFT_BORDER)
```

## Slide patterns (pick what fits the content)

### Title slide (dark canvas + right panel + chips + at-a-glance)

```python
def build_title_slide(prs, title, subtitle, chips, glance):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _rect(s, Emu(0), Emu(0), SLIDE_W, SLIDE_H, BG_MAIN_DARK)
    _rect(s, Inches(6.9), Emu(0), SLIDE_W - Inches(6.9), SLIDE_H, BG_PANEL_DARK)
    _rect(s, Inches(6.9), Emu(0), Emu(54864), SLIDE_H, ACCENT_RED)  # red stripe
    _sparkle(s, Inches(0.45), Inches(0.32))
    _text(s, Inches(0.85), Inches(0.30), Inches(3.0), Inches(0.4),
          BRAND_NAME, size=15, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    _text(s, Inches(0.5), Inches(1.75), Inches(6.2), Inches(0.7),
          title, size=40, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
    _text(s, Inches(0.5), Inches(2.45), Inches(6.2), Inches(0.55),
          subtitle, size=22, color=SOFT_BLUE, anchor=MSO_ANCHOR.MIDDLE)
    # chips
    cy = Inches(3.7); cw = Inches(1.45); ch = Inches(0.36); gap = Inches(0.16)
    x = Inches(0.5)
    for label, color in chips:
        _chip(s, x, cy, cw, ch, label, color); x += cw + gap
    # at-a-glance bullets on right panel
    _text(s, Inches(7.1), Inches(0.55), Inches(2.7), Inches(0.36),
          "At a glance", size=13, bold=True, color=LIGHT_GRAY)
    for i, line in enumerate(glance):
        y = Inches(1.05) + Inches(0.52) * i
        _rect(s, Inches(7.1), y, Emu(36576), Inches(0.32), ACCENT_RED)
        _text(s, Inches(7.2), y, Inches(2.55), Inches(0.32),
              line, size=10.5, color=LIGHT_GRAY, anchor=MSO_ANCHOR.MIDDLE)
```

### Bullets + proof-card (two-column light slide)

```python
def build_bullets(prs, title, eyebrow, bullets, proof_title, proof_lines):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, title, eyebrow)
    # bullets on left (red-square markers, optional bold head)
    row_h = Inches(0.42); x = BODY_LEFT
    for i, item in enumerate(bullets):
        y = BODY_TOP + Inches(0.20) + row_h * i
        _rect(s, x, y + Inches(0.10), Inches(0.10), Inches(0.10), ACCENT_RED)
        tb = s.shapes.add_textbox(x + Inches(0.22), y, Inches(5.30), row_h)
        p = tb.text_frame.paragraphs[0]
        if isinstance(item, tuple):
            head, tail = item
            r1 = p.add_run(); r1.text = head + " "
            r1.font.name = "Calibri Light"; r1.font.size = Pt(11)
            r1.font.bold = True; r1.font.color.rgb = INK
            r2 = p.add_run(); r2.text = tail
            r2.font.name = "Calibri Light"; r2.font.size = Pt(11)
            r2.font.color.rgb = INK
        else:
            r = p.add_run(); r.text = item
            r.font.name = "Calibri Light"; r.font.size = Pt(11)
            r.font.color.rgb = INK
    # proof card on right
    rx = BODY_LEFT + Inches(5.85); rw = Inches(3.65)
    _rect(s, rx, BODY_TOP + Inches(0.20), rw, Inches(0.10), CHIP_BLUE)
    _rect(s, rx, BODY_TOP + Inches(0.30), rw, Inches(2.85),
          CARD_BG, outline=SOFT_BORDER)
    _text(s, rx + Inches(0.15), BODY_TOP + Inches(0.38), rw - Inches(0.25),
          Inches(0.32), proof_title, size=12, bold=True, color=INK)
    for i, line in enumerate(proof_lines):
        y = BODY_TOP + Inches(0.78) + Inches(0.36) * i
        _rect(s, rx + Inches(0.18), y + Inches(0.10),
              Inches(0.10), Inches(0.10), ACCENT_RED)
        _text(s, rx + Inches(0.35), y, rw - Inches(0.45), Inches(0.32),
              line, size=10.5, color=INK)
    _footer(s)
```

### Card grid (3-column feature showcase)

```python
def build_grid(prs, title, eyebrow, cards, cols=3):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, title, eyebrow)
    col_w = (BODY_W - Inches(0.10) * (cols - 1)) / cols
    row_h = Inches(1.05); cg = Inches(0.10); rg = Inches(0.12)
    gy = BODY_TOP + Inches(0.15)
    for i, (head, sub, color) in enumerate(cards):
        col = i % cols; row = i // cols
        x = BODY_LEFT + (col_w + cg) * col
        y = gy + (row_h + rg) * row
        _light_card(s, x, y, col_w, row_h, color)
        _text(s, x + Inches(0.15), y + Inches(0.20), col_w - Inches(0.25),
              Inches(0.32), head, size=13, bold=True, color=INK)
        _text(s, x + Inches(0.15), y + Inches(0.55), col_w - Inches(0.25),
              Inches(0.45), sub, size=10, color=SUBTLE_INK)
    _footer(s)
```

### Comparison table (alternating rows + navy header)

```python
def build_table(prs, title, eyebrow, columns, rows, highlight_col=1):
    s = prs.slides.add_slide(prs.slide_layouts[6])
    _canvas_light(s); _header(s, title, eyebrow)
    n = len(columns); col_w = BODY_W / n
    tx = BODY_LEFT; ty = BODY_TOP + Inches(0.10)
    hh = Inches(0.36); rh = Inches(0.30); total_w = col_w * n
    _rect(s, tx, ty, total_w, hh, HEADER_NAVY)
    cx = tx
    for label in columns:
        _text(s, cx + Inches(0.06), ty, col_w - Inches(0.10), hh,
              label, size=10, bold=True, color=WHITE, anchor=MSO_ANCHOR.MIDDLE)
        cx += col_w
    ry = ty + hh
    for i, row in enumerate(rows):
        bg = CARD_BG_ALT if i % 2 == 0 else CARD_BG
        _rect(s, tx, ry, total_w, rh, bg)
        cx = tx
        for j, cell in enumerate(row):
            color = CHIP_BLUE if j == highlight_col else (INK if j == 0 else SUBTLE_INK)
            bold = (j == highlight_col)
            _text(s, cx + Inches(0.06), ry, col_w - Inches(0.10), rh,
                  str(cell), size=9, bold=bold, color=color, anchor=MSO_ANCHOR.MIDDLE)
            cx += col_w
        ry += rh
    _footer(s)
```

## Geometry conventions (memorize these)

| Constant | Value | Use |
|---|---|---|
| `SLIDE_W`, `SLIDE_H` | 10 × 5.625 in (16:9) | Canvas |
| `HEADER_H` | 0.75 in | Top navy band |
| `FOOTER_H` | 0.21 in | Bottom navy band |
| `BODY_TOP` | 0.90 in | First-content-row Y |
| `BODY_LEFT` | 0.50 in | First-content-col X |
| `BODY_W` | 9.00 in | Usable width |

A content slide's body is roughly **4.5 in tall × 9 in wide**. Plan
card heights so 3 rows × 1.05 in (≈ 3.15 in) plus 2 gaps still fits.

## Verify checklist (don't claim Done until ALL pass)

- `python -c "from pptx import Presentation; p=Presentation('out/deck.pptx'); print(len(p.slides))"` returns the expected slide count.
- File size > 30 KB (a deck with chrome can't be smaller; a 5 KB file
  means most slides are blank or chrome failed to render).
- Shape count > 6 × slide count (each slide has ≥ 6 chrome shapes).
- Open in PowerPoint or LibreOffice to visually confirm chrome is
  rendering. If you're remote / headless, ask the user to open it
  and confirm.

## Required dependency

`python-pptx` (already installed in most workspaces). If missing, ask
the user before running `pip install python-pptx` — never auto-install.

## Don't

- Don't reach for `python-pptx`'s native chart API beyond simple bars.
  For real charts, pre-render with matplotlib to PNG and embed via
  `slide.shapes.add_picture(...)`.
- Don't put more than ~6 light cards on one content slide. If you need
  more, add another slide.
- Don't change `Calibri Light` casually — the deck is designed around
  its metrics. If swapping fonts, re-check that text fits its boxes.
- Don't claim "Done" without the verify step.
