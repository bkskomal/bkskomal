---
name: powershell-commands
description: Run PowerShell (pwsh / Windows PowerShell) commands from iOmCode with the right cmdlets, quoting, and pipeline shape
tools: [exec, read_file, write_file, get_workspace_context]
triggers:
  - powershell
  - pwsh
  - "Get-"
  - "Set-"
  - "Invoke-"
  - "$env:"
  - "Select-Object"
  - "Where-Object"
  - "windows command"
  - registry
  - msi
---

# Skill: PowerShell commands

Use this playbook when the user asks for a PowerShell command, when the
task involves Windows-specific affordances (registry, MSI, Get-Process,
Win32 APIs, Scheduled Tasks), or when pipeline-object semantics matter.

## 1. Always invoke through the `exec` tool with `shell: "pwsh"`

```json
{
  "command": "Get-ChildItem -Recurse -Filter *.ts | Measure-Object | Select-Object -ExpandProperty Count",
  "shell": "pwsh"
}
```

- `pwsh` resolves to PowerShell 7+ (`pwsh.exe`) when available, falling
  back to Windows PowerShell 5.1 (`powershell.exe`).
- Force PowerShell 5.1 explicitly with `shell: "powershell"` if a script
  depends on Desktop-only modules (e.g. some `ActiveDirectory` cmdlets).
- The host launches PowerShell with `-NoProfile -NonInteractive -Command`.
  We do NOT pass `-ExecutionPolicy Bypass` — the user's machine policy
  is in charge. If a script is blocked, ask the user to adjust their
  policy rather than overriding it.

## 2. Pick PowerShell when…

- Using cmdlets: `Get-ChildItem`, `Select-Object`, `Where-Object`,
  `Measure-Object`, `Invoke-WebRequest`, `ConvertFrom-Json`.
- Working with environment variables Windows-style: `$env:PATH`,
  `$env:USERPROFILE`.
- Touching the registry (`HKLM:\…`, `HKCU:\…` — these are PowerShell
  drives, not raw paths).
- Managing services, scheduled tasks, MSIs, Windows event logs.
- Anywhere pipeline-object semantics help: `… | Where-Object { $_.Length -gt 1MB }`.

## 3. Common patterns

| Goal                                    | PowerShell                                                       |
| --------------------------------------- | ---------------------------------------------------------------- |
| Find files by pattern                   | `Get-ChildItem -Recurse -Filter *.ts`                            |
| Count lines per file                    | `Get-Content file.ts \| Measure-Object -Line`                    |
| Search content                          | `Select-String -Pattern "TODO" -Path src\**\*.ts`                |
| Read env var                            | `$env:PATH`                                                      |
| Set env var (current process only)      | `$env:NODE_ENV = "production"`                                   |
| Read JSON                               | `Get-Content pkg.json \| ConvertFrom-Json`                       |
| Make a directory (with -p semantics)    | `New-Item -ItemType Directory -Force -Path out\reports`          |
| Remove with confirmation suppressed     | `Remove-Item -Recurse -Force build\`                             |
| Conditional                             | `if (Test-Path package.json) { "ok" }`                           |
| Find an executable                      | `(Get-Command node).Source`                                      |
| Pipeline filter                         | `Get-Process \| Where-Object { $_.WorkingSet -gt 200MB }`        |
| Download a file                         | `Invoke-WebRequest -OutFile out.zip -Uri https://example/a.zip`  |

## 4. Pipeline chain operators

- PowerShell 7 supports `&&` and `||` just like bash — prefer them
  over `;` when the second command depends on the first succeeding.
- Older Windows PowerShell 5.1 does NOT support `&&` / `||`.
  Use `if ($LASTEXITCODE -eq 0) { … }` when you know you might be
  targeting Windows PowerShell 5.1.

## 5. Quoting rules

- Single quotes are literal — no `$var` expansion, no backticks.
- Double quotes expand `$var` and let you embed sub-expressions via
  `$(…)`: `"User: $env:USERNAME at $(Get-Date)"`.
- The escape character is backtick `` ` ``, not backslash.
- To pass a string containing newlines to a native command (e.g.
  `git commit -m`), use a single-quoted here-string. The closing
  `'@` MUST start at column 0:

```powershell
git commit -m @'
First line
Second line
'@
```

## 6. Unix → PowerShell migration cheats

| Unix              | PowerShell                                                       |
| ----------------- | ---------------------------------------------------------------- |
| `head -n 5 f`     | `Get-Content f -TotalCount 5`                                    |
| `tail -n 5 f`     | `Get-Content f -Tail 5`                                          |
| `which node`      | `(Get-Command node).Source`                                      |
| `wc -l f`         | `(Get-Content f \| Measure-Object -Line).Lines`                  |
| `mkdir -p path`   | `New-Item -ItemType Directory -Force -Path path`                 |
| `rm -rf dir`      | `Remove-Item -Recurse -Force dir`                                |
| `ln -s src dst`   | `New-Item -ItemType SymbolicLink -Path dst -Target src`          |
| `cmd1 2>/dev/null`| `cmd1 2>$null` (or wrap in `try { … -ErrorAction Stop } catch {}`) |
| `VAR=x cmd`       | `$env:VAR = 'x'; cmd`                                            |

## 7. Hidden pitfalls

- **Interactive prompts hang.** PowerShell is launched non-interactive.
  Never call `Read-Host`, `Get-Credential`, `Out-GridView`, or `pause` —
  they block forever.
- **Destructive cmdlets prompt by default.** Add `-Confirm:$false` and
  `-Force` when you mean to proceed unattended. Be deliberate about
  this — only use it when the action is genuinely intended.
- **`-ErrorAction SilentlyContinue` swallows output, not exit codes.**
  To make a cmdlet failure truly non-fatal, promote it to terminating
  and swallow it: `try { Cmdlet … -ErrorAction Stop } catch {}`.
- **Argument parsing surprises.** When passing args that start with `-`
  or contain `@` to a native exe, use the stop-parsing token:
  `git log --% --format=%H`.
- **`New-Item -Force` on an existing file truncates it.** Use
  `if (-not (Test-Path x)) { New-Item -ItemType File x }` for a
  `touch`-equivalent.

## 8. Working directory

- The `cwd` argument on `exec` is the right way to set the working
  directory — don't `cd path; …` because each `exec` is its own
  PowerShell process with no shared state.

## 9. When NOT to use PowerShell

- The command is a POSIX one-liner that's clearer in bash → use
  `shell: "bash"` (see the `bash-commands` skill).
- You only need a single CMD builtin (`dir`, `where`, `type`,
  `tasklist`) → `shell: "cmd"` is fine.

## 10. Recovery

- Exit code `127` with "Shell 'pwsh' not found" means PowerShell 7
  isn't installed. Re-run with `shell: "powershell"` to use the
  built-in Windows PowerShell 5.1.
- A non-zero exit is data — read stderr (the PowerShell error stream
  is merged in), diagnose, and adjust quoting / cmdlet choice.
- If a script is "not digitally signed" or "running scripts is
  disabled on this system," explain that the user's execution policy
  is blocking it and link to `about_Execution_Policies`.
