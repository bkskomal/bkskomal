---
name: code-driven-artifacts
description: Generate any artifact (PDF, PPTX, SVG, PNG, charts, diagrams, CSV, JSON, scraped data, ML outputs, …) by writing Python that produces it, running the script via exec, and verifying the file on disk. ONE general capability — not a separate tool per artifact type.
tools: [write_file, exec, read_file, list_dir, get_workspace_context]
triggers:
  # Documents
  - pdf
  - create pdf
  - generate pdf
  - export pdf
  - pdf report
  - markdown to pdf
  - html to pdf
  - convert to pdf
  # Decks
  - ppt
  - pptx
  - powerpoint
  - power point
  - presentation
  - slides
  - slide deck
  - create deck
  - deck for
  # Images
  - svg
  - png
  - image
  - create image
  - generate image
  - logo
  - icon
  - thumbnail
  - banner
  # Charts and diagrams
  - chart
  - plot
  - graph
  - bar chart
  - line chart
  - pie chart
  - histogram
  - scatter
  - heatmap
  - diagram
  - flowchart
  - sequence diagram
  - architecture diagram
  - mermaid
  - plantuml
  - graphviz
  # Data
  - csv
  - excel
  - xlsx
  - generate data
  - scrape
  # Generic creation verbs likely to surface this
  - generate artifact
  - render
  - write python that
---

# Skill: Code-driven artifact generation

You write Python. The runtime runs it. The artifact lands on disk. That's
the whole skill. It works for decks, PDFs, charts, images, diagrams,
scraped data, ML outputs — anything Python can produce.

## ⚠️ The honesty rules

1. **There is NO single-step "make me a PDF/deck/image" tool.** Do NOT
   emit a JSON spec (`pdf-creation-v2 { sections: [...] }`,
   `ppt-creation { slides: [...] }`, `image-gen { ... }`) and declare
   success — no file gets created. The skill is the WORKFLOW, executed
   with two real tools: `write_file` (for the script) and `exec` (to
   run it).

2. **Never claim "✅ Done — created X" unless you've verified.** Use
   `exec` (`ls`, `Get-ChildItem`, `python -c "from pathlib import Path; print(Path('X').stat().st_size)"`)
   or `read_file` to confirm the artifact actually exists at the path
   you claimed. The iOmCode agent runs a structural false-Done check at
   end-of-turn — claims about non-existent files will be flagged.

3. **If a step failed (script errored, library missing, path wrong),
   tell the user what happened and stop.** Do not fabricate success
   over a real failure.

## Workflow (the spine)

Every artifact follows the same three steps:

1. **`write_file` → `out/generate_<slug>.py`** — the Python script that
   produces the artifact. Readable, complete, runnable end-to-end.
2. **`exec` → `python out/generate_<slug>.py`** — capture stdout +
   stderr. Non-zero exit is a hard failure to investigate, not a silent
   retry.
3. **Verify** — confirm the file exists, has plausible size, and
   parses/loads. THEN report path + size + summary to the user.

You are the engine. Translate the plan directly into Python that uses
the right library; don't emit a spec for some imagined downstream tool
to consume.

## Library cheat sheet (one line each — pick what fits)

| Artifact          | Library / Tool                 | When                                              |
| ----------------- | ------------------------------ | ------------------------------------------------- |
| PPTX              | `python-pptx`                  | decks; full custom layouts                        |
| PDF (HTML→PDF)    | `weasyprint` + `jinja2`        | content-driven; modern CSS3 (`@page`, counters)   |
| PDF (programmatic)| `reportlab` Platypus           | invoices, statements, precise layout              |
| PDF (web app)     | `playwright` (Chromium)        | render a live React/Vue app to PDF                |
| PDF (Markdown)    | `pandoc` + xelatex             | source already Markdown; styling forgiving        |
| PDF post-process  | `pymupdf` (fitz)               | watermarks, page numbers, merging, redaction      |
| PDF/A archival    | Ghostscript `pdfwrite -dPDFA=2`| long-term archival                                |
| Chart             | `matplotlib`                   | publication-quality, `fig.savefig(...)`           |
| Chart             | `plotly` + `kaleido`           | interactive design → PNG/SVG export               |
| PNG (procedural)  | `pillow` (PIL)                 | draw shapes, text, composites, resize             |
| SVG               | `svgwrite`, or raw XML strings | scalable diagrams, icons, simple graphics         |
| SVG → PNG         | `cairosvg`                     | rasterize an SVG                                  |
| Diagram (flowchart, sequence) | mermaid CLI (`npx @mermaid-js/mermaid-cli`) | `.mmd` → PNG/SVG  |
| Diagram (UML, ER) | PlantUML (`java -jar plantuml.jar`) | `.puml` → PNG/SVG                             |
| Diagram (graph)   | `graphviz` (`dot` CLI or `pygraphviz`) | network / dependency graphs               |
| Tables / CSV / Excel | `pandas`, `openpyxl`        | data wrangling, multi-sheet workbooks             |
| Web scrape        | `requests` + `beautifulsoup4`  | static HTML                                       |
| Web scrape        | `playwright`                   | JS-rendered pages                                 |
| Image batch       | `pillow` + `glob`              | resize, watermark, convert formats                |
| Vector → raster   | `cairosvg`, ImageMagick (`convert`) | SVG/PDF → PNG/JPG                            |
| Static HTML site  | `jinja2` templates + `pathlib` | per-page render                                   |

The model picks the library that fits the task. The cheat sheet is
HINTS, not prescriptions — if you know a better library for the job,
use it.

## Recipe (the pattern, not a template)

```python
"""Generate <one-line description of the artifact>."""
from pathlib import Path
# import only what this script needs

def main() -> None:
    out_dir = Path(__file__).parent
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / "artifact.ext"

    # Build the artifact with the right library.
    # Real content, not lorem ipsum — fill from the user's prompt /
    # workspace files / git history / data source.

    # Save to disk.
    # ...

    size = out.stat().st_size
    print(f"wrote {out} ({size:,} bytes)")

if __name__ == "__main__":
    main()
```

Pattern, not a template. Different artifacts need different shapes —
PPTX scripts build slides; SVG scripts emit XML; chart scripts call
matplotlib; pandas scripts read + transform + write CSV.

## Verify per artifact (post-`exec`)

Run a SMALL second Python (or shell) command via `exec` to confirm the
artifact is real and plausible. One-liners:

| Artifact | One-liner verifier                                                                   |
| -------- | ------------------------------------------------------------------------------------ |
| PPTX     | `python -c "from pptx import Presentation; p=Presentation('out/X.pptx'); print(len(p.slides))"` |
| PDF      | `python -c "import pymupdf; d=pymupdf.open('out/X.pdf'); print(len(d))"`            |
| PNG/JPG  | `python -c "from PIL import Image; print(Image.open('out/X.png').size)"`            |
| SVG      | `python -c "import re,sys; t=open('out/X.svg').read(); print('ok' if re.search(r'<svg', t) and t.rstrip().endswith('</svg>') else 'BAD')"` |
| CSV      | `python -c "import csv; r=list(csv.reader(open('out/X.csv'))); print(len(r),'rows')"` |
| Excel    | `python -c "import openpyxl; wb=openpyxl.load_workbook('out/X.xlsx'); print(wb.sheetnames)"` |

Then report: path, size, summary (slide count / page count / image
dimensions / row count) to the user. If the verifier fails, the
artifact is bad — investigate `exec` stdout/stderr before re-claiming.

## Common patterns (kept brief — model fills in details)

**Render a chart to PNG:**
```python
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(8, 4), dpi=200)
ax.plot([1,2,3,4], [10,20,15,30], marker="o", lw=2)
ax.spines[["top","right"]].set_visible(False)
fig.tight_layout()
fig.savefig("out/chart.png", dpi=200, bbox_inches="tight")
```

**Procedural PNG (Pillow):**
```python
from PIL import Image, ImageDraw, ImageFont
img = Image.new("RGB", (800, 400), "#0F172A")
d = ImageDraw.Draw(img)
d.rectangle([40, 40, 760, 360], outline="#2563EB", width=4)
d.text((400, 200), "Hello", fill="white", anchor="mm")
img.save("out/banner.png", optimize=True)
```

**SVG (raw XML, no dependency):**
```python
from pathlib import Path
svg = """<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <circle cx="100" cy="100" r="80" fill="#2563EB"/>
  <text x="100" y="110" text-anchor="middle" fill="white"
        font-family="Inter" font-size="20">OATI</text>
</svg>"""
Path("out/logo.svg").write_text(svg, encoding="utf-8")
```

**Mermaid → PNG via npx:**
```bash
echo 'graph LR; A-->B; B-->C' > out/flow.mmd
npx --yes @mermaid-js/mermaid-cli -i out/flow.mmd -o out/flow.png -w 1600
```

**Deck (python-pptx skeleton):**
```python
from pptx import Presentation
from pptx.util import Inches, Pt
prs = Presentation()
prs.slide_width, prs.slide_height = Inches(10), Inches(5.625)
s = prs.slides.add_slide(prs.slide_layouts[6])  # blank
tb = s.shapes.add_textbox(Inches(0.5), Inches(2), Inches(9), Inches(1))
r = tb.text_frame.paragraphs[0].add_run()
r.text = "Deck title"
r.font.size = Pt(36)
r.font.bold = True
prs.save("out/deck.pptx")
```

**Content-driven PDF (Jinja2 + WeasyPrint):**
```python
from jinja2 import Template
from weasyprint import HTML
html = Template("<h1>{{ title }}</h1><p>{{ body }}</p>").render(
    title="Q4 Report", body="…")
HTML(string=html).write_pdf("out/report.pdf")
```

## Auto-install

If a required library is missing, ASK the user before running
`pip install`. Don't auto-install Python packages. Suggested phrasing:
"`python-pptx` isn't installed. OK to run `pip install python-pptx`?"

## Don't

- Emit JSON specs / fake tool names. You ARE the engine.
- Claim "Done" without verifying the file exists.
- Generate placeholder lorem ipsum. Fill from real workspace content.
- Hardcode palettes / themes across multiple files — put constants
  once at the top of the generator so a re-skin is one edit.
- Use python-pptx's native chart API beyond the simplest bar chart —
  pre-render with matplotlib instead.
- Auto-install Python packages without explicit user permission.
- Mix engines for the same artifact. Pick one and commit.
