"""Generates assets/icon.png (128×128) and a matching icon.svg for iOmCode.

Design intent — kept deliberately simple:
- Rounded-square background, smooth indigo → teal diagonal gradient.
- Bold "OC" wordmark centered, off-white.
- Nothing else. No orbital dots, no satellites, no inner shapes.

Simplicity wins at 16×16 (Activity Bar). Single dominant element + clean
gradient reads as a logo at any size and stays calm at any background.

Usage:
    python generate-icon.py
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

HERE = Path(__file__).parent
PNG_PATH = HERE / "icon.png"
SVG_PATH = HERE / "icon.svg"

SIZE = 128
RADIUS = 28  # corner radius for the rounded-square bg


def lerp(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))  # type: ignore[return-value]


def make_gradient(size: int) -> Image.Image:
    """Diagonal indigo → teal gradient on an RGB image (no alpha yet)."""
    img = Image.new("RGB", (size, size), (0, 0, 0))
    px = img.load()
    indigo = (49, 46, 129)   # #312E81 — deep, calm
    blue = (37, 99, 235)     # #2563EB
    teal = (13, 148, 136)    # #0D9488 — anchors warmer than cyan
    for y in range(size):
        for x in range(size):
            t = ((x + y) / (2 * (size - 1)))
            if t < 0.55:
                c = lerp(indigo, blue, t / 0.55)
            else:
                c = lerp(blue, teal, (t - 0.55) / 0.45)
            px[x, y] = c
    return img


def rounded_mask(size: int, radius: int) -> Image.Image:
    """L-mode mask matching the rounded square."""
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        (0, 0, size - 1, size - 1), radius=radius, fill=255
    )
    return mask


def soft_highlight(size: int) -> Image.Image:
    """A subtle top-left highlight, blurred, for depth — keeps the flat
    gradient from looking like a printed sticker."""
    layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    cx, cy, r = int(size * 0.30), int(size * 0.22), int(size * 0.5)
    draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(255, 255, 255, 55))
    return layer.filter(ImageFilter.GaussianBlur(radius=20))


def find_font(target_size: int) -> ImageFont.ImageFont:
    """Try a few bold system fonts; fall back to PIL's default."""
    candidates = [
        "C:/Windows/Fonts/SegoeUIB.ttf",   # Segoe UI Bold (Windows)
        "C:/Windows/Fonts/segoeuib.ttf",
        "C:/Windows/Fonts/arialbd.ttf",     # Arial Bold (Windows)
        "/System/Library/Fonts/SFNS.ttf",   # macOS system
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",  # Linux
    ]
    for path in candidates:
        if Path(path).exists():
            try:
                return ImageFont.truetype(path, target_size)
            except OSError:
                continue
    return ImageFont.load_default()


def draw_wordmark(canvas: Image.Image, text: str = "OC") -> None:
    """Bold OC wordmark, white with a faint drop shadow for depth."""
    draw = ImageDraw.Draw(canvas)
    font = find_font(target_size=72)
    bbox = draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    x = (SIZE - text_w) / 2 - bbox[0]
    y = (SIZE - text_h) / 2 - bbox[1] - 2
    # Faint drop shadow so the mark feels lifted off the gradient
    draw.text((x + 1, y + 2), text, font=font, fill=(0, 0, 0, 70))
    draw.text((x, y), text, font=font, fill=(255, 255, 255, 248))


def build_icon() -> Image.Image:
    bg = make_gradient(SIZE).convert("RGBA")
    bg.putalpha(rounded_mask(SIZE, RADIUS))

    hi = soft_highlight(SIZE)
    composed = Image.alpha_composite(bg, hi)
    composed.putalpha(rounded_mask(SIZE, RADIUS))

    draw_wordmark(composed, "OC")
    return composed


def write_svg() -> None:
    """Vector counterpart — used for marketplace screenshots / hi-DPI displays."""
    svg = f"""<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128">
  <defs>
    <linearGradient id="oc-bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#312e81" />
      <stop offset="55%" stop-color="#2563eb" />
      <stop offset="100%" stop-color="#0d9488" />
    </linearGradient>
    <radialGradient id="oc-glow" cx="30%" cy="22%">
      <stop offset="0%" stop-color="#ffffff" stop-opacity="0.32" />
      <stop offset="100%" stop-color="#ffffff" stop-opacity="0" />
    </radialGradient>
  </defs>
  <rect x="0" y="0" width="128" height="128" rx="{RADIUS}" fill="url(#oc-bg)" />
  <rect x="0" y="0" width="128" height="128" rx="{RADIUS}" fill="url(#oc-glow)" />
  <text x="64" y="84" text-anchor="middle"
        font-family="Segoe UI, Helvetica, Arial, sans-serif"
        font-weight="700" font-size="64" fill="#ffffff"
        letter-spacing="-2">OC</text>
</svg>
"""
    SVG_PATH.write_text(svg, encoding="utf-8")


def main() -> None:
    icon = build_icon()
    icon.save(PNG_PATH, format="PNG")
    write_svg()
    print(f"[generate-icon] wrote {PNG_PATH} ({PNG_PATH.stat().st_size:,} bytes)")
    print(f"[generate-icon] wrote {SVG_PATH}")


if __name__ == "__main__":
    main()
