// R7-B: VS Code E2E test runner.
//
// Launches a real VS Code instance with the extension loaded and runs the
// Mocha suite at `./suite-out/index.js`. The suite folder is TypeScript
// (`./suite/**/*.ts`); we compile it to `./suite-out/` via the local tsc
// before launching so VS Code's Electron Node can load plain `.js` modules.
//
// Use: `node packages/extension-host/test-electron/runner.mjs`
// Or via the workspace script:
//   `npm run test:electron --workspace=oati-code`
//
// CI gating:
//   - The unit suite (`npm test`) is the default CI gate; it stays fast.
//   - These E2E tests are OPT-IN via `CI_E2E=1` because they download a real
//     VS Code build (~150 MB) and take ~30s to spin up. CI workflows that
//     want this coverage should set `CI_E2E=1` explicitly.

import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { runTests } from "@vscode/test-electron";

const here = path.dirname(fileURLToPath(import.meta.url));
const extensionDevelopmentPath = path.resolve(here, "..");
const suiteSrc = path.resolve(here, "suite");
const suiteOut = path.resolve(here, "suite-out");
const extensionTestsPath = path.resolve(suiteOut, "index.js");

// CI gate: only run when the env says so. Local runs can skip the gate by
// invoking this script directly.
if (process.env.CI && !process.env.CI_E2E) {
	console.log(
		"[iom-e2e] CI detected and CI_E2E not set — skipping E2E suite (unit tests still run).",
	);
	process.exit(0);
}

// Skip cleanly if the suite folder is empty (sibling worktrees may not have
// it populated yet).
if (!fs.existsSync(suiteSrc)) {
	console.log("[iom-e2e] no suite/ folder found — nothing to run.");
	process.exit(0);
}

// Compile the suite from TS to JS. We invoke the local tsc via npm exec so we
// don't have to assume a global install. The tsc config lives in
// `./tsconfig.json` next to this runner.
const tscArgs = ["--project", path.resolve(here, "tsconfig.json")];
console.log("[iom-e2e] compiling suite:", tscArgs.join(" "));
const tsc = spawnSync(
	process.platform === "win32" ? "npx.cmd" : "npx",
	["--no-install", "tsc", ...tscArgs],
	{
		cwd: here,
		stdio: "inherit",
		// Inherit env so npm's `_PATH` resolution works inside workspaces.
		env: process.env,
	},
);
if (tsc.status !== 0) {
	console.error("[iom-e2e] suite compile failed (exit", tsc.status, ")");
	process.exit(tsc.status ?? 1);
}

if (!fs.existsSync(extensionTestsPath)) {
	console.error(`[iom-e2e] expected compiled entry at ${extensionTestsPath} — aborting.`);
	process.exit(1);
}

try {
	await runTests({
		extensionDevelopmentPath,
		extensionTestsPath,
		// `--disable-extensions` keeps the launched VS Code free of marketplace
		// extensions that could pollute command IDs / output channels. The
		// `--disable-workspace-trust` flag avoids the trust prompt blocking
		// activation.
		launchArgs: ["--disable-extensions", "--disable-workspace-trust"],
		// OATI_E2E=1 is read by `src/e2e-helpers.ts` to register the internal
		// commands that the tests drive (`iom._test.*`). Without it the
		// suite skips those checks gracefully.
		extensionTestsEnv: { OATI_E2E: "1" },
	});
} catch (err) {
	console.error("[iom-e2e] vs-code test launch failed:", err);
	process.exit(1);
}
