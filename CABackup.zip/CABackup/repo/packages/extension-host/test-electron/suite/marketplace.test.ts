// R7-B: MCP marketplace flow.
//
// Verifies that triggering `iom.openMarketplace` results in a non-empty
// curated registry snapshot. We assert against the test-helper command
// `iom._test.marketplaceState` rather than the webview message bus because
// inspecting webview->host RPCs in a single Mocha process requires reaching
// into private fields. The helper returns the same entries that
// `marketplace_state` carries to the panel.

import { strict as assert } from "node:assert";
import * as vscode from "vscode";

const EXTENSION_ID = "iom.oati-code";

interface MarketplaceEntry {
	id: string;
	displayName: string;
	installed: boolean;
	enabled: boolean;
}

describe("flow: mcp marketplace", () => {
	before(async () => {
		const ext = vscode.extensions.getExtension(EXTENSION_ID);
		assert.ok(ext, "extension missing");
		if (!ext.isActive) await ext.activate();
	});

	it("openMarketplace exposes the curated registry", async function () {
		this.timeout(15_000);
		// Trigger the user-visible command first to exercise its registration.
		await vscode.commands.executeCommand("iom.openMarketplace");

		let state: readonly MarketplaceEntry[] | undefined;
		try {
			state = await vscode.commands.executeCommand<readonly MarketplaceEntry[]>(
				"iom._test.marketplaceState",
			);
		} catch (err) {
			if (
				err instanceof Error &&
				/command 'iom._test\.marketplaceState' not found/i.test(err.message)
			) {
				console.log("[skipped] OATI_E2E not set — internal helper not registered");
				this.skip();
				return;
			}
			throw err;
		}

		assert.ok(Array.isArray(state), "expected an array of marketplace entries");
		assert.ok((state ?? []).length >= 10, `expected >= 10 curated entries, got ${state?.length}`);
		// At least the well-known IDs should be present.
		const ids = new Set((state ?? []).map((e) => e.id));
		for (const expected of ["filesystem", "git", "github"]) {
			assert.ok(ids.has(expected), `expected curated entry '${expected}' in marketplace`);
		}
		// Default state should be "not installed" in a fresh test profile.
		for (const e of state ?? []) {
			assert.equal(typeof e.installed, "boolean", "installed flag missing");
			assert.equal(typeof e.enabled, "boolean", "enabled flag missing");
		}
	});
});
