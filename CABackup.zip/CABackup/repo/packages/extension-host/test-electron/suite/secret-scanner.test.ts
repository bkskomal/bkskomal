// R7-B: Secret-scanner flow.
//
// The contract under test: when a user_message hits the chat-panel, the
// outbound payload is scanned BEFORE any provider HTTP call, and a
// `secret_warning` is surfaced for the user to acknowledge.
//
// We can't easily drive the full webview <-> host bus inside a Mocha process
// (the webview lives in a different renderer), so we hit the same scanner the
// chat-panel uses via the `iom._test.scanForSecrets` helper command. That
// helper calls into the same `scanForSecrets`/`redactSecrets` module the panel
// imports — same module, same behavior, no provider involved.

import { strict as assert } from "node:assert";
import * as vscode from "vscode";

const EXTENSION_ID = "iom.oati-code";

interface ScanResult {
	count: number;
	summary: string;
	matches: ReadonlyArray<{ kind: string; preview: string }>;
	redacted: string;
}

describe("flow: secret scanner", () => {
	before(async () => {
		const ext = vscode.extensions.getExtension(EXTENSION_ID);
		assert.ok(ext, "extension missing");
		if (!ext.isActive) await ext.activate();
	});

	it("detects an AWS access key before dispatch", async function () {
		this.timeout(15_000);
		// 20-char key: AKIA + 16 uppercase alphanumerics. Not a real key.
		const text = "please look at my AWS key AKIAIOSFODNN7EXAMPLE in the env";

		let res: ScanResult | undefined;
		try {
			res = await vscode.commands.executeCommand<ScanResult>("iom._test.scanForSecrets", { text });
		} catch (err) {
			if (err instanceof Error && /command 'iom._test\.scanForSecrets' not found/i.test(err.message)) {
				console.log("[skipped] OATI_E2E not set — internal helper not registered");
				this.skip();
				return;
			}
			throw err;
		}

		assert.ok(res, "expected a scan result");
		assert.equal(res.count, 1, `expected exactly one match, got ${res.count}`);
		assert.equal(res.matches[0].kind, "AWS access key");
		// Redaction should have replaced the key with [REDACTED:AWS access key].
		assert.match(
			res.redacted,
			/\[REDACTED:AWS access key\]/,
			"redacted payload missing redaction marker",
		);
		assert.ok(
			!res.redacted.includes("AKIAIOSFODNN7EXAMPLE"),
			"redacted payload still contains the raw key",
		);
		assert.match(res.summary, /AWS access key \(1\)/, "summary should count the AWS-key match");
	});

	it("does not flag innocuous text", async function () {
		this.timeout(10_000);

		let res: ScanResult | undefined;
		try {
			res = await vscode.commands.executeCommand<ScanResult>("iom._test.scanForSecrets", {
				text: "hello world, this is a perfectly normal sentence.",
			});
		} catch (err) {
			if (err instanceof Error && /command 'iom._test\.scanForSecrets' not found/i.test(err.message)) {
				console.log("[skipped] OATI_E2E not set — internal helper not registered");
				this.skip();
				return;
			}
			throw err;
		}

		assert.ok(res, "expected a scan result");
		assert.equal(res.count, 0, "innocuous text should produce zero matches");
	});
});
