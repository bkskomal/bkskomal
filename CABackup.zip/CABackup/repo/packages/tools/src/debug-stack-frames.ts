// R6-E: debug_stack_frames — fetch the current call stack for a thread in
// the active debug session. Backed by `ctx.debug.getStackFrames` (wraps the
// DAP `stackTrace` request). When no thread id is supplied the bridge
// defaults to whichever thread is currently stopped.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface DebugStackFramesArgs {
	readonly threadId?: number;
}

function isDebugStackFramesArgs(v: unknown): v is DebugStackFramesArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as DebugStackFramesArgs;
	if (a.threadId !== undefined && typeof a.threadId !== "number") return false;
	return true;
}

export const debugStackFramesTool: ToolSpec = {
	name: "debug_stack_frames",
	description:
		"List the call stack for a thread in the active debug session. Returns a JSON array of {id, name, path?, line?} entries (1-based lines). Omit threadId to use whichever thread is currently stopped. Use this to inspect where execution paused before evaluating expressions or reading variables.",
	schema: {
		type: "object",
		properties: {
			threadId: {
				type: "integer",
				description: "Optional thread id (DAP). Defaults to the currently stopped thread.",
			},
		},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isDebugStackFramesArgs(args)) {
			throw new Error("debug_stack_frames: invalid args, expected { threadId?: number }");
		}
		if (!ctx.debug) {
			return JSON.stringify({ frames: [], note: "debug_stack_frames: no debug bridge in this host." });
		}
		if (!ctx.debug.getActiveSession()) {
			return JSON.stringify({ frames: [], note: "debug_stack_frames: no active debug session." });
		}
		try {
			const frames = await ctx.debug.getStackFrames(args?.threadId);
			return JSON.stringify({ frames });
		} catch (err) {
			const msg = err instanceof Error ? err.message : String(err);
			return JSON.stringify({ frames: [], error: msg });
		}
	},
};
