// R5-D: set_persona tool. Lets the agent switch its own persona mid-task — for
// example a Plan-mode session can briefly hop into the `security-auditor`
// persona to review a draft, then back to whatever it was using.
//
// Approval is `auto` because the action is purely an in-process prompt swap;
// it never touches files, network, or shell. The host enforces persona
// validity (unknown ids are rejected) and persists the change on SessionMeta.
//
// TODO(r5-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import type { ToolSpec } from "@iom/shared";

interface SetPersonaArgs {
	/**
	 * Persona slug from the built-in catalog (e.g. `senior-reviewer`). Pass
	 * `null` (or the literal string "none" / "") to clear the active persona.
	 */
	readonly personaId: string | null;
}

function isSetPersonaArgs(v: unknown): v is SetPersonaArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as { personaId?: unknown };
	if (a.personaId === null) return true;
	return typeof a.personaId === "string";
}

export const setPersonaTool: ToolSpec = {
	name: "set_persona",
	description:
		"Switch the active built-in persona for the current session. Pass null (or empty string) to clear. Personas layer a small system-prompt addendum onto the active mode's prompt; they do not change the mode itself. Use when the task would benefit from a different lens (e.g. `security-auditor` for a review pass) and switch back afterwards.",
	schema: {
		type: "object",
		properties: {
			personaId: {
				type: "string",
				description:
					"Built-in persona id, or empty string to clear. Known ids: junior-dev, senior-reviewer, security-auditor, perf-optimizer, doc-writer, refactorer.",
			},
		},
		required: ["personaId"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, _ctx): Promise<string> {
		if (!isSetPersonaArgs(args)) {
			throw new Error("set_persona: invalid args — expected { personaId: string | null }");
		}
		// The actual session-store mutation is wired in chat-panel.ts via the
		// `set_persona` RPC; from the tool's vantage point we just need to
		// surface the intent so the conductor records it in the transcript.
		// The host-side bridge that listens for tool_call events promotes this
		// to a setPersona() call on SessionStore (see r5-merge TODO above).
		const raw = args.personaId;
		const normalized =
			raw === null || (typeof raw === "string" && raw.trim().length === 0) ? null : raw;
		if (normalized === null) {
			return "Persona cleared. The next agent turn will use the active mode's system prompt alone.";
		}
		return `Persona set to '${normalized}'. The next agent turn will prepend this persona's addendum to the active mode's system prompt.`;
	},
};
