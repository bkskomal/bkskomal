// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts (owned by R8-A).
// R8-D: computer-use key_press tool — sends a key (with optional modifiers)
// using VS Code-style names like "cmd+s", "ctrl+shift+p", "Enter".

import type { ToolSpec } from "@iom/shared";
import { loadNutJs, resolveKeyChord } from "./nut-loader";

interface KeyPressArgs {
	readonly key: string;
	readonly modifiers?: readonly string[];
}

interface KeyPressResult {
	readonly pressed: true;
	readonly key: string;
	readonly modifiers: readonly string[];
}

function isKeyPressArgs(v: unknown): v is KeyPressArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as KeyPressArgs;
	if (typeof a.key !== "string" || a.key.length === 0) return false;
	if (a.modifiers !== undefined) {
		if (!Array.isArray(a.modifiers)) return false;
		if (!a.modifiers.every((m) => typeof m === "string")) return false;
	}
	return true;
}

export const keyPressTool: ToolSpec<KeyPressArgs, KeyPressResult> = {
	name: "key_press",
	description:
		"Press a key (with optional modifiers) using VS Code-style names. " +
		"Accepts combined chords like `cmd+s`, `ctrl+shift+p`, or a base key plus `modifiers: ['ctrl','shift']`. Approval-gated.",
	schema: {
		type: "object",
		properties: {
			key: {
				type: "string",
				description: "Key name or chord. Examples: `Enter`, `Escape`, `a`, `ctrl+shift+p`.",
			},
			modifiers: {
				type: "array",
				items: { type: "string" },
				description: "Optional modifiers to combine with `key`: any of ctrl, shift, alt, cmd.",
			},
		},
		required: ["key"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<KeyPressResult> {
		if (!isKeyPressArgs(args)) throw new Error("key_press: invalid args");
		const api = await loadNutJs();
		const chord = resolveKeyChord(api, args.key, args.modifiers);
		// Press modifiers, then base key, then release in reverse order so the
		// OS sees a clean chord rather than overlapping repeats.
		for (const m of chord.modifiers) await api.keyboard.pressKey(m);
		await api.keyboard.pressKey(chord.key);
		await api.keyboard.releaseKey(chord.key);
		for (let i = chord.modifiers.length - 1; i >= 0; i--) {
			await api.keyboard.releaseKey(chord.modifiers[i]);
		}
		return {
			pressed: true,
			key: chord.keyName,
			modifiers: args.modifiers ?? [],
		};
	},
};
