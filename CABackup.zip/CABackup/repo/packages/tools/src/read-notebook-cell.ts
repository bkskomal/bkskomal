// R6-B: read_notebook_cell — fetch a single cell from a .ipynb file (source +
// outputs). Companion to `read_notebook` for when the agent only needs one
// cell; saves dragging the whole notebook through the context window.
import type { NotebookCellSnapshot, ToolSpec } from "@iom/shared";
import { parseNotebookJson } from "./read-notebook";

interface ReadNotebookCellArgs {
	readonly path: string;
	readonly index: number;
}

function isReadNotebookCellArgs(v: unknown): v is ReadNotebookCellArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as ReadNotebookCellArgs;
	return typeof a.path === "string" && typeof a.index === "number" && Number.isFinite(a.index);
}

export const readNotebookCellTool: ToolSpec = {
	name: "read_notebook_cell",
	description:
		"Read a single cell from a Jupyter notebook (.ipynb) by 0-based index. Returns {index, kind, language, source, outputs}. Outputs are always included since the caller has explicitly asked for one cell.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Path to the .ipynb file, relative to workspace root or absolute.",
			},
			index: {
				type: "integer",
				description: "0-based cell index. Use read_notebook first if you don't know the index.",
			},
		},
		required: ["path", "index"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isReadNotebookCellArgs(args)) {
			throw new Error("read_notebook_cell: invalid args, expected { path: string; index: number }");
		}
		let cells: readonly NotebookCellSnapshot[];
		if (ctx.notebooks) {
			cells = await ctx.notebooks.read(args.path, true);
		} else {
			const raw = await ctx.readFile(args.path);
			cells = parseNotebookJson(raw, true);
		}
		if (args.index < 0 || args.index >= cells.length) {
			throw new Error(
				`read_notebook_cell: index ${args.index} out of range (notebook has ${cells.length} cells)`,
			);
		}
		return JSON.stringify(cells[args.index]);
	},
};
