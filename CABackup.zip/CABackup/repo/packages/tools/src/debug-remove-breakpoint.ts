// R6-E: debug_remove_breakpoint — remove any source breakpoint at `path:line`.
// Backed by `ctx.debug.removeBreakpoint`, which wraps
// `vscode.debug.removeBreakpoints(...)`. No-ops cleanly when no breakpoint is
// registered at the location. Approval is "prompt" because removing a
// breakpoint can change behavior of the user's running debug session.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface DebugRemoveBreakpointArgs {
	readonly path: string;
	readonly line: number;
}

function isDebugRemoveBreakpointArgs(v: unknown): v is DebugRemoveBreakpointArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DebugRemoveBreakpointArgs;
	if (typeof a.path !== "string" || a.path.length === 0) return false;
	if (typeof a.line !== "number" || a.line < 1) return false;
	return true;
}

export const debugRemoveBreakpointTool: ToolSpec = {
	name: "debug_remove_breakpoint",
	description:
		"Remove any source breakpoint anchored at the given path:line (1-based). Returns 'ok' on success, even when no matching breakpoint was registered (idempotent).",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Workspace-relative or absolute path to the source file.",
			},
			line: {
				type: "integer",
				description: "1-based line number of the breakpoint to remove.",
			},
		},
		required: ["path", "line"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx) {
		if (!isDebugRemoveBreakpointArgs(args)) {
			throw new Error(
				"debug_remove_breakpoint: invalid args, expected { path: string; line: number }",
			);
		}
		if (!ctx.debug) {
			return "debug_remove_breakpoint: no debug bridge in this host.";
		}
		try {
			await ctx.debug.removeBreakpoint(args.path, args.line);
			return `ok — removed breakpoint at ${args.path}:${args.line}`;
		} catch (err) {
			return `debug_remove_breakpoint: error — ${err instanceof Error ? err.message : String(err)}`;
		}
	},
};
