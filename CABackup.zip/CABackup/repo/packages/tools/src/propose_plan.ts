// R6-A: `propose_plan` tool.
//
// Lets the agent ask for a structured PlanV2 from a non-Plan-mode turn. The
// actual `planRequest` call lives in `@iom/agent-core`; this tool's handler
// is a thin pass-through so that:
//   - The host bridge can intercept the tool_call event and surface the plan
//     in the webview editor via `plan_proposed`, OR
//   - When no bridge is wired (tests / CLI), the agent simply gets a textual
//     description back and can decide what to do.
//
// Approval is `auto` because producing a plan is a purely-cognitive action —
// no files, shell, or network egress beyond the model call itself.

import type { ToolSpec } from "@iom/shared";

interface ProposePlanArgs {
	readonly task: string;
	/** Optional: hint for how much detail (3-8 steps). */
	readonly stepCountHint?: number;
}

function isProposePlanArgs(v: unknown): v is ProposePlanArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as { task?: unknown; stepCountHint?: unknown };
	if (typeof a.task !== "string" || a.task.trim().length === 0) return false;
	if (a.stepCountHint !== undefined && typeof a.stepCountHint !== "number") return false;
	return true;
}

export const proposePlanTool: ToolSpec = {
	name: "propose_plan",
	description:
		"Produce a structured plan (PlanV2) for the given task: 3-8 steps with title + acceptance criterion + optional dependsOn edges. Useful when the user wants a plan upfront without switching to Plan mode. The host surfaces the resulting plan in the editor side panel; the agent only needs to call this once per request.",
	schema: {
		type: "object",
		properties: {
			task: {
				type: "string",
				description: "Free-form task description to plan for.",
			},
			stepCountHint: {
				type: "number",
				description:
					"Optional preferred step count in [3,8]. The planner may still emit a different count.",
			},
		},
		required: ["task"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, _ctx, _callCtx): Promise<unknown> {
		if (!isProposePlanArgs(args)) {
			throw new Error("propose_plan: invalid args — expected { task: string }");
		}
		// The host bridge (chat-panel.ts) is responsible for intercepting this
		// tool_call event, invoking `planRequest()` against the active provider,
		// and forwarding the result to the webview via `plan_proposed`. From
		// the tool's vantage point we just confirm the request was queued so
		// the agent transcript records the intent.
		const hint = args.stepCountHint !== undefined ? ` (target ~${args.stepCountHint} steps)` : "";
		return {
			ok: true,
			note: `Plan requested for: ${args.task.slice(0, 200)}${hint}. The host will produce a structured PlanV2 and open the editor side panel.`,
		};
	},
};
