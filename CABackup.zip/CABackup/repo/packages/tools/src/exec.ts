import type { ExecShell, ToolSpec } from "@iom/shared";

interface ExecArgs {
	readonly command: string;
	readonly cwd?: string;
	readonly timeoutMs?: number;
	readonly shell?: ExecShell;
}

const VALID_SHELLS: readonly ExecShell[] = ["auto", "bash", "pwsh", "powershell", "cmd", "sh"];

function isExecArgs(v: unknown): v is ExecArgs {
	if (typeof v !== "object" || v === null) return false;
	const e = v as ExecArgs;
	if (typeof e.command !== "string") return false;
	if (e.cwd !== undefined && typeof e.cwd !== "string") return false;
	if (e.timeoutMs !== undefined && typeof e.timeoutMs !== "number") return false;
	if (e.shell !== undefined && !VALID_SHELLS.includes(e.shell)) return false;
	return true;
}

/** Soft cap on streamed bytes per call to keep the webview snappy. */
const STREAM_CHUNK_BUDGET = 256 * 1024;

// Description-policy reference:
// - `shell` selection: `bash` for POSIX (ls, grep, &&, here-docs, $vars),
//   `pwsh` for PowerShell (cmdlets, $env:, -NoProfile), `cmd` for Windows
//   CMD, `auto` for platform default. Windows fallbacks: bash→Git Bash,
//   pwsh→Windows PowerShell.
// - Returns stdout, stderr, exitCode. Streams stdout when host supports it.
// - For commands that don't return (servers, watchers), use
//   `start_background_process` instead — exec blocks and times out at 60s.
export const execTool: ToolSpec = {
	name: "exec",
	description:
		"Run a shell command in the workspace. Pick `shell`: `bash` (POSIX), `pwsh` (PowerShell), `cmd` (Windows CMD), or `auto`. For long-running processes (dev servers, watchers), use `start_background_process` instead — exec times out at 60s.",
	schema: {
		type: "object",
		properties: {
			command: { type: "string", description: "Shell command to run." },
			cwd: {
				type: "string",
				description: "Working directory. Defaults to workspace root.",
			},
			timeoutMs: {
				type: "integer",
				description: "Optional timeout in milliseconds. Default 60000.",
				default: 60000,
			},
			shell: {
				type: "string",
				enum: ["auto", "bash", "pwsh", "powershell", "cmd", "sh"],
				description:
					"Shell to dispatch through. `auto` uses the platform default. `bash` runs via Git Bash on Windows. `pwsh` prefers PowerShell 7, falling back to Windows PowerShell when pwsh isn't installed.",
				default: "auto",
			},
		},
		required: ["command"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx, callCtx) {
		if (!isExecArgs(args)) throw new Error("exec: invalid args");
		const callId = callCtx?.callId;
		// Only stream when both the host can receive tool_progress events AND we
		// know the call id to tag chunks with. Otherwise fall back to buffered.
		const emit = ctx.emitToolProgress;
		let streamed = 0;
		const onChunk =
			emit && callId
				? (chunk: string) => {
						if (streamed >= STREAM_CHUNK_BUDGET) return;
						const room = STREAM_CHUNK_BUDGET - streamed;
						const trimmed = chunk.length > room ? chunk.slice(0, room) : chunk;
						streamed += trimmed.length;
						emit(callId, trimmed);
					}
				: undefined;
		return ctx.exec(args.command, {
			cwd: args.cwd,
			timeoutMs: args.timeoutMs ?? 60_000,
			...(onChunk ? { onChunk } : {}),
			...(args.shell ? { shell: args.shell } : {}),
		});
	},
};
