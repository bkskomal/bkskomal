import type { ToolSpec } from "@iom/shared";

interface GitCommitArgs {
	readonly message: string;
	readonly paths?: readonly string[];
	readonly signoff?: boolean;
}

interface GitCommitResult {
	readonly committed: boolean;
	readonly stdout: string;
	readonly stderr: string;
	readonly exitCode: number;
}

function isGitCommitArgs(v: unknown): v is GitCommitArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as GitCommitArgs;
	if (typeof a.message !== "string" || a.message.length === 0) return false;
	if (a.signoff !== undefined && typeof a.signoff !== "boolean") return false;
	if (a.paths !== undefined) {
		if (!Array.isArray(a.paths)) return false;
		for (const p of a.paths) if (typeof p !== "string") return false;
	}
	return true;
}

function quotePath(p: string): string {
	if (process.platform === "win32") return `"${p.replace(/"/g, '\\"')}"`;
	return `'${p.replace(/'/g, "'\\''")}'`;
}

/**
 * Quote a commit message for the shell. Single-quote on POSIX, double-quote on
 * Windows (cmd doesn't honor single quotes). Newlines in messages are passed
 * through verbatim — both `bash -c` and `cmd /c` handle them correctly when the
 * argument is properly quoted.
 */
function quoteMessage(m: string): string {
	if (process.platform === "win32") {
		// cmd.exe: double-quote and escape embedded double quotes.
		return `"${m.replace(/"/g, '\\"')}"`;
	}
	// POSIX: single-quote, escape embedded single quotes.
	return `'${m.replace(/'/g, "'\\''")}'`;
}

export const gitCommitTool: ToolSpec = {
	name: "git_commit",
	description:
		"Create a git commit with the given message. Optionally stage specific paths first. Requires user approval because it mutates repo state.",
	schema: {
		type: "object",
		properties: {
			message: { type: "string", description: "Commit message (may be multi-line)." },
			paths: {
				type: "array",
				items: { type: "string" },
				description:
					"Optional paths to stage with `git add` before committing. If omitted, only already-staged changes are committed.",
			},
			signoff: {
				type: "boolean",
				description: "When true, append a `Signed-off-by` trailer.",
			},
		},
		required: ["message"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isGitCommitArgs(args)) return {};
		const lines = [
			`Commit message: ${args.message.split("\n")[0]}`,
			args.paths && args.paths.length > 0
				? `Will stage: ${args.paths.join(", ")}`
				: "Will commit currently staged changes only.",
			args.signoff ? "Signoff: yes" : "",
		].filter((l) => l.length > 0);
		return { note: lines.join("\n") };
	},
	async handler(args, ctx): Promise<GitCommitResult> {
		if (!isGitCommitArgs(args)) throw new Error("git_commit: invalid args");

		// Stage requested paths first, if any.
		if (args.paths && args.paths.length > 0) {
			const addCmd = ["git", "add", "--", ...args.paths.map(quotePath)].join(" ");
			const addRes = await ctx.exec(addCmd, { timeoutMs: 30_000 });
			if (addRes.exitCode !== 0) {
				throw new Error(
					`git add failed (exit ${addRes.exitCode}): ${addRes.stderr.trim() || addRes.stdout.trim() || "no output"}`,
				);
			}
		}

		const parts: string[] = ["git", "commit", "-m", quoteMessage(args.message)];
		if (args.signoff) parts.push("--signoff");
		const res = await ctx.exec(parts.join(" "), { timeoutMs: 30_000 });
		return {
			committed: res.exitCode === 0,
			stdout: res.stdout,
			stderr: res.stderr,
			exitCode: res.exitCode,
		};
	},
};
