// TODO(r5-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import { promises as fs } from "node:fs";
import * as path from "node:path";
import { CodebaseIndex, TfIdfEmbedder } from "@iom/codebase-index";
import type { ToolSpec } from "@iom/shared";

const KNOWLEDGE_RELATIVE_DIR = ".iom/knowledge";
const KNOWLEDGE_DB_FILENAME = "knowledge.sqlite";

const DEFAULT_K = 4;
const MAX_K = 12;
const SNIPPET_CHAR_CAP = 600;

interface SearchKnowledgeArgs {
	readonly query: string;
	readonly k?: number;
}

function isSearchKnowledgeArgs(v: unknown): v is SearchKnowledgeArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SearchKnowledgeArgs;
	if (typeof a.query !== "string") return false;
	if (a.k !== undefined && typeof a.k !== "number") return false;
	return true;
}

interface SearchKnowledgeHit {
	readonly path: string;
	readonly snippet: string;
	readonly score: number;
}

interface SearchKnowledgeResult {
	readonly hits: readonly SearchKnowledgeHit[];
}

/**
 * R5-B: semantic search over the knowledge namespace. Opens the same sqlite
 * file the host-side `KnowledgeStore` writes (`<workspace>/.iom/knowledge.sqlite`)
 * with a fresh `CodebaseIndex` for read-only queries — no rebuild kicked off
 * here so the tool stays fast. When the knowledge dir is empty (or the host
 * has never indexed yet), returns `{ hits: [] }` rather than failing.
 */
export const searchKnowledgeTool: ToolSpec = {
	name: "search_knowledge",
	description:
		"Semantic search over the project knowledge base (`<workspace>/.iom/knowledge/**/*.md`). Returns the top-k chunks with file path + snippet + score. Use this before reading whole docs when you're not sure where the relevant note lives. Falls back to an empty result when the knowledge index hasn't been built yet.",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description: "Natural-language description of what you're looking for.",
			},
			k: {
				type: "integer",
				description: `Max results. Default ${DEFAULT_K}, max ${MAX_K}.`,
			},
		},
		required: ["query"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<SearchKnowledgeResult> {
		if (!isSearchKnowledgeArgs(args)) {
			throw new Error("search_knowledge: invalid args");
		}
		const root = ctx.workspaceRoot();
		if (!root) return { hits: [] };
		// Bail out early when there's no knowledge dir at all — avoids opening
		// an empty sqlite file just to return zero hits.
		const dir = path.join(root, KNOWLEDGE_RELATIVE_DIR);
		try {
			const stat = await fs.stat(dir);
			if (!stat.isDirectory()) return { hits: [] };
		} catch {
			return { hits: [] };
		}
		const dbPath = path.join(root, ".iom", KNOWLEDGE_DB_FILENAME);
		const k = Math.min(Math.max(args.k ?? DEFAULT_K, 1), MAX_K);
		const idx = new CodebaseIndex({
			workspaceRoot: root,
			dbPath,
			embedder: new TfIdfEmbedder(),
		});
		try {
			const results = await idx.query(args.query, { k });
			const hits: SearchKnowledgeHit[] = results.map((r) => ({
				path: r.filePath,
				snippet:
					r.content.length > SNIPPET_CHAR_CAP
						? `${r.content.slice(0, SNIPPET_CHAR_CAP)}\n... (truncated)`
						: r.content,
				score: r.score,
			}));
			return { hits };
		} finally {
			idx.close();
		}
	},
};
