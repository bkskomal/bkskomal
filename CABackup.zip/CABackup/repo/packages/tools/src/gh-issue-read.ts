// TODO(r3-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface GhIssueReadArgs {
	readonly url?: string;
	readonly owner?: string;
	readonly repo?: string;
	readonly number?: number;
}

interface GhIssueComment {
	readonly author: string;
	readonly body: string;
}

interface GhIssueReadResult {
	readonly ok: boolean;
	readonly title?: string;
	readonly body?: string;
	readonly labels?: readonly string[];
	readonly assignees?: readonly string[];
	readonly comments?: readonly GhIssueComment[];
	readonly message?: string;
	readonly stdout?: string;
	readonly stderr?: string;
}

interface GhIssueRef {
	readonly owner: string;
	readonly repo: string;
	readonly number: number;
}

function isGhIssueReadArgs(v: unknown): v is GhIssueReadArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as GhIssueReadArgs;
	if (a.url !== undefined && typeof a.url !== "string") return false;
	if (a.owner !== undefined && typeof a.owner !== "string") return false;
	if (a.repo !== undefined && typeof a.repo !== "string") return false;
	if (a.number !== undefined && typeof a.number !== "number") return false;
	return true;
}

/**
 * Parse a GitHub issue URL into (owner, repo, number). Accepts the standard
 * `https://github.com/<owner>/<repo>/issues/<n>` shape; returns undefined for
 * anything else (PR URLs included — they'd need `gh pr view` instead).
 */
export function parseIssueUrl(url: string): GhIssueRef | undefined {
	const m = url.match(/github\.com\/([^/\s]+)\/([^/\s]+)\/issues\/(\d+)/i);
	if (!m) return undefined;
	const n = Number.parseInt(m[3], 10);
	if (!Number.isFinite(n) || n <= 0) return undefined;
	return { owner: m[1], repo: m[2], number: n };
}

export function resolveIssueRef(args: GhIssueReadArgs): GhIssueRef | undefined {
	if (args.url) {
		const parsed = parseIssueUrl(args.url);
		if (parsed) return parsed;
	}
	if (args.owner && args.repo && typeof args.number === "number" && args.number > 0) {
		return { owner: args.owner, repo: args.repo, number: args.number };
	}
	return undefined;
}

function quoteArg(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

interface RawGhIssue {
	title?: string;
	body?: string;
	labels?: Array<{ name?: string }>;
	assignees?: Array<{ login?: string }>;
	comments?: Array<{ author?: { login?: string }; body?: string }>;
}

function normalizeIssue(raw: RawGhIssue): Omit<GhIssueReadResult, "ok" | "stdout" | "stderr"> {
	const labels = (raw.labels ?? [])
		.map((l) => (typeof l?.name === "string" ? l.name : ""))
		.filter((s) => s.length > 0);
	const assignees = (raw.assignees ?? [])
		.map((a) => (typeof a?.login === "string" ? a.login : ""))
		.filter((s) => s.length > 0);
	const comments: GhIssueComment[] = (raw.comments ?? []).map((c) => ({
		author: c?.author?.login ?? "(unknown)",
		body: c?.body ?? "",
	}));
	return {
		title: raw.title ?? "",
		body: raw.body ?? "",
		labels,
		assignees,
		comments,
	};
}

export const ghIssueReadTool: ToolSpec = {
	name: "gh_issue_read",
	description:
		"Read a GitHub issue (title, body, labels, assignees, comments) via the `gh` CLI. Accepts either a full issue URL or owner+repo+number.",
	schema: {
		type: "object",
		properties: {
			url: {
				type: "string",
				description: "Full GitHub issue URL, e.g. https://github.com/owner/repo/issues/42.",
			},
			owner: { type: "string", description: "Repo owner (used when `url` is absent)." },
			repo: { type: "string", description: "Repo name (used when `url` is absent)." },
			number: { type: "integer", description: "Issue number (used when `url` is absent)." },
		},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<GhIssueReadResult> {
		if (!isGhIssueReadArgs(args)) throw new Error("gh_issue_read: invalid args");
		const ref = resolveIssueRef(args);
		if (!ref) {
			return {
				ok: false,
				message:
					"gh_issue_read: provide either `url` (e.g. https://github.com/owner/repo/issues/42) or all of `owner`, `repo`, and `number`.",
			};
		}

		// Detect `gh` first so we can surface a friendly install hint.
		const probeCmd = process.platform === "win32" ? "where gh" : "command -v gh";
		const probe = await ctx.exec(probeCmd, { timeoutMs: 10_000 });
		if (probe.exitCode !== 0) {
			return {
				ok: false,
				message:
					"GitHub CLI (`gh`) is not installed or not on PATH. Install from https://cli.github.com/ and run `gh auth login`, then retry.",
				stdout: probe.stdout,
				stderr: probe.stderr,
			};
		}

		const repoSpec = `${ref.owner}/${ref.repo}`;
		const cmd = [
			"gh",
			"issue",
			"view",
			String(ref.number),
			"-R",
			quoteArg(repoSpec),
			"--json",
			"title,body,labels,assignees,comments",
		].join(" ");
		const res = await ctx.exec(cmd, { timeoutMs: 30_000 });
		if (res.exitCode !== 0) {
			const stderr = res.stderr.trim();
			let hint = "";
			if (/not.*authenticated|gh auth login/i.test(stderr)) {
				hint = " Tip: run `gh auth login` first.";
			} else if (/could not resolve|not found/i.test(stderr)) {
				hint = " Tip: check the owner/repo/number — the issue may not exist or be private.";
			}
			return {
				ok: false,
				message: `gh issue view failed (exit ${res.exitCode}).${hint}`,
				stdout: res.stdout,
				stderr: res.stderr,
			};
		}

		let raw: RawGhIssue;
		try {
			raw = JSON.parse(res.stdout) as RawGhIssue;
		} catch (err) {
			return {
				ok: false,
				message: `gh_issue_read: failed to parse JSON from gh (${err instanceof Error ? err.message : String(err)}).`,
				stdout: res.stdout,
				stderr: res.stderr,
			};
		}

		const normalized = normalizeIssue(raw);
		return {
			ok: true,
			...normalized,
			stdout: res.stdout,
			stderr: res.stderr,
		};
	},
};

// Exported for unit testing.
export const __test = { parseIssueUrl, resolveIssueRef, normalizeIssue };
