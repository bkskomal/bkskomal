// TODO(r3-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";
import { parseIssueUrl } from "./gh-issue-read";

interface GhIssueCommentArgs {
	readonly url?: string;
	readonly owner?: string;
	readonly repo?: string;
	readonly number?: number;
	readonly body: string;
}

interface GhIssueCommentResult {
	readonly ok: boolean;
	readonly url?: string;
	readonly message: string;
	readonly stdout: string;
	readonly stderr: string;
}

function isGhIssueCommentArgs(v: unknown): v is GhIssueCommentArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as GhIssueCommentArgs;
	if (typeof a.body !== "string" || a.body.length === 0) return false;
	if (a.url !== undefined && typeof a.url !== "string") return false;
	if (a.owner !== undefined && typeof a.owner !== "string") return false;
	if (a.repo !== undefined && typeof a.repo !== "string") return false;
	if (a.number !== undefined && typeof a.number !== "number") return false;
	return true;
}

interface ResolvedRef {
	readonly owner: string;
	readonly repo: string;
	readonly number: number;
}

function resolveRef(args: GhIssueCommentArgs): ResolvedRef | undefined {
	if (args.url) {
		const parsed = parseIssueUrl(args.url);
		if (parsed) return parsed;
	}
	if (args.owner && args.repo && typeof args.number === "number" && args.number > 0) {
		return { owner: args.owner, repo: args.repo, number: args.number };
	}
	return undefined;
}

function quoteArg(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

function extractCommentUrl(stdout: string): string | undefined {
	const m = stdout.match(/https?:\/\/\S+/);
	return m ? m[0] : undefined;
}

export const ghIssueCommentTool: ToolSpec = {
	name: "gh_issue_comment",
	description:
		"Post a comment on a GitHub issue via the `gh` CLI. Requires user approval (visible side effect) and `gh` installed on PATH.",
	schema: {
		type: "object",
		properties: {
			url: {
				type: "string",
				description: "Full GitHub issue URL, e.g. https://github.com/owner/repo/issues/42.",
			},
			owner: { type: "string", description: "Repo owner (used when `url` is absent)." },
			repo: { type: "string", description: "Repo name (used when `url` is absent)." },
			number: { type: "integer", description: "Issue number (used when `url` is absent)." },
			body: { type: "string", description: "Markdown body of the comment to post." },
		},
		required: ["body"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isGhIssueCommentArgs(args)) return {};
		const ref = resolveRef(args);
		const target = ref
			? `${ref.owner}/${ref.repo}#${ref.number}`
			: (args.url ?? "(no target resolved)");
		const lines = [
			`Post comment on: ${target}`,
			`Body (first 200 chars): ${args.body.slice(0, 200)}${args.body.length > 200 ? "…" : ""}`,
		];
		return { note: lines.join("\n") };
	},
	async handler(args, ctx): Promise<GhIssueCommentResult> {
		if (!isGhIssueCommentArgs(args)) throw new Error("gh_issue_comment: invalid args");
		const ref = resolveRef(args);
		if (!ref) {
			return {
				ok: false,
				message: "gh_issue_comment: provide either `url` or all of `owner`, `repo`, and `number`.",
				stdout: "",
				stderr: "",
			};
		}

		const probeCmd = process.platform === "win32" ? "where gh" : "command -v gh";
		const probe = await ctx.exec(probeCmd, { timeoutMs: 10_000 });
		if (probe.exitCode !== 0) {
			return {
				ok: false,
				message:
					"GitHub CLI (`gh`) is not installed or not on PATH. Install from https://cli.github.com/ and run `gh auth login`, then retry.",
				stdout: probe.stdout,
				stderr: probe.stderr,
			};
		}

		const repoSpec = `${ref.owner}/${ref.repo}`;
		const cmd = [
			"gh",
			"issue",
			"comment",
			String(ref.number),
			"-R",
			quoteArg(repoSpec),
			"-b",
			quoteArg(args.body),
		].join(" ");
		const res = await ctx.exec(cmd, { timeoutMs: 30_000 });
		if (res.exitCode !== 0) {
			const stderr = res.stderr.trim();
			let hint = "";
			if (/not.*authenticated|gh auth login/i.test(stderr)) {
				hint = " Tip: run `gh auth login` first.";
			}
			return {
				ok: false,
				message: `gh issue comment failed (exit ${res.exitCode}).${hint}`,
				stdout: res.stdout,
				stderr: res.stderr,
			};
		}
		const url = extractCommentUrl(res.stdout);
		return {
			ok: true,
			url,
			message: url ? `Posted comment: ${url}` : "Comment posted.",
			stdout: res.stdout,
			stderr: res.stderr,
		};
	},
};

// Exported for unit testing.
export const __test = { resolveRef };
