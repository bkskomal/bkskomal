// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts (owned by R8-A).
// R8-D: computer-use mouse_move tool — repositions the mouse cursor without
// clicking. Useful before screenshotting so the next visual frame matches
// what the model just decided to do.

import type { ToolSpec } from "@iom/shared";
import { loadNutJs } from "./nut-loader";

interface MouseMoveArgs {
	readonly x: number;
	readonly y: number;
}

interface MouseMoveResult {
	readonly moved: true;
	readonly x: number;
	readonly y: number;
}

function isMouseMoveArgs(v: unknown): v is MouseMoveArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as MouseMoveArgs;
	return typeof a.x === "number" && typeof a.y === "number";
}

export const mouseMoveTool: ToolSpec<MouseMoveArgs, MouseMoveResult> = {
	name: "mouse_move",
	description:
		"Move the mouse cursor to absolute screen coordinates (x, y) without clicking. Approval-gated.",
	schema: {
		type: "object",
		properties: {
			x: { type: "integer", description: "Screen x-coordinate." },
			y: { type: "integer", description: "Screen y-coordinate." },
		},
		required: ["x", "y"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<MouseMoveResult> {
		if (!isMouseMoveArgs(args)) throw new Error("mouse_move: invalid args");
		const api = await loadNutJs();
		await api.mouse.setPosition(new api.Point(args.x, args.y));
		return { moved: true, x: args.x, y: args.y };
	},
};
