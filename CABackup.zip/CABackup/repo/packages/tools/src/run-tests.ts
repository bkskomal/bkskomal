import type { HostContext, ToolSpec } from "@iom/shared";

interface RunTestsArgs {
	readonly pattern?: string;
	readonly bail?: boolean;
}

export interface TestFailure {
	readonly name: string;
	readonly snippet: string;
}

interface RunTestsResult {
	readonly exitCode: number;
	readonly summary: string;
	readonly failures: readonly TestFailure[];
	readonly runner: string;
}

function isRunTestsArgs(v: unknown): v is RunTestsArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as RunTestsArgs;
	if (a.pattern !== undefined && typeof a.pattern !== "string") return false;
	if (a.bail !== undefined && typeof a.bail !== "boolean") return false;
	return true;
}

type RunnerKind = "vitest" | "jest" | "mocha" | "pytest" | "npm-test" | "none";

interface RunnerDetection {
	readonly kind: RunnerKind;
	readonly buildCommand: (args: RunTestsArgs) => string;
}

function quote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}

/**
 * Detect the test runner the workspace uses. We check the JS/TS side first
 * (package.json devDeps + scripts) then fall back to Python markers. The
 * detection is intentionally tolerant — when nothing matches we return `none`
 * and the tool surfaces a friendly "no runner detected" result instead of
 * blowing up the agent loop.
 */
export async function detectRunner(ctx: HostContext): Promise<RunnerDetection> {
	const root = ctx.workspaceRoot();
	if (!root) {
		return {
			kind: "none",
			buildCommand: () => "true",
		};
	}

	// JS/TS side: read package.json if present.
	if (await ctx.fileExists("package.json")) {
		try {
			const pkgRaw = await ctx.readFile("package.json");
			const pkg = JSON.parse(pkgRaw) as {
				scripts?: Record<string, string>;
				dependencies?: Record<string, string>;
				devDependencies?: Record<string, string>;
			};
			const allDeps = {
				...(pkg.dependencies ?? {}),
				...(pkg.devDependencies ?? {}),
			};
			if ("vitest" in allDeps) {
				return {
					kind: "vitest",
					buildCommand: (a) => {
						const parts = ["npx", "vitest", "run", "--reporter=default"];
						if (a.bail) parts.push("--bail=1");
						if (a.pattern) parts.push(quote(a.pattern));
						return parts.join(" ");
					},
				};
			}
			if ("jest" in allDeps) {
				return {
					kind: "jest",
					buildCommand: (a) => {
						const parts = ["npx", "jest"];
						if (a.bail) parts.push("--bail");
						if (a.pattern) parts.push("-t", quote(a.pattern));
						return parts.join(" ");
					},
				};
			}
			if ("mocha" in allDeps) {
				return {
					kind: "mocha",
					buildCommand: (a) => {
						const parts = ["npx", "mocha"];
						if (a.bail) parts.push("--bail");
						if (a.pattern) parts.push("--grep", quote(a.pattern));
						return parts.join(" ");
					},
				};
			}
			// Fall back to `npm test` if a test script is defined — better than nothing.
			if (pkg.scripts && typeof pkg.scripts.test === "string") {
				return {
					kind: "npm-test",
					buildCommand: () => "npm test --silent",
				};
			}
		} catch {
			// fall through to python detection
		}
	}

	// Python side: pytest.ini / pyproject.toml
	const hasPytestIni = await ctx.fileExists("pytest.ini");
	const hasPyproject = await ctx.fileExists("pyproject.toml");
	if (hasPytestIni || hasPyproject) {
		return {
			kind: "pytest",
			buildCommand: (a) => {
				const parts = ["pytest", "-q"];
				if (a.bail) parts.push("-x");
				if (a.pattern) parts.push("-k", quote(a.pattern));
				return parts.join(" ");
			},
		};
	}

	return {
		kind: "none",
		buildCommand: () => "true",
	};
}

/**
 * Extract failure entries from a runner's combined stdout/stderr. Parsers are
 * intentionally permissive — they look for the most common shapes each runner
 * emits and stop after MAX_FAILURES so a giant failing suite doesn't blow up
 * the agent's context. When NO recognized pattern matches we fall back to
 * "first 40 lines of stderr" wrapped as a single synthetic failure entry, so
 * the agent always has SOMETHING actionable to feed back to the loop.
 */
const MAX_FAILURES = 20;
const SNIPPET_LINES = 12;

export function parseFailures(runner: RunnerKind, stdout: string, stderr: string): TestFailure[] {
	const combined = `${stdout}\n${stderr}`;
	const out: TestFailure[] = [];

	if (runner === "vitest") {
		// Vitest prints `FAIL  path/to/file.test.ts > name > sub-name` blocks.
		const lines = combined.split(/\r?\n/);
		for (let i = 0; i < lines.length && out.length < MAX_FAILURES; i++) {
			const l = lines[i];
			const m = l.match(/^\s*(?:×|FAIL)\s+(.+)$/);
			if (m) {
				const name = m[1].trim();
				const snippet = lines.slice(i, i + SNIPPET_LINES).join("\n");
				out.push({ name, snippet });
			}
		}
	} else if (runner === "jest") {
		// Jest prints `● TestName > nested name` then a stack trace.
		const lines = combined.split(/\r?\n/);
		for (let i = 0; i < lines.length && out.length < MAX_FAILURES; i++) {
			const l = lines[i];
			const m = l.match(/^\s*●\s+(.+)$/);
			if (m) {
				out.push({
					name: m[1].trim(),
					snippet: lines.slice(i, i + SNIPPET_LINES).join("\n"),
				});
			}
		}
	} else if (runner === "mocha") {
		// Mocha lists failing specs as `N) <name>` then "<stack>".
		const lines = combined.split(/\r?\n/);
		for (let i = 0; i < lines.length && out.length < MAX_FAILURES; i++) {
			const m = lines[i].match(/^\s*\d+\)\s+(.+)$/);
			if (m) {
				out.push({
					name: m[1].trim(),
					snippet: lines.slice(i, i + SNIPPET_LINES).join("\n"),
				});
			}
		}
	} else if (runner === "pytest") {
		// pytest prints `FAILED path::test_name - reason` lines in short mode, and
		// `_____ test_name _____` headers in verbose. We catch both.
		const lines = combined.split(/\r?\n/);
		for (let i = 0; i < lines.length && out.length < MAX_FAILURES; i++) {
			const l = lines[i];
			const failed = l.match(/^FAILED\s+(\S+)(?:\s+-\s+(.+))?$/);
			if (failed) {
				out.push({
					name: failed[1],
					snippet: failed[2] ? `${l}` : lines.slice(i, i + SNIPPET_LINES).join("\n"),
				});
				continue;
			}
			const header = l.match(/^_+\s+(\S.+?)\s+_+$/);
			if (header) {
				out.push({
					name: header[1].trim(),
					snippet: lines.slice(i, i + SNIPPET_LINES).join("\n"),
				});
			}
		}
	}

	if (out.length === 0) {
		// Tolerant fallback: surface first 40 lines of stderr (or stdout if stderr is empty).
		const source = stderr.trim().length > 0 ? stderr : stdout;
		const tail = source.split(/\r?\n/).slice(0, 40).join("\n").trim();
		if (tail.length > 0) {
			out.push({ name: "(unparsed test output)", snippet: tail });
		}
	}

	return out;
}

function extractSummary(stdout: string, stderr: string): string {
	const combined = `${stdout}\n${stderr}`;
	const lines = combined.split(/\r?\n/).filter((l) => l.trim().length > 0);
	// Heuristic: pull out the most useful tail of the output. Most runners print
	// a summary like `Tests: 3 failed, 5 passed` near the end.
	const candidates = lines.slice(-10);
	for (const l of candidates) {
		if (/(passed|failed|error|test|spec)/i.test(l)) {
			return l.trim();
		}
	}
	return candidates[candidates.length - 1]?.trim() ?? "(no summary)";
}

const STREAM_CHUNK_BUDGET = 256 * 1024;

export const runTestsTool: ToolSpec = {
	name: "run_tests",
	description:
		"Detect and run the workspace's test suite (vitest/jest/mocha/pytest). Returns exit code, a summary line, and a parsed list of failures with snippets. Streams output progressively to the chat.",
	schema: {
		type: "object",
		properties: {
			pattern: {
				type: "string",
				description: "Optional test-name pattern (passed to the runner's filter flag).",
			},
			bail: {
				type: "boolean",
				description: "When true, stop on first failure.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx, callCtx): Promise<RunTestsResult> {
		if (!isRunTestsArgs(args)) throw new Error("run_tests: invalid args");
		const safe = (args ?? {}) as RunTestsArgs;
		const detection = await detectRunner(ctx);
		if (detection.kind === "none") {
			return {
				exitCode: 0,
				summary:
					"No test runner detected (looked for vitest/jest/mocha in package.json, pytest.ini, pyproject.toml).",
				failures: [],
				runner: "none",
			};
		}
		const cmd = detection.buildCommand(safe);

		const emit = ctx.emitToolProgress;
		const callId = callCtx?.callId;
		let streamed = 0;
		const onChunk =
			emit && callId
				? (chunk: string) => {
						if (streamed >= STREAM_CHUNK_BUDGET) return;
						const room = STREAM_CHUNK_BUDGET - streamed;
						const trimmed = chunk.length > room ? chunk.slice(0, room) : chunk;
						streamed += trimmed.length;
						emit(callId, trimmed);
					}
				: undefined;

		const res = await ctx.exec(cmd, {
			timeoutMs: 5 * 60_000,
			...(onChunk ? { onChunk } : {}),
		});
		const failures = parseFailures(detection.kind, res.stdout, res.stderr);
		const summary = extractSummary(res.stdout, res.stderr);
		return {
			exitCode: res.exitCode,
			summary,
			failures,
			runner: detection.kind,
		};
	},
};
