// R8-B: codebase_deep_search tool — agent-callable deep semantic search with
// k=20 and rerank=true. Pairs with the `@codebase` webview mention (same
// host-side machinery, different entry point).
//
// TODO(r8-merge): R8-A owns `packages/tools/src/registry.ts` and
// `packages/tools/src/index.ts`. After R8-merge, append this tool to
// `builtinTools` in registry.ts so the conductor picks it up. Until then the
// tool spec is exported but not registered.

import type { ToolSpec } from "@iom/shared";

interface DeepSearchArgs {
	readonly query: string;
	readonly k?: number;
	readonly extensions?: readonly string[];
	readonly rerank?: boolean;
}

function isDeepSearchArgs(v: unknown): v is DeepSearchArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DeepSearchArgs;
	if (typeof a.query !== "string") return false;
	if (a.k !== undefined && typeof a.k !== "number") return false;
	if (a.rerank !== undefined && typeof a.rerank !== "boolean") return false;
	if (a.extensions !== undefined) {
		if (!Array.isArray(a.extensions)) return false;
		for (const e of a.extensions) if (typeof e !== "string") return false;
	}
	return true;
}

const DEFAULT_K = 20;
const MAX_K = 50;
const SNIPPET_CHAR_CAP = 600;

/**
 * `codebase_deep_search` — broader, higher-precision counterpart to
 * `code_semantic_search`. Defaults to k=20 (vs k=8) and applies the
 * LLM-as-reranker by default when the active provider is reachable. Use this
 * when you need the BEST answer to a semantic query (e.g. "which file owns
 * the auth flow?") and are willing to pay a slightly larger context budget.
 *
 * Result format mirrors `code_semantic_search`: one human-readable block per
 * hit with the file path, line range, score, and a snippet.
 */
export const codebaseDeepSearchTool: ToolSpec = {
	name: "codebase_deep_search",
	description:
		"Deeper semantic search over the local codebase index (k=20, LLM-reranked by default). Use this when you need a broader candidate set than `code_semantic_search` or when the first-pass results were off-target. Falls back gracefully to TF-IDF when no embedder API key is configured.",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description: "Natural-language description of what you're looking for.",
			},
			k: {
				type: "integer",
				description: `Max results. Default ${DEFAULT_K}, max ${MAX_K}.`,
			},
			extensions: {
				type: "array",
				description: "Optional list of file extensions to restrict the search to (e.g. ['ts','tsx']).",
				items: { type: "string" },
			},
			rerank: {
				type: "boolean",
				description:
					"Whether to LLM-rerank the top-N candidates. Defaults to true; set false to avoid an extra LLM call.",
			},
		},
		required: ["query"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isDeepSearchArgs(args)) {
			throw new Error("codebase_deep_search: invalid args");
		}
		if (!ctx.codebaseIndex) {
			return (
				"codebase_deep_search: no index available. " +
				"Run /reindex from the chat panel to build one, or check that a workspace is open."
			);
		}
		const k = Math.min(Math.max(args.k ?? DEFAULT_K, 1), MAX_K);
		// NB: the `rerank` option on the search-provider interface is forwarded
		// host-side from the chat-panel; agent-side we just pass through `k` +
		// extensions. The host applies its configured reranker around this
		// call when `iom.codebaseIndex.rerank` is on.
		const hits = await ctx.codebaseIndex.query(args.query, {
			k,
			...(args.extensions ? { filter: { extensions: args.extensions } } : {}),
		});
		if (hits.length === 0) {
			return `codebase_deep_search: no matches for "${args.query}". The index may be empty — try /reindex.`;
		}
		const blocks = hits.map((h, i) => {
			const snippet =
				h.content.length > SNIPPET_CHAR_CAP
					? `${h.content.slice(0, SNIPPET_CHAR_CAP)}\n... (truncated)`
					: h.content;
			return [
				`### ${i + 1}. ${h.filePath}:${h.startLine}-${h.endLine}  (score=${h.score.toFixed(3)})`,
				"```",
				snippet,
				"```",
			].join("\n");
		});
		return blocks.join("\n\n");
	},
};
