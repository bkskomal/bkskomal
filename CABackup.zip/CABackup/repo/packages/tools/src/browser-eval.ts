// TODO(r2-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import type { ToolSpec } from "@iom/shared";
import { getOrLaunch } from "./browser-state";

interface BrowserEvalArgs {
	readonly expression: string;
}

function isBrowserEvalArgs(v: unknown): v is BrowserEvalArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as BrowserEvalArgs;
	return typeof a.expression === "string";
}

interface BrowserEvalResult {
	readonly result: string;
	readonly truncated: boolean;
}

/** 64KB cap on the serialized result string. */
const MAX_RESULT_BYTES = 64 * 1024;

function safeSerialize(value: unknown): string {
	if (value === undefined) return "undefined";
	try {
		return JSON.stringify(value, null, 2) ?? String(value);
	} catch {
		// Cycles, BigInt, etc. — fall back to a tagged string.
		return `[unserializable: ${typeof value}]`;
	}
}

export const browserEvalTool: ToolSpec = {
	name: "browser_eval",
	description:
		"DANGEROUS: runs arbitrary JavaScript inside the active browser page via page.evaluate. " +
		"The expression executes in the page's origin and can read cookies, localStorage, DOM, etc. " +
		"Approval required on every call. Result is JSON-serialized and truncated to 64KB.",
	schema: {
		type: "object",
		properties: {
			expression: {
				type: "string",
				description:
					"JavaScript expression or function body to evaluate in the page context. " +
					"The return value is serialized with JSON.stringify.",
			},
		},
		required: ["expression"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isBrowserEvalArgs(args)) return {};
		const snippet =
			args.expression.length > 500 ? `${args.expression.slice(0, 500)}\n…` : args.expression;
		return {
			note: `This runs arbitrary JS in the browser context — it can read cookies, localStorage, the DOM, and exfiltrate data. Review the snippet carefully.\n\nExpression:\n${snippet}`,
		};
	},
	async handler(args): Promise<BrowserEvalResult> {
		if (!isBrowserEvalArgs(args)) throw new Error("browser_eval: invalid args");
		const { page } = await getOrLaunch();
		// page.evaluate accepts a string and treats it as an expression in the
		// page context. We deliberately don't wrap it so the agent can pass
		// either an expression ("document.title") or an IIFE.
		const raw = await page.evaluate<unknown>(args.expression);
		const serialized = safeSerialize(raw);
		const truncated = serialized.length > MAX_RESULT_BYTES;
		return {
			result: truncated ? serialized.slice(0, MAX_RESULT_BYTES) : serialized,
			truncated,
		};
	},
};
