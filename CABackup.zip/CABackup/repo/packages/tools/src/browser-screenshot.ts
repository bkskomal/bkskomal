// TODO(r2-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import { type ToolSpec, detectModelQuirks } from "@iom/shared";
import { getOrLaunch } from "./browser-state";

interface BrowserScreenshotArgs {
	readonly fullPage?: boolean;
	readonly selector?: string;
}

function isBrowserScreenshotArgs(v: unknown): v is BrowserScreenshotArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as BrowserScreenshotArgs;
	if (a.fullPage !== undefined && typeof a.fullPage !== "boolean") return false;
	if (a.selector !== undefined && typeof a.selector !== "string") return false;
	return true;
}

interface BrowserScreenshotResult {
	readonly dataUrl: string;
	readonly downscaled: boolean;
	/**
	 * 2026-05-30: when the active model isn't vision-capable, this field
	 * carries a text warning explaining the model can't see the image AND
	 * pointing at concrete fallback paths (browser_eval, re-read file).
	 * Vision-capable models won't see this field. Critical for preventing
	 * the "took a screenshot, claimed Done without looking" failure mode
	 * surfaced in a live trace: model captured a clearly-broken page,
	 * never noticed because it can't see images, said "Done".
	 */
	readonly visionWarning?: string;
	/**
	 * 2026-05-30: auto-extracted DOM text from the page when the model
	 * is non-vision and a full-page (not selector-targeted) screenshot
	 * was taken. Gives the model the SAME information a human would read
	 * from the page, but as text it can actually process. Catches the
	 * "page rendered literal `\\n` instead of newlines" failure mode the
	 * vision warning alone couldn't — the warning told the model what
	 * to do; this just hands it the answer.
	 *
	 * Capped at 2000 chars to keep token cost bounded; the model can
	 * call browser_eval directly for more.
	 */
	readonly pageText?: string;
	/**
	 * 2026-06-01: present when fullPage exceeded the vision-token budget
	 * and got clipped. Carries the dimensions actually captured vs. the
	 * full scrollHeight, so the model knows there's more content below
	 * and can re-screenshot with a selector or scroll-and-capture.
	 */
	readonly truncated?: {
		readonly capturedHeight: number;
		readonly fullScrollHeight: number;
	};
}

/** 4MB cap on the returned base64 PNG (approx 3MB raw). */
const MAX_BYTES = 4 * 1024 * 1024;
/** Downscale target when the raw screenshot blows the cap. */
const DOWNSCALE_WIDTH = 1280;
const DOWNSCALE_HEIGHT = 800;
/**
 * 2026-06-01: hard pixel budget for vision-capable captures. K2.6's MoonViT
 * (and most ViT-style image tokenizers) cost roughly proportional to pixel
 * count — a 1280×10000 fullPage screenshot lands ~200k tokens BEFORE
 * accounting for any prior context. Live-bug: a fullPage capture of an
 * E-commerce page hit 950k requested tokens vs a 262k cap. Clipping the
 * capture to 1280×4096 keeps a single screenshot at ~80k vision tokens,
 * leaving 180k for the rest of the turn (history, system prompt, tools).
 */
const FULLPAGE_MAX_WIDTH = 1280;
const FULLPAGE_MAX_HEIGHT = 4096;

function base64ToBytes(b64: string): number {
	// Each 4 base64 chars = 3 bytes; padding subtracts up to 2.
	const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
	return Math.floor((b64.length * 3) / 4) - padding;
}

export const browserScreenshotTool: ToolSpec = {
	name: "browser_screenshot",
	description:
		"Capture a PNG screenshot of the current browser page (or a single element via CSS selector) " +
		"and return it as a base64 data URL. fullPage captures are clipped to 1280×4096px (a " +
		"`truncated` field reports the full scrollHeight when this fires — re-call with a selector " +
		"or scroll to see lower content). Oversize captures are retried at 1280×800 with fullPage disabled.",
	schema: {
		type: "object",
		properties: {
			fullPage: {
				type: "boolean",
				description: "Capture the entire scrollable page rather than the viewport.",
			},
			selector: {
				type: "string",
				description: "CSS selector — when set, screenshots just that element.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<BrowserScreenshotResult> {
		if (!isBrowserScreenshotArgs(args)) throw new Error("browser_screenshot: invalid args");
		const { page } = await getOrLaunch();

		// 2026-06-01: when fullPage is requested without a selector, pre-
		// measure scrollHeight and use an explicit `clip` rectangle instead
		// of fullPage:true so we can hard-cap the captured height. Without
		// this, vision-token cost is unbounded — a tall page produces an
		// image too large to fit in any model's context. Width comes from
		// FULLPAGE_MAX_WIDTH so layout is captured at a sensible breakpoint.
		let truncated: { capturedHeight: number; fullScrollHeight: number } | undefined;
		const capture = async (full: boolean): Promise<string> => {
			if (args.selector) {
				const el = await page.$(args.selector);
				if (!el) throw new Error(`browser_screenshot: selector not found: ${args.selector}`);
				return el.screenshot({ encoding: "base64", type: "png" });
			}
			if (full) {
				// Set the viewport to our capture width so the document lays
				// out at a stable breakpoint regardless of the user's screen.
				await page.setViewport({ width: FULLPAGE_MAX_WIDTH, height: 800 });
				const scrollHeight = await page
					.evaluate<number>(
						"(function(){var d=document.documentElement,b=document.body;return Math.max(d?d.scrollHeight:0,b?b.scrollHeight:0,d?d.offsetHeight:0,b?b.offsetHeight:0,800)})()",
					)
					.catch(() => FULLPAGE_MAX_HEIGHT);
				const safeHeight = Math.min(scrollHeight, FULLPAGE_MAX_HEIGHT);
				if (scrollHeight > FULLPAGE_MAX_HEIGHT) {
					truncated = { capturedHeight: safeHeight, fullScrollHeight: scrollHeight };
				}
				return page.screenshot({
					encoding: "base64",
					type: "png",
					clip: { x: 0, y: 0, width: FULLPAGE_MAX_WIDTH, height: safeHeight },
				});
			}
			return page.screenshot({ encoding: "base64", fullPage: false, type: "png" });
		};

		let b64 = await capture(args.fullPage === true);
		let downscaled = false;
		if (base64ToBytes(b64) > MAX_BYTES) {
			// Shrink viewport and re-capture at the smaller size with fullPage off.
			// Puppeteer doesn't expose true image resampling, so we approximate by
			// reducing the source viewport — adequate for "agent can see what's
			// going on" use cases without dragging in sharp/jimp.
			await page.setViewport({ width: DOWNSCALE_WIDTH, height: DOWNSCALE_HEIGHT });
			b64 = await capture(false);
			downscaled = true;
			// A viewport-only re-capture is no longer "truncated fullPage".
			truncated = undefined;
		}

		// Vision-blindness fallback. When the active model is text-only,
		// taking a screenshot is theatre — the model gets back a base64
		// blob it can't interpret and infers success from the tool not
		// throwing. Inject a clear text warning + concrete next-step
		// suggestions so the model actually verifies the page state.
		const modelId = ctx.activeModelId;
		const canSee = modelId ? detectModelQuirks(modelId).supportsVision : true;
		const visionWarning = canSee ? undefined : buildVisionWarning(modelId, args.selector, page.url());

		// 2026-05-30: ALWAYS auto-extract the DOM text on full-page
		// screenshots, regardless of model vision capability. Reasons:
		//   1. Even vision-capable models benefit — DOM text is cheaper
		//      to process than image tokens AND deterministic (no OCR
		//      mistakes).
		//   2. Until the screenshot is packed as a multimodal content
		//      block in the API request (separate architectural commit),
		//      vision-capable models also can't see the data-URL string
		//      we return — pageText is the only thing they can actually
		//      read from this tool result today.
		//   3. The cost is ~50ms of page.evaluate. Bounded.
		// Best-effort: silent on failure (CSP-restricted pages, eval-not-
		// supported, page mid-navigation).
		let pageText: string | undefined;
		if (!args.selector) {
			try {
				const raw = await page.evaluate<unknown>(
					"(function(){var b=document.body;if(!b)return '';return b.innerText.slice(0,2000)})()",
				);
				if (typeof raw === "string" && raw.length > 0) pageText = raw;
			} catch {
				/* best-effort */
			}
		}

		return {
			dataUrl: `data:image/png;base64,${b64}`,
			downscaled,
			...(visionWarning ? { visionWarning } : {}),
			...(pageText !== undefined ? { pageText } : {}),
			...(truncated ? { truncated } : {}),
		};
	},
};

function buildVisionWarning(
	modelId: string | undefined,
	selector: string | undefined,
	pageUrl: string,
): string {
	const target = selector ? `the element matching \`${selector}\`` : `the page at ${pageUrl}`;
	const modelTag = modelId ? ` (\`${modelId}\`)` : "";
	return [
		`Heads-up: the active model${modelTag} is text-only and can't process the image bytes directly.`,
		"",
		selector
			? `To inspect ${target}, use ONE of:`
			: `To inspect ${target}, look at the **\`pageText\`** field in this tool result — it has the visible DOM text. If pageText looks garbled (literal \`\\n\` characters, mojibake, raw HTML markup), the source file is broken; re-read it and rewrite with proper newlines/encoding. Other options:`,
		"",
		"  1. `browser_eval` with `document.body.innerText.slice(0, 800)` — visible text the user would read.",
		"  2. `browser_eval` with a specific selector like `document.querySelector('h1').innerText` — confirms specific content.",
		"  3. Re-read the source file (`read_file`) and check its actual content.",
		"",
		"Don't claim the page is fixed without checking at least one of these.",
	].join("\n");
}
