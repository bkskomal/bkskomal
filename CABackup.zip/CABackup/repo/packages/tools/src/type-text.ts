// TODO(r8-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts (owned by R8-A).
// R8-D: computer-use type_text tool — synthesizes keystrokes for a literal
// string. Optional per-keystroke delay (ms) tunes the typing speed; useful
// for forms that throttle paste or do per-keystroke validation.

import type { ToolSpec } from "@iom/shared";
import { loadNutJs } from "./nut-loader";

interface TypeTextArgs {
	readonly text: string;
	readonly delay?: number;
}

interface TypeTextResult {
	readonly typed: true;
	readonly length: number;
}

function isTypeTextArgs(v: unknown): v is TypeTextArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as TypeTextArgs;
	if (typeof a.text !== "string") return false;
	if (a.delay !== undefined && (typeof a.delay !== "number" || a.delay < 0)) return false;
	return true;
}

export const typeTextTool: ToolSpec<TypeTextArgs, TypeTextResult> = {
	name: "type_text",
	description:
		"Type a literal string at the current keyboard focus, character-by-character. Optional `delay` (ms) controls per-keystroke pause. Approval-gated.",
	schema: {
		type: "object",
		properties: {
			text: { type: "string", description: "Literal text to type. Newlines emit Enter." },
			delay: {
				type: "integer",
				description: "Optional per-keystroke delay in milliseconds (0–500). Default 0.",
			},
		},
		required: ["text"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<TypeTextResult> {
		if (!isTypeTextArgs(args)) throw new Error("type_text: invalid args");
		const api = await loadNutJs();
		if (args.delay !== undefined && api.keyboard.config) {
			api.keyboard.config.autoDelayMs = Math.min(500, Math.max(0, args.delay));
		}
		await api.keyboard.type(args.text);
		return { typed: true, length: args.text.length };
	},
};
