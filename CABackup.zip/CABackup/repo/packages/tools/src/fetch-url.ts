import type { ToolSpec } from "@iom/shared";

interface FetchArgs {
	readonly url: string;
	readonly max_bytes?: number;
	readonly timeout_ms?: number;
}

function isFetchArgs(v: unknown): v is FetchArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as FetchArgs;
	if (typeof a.url !== "string") return false;
	if (a.max_bytes !== undefined && typeof a.max_bytes !== "number") return false;
	if (a.timeout_ms !== undefined && typeof a.timeout_ms !== "number") return false;
	return true;
}

interface FetchResult {
	readonly url: string;
	readonly status: number;
	readonly contentType: string;
	readonly body: string;
	readonly truncated: boolean;
}

const DEFAULT_MAX_BYTES = 200_000;
const ABSOLUTE_MAX_BYTES = 2_000_000;
const DEFAULT_TIMEOUT_MS = 15_000;

export const fetchUrlTool: ToolSpec = {
	name: "fetch_url",
	description:
		"HTTP GET a URL and return the body as text. Approval-gated to prevent SSRF / unintended outbound calls. Body is truncated past max_bytes.",
	schema: {
		type: "object",
		properties: {
			url: { type: "string", description: "Full URL including scheme (https://...)." },
			max_bytes: {
				type: "integer",
				description: `Max bytes to read from the body. Default ${DEFAULT_MAX_BYTES}, max ${ABSOLUTE_MAX_BYTES}.`,
			},
			timeout_ms: {
				type: "integer",
				description: `Request timeout in ms. Default ${DEFAULT_TIMEOUT_MS}.`,
			},
		},
		required: ["url"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args): Promise<FetchResult> {
		if (!isFetchArgs(args)) throw new Error("fetch_url: invalid args");

		let parsedUrl: URL;
		try {
			parsedUrl = new URL(args.url);
		} catch {
			throw new Error(`fetch_url: invalid URL: ${args.url}`);
		}
		if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
			throw new Error(`fetch_url: only http/https supported, got ${parsedUrl.protocol}`);
		}

		const cap = Math.min(args.max_bytes ?? DEFAULT_MAX_BYTES, ABSOLUTE_MAX_BYTES);
		const ctrl = new AbortController();
		const timer = setTimeout(() => ctrl.abort(), args.timeout_ms ?? DEFAULT_TIMEOUT_MS);

		try {
			const response = await fetch(parsedUrl.toString(), {
				method: "GET",
				signal: ctrl.signal,
				redirect: "follow",
			});

			const contentType = response.headers.get("content-type") ?? "";
			const buf = await response.arrayBuffer();
			const truncated = buf.byteLength > cap;
			const sliced = truncated ? buf.slice(0, cap) : buf;
			const decoder = new TextDecoder("utf-8", { fatal: false });
			const body = decoder.decode(sliced);

			return {
				url: parsedUrl.toString(),
				status: response.status,
				contentType,
				body,
				truncated,
			};
		} catch (err) {
			if (err instanceof Error && err.name === "AbortError") {
				throw new Error("fetch_url: request timed out");
			}
			throw new Error(`fetch_url: ${err instanceof Error ? err.message : String(err)}`);
		} finally {
			clearTimeout(timer);
		}
	},
};
