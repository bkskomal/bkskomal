// TODO(r2-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import type { ToolSpec } from "@iom/shared";
import { getOrLaunch } from "./browser-state";

interface BrowserNavigateArgs {
	readonly url: string;
}

function isBrowserNavigateArgs(v: unknown): v is BrowserNavigateArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as BrowserNavigateArgs;
	return typeof a.url === "string";
}

interface BrowserNavigateResult {
	readonly title: string;
	readonly url: string;
	readonly statusCode: number | null;
}

export const browserNavigateTool: ToolSpec = {
	name: "browser_navigate",
	description:
		"Navigate the existing browser session to a new URL. The session must already be open via " +
		"browser_open. No approval required because the user already consented to the browser window.",
	schema: {
		type: "object",
		properties: {
			url: { type: "string", description: "Full URL including scheme (http:// or https://)." },
		},
		required: ["url"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args): Promise<BrowserNavigateResult> {
		if (!isBrowserNavigateArgs(args)) throw new Error("browser_navigate: invalid args");
		let parsed: URL;
		try {
			parsed = new URL(args.url);
		} catch {
			throw new Error(`browser_navigate: invalid URL: ${args.url}`);
		}
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
			throw new Error(`browser_navigate: only http/https supported, got ${parsed.protocol}`);
		}

		// Reuses the singleton; if the user never approved browser_open this
		// will still launch — that's intentional fallback, but typical flow is
		// open-first, navigate-after.
		const { page } = await getOrLaunch();
		const response = await page.goto(parsed.toString(), {
			waitUntil: "domcontentloaded",
			timeout: 30_000,
		});
		const title = await page.title();
		return {
			title,
			url: page.url(),
			statusCode: response ? response.status() : null,
		};
	},
};
