import type { ToolSpec } from "@iom/shared";

interface FindDefinitionArgs {
	readonly path: string;
	readonly line: number;
	readonly character?: number;
}

function isFindDefinitionArgs(v: unknown): v is FindDefinitionArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as FindDefinitionArgs;
	if (typeof a.path !== "string") return false;
	if (typeof a.line !== "number") return false;
	if (a.character !== undefined && typeof a.character !== "number") return false;
	return true;
}

const SNIPPET_CHAR_CAP = 300;

/**
 * `find_definition` — wraps `vscode.executeDefinitionProvider`. Symmetric to
 * `find_references`; returns the declaration site(s) for the symbol at the
 * given file position. Most languages return exactly one hit, but overloaded
 * symbols (TypeScript declaration merging, C++ overloads) can produce more
 * than one — we return them all and let the agent pick.
 */
export const findDefinitionTool: ToolSpec = {
	name: "find_definition",
	description:
		"Find the declaration site for the symbol at a given file position using the editor's language server. Use this when the agent needs to read a function's source after seeing it called. Returns up to N {path, line, snippet} entries. Falls back gracefully when no language server is attached.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "File containing the symbol reference. Relative to workspace root, or absolute.",
			},
			line: {
				type: "integer",
				description: "1-based line number where the symbol appears.",
			},
			character: {
				type: "integer",
				description: "Optional 0-based column. Defaults to 0 (start of line).",
			},
		},
		required: ["path", "line"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isFindDefinitionArgs(args)) {
			throw new Error("find_definition: invalid args, expected { path, line, character? }");
		}
		if (!ctx.symbols) {
			return "find_definition: no language-server bridge available in this host.";
		}
		const character = args.character ?? 0;
		const hits = await ctx.symbols.findDefinition(args.path, args.line, character);
		if (hits.length === 0) {
			return `find_definition: no definition found for ${args.path}:${args.line}.`;
		}
		const blocks = hits.map((h, i) => {
			const snippet =
				h.snippet.length > SNIPPET_CHAR_CAP ? `${h.snippet.slice(0, SNIPPET_CHAR_CAP)}…` : h.snippet;
			return `${i + 1}. ${h.path}:${h.line}\n   ${snippet.replace(/\n/g, "\n   ")}`;
		});
		return blocks.join("\n");
	},
};
