// R6-A: `consolidate_memory` tool.
//
// Triggers a memory-consolidation pass over older sessions. The actual
// `consolidateOldSessions()` implementation lives in
// `@iom/extension-host/memory-consolidator`; this tool's handler is a thin
// shim so non-VS Code hosts can wire their own implementation against the
// same name. Approval is `prompt` because the action writes new entries to
// `<workspace>/.iom/facts.json` (persistent across sessions) and may take
// non-trivial model time depending on the volume of old sessions.

import type { ToolSpec } from "@iom/shared";

interface ConsolidateMemoryArgs {
	/** Sessions older than this many days are scanned. Defaults to 30. */
	readonly daysOld?: number;
	/** Cap on sessions processed in a single run. Defaults to 20. */
	readonly maxSessions?: number;
}

function isConsolidateMemoryArgs(v: unknown): v is ConsolidateMemoryArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as { daysOld?: unknown; maxSessions?: unknown };
	if (a.daysOld !== undefined && typeof a.daysOld !== "number") return false;
	if (a.maxSessions !== undefined && typeof a.maxSessions !== "number") return false;
	return true;
}

export const consolidateMemoryTool: ToolSpec = {
	name: "consolidate_memory",
	description:
		'Walk older sessions (older than `daysOld`, default 30) and promote 1-3 "lessons learned" per session to `<workspace>/.iom/facts.json`. Existing facts are deduped (case-insensitive). Use this when the user wants to compress long-term project knowledge from past chats into the persistent facts store.',
	schema: {
		type: "object",
		properties: {
			daysOld: {
				type: "number",
				description: "Sessions older than this many days are scanned. Defaults to 30.",
			},
			maxSessions: {
				type: "number",
				description: "Cap on sessions processed in a single call. Defaults to 20.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isConsolidateMemoryArgs(args)) return {};
		const days = args.daysOld ?? 30;
		const cap = args.maxSessions ?? 20;
		return {
			note: `Will scan up to ${cap} session(s) older than ${days} day(s) and append distilled lessons to .iom/facts.json (idempotent — duplicates are skipped).`,
		};
	},
	async handler(args, _ctx, _callCtx): Promise<unknown> {
		if (!isConsolidateMemoryArgs(args)) {
			throw new Error("consolidate_memory: invalid args");
		}
		// The host bridge listens for `tool_call.name === "consolidate_memory"`
		// and dispatches the actual `consolidateOldSessions()` pass. From the
		// tool's vantage point we just confirm the request was queued so the
		// agent transcript records the intent.
		const days = args.daysOld ?? 30;
		return {
			ok: true,
			note: `Memory consolidation queued — scanning sessions older than ${days} day(s).`,
		};
	},
};
