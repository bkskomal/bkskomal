import { promises as fs } from "node:fs";
import * as path from "node:path";
// TODO(r4-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface ListSnippetsArgs {
	readonly query?: string;
}

function isListSnippetsArgs(v: unknown): v is ListSnippetsArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as ListSnippetsArgs;
	if (a.query !== undefined && typeof a.query !== "string") return false;
	return true;
}

interface SnippetEntry {
	readonly name: string;
	readonly description: string;
}

interface ListSnippetsResult {
	readonly snippets: readonly SnippetEntry[];
}

const VALID_NAME = /^[a-zA-Z0-9_-]+$/;

/**
 * R4-C: list snippet entries stored under `<workspace>/.iom/snippets/*.md`.
 * The H1 line of each file is its description; the name is the filename minus
 * `.md`. Filter with an optional `query` substring (case-insensitive).
 */
export const listSnippetsTool: ToolSpec = {
	name: "list_snippets",
	description:
		"List user-defined snippets stored under `<workspace>/.iom/snippets/*.md`. Returns name + description per snippet. Optional `query` substring filter (case-insensitive).",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description: "Optional case-insensitive substring filter on name or description.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<ListSnippetsResult> {
		if (!isListSnippetsArgs(args)) throw new Error("list_snippets: invalid args");
		const root = ctx.workspaceRoot();
		if (!root) return { snippets: [] };
		const dir = path.join(root, ".iom", "snippets");
		let entries: string[];
		try {
			entries = await fs.readdir(dir);
		} catch {
			return { snippets: [] };
		}
		const all: SnippetEntry[] = [];
		for (const entry of entries) {
			if (!entry.toLowerCase().endsWith(".md")) continue;
			const name = entry.slice(0, -3);
			if (!VALID_NAME.test(name)) continue;
			const abs = path.join(dir, entry);
			let raw: string;
			try {
				const stat = await fs.stat(abs);
				if (!stat.isFile()) continue;
				raw = await fs.readFile(abs, "utf-8");
			} catch {
				continue;
			}
			all.push({ name, description: extractDescription(raw, name) });
		}
		all.sort((a, b) => a.name.localeCompare(b.name));
		const q = args?.query?.trim().toLowerCase();
		const filtered = q
			? all.filter((s) => s.name.toLowerCase().includes(q) || s.description.toLowerCase().includes(q))
			: all;
		return { snippets: filtered };
	},
};

function extractDescription(raw: string, fallback: string): string {
	const lines = raw.split(/\r?\n/);
	for (const line of lines) {
		if (line.trim().length === 0) continue;
		const m = /^#\s+(.+?)\s*$/.exec(line);
		if (m) return m[1];
		break;
	}
	return fallback;
}
