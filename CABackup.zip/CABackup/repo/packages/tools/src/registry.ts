import type { ToolSpec } from "@iom/shared";
// 2026-05-27: ask the user a multiple-choice clarifying question.
import { askUserTool } from "./ask-user";
// 2026-06-29: batched sibling for START-of-task disambiguation.
import { askUserBatchTool } from "./ask-user-batch";
// 2026-05-23: non-blocking process spawn for dev servers + watchers.
import {
	listBackgroundProcessesTool,
	startBackgroundProcessTool,
	stopBackgroundProcessTool,
} from "./background-process";
// 2026-05-29: batch_file_edit — atomic cross-file find-and-replace.
import { batchFileEditTool } from "./batch-file-edit";
import { browserCloseTool } from "./browser-close";
import { browserEvalTool } from "./browser-eval";
import { browserNavigateTool } from "./browser-navigate";
import { browserOpenTool } from "./browser-open";
import { browserScreenshotTool } from "./browser-screenshot";
import { codeSemanticSearchTool } from "./code-semantic-search";
// R8-B: codebase_deep_search — first-class @codebase mention backing tool.
import { codebaseDeepSearchTool } from "./codebase-deep-search";
// R6-A: propose_plan + consolidate_memory.
import { consolidateMemoryTool } from "./consolidate-memory";
// R6-E: debug bridge tools.
import { debugEvaluateTool } from "./debug-evaluate";
import { debugListBreakpointsTool } from "./debug-list-breakpoints";
import { debugRemoveBreakpointTool } from "./debug-remove-breakpoint";
import { debugScopesTool } from "./debug-scopes";
import { debugSetBreakpointTool } from "./debug-set-breakpoint";
import { debugStackFramesTool } from "./debug-stack-frames";
import { debugVariablesTool } from "./debug-variables";
// R6-B: notebook cell tools.
import { deleteNotebookCellTool } from "./delete-notebook-cell";
import { editNotebookCellTool } from "./edit-notebook-cell";
import { execTool } from "./exec";
// 2026-05-30: OCR for image files / data URLs (companion to
// browser_screenshot's pageText).
import { extractImageTextTool } from "./extract-image-text";
import { fetchUrlTool } from "./fetch-url";
// APPENDED in R3-A — symbol-aware retrieval tools backed by the editor's LSP.
import { findDefinitionTool } from "./find-definition";
import { findReferencesTool } from "./find-references";
// R4-B: get_diagnostics — LSP diagnostics snapshot.
import { getDiagnosticsTool } from "./get-diagnostics";
// APPENDED in R3-E — gh issue read/comment.
import { ghIssueCommentTool } from "./gh-issue-comment";
import { ghIssueReadTool } from "./gh-issue-read";
import { gitCommitTool } from "./git-commit";
import { gitDiffTool } from "./git-diff";
import { gitOpenPrTool } from "./git-open-pr";
import { gitStatusTool } from "./git-status";
import { grepSearchTool } from "./grep-search";
// R5-A: inline-completion telemetry tool.
import { inlineCompletionStatsTool } from "./inline-completion-stats";
// R6-B: insert_notebook_cell.
import { insertNotebookCellTool } from "./insert-notebook-cell";
// R8-D: computer-use key_press.
import { keyPressTool } from "./key-press";
import { listDirTool } from "./list-dir";
// R5-B: knowledge tools.
import { listKnowledgeTool } from "./list-knowledge";
// APPENDED in R4-C — snippet library.
import { listSnippetsTool } from "./list-snippets";
// R8-E: load_skill — lazy-load a skill's full body.
import { loadSkillTool } from "./load-skill";
// R8-D: computer-use mouse_click + mouse_move.
import { mouseClickTool } from "./mouse-click";
import { mouseMoveTool } from "./mouse-move";
// R8-E: multi_cursor_edit — batch identical edits at N positions.
import { multiCursorEditTool } from "./multi-cursor-edit";
// R8-A: predict_next_edit_location — pure-heuristic next-edit estimator.
import { predictNextEditLocationTool } from "./predict-next-edit";
import { proposePlanTool } from "./propose_plan";
import { readFileTool } from "./read-file";
// R6-B: read_notebook + read_notebook_cell.
import { readNotebookTool } from "./read-notebook";
import { readNotebookCellTool } from "./read-notebook-cell";
import { readSessionArchiveTool } from "./read-session-archive";
import { readSharedNotesTool } from "./read-shared-notes";
import { recallFactsTool } from "./recall-facts";
import { rememberFactTool } from "./remember-fact";
// APPENDED in R3-C — render_diagram (mermaid).
import { renderDiagramTool } from "./render-diagram";
// R8-C: resolve_context_mention — generic @mention resolver tool.
import { resolveContextMentionTool } from "./resolve-context-mention";
// R6-B: run_notebook_cell.
import { runNotebookCellTool } from "./run-notebook-cell";
// R5-D: run_recipe — sequence saved multi-step workflows.
import { runRecipeTool } from "./run-recipe";
import { runTestsTool } from "./run-tests";
// APPENDED in R4-C — save_snippet.
import { saveSnippetTool } from "./save-snippet";
// R8-D: computer-use screenshot.
import { screenshotTool } from "./screenshot";
// R5-C: search_conversations — cross-session semantic search.
import { searchConversationsTool } from "./search-conversations";
// R5-B: search_knowledge — semantic search of .iom/knowledge.
import { searchKnowledgeTool } from "./search-knowledge";
// R5-D: set_persona — agent can switch persona mid-task.
import { setPersonaTool } from "./set-persona";
// Lets the model change the project root from chat ("set project path to X").
import { setWorkspaceRootTool } from "./set-workspace-root";
// R6-D: smart_apply_patch.
import { smartApplyPatchTool } from "./smart-apply";
import { spawnAgentTool } from "./spawn-agent";
import { spawnParallelAgentsTool } from "./spawn-parallel-agents";
import { startBackgroundTaskTool } from "./start-background-task";
// R6-C: suggest_commit_message.
import { suggestCommitMessageTool } from "./suggest-commit-message";
import { suggestProjectMemoryAdditionTool } from "./suggest-project-memory-addition";
import { symbolsInFileTool } from "./symbols-in-file";
// Agent-managed todo list (Claude-style task tracking).
import { todoWriteTool } from "./todo-write";
// R8-D: computer-use type_text.
import { typeTextTool } from "./type-text";
import { webSearchTool } from "./web-search";
import { workspaceContextTool } from "./workspace-context";
import { writeFileTool } from "./write-file";
import { writeSharedNoteTool } from "./write-shared-note";

export const builtinTools: readonly ToolSpec[] = [
	workspaceContextTool,
	readFileTool,
	writeFileTool,
	listDirTool,
	grepSearchTool,
	codeSemanticSearchTool,
	execTool,
	startBackgroundProcessTool,
	stopBackgroundProcessTool,
	listBackgroundProcessesTool,
	fetchUrlTool,
	webSearchTool,
	spawnAgentTool,
	spawnParallelAgentsTool,
	rememberFactTool,
	recallFactsTool,
	readSessionArchiveTool,
	suggestProjectMemoryAdditionTool,
	writeSharedNoteTool,
	readSharedNotesTool,
	gitStatusTool,
	gitDiffTool,
	gitCommitTool,
	gitOpenPrTool,
	runTestsTool,
	// Cast: handler args are specific (StartBackgroundTaskArgs); the array site
	// uses ToolSpec<unknown, unknown>, which is contravariant in Args.
	startBackgroundTaskTool as ToolSpec<unknown, unknown>,
	browserOpenTool,
	browserNavigateTool,
	browserScreenshotTool,
	browserEvalTool,
	browserCloseTool,
	// 2026-05-30: extract_image_text — Tesseract OCR for non-DOM images.
	extractImageTextTool,
	// APPENDED in R3-A.
	findReferencesTool,
	findDefinitionTool,
	symbolsInFileTool,
	// APPENDED in R3-C.
	// Cast: handler args are specific (RenderDiagramArgs); the array site uses
	// ToolSpec<unknown, unknown>, which is contravariant in Args.
	renderDiagramTool as ToolSpec<unknown, unknown>,
	// APPENDED in R3-E.
	ghIssueReadTool,
	ghIssueCommentTool,
	// R4-B: get_diagnostics.
	getDiagnosticsTool,
	// R4-C: snippet library.
	listSnippetsTool,
	saveSnippetTool,
	// R5-A: inline-completion telemetry.
	inlineCompletionStatsTool,
	// R5-B: knowledge tools.
	listKnowledgeTool,
	searchKnowledgeTool,
	// R5-C: cross-session search.
	searchConversationsTool,
	// R5-D: personas + recipes.
	setPersonaTool,
	runRecipeTool,
	// R6-A: structured Plan v2 + memory consolidation.
	proposePlanTool,
	consolidateMemoryTool,
	// R6-B: notebook tools.
	readNotebookTool,
	readNotebookCellTool,
	editNotebookCellTool,
	insertNotebookCellTool,
	deleteNotebookCellTool,
	runNotebookCellTool,
	// R6-C: AI commit message helper.
	suggestCommitMessageTool,
	// R6-D: smart-apply (three-way merge).
	smartApplyPatchTool,
	// R6-E: debug bridge tools.
	debugStackFramesTool,
	debugEvaluateTool,
	debugScopesTool,
	debugVariablesTool,
	debugListBreakpointsTool,
	debugSetBreakpointTool,
	debugRemoveBreakpointTool,
	// R8-A: Cursor-parity inline completion — predict_next_edit_location.
	predictNextEditLocationTool,
	// R8-B: pluggable embedders — @codebase deep-search backing tool.
	codebaseDeepSearchTool,
	// R8-C: context provider plugin system — generic @mention resolver.
	resolveContextMentionTool as ToolSpec<unknown, unknown>,
	// R8-D: computer-use vision tools.
	screenshotTool as ToolSpec<unknown, unknown>,
	mouseClickTool as ToolSpec<unknown, unknown>,
	mouseMoveTool as ToolSpec<unknown, unknown>,
	typeTextTool as ToolSpec<unknown, unknown>,
	keyPressTool as ToolSpec<unknown, unknown>,
	// R8-E: hooks v2 + skills loader + multi-cursor edits.
	loadSkillTool,
	multiCursorEditTool,
	// 2026-05-29: atomic cross-file batch find-and-replace for refactors.
	batchFileEditTool,
	// Agent-managed todo list (Claude-style task tracking).
	todoWriteTool,
	// 2026-05-27: ask the user a multiple-choice clarifying question.
	askUserTool,
	// 2026-06-29: batched sibling for START-of-task disambiguation.
	askUserBatchTool,
	// Lets the model change the project root from chat.
	setWorkspaceRootTool,
] as const;
