// TODO(r5-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ConversationSearchHit, ToolSpec } from "@iom/shared";

interface SearchConversationsArgs {
	readonly query: string;
	readonly k?: number;
	readonly sessionId?: string;
}

function isSearchConversationsArgs(v: unknown): v is SearchConversationsArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SearchConversationsArgs;
	if (typeof a.query !== "string") return false;
	if (a.k !== undefined && typeof a.k !== "number") return false;
	if (a.sessionId !== undefined && typeof a.sessionId !== "string") return false;
	return true;
}

const DEFAULT_K = 10;
const MAX_K = 50;

/**
 * R5-C: `search_conversations` — semantic search across the message bodies
 * of every past session in the workspace. The agent uses this to surface
 * "have we discussed X before?" without re-deriving the answer from
 * scratch. Returns a structured array (one entry per hit) so the model can
 * cite session+message ids when summarizing.
 */
export const searchConversationsTool: ToolSpec = {
	name: "search_conversations",
	description:
		"Semantic search over the message bodies of every past chat session in this workspace. Returns the top matches with session/message ids, role, snippet, and similarity score. Use this when you need to recall what was decided in an earlier conversation.",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description: "Natural-language description of what you're trying to recall.",
			},
			k: {
				type: "integer",
				description: `Max results. Default ${DEFAULT_K}, max ${MAX_K}.`,
			},
			sessionId: {
				type: "string",
				description: "Optional: restrict the search to a single session id.",
			},
		},
		required: ["query"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<{ hits: readonly ConversationSearchHit[]; message?: string }> {
		if (!isSearchConversationsArgs(args)) {
			throw new Error("search_conversations: invalid args");
		}
		if (!ctx.conversationSearch) {
			return {
				hits: [],
				message:
					"search_conversations: no conversation index available. The host hasn't wired one in yet.",
			};
		}
		const k = Math.min(Math.max(args.k ?? DEFAULT_K, 1), MAX_K);
		const hits = await ctx.conversationSearch.search(args.query, {
			k,
			...(args.sessionId ? { sessionId: args.sessionId } : {}),
		});
		if (hits.length === 0) {
			return {
				hits: [],
				message: `search_conversations: no matches for "${args.query}".`,
			};
		}
		return { hits };
	},
};
