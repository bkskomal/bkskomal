import {
	type SpawnSubAgentsOptions,
	type SubAgentRequest,
	type SubAgentResult,
	type ToolSpec,
	detectModelQuirks,
} from "@iom/shared";

interface TaskSpec {
	readonly task: string;
	readonly systemPromptOverride?: string;
}

interface SpawnParallelArgs {
	readonly tasks: readonly TaskSpec[];
	readonly maxConcurrency?: number;
}

const DEFAULT_CONCURRENCY = 4;
const HARD_CAP_CONCURRENCY = 8;

function isTaskSpec(v: unknown): v is TaskSpec {
	if (typeof v !== "object" || v === null) return false;
	const t = v as TaskSpec;
	if (typeof t.task !== "string") return false;
	if (t.systemPromptOverride !== undefined && typeof t.systemPromptOverride !== "string") {
		return false;
	}
	return true;
}

function isSpawnParallelArgs(v: unknown): v is SpawnParallelArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SpawnParallelArgs;
	if (!Array.isArray(a.tasks)) return false;
	if (!a.tasks.every(isTaskSpec)) return false;
	if (a.maxConcurrency !== undefined && typeof a.maxConcurrency !== "number") return false;
	return true;
}

function summarizeTask(task: string): string {
	const trimmed = task.replace(/\s+/g, " ").trim();
	if (trimmed.length <= 120) return trimmed;
	return `${trimmed.slice(0, 117)}...`;
}

function formatBatch(
	tasks: readonly TaskSpec[],
	results: readonly SubAgentResult[],
	concurrency: number,
): string {
	const header = `Spawned ${results.length} sub-agents (max concurrency ${concurrency}):`;
	const blocks = results.map((r, i) => {
		const taskLine = summarizeTask(tasks[i].task);
		return [
			`[Agent ${i + 1}] ${taskLine}`,
			`  → ${r.toolCalls} tool calls, ${r.iterations} iterations`,
			r.text,
		].join("\n");
	});
	return `${header}\n\n${blocks.join("\n\n")}`;
}

export const spawnParallelAgentsTool: ToolSpec = {
	name: "spawn_parallel_agents",
	description:
		"Spawn multiple isolated sub-agents concurrently to handle independent sub-tasks in parallel. Each sub-agent runs the full tool loop with a fresh conversation. Use when you have N self-contained chunks of research/refactoring that don't depend on each other. Returns a joined summary of every agent's final answer plus stats.",
	// Phase 2.2: same capability gate as `spawn_agent` — fan-out is the
	// extreme case of sub-agent orchestration, so a model that can't
	// reliably handle one sub-agent definitely can't handle several.
	requiredCapability: "spawn-sub-agents",
	schema: {
		type: "object",
		properties: {
			tasks: {
				type: "array",
				description:
					"List of independent sub-tasks to run in parallel. Each entry: { task: string, systemPromptOverride?: string }.",
				items: {
					type: "object",
				},
			},
			maxConcurrency: {
				type: "integer",
				description: `Maximum number of sub-agents to run simultaneously. Default ${DEFAULT_CONCURRENCY}, hard cap ${HARD_CAP_CONCURRENCY}.`,
			},
		},
		required: ["tasks"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isSpawnParallelArgs(args)) throw new Error("spawn_parallel_agents: invalid args");

		if (args.tasks.length === 0) {
			return "Spawned 0 sub-agents: no tasks provided.";
		}

		if (!ctx.spawnSubAgentsParallel) {
			throw new Error(
				"spawn_parallel_agents: parallel sub-agent spawning is not enabled in this host. Increase maxParallelAgents and ensure the host wires HostContext.spawnSubAgentsParallel.",
			);
		}

		// Phase 2.3: clamp the user-requested concurrency against the
		// active model's per-model cap from the quirks registry. A
		// frontier model gets up to 5, open-weight-large gets 3, small
		// and unknown models would normally be filtered out of this
		// tool entirely (capability gate in Phase 2.2) — but if a host
		// has manually re-enabled the tool for a weak model, we still
		// refuse to fan out beyond what the model can handle. The
		// global HARD_CAP_CONCURRENCY remains as a top-level safety net.
		const requested = args.maxConcurrency ?? DEFAULT_CONCURRENCY;
		const modelCap = ctx.activeModelId
			? detectModelQuirks(ctx.activeModelId).parallelConcurrencyCap
			: HARD_CAP_CONCURRENCY;
		const concurrency = Math.max(
			1,
			Math.min(Math.floor(requested), HARD_CAP_CONCURRENCY, modelCap, args.tasks.length),
		);

		const requests: SubAgentRequest[] = args.tasks.map((t) => ({
			task: t.task,
			systemPromptOverride: t.systemPromptOverride,
		}));

		// Tag the batch with a parent agent id so sibling sub-agents share a
		// scratchpad bucket and so the host can expose sub-agent-scoped tools
		// (e.g. write_shared_note) to children but not to the top-level agent.
		const opts: SpawnSubAgentsOptions = {
			parentAgentId: `parent_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
			scope: "sub-agent",
		};
		const results = await ctx.spawnSubAgentsParallel(requests, concurrency, opts);
		return formatBatch(args.tasks, results, concurrency);
	},
};
