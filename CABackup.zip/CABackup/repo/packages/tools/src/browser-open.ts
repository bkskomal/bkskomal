// TODO(r2-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts

import type { ToolSpec } from "@iom/shared";
import { BrowserUnavailableError, getOrLaunch } from "./browser-state";

interface BrowserOpenArgs {
	readonly url: string;
}

function isBrowserOpenArgs(v: unknown): v is BrowserOpenArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as BrowserOpenArgs;
	return typeof a.url === "string";
}

interface BrowserOpenResult {
	readonly title: string;
	readonly url: string;
	readonly statusCode: number | null;
	/** Set when puppeteer couldn't launch and we returned a URL-only fallback. */
	readonly fallback?: string;
}

export const browserOpenTool: ToolSpec = {
	name: "browser_open",
	description:
		"Open a URL in a Puppeteer-controlled Chromium window so the agent can see a running web app. " +
		"Reuses one shared window across all browser_* calls. Requires `puppeteer-core` + a local Chrome/Edge/Chromium; " +
		"set OATI_CHROME_PATH to override discovery. When no browser is available, returns a `fallback` field with the URL " +
		"so you can still surface it in chat (the user can click it in their default browser). " +
		"Approval-gated because it spawns a visible window on the user's machine.",
	schema: {
		type: "object",
		properties: {
			url: { type: "string", description: "Full URL including scheme (http:// or https://)." },
		},
		required: ["url"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx): Promise<BrowserOpenResult> {
		if (!isBrowserOpenArgs(args)) throw new Error("browser_open: invalid args");
		let parsed: URL;
		try {
			parsed = new URL(args.url);
		} catch {
			throw new Error(`browser_open: invalid URL: ${args.url}`);
		}
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
			throw new Error(`browser_open: only http/https supported, got ${parsed.protocol}`);
		}

		try {
			const { page } = await getOrLaunch();
			const response = await page.goto(parsed.toString(), {
				waitUntil: "domcontentloaded",
				timeout: 30_000,
			});
			const title = await page.title();
			return {
				title,
				url: page.url(),
				statusCode: response ? response.status() : null,
			};
		} catch (err) {
			// 2026-05-29: when puppeteer can't find a Chrome to drive (no
			// install, no env var, OS without our probe paths), don't fail
			// the turn — return the URL with a fallback note so the model
			// can pass it to the user in chat. The chat UI auto-linkifies,
			// so the user gets a clickable link in their default browser.
			// We only soft-fall for the unavailable case; other errors
			// (network timeout, 4xx page, etc.) keep their existing throw
			// behavior because the puppeteer launch DID succeed.
			if (err instanceof BrowserUnavailableError) {
				ctx.log?.("info", `browser_open: ${err.message}`);
				return {
					title: "(browser preview unavailable)",
					url: parsed.toString(),
					statusCode: null,
					fallback: `Couldn't launch an embedded browser on this machine — share the URL with the user instead: ${parsed.toString()}. ${err.attempts.length > 0 ? `(launch attempts: ${err.attempts.join("; ")})` : "Install Chrome/Edge or set OATI_CHROME_PATH."}`,
				};
			}
			throw err;
		}
	},
};
