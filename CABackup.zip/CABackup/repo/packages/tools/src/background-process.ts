// 2026-05-23: `start_background_process` + `stop_background_process` +
// `list_background_processes`.
//
// `exec` blocks until the command exits, which is great for `npm run build`
// or `pytest` but catastrophic for `python -m http.server` / `npm run dev` /
// `flask run` — anything that's meant to keep running. Without these
// tools, the model has no way to launch a dev server and then verify it
// with another tool (fetch_url, browser_open) in the same turn.
//
// The host registry tracks PIDs and kills them on session end so the user
// never leaves a chat window with orphan servers running.

import type { ToolSpec } from "@iom/shared";

// ─── start_background_process ─────────────────────────────────────────

interface StartArgs {
	readonly command: string;
	readonly cwd?: string;
	readonly waitForOutputMs?: number;
	readonly label?: string;
}

function isStartArgs(v: unknown): v is StartArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as StartArgs;
	if (typeof a.command !== "string" || a.command.trim().length === 0) return false;
	if (a.cwd !== undefined && typeof a.cwd !== "string") return false;
	if (a.waitForOutputMs !== undefined && typeof a.waitForOutputMs !== "number") return false;
	if (a.label !== undefined && typeof a.label !== "string") return false;
	return true;
}

// Description-policy reference:
// - Use this (NOT `exec`) for ANY command that doesn't return: dev servers
//   (`npm run dev`, `vite`, `python -m http.server`, `flask run`), file
//   watchers (`nodemon`, `cargo watch`), etc. `exec` blocks and times out
//   at 60s.
// - Returns IMMEDIATELY with PID + ~1.5s of early stdout/stderr.
// - After starting, verify with `fetch_url` (server responding?) then
//   optionally `browser_open`.
// - Pair with `stop_background_process`. Host kills tracked processes on
//   session end.
export const startBackgroundProcessTool: ToolSpec = {
	name: "start_background_process",
	description:
		"Spawn a long-running process (dev server, file watcher, anything that doesn't return) in the background. Returns PID + early output. Use this — NOT `exec` — for npm run dev / vite / python -m http.server / nodemon / etc.",
	schema: {
		type: "object",
		properties: {
			command: {
				type: "string",
				description: "The shell command to run (e.g. 'python -m http.server 8000', 'npm run dev').",
			},
			cwd: {
				type: "string",
				description: "Working directory. Defaults to the workspace root.",
			},
			waitForOutputMs: {
				type: "integer",
				description:
					"How long to wait for early stdout/stderr before returning. Default 1500, clamped to [100, 10000]. Useful to capture 'Listening on port X' log lines.",
			},
			label: {
				type: "string",
				description:
					"Optional human-friendly label shown in the host's running-processes list. Defaults to the command.",
			},
		},
		required: ["command"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx) {
		if (!isStartArgs(args)) throw new Error("start_background_process: invalid args");
		if (!ctx.startBackgroundProcess) {
			throw new Error(
				"start_background_process: this host does not support background processes. Run iOmCode in VS Code or via the sidecar to get this capability.",
			);
		}
		const opts: {
			cwd?: string;
			waitForOutputMs?: number;
			label?: string;
		} = {};
		if (args.cwd !== undefined) opts.cwd = args.cwd;
		if (args.waitForOutputMs !== undefined) opts.waitForOutputMs = args.waitForOutputMs;
		if (args.label !== undefined) opts.label = args.label;
		const handle = await ctx.startBackgroundProcess(args.command, opts);
		// Return a flattened text-friendly shape — the model sees
		// startup logs inline rather than as a separate field it has
		// to remember to inspect.
		return {
			pid: handle.pid,
			command: handle.command,
			cwd: handle.cwd,
			label: handle.label,
			startedAt: handle.startedAt,
			...(handle.exitedDuringWait !== undefined
				? {
						exitedDuringWait: handle.exitedDuringWait,
						warning: `Process exited during the wait window with code ${handle.exitedDuringWait}. The command may have failed immediately — check earlyStderr.`,
					}
				: { status: "running" }),
			earlyStdout: handle.earlyStdout,
			earlyStderr: handle.earlyStderr,
		};
	},
};

// ─── stop_background_process ──────────────────────────────────────────

interface StopArgs {
	readonly pid: number;
}

function isStopArgs(v: unknown): v is StopArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as StopArgs;
	return typeof a.pid === "number" && Number.isFinite(a.pid) && a.pid > 0;
}

export const stopBackgroundProcessTool: ToolSpec = {
	name: "stop_background_process",
	description:
		"Stop a background process started by `start_background_process`. Use the PID returned from start. Idempotent — returns `{killed: false}` if the PID is unknown (already exited or never tracked). The host also kills every background process automatically on session end, so you don't strictly need to stop them before the chat closes.",
	schema: {
		type: "object",
		properties: {
			pid: {
				type: "integer",
				description: "OS process id returned by start_background_process.",
			},
		},
		required: ["pid"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isStopArgs(args)) throw new Error("stop_background_process: invalid args");
		if (!ctx.stopBackgroundProcess) {
			throw new Error("stop_background_process: this host does not support background processes.");
		}
		return ctx.stopBackgroundProcess(args.pid);
	},
};

// ─── list_background_processes ────────────────────────────────────────

export const listBackgroundProcessesTool: ToolSpec = {
	name: "list_background_processes",
	description:
		"List every background process the agent has started in this session that's still running. Returns an array of `{pid, command, cwd, label, startedAt}`. Useful when the model has lost track of which PID is which after a long session, or when deciding whether to start a new server vs. reuse an existing one.",
	schema: {
		type: "object",
		properties: {},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(_args, ctx) {
		if (!ctx.listBackgroundProcesses) {
			throw new Error("list_background_processes: this host does not support background processes.");
		}
		return { running: ctx.listBackgroundProcesses() };
	},
};
