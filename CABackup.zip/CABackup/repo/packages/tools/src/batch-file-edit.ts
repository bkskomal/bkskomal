// 2026-05-29: batch_file_edit — atomic multi-file find-and-replace.
//
// The gap this closes: when the user asks for a refactor that touches N
// files ("rename `parseFoo` to `parseBar` across the codebase", "switch
// from `axios` to `fetch` everywhere", "update the import path from `@/old`
// to `@/new`"), the model historically issued N separate write_file calls.
// Each carried its own approval prompt in non-auto modes, its own
// validation gauntlet, and its own chance to fail. The end-to-end was
// slow and fragile.
//
// One batch tool call lets the model declare the whole intent up-front:
// here's the list of (path, before, after) edits, apply them all or
// report which ones didn't match. The host previews the combined diff
// (already supported by showDiff) before any writes commit.
//
// Each edit is a STRING FIND-AND-REPLACE inside one file. The `before`
// string must match EXACTLY once in the file's current content. We chose
// strict "match exactly once" over regex / fuzzy match to keep the
// semantics obvious to the model — when the match isn't unique, the model
// must add surrounding context to disambiguate (a clearer error than
// "your regex matched 7 places, which did you mean?").
//
// Atomic-per-file: each entry is independent. We process them serially,
// recording per-edit status. Failures don't roll back successful writes —
// the model sees a structured report and can fix the failed entries on
// its next iteration. Atomic-across-files would require a transactional
// filesystem we don't have.

import type { ToolSpec } from "@iom/shared";

interface EditEntry {
	readonly path: string;
	readonly before: string;
	readonly after: string;
}

interface BatchFileEditArgs {
	readonly edits: readonly EditEntry[];
}

interface EditResult {
	readonly path: string;
	readonly status: "applied" | "skipped";
	readonly reason?: string;
}

interface BatchFileEditResult {
	readonly applied: number;
	readonly skipped: number;
	readonly results: readonly EditResult[];
}

function isEditEntry(v: unknown): v is EditEntry {
	if (typeof v !== "object" || v === null) return false;
	const e = v as EditEntry;
	return (
		typeof e.path === "string" &&
		e.path.length > 0 &&
		typeof e.before === "string" &&
		e.before.length > 0 &&
		typeof e.after === "string"
	);
}

function isBatchFileEditArgs(v: unknown): v is BatchFileEditArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as BatchFileEditArgs;
	return Array.isArray(a.edits) && a.edits.every(isEditEntry);
}

/**
 * Count how many times `needle` appears in `haystack`. Simple linear scan,
 * no regex (so the model's `before` string can contain any characters
 * including `.`, `*`, `(`, `\`, etc. without escaping).
 */
function countOccurrences(haystack: string, needle: string): number {
	if (needle.length === 0) return 0;
	let count = 0;
	let from = 0;
	while (true) {
		const idx = haystack.indexOf(needle, from);
		if (idx < 0) break;
		count++;
		from = idx + needle.length;
	}
	return count;
}

export const batchFileEditTool: ToolSpec = {
	name: "batch_file_edit",
	description:
		"Apply N (path, before, after) find-and-replace edits across multiple files in ONE call. Use for cross-file refactors: rename a symbol, update an import path, swap a library, change a config value everywhere. `before` must match EXACTLY once per file — when it's ambiguous, add surrounding context. Faster than N write_file calls; previews the combined diff. Returns per-edit status; ambiguous / unmatched entries are reported, the rest still commit.",
	schema: {
		type: "object",
		properties: {
			edits: {
				type: "array",
				description:
					'List of edits. Each entry is { path, before, after }. `before` is the exact text to find in the file (must match exactly once); `after` is the replacement. For pure deletions use after="". Paths are workspace-relative or absolute. Each path may appear multiple times if multiple distinct edits in the same file are needed.',
				items: {
					type: "object",
					properties: {
						path: { type: "string", description: "File to edit." },
						before: {
							type: "string",
							description:
								"Exact text to find. Must match exactly ONE location in the file — include surrounding context to disambiguate.",
						},
						after: {
							type: "string",
							description: "Replacement text. Empty string deletes the matched range.",
						},
					},
					required: ["path", "before", "after"],
				},
			},
		},
		required: ["edits"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args, ctx) {
		if (!isBatchFileEditArgs(args) || args.edits.length === 0) return {};
		// 2026-06-02: build a per-file diff array so the approval modal can
		// render a navigable multi-file view via MultiFileDiff. Group edits
		// by path so multiple edits to the same file get composed into a
		// single before/after pair (the user sees the cumulative diff per
		// file, not three separate one-line micro-diffs). Falls back to
		// `diff` (single-file shape) when there's exactly one file so older
		// hosts that don't read `diffs` still get a render.
		const byPath = new Map<string, { before: string; after: string }>();
		const orderedPaths: string[] = [];
		for (const edit of args.edits) {
			let entry = byPath.get(edit.path);
			if (!entry) {
				const before = (await ctx.fileExists(edit.path)) ? await ctx.readFile(edit.path) : "";
				entry = { before, after: before };
				byPath.set(edit.path, entry);
				orderedPaths.push(edit.path);
			}
			// Apply this edit cumulatively to `after`, matching the handler's
			// exact-once semantics. Edits that don't match cleanly leave the
			// current `after` unchanged in the preview (the actual handler
			// surfaces them as errors in its result).
			const count = countOccurrences(entry.after, edit.before);
			if (count === 1) {
				entry.after = entry.after.replace(edit.before, edit.after);
			}
		}
		const diffs = orderedPaths.map((p) => {
			const e = byPath.get(p);
			if (!e) throw new Error(`batch_file_edit: orderedPaths/byPath mismatch on ${p}`);
			return { path: p, before: e.before, after: e.after };
		});
		const note =
			args.edits.length > 1
				? `Approving applies ${args.edits.length} edit${args.edits.length === 1 ? "" : "s"} across ${orderedPaths.length} file${orderedPaths.length === 1 ? "" : "s"}.`
				: undefined;
		return {
			// `diff` stays populated as the single-file fallback (first entry).
			diff: diffs[0],
			diffs,
			...(note ? { note } : {}),
		};
	},
	async handler(args, ctx): Promise<BatchFileEditResult> {
		if (!isBatchFileEditArgs(args)) {
			throw new Error(
				"batch_file_edit: invalid args, expected { edits: [{ path: string, before: string, after: string }, …] }",
			);
		}
		if (args.edits.length === 0) {
			return { applied: 0, skipped: 0, results: [] };
		}
		const results: EditResult[] = [];
		// Group by path so multiple edits to the same file are applied in
		// sequence on the same buffer (the second `before` may only appear
		// AFTER the first edit landed). We process files one at a time.
		const editsByPath = new Map<string, EditEntry[]>();
		for (const e of args.edits) {
			const list = editsByPath.get(e.path) ?? [];
			list.push(e);
			editsByPath.set(e.path, list);
		}
		for (const [path, fileEdits] of editsByPath) {
			let content: string;
			try {
				content = (await ctx.fileExists(path)) ? await ctx.readFile(path) : "";
			} catch (err) {
				for (const _ of fileEdits) {
					results.push({
						path,
						status: "skipped",
						reason: `read failed: ${err instanceof Error ? err.message : String(err)}`,
					});
				}
				continue;
			}
			let mutated = false;
			for (const e of fileEdits) {
				const count = countOccurrences(content, e.before);
				if (count === 0) {
					results.push({
						path,
						status: "skipped",
						reason: "`before` text not found in file",
					});
					continue;
				}
				if (count > 1) {
					results.push({
						path,
						status: "skipped",
						reason: `\`before\` text matched ${count} locations; add surrounding context to disambiguate`,
					});
					continue;
				}
				content = content.replace(e.before, e.after);
				mutated = true;
				results.push({ path, status: "applied" });
			}
			if (mutated) {
				try {
					await ctx.writeFile(path, content);
				} catch (err) {
					// Mark previously-applied entries as skipped retroactively —
					// they didn't survive the write.
					for (const r of results.filter((r) => r.path === path && r.status === "applied")) {
						(r as { status: string; reason?: string }).status = "skipped";
						(r as { status: string; reason?: string }).reason =
							`write failed: ${err instanceof Error ? err.message : String(err)}`;
					}
				}
			}
		}
		const applied = results.filter((r) => r.status === "applied").length;
		const skipped = results.length - applied;
		return { applied, skipped, results };
	},
};
