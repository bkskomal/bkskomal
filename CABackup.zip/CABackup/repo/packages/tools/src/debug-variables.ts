// R6-E: debug_variables — expand a `variablesReference` returned by
// `debug_scopes` (or recursively by another `debug_variables` call) into the
// list of named values it contains. Backed by the DAP `variables` request
// via `ctx.debug.getVariables`.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface DebugVariablesArgs {
	readonly variablesReference: number;
}

function isDebugVariablesArgs(v: unknown): v is DebugVariablesArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DebugVariablesArgs;
	if (typeof a.variablesReference !== "number") return false;
	return true;
}

export const debugVariablesTool: ToolSpec = {
	name: "debug_variables",
	description:
		"Expand a `variablesReference` (from debug_scopes or a previous debug_variables call) into its named values. Returns a JSON array of {name, value, type?}. Use this to inspect locals/arguments at a paused frame.",
	schema: {
		type: "object",
		properties: {
			variablesReference: {
				type: "integer",
				description: "Opaque DAP reference returned by debug_scopes (or nested debug_variables).",
			},
		},
		required: ["variablesReference"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isDebugVariablesArgs(args)) {
			throw new Error("debug_variables: invalid args, expected { variablesReference: number }");
		}
		if (!ctx.debug) {
			return JSON.stringify({ variables: [], note: "debug_variables: no debug bridge in this host." });
		}
		if (!ctx.debug.getActiveSession()) {
			return JSON.stringify({ variables: [], note: "debug_variables: no active debug session." });
		}
		try {
			const variables = await ctx.debug.getVariables(args.variablesReference);
			return JSON.stringify({ variables });
		} catch (err) {
			return JSON.stringify({
				variables: [],
				error: err instanceof Error ? err.message : String(err),
			});
		}
	},
};
