// R6-E: debug_list_breakpoints — snapshot every source breakpoint currently
// registered with the editor. Backed by `ctx.debug.listBreakpoints` (which
// wraps `vscode.debug.breakpoints`). Function/logpoint breakpoints are
// intentionally omitted; only line-anchored source breakpoints are surfaced
// because they're the only kind we can set via `debug_set_breakpoint`.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

export const debugListBreakpointsTool: ToolSpec = {
	name: "debug_list_breakpoints",
	description:
		"List every source breakpoint currently registered with the editor. Returns a JSON array of {uri, line, condition?, enabled} entries (1-based lines). Useful before calling debug_set_breakpoint to avoid duplicates.",
	schema: {
		type: "object",
		properties: {},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(_args, ctx) {
		if (!ctx.debug) {
			return JSON.stringify({
				breakpoints: [],
				note: "debug_list_breakpoints: no debug bridge in this host.",
			});
		}
		const breakpoints = ctx.debug.listBreakpoints();
		return JSON.stringify({ breakpoints });
	},
};
