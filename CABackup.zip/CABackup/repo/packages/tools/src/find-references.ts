import type { ToolSpec } from "@iom/shared";

interface FindReferencesArgs {
	readonly path: string;
	readonly line: number;
	readonly character?: number;
}

function isFindReferencesArgs(v: unknown): v is FindReferencesArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as FindReferencesArgs;
	if (typeof a.path !== "string") return false;
	if (typeof a.line !== "number") return false;
	if (a.character !== undefined && typeof a.character !== "number") return false;
	return true;
}

/** Cap per-result snippets so a single huge identifier-spam file can't blow up the agent context. */
const SNIPPET_CHAR_CAP = 300;

/**
 * `find_references` — wraps `vscode.executeReferenceProvider` to give the
 * agent a "where is this symbol used?" tool. Coordinates are 1-based on the
 * outside (matching grep/IDE convention); we convert to LSP's 0-based on the
 * host side. `character` defaults to 0 (start of line) when omitted, which
 * picks up the leading identifier in most cases.
 */
export const findReferencesTool: ToolSpec = {
	name: "find_references",
	description:
		"Find all references to the symbol at a given file position using the editor's language server. Use this when you need to know where a function/class/variable is used before refactoring. Returns up to N {path, line, snippet} entries. Falls back gracefully when no language server is attached.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "File containing the symbol. Relative to workspace root, or absolute.",
			},
			line: {
				type: "integer",
				description: "1-based line number where the symbol appears.",
			},
			character: {
				type: "integer",
				description: "Optional 0-based column. Defaults to 0 (start of line).",
			},
		},
		required: ["path", "line"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isFindReferencesArgs(args)) {
			throw new Error("find_references: invalid args, expected { path, line, character? }");
		}
		if (!ctx.symbols) {
			return "find_references: no language-server bridge available in this host.";
		}
		const character = args.character ?? 0;
		const hits = await ctx.symbols.findReferences(args.path, args.line, character);
		if (hits.length === 0) {
			return `find_references: no references found for ${args.path}:${args.line}.`;
		}
		const blocks = hits.map((h, i) => {
			const snippet =
				h.snippet.length > SNIPPET_CHAR_CAP ? `${h.snippet.slice(0, SNIPPET_CHAR_CAP)}…` : h.snippet;
			return `${i + 1}. ${h.path}:${h.line}\n   ${snippet.replace(/\n/g, "\n   ")}`;
		});
		return blocks.join("\n");
	},
};
