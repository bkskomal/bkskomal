import type { ToolSpec } from "@iom/shared";

interface ReadFileArgs {
	readonly path: string;
}

function isReadFileArgs(v: unknown): v is ReadFileArgs {
	return typeof v === "object" && v !== null && typeof (v as ReadFileArgs).path === "string";
}

// 2026-05-27: known-binary file extensions. read_file refuses these
// outright because reading a binary file as UTF-8 produces garbled
// content that poisons agent history — the model sees thousands of
// replacement characters in subsequent turns and chokes.
// Hint the agent toward the right tool (Python lib via exec, etc.).
const BINARY_EXTENSIONS = new Map<string, string>([
	// Office / PDF
	[
		".pptx",
		"Use `exec` with python-pptx: `python -c \"from pptx import Presentation; p=Presentation('path'); print([l.name for l in p.slide_layouts])\"`",
	],
	[
		".docx",
		"Use `exec` with python-docx: `python -c \"from docx import Document; d=Document('path'); print(len(d.paragraphs), 'paragraphs')\"`",
	],
	[
		".xlsx",
		"Use `exec` with openpyxl: `python -c \"import openpyxl; wb=openpyxl.load_workbook('path'); print(wb.sheetnames)\"`",
	],
	[
		".pdf",
		"Use `exec` with pymupdf: `python -c \"import pymupdf; d=pymupdf.open('path'); print(len(d), 'pages'); print(d[0].get_text()[:500])\"`",
	],
	[".odt", "Use `exec` with odfpy or pandoc to extract text."],
	// Images
	[
		".png",
		"Use `exec` with PIL: `python -c \"from PIL import Image; print(Image.open('path').size)\"`. To see content, ask the user to attach the image to the chat.",
	],
	[".jpg", "Use `exec` with PIL (same as .png)."],
	[".jpeg", "Use `exec` with PIL (same as .png)."],
	[".gif", "Use `exec` with PIL (same as .png)."],
	[".bmp", "Use `exec` with PIL (same as .png)."],
	[".webp", "Use `exec` with PIL (same as .png)."],
	[".tiff", "Use `exec` with PIL (same as .png)."],
	[".ico", "Use `exec` with PIL (same as .png)."],
	// Audio / video
	[".mp3", "Use `exec` with ffprobe or mutagen for metadata."],
	[".mp4", "Use `exec` with ffprobe for metadata."],
	[".wav", "Use `exec` with ffprobe or wave library."],
	[".mov", "Use `exec` with ffprobe."],
	[".webm", "Use `exec` with ffprobe."],
	// Archives
	[
		".zip",
		"Use `exec`: `python -c \"import zipfile; z=zipfile.ZipFile('path'); print(z.namelist()[:50])\"`",
	],
	[".tar", "Use `exec`: `tar -tf path | head`"],
	[".gz", "Use `exec`: `tar -tzf path | head` (assuming .tar.gz)"],
	[".7z", "Use `exec` with 7z CLI or py7zr."],
	[".rar", "Use `exec` with unrar."],
	// Compiled / executable
	[".exe", "Refused — executable file."],
	[".dll", "Refused — shared library file."],
	[".so", "Refused — shared library file."],
	[".dylib", "Refused — shared library file."],
	[".class", "Refused — compiled bytecode."],
	[".pyc", "Refused — compiled Python bytecode."],
	[".o", "Refused — object file."],
	[".obj", "Refused — object file."],
	// Misc binary
	[".db", "Use `exec` with sqlite3 CLI: `sqlite3 path '.tables'`"],
	[".sqlite", "Use `exec` with sqlite3 CLI."],
	[".sqlite3", "Use `exec` with sqlite3 CLI."],
	[
		".parquet",
		"Use `exec` with pyarrow: `python -c \"import pyarrow.parquet as pq; print(pq.read_table('path').schema)\"`",
	],
	[
		".npy",
		"Use `exec` with numpy: `python -c \"import numpy as np; a=np.load('path'); print(a.shape, a.dtype)\"`",
	],
	[".pickle", "Use `exec` with pickle CAREFULLY (untrusted pickle is code execution)."],
	[".pkl", "Use `exec` with pickle CAREFULLY."],
	[".woff", "Refused — font file."],
	[".woff2", "Refused — font file."],
	[".ttf", "Refused — font file."],
	[".otf", "Refused — font file."],
]);

function extensionOf(path: string): string {
	const slash = Math.max(path.lastIndexOf("/"), path.lastIndexOf("\\"));
	const base = slash >= 0 ? path.slice(slash + 1) : path;
	const dot = base.lastIndexOf(".");
	if (dot <= 0) return ""; // no extension OR leading-dot dotfile
	return base.slice(dot).toLowerCase();
}

/**
 * Sniff for binary content even when the extension is unknown — files
 * with a high ratio of NUL bytes or replacement characters in the first
 * few KB are almost certainly binary.
 */
function looksBinary(content: string): boolean {
	const head = content.slice(0, 4096);
	if (head.length === 0) return false;
	let suspicious = 0;
	for (let i = 0; i < head.length; i++) {
		const ch = head.charCodeAt(i);
		// NUL byte, OR Unicode replacement char (U+FFFD), OR control char
		// outside the usual whitespace set.
		if (ch === 0 || ch === 0xfffd) {
			suspicious++;
		} else if (ch < 32 && ch !== 9 && ch !== 10 && ch !== 13) {
			suspicious++;
		}
	}
	return suspicious / head.length > 0.05; // 5% threshold catches binaries cleanly while sparing valid UTF-8 text
}

export const readFileTool: ToolSpec = {
	name: "read_file",
	description:
		"Read the full contents of a TEXT file from the user's workspace. Paths are relative to the workspace root unless absolute. Refuses binary files (.pptx, .pdf, .png, .docx, etc.) — use `exec` with the appropriate Python library to inspect those instead.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description:
					"Path to a TEXT file, relative to workspace root or absolute. Do NOT pass binary files like .pptx, .pdf, .png — those return an error with a hint to use `exec` + a Python library.",
			},
		},
		required: ["path"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isReadFileArgs(args)) throw new Error("read_file: invalid args, expected { path: string }");
		// 2026-05-27: binary guard. Check the extension first (cheap +
		// covers the common cases). If the extension is unknown, read
		// the file and sniff. Reading a binary file as text returns
		// garbled bytes that poison agent history — the model sees
		// thousands of replacement characters on every subsequent turn
		// and gives up (the "empty response after read_file" failure
		// the user reported on 2026-05-27).
		const ext = extensionOf(args.path);
		const hint = BINARY_EXTENSIONS.get(ext);
		if (hint) {
			throw new Error(
				`read_file refused: '${args.path}' is a binary file (${ext}). ${hint} Do NOT attempt read_file on binaries — the resulting bytes poison the conversation context and lead to empty responses on subsequent turns.`,
			);
		}
		const content = await ctx.readFile(args.path);
		if (typeof content === "string" && looksBinary(content)) {
			throw new Error(
				`read_file refused: '${args.path}' looks like binary content (NUL bytes / replacement chars in the first 4KB). If this IS a text file with an unusual encoding, use \`exec\` with a controlled decoder. If it'\\''s actually binary, use the appropriate Python library via \`exec\` to inspect it.`,
			);
		}
		// 2026-05-30: broken-shape detector. A file with many literal `\n`
		// character sequences AND zero real newlines is almost always
		// double-escaped — typically the result of an earlier wrapped-args
		// write that serialized the content as a JSON-encoded string AND
		// THEN serialized that string AGAIN. Such a file renders the `\n`s
		// as visible text in a browser (the failure pattern from the live
		// trace where the AI Learning Hub page showed `\\n\\n` rubbish).
		// Pre-fix the model could read the content and not recognize the
		// breakage — looked like minified HTML. The warning prepended
		// below makes the malformed shape unmissable and points at the
		// fix path (rewrite with write_file).
		if (typeof content === "string") {
			const warning = detectBrokenShapeWarning(args.path, content);
			if (warning) return `${warning}\n\n---\n\n${content}`;
		}
		return content;
	},
};

/**
 * Return a warning string when the file's contents look structurally
 * broken (literal `\n` sequences instead of real newlines), or undefined
 * when the content is healthy.
 *
 * Exported for tests.
 */
export function detectBrokenShapeWarning(path: string, content: string): string | undefined {
	if (content.length < 80) return undefined; // too short to make a confident call
	// Count literal `\n` sequences (backslash + n, 2 chars). This is what
	// a double-escaped write leaves behind: the JSON encoder turned a real
	// newline into the 2-char string "\n", then a second pass left those
	// chars in the file as-is.
	let literalNL = 0;
	let realNL = 0;
	for (let i = 0; i < content.length; i++) {
		const ch = content.charCodeAt(i);
		if (ch === 10)
			realNL++; // \n
		else if (ch === 92 /* \ */ && content.charCodeAt(i + 1) === 110 /* n */) {
			literalNL++;
			i++; // skip the n we just consumed as part of the pair
		}
	}
	// Strict: many literal sequences AND ZERO real newlines. A file with
	// even a few real newlines is probably valid (e.g. a JSON file whose
	// values legitimately contain `\n`).
	if (literalNL >= 5 && realNL === 0) {
		return [
			`⚠️ [iOmCode heads-up — ${path}] This file appears to contain ${literalNL} literal \`\\n\` character sequences AND ZERO real newlines. That's the structural signature of a double-escaped write — typically what happens when a tool call's args got wrapped and the content was serialized as a JSON-string-in-a-JSON-string.`,
			"",
			"In a browser this file renders the `\\n` characters as visible text instead of line breaks (the page shows `\\\\n\\\\n` rubbish instead of paragraph breaks). To fix:",
			"",
			"  1. Identify the desired content (often a sibling `*-fixed.*` file in the same directory holds a clean copy).",
			"  2. Rewrite this file with `write_file`, using REAL newlines in the `content` argument (not the 2-char `\\n` sequence).",
			"  3. Re-read the file to confirm `\\n` is gone.",
			"",
			"Don't try to interpret the content below as if it's minified — it isn't, the file is malformed.",
		].join("\n");
	}
	return undefined;
}
