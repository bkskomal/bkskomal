export { readFileTool } from "./read-file";
export { writeFileTool } from "./write-file";
export { execTool } from "./exec";
export {
	startBackgroundProcessTool,
	stopBackgroundProcessTool,
	listBackgroundProcessesTool,
} from "./background-process";
export { spawnAgentTool } from "./spawn-agent";
export { spawnParallelAgentsTool } from "./spawn-parallel-agents";
export { listDirTool } from "./list-dir";
export { grepSearchTool } from "./grep-search";
export { fetchUrlTool } from "./fetch-url";
export { webSearchTool } from "./web-search";
export { workspaceContextTool } from "./workspace-context";
export { rememberFactTool } from "./remember-fact";
export { recallFactsTool } from "./recall-facts";
export { readSessionArchiveTool } from "./read-session-archive";
export { suggestProjectMemoryAdditionTool } from "./suggest-project-memory-addition";
export { writeSharedNoteTool } from "./write-shared-note";
export { readSharedNotesTool } from "./read-shared-notes";
export { codeSemanticSearchTool } from "./code-semantic-search";
export { gitStatusTool } from "./git-status";
export { gitDiffTool } from "./git-diff";
export { gitCommitTool } from "./git-commit";
export { gitOpenPrTool } from "./git-open-pr";
export { runTestsTool, detectRunner } from "./run-tests";
export type { TestFailure } from "./run-tests";
export { startBackgroundTaskTool } from "./start-background-task";
export { browserOpenTool } from "./browser-open";
export { browserNavigateTool } from "./browser-navigate";
export { browserScreenshotTool } from "./browser-screenshot";
export { browserEvalTool } from "./browser-eval";
export { browserCloseTool } from "./browser-close";
// 2026-05-30: OCR companion to browser_screenshot's pageText — for
// images on disk / data URLs where there's no live DOM to query.
export { extractImageTextTool } from "./extract-image-text";
// APPENDED in R3-A — symbol-aware retrieval tools backed by the editor's LSP.
export { findReferencesTool } from "./find-references";
export { findDefinitionTool } from "./find-definition";
export { symbolsInFileTool } from "./symbols-in-file";
// APPENDED in R3-C — render_diagram (mermaid).
export { renderDiagramTool } from "./render-diagram";
// APPENDED in R3-E — gh issue read/comment.
export { ghIssueReadTool } from "./gh-issue-read";
export { ghIssueCommentTool } from "./gh-issue-comment";
// R4-B: diagnostics pill — LSP diagnostics snapshot tool.
export { getDiagnosticsTool } from "./get-diagnostics";
// R4-C: snippet library — list/save snippet tools.
export { listSnippetsTool } from "./list-snippets";
export { saveSnippetTool } from "./save-snippet";
// R5-A: inline-completion telemetry tool.
export {
	_setInlineCompletionStatsReader,
	inlineCompletionStatsTool,
} from "./inline-completion-stats";
export type { InlineCompletionStatsSnapshot } from "./inline-completion-stats";
// R5-B: knowledge tools.
export { listKnowledgeTool } from "./list-knowledge";
export { searchKnowledgeTool } from "./search-knowledge";
// R5-C: cross-session search.
export { searchConversationsTool } from "./search-conversations";
// R5-D: personas + recipes.
export { setPersonaTool } from "./set-persona";
export { runRecipeTool } from "./run-recipe";
// R6-A: structured Plan v2 + memory consolidation tools.
export { proposePlanTool } from "./propose_plan";
export { consolidateMemoryTool } from "./consolidate-memory";
// R6-B: Jupyter notebook tools.
export { readNotebookTool } from "./read-notebook";
export { readNotebookCellTool } from "./read-notebook-cell";
export { editNotebookCellTool } from "./edit-notebook-cell";
export { insertNotebookCellTool } from "./insert-notebook-cell";
export { deleteNotebookCellTool } from "./delete-notebook-cell";
export { runNotebookCellTool } from "./run-notebook-cell";
// R6-C: AI commit message helper.
export { suggestCommitMessageTool } from "./suggest-commit-message";
// R6-D: smart-apply (three-way merge).
export { smartApplyPatchTool } from "./smart-apply";
// R6-E: debug bridge tools.
export { debugStackFramesTool } from "./debug-stack-frames";
export { debugEvaluateTool } from "./debug-evaluate";
export { debugScopesTool } from "./debug-scopes";
export { debugVariablesTool } from "./debug-variables";
export { debugListBreakpointsTool } from "./debug-list-breakpoints";
export { debugSetBreakpointTool } from "./debug-set-breakpoint";
export { debugRemoveBreakpointTool } from "./debug-remove-breakpoint";
// R8-A: predict_next_edit_location — Cursor-parity tab-to-jump helper.
export { predictNextEditLocationTool } from "./predict-next-edit";
// R8-B: codebase_deep_search — @codebase mention backing tool.
export { codebaseDeepSearchTool } from "./codebase-deep-search";
// R8-C: resolve_context_mention — generic @mention resolver.
export { resolveContextMentionTool } from "./resolve-context-mention";
// R8-D: computer-use vision tools.
export { screenshotTool } from "./screenshot";
export { mouseClickTool } from "./mouse-click";
export { mouseMoveTool } from "./mouse-move";
export { typeTextTool } from "./type-text";
export { keyPressTool } from "./key-press";
// R8-E: hooks v2 + skills + multi-cursor edits.
export { loadSkillTool } from "./load-skill";
export { multiCursorEditTool } from "./multi-cursor-edit";
// 2026-05-29: atomic cross-file batch edits for refactors.
export { batchFileEditTool } from "./batch-file-edit";
// Agent-managed todo list (Claude-style).
export { todoWriteTool } from "./todo-write";
// 2026-05-27: ask the user a multiple-choice clarifying question.
export { askUserTool } from "./ask-user";
// 2026-06-29: batched sibling for start-of-task disambiguation ("build me X").
export { askUserBatchTool } from "./ask-user-batch";
// Workspace-root mutator — the model can swap the project folder mid-session.
export { setWorkspaceRootTool } from "./set-workspace-root";
export { builtinTools } from "./registry";
