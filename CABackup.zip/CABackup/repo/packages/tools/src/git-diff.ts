import type { ToolSpec } from "@iom/shared";

interface GitDiffArgs {
	readonly paths?: readonly string[];
	readonly staged?: boolean;
}

interface GitDiffResult {
	readonly diff: string;
	readonly truncated: boolean;
	readonly originalBytes: number;
	readonly staged: boolean;
}

const MAX_BYTES = 200 * 1024;
const TAIL_MARKER =
	"\n\n--- (diff truncated at 200 KB; re-run on a narrower path set for full output) ---\n";

function isGitDiffArgs(v: unknown): v is GitDiffArgs {
	if (typeof v !== "object" || v === null) return true; // {} is valid (all defaults)
	const a = v as GitDiffArgs;
	if (a.staged !== undefined && typeof a.staged !== "boolean") return false;
	if (a.paths !== undefined) {
		if (!Array.isArray(a.paths)) return false;
		for (const p of a.paths) if (typeof p !== "string") return false;
	}
	return true;
}

/**
 * Shell-quote a path for inclusion in a `git` command. Paths come from the
 * agent, so we always quote to defang spaces, semicolons, and shell metachars.
 * We allow `--` separators to be added by the caller as plain strings.
 */
function quotePath(p: string): string {
	if (process.platform === "win32") return `"${p.replace(/"/g, '\\"')}"`;
	return `'${p.replace(/'/g, "'\\''")}'`;
}

export const gitDiffTool: ToolSpec = {
	name: "git_diff",
	description:
		"Show a unified git diff for the workspace. Optionally narrow to specific paths or show only staged changes. Output is truncated to 200 KB with a tail marker.",
	schema: {
		type: "object",
		properties: {
			paths: {
				type: "array",
				items: { type: "string" },
				description: "Optional path filter (relative to workspace root).",
			},
			staged: {
				type: "boolean",
				description: "When true, diff against the index (`git diff --cached`). Default false.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<GitDiffResult> {
		if (!isGitDiffArgs(args)) throw new Error("git_diff: invalid args");
		const staged = args?.staged === true;
		const parts: string[] = ["git", "diff"];
		if (staged) parts.push("--cached");
		// `--no-color` keeps the diff parseable by downstream agents and tests.
		parts.push("--no-color");
		if (args?.paths && args.paths.length > 0) {
			parts.push("--");
			for (const p of args.paths) parts.push(quotePath(p));
		}
		const cmd = parts.join(" ");

		const res = await ctx.exec(cmd, { timeoutMs: 30_000 });
		if (res.exitCode !== 0 && res.exitCode !== 1) {
			// git diff exits 0 (no diff) or 1 (diff present); anything else is real failure.
			throw new Error(
				`git diff failed (exit ${res.exitCode}): ${res.stderr.trim() || res.stdout.trim() || "no output"}`,
			);
		}
		const out = res.stdout;
		if (out.length <= MAX_BYTES) {
			return { diff: out, truncated: false, originalBytes: out.length, staged };
		}
		return {
			diff: out.slice(0, MAX_BYTES) + TAIL_MARKER,
			truncated: true,
			originalBytes: out.length,
			staged,
		};
	},
};
