// 2026-06-29: `ask_user_batch` — batched sibling of `ask_user`. Called at
// the START of a substantial task when 2-4 independent decisions need to
// be made before writing code ("please build me a YouTube replica" →
// tech stack + scope + persistence). Rendered as a paginated card in the
// webview ("1 of 3 → 2 of 3 → 3 of 3 → Submit") rather than the composer-
// strip chip UI.
//
// When to use it (agent guidance, mirrored in the tool description):
//   - START of a large "build/create/make me X" request with genuine
//     ambiguity that a reasonable engineer would disambiguate up front.
//   - 2-4 questions, each with 2-4 options. First option is the safest
//     default (auto modes pick it).
//   - NOT mid-implementation micro-decisions — use `ask_user` for those.
//   - NOT as a stalling tactic — if the task is well-scoped, just do it.

import type { ToolSpec } from "@iom/shared";

interface AskUserBatchOption {
	readonly label: string;
	readonly description?: string;
}

interface AskUserBatchQuestion {
	readonly header: string;
	readonly question: string;
	readonly options: readonly AskUserBatchOption[];
	readonly multiSelect?: boolean;
	readonly allowOther?: boolean;
}

interface AskUserBatchArgs {
	readonly intro?: string;
	readonly questions: readonly AskUserBatchQuestion[];
}

function isString(v: unknown): v is string {
	return typeof v === "string";
}

function isValidQuestion(v: unknown): v is AskUserBatchQuestion {
	if (typeof v !== "object" || v === null) return false;
	const q = v as Record<string, unknown>;
	if (!isString(q.header) || q.header.trim().length === 0 || q.header.length > 20) return false;
	if (!isString(q.question) || q.question.trim().length === 0) return false;
	if (!Array.isArray(q.options) || q.options.length < 2 || q.options.length > 4) return false;
	for (const opt of q.options) {
		if (typeof opt !== "object" || opt === null) return false;
		const o = opt as Record<string, unknown>;
		if (!isString(o.label) || o.label.trim().length === 0) return false;
		if (o.description !== undefined && !isString(o.description)) return false;
	}
	if (q.multiSelect !== undefined && typeof q.multiSelect !== "boolean") return false;
	if (q.allowOther !== undefined && typeof q.allowOther !== "boolean") return false;
	return true;
}

function isAskUserBatchArgs(v: unknown): v is AskUserBatchArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as Record<string, unknown>;
	if (a.intro !== undefined && !isString(a.intro)) return false;
	if (!Array.isArray(a.questions) || a.questions.length < 2 || a.questions.length > 4) return false;
	return a.questions.every(isValidQuestion);
}

export const askUserBatchTool: ToolSpec = {
	name: "ask_user_batch",
	description:
		'Ask 2-4 clarifying questions in one paginated card. Use ONLY at the start of a substantial task ("please build me X") when the answer to each question would meaningfully change what you produce and you can\'t infer them from context. Do NOT use for mid-implementation micro-decisions (use ask_user for those). Do NOT use as a stalling tactic. First option of each question should be the safest default — auto modes may pick it.',
	schema: {
		type: "object",
		properties: {
			intro: {
				type: "string",
				description:
					'One-sentence context shown above the card, e.g. "I\'d be happy to build a YouTube replica — a couple of quick questions to make sure I build what you want." Keep it warm but brief.',
			},
			questions: {
				type: "array",
				description:
					"2-4 clarifying questions. Order them by importance (most impactful first). Each question is an object with `header` (≤12 chars, shown as chip label), `question` (full text ending in `?`), `options` (2-4 objects each with `label` + optional `description`), optional `multiSelect` (default false), optional `allowOther` (default true; adds a 'Type your own answer' text input as the last option).",
				items: { type: "object" },
			},
		},
		required: ["questions"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isAskUserBatchArgs(args)) {
			throw new Error(
				"ask_user_batch: invalid args — expected { intro?: string, questions: [{header, question, options: [{label,description?}] (2-4), multiSelect?, allowOther?}] (2-4) }",
			);
		}
		if (!ctx.askUserBatch) {
			// Host doesn't support batched prompting (test harness, headless
			// CLI, or an older extension version). Fall back to auto-picking
			// option[0] of every question — same fallback semantics as
			// ask_user's option[0] fallback.
			return {
				answers: args.questions.map((q) => ({
					header: q.header,
					answer: q.multiSelect ? [q.options[0].label] : q.options[0].label,
				})),
				autoPicked: true,
			};
		}
		const id = `askb_${Math.random().toString(36).slice(2, 10)}`;
		return await ctx.askUserBatch({
			id,
			intro: args.intro,
			questions: args.questions,
		});
	},
};
