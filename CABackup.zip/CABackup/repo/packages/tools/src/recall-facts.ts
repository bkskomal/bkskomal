import type { ToolSpec } from "@iom/shared";

interface RecallFactsArgs {
	readonly query?: string;
}

function isRecallFactsArgs(v: unknown): v is RecallFactsArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as RecallFactsArgs;
	if (a.query !== undefined && typeof a.query !== "string") return false;
	return true;
}

export const recallFactsTool: ToolSpec = {
	name: "recall_facts",
	description:
		"Retrieve persistent facts stored for this project (loaded from `<workspace>/.iom/facts.json`). Pass an optional `query` to filter by substring; omit it to list everything.",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description: "Optional substring filter (case-insensitive). Omit to list all facts.",
			},
		},
		required: [],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isRecallFactsArgs(args)) throw new Error("recall_facts: invalid args");
		if (!ctx.loadFacts) {
			return "(persistent facts are not enabled in this host)";
		}
		const all = await ctx.loadFacts();
		if (all.length === 0) return "(no persistent facts stored yet)";
		const q = args?.query?.trim().toLowerCase();
		const filtered = q ? all.filter((f) => f.fact.toLowerCase().includes(q)) : all;
		if (filtered.length === 0) return `(no facts match "${q}")`;
		const lines = filtered.map((f) => `- ${f.fact}  [${f.source}, ${f.addedAt}]`);
		return `${filtered.length} fact${filtered.length === 1 ? "" : "s"}:\n${lines.join("\n")}`;
	},
};
