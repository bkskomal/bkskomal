// R6-E: debug_evaluate — run an expression in the context of a stack frame
// inside the active debug session. Backed by the DAP `evaluate` request via
// `ctx.debug.evaluate`. Approval is "prompt" because this executes arbitrary
// code in the user's running program.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface DebugEvaluateArgs {
	readonly expression: string;
	readonly frameId?: number;
}

function isDebugEvaluateArgs(v: unknown): v is DebugEvaluateArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DebugEvaluateArgs;
	if (typeof a.expression !== "string" || a.expression.length === 0) return false;
	if (a.frameId !== undefined && typeof a.frameId !== "number") return false;
	return true;
}

export const debugEvaluateTool: ToolSpec = {
	name: "debug_evaluate",
	description:
		"Evaluate an expression in the active debug session. The expression is run as if typed into the debug console (REPL context). Returns the formatted result string. Omit frameId to evaluate against the top of the active stack. Approval-gated because this runs arbitrary code inside the user's process.",
	schema: {
		type: "object",
		properties: {
			expression: {
				type: "string",
				description: "Expression to evaluate (any syntax the language adapter accepts).",
			},
			frameId: {
				type: "integer",
				description:
					"Optional DAP frame id to scope the evaluation. Defaults to the top frame of the active stack.",
			},
		},
		required: ["expression"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx) {
		if (!isDebugEvaluateArgs(args)) {
			throw new Error(
				"debug_evaluate: invalid args, expected { expression: string; frameId?: number }",
			);
		}
		if (!ctx.debug) {
			return "debug_evaluate: no debug bridge in this host.";
		}
		if (!ctx.debug.getActiveSession()) {
			return "debug_evaluate: no active debug session.";
		}
		try {
			const result = await ctx.debug.evaluate(args.expression, args.frameId);
			return result;
		} catch (err) {
			return `debug_evaluate: error — ${err instanceof Error ? err.message : String(err)}`;
		}
	},
};
