// R6-B: read_notebook — surface a Jupyter notebook's cell structure (and
// optionally their execution outputs) to the agent so it can read .ipynb files
// the same way it reads .ts/.py sources. Backed by `ctx.notebooks` (the host's
// wrapper around `vscode.workspace.openNotebookDocument`). When the host has
// no notebook bridge — e.g. non-VS Code embedders — the tool falls back to
// parsing the on-disk JSON directly so reads still work.
import type { NotebookCellSnapshot, ToolSpec } from "@iom/shared";

interface ReadNotebookArgs {
	readonly path: string;
	readonly includeOutputs?: boolean;
}

function isReadNotebookArgs(v: unknown): v is ReadNotebookArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as ReadNotebookArgs;
	if (typeof a.path !== "string") return false;
	if (a.includeOutputs !== undefined && typeof a.includeOutputs !== "boolean") return false;
	return true;
}

/**
 * Fallback that parses an .ipynb file's JSON envelope without needing a live
 * VS Code notebook controller. Mirrors the nbformat v4 schema closely enough
 * for read-only inspection — we surface `cell_type`, `source` (joined if it's
 * an array of lines), the per-cell `metadata.language` if present, and (when
 * `includeOutputs` is true) a best-effort flattening of `outputs[*].data` into
 * a `{mime, text}[]` list.
 */
export function parseNotebookJson(
	raw: string,
	includeOutputs: boolean,
): readonly NotebookCellSnapshot[] {
	let nb: unknown;
	try {
		nb = JSON.parse(raw);
	} catch (err) {
		throw new Error(
			`read_notebook: file is not valid JSON: ${err instanceof Error ? err.message : String(err)}`,
		);
	}
	if (!nb || typeof nb !== "object") {
		throw new Error("read_notebook: notebook envelope is not an object");
	}
	const cells = (nb as { cells?: unknown }).cells;
	if (!Array.isArray(cells)) {
		throw new Error('read_notebook: notebook envelope is missing "cells" array');
	}
	const defaultLang = (nb as { metadata?: { language_info?: { name?: unknown } } }).metadata
		?.language_info?.name;
	const fallbackLanguage = typeof defaultLang === "string" ? defaultLang : "plaintext";
	const out: NotebookCellSnapshot[] = [];
	for (let i = 0; i < cells.length; i++) {
		const c = cells[i];
		if (!c || typeof c !== "object") continue;
		const cellType = (c as { cell_type?: unknown }).cell_type;
		const kind: "code" | "markdown" = cellType === "markdown" ? "markdown" : "code";
		const rawSource = (c as { source?: unknown }).source;
		const source = Array.isArray(rawSource)
			? rawSource.map((s) => String(s)).join("")
			: typeof rawSource === "string"
				? rawSource
				: "";
		const meta = (c as { metadata?: { language?: unknown } }).metadata;
		const cellLang = meta && typeof meta.language === "string" ? meta.language : undefined;
		const language = kind === "markdown" ? "markdown" : (cellLang ?? fallbackLanguage);
		const snapshot: NotebookCellSnapshot = includeOutputs
			? {
					index: i,
					kind,
					language,
					source,
					outputs: extractOutputs((c as { outputs?: unknown }).outputs),
				}
			: { index: i, kind, language, source };
		out.push(snapshot);
	}
	return out;
}

/**
 * Best-effort flattening of nbformat `outputs[*]` into `{mime, text}` pairs.
 * Handles the three common shapes:
 *   - `stream` outputs (`name`, `text`) → mime `application/vnd.code.notebook.stdout`
 *     or `.stderr` depending on `name`.
 *   - `error` outputs (`ename`, `evalue`, `traceback`) → mime
 *     `application/vnd.code.notebook.error` with a single joined string.
 *   - `display_data` / `execute_result` (`data`) → one entry per mime in the
 *     `data` map, with array-of-strings values joined.
 */
function extractOutputs(raw: unknown): readonly { readonly mime: string; readonly text: string }[] {
	if (!Array.isArray(raw)) return [];
	const out: { mime: string; text: string }[] = [];
	for (const o of raw) {
		if (!o || typeof o !== "object") continue;
		const type = (o as { output_type?: unknown }).output_type;
		if (type === "stream") {
			const name = (o as { name?: unknown }).name;
			const txt = (o as { text?: unknown }).text;
			const text = Array.isArray(txt)
				? txt.map((s) => String(s)).join("")
				: typeof txt === "string"
					? txt
					: "";
			const mime =
				name === "stderr"
					? "application/vnd.code.notebook.stderr"
					: "application/vnd.code.notebook.stdout";
			out.push({ mime, text });
			continue;
		}
		if (type === "error") {
			const ename = String((o as { ename?: unknown }).ename ?? "");
			const evalue = String((o as { evalue?: unknown }).evalue ?? "");
			const tb = (o as { traceback?: unknown }).traceback;
			const trace = Array.isArray(tb) ? tb.map((s) => String(s)).join("\n") : "";
			const text = [`${ename}: ${evalue}`, trace].filter((s) => s.length > 0).join("\n");
			out.push({ mime: "application/vnd.code.notebook.error", text });
			continue;
		}
		const data = (o as { data?: unknown }).data;
		if (data && typeof data === "object") {
			for (const [mime, value] of Object.entries(data as Record<string, unknown>)) {
				const text = Array.isArray(value)
					? value.map((s) => String(s)).join("")
					: typeof value === "string"
						? value
						: JSON.stringify(value);
				out.push({ mime, text });
			}
		}
	}
	return out;
}

export const readNotebookTool: ToolSpec = {
	name: "read_notebook",
	description:
		"Read a Jupyter notebook (.ipynb) and return its cells as a structured list. Use this instead of read_file for notebooks so you see cell boundaries, cell kinds (code/markdown), and (optionally) execution outputs. Returns a JSON object {cells: [{index, kind, language, source, outputs?}]}.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Path to the .ipynb file, relative to workspace root or absolute.",
			},
			includeOutputs: {
				type: "boolean",
				description:
					"When true, include each cell's execution outputs as `{mime,text}[]`. Defaults to false to keep payloads small.",
			},
		},
		required: ["path"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isReadNotebookArgs(args)) {
			throw new Error(
				"read_notebook: invalid args, expected { path: string; includeOutputs?: boolean }",
			);
		}
		const includeOutputs = args.includeOutputs === true;
		if (ctx.notebooks) {
			const cells = await ctx.notebooks.read(args.path, includeOutputs);
			return JSON.stringify({ cells });
		}
		// Fallback path: parse the on-disk JSON directly. Useful for non-VS Code
		// hosts and for unit tests that wire a plain HostContext.
		const raw = await ctx.readFile(args.path);
		const cells = parseNotebookJson(raw, includeOutputs);
		return JSON.stringify({ cells });
	},
};
