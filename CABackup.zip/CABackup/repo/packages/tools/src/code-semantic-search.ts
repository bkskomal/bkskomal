import { buildLexicalRegex, extractLexicalPatterns } from "@iom/codebase-index";
import type { ToolSpec } from "@iom/shared";

interface SemanticSearchArgs {
	readonly query: string;
	readonly k?: number;
	readonly extensions?: readonly string[];
}

function isSemanticSearchArgs(v: unknown): v is SemanticSearchArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as SemanticSearchArgs;
	if (typeof a.query !== "string") return false;
	if (a.k !== undefined && typeof a.k !== "number") return false;
	if (a.extensions !== undefined) {
		if (!Array.isArray(a.extensions)) return false;
		for (const e of a.extensions) if (typeof e !== "string") return false;
	}
	return true;
}

const DEFAULT_K = 8;
const MAX_K = 25;
/** Per-result snippet cap. Long matches get truncated so the agent's context window doesn't explode. */
const SNIPPET_CHAR_CAP = 600;
/**
 * Hard ceiling on lexical-side ripgrep matches we'll consider before
 * collapsing to file-level. The collapse keeps only one entry per file,
 * so 200 line-matches typically maps to ~30-60 distinct files — plenty
 * of breadth without burning latency. Past this, ripgrep is a sign the
 * query is too broad and the lexical signal is noise anyway.
 */
const LEXICAL_MATCH_CAP = 200;

/**
 * `code_semantic_search` — workspace-scoped code search.
 *
 * As of Phase 1.2 (2026-05-23) this tool is HYBRID by default. The
 * pipeline is:
 *
 *   1. **Semantic** — query the local embedding index (cosine over
 *      TF-IDF or your configured provider).
 *   2. **Lexical** (only when the query contains identifier-shaped
 *      tokens) — run ripgrep for the same query, OR'd across the
 *      extracted tokens.
 *   3. **Fuse** — Reciprocal Rank Fusion (RRF) merges the two
 *      rankings at the file level. A file appearing in BOTH gets
 *      amplified — this is the same gap-closing trick Cursor and
 *      Sourcegraph use.
 *
 * Pure-English queries ("where is auth validated") skip lexical and
 * fall through to pure semantic, so we don't waste a ripgrep call
 * matching English words against code. Identifier-shaped queries
 * ("find calls to authenticateUser") get the full hybrid treatment.
 *
 * Result format: a single human-readable string with one block per hit.
 * Text-not-JSON because the model's downstream summary is more useful
 * when it can see the snippets inline.
 */
// Description-policy reference:
// - Hybrid: semantic embeddings + literal ripgrep, blended via RRF.
// - Fallback to TF-IDF when provider doesn't expose embeddings (still
//   useful after /reindex).
// - Lexical signal only fires on identifier-shaped tokens (camelCase,
//   snake_case, quoted strings).
export const codeSemanticSearchTool: ToolSpec = {
	name: "code_semantic_search",
	description:
		"Hybrid semantic + lexical code search. Use BEFORE reading multiple files when you don't know exactly where the relevant code lives. Requires /reindex to be run once per workspace.",
	schema: {
		type: "object",
		properties: {
			query: {
				type: "string",
				description: "Natural-language description of what you're looking for.",
			},
			k: {
				type: "integer",
				description: `Max results. Default ${DEFAULT_K}, max ${MAX_K}.`,
			},
			extensions: {
				type: "array",
				description:
					"Optional list of file extensions to restrict the search to (e.g. ['ts','tsx']). Bare 'ts' or '.ts' both work.",
				items: { type: "string" },
			},
		},
		required: ["query"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<string> {
		if (!isSemanticSearchArgs(args)) {
			throw new Error("code_semantic_search: invalid args");
		}
		if (!ctx.codebaseIndex) {
			return (
				"code_semantic_search: no index available. " +
				"Run /reindex from the chat panel to build one, or check that " +
				"a workspace is open."
			);
		}
		const k = Math.min(Math.max(args.k ?? DEFAULT_K, 1), MAX_K);

		// Phase 1.2: build a ripgrep-backed lexical callback when the
		// query contains identifier-shaped tokens. Returning `undefined`
		// here means we don't even add the option to the call — semantic
		// path is unchanged. The callback itself is best-effort: if
		// ripgrep is missing or errors, the underlying RRF code falls
		// back to pure semantic gracefully (see codebase-index.query).
		const lexicalQuery = buildLexicalQueryCallback(args.query, args.extensions, ctx);

		// Phase 1.3: opt-in LLM-as-reranker layered on top of hybrid
		// retrieval. The host only exposes `rerankerLlmCall` when the
		// user has set `iom.codebaseIndex.rerank = true`; when present,
		// we pass it through so codebase-index can re-score the top
		// candidates with the active model. Skipped entirely otherwise
		// (no extra latency, no extra tokens).
		const rerank = ctx.rerankerLlmCall
			? { callLlm: ctx.rerankerLlmCall, maxCandidates: 20 }
			: undefined;

		const hits = await ctx.codebaseIndex.query(args.query, {
			k,
			...(args.extensions ? { filter: { extensions: args.extensions } } : {}),
			...(lexicalQuery ? { lexicalQuery } : {}),
			...(rerank ? { rerank } : {}),
		});
		if (hits.length === 0) {
			return `code_semantic_search: no matches for "${args.query}". The index may be empty — try /reindex.`;
		}
		const blocks = hits.map((h, i) => {
			const snippet =
				h.content.length > SNIPPET_CHAR_CAP
					? `${h.content.slice(0, SNIPPET_CHAR_CAP)}\n... (truncated)`
					: h.content;
			return [
				`### ${i + 1}. ${h.filePath}:${h.startLine}-${h.endLine}  (score=${h.score.toFixed(3)})`,
				"```",
				snippet,
				"```",
			].join("\n");
		});
		return blocks.join("\n\n");
	},
};

/**
 * Build the ripgrep-backed lexical callback for a query, or return
 * undefined when the query has no identifier-shaped tokens (in which
 * case we skip lexical entirely).
 *
 * The callback runs once per `query()` call. Cheap enough not to
 * memoize — ripgrep is typically <50ms even on large repos.
 */
function buildLexicalQueryCallback(
	query: string,
	extensions: readonly string[] | undefined,
	ctx: { exec: (cmd: string) => Promise<{ stdout: string; exitCode: number }> },
): ((q: string) => Promise<readonly LexicalSearchResult[]>) | undefined {
	const patterns = extractLexicalPatterns(query);
	const rgRegex = buildLexicalRegex(patterns);
	if (!rgRegex) return undefined;
	return async () => {
		const args: string[] = [
			"--json",
			"--no-heading",
			"--line-number",
			"--ignore-case",
			"--max-count",
			String(LEXICAL_MATCH_CAP),
		];
		if (extensions && extensions.length > 0) {
			for (const ext of extensions) {
				const clean = ext.replace(/^\./, "");
				args.push("--glob", `*.${clean}`);
			}
		}
		const cmd = `rg ${args.map(shellQuote).join(" ")} ${shellQuote(rgRegex)} .`;
		let out: { stdout: string; exitCode: number };
		try {
			out = await ctx.exec(cmd);
		} catch {
			// `exec` itself threw (process spawn failed). Best-effort: empty
			// lexical ranking, hybrid degrades to pure semantic.
			return [];
		}
		// rg exit 1 == no matches (still a successful run).
		if (out.exitCode !== 0 && out.exitCode !== 1) return [];
		return parseRipgrepJsonToSearchResults(out.stdout);
	};
}

interface LexicalSearchResult {
	readonly filePath: string;
	readonly startLine: number;
	readonly endLine: number;
	readonly content: string;
	readonly score: number;
}

/**
 * Parse ripgrep's `--json` stream into SearchResult-shaped objects so
 * the codebase-index's RRF merge can treat them on equal footing with
 * semantic hits. Each line becomes one result with startLine === endLine.
 *
 * Tolerant of malformed/event-only JSON lines (ripgrep emits `begin`
 * and `end` events alongside `match` events).
 */
function parseRipgrepJsonToSearchResults(stdout: string): LexicalSearchResult[] {
	const out: LexicalSearchResult[] = [];
	for (const raw of stdout.split("\n")) {
		const line = raw.trim();
		if (!line) continue;
		try {
			const ev = JSON.parse(line) as {
				type?: string;
				data?: {
					path?: { text?: string };
					line_number?: number;
					lines?: { text?: string };
				};
			};
			if (ev.type !== "match" || !ev.data) continue;
			const filePath = ev.data.path?.text ?? "";
			if (!filePath) continue;
			const lineNo = ev.data.line_number ?? 0;
			const text = (ev.data.lines?.text ?? "").trim().slice(0, 300);
			out.push({
				filePath: normalizeFilePath(filePath),
				startLine: lineNo,
				endLine: lineNo,
				content: text,
				// Score is unused by RRF (rank-only) but downstream
				// SearchResult shape requires it. Higher = earlier rank;
				// we use the negative index later, but here ripgrep
				// already emits results in file order, which preserves
				// per-file groupings for the collapse step.
				score: 1.0,
			});
		} catch {
			// ignore malformed lines
		}
	}
	return out;
}

/**
 * Strip the leading "./" ripgrep prepends when invoked with `.` as the
 * search root, so the path matches the form CodebaseIndex stores
 * (workspace-relative, no "./" prefix).
 */
function normalizeFilePath(p: string): string {
	if (p.startsWith("./") || p.startsWith(".\\")) return p.slice(2);
	return p;
}

function shellQuote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}
