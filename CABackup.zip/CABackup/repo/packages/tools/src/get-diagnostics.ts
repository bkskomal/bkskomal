// R4-B: get_diagnostics — surface the editor's LSP-reported errors,
// warnings, info, and hints to the agent so it can ground its decisions in
// the actual compiler/linter state instead of guessing from greps. Backed by
// `ctx.diagnostics` (the host's wrapper around `vscode.languages.getDiagnostics`).
import type { DiagnosticEntry, ToolSpec } from "@iom/shared";

const DEFAULT_MAX = 50;
const SEVERITY_VALUES = ["error", "warning", "info", "hint"] as const;
type Severity = (typeof SEVERITY_VALUES)[number];

interface GetDiagnosticsArgs {
	readonly path?: string;
	readonly severity?: readonly Severity[];
	readonly max?: number;
}

function isSeverity(v: unknown): v is Severity {
	return typeof v === "string" && (SEVERITY_VALUES as readonly string[]).includes(v);
}

function isGetDiagnosticsArgs(v: unknown): v is GetDiagnosticsArgs {
	if (v === undefined || v === null) return true;
	if (typeof v !== "object") return false;
	const a = v as GetDiagnosticsArgs;
	if (a.path !== undefined && typeof a.path !== "string") return false;
	if (a.max !== undefined && typeof a.max !== "number") return false;
	if (a.severity !== undefined) {
		if (!Array.isArray(a.severity)) return false;
		if (!a.severity.every(isSeverity)) return false;
	}
	return true;
}

/**
 * `get_diagnostics` — workspace-scoped (or file-scoped) snapshot of LSP
 * diagnostics. Truncates at `max ?? 50` entries so a project with thousands
 * of TS errors doesn't blow the agent's context window. The full count is
 * always reported alongside the (possibly truncated) items so the agent knows
 * when it's only seeing a subset.
 */
export const getDiagnosticsTool: ToolSpec = {
	name: "get_diagnostics",
	description:
		"Read the editor's current LSP diagnostics (errors, warnings, info, hints) — the same squiggles you'd see in the gutter. Optionally filter by workspace-relative path and/or severity. Use this before refactoring to ground decisions in real compiler/linter output rather than guessing. Returns a JSON object {count, items, truncated}; items are 1-based line/column.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description:
					"Optional file to filter to. Relative to workspace root, or absolute. Omit to read the whole workspace.",
			},
			severity: {
				type: "array",
				items: { type: "string", enum: ["error", "warning", "info", "hint"] },
				description: "Optional severity filter. Omit for all severities.",
			},
			max: {
				type: "integer",
				description: "Cap on returned items (defaults to 50; set higher for a bigger sample).",
			},
		},
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx) {
		if (!isGetDiagnosticsArgs(args)) {
			throw new Error(
				'get_diagnostics: invalid args, expected { path?: string; severity?: ("error"|"warning"|"info"|"hint")[]; max?: number }',
			);
		}
		if (!ctx.diagnostics) {
			return JSON.stringify({
				count: 0,
				items: [],
				truncated: false,
				note: "get_diagnostics: no diagnostics bridge available in this host.",
			});
		}
		const opts: { path?: string; severity?: Severity[] } = {};
		if (args?.path) opts.path = args.path;
		if (args?.severity && args.severity.length > 0) opts.severity = [...args.severity];
		const all = await ctx.diagnostics.all(opts);
		const cap = Math.max(1, args?.max ?? DEFAULT_MAX);
		const items: DiagnosticEntry[] = all.slice(0, cap);
		const payload = {
			count: all.length,
			items,
			truncated: all.length > items.length,
		};
		return JSON.stringify(payload);
	},
};
