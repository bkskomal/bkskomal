// R6-E: debug_set_breakpoint — add a source breakpoint at `path:line`.
// Backed by `ctx.debug.setBreakpoint`, which wraps
// `vscode.debug.addBreakpoints(new SourceBreakpoint(...))`. Approval is
// "prompt" because adding a breakpoint can pause the user's running
// program and change the meaning of "step over" in their debugger.
// TODO(r6-merge): register in tools/src/registry.ts and re-export from tools/src/index.ts
import type { ToolSpec } from "@iom/shared";

interface DebugSetBreakpointArgs {
	readonly path: string;
	readonly line: number;
	readonly condition?: string;
}

function isDebugSetBreakpointArgs(v: unknown): v is DebugSetBreakpointArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as DebugSetBreakpointArgs;
	if (typeof a.path !== "string" || a.path.length === 0) return false;
	if (typeof a.line !== "number" || a.line < 1) return false;
	if (a.condition !== undefined && typeof a.condition !== "string") return false;
	return true;
}

export const debugSetBreakpointTool: ToolSpec = {
	name: "debug_set_breakpoint",
	description:
		"Add a source breakpoint at the given path:line (1-based). Optionally make it conditional by passing a `condition` expression — execution will only halt when the expression is truthy. Returns 'ok' or a friendly error message. Approval-gated because this affects the user's debug session behavior.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Workspace-relative or absolute path to the source file.",
			},
			line: {
				type: "integer",
				description: "1-based line number to halt on.",
			},
			condition: {
				type: "string",
				description: "Optional conditional expression; the breakpoint only fires when it's truthy.",
			},
		},
		required: ["path", "line"],
		additionalProperties: false,
	},
	approval: "prompt",
	async handler(args, ctx) {
		if (!isDebugSetBreakpointArgs(args)) {
			throw new Error(
				"debug_set_breakpoint: invalid args, expected { path: string; line: number; condition?: string }",
			);
		}
		if (!ctx.debug) {
			return "debug_set_breakpoint: no debug bridge in this host.";
		}
		try {
			await ctx.debug.setBreakpoint(args.path, args.line, args.condition, true);
			return `ok — breakpoint set at ${args.path}:${args.line}${args.condition ? ` (when ${args.condition})` : ""}`;
		} catch (err) {
			return `debug_set_breakpoint: error — ${err instanceof Error ? err.message : String(err)}`;
		}
	},
};
