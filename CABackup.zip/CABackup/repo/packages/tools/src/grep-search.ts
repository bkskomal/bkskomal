import type { ToolSpec } from "@iom/shared";

interface GrepArgs {
	readonly pattern: string;
	readonly path?: string;
	readonly case_sensitive?: boolean;
	readonly max_matches?: number;
	readonly glob?: string;
}

function isGrepArgs(v: unknown): v is GrepArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as GrepArgs;
	if (typeof a.pattern !== "string") return false;
	if (a.path !== undefined && typeof a.path !== "string") return false;
	if (a.case_sensitive !== undefined && typeof a.case_sensitive !== "boolean") return false;
	if (a.max_matches !== undefined && typeof a.max_matches !== "number") return false;
	if (a.glob !== undefined && typeof a.glob !== "string") return false;
	return true;
}

interface GrepMatch {
	readonly file: string;
	readonly line: number;
	readonly text: string;
}

interface GrepResult {
	readonly pattern: string;
	readonly matches: readonly GrepMatch[];
	readonly truncated: boolean;
}

const DEFAULT_LIMIT = 200;
const MAX_LIMIT = 1000;

export const grepSearchTool: ToolSpec = {
	name: "grep_search",
	description:
		"Regex search across workspace files. Returns file:line:text for each match (capped). Uses ripgrep if available, otherwise falls back to a Node scan.",
	schema: {
		type: "object",
		properties: {
			pattern: { type: "string", description: "Regex pattern to search for." },
			path: {
				type: "string",
				description: "Directory or file to search in. Defaults to workspace root.",
			},
			case_sensitive: {
				type: "boolean",
				description: "Case-sensitive match. Default false.",
			},
			max_matches: {
				type: "integer",
				description: `Hard cap on returned matches. Default ${DEFAULT_LIMIT}, max ${MAX_LIMIT}.`,
			},
			glob: {
				type: "string",
				description: "Optional glob pattern to filter files (e.g. '*.ts', '**/*.{js,tsx}').",
			},
		},
		required: ["pattern"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args, ctx): Promise<GrepResult> {
		if (!isGrepArgs(args)) throw new Error("grep_search: invalid args");
		const cap = Math.min(args.max_matches ?? DEFAULT_LIMIT, MAX_LIMIT);
		const path = args.path ?? ".";

		// Try ripgrep first — it's usually 100x faster and present on most dev machines.
		const rgArgs: string[] = ["--json", "--no-heading", "--line-number", "--max-count", String(cap)];
		if (!args.case_sensitive) rgArgs.push("--ignore-case");
		if (args.glob) {
			rgArgs.push("--glob", args.glob);
		}
		const rgCmd = `rg ${rgArgs.map(shellQuote).join(" ")} ${shellQuote(args.pattern)} ${shellQuote(path)}`;
		const rg = await ctx.exec(rgCmd);
		if (rg.exitCode === 0 || rg.exitCode === 1) {
			// rg exit 1 == no matches (still a success)
			const matches = parseRipgrepJson(rg.stdout, cap);
			return { pattern: args.pattern, matches, truncated: matches.length >= cap };
		}

		// Fallback: Node scan (slower but always works)
		const flag = args.case_sensitive ? "" : "i";
		const pattern = args.pattern.replace(/'/g, "\\'");
		const script = `
const fs=require('fs');const path=require('path');
const re=new RegExp(${JSON.stringify(pattern)},'${flag}');
const cap=${cap};const out=[];
function walk(d){if(out.length>=cap)return;let es;try{es=fs.readdirSync(d,{withFileTypes:true})}catch{return}
for(const e of es){if(out.length>=cap)break;if(e.name.startsWith('.git')||e.name==='node_modules')continue;
const p=path.join(d,e.name);if(e.isDirectory())walk(p);else{let txt;try{txt=fs.readFileSync(p,'utf8')}catch{continue}
const lines=txt.split('\\n');for(let i=0;i<lines.length;i++){if(re.test(lines[i])){
out.push({file:path.relative(${JSON.stringify(path)},p).replace(/\\\\/g,'/'),line:i+1,text:lines[i].slice(0,300)});
if(out.length>=cap)break}}}}}
walk(${JSON.stringify(path)});
console.log(JSON.stringify({matches:out}));`;
		const fb = await ctx.exec(`node -e ${shellQuote(script.trim())}`);
		if (fb.exitCode !== 0) {
			throw new Error(`grep_search failed: ${fb.stderr || fb.stdout}`);
		}
		try {
			const parsed = JSON.parse(fb.stdout) as { matches: GrepMatch[] };
			return {
				pattern: args.pattern,
				matches: parsed.matches,
				truncated: parsed.matches.length >= cap,
			};
		} catch {
			throw new Error("grep_search: failed to parse fallback output");
		}
	},
};

function parseRipgrepJson(stdout: string, cap: number): GrepMatch[] {
	const out: GrepMatch[] = [];
	for (const line of stdout.split("\n")) {
		if (out.length >= cap) break;
		const trimmed = line.trim();
		if (!trimmed) continue;
		try {
			const ev = JSON.parse(trimmed) as {
				type?: string;
				data?: {
					path?: { text?: string };
					line_number?: number;
					lines?: { text?: string };
				};
			};
			if (ev.type === "match" && ev.data) {
				out.push({
					file: ev.data.path?.text ?? "",
					line: ev.data.line_number ?? 0,
					text: (ev.data.lines?.text ?? "").trim().slice(0, 300),
				});
			}
		} catch {
			// ignore malformed lines
		}
	}
	return out;
}

function shellQuote(s: string): string {
	if (process.platform === "win32") return `"${s.replace(/"/g, '\\"')}"`;
	return `'${s.replace(/'/g, "'\\''")}'`;
}
