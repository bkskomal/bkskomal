// R8-A: `predict_next_edit_location` tool.
//
// Lets the agent ask the host "given the file the user is currently editing
// (or a supplied file + offset), where is the next likely edit going to
// happen?". Useful for proactive UI: the agent can pre-open the next file or
// flag "you'll probably want to update line 87 too".
//
// Approval is `auto` because the tool is purely read-only — it inspects file
// contents the agent already has access to via `read_file` and never mutates
// anything.

import type { ToolSpec } from "@iom/shared";

interface PredictNextEditArgs {
	/** Document text to scan. If omitted, the agent should call `read_file` first. */
	readonly documentText: string;
	/** 0-based cursor offset to scan forward from. */
	readonly currentOffset: number;
	/** Language id for picking comment-style placeholder regexes. */
	readonly languageId?: string;
	/** Optional cap on bytes to scan ahead. Defaults to 4096. */
	readonly scanBudgetBytes?: number;
}

function isPredictNextEditArgs(v: unknown): v is PredictNextEditArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as Record<string, unknown>;
	if (typeof a.documentText !== "string") return false;
	if (typeof a.currentOffset !== "number") return false;
	if (a.languageId !== undefined && typeof a.languageId !== "string") return false;
	if (a.scanBudgetBytes !== undefined && typeof a.scanBudgetBytes !== "number") return false;
	return true;
}

// Re-implemented here (pure, no host deps) so the tool runs in headless / CLI
// hosts that don't load `@iom/extension-host`. The extension-host module has
// its own copy that drives the live cursor jump.
const PLACEHOLDER_MARKERS: readonly string[] = [
	"<TODO>",
	"<FIXME>",
	"<CURSOR>",
	"<HERE>",
	"<todo>",
	"<fixme>",
	"<cursor>",
	"<here>",
];
const NOT_IMPLEMENTED_SNIPPETS: readonly string[] = [
	'throw new Error("Not implemented")',
	"throw new Error('Not implemented')",
	"raise NotImplementedError",
	"unimplemented!()",
	"todo!()",
];
const TODO_COMMENT_BY_LANGUAGE: Record<string, readonly RegExp[]> = {
	python: [/^\s*#\s*(TODO|FIXME)\b/m, /^\s*pass\s*$/m],
	ruby: [/^\s*#\s*(TODO|FIXME)\b/m],
	shellscript: [/^\s*#\s*(TODO|FIXME)\b/m],
};
const DEFAULT_TODO_REGEXES: readonly RegExp[] = [
	/^\s*\/\/\s*(TODO|FIXME)\b/m,
	/^\s*\/\*\s*(TODO|FIXME)\b/m,
];

interface Hit {
	offset: number;
	reason: string;
	marker: string;
}

function predict(args: PredictNextEditArgs): Hit {
	const text = args.documentText;
	const start = Math.max(0, Math.min(text.length, args.currentOffset));
	const budget = args.scanBudgetBytes ?? 4096;
	const window = text.slice(start, Math.min(text.length, start + budget));

	let best: Hit | undefined;
	const consider = (idx: number, reason: string, marker: string): void => {
		if (idx < 0) return;
		if (!best || idx < best.offset - start) {
			best = { offset: start + idx, reason, marker };
		}
	};

	for (const m of PLACEHOLDER_MARKERS) {
		const idx = window.indexOf(m);
		if (idx >= 0) consider(idx, "placeholder_marker", m);
	}
	for (const m of NOT_IMPLEMENTED_SNIPPETS) {
		const idx = window.indexOf(m);
		if (idx >= 0) consider(idx, "not_implemented", m);
	}
	const id = (args.languageId ?? "").toLowerCase();
	const regexes = TODO_COMMENT_BY_LANGUAGE[id] ?? DEFAULT_TODO_REGEXES;
	for (const re of regexes) {
		const match = re.exec(window);
		if (match) {
			const reason = /^\s*pass\s*$/.test(match[0]) ? "pass_keyword" : "todo_comment";
			consider(match.index, reason, match[0].trim());
		}
	}
	if (best) return best;

	// Fallback: start of the next non-empty line below the cursor.
	let i = start;
	while (i < text.length && text.charCodeAt(i) !== 10) i++;
	while (i < text.length) {
		if (text.charCodeAt(i) === 10) i++;
		let lineEnd = i;
		while (lineEnd < text.length && text.charCodeAt(lineEnd) !== 10) lineEnd++;
		const candidate = text.slice(i, lineEnd);
		if (candidate.trim().length > 0) {
			let lead = 0;
			while (lead < candidate.length && /\s/.test(candidate[lead])) lead++;
			return { offset: i + lead, reason: "next_nonempty_line", marker: "" };
		}
		i = lineEnd;
	}
	return { offset: text.length, reason: "end_of_document", marker: "" };
}

export const predictNextEditLocationTool: ToolSpec = {
	name: "predict_next_edit_location",
	description:
		"R8-A: predict where the user's next edit is likely to happen given the current file contents and cursor offset. Scans ahead for placeholder markers (<TODO>, <FIXME>, <CURSOR>), TODO/FIXME comments, `pass` / `unimplemented!()` sentinels, and falls back to the next non-empty line. Returns {offset, reason, marker}. Pure heuristic — no model call. Useful when proposing a sequence of related edits.",
	schema: {
		type: "object",
		properties: {
			documentText: {
				type: "string",
				description: "Full text of the file to scan.",
			},
			currentOffset: {
				type: "number",
				description: "0-based byte offset to start scanning from (typically the cursor position).",
			},
			languageId: {
				type: "string",
				description:
					"Language id (typescript, python, rust, etc.) — picks the right comment-style regex.",
			},
			scanBudgetBytes: {
				type: "number",
				description: "Optional cap on bytes scanned ahead. Defaults to 4096.",
			},
		},
		required: ["documentText", "currentOffset"],
		additionalProperties: false,
	},
	approval: "auto",
	async handler(args): Promise<unknown> {
		if (!isPredictNextEditArgs(args)) {
			throw new Error(
				"predict_next_edit_location: invalid args — expected { documentText: string, currentOffset: number }",
			);
		}
		const hit = predict(args);
		return JSON.stringify(hit);
	},
};
