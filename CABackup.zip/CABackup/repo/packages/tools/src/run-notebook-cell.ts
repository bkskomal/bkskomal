// R6-B: run_notebook_cell — execute a single cell in a Jupyter notebook and
// return its outputs once execution settles. Backed by `ctx.notebooks.runCell`,
// which wraps `vscode.commands.executeCommand("notebook.cell.execute", …)`.
// Approval is `"prompt"` because this literally runs user code in whichever
// kernel is attached to the notebook.
import type { ToolSpec } from "@iom/shared";

interface RunNotebookCellArgs {
	readonly path: string;
	readonly index: number;
}

function isRunNotebookCellArgs(v: unknown): v is RunNotebookCellArgs {
	if (typeof v !== "object" || v === null) return false;
	const a = v as RunNotebookCellArgs;
	return typeof a.path === "string" && typeof a.index === "number" && Number.isFinite(a.index);
}

export const runNotebookCellTool: ToolSpec = {
	name: "run_notebook_cell",
	description:
		"Execute a single cell in a Jupyter notebook (.ipynb) using the notebook's attached kernel and return its outputs. Identified by 0-based index. Requires approval since this runs arbitrary code. Returns a JSON object {outputs: [{mime, text}]}.",
	schema: {
		type: "object",
		properties: {
			path: {
				type: "string",
				description: "Path to the .ipynb file, relative to workspace root or absolute.",
			},
			index: {
				type: "integer",
				description: "0-based cell index to execute.",
			},
		},
		required: ["path", "index"],
		additionalProperties: false,
	},
	approval: "prompt",
	async prepareApprovalPreview(args) {
		if (!isRunNotebookCellArgs(args)) return {};
		return {
			note: `Execute cell ${args.index} of ${args.path} in its attached Jupyter kernel.`,
		};
	},
	async handler(args, ctx) {
		if (!isRunNotebookCellArgs(args)) {
			throw new Error("run_notebook_cell: invalid args, expected { path: string; index: number }");
		}
		if (!ctx.notebooks) {
			throw new Error(
				"run_notebook_cell: this host has no notebook bridge — open the .ipynb in VS Code first.",
			);
		}
		const outputs = await ctx.notebooks.runCell(args.path, args.index);
		return JSON.stringify({ outputs });
	},
};
