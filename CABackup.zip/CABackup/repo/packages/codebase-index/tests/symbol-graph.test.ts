import type { DocumentSymbol, SymbolHit, SymbolLookupProvider } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { buildSymbolGraphHop, symbolGraphBoost } from "../src/symbol-graph";

/**
 * Build a `SymbolLookupProvider` that drives off a small synthetic graph.
 *
 * The graph here is a hand-rolled adjacency map: for each (path, line, char)
 * key we record the references and definitions that should be returned. The
 * test then asserts the hop expansion lines up with that adjacency.
 */
function makeFakeSymbols(graph: {
	references?: Readonly<Record<string, readonly SymbolHit[]>>;
	definitions?: Readonly<Record<string, readonly SymbolHit[]>>;
}): SymbolLookupProvider {
	const key = (p: string, l: number, c: number) => `${p}:${l}:${c}`;
	return {
		async findReferences(path, line, character) {
			return graph.references?.[key(path, line, character)] ?? [];
		},
		async findDefinition(path, line, character) {
			return graph.definitions?.[key(path, line, character)] ?? [];
		},
		async documentSymbols(_path): Promise<readonly DocumentSymbol[]> {
			return [];
		},
	};
}

describe("buildSymbolGraphHop", () => {
	it("returns an empty neighbor set when no provider is supplied", async () => {
		const hop = await buildSymbolGraphHop(undefined, "a.ts", 1, 0, "foo");
		expect(hop.available).toBe(false);
		expect([...hop.neighbors]).toEqual([]);
	});

	it("collects references and definitions into a deduped neighbor set", async () => {
		const symbols = makeFakeSymbols({
			references: {
				"src/auth/login.ts:10:5": [
					{ path: "src/auth/session.ts", line: 4, snippet: "validate(...)" },
					{ path: "src/api/login-route.ts", line: 22, snippet: "validate(...)" },
					// Self-references should be filtered out — they don't help re-rank.
					{ path: "src/auth/login.ts", line: 99, snippet: "validate(...)" },
				],
			},
			definitions: {
				"src/auth/login.ts:10:5": [
					{ path: "src/auth/validators.ts", line: 1, snippet: "export function validate" },
					// Already present from references → set semantics dedupes.
					{ path: "src/auth/session.ts", line: 4, snippet: "..." },
				],
			},
		});

		const hop = await buildSymbolGraphHop(symbols, "src/auth/login.ts", 10, 5, "validate");
		expect(hop.available).toBe(true);
		expect(hop.seedSymbol).toBe("validate");
		const sorted = [...hop.neighbors].sort();
		expect(sorted).toEqual([
			"src/api/login-route.ts",
			"src/auth/session.ts",
			"src/auth/validators.ts",
		]);
	});

	it("normalizes backslash paths so Windows-style hits match Unix-style queries", async () => {
		const symbols = makeFakeSymbols({
			references: {
				"src/auth/login.ts:1:0": [{ path: "src\\auth\\session.ts", line: 4, snippet: "x" }],
			},
		});
		const hop = await buildSymbolGraphHop(symbols, "src/auth/login.ts", 1, 0, "validate");
		expect(hop.neighbors.has("src/auth/session.ts")).toBe(true);
	});

	it("tolerates provider exceptions on either edge type", async () => {
		const symbols: SymbolLookupProvider = {
			async findReferences() {
				throw new Error("LSP not ready");
			},
			async findDefinition() {
				return [{ path: "src/auth/validators.ts", line: 1, snippet: "" }];
			},
			async documentSymbols() {
				return [];
			},
		};
		const hop = await buildSymbolGraphHop(symbols, "src/auth/login.ts", 1, 0, "validate");
		expect(hop.available).toBe(true);
		expect([...hop.neighbors]).toEqual(["src/auth/validators.ts"]);
	});
});

describe("symbolGraphBoost", () => {
	it("returns 1 when the neighbor set is empty (no-op)", () => {
		expect(symbolGraphBoost("src/foo.ts", new Set())).toBe(1);
	});

	it("returns factor for paths inside the neighbor set", () => {
		const neighbors = new Set(["src/auth/session.ts"]);
		expect(symbolGraphBoost("src/auth/session.ts", neighbors)).toBeCloseTo(1.2);
		// Custom factor wins over default.
		expect(symbolGraphBoost("src/auth/session.ts", neighbors, 1.5)).toBeCloseTo(1.5);
	});

	it("returns 1 for paths not in the neighbor set", () => {
		const neighbors = new Set(["src/auth/session.ts"]);
		expect(symbolGraphBoost("src/billing/charge.ts", neighbors)).toBe(1);
	});

	it("normalizes backslashes before matching", () => {
		const neighbors = new Set(["src/auth/session.ts"]);
		expect(symbolGraphBoost("src\\auth\\session.ts", neighbors)).toBeCloseTo(1.2);
	});
});
