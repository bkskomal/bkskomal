// R8-B: Embedder factory barrel.
//
// Single entry point for the host to construct any embedder by id. Keeps
// per-provider knobs (model overrides, base-URL overrides) optional so the
// caller can stay terse for the common case.

import { CohereEmbedder, createCohereEmbedder } from "./cohere";
import { OpenAIEmbedder, createOpenAIEmbedder } from "./openai";
import type { EmbedderId, EmbedderProvider, GetSecret } from "./registry";
import { EMBEDDER_CATALOG, EMBEDDER_IDS, SECRET_KEYS, getCatalogEntry } from "./registry";
import { TfIdfEmbedderProvider, createTfIdfEmbedder } from "./tfidf";
import { VoyageEmbedder, createVoyageEmbedder } from "./voyage";

export type { EmbedderProvider, EmbedderId, GetSecret, EmbedderCatalogEntry } from "./registry";
export { EMBEDDER_CATALOG, EMBEDDER_IDS, SECRET_KEYS, getCatalogEntry };
export {
	CohereEmbedder,
	OpenAIEmbedder,
	TfIdfEmbedderProvider,
	VoyageEmbedder,
	createCohereEmbedder,
	createOpenAIEmbedder,
	createTfIdfEmbedder,
	createVoyageEmbedder,
};

export interface CreateEmbedderOptions {
	readonly id: EmbedderId;
	readonly getSecret: GetSecret;
	/** Optional override for the provider's default model (e.g. `text-embedding-3-large`). */
	readonly model?: string;
	/** Optional override for the dimension (some providers support truncated dims). */
	readonly dimensions?: number;
	/** Optional override for the provider's base URL (proxies / Azure). */
	readonly baseUrl?: string;
	/** Test seam — replaces global fetch when set. */
	readonly fetchImpl?: typeof fetch;
}

/**
 * Construct an EmbedderProvider by id. The host calls this on activation and
 * whenever the `iom.codebaseIndex.embedder` setting changes; the returned
 * provider is then handed to a fresh CodebaseIndex.
 */
export function createEmbedder(opts: CreateEmbedderOptions): EmbedderProvider {
	switch (opts.id) {
		case "tfidf":
			return createTfIdfEmbedder(opts.dimensions);
		case "openai":
			return createOpenAIEmbedder({
				model: opts.model,
				dimensions: opts.dimensions,
				baseUrl: opts.baseUrl,
				getSecret: opts.getSecret,
				...(opts.fetchImpl ? { fetchImpl: opts.fetchImpl } : {}),
			});
		case "voyage":
			return createVoyageEmbedder({
				model: opts.model,
				dimensions: opts.dimensions,
				baseUrl: opts.baseUrl,
				getSecret: opts.getSecret,
				...(opts.fetchImpl ? { fetchImpl: opts.fetchImpl } : {}),
			});
		case "cohere":
			return createCohereEmbedder({
				model: opts.model,
				dimensions: opts.dimensions,
				baseUrl: opts.baseUrl,
				getSecret: opts.getSecret,
				...(opts.fetchImpl ? { fetchImpl: opts.fetchImpl } : {}),
			});
	}
}
