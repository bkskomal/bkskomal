// R8-B: OpenAI embeddings provider.
//
// Calls `POST https://api.openai.com/v1/embeddings` with the standard
// OpenAI payload `{ model, input, dimensions? }` and parses the
// `{ data: [{ embedding: number[] }, ...] }` response. The result vectors
// are L2-normalized so the index's cosine math == dot product.
//
// Why not reuse the existing `OpenAICompatEmbedder` from `../embedder.ts`?
//   - It hard-codes the dimension fallback to 1536 and doesn't expose `id`
//     / `displayName` for the picker.
//   - Here we want a provider object the host can construct purely from a
//     `GetSecret` callback, with the OpenAI-specific defaults baked in
//     (model, base URL, dimension) so the rest of the system doesn't need to
//     know which API it's talking to.

import { l2Normalize } from "../embedder";
import type { EmbedderProvider, GetSecret } from "./registry";
import { SECRET_KEYS } from "./registry";

export interface OpenAIEmbedderOptions {
	readonly model?: string;
	readonly dimensions?: number;
	readonly baseUrl?: string;
	readonly getSecret: GetSecret;
	readonly fetchImpl?: typeof fetch;
}

interface OpenAIEmbeddingsResponse {
	readonly data?: readonly { readonly embedding: readonly number[] }[];
	readonly error?: { readonly message?: string };
}

const DEFAULT_MODEL = "text-embedding-3-small";
const DEFAULT_DIMENSIONS = 1536;
const DEFAULT_BASE_URL = "https://api.openai.com/v1";

export class OpenAIEmbedder implements EmbedderProvider {
	readonly id = "openai";
	readonly displayName: string;
	readonly dimensions: number;
	readonly dim: number;
	private readonly model: string;
	private readonly url: string;
	private readonly getSecret: GetSecret;
	private readonly fetchImpl: typeof fetch;
	private cachedKey: string | undefined;

	constructor(opts: OpenAIEmbedderOptions) {
		this.model = opts.model ?? DEFAULT_MODEL;
		this.dimensions = opts.dimensions ?? DEFAULT_DIMENSIONS;
		this.dim = this.dimensions;
		this.displayName = `OpenAI ${this.model}`;
		const base = (opts.baseUrl ?? DEFAULT_BASE_URL).replace(/\/$/, "");
		this.url = `${base}/embeddings`;
		this.getSecret = opts.getSecret;
		this.fetchImpl = opts.fetchImpl ?? fetch;
	}

	private async resolveKey(): Promise<string> {
		if (this.cachedKey) return this.cachedKey;
		const k = await this.getSecret(SECRET_KEYS.openai);
		if (!k) {
			throw new Error(
				"OpenAI embedder: API key not set. Run `iOmCode: Set Codebase Embedder API Key` to configure it.",
			);
		}
		this.cachedKey = k;
		return k;
	}

	async embed(texts: readonly string[]): Promise<readonly Float32Array[]> {
		if (texts.length === 0) return [];
		const apiKey = await this.resolveKey();
		const body: Record<string, unknown> = {
			model: this.model,
			input: [...texts],
			// `text-embedding-3-*` supports a `dimensions` knob; older models
			// (ada-002) reject it. We always send it for v3 models; callers
			// who want to talk to ada-002 should construct the embedder
			// directly via the lower-level `OpenAICompatEmbedder`.
			dimensions: this.dimensions,
			encoding_format: "float",
		};
		const res = await this.fetchImpl(this.url, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`,
			},
			body: JSON.stringify(body),
		});
		if (!res.ok) {
			let detail = "";
			try {
				detail = (await res.text()).slice(0, 200);
			} catch {
				/* swallow */
			}
			throw new Error(`OpenAI embeddings failed (${res.status}): ${detail}`);
		}
		const json = (await res.json()) as OpenAIEmbeddingsResponse;
		if (json.error?.message) {
			throw new Error(`OpenAI embeddings error: ${json.error.message}`);
		}
		if (!json.data || json.data.length !== texts.length) {
			throw new Error(
				`OpenAI embeddings: expected ${texts.length} vectors, got ${json.data?.length ?? 0}`,
			);
		}
		return json.data.map((d) => {
			const arr = new Float32Array(d.embedding.length);
			for (let i = 0; i < d.embedding.length; i++) arr[i] = d.embedding[i];
			l2Normalize(arr);
			return arr;
		});
	}
}

export function createOpenAIEmbedder(opts: OpenAIEmbedderOptions): OpenAIEmbedder {
	return new OpenAIEmbedder(opts);
}
