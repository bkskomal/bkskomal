// R8-B: Pluggable embedder provider registry.
//
// Closes the gap with Cursor / Copilot / Cline / Continue by letting the
// codebase-index swap its embedding backend at runtime. The existing
// `Embedder` interface (in `../embedder.ts`) is too thin for a UI to reason
// about because it only carries `dim`; this richer interface adds an id,
// display name, and explicit `dimensions` field so the host can persist the
// active embedder, label the header chip, and warn on dim mismatches without
// invoking `.embed()`.
//
// Concrete providers live in sibling files (openai.ts, voyage.ts, cohere.ts,
// tfidf.ts). They are intentionally framework-agnostic: API keys arrive via a
// `getSecret(key)` callback so the embedders don't depend on `vscode`. The
// extension-host owns the `vscode.SecretStorage` plumbing and passes the
// resolved key through; tests pass a stub.

import type { Embedder } from "../embedder";

/**
 * Pluggable embedder provider. Extends the existing thin `Embedder` interface
 * with metadata the UI/host needs:
 *   - `id` — stable identifier persisted to the SQLite `meta` table; used by
 *     the dim-mismatch check on startup.
 *   - `displayName` — human-readable string shown in the webview header chip
 *     (e.g. "OpenAI text-embedding-3-small").
 *   - `dimensions` — vector length; same value as `Embedder.dim` but exposed
 *     here so callers don't have to reach into the underlying object.
 *
 * Implementations remain `Embedder`-compatible so existing call sites
 * (CodebaseIndex, the host's CodebaseIndexManager) continue to work unchanged.
 */
export interface EmbedderProvider extends Embedder {
	readonly id: string;
	readonly displayName: string;
	readonly dimensions: number;
	embed(texts: readonly string[]): Promise<readonly Float32Array[]>;
}

/**
 * Secret resolver passed into each `createXxxEmbedder` factory so the embedder
 * can fetch its API key from `vscode.SecretStorage` (or a test stub) without
 * importing `vscode` directly. Returning `undefined` means the key is not set;
 * the embedder throws on its first call so we surface a clear error rather
 * than silently producing junk vectors.
 */
export type GetSecret = (key: string) => Promise<string | undefined>;

/** Canonical ids for the bundled embedder providers. */
export type EmbedderId = "tfidf" | "openai" | "voyage" | "cohere";

export const EMBEDDER_IDS: readonly EmbedderId[] = ["tfidf", "openai", "voyage", "cohere"];

/** Per-provider secret-storage keys. Documented here so the host stays in sync. */
export const SECRET_KEYS = {
	openai: "iom.codebaseIndex.openai.apiKey",
	voyage: "iom.codebaseIndex.voyage.apiKey",
	cohere: "iom.codebaseIndex.cohere.apiKey",
} as const;

/**
 * Static catalog of supported embedder providers. The host uses this to label
 * the picker in Settings; the webview reads it (indirectly via the embedder
 * pill) to show the active provider. Dimensions are the model defaults — when
 * a user picks a non-default model the actual `dimensions` may differ; that's
 * fine, the SQLite `meta` table is the source of truth.
 */
export interface EmbedderCatalogEntry {
	readonly id: EmbedderId;
	readonly displayName: string;
	readonly defaultModel: string;
	readonly defaultDimensions: number;
	readonly requiresApiKey: boolean;
}

export const EMBEDDER_CATALOG: readonly EmbedderCatalogEntry[] = [
	{
		id: "tfidf",
		displayName: "Local TF-IDF (offline)",
		defaultModel: "tfidf-hash-256",
		defaultDimensions: 256,
		requiresApiKey: false,
	},
	{
		id: "openai",
		displayName: "OpenAI text-embedding-3-small",
		defaultModel: "text-embedding-3-small",
		defaultDimensions: 1536,
		requiresApiKey: true,
	},
	{
		id: "voyage",
		displayName: "Voyage voyage-code-3",
		defaultModel: "voyage-code-3",
		defaultDimensions: 1024,
		requiresApiKey: true,
	},
	{
		id: "cohere",
		displayName: "Cohere embed-english-v3.0",
		defaultModel: "embed-english-v3.0",
		defaultDimensions: 1024,
		requiresApiKey: true,
	},
];

export function getCatalogEntry(id: EmbedderId): EmbedderCatalogEntry {
	const entry = EMBEDDER_CATALOG.find((e) => e.id === id);
	if (!entry) throw new Error(`Unknown embedder id: ${id}`);
	return entry;
}
