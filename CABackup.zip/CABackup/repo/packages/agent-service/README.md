# @iom/agent-service

Standalone HTTP+SSE wrapper around `@iom/agent-core`. Lets non-Node IDE shells (Microsoft Visual Studio, JetBrains, future CLIs) drive the same agent loop without re-implementing it in their host language.

## Architecture

```
┌──────────────────────────┐         HTTP+SSE          ┌─────────────────────────────┐
│  IDE shell (any lang)    │ ────────────────────────> │  iom-service (Node)        │
│  e.g. VS extension (C#)  │ <─── agent events ─────── │   ├─ @iom/agent-core       │
│       JetBrains (Kotlin) │   POST /v1/agent/run      │   ├─ @iom/providers        │
│       CLI                │                           │   ├─ @iom/tools            │
└──────────────────────────┘                           │   └─ NodeHostContext (fs)   │
                                                       └─────────────────────────────┘
```

The IDE shell owns the UI (chat panel, settings, approvals). The service owns the agent loop and tool execution.

## Endpoints

### `GET /v1/health`

Liveness check.

```json
{ "status": "ok", "version": "0.0.1" }
```

### `GET /v1/tools`

Lists registered tools and their JSON schemas — useful for the shell to render an "enabled tools" UI.

```json
[
  { "name": "read_file", "description": "...", "schema": {...}, "approval": "auto" },
  ...
]
```

### `POST /v1/agent/run`

Streams agent events as Server-Sent Events. Each line is `data: <json>\n\n`, terminated by `data: [DONE]\n\n`.

Request body:

```json
{
  "providerConfig": {
    "id": "main",
    "type": "openai-compatible",
    "displayName": "OpenRouter",
    "preset": "openrouter",
    "baseUrl": "https://openrouter.ai/api/v1",
    "defaultModel": "anthropic/claude-sonnet-4"
  },
  "apiKey": "sk-...",
  "modelId": "anthropic/claude-sonnet-4",
  "mode": { ... full ModeConfig ... },
  "userMessage": "List the files in src/",
  "history": [/* prior ConversationMessage[], optional */]
}
```

SSE event types match `AgentEvent` from `@iom/shared` (`text_delta`, `tool_call`, `tool_result`, `iteration`, `done`, `error`), plus a final `{ type: "history_snapshot", history: [...] }` containing the full updated conversation.

## Authentication

If `OATI_SERVICE_TOKEN` is set in the environment, every request must carry `Authorization: Bearer <token>`. If unset, the service runs without auth — only safe on `127.0.0.1`.

## Approval model

The default `NodeHostContext` **auto-approves** every tool invocation. This is intentional: the service trusts its caller (an IDE shell) to handle user-facing approval in its own UI before sending the request. Until then, the shell can either pre-filter tools or run in a confined workspace.

A future iteration will add a callback-based approval pattern where the SSE stream emits `approval_request` events and the shell responds via a separate `POST /v1/approval/:id`. Not implemented yet.

## Running

```bash
# Build the CLI
npm run build --workspace=@iom/agent-service

# Run it
OATI_WORKSPACE_ROOT=/path/to/project OATI_SERVICE_TOKEN=secret node packages/agent-service/dist/cli.js

# Or via npm bin (after publish/link)
iom-service
```

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `OATI_SERVICE_PORT` | `8765` | TCP port to bind |
| `OATI_SERVICE_HOST` | `127.0.0.1` | Bind address. Use `0.0.0.0` to expose externally. |
| `OATI_SERVICE_TOKEN` | (none) | If set, required as `Authorization: Bearer <token>` |
| `OATI_WORKSPACE_ROOT` | `process.cwd()` | Root for relative file paths in tools |

## Why this exists

`agent-core` is pure TypeScript with zero VS Code deps. That decoupling was intentional so it can also run as a long-lived service for IDE shells that aren't Electron/Node (Visual Studio, JetBrains, Xcode). This package is the thin glue.
