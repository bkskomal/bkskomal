// 2026-05-23: background-process registry for the sidecar.
//
// Mirrors `packages/extension-host/src/background-processes.ts` byte-for-byte
// because the two hosts have separate dependency graphs (no cross-package
// dep). Keep these in sync — when one is updated, update the other. There
// are tests for the registry's contract in this package's tests folder.

import * as cp from "node:child_process";
import type { BackgroundProcessHandle, BackgroundProcessOptions } from "@iom/shared";

const EARLY_OUTPUT_CAP = 8 * 1024;
const DEFAULT_WAIT_MS = 1500;
const MIN_WAIT_MS = 100;
const MAX_WAIT_MS = 10_000;

interface InternalEntry {
	readonly child: cp.ChildProcess;
	readonly handle: BackgroundProcessHandle;
}

export class BackgroundProcessRegistry {
	private readonly entries = new Map<number, InternalEntry>();

	async start(
		command: string,
		defaultCwd: string,
		options?: BackgroundProcessOptions,
	): Promise<BackgroundProcessHandle> {
		const cwd = options?.cwd ?? defaultCwd;
		const label = options?.label ?? command;
		const waitMs = clamp(options?.waitForOutputMs ?? DEFAULT_WAIT_MS, MIN_WAIT_MS, MAX_WAIT_MS);

		const child = cp.spawn(command, {
			cwd,
			env: { ...process.env, ...(options?.env ?? {}) },
			shell: true,
			detached: false,
		});

		if (!child.pid) {
			throw new Error(`Failed to spawn background process: ${command}`);
		}

		let earlyStdout = "";
		let earlyStderr = "";
		const onStdout = (chunk: Buffer | string): void => {
			if (earlyStdout.length >= EARLY_OUTPUT_CAP) return;
			const next = earlyStdout + chunk.toString();
			earlyStdout = next.length > EARLY_OUTPUT_CAP ? next.slice(0, EARLY_OUTPUT_CAP) : next;
		};
		const onStderr = (chunk: Buffer | string): void => {
			if (earlyStderr.length >= EARLY_OUTPUT_CAP) return;
			const next = earlyStderr + chunk.toString();
			earlyStderr = next.length > EARLY_OUTPUT_CAP ? next.slice(0, EARLY_OUTPUT_CAP) : next;
		};
		child.stdout?.on("data", onStdout);
		child.stderr?.on("data", onStderr);

		let exitDuringWait: number | undefined;
		const exitDuringWaitPromise = new Promise<void>((resolve) => {
			child.once("exit", (code) => {
				exitDuringWait = code ?? -1;
				resolve();
			});
		});

		await Promise.race([
			new Promise<void>((resolve) => setTimeout(resolve, waitMs)),
			exitDuringWaitPromise,
		]);

		child.stdout?.removeListener("data", onStdout);
		child.stderr?.removeListener("data", onStderr);
		child.stdout?.resume();
		child.stderr?.resume();

		const handle: BackgroundProcessHandle = {
			pid: child.pid,
			command,
			cwd,
			label,
			startedAt: Date.now(),
			earlyStdout,
			earlyStderr,
			...(exitDuringWait !== undefined ? { exitedDuringWait: exitDuringWait } : {}),
		};

		if (exitDuringWait === undefined) {
			this.entries.set(child.pid, { child, handle });
			child.once("exit", () => {
				this.entries.delete(child.pid as number);
			});
		}

		return handle;
	}

	async stop(pid: number): Promise<{ killed: boolean }> {
		const entry = this.entries.get(pid);
		if (!entry) return { killed: false };
		try {
			entry.child.kill("SIGTERM");
			await new Promise<void>((resolve) => setTimeout(resolve, 500));
			if (!entry.child.killed) {
				try {
					entry.child.kill("SIGKILL");
				} catch {
					/* best-effort */
				}
			}
			return { killed: true };
		} finally {
			this.entries.delete(pid);
		}
	}

	list(): readonly BackgroundProcessHandle[] {
		return [...this.entries.values()].map((e) => e.handle);
	}

	disposeAll(): void {
		for (const [pid] of this.entries) {
			void this.stop(pid);
		}
	}
}

function clamp(n: number, lo: number, hi: number): number {
	return Math.max(lo, Math.min(hi, n));
}
