import type { HostToWebview, RpcEnvelope, WebviewToHost } from "@iom/shared";

export interface Transport<In, Out> {
	postMessage(msg: RpcEnvelope<Out>): void;
	onMessage(handler: (msg: RpcEnvelope<In>) => void): () => void;
}

export type Listener<T> = (msg: T) => void;

export class Bus<In, Out> {
	private readonly listeners = new Set<Listener<In>>();
	private readonly disposeTransport: () => void;

	constructor(private readonly transport: Transport<In, Out>) {
		this.disposeTransport = this.transport.onMessage((env) => {
			if (env.v !== 1) return;
			for (const fn of this.listeners) fn(env.body);
		});
	}

	send(body: Out): void {
		this.transport.postMessage({ v: 1, body });
	}

	on(listener: Listener<In>): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	dispose(): void {
		this.listeners.clear();
		this.disposeTransport();
	}
}

export type HostBus = Bus<WebviewToHost, HostToWebview>;
export type WebviewBus = Bus<HostToWebview, WebviewToHost>;
