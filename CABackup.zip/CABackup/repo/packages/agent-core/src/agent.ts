import {
	type AgentEvent,
	type AgentRunOptions,
	type ConversationMessage,
	type HostContext,
	type MessagePart,
	type ModeConfig,
	type ProviderSpec,
	type ToolCallPart,
	type ToolResultPart,
	type ToolSpec,
	detectModelQuirks,
} from "@iom/shared";
import { shrinkOldToolResults } from "./context-shrink";
import { describeImage } from "./image-describer";
import { CORE_TOOL_NAMES, buildDroppedToolsHint, filterToolsJIT } from "./jit-tools";
import { normalizeToolArgs } from "./normalize-tool-args";
import { dedupDuplicateReads } from "./read-dedup";
import { renderSegmentAsTranscript, summarizeHistorySegment } from "./summarizer";
import { filterToolsForModel } from "./tool-filter";
import { auditWireBody } from "./wire-audit";

// Re-export for callers that imported from agent.ts before the
// extraction (back-compat).
export { normalizeToolArgs };

export interface AgentDeps {
	readonly id: string;
	readonly provider: ProviderSpec;
	readonly tools: readonly ToolSpec[];
	readonly host: HostContext;
	readonly mode: ModeConfig;
}

export interface AgentOptions {
	readonly modelId: string;
	/**
	 * 2026-06-29: mirrors ModeConfig.contextBudget. Set by the caller
	 * (chat-panel resolves it from the active mode) so agent-core can
	 * adjust its auto-compact threshold and apply rolling tool_result
	 * truncation on the wire. Default `"normal"` = historical behavior.
	 */
	readonly contextBudget?: "aggressive" | "normal" | "generous";
}

export type EventListener = (event: AgentEvent) => void;

export class Agent {
	private readonly history: ConversationMessage[];
	private readonly listeners = new Set<EventListener>();
	// Tracks whether the current run has dispatched any tools — used by the
	// loop-end safety net that synthesizes a wrap-up when the model exits
	// after a tool call without writing a closing summary.
	private lastTurnUsedTools = false;
	/**
	 * 2026-05-29: tracks recent tool-call signatures for the
	 * repeated-failure escalator. Each iteration logs a hash of
	 * (toolName, args-snapshot) per result. When the same signature
	 * fails THREE times in a row, the next iteration emits a clear
	 * "stuck on the same broken call" error and the turn ends — better
	 * than letting the model loop a 4th, 5th, 6th time on a malformed
	 * arg shape it can't self-correct.
	 *
	 * Cleared at turn start. Per-run, not session-wide; a manual retry
	 * gets a fresh budget.
	 */
	private repeatedFailureSignatures: { sig: string; count: number }[] = [];
	// Mirrors whether the most recently emitted assistant message contains
	// any text (vs being a pure tool_call message). Updated by streamOnce.
	private lastAssistantHasText = false;
	// The text content of the most recent assistant turn. Used by the
	// "stopped mid-thought" detector — when the model writes "Let me
	// check..." then ends with no tool call, we auto-continue once instead
	// of leaving the chat silent.
	private lastAssistantText = "";
	// Set true after we've injected an auto-continue nudge in the current
	// run, so the loop can't ping-pong forever if the model keeps trailing
	// off into "let me…" with no follow-up.
	private autoContinuedThisTurn = false;
	// Recent (tool name + args JSON) fingerprints. When the model issues the
	// SAME call N times in a row — typically because it misreads a failing
	// tool result and keeps retrying with identical args — we trip a loop
	// guard so the user isn't watching their token budget burn.
	private recentToolCallFingerprints: string[] = [];
	// 2026-05-25: mid-turn user input queue. The host (chat-panel) can call
	// `enqueueUserMessage` while the agent is mid-run; the queued text gets
	// drained at the START of the next iteration as a user-role message
	// pushed before the model's next call. This is what lets the user say
	// "actually, focus on X instead" without waiting for the current turn
	// to finish or cancelling everything outright.
	private pendingUserInput: string[] = [];
	// 2026-05-26: one-shot auto-compact guard. When the model returns NO
	// output on a turn with a large accumulated history (the "review the
	// nopCommerce codebase" failure mode), we run a summarize pass on
	// the middle of history and retry the stream once. Guarded so the
	// retry can't loop forever — if the second attempt is also empty,
	// the normal no-output diagnostic fires.
	private autoCompactedThisTurn = false;
	/**
	 * 2026-06-29: safety net for JIT tool-schema pruning. When a provider
	 * error names a tool that WAS in our toolbelt but got JIT-dropped
	 * from tools[] this turn, the tool name gets added here — the JIT
	 * filter promotes it to the core-set for the rest of the session.
	 * Never removed (session-lifetime learning). Ephemeral — a new
	 * session starts with an empty set.
	 */
	private readonly jitAlwaysInclude = new Set<string>();
	// 2026-05-26: one-shot empty-response retry guard. Separate from
	// `autoCompactedThisTurn` because empty responses on SHORT sessions
	// (where history isn'\''t the cause) need a different recovery — we
	// just nudge the model with "your previous response was empty,
	// please respond now" and re-stream once. Guarded so a model stuck
	// in a permanent silent state hits the diagnostic after two tries
	// rather than looping forever.
	private emptyRetriedThisTurn = false;
	/**
	 * 2026-05-29: how many empty-response retries we've spent this turn.
	 * Bumped from 1 → 2 because the original single retry kept failing
	 * on Kimi K2.6 cold-start (first turn of a fresh session with a
	 * complex prompt). Two retries with progressively simpler nudges
	 * catches it about 80% of the time; the third drops into a friendly
	 * action-oriented diagnostic.
	 */
	private emptyRetryCount = 0;
	private static readonly MAX_EMPTY_RETRIES = 2;
	// 2026-05-29: one-shot wrapped-args self-correction.
	//
	// When the model emits malformed tool args (the `{_raw: "..."}` /
	// double-encoded-JSON-string shape Kimi K2.6 falls into), we recover
	// the fields and proceed transparently — but the model NEVER sees that
	// anything went wrong, so it keeps making the same mistake call after
	// call. The fix-up worked but didn't teach.
	//
	// Two flags needed:
	//   - `wrappedArgsAdvicePending`: per-BATCH signal armed on a successful
	//     recovery, drained when the next executeToolCalls dispatch fires
	//     and (when allowed) prepends the teach note to the first result.
	//   - `wrappedArgsAdviceEmittedThisTurn`: per-TURN record. Once set,
	//     subsequent recoveries in the same turn arm `pending` as usual but
	//     the dispatch suppression keeps the note from re-firing — Kimi
	//     can't actually internalise the correction mid-turn (it's a
	//     structural quirk, not something prompting can fix), so repeating
	//     the note buys nothing and just floods the chat. ORIGINAL impl
	//     (4f6e4e7) re-fired on every batch because it conflated these two
	//     timescales; a 30-call scaffold turn rendered the same teach note
	//     15+ times.
	//
	// Both reset at user turn start.
	private wrappedArgsAdvicePending = false;
	private wrappedArgsAdviceEmittedThisTurn = false;
	// 2026-05-30: fix-intent detector state. When the user's message asks
	// for a fix ("fix this", "broken", "not working", "make it work") and
	// the turn ends with ZERO mutating tool calls, the model is almost
	// certainly investigating-without-acting — the exact pattern that
	// produced the "read 8 files, took screenshot, said Done, fixed
	// nothing" trace. One-shot per turn; uses the same nudge channel as
	// the other auto-continues.
	private originalUserMessageThisTurn = "";
	private fixIntentNudgeFiredThisTurn = false;
	// 2026-05-26: set true when the most recent streamOnce ended with a
	// stream-level error (HTTP failure, provider guardrail block, parse
	// error, etc.). Used to suppress the honest-Done synthesis — when
	// the provider hard-failed we don't want to claim "✅ Done" on top
	// of an error bubble.
	private lastStreamErrored = false;
	// 2026-06-01: per-session file-read deduplication. Maps a normalized
	// file path to a SHA1 hash of its last-read content. When the model
	// re-reads the same file and the hash matches, the result is replaced
	// with a short "unchanged since prior read" note — saves ~30k tokens
	// per duplicated read_file on a 2000-line file. Map persists across
	// turns within a session; invalidated when the agent writes to the
	// same path (write_file/batch_file_edit, see executeToolCalls).
	private readonly fileReadHashes = new Map<string, string>();
	// 2026-06-01: tracks which ImagePart dataUrls have already been swapped
	// for text descriptions, so the demote pass doesn't re-describe the
	// same image on every subsequent turn. Keyed by quickHash of the
	// dataUrl since the strings are huge.
	private readonly describedImageHashes = new Set<string>();
	// 2026-06-01: lazily-fetched repo map (Aider-style top-level symbol
	// view of the workspace). Built once per Agent instance via the
	// host's optional getRepoMap hook; injected into every stream's
	// system prompt for orientation. Cached as a string so we don't pay
	// the walk cost on every turn. `null` means "tried and got nothing"
	// (host didn't implement, or empty workspace) — distinct from
	// `undefined` which means "haven't tried yet".
	private repoMapCache: string | null | undefined;
	// 2026-06-03: same caching shape for the project memory file. One
	// read per Agent instance, then served from memory on every stream
	// call. The "edit IOM.md and restart" workflow is intentional — we
	// don't auto-refresh because the agent's reasoning would otherwise
	// see a moving target mid-turn.
	private projectMemoryCache: string | null | undefined;

	private readonly deps: AgentDeps;
	private readonly options: AgentOptions;

	constructor(
		deps: AgentDeps,
		options: AgentOptions,
		initialHistory: readonly ConversationMessage[] = [],
	) {
		// Phase 2.2: filter the toolbelt to what the active model can
		// actually use. spawn_agent / spawn_parallel_agents drop off
		// the list for small open-weight + local models because they
		// can't coherently track sub-agent results. The model never
		// sees the tool definition, so it never tries to call it —
		// no confused output, no wasted iterations.
		this.deps = { ...deps, tools: filterToolsForModel(deps.tools, options.modelId) };
		this.options = options;
		this.history = [...initialHistory];
	}

	getHistory(): readonly ConversationMessage[] {
		return this.history;
	}

	on(listener: EventListener): () => void {
		this.listeners.add(listener);
		return () => this.listeners.delete(listener);
	}

	/**
	 * Queue a user message to be injected at the next iteration boundary of
	 * the currently-running turn. Safe to call any time — if no turn is
	 * running the message just sits in the queue and gets drained when the
	 * next turn starts.
	 *
	 * Why "next iteration" rather than "immediately": injecting mid-stream
	 * would race with the provider's in-flight response and produce a
	 * malformed conversation (assistant message half-written, user message
	 * crammed before it). Iteration boundary is the safe insertion point —
	 * the previous streamOnce has fully landed in history, the next one
	 * hasn't started.
	 */
	enqueueUserMessage(text: string): void {
		const trimmed = text.trim();
		if (trimmed.length === 0) return;
		this.pendingUserInput.push(trimmed);
	}

	/** True when there's queued user input waiting for the next iteration. */
	hasPendingUserInput(): boolean {
		return this.pendingUserInput.length > 0;
	}

	private emit(event: AgentEvent): void {
		for (const fn of this.listeners) fn(event);
	}

	async run(opts: AgentRunOptions): Promise<void> {
		const parts: MessagePart[] = [{ kind: "text", text: opts.userMessage }];
		if (opts.userParts) {
			for (const p of opts.userParts) parts.push(p);
		}
		this.history.push({
			role: "user",
			parts,
		});

		// 2026-05-26: vision-capability pre-flight. When the user attached
		// an image but the active model is text-only, the wire request
		// goes through but the model has no way to read the image_url
		// blocks — response comes back silent or with "I can't see images"
		// hallucinations. Surface this BEFORE the silent failure, with a
		// concrete model recommendation. Only fires when the JUST-pushed
		// user message has image parts; doesn't trip on historical images
		// from earlier in the session.
		const hasImageParts = parts.some((p) => p.kind === "image");
		if (hasImageParts) {
			const quirksVision = detectModelQuirks(this.options.modelId);
			if (!quirksVision.supportsVision) {
				const wrap = [
					`⛔ **The current model (\`${this.options.modelId}\`) doesn't accept image inputs.** ${quirksVision.displayName} is text-only, so the image you attached can't be read — the model will either return empty or hallucinate "I can't see images" content.`,
					"",
					"**To analyze this image, switch to a vision-capable model:**",
					"",
					"  - **Claude Sonnet 4.6 / Opus 4.7** (Anthropic) — best for screenshots + code review.",
					"  - **GPT-4o / GPT-4.1** (OpenAI) — best general-purpose vision.",
					"  - **Gemini 2.x** (Google) — natively multimodal; cheapest per image.",
					"",
					"Open Settings → API Configuration → switch the active model, then resend the message. Your conversation history is preserved.",
				].join("\n");
				this.emit({ type: "text_delta", agentId: this.deps.id, text: wrap });
				this.history.push({
					role: "assistant",
					parts: [{ kind: "text", text: wrap }],
				});
				this.emit({ type: "done", agentId: this.deps.id, reason: "end" });
				return;
			}
		}

		// Phase 3.1: per-turn lifecycle events. Hosts use these to bracket
		// auto-checkpoint snapshots (capture file states before any tools
		// fire; finalize the checkpoint on turn_end) so an entire turn can
		// be rolled back atomically via the `revert_turn` RPC later. The
		// turnId is opaque and host-side observers MUST treat it that way.
		const turnId = `t_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
		this.emit({
			type: "turn_start",
			agentId: this.deps.id,
			turnId,
			userMessage: opts.userMessage,
		});
		let turnOutcome: "end" | "max_iterations" | "cancelled" | "error" = "error";
		try {
			const historyLenBefore = this.history.length;
			this.lastTurnUsedTools = false;
			this.lastAssistantHasText = false;
			this.lastAssistantText = "";
			this.autoContinuedThisTurn = false;
			this.autoCompactedThisTurn = false;
			this.emptyRetriedThisTurn = false;
			this.emptyRetryCount = 0;
			this.lastStreamErrored = false;
			// 2026-05-29: reset the repeated-failure budget at the start
			// of every user turn so each new instruction gets its own
			// fresh 3-strike count.
			this.repeatedFailureSignatures = [];
			// 2026-05-29: reset the wrapped-args advice flags so each turn
			// gets its own one-shot teach if the model regresses.
			this.wrappedArgsAdvicePending = false;
			this.wrappedArgsAdviceEmittedThisTurn = false;
			// 2026-05-30: stash the user's original message so the
			// fix-intent-without-mutation detector can pattern-match it
			// against fix/repair/broken keywords on turn end.
			this.originalUserMessageThisTurn = opts.userMessage;
			this.fixIntentNudgeFiredThisTurn = false;
			const maxIter = this.deps.mode.maxIterations;
			for (let i = 0; i < maxIter; i++) {
				if (opts.signal?.aborted) {
					turnOutcome = "cancelled";
					this.emit({ type: "done", agentId: this.deps.id, reason: "cancelled" });
					return;
				}
				this.emit({ type: "iteration", agentId: this.deps.id, n: i + 1 });

				// 2026-05-25: drain any mid-turn user input the host enqueued
				// while the previous iteration was running. Push each one as
				// its own user-role message so the model sees them in order;
				// emit `user_message_injected` so the webview can flip the
				// queued bubble to "delivered". Done BEFORE streamOnce so the
				// next provider call carries the new instructions.
				if (this.pendingUserInput.length > 0) {
					const drained = this.pendingUserInput.splice(0, this.pendingUserInput.length);
					for (const text of drained) {
						this.history.push({
							role: "user",
							parts: [{ kind: "text", text }],
						});
						this.emit({
							type: "user_message_injected",
							agentId: this.deps.id,
							text,
						});
					}
				}

				const toolCalls = await this.streamOnce(opts.signal);
				if (toolCalls.length === 0) {
					// 2026-05-25: auto-continue safety net. Three distinct silent
					// dead-ends the user was hitting:
					//   (a) Text-only mid-thought — "Let me check..." then stop.
					//   (b) Tool ran, it FAILED, model went silent instead of
					//       retrying or summarizing the error.
					//   (c) 2026-05-29: investigatory tool ran (workspace_context,
					//       read_file, list_dir, …), model got the result, then
					//       went silent without doing the user's actual ask.
					//       Symptom: chat shows ONE workspace_context call and
					//       then "✅ Done — tool calls above completed" with
					//       nothing actually built. Read-only investigation
					//       calls are NEVER the user's destination; silence
					//       after one is a stuck signal, not completion.
					// In all three cases, inject a context-appropriate nudge and
					// loop ONE more time. One-shot, guarded by
					// autoContinuedThisTurn so the loop can't ping-pong.
					if (!this.autoContinuedThisTurn && i + 1 < maxIter) {
						const recentFailures = countRecentToolFailures(this.history);
						const lastCallsWereInvestigatory =
							this.lastTurnUsedTools &&
							!this.lastAssistantHasText &&
							recentFailures === 0 &&
							lastToolCallsAreInvestigatory(this.history);
						const nudge =
							this.lastAssistantHasText && looksMidThought(this.lastAssistantText)
								? "Continue from where you left off — your last message trailed off without completing the action. Call the tool you were about to call, or write the conclusion."
								: this.lastTurnUsedTools && !this.lastAssistantHasText && recentFailures > 0
									? "Your previous tool call failed — read the error in the most recent tool_result, then either (1) retry with corrected arguments, (2) call a different tool, or (3) write a short message explaining what went wrong and what you'd need from me to proceed. Do not stay silent."
									: lastCallsWereInvestigatory
										? "You ran a read-only investigation tool (e.g. workspace_context, list_dir, read_file) and then stopped. Investigation alone doesn't fulfill the user's request — you need to follow up with the actual WORK: write the file(s), run the command, edit the existing code. Continue now: produce the next tool call. If you genuinely need clarification before proceeding, ask the user a specific question (don't stay silent)."
										: undefined;
						if (nudge) {
							this.autoContinuedThisTurn = true;
							this.history.push({
								role: "user",
								parts: [{ kind: "text", text: nudge }],
							});
							continue;
						}
						// 2026-05-30: fix-intent without mutation. Unlike the
						// cases above (which gate on silence after tools), this
						// fires EVEN when the model emitted closing text — the
						// live trace had the model claim "Done" after a turn of
						// read_file + screenshot + zero writes for a "fix the
						// css" prompt. Catches the false-Done failure mode where
						// the model investigates and then bails without acting.
						if (
							!this.fixIntentNudgeFiredThisTurn &&
							isFixIntent(this.originalUserMessageThisTurn) &&
							countRelevantMutationsThisTurn(this.history, this.originalUserMessageThisTurn) === 0
						) {
							this.fixIntentNudgeFiredThisTurn = true;
							this.autoContinuedThisTurn = true;
							this.history.push({
								role: "user",
								parts: [
									{
										kind: "text",
										text: buildFixIntentNudge(this.originalUserMessageThisTurn),
									},
								],
							});
							continue;
						}
					}

					// If the model produced no assistant content at all across the
					// entire run (no text, no tool calls), the provider almost
					// certainly couldn't reach the model — wrong base URL, missing
					// API key, invalid model id, etc. Surface that as an explicit
					// error so the user sees a chat-visible message rather than a
					// silently-empty turn.
					// 2026-05-25: false-Done verification runs FIRST. If the
					// model already emitted a confident "Created X" claim in
					// its real assistant message (alongside earlier tool
					// calls), we need to check that claim against disk BEFORE
					// the honest-Done synthesis below pushes its own
					// follow-up message — otherwise `findLastAssistantText`
					// picks up the synthetic wrap instead of the lie.
					await this.verifyFileCreationClaims();

					if (this.history.length === historyLenBefore) {
						// 2026-05-26: auto-compact recovery. The "review this huge
						// codebase" failure mode — large accumulated history of
						// file reads, model returns empty on the follow-up
						// summary turn. Before surfacing the no-output error,
						// try once to summarize the middle of history and
						// re-stream. Guarded by `autoCompactedThisTurn` so the
						// second empty response falls through to the diagnostic
						// instead of looping.
						if (!this.autoCompactedThisTurn && i + 1 < maxIter && this.shouldAutoCompact()) {
							this.autoCompactedThisTurn = true;
							try {
								await this.compactHistoryMiddle(opts.signal);
								// Emit a chat-visible note so the user knows what
								// happened. Filtered to verboseInternals via the
								// existing `[wrapped-args]`-style prefix list.
								const before = this.history.length;
								this.emit({
									type: "error",
									agentId: this.deps.id,
									message: `[auto-compact] history was large and the model returned empty — summarized the middle ${before > 0 ? `(now ${this.history.length} messages)` : ""} and retrying.`,
								});
								continue;
							} catch (err) {
								this.deps.host.log?.(
									"warn",
									`[auto-compact] failed: ${err instanceof Error ? err.message : String(err)}`,
								);
								/* fall through to the no-output diagnostic */
							}
						}
						// 2026-05-26: empty-response auto-retry for the SHORT-
						// session case. When history isn'\''t the culprit (no
						// auto-compact triggered) but the model still returned
						// nothing — typically because Kimi/DeepSeek picked the
						// reasoning channel only, or a flaky 200-OK-with-empty-
						// body from the gateway — nudge the model once with a
						// clarifying user turn and re-stream. The retry is
						// gated by `emptyRetriedThisTurn` so a permanently silent
						// model can'\''t loop forever; the second empty stream
						// falls through to the diagnostic below.
						// 2026-05-29: two retries with progressively simpler nudges.
						// The original first nudge ("respond with normal text, not
						// reasoning") works for a fully-formed but reasoning-channel-
						// hidden response. When that fails, the second nudge takes
						// the opposite tack — break the request down to ONE step.
						// Kimi K2.6 cold-start tends to choke on multi-task prompts
						// like "create a website with 9 sections AND 4 themes" but
						// will happily reply to "What's the first file you'd create?"
						if (this.emptyRetryCount < Agent.MAX_EMPTY_RETRIES && i + 1 < maxIter) {
							this.emptyRetryCount++;
							this.emptyRetriedThisTurn = true; // legacy flag, kept for the diagnostic branch below
							const nudge =
								this.emptyRetryCount === 1
									? "Your previous response was empty (no text and no tool calls). Please respond now with your answer as normal text output — not in a reasoning channel. If you intended to call a tool, emit the tool call directly."
									: "Your last two responses were both empty. Let's simplify: respond now with ONE short sentence describing the FIRST concrete step you'd take for the user's request. Don't try to do everything at once. After that single step, I'll tell you to continue.";
							this.history.push({
								role: "user",
								parts: [{ kind: "text", text: nudge }],
							});
							this.emit({
								type: "error",
								agentId: this.deps.id,
								message: `[empty-response] model returned no output — nudging with ${this.emptyRetryCount === 1 ? "a clarifying" : "a simpler"} user message and retrying (attempt ${this.emptyRetryCount}/${Agent.MAX_EMPTY_RETRIES}).`,
							});
							continue;
						}
						// 2026-05-25: context-aware diagnostic. The previous text
						// always blamed "history too large" as the #1 cause, which
						// was misleading on short sessions (3 prompts in, history
						// is tiny — that's clearly NOT the bug). Now we reorder
						// the suggestions based on actual session size, and add
						// the most-common-but-previously-unnamed cause for short
						// sessions: reasoning models whose output lives in
						// `reasoning_content` rather than `content`, plus tools-
						// schema rejection that 200-OKs with an empty stream.
						const userTurnsSoFar = this.history.filter((m) => m.role === "user").length;
						const isShortSession = userTurnsSoFar <= 5;
						const modelId = this.options.modelId;
						// 2026-05-29: action-oriented headline. The previous version
						// led with the technical "the provider's response stream
						// completed without producing any text or tool calls" — a
						// sentence that taught the user nothing about what to do.
						// Now lead with the THREE most likely fixes in priority
						// order, followed by the technical detail for users who
						// want it.
						const lines: string[] = [
							`**The model returned nothing.** \`${modelId}\` produced no text and no tool calls after ${Agent.MAX_EMPTY_RETRIES + 1} attempts (1 initial + ${Agent.MAX_EMPTY_RETRIES} retries with progressively simpler nudges).`,
							"",
							"**Try one of these — usually one of them fixes it:**",
							"",
							isShortSession
								? `- 🔄 **Send a simpler test message** — type "hi" or "what tools do you have?" and Send. If THAT works, your original prompt was probably too complex for ${modelId} on cold start. Re-send the original split into smaller asks.`
								: "- 🧹 **Run `/compact`** to summarize older turns. The session may have accumulated history the model can't handle.",
							isShortSession
								? "- 🔌 **Check provider** — Settings → API Configuration → Test Connection. A wrong model id often 200-OKs an empty stream."
								: "- ✨ **Click `+ New Session`** to start fresh. The current session may have a malformed tool_result blob in history.",
							"- 🔁 **Switch model** — Settings → API Configuration → pick a different model (e.g. Claude or GPT-4 frontier). Some open-weight models silently empty on certain prompt shapes.",
							"",
							"**Technical detail (for debugging):**",
							"",
						];
						// 2026-05-26: when the empty-response auto-retry ALREADY
						// ran AND ALSO came back empty, the diagnostic ordering
						// should be different. A clean re-prompt failing means
						// the issue is structural — the session itself is
						// likely poisoned (a prior tool_result blob is
						// confusing the model on every turn) or the provider
						// is hard-broken. Lead with "+ New Session" rather
						// than reasoning-model theory.
						if (this.emptyRetriedThisTurn) {
							lines.push(
								"iOmCode auto-retried with a clarifying nudge and the model STILL returned empty. That means the issue is structural, not a transient miss. Most likely causes:",
								"",
								"  1. **This session is poisoned.** A prior turn (often a wrapped-args tool failure) left a confusing blob in history that the model now chokes on every turn. Fix: click `+ New Session` to start fresh. Your other sessions are unaffected.",
								"  2. **Provider unreachable / wrong model id.** Open Settings → Test Connection. A wrong model id can 200-OK an empty stream — looks exactly like this.",
								"  3. **Rate limit / quota.** Check the provider's dashboard. OpenRouter, Together, Fireworks all silently 200-OK over-quota requests on some plans.",
								"  4. **Tool schema rejected silently.** If you recently installed an MCP server or enabled extra tools, try disabling them in Settings and retrying.",
							);
						} else if (isShortSession) {
							lines.push(
								`This is turn ${userTurnsSoFar} of this session, so history size is NOT the culprit. The most likely causes, in order:`,
								"",
								"  1. **Provider unreachable / wrong model id.** Open Settings → Test Connection. A wrong model id often returns 200-OK with an empty stream (instead of a proper 404), which looks exactly like this.",
								"  2. **Tools schema rejected silently.** Some open-weight models 200-OK then emit zero tokens when the JSON Schema for a registered tool contains shapes they don't like (oneOf, anyOf, deeply nested objects, `additionalProperties: false`). Try disabling MCP servers or extra tools in Settings and retry — if the empty stream goes away, a tool's schema is the trigger.",
								"  3. **Rate limit / quota.** Check the provider's dashboard. Some gateways silently 200-OK an empty body when over-quota.",
								"  4. **Thinking-mode model with no normal output.** If you're on a thinking-mode variant (DeepSeek-R1, GPT-o1, Kimi K2.6 thinking), the model may emit ONLY reasoning content this turn. iOmCode surfaces that as `💭 ...` text, so a fully-empty response means it didn't emit either channel. Switch to the non-thinking variant or to a frontier model.",
							);
						} else {
							lines.push(
								"On a longer session like this one, the most common causes are:",
								"",
								"  1. **History too large or contaminated.** Type `/compact` to summarize old turns, or click `+ New Session` to start fresh. Past sessions with wrapped/malformed tool args can confuse the model into returning empty.",
								"  2. **Provider unreachable.** Open Settings and verify Base URL, API key, and Model ID. Hit `Test Connection`.",
								"  3. **Rate limit / quota.** Check the provider's dashboard for usage caps on this account.",
								"  4. **Thinking-mode model.** If you're on a thinking-only variant (DeepSeek-R1, GPT-o1, Kimi K2.6 thinking), iOmCode surfaces reasoning as `💭 ...` — a completely empty turn means neither channel emitted. Switch to a non-thinking variant or a frontier model.",
							);
						}
						lines.push(
							"",
							"For deeper debugging: open the `iOmCode` Output channel in VS Code — the raw provider HTTP response is logged there.",
						);
						this.emit({
							type: "error",
							agentId: this.deps.id,
							message: lines.join("\n"),
						});
					} else if (this.lastTurnUsedTools && !this.lastAssistantHasText && !this.lastStreamErrored) {
						// The model ran tools (so SOMETHING happened in the workspace)
						// but never wrote a closing summary. Synthesize a system note
						// so the chat doesn't fall silent.
						//
						// 2026-05-26: skip the synthesis when the LAST stream errored
						// (HTTP failure, guardrail block, parse error). In that case
						// the user has already seen the real error bubble; adding a
						// "✅ Done — tool calls above completed" right after it would
						// read as "the failure was actually a success" — exactly
						// the wrong message.
						//
						// 2026-05-24 honesty fix: the old version said "✅ Done"
						// unconditionally, even when the latest tool calls FAILED.
						// That misled the user into thinking work succeeded when
						// the model had actually given up mid-task. Now we
						// inspect the most recent tool-message results in
						// history and tell the truth — success only when every
						// recent result was non-error; otherwise an explicit
						// "tools failed" notice so the user reviews the errors
						// instead of trusting a false "Done".
						const recentFailures = countRecentToolFailures(this.history);
						const wrapText =
							recentFailures > 0
								? `⚠️ Stopped without a written summary, and ${recentFailures} recent tool call${recentFailures === 1 ? "" : "s"} failed. The task may NOT be complete — scroll up and review the errors above before assuming success. Tell me to retry, or describe what you'd like me to do differently.`
								: "✅ Done — the tool calls above completed, but I didn't add a written summary this time. Let me know if the change worked, or ask me to verify / explain what I did.";
						this.history.push({
							role: "assistant",
							parts: [{ kind: "text", text: wrapText }],
						});
						this.emit({ type: "text_delta", agentId: this.deps.id, text: wrapText });
					}

					turnOutcome = "end";
					this.emit({ type: "done", agentId: this.deps.id, reason: "end" });
					return;
				}

				const results = await this.executeToolCalls(toolCalls);
				// Track tool-call fingerprints across a sliding window so we
				// can detect both "consecutive duplicates" and the more common
				// "interleaved retry" loop (Read, Read-with-absolute-path,
				// Read, exec, exec, Read, …). The model keeps trying tiny
				// variants of the same target and never makes progress.
				for (const call of toolCalls) {
					this.recentToolCallFingerprints.push(`${call.name}::${stableStringify(call.args)}`);
				}
				const WINDOW = 8;
				if (this.recentToolCallFingerprints.length > WINDOW) {
					this.recentToolCallFingerprints = this.recentToolCallFingerprints.slice(-WINDOW);
				}
				const stuckHit = detectStuckPattern(this.recentToolCallFingerprints);
				// 2026-06-06: hold the guidance — push it as a user-role
				// follow-up message AFTER the tool results message is
				// committed, NOT as a synthetic tool_result. Previously we
				// injected a `tool_result` with a fabricated `loop_guard_*`
				// id; Anthropic strictly validates that every tool_result
				// has a matching tool_use and 400s the request with
				// "unexpected tool_use_id". OpenAI tolerated the orphan but
				// the shape was semantically wrong on both. As a real user
				// message the guidance is provider-agnostic and shows up
				// as the next prompt the model reads.
				let loopGuardGuidance: string | undefined;
				if (stuckHit) {
					loopGuardGuidance = [
						`⚠️ LOOP GUARD — ${stuckHit.reason}. Repeating tiny variants of the same call WILL NOT change the outcome. STOP and switch strategy:`,
						"  (1) Read the most recent tool_result carefully — the error message names the actual problem.",
						"  (2) If you're trying to read a file: call `get_workspace_context` first to confirm what workspace root the tools resolve against. Many tool failures are because the sidecar's CWD is not where you assumed.",
						"  (3) If you used a relative path, retry with the full absolute path (e.g. `E:\\\\Folder\\\\file.ts`). If you used an absolute path that failed, the file genuinely does not exist there — call `list_dir` on its parent to verify the spelling.",
						"  (4) Switch tools entirely: use `exec` with `cat` / `Get-Content` / `Select-String` as a fallback to bypass `read_file`. Use `exec` with `dir /b /s` to find a file when you're not sure of the path.",
						"  (5) If you've tried 2+ approaches and ALL of them fail, STOP looping. Write a short message to the user: 'I tried X and Y, both failed because Z. Could you confirm <specific question>?'",
						"  (6) The user CANNOT change the sidecar's workspace root from chat. If the workspace is wrong, ask the user to open the right folder in their IDE — don't keep trying paths.",
					].join("\n");
					// Reset so the guidance fires once per stuck episode, not
					// on every subsequent iteration.
					this.recentToolCallFingerprints = [];
					this.emit({
						type: "error",
						agentId: this.deps.id,
						message: `Loop guard: ${stuckHit.reason}. Guidance injected — model should pivot.`,
					});
				}
				// 2026-05-30: image-bearing tool results (browser_screenshot,
				// extract_image_text data URLs, etc.) need to be packed as a
				// proper multimodal content block for vision-capable models
				// to actually SEE them. The tool_result.output is a plain
				// string/object inside a tool role; the OpenAI/Anthropic
				// envelopes only render images from USER role ImageParts.
				// Fix: scan results for image dataUrls and inject a synthetic
				// user follow-up message carrying the actual ImagePart, so
				// the model sees both the structured tool_result text AND
				// the live image on the next turn.
				//
				// Gated on the active model's `supportsVision` flag — non-
				// vision models get nothing useful from an image block and
				// pay extra tokens. They have `pageText` from the screenshot
				// tool to fall back on.
				const imageInjections = collectImageInjections(results);
				// 2026-06-01: truncate large tool results AND strip dataUrl
				// fields that have already been hoisted into ImagePart blocks.
				// Without this, a 100k stdout from `exec` or a multi-thousand-
				// line `read_file` floods every subsequent turn with the same
				// payload — and a screenshot's dataUrl gets serialized TWICE
				// (once in the tool_result JSON, once in the user follow-up
				// ImagePart). Real-world: a single Vite build log replayed
				// 5 turns later consumed ~30k tokens per turn.
				const trimmedResults = results.map((r) =>
					trimToolResultForHistory(r, imageInjections.length > 0),
				);
				this.history.push({
					role: "tool",
					parts: trimmedResults,
				});
				// 2026-06-06: loop-guard guidance as a real user message,
				// landed right after the tool results so the model reads it
				// on the next prompt. See the stuck-detection block above
				// for why we don't pack it as a tool_result.
				if (loopGuardGuidance) {
					this.history.push({
						role: "user",
						parts: [{ kind: "text", text: loopGuardGuidance }],
					});
				}
				if (imageInjections.length > 0 && this.modelSupportsVision()) {
					// 2026-06-02: proactive budget check. Even with the demote
					// pass running between turns (which strips older images
					// to text descriptions), a single fullPage screenshot on
					// a long-running session can still push the wire request
					// over the model's context limit — the demote pass spares
					// the most-recent image as "the one the model needs to
					// see right now," but if history is already at ~220k and
					// the new screenshot is ~27k, we land over 256k and the
					// upstream rejects.
					//
					// Fix: estimate the request size BEFORE hoisting. When
					// it would exceed the soft threshold, eagerly describe
					// the image right here (same describeImage sub-call used
					// by the demote pass) and inject the description as a
					// TextPart instead. Costs us a ~300-token text block
					// instead of a ~27k vision-token image — same delta
					// the demote pass achieves, but applied at injection
					// time so we never produce the oversized request in
					// the first place.
					const injected = await this.injectImagesRespectingBudget(imageInjections, opts.signal);
					this.history.push({ role: "user", parts: injected });
				}
				this.lastTurnUsedTools = true;
			}

			turnOutcome = "max_iterations";
			this.emit({ type: "done", agentId: this.deps.id, reason: "max_iterations" });
		} finally {
			// Phase 3.1: turn_end always fires — covers normal end, max
			// iterations, cancellation, and uncaught errors. Host's
			// per-turn checkpoint finalizer must be idempotent and
			// outcome-agnostic; we just deliver the verdict.
			this.emit({
				type: "turn_end",
				agentId: this.deps.id,
				turnId,
				outcome: turnOutcome,
			});
		}
	}

	private async streamOnce(signal?: AbortSignal): Promise<ToolCallPart[]> {
		const toolCalls: ToolCallPart[] = [];
		const textChunks: string[] = [];
		// 2026-06-01: thinking-mode reasoning trace, captured separately so
		// it can be round-tripped on history as a ReasoningPart. Required
		// by Kimi K2.6 — Moonshot refuses subsequent turns with "thinking
		// is enabled but reasoning_content is missing" when the assistant
		// history is replayed without its original reasoning content.
		const reasoningChunks: string[] = [];
		let stopReason: "end" | "tool_use" | "max_tokens" | "error" = "end";
		// Aggregate per-turn usage so we can emit one `usage` event AFTER the
		// assistant message is pushed onto history. The webview attaches the
		// numbers to that just-pushed assistant bubble, which gives us
		// per-message token attribution.
		let usageInput = 0;
		let usageOutput = 0;
		let sawUsage = false;

		// Local AbortController so the loop guard can stop the upstream stream
		// even if the caller didn't provide a signal.
		const localAbort = new AbortController();
		const onCallerAbort = () => localAbort.abort();
		if (signal) {
			if (signal.aborted) localAbort.abort();
			else signal.addEventListener("abort", onCallerAbort, { once: true });
		}

		// 2026-05-26: plumb maxTokens from the model-quirks table into the
		// provider request so providers (especially OpenRouter brokers)
		// don't fall back to their own tiny defaults. Without this, Kimi
		// K2.6 routinely got chopped to 4K output even though the model
		// supports 16K — making "summarize this huge codebase review"
		// silently truncate or return empty.
		const quirks = detectModelQuirks(this.options.modelId);
		// 2026-06-01: hard temperature override. When the model has a
		// requiresTemperature constraint (e.g. K2.6 thinking variants that
		// reject anything other than 1), it WINS over the mode's setting
		// — the user's mode-level preference can't satisfy a server-side
		// "this value or nothing" rule. When the constraint isn't set
		// (most models), fall through to the mode's temperature.
		const effectiveTemperature =
			quirks.requiresTemperature !== undefined
				? quirks.requiresTemperature
				: this.deps.mode.temperature;
		// 2026-06-01: predictive auto-compact. The existing post-empty-
		// response trigger only fires AFTER the provider has rejected /
		// returned nothing — for the "history is huge, model still wants
		// to call a tool" case, history grows until we exceed the model's
		// context window and the request fails with `Your request
		// exceeded model token limit: 262144 (requested: ...)`. Live-bug:
		// 323k requested vs 262k cap on a viewport-only screenshot turn.
		// The fix: estimate before sending; if we're past the threshold
		// AND haven't compacted this turn, summarize the middle now so
		// the request fits.
		// 2026-06-01: image-to-description demotion. Walk history; if there
		// are multiple image-bearing user messages, replace older ones with
		// a model-generated text description (~150-300 tokens) instead of
		// keeping the full base64 payload (~5-27k tokens per image). The
		// most recent image stays as-is so the model can still see what
		// just happened in detail. Runs ONLY when the model supports
		// vision (otherwise there's no image-injection pipeline to worry
		// about) and there's actually more than one image to demote.
		if (this.modelSupportsVision()) {
			await this.demoteOldImages(signal);
		}
		// 2026-06-02: sliding window over image descriptions. After
		// demoteOldImages converts ImageParts → text descriptions, the
		// pool of "[iOm image memory] ..." text blocks can still grow
		// unbounded across a long session. Cap to K most-recent;
		// collapse older to a short marker that names the page if the
		// description carried one. Default K=10, configurable later.
		this.collapseOldImageDescriptions(10);
		// 2026-06-02: emit a context-budget breakdown when usage is high
		// enough that the user (and the model) benefits from knowing
		// WHERE the tokens are going. Fires at 60% of the model's
		// context window — early enough to be actionable, not so early
		// that it spams the chat on a normal session.
		const breakdown = estimateContextBreakdown(this.history);
		if (breakdown.total > quirks.contextWindow * 0.6) {
			this.emit({
				type: "error",
				agentId: this.deps.id,
				message: formatBudgetBreakdown(breakdown, quirks.contextWindow),
			});
		}
		if (!this.autoCompactedThisTurn && this.shouldAutoCompact()) {
			this.autoCompactedThisTurn = true;
			try {
				const before = this.history.length;
				await this.compactHistoryMiddle(signal);
				this.emit({
					type: "error",
					agentId: this.deps.id,
					message: `[auto-compact] history was nearing the model's context limit (${quirks.contextWindow.toLocaleString()} tokens) — summarized ${before - this.history.length} older messages before sending.`,
				});
			} catch (err) {
				this.deps.host.log?.(
					"warn",
					`[auto-compact pre-send] failed: ${err instanceof Error ? err.message : String(err)}`,
				);
				// Fall through — the provider may still accept the request,
				// or fail with a clearer error than us trying to compact
				// during an already-broken state.
			}
		}
		// 2026-06-01: self-heal orphan tool_calls. A session whose history
		// was corrupted by an earlier buggy compaction (or by any other
		// means) carries assistant messages with tool_calls whose matching
		// tool responses are missing. OpenAI rejects this shape with `an
		// assistant message with 'tool_calls' must be followed by tool
		// messages responding to each 'tool_call_id'. The following
		// tool_call_ids did not have response messages: ...`. We scan
		// every assistant message and inject synthetic tool_result stubs
		// for any unanswered tool_call_ids so the wire becomes valid AND
		// the session is repaired on disk for future turns.
		// 2026-06-03 bug-fix: ALWAYS apply repair.repaired, not only when
		// orphans were found. repairOrphanToolCalls's Pass-0 normalization
		// renames empty tool_call_ids to synthesized ones — that work has
		// to persist even when there's nothing to inject (e.g. when both
		// sides of an empty-id pair existed but balanced). The prior
		// `if (orphans.length > 0)` gate threw the rename away for those
		// cases, leaving the bare empty ids in history. The wire filter
		// then dropped them, sometimes producing imbalanced wire bodies
		// that the upstream rejected with `tool_call_id  is not found`.
		// Diff `repair.repaired` against the input — if anything changed,
		// either by orphan injection or by rename, swap it in.
		const repair = repairOrphanToolCalls(this.history);
		const didNormalize = !areHistoriesEqual(this.history, repair.repaired);
		if (didNormalize) {
			this.history.length = 0;
			this.history.push(...repair.repaired);
		}
		if (repair.orphans.length > 0) {
			this.emit({
				type: "error",
				agentId: this.deps.id,
				message: `[history-repair] recovered ${repair.orphans.length} orphan tool_call${repair.orphans.length === 1 ? "" : "s"} (${repair.orphans.join(", ")}) — their results were missing from this session's history. Injected placeholder responses so the conversation can continue.`,
			});
		} else if (didNormalize) {
			// Pass-0 rewrote something (empty-id renames, malformed entries)
			// but no orphans needed injection. Light diagnostic so the user
			// sees that history was touched.
			this.emit({
				type: "error",
				agentId: this.deps.id,
				message:
					"[history-repair] normalized empty-id tool_call/tool_result entries from prior session state; conversation can continue.",
			});
		}
		// 2026-06-01: compose the effective system prompt. mode.systemPrompt
		// is the static base; we append a per-session repo map (Aider-style
		// top-level-symbols view) when the host exposes one. The repo map
		// is fetched lazily once per Agent instance and cached. Token cost:
		// ~5-8k tokens for a typical mid-sized repo, paid back many times
		// over by the model not needing to grep around for orientation.
		const repoMap = await this.getRepoMapCached();
		// 2026-06-03: project memory (IOM.md). Auto-loaded once per
		// session, prepended to the system prompt — Claude Code's
		// CLAUDE.md pattern. Lets users curate "things the agent should
		// always know about this project" in a single markdown file.
		// Wrapped in <project_memory> markers so the model can tell it
		// apart from the repo map and the static system prompt.
		const projectMemory = await this.getProjectMemoryCached();
		const systemPromptParts: string[] = [this.deps.mode.systemPrompt];
		if (projectMemory) {
			systemPromptParts.push(`<project_memory>\n${projectMemory}\n</project_memory>`);
		}
		if (repoMap) systemPromptParts.push(repoMap);
		const systemPromptWithMap = systemPromptParts.join("\n\n");
		// 2026-06-29: aggressive contextBudget → three complementary
		// wire-body transforms, applied in dependency order:
		//   1. Duplicate-read dedup: same-hash reads of the same path
		//      collapse to reference stubs (BEFORE shrink so it doesn't
		//      shrink a dedup stub twice — no-op but wasteful).
		//   2. Rolling tool_result truncation: everything else older than
		//      5 assistant turns collapses to summary stubs.
		//   3. JIT tool schemas: below.
		// Session history on disk stays verbatim through all of these.
		let wireMessages: readonly ConversationMessage[] = this.history;
		let wireTools: readonly ToolSpec[] = this.deps.tools;
		let jitDroppedHint = "";
		if (this.options.contextBudget === "aggressive") {
			// 1) Read-dedup first
			const deduped = dedupDuplicateReads(wireMessages);
			if (deduped.dedupCount > 0) {
				this.emit({
					type: "error",
					agentId: this.deps.id,
					message: `[read-dedup] aggressive mode collapsed ${deduped.dedupCount} duplicate read_file result${deduped.dedupCount === 1 ? "" : "s"} — saved ~${Math.round(deduped.bytesSaved / 1024).toLocaleString()}KB on the wire.`,
				});
			}
			wireMessages = deduped.messages;

			// 2) Rolling truncation
			const shrunk = shrinkOldToolResults(wireMessages);
			if (shrunk.truncatedCount > 0) {
				this.emit({
					type: "error",
					agentId: this.deps.id,
					message: `[context-shrink] aggressive mode replaced ${shrunk.truncatedCount} old tool_result${shrunk.truncatedCount === 1 ? "" : "s"} with summaries — saved ~${Math.round(shrunk.bytesSaved / 1024).toLocaleString()}KB on the wire (session history preserved intact for scrollback).`,
				});
			}
			wireMessages = shrunk.messages;

			// 3) JIT tool schemas. Only meaningful for openai-tools format
			// providers (Kimi native + inline-XML formats don't send tools[]
			// arrays). We can't reliably detect the format from here, so we
			// filter unconditionally — for non-tools-array formats the wire
			// impact is nil (they ignore the array anyway) so filtering is
			// harmless. Guarding: keep everything if tool count is small.
			if (this.deps.tools.length >= 12) {
				const lastUserMsg = findLastUserText(wireMessages);
				// 2026-06-29: promote any tool names the safety net has learned
				// about (from prior "unknown tool" errors this session) into
				// the effective core-set so they always ship with their schemas.
				const effectiveCore =
					this.jitAlwaysInclude.size > 0 ? [...CORE_TOOL_NAMES, ...this.jitAlwaysInclude] : undefined;
				const jit = filterToolsJIT(this.deps.tools, wireMessages, lastUserMsg, {
					...(effectiveCore ? { coreToolNames: effectiveCore } : {}),
				});
				if (jit.dropped.length > 0) {
					this.emit({
						type: "error",
						agentId: this.deps.id,
						message: `[jit-tools] aggressive mode kept ${jit.kept.length}/${this.deps.tools.length} tool schemas on the wire (dropped: ${jit.dropped.slice(0, 6).join(", ")}${jit.dropped.length > 6 ? `, +${jit.dropped.length - 6} more` : ""}). Safety net: dropped tools' NAMES stay in system prompt; the provider will retry with the missing schema if the model calls a pruned tool.`,
					});
					wireTools = jit.tools;
					jitDroppedHint = buildDroppedToolsHint(this.deps.tools, jit.dropped);
				}
			}
		}
		// 2026-06-29: append the JIT dropped-tools hint to the system prompt
		// so the model knows what still exists even though the schemas
		// aren't in tools[]. Empty when JIT didn't fire (normal mode, or
		// aggressive mode with < 12 tools).
		const finalSystemPrompt = jitDroppedHint
			? `${systemPromptWithMap}\n\n${jitDroppedHint}`
			: systemPromptWithMap;
		// Capture a wire-audit snapshot BEFORE dispatching so `/wire-audit`
		// sees exactly what went on the wire. Emitted as an AgentEvent the
		// host can route into its WireAuditRecorder ring buffer.
		const auditSnapshot = auditWireBody({
			modelId: this.options.modelId,
			systemPrompt: finalSystemPrompt,
			tools: wireTools,
			messages: wireMessages,
			turnIndex: this.history.length,
		});
		this.emit({
			type: "wire_audit",
			agentId: this.deps.id,
			snapshot: auditSnapshot,
		});
		const stream = this.deps.provider.stream({
			messages: wireMessages,
			tools: wireTools,
			modelId: this.options.modelId,
			systemPrompt: finalSystemPrompt,
			temperature: effectiveTemperature,
			maxTokens: quirks.maxTokens,
			signal: localAbort.signal,
		});

		let loopGuardTripped: string | undefined;
		try {
			for await (const ev of stream) {
				if (ev.type === "text_delta") {
					textChunks.push(ev.text);
					this.emit({ type: "text_delta", agentId: this.deps.id, text: ev.text });
					const tripReason = detectRunawayRepetition(textChunks);
					if (tripReason) {
						loopGuardTripped = tripReason;
						localAbort.abort();
						break;
					}
				} else if (ev.type === "reasoning_delta") {
					// 2026-06-01: accumulate reasoning into a separate channel
					// so it can ride on the assistant history as a ReasoningPart
					// (required by Kimi K2.6 — Moonshot refuses subsequent turns
					// when the original reasoning_content is missing on replay).
					// Also surface as text_delta with a 💭 marker on the first
					// chunk so the user sees the model thinking aloud — the
					// rendering stays the same as before this refactor.
					// Reasoning text deliberately does NOT feed the runaway-
					// repetition loop guard — models often repeat themselves
					// while reasoning aloud and that's harmless thought
					// revision, not stuck output.
					if (reasoningChunks.length === 0) {
						this.emit({ type: "text_delta", agentId: this.deps.id, text: "💭 " });
					}
					reasoningChunks.push(ev.text);
					this.emit({ type: "text_delta", agentId: this.deps.id, text: ev.text });
				} else if (ev.type === "tool_call") {
					// Normalize args at the source — the ToolCallPart is consumed by
					// (a) history, (b) approval preview, (c) approval dialog, (d) the
					// loop-guard fingerprint, and (e) the tool handler. Previously we
					// only normalized for (e), so preview/approval/fingerprint saw the
					// raw `{_raw: "..."}` shape: preview returned no diff, the user
					// approved a blank dialog, and each retry with a slightly different
					// escape level looked like a NEW fingerprint to the loop guard.
					// Normalizing at ingestion makes every downstream stage see the
					// unwrapped object Kimi actually meant to send.
					const normalizedArgs = normalizeToolArgs(ev.args);
					// 2026-05-25: history sanitization. If normalize still couldn't
					// reach a clean object (the wrapped-args shape persists past
					// our 8-layer unwrap), DON'T let that blob accumulate in
					// history — the model sees its own malformed payload on every
					// subsequent turn and the provider can silently return empty
					// because the input is too confused to act on. Replace with
					// a placeholder that names the specific failure mode +
					// recovery strategy so the model can break out of the loop.
					let safeArgs: unknown = normalizedArgs;
					// 2026-05-26: semantic contamination check. Even when JSON
					// parses cleanly + schema fields are present, the VALUE of
					// one field may have absorbed another field's content (e.g.
					// write_file's `path` ends up containing `","content":"...`
					// because escape boundaries collapsed). Catch that here so
					// we don't write a 200-char garbage filename to disk.
					const matchedForContam = this.deps.tools.find((t) => t.name === ev.name);
					const contamination = matchedForContam
						? detectFieldContamination(normalizedArgs, matchedForContam.schema)
						: undefined;
					if (isStillWrappedAfterNormalize(normalizedArgs) || contamination) {
						// Log the raw payload to the host's log so the user can
						// open the iOmCode Output channel and SEE what's failing
						// to parse — diagnosing wrapped-args requires the raw bytes.
						// Also emit a diagnostic event so the chat itself shows
						// the raw payload when verboseInternals is ON (webview
						// filters by the `[wrapped-args]` prefix when OFF, see
						// `isInternalAgentDiagnosticMessage`). This makes the
						// info one-click copy-paste-able instead of forcing the
						// user to hunt through the Output channel.
						let rawPreview = "";
						try {
							rawPreview = JSON.stringify(ev.args).slice(0, 800);
							const label = contamination ? "field-contamination" : "wrapped-args";
							this.deps.host.log?.("warn", `[${label}] tool=${ev.name} raw=${rawPreview}`);
						} catch {
							/* logging never blocks the loop */
						}
						this.emit({
							type: "error",
							agentId: this.deps.id,
							message: `[${contamination ? "field-contamination" : "wrapped-args"}] tool=${ev.name} ${contamination ?? `raw=${rawPreview}`}`,
						});
						const matched = matchedForContam;
						// 2026-05-25 (live-bug fix): smart args recovery. Better
						// prompting alone doesn't save us — Kimi K2.6 pattern-
						// matches "tool failed twice → give up" regardless of how
						// useful the hint is. The structural fix is to RECOVER
						// the args ourselves from the malformed raw payload
						// (regex-extract the schema's known fields with greedy-
						// last-quote matching that tolerates unescaped quotes /
						// newlines / backslashes in the captured value) and
						// proceed AS IF the call had been clean. Only fall back
						// to the placeholder hint when recovery genuinely
						// can't find the required fields.
						const recovered = matched ? tryRecoverWrappedArgs(normalizedArgs, matched.schema) : undefined;
						// 2026-05-26: recovery may extract fields but leave the
						// contamination intact (same string, different wrapper).
						// Re-check after recovery — if still contaminated, fall
						// through to the hint path so the model retries cleanly.
						const stillContaminated =
							recovered && matched ? detectFieldContamination(recovered, matched.schema) : undefined;
						if (recovered && !stillContaminated) {
							const recoveryMsg = `[wrapped-args] tool=${ev.name} recovered fields=${Object.keys(recovered).join(",")}`;
							try {
								this.deps.host.log?.("info", recoveryMsg);
							} catch {
								/* logging never blocks the loop */
							}
							// Surface the recovery in chat too (filtered by
							// verboseInternals) so the user knows the rescue
							// fired and which fields it pulled out.
							this.emit({
								type: "error",
								agentId: this.deps.id,
								message: recoveryMsg,
							});
							// 2026-05-29: arm the one-shot self-correction so the
							// dispatcher prepends a teach note to the first
							// tool_result the model sees in this turn.
							this.wrappedArgsAdvicePending = true;
							safeArgs = recovered;
						} else {
							// Build a hint that names the tool, the required schema, and
							// the most common cause for THIS tool. The model needs
							// specific guidance — "use plain JSON" alone isn't enough
							// when the JSON itself is being mangled by string escaping.
							const schemaHint = matched
								? `Tool \`${ev.name}\` expects: ${describeSchema(matched.schema)}.`
								: `Tool \`${ev.name}\` is registered but its schema couldn't be looked up.`;
							const causeHint =
								ev.name === "exec"
									? 'MOST COMMON CAUSE: your `command` argument contained an embedded multi-line string (PowerShell heredoc `@"…"@`, here-doc, or unescaped `\\n` / `\\"` / backtick). The model\'s tool-call JSON breaks when those embedded strings aren\'t properly escaped. FIX: write the script CONTENT to a file via `write_file` first (separate call), then `exec` ONLY the short command that runs the file (e.g. `python out/script.py`). Never put multi-line code inside the `command` string.'
									: ev.name === "write_file"
										? "MOST COMMON CAUSE: your `content` argument contained unescaped newlines, quotes, or backslashes that broke the tool-call JSON. FIX: ensure all `\\n`, `\\\"`, `\\\\` are properly escaped in the JSON string — most languages have a stdlib JSON encoder (Python's `json.dumps`, JS's `JSON.stringify`) that handles this correctly. If you're hand-writing the JSON, use `\\n` for newlines, `\\\"` for quotes, `\\\\` for backslashes."
										: "Re-emit the call with a plain JSON object — every value must be a valid JSON scalar/object/array, no embedded raw newlines or quotes.";
							safeArgs = {
								_oatiMalformed: true,
								_hint: `${schemaHint} ${causeHint}`,
							};
						}
					}
					// 2026-06-01: synthesize a fallback id when the provider
					// emits an empty/missing tool_call id. Live-bug: an
					// upstream call (Kimi-native or inline-XML parsed)
					// surfaced with `ev.id === ""`, which propagated through
					// to a tool_result with empty id, and the wire request
					// failed on the NEXT turn with `tool_call_id  is not
					// found` (note the double space — empty interpolated).
					// Synthesizing here means the assistant tool_call AND
					// its matching tool_result both carry the same non-empty
					// id, satisfying the API's pair-matching rule.
					// 2026-06-03: synth bug-fix. When the provider event has
					// both empty id AND empty name (model emitted a malformed
					// tool-call marker), the prior `${ev.name}:${idx}` form
					// produced ids like `":0"` — non-empty but colon-prefixed,
					// which slips through the wire-empty-id filter but the
					// upstream's matcher rejects with `tool_call_id  is not
					// found` (the upstream's display format collapses
					// leading colons). Coerce empty name to `"unknown"` so
					// the id always starts with a letter and is matchable.
					const synthName = typeof ev.name === "string" && ev.name.length > 0 ? ev.name : "unknown";
					const safeId =
						typeof ev.id === "string" && ev.id.length > 0 ? ev.id : `${synthName}:${toolCalls.length}`;
					const call: ToolCallPart = {
						kind: "tool_call",
						id: safeId,
						name: ev.name,
						args: safeArgs,
					};
					toolCalls.push(call);
					this.emit({ type: "tool_call", agentId: this.deps.id, call });
				} else if (ev.type === "usage") {
					usageInput += ev.usage.inputTokens;
					usageOutput += ev.usage.outputTokens;
					sawUsage = true;
				} else if (ev.type === "message_end") {
					stopReason = ev.stopReason;
				} else if (ev.type === "error") {
					// 2026-05-26: detect provider content-safety guardrail blocks.
					// OpenRouter (and a few other brokers) wrap a 403 with a
					// `guardrail_blocked` JSON body when their prompt-injection
					// classifier matches something in history. The default
					// error message is raw HTTP JSON — useless to a non-power
					// user. Surface an actionable diagnostic naming the index
					// of the offending message and the recovery options.
					const augmented = augmentGuardrailError(ev.message);
					this.emit({ type: "error", agentId: this.deps.id, message: augmented ?? ev.message });
					stopReason = "error";
					this.lastStreamErrored = true;
					// 2026-06-29: JIT tool-schema retry safety net. When the
					// provider rejects because the model referenced a tool whose
					// schema wasn't in tools[] (Anthropic native validates
					// strictly; some vLLM chat endpoints do too), extract the
					// offending tool name and mark it as "always include" for
					// the rest of this session. Next iteration will send its
					// schema. Non-invasive — only fires on error events that
					// actually match the unknown-tool pattern, so unrelated
					// errors pass through unchanged.
					if (this.options.contextBudget === "aggressive") {
						const unknownToolNames = extractUnknownToolNames(ev.message, this.deps.tools);
						for (const name of unknownToolNames) {
							if (!this.jitAlwaysInclude.has(name)) {
								this.jitAlwaysInclude.add(name);
								this.emit({
									type: "error",
									agentId: this.deps.id,
									message: `[jit-tools] provider rejected — tool \`${name}\` was JIT-dropped from tools[]. Promoted to always-include for this session; next iteration will retry with its schema on the wire.`,
								});
							}
						}
					}
				}
			}
		} finally {
			if (signal) signal.removeEventListener("abort", onCallerAbort);
		}

		if (loopGuardTripped) {
			this.emit({
				type: "error",
				agentId: this.deps.id,
				message: `Loop guard tripped — ${loopGuardTripped}. The agent was generating the same text repeatedly; aborted this turn so the chat doesn't fill up. Try cancelling, rephrasing, or switching modes.`,
			});
			stopReason = "error";
		}

		const assistantParts: MessagePart[] = [];
		// 2026-06-01: ReasoningPart goes FIRST so providers can mirror the
		// channel order on the wire (reasoning_content above content). The
		// position is mostly cosmetic for our consumers, but Moonshot's
		// thinking-mode constraint is strict about the field being present
		// — order doesn't matter, presence does.
		const reasoning = reasoningChunks.join("");
		if (reasoning.length > 0) assistantParts.push({ kind: "reasoning", text: reasoning });
		const text = textChunks.join("");
		if (text.length > 0) assistantParts.push({ kind: "text", text });
		for (const c of toolCalls) assistantParts.push(c);
		if (assistantParts.length > 0) {
			this.history.push({ role: "assistant", parts: assistantParts });
		}
		// Track whether the most-recent assistant turn contained any text so
		// the loop-end wrap-up safety net can detect "fired tools then went
		// silent" runs.
		this.lastAssistantHasText = text.length > 0;
		this.lastAssistantText = text;

		// Emit the consolidated usage AFTER the assistant message has landed so
		// the webview can attribute it to that turn's bubble.
		if (sawUsage) {
			this.emit({
				type: "usage",
				agentId: this.deps.id,
				inputTokens: usageInput,
				outputTokens: usageOutput,
			});
		}

		return stopReason === "tool_use" || toolCalls.length > 0 ? toolCalls : [];
	}

	/**
	 * Walk the assistant's most recent message in history, extract every
	 * file the model claimed to have created (`Created X.pptx`, `wrote
	 * out/foo.pdf`, etc.), and verify each via the host. Any missing file
	 * gets surfaced as a False-Done warning.
	 *
	 * Why we scan history rather than `lastAssistantText`: when the model
	 * emits its "Done" claim ALONGSIDE the final tool call (same iteration
	 * — e.g. exec to write a python file, exec to run it, and a "Done"
	 * sentence wrapping up — followed by the agent's natural loop exit
	 * iteration), `lastAssistantText` from the trailing empty iteration is
	 * "". The actual "Done" prose lives on the previous assistant message
	 * pushed to history. So we look there.
	 *
	 * Path resolution attempts, in order: as-given, `out/<name>`, `./<name>`
	 * (the last two only for bare filenames). Absolute paths are checked
	 * verbatim — `host.fileExists` passes them through.
	 */
	private async verifyFileCreationClaims(): Promise<void> {
		const lastAssistantText = findLastAssistantText(this.history);
		if (!lastAssistantText) return;
		const claims = extractFileCreationClaims(lastAssistantText);
		if (claims.length === 0) return;

		const missing: string[] = [];
		for (const path of claims) {
			try {
				if (await this.deps.host.fileExists(path)) continue;
				// Bare-filename fallback: model may have meant `out/<name>`
				// or `./<name>`. Skip when the path already has a separator.
				const isBare = !path.includes("/") && !path.includes("\\");
				if (isBare) {
					if (await this.deps.host.fileExists(`out/${path}`)) continue;
					if (await this.deps.host.fileExists(`./${path}`)) continue;
				}
				missing.push(path);
			} catch {
				/* host call failed — don't block the turn */
			}
		}
		if (missing.length === 0) return;

		const list = missing.map((p) => `  • \`${p}\``).join("\n");
		const wrap = [
			"⚠️ **False-Done check:** you claimed to have created the following file(s), but they do NOT exist on disk:",
			"",
			list,
			"",
			"Likely root causes — investigate in this order before retrying:",
			"  1. **The Python script errored** — re-read the most recent `exec` stdout/stderr. A typo (e.g. `p.size = Pt(14)` should be `p.font.size = Pt(14)`) makes the script throw and no file lands.",
			"  2. **You wrote the script but never ran it** — confirm there's an `exec` call that ACTUALLY invoked python on the script you wrote.",
			"  3. **Path mismatch** — the script saved to a different directory than you claimed. Echo the resolved absolute path in the script (`print(out_path)`) and check against your claim.",
			"  4. **You skipped the work entirely** — sometimes the model emits a Done claim with no real tool calls behind it. Don't do that. If you're stuck, ask the user; never fabricate success.",
			"",
			"Either fix the underlying issue and retry, or tell the user honestly what failed.",
		].join("\n");
		this.history.push({
			role: "assistant",
			parts: [{ kind: "text", text: wrap }],
		});
		this.emit({ type: "text_delta", agentId: this.deps.id, text: wrap });
	}

	/**
	 * Heuristic: does this turn's accumulated history look big enough that
	 * the provider might have choked on the request size / context budget?
	 *
	 * 2026-05-26 (revised): the threshold now scales with `contextWindow`.
	 * Small windows (Gemma 8K, Ollama default 8K) compact aggressively at
	 * 60% because hitting the wall is catastrophic. Large windows (Kimi
	 * 256K, Claude 200K) get 80%, and huge ones (Gemini 1M) get 90% —
	 * big-context models are SUPPOSED to handle big-project work; an
	 * agent that compacted Kimi K2.6 at 60% (~144K of 256K) would be
	 * leaving 100K+ tokens of useful context on the table. The user's
	 * point: "we should use the full capability and capacity of the
	 * coding model with respect to context window."
	 *
	 * Token estimate is coarse char-count / 4. The cost of being slightly
	 * off is one extra summarize call; the cost of NOT compacting is a
	 * silent empty turn (which is what we're here to avoid).
	 */
	/**
	 * 2026-05-30: thin wrapper for the supportsVision flag from the model
	 * quirks registry. Used to gate image-injection into history (we don't
	 * pay extra tokens to send an image_url block to a text-only model
	 * that can't process it).
	 */
	private modelSupportsVision(): boolean {
		return detectModelQuirks(this.options.modelId).supportsVision === true;
	}

	/**
	 * 2026-06-01: cached fetch of the host's repo map. Built once per
	 * Agent instance; subsequent calls return the cached string. When
	 * the host doesn't implement getRepoMap or the call returns nothing,
	 * caches null (distinct from undefined-as-uninitialized) so we don't
	 * re-try on every turn. Failures are swallowed — repo map is a
	 * quality-of-life feature, not a hard requirement.
	 */
	private async getRepoMapCached(): Promise<string | undefined> {
		if (this.repoMapCache !== undefined) {
			return this.repoMapCache ?? undefined;
		}
		const fn = this.deps.host.getRepoMap;
		if (!fn) {
			this.repoMapCache = null;
			return undefined;
		}
		try {
			const map = await fn({ tokenBudget: 8000 });
			this.repoMapCache = map && map.length > 0 ? map : null;
			return this.repoMapCache ?? undefined;
		} catch (err) {
			this.deps.host.log?.(
				"warn",
				`[repo-map] failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			this.repoMapCache = null;
			return undefined;
		}
	}

	/**
	 * 2026-06-03: load and cache the workspace's project-memory file
	 * (IOM.md). Same memoization shape as getRepoMapCached — read
	 * once per Agent instance, serve from cache afterward. Failures
	 * are swallowed and treated as "no memory file"; the agent still
	 * runs, just without the curated context.
	 */
	private async getProjectMemoryCached(): Promise<string | undefined> {
		if (this.projectMemoryCache !== undefined) {
			return this.projectMemoryCache ?? undefined;
		}
		const fn = this.deps.host.getProjectMemory;
		if (!fn) {
			this.projectMemoryCache = null;
			return undefined;
		}
		try {
			const memory = await fn();
			this.projectMemoryCache = memory && memory.length > 0 ? memory : null;
			return this.projectMemoryCache ?? undefined;
		} catch (err) {
			this.deps.host.log?.(
				"warn",
				`[project-memory] failed: ${err instanceof Error ? err.message : String(err)}`,
			);
			this.projectMemoryCache = null;
			return undefined;
		}
	}

	/**
	 * 2026-06-01: image-to-description demotion. Walks history finding
	 * all user messages that carry ImagePart entries; for every one
	 * EXCEPT the most recent, fires a vision sub-call to get a 3-4
	 * sentence text description and replaces the ImagePart with a
	 * TextPart carrying that description. Mutates `this.history` in
	 * place so the demotion persists across turns. Skipped images
	 * (already-demoted or just-described) are tracked in
	 * `describedImageHashes` to avoid re-describing.
	 *
	 * The wire-pruning in toWireMessages stays as a defense-in-depth
	 * fallback (e.g. for a model that lost vision support mid-session),
	 * but the primary path is now this in-history swap.
	 */
	private async demoteOldImages(signal?: AbortSignal): Promise<void> {
		// Find the index of the LAST user message bearing any ImagePart —
		// that one stays intact.
		let lastImageMsgIdx = -1;
		for (let i = 0; i < this.history.length; i++) {
			const m = this.history[i];
			if (m.role === "user" && m.parts.some((p) => p.kind === "image")) {
				lastImageMsgIdx = i;
			}
		}
		if (lastImageMsgIdx < 0) return; // no images at all
		// Walk every prior image-bearing user message and demote its images.
		for (let i = 0; i < lastImageMsgIdx; i++) {
			const m = this.history[i];
			if (m.role !== "user") continue;
			const hasImage = m.parts.some((p) => p.kind === "image");
			if (!hasImage) continue;
			// Build the replacement part list: text/reasoning parts stay,
			// every image gets replaced with a description (or a generic
			// breadcrumb if the sub-call fails).
			const newParts: MessagePart[] = [];
			for (const p of m.parts) {
				if (p.kind !== "image") {
					newParts.push(p);
					continue;
				}
				const key = quickHash(p.dataUrl);
				if (this.describedImageHashes.has(key)) {
					// Shouldn't happen — already-demoted images would have
					// been TextParts. Defensive: skip.
					continue;
				}
				this.describedImageHashes.add(key);
				const desc = await describeImage(
					p.dataUrl,
					p.mimeType,
					this.deps.provider,
					this.options.modelId,
					{ signal },
				).catch(() => undefined);
				const text = desc
					? `[iOm image memory] ${desc}`
					: `[iOm image memory] Earlier screenshot (${p.mimeType}) — the pixels have been released to keep the conversation within token budget. Re-capture if you need them again.`;
				newParts.push({ kind: "text", text });
			}
			// Mutate the message at index i with the new parts. ConversationMessage
			// is readonly at the type level; we splice in a fresh object.
			this.history[i] = { role: "user", parts: newParts };
		}
	}

	/**
	 * 2026-06-02: sliding window over image descriptions. The demote
	 * pass converts old ImageParts to text descriptions (~300 tokens
	 * each), which is great — but in a marathon session with 50+
	 * screenshots, even those descriptions accumulate (50 × 300 = 15k
	 * tokens of stale image memory). Past a certain age, the model
	 * doesn't need the description either; a tiny "image-from-earlier-
	 * turn" marker (~10 tokens) preserves the trace that something
	 * happened without paying for the recall.
	 *
	 * Runs AFTER demoteOldImages so it operates on the unified pool of
	 * description TextParts. Keeps the K most-recent descriptions
	 * intact; replaces the rest with a marker that names the page (if
	 * extractable from the original description) so the model can still
	 * reason about "I screenshotted the cart page" without the prose.
	 */
	private collapseOldImageDescriptions(keepRecent: number): void {
		if (keepRecent < 1) return;
		// Find all message indices that contain a description TextPart.
		const descIndices: number[] = [];
		for (let i = 0; i < this.history.length; i++) {
			const m = this.history[i];
			if (m.role !== "user") continue;
			if (m.parts.some((p) => p.kind === "text" && p.text.startsWith("[iOm image memory]"))) {
				descIndices.push(i);
			}
		}
		if (descIndices.length <= keepRecent) return; // nothing to collapse
		// Collapse all but the last `keepRecent`.
		const collapseUpTo = descIndices.length - keepRecent;
		for (let k = 0; k < collapseUpTo; k++) {
			const idx = descIndices[k];
			const msg = this.history[idx];
			const newParts: MessagePart[] = [];
			for (const p of msg.parts) {
				if (p.kind === "text" && p.text.startsWith("[iOm image memory]")) {
					// Try to extract a short page label from the description for
					// the marker (e.g., "the cart page" → keep that as the hint).
					const hint = extractDescriptionHint(p.text);
					newParts.push({
						kind: "text",
						text: hint
							? `[iOm image memory — collapsed, was: ${hint}]`
							: "[iOm image memory — earlier screenshot, collapsed to keep context lean]",
					});
				} else {
					newParts.push(p);
				}
			}
			this.history[idx] = { role: "user", parts: newParts };
		}
	}

	/**
	 * 2026-06-02: build the image-injection user-message parts, swapping
	 * ImageParts for TextPart descriptions when the resulting request
	 * would exceed the model's context budget.
	 *
	 * The check is deliberately per-image (not all-or-nothing) — if we're
	 * about to inject 3 images and the budget can fit 1, we keep the
	 * first as a real ImagePart and describe the rest. The model still
	 * sees the most-recent capture in full fidelity, but the older
	 * sibling captures get the description treatment.
	 *
	 * Emits a chat-visible error event so the user understands why their
	 * screenshot didn't come through as an image. Without the diagnostic,
	 * silent demotion would feel like a feature regression ("why didn't
	 * the model see my screenshot?").
	 */
	private async injectImagesRespectingBudget(
		images: readonly MessagePart[],
		signal?: AbortSignal,
	): Promise<MessagePart[]> {
		const quirks = detectModelQuirks(this.options.modelId);
		const budget = quirks.contextWindow - quirks.maxTokens;
		const threshold =
			quirks.contextWindow >= 500_000 ? 0.9 : quirks.contextWindow >= 100_000 ? 0.8 : 0.6;
		const ceiling = Math.floor(budget * threshold);
		const currentTokens = estimateMessagesTokens(this.history);
		// Pre-compute per-image token cost so we can decide individually.
		const imageCosts: number[] = images.map((p) =>
			p.kind === "image" ? estimateImageVisionTokens(p.dataUrl, p.mimeType) : 0,
		);
		const totalImageTokens = imageCosts.reduce((a, b) => a + b, 0);
		if (currentTokens + totalImageTokens <= ceiling) {
			// Everything fits. Default path — hoist all images as-is.
			return [
				{
					kind: "text",
					text: `[iOmCode inlined ${images.length} image${images.length === 1 ? "" : "s"} from the tool result${images.length === 1 ? "" : "s"} above so you can see ${images.length === 1 ? "it" : "them"} natively:]`,
				},
				...images,
			];
		}
		// At least one image needs to be demoted to a description.
		// Strategy: greedily keep images that fit; demote the rest. The
		// images arrive in order (most-recent-first per the collect
		// pipeline), so this preferentially keeps the most-recent visible.
		const out: MessagePart[] = [];
		let runningTotal = currentTokens;
		let demoted = 0;
		let kept = 0;
		for (let i = 0; i < images.length; i++) {
			const p = images[i];
			const cost = imageCosts[i];
			if (p.kind !== "image") {
				out.push(p);
				continue;
			}
			if (runningTotal + cost <= ceiling) {
				out.push(p);
				runningTotal += cost;
				kept++;
				continue;
			}
			// Doesn't fit — eagerly describe instead.
			demoted++;
			const desc = await describeImage(
				p.dataUrl,
				p.mimeType,
				this.deps.provider,
				this.options.modelId,
				{ signal },
			).catch(() => undefined);
			const text = desc
				? `[iOm image memory] ${desc}`
				: `[iOm image memory] Screenshot (${p.mimeType}) — the pixels were released because the resulting request would have exceeded the model's context budget (${Math.round(currentTokens / 1000)}k tokens in history + ${Math.round(cost / 1000)}k vision tokens for the image vs ~${Math.round(ceiling / 1000)}k available). Use the pageText field on the tool result, or re-capture with a tighter selector if you need to look again.`;
			out.push({ kind: "text", text });
			// Track that this image's hash has been "described" so the
			// inter-turn demote pass doesn't re-describe a description.
			this.describedImageHashes.add(quickHash(p.dataUrl));
		}
		// Headline text block: explain what happened so the model has
		// context and the user sees the budget triage in the chat.
		const headline =
			demoted === images.length
				? `[iOmCode inlined ${images.length} image description${images.length === 1 ? "" : "s"} (the actual screenshot${images.length === 1 ? "" : "s"} would have exceeded the model's ${Math.round(quirks.contextWindow / 1000)}k context budget):`
				: `[iOmCode inlined ${kept} screenshot${kept === 1 ? "" : "s"} + ${demoted} image description${demoted === 1 ? "" : "s"} (some screenshots were demoted to fit the model's context budget):`;
		this.emit({
			type: "error",
			agentId: this.deps.id,
			message: `[image-budget] history at ${Math.round(currentTokens / 1000)}k tokens + image${images.length === 1 ? "" : "s"} would have exceeded ~${Math.round(ceiling / 1000)}k threshold — eagerly described ${demoted} of ${images.length} image${images.length === 1 ? "" : "s"}.`,
		});
		return [{ kind: "text", text: headline }, ...out];
	}

	/**
	 * 2026-06-01: per-session file-read dedup. If `output` is a string
	 * (the normal read_file return shape) and we've seen the same content
	 * for the same path earlier in this session, return a short stub
	 * instead. The model already has the content in its scrolled-back
	 * context (or in compacted history's summary). If the file was
	 * written-to since the last read, invalidateFileReadHashes will have
	 * cleared the cached hash and this call returns the fresh content
	 * normally.
	 *
	 * Returns the input unchanged for non-string outputs (e.g.,
	 * read_file's broken-shape warning prepends, which return a string
	 * starting with "[OATI…]" — those still take the string code path).
	 */
	private maybeDedupeFileRead(args: unknown, output: unknown): unknown {
		if (typeof output !== "string") return output;
		const path = this.extractPathArg(args);
		if (!path) return output;
		const key = this.normalizePath(path);
		const hash = quickHash(output);
		const prior = this.fileReadHashes.get(key);
		if (prior === hash) {
			return `[iOm dedup: \`${path}\` is unchanged since the last time you read it this session. Use the prior result. If you need to verify a change, re-call read_file ONLY after a write_file/batch_file_edit on this path — otherwise the content is identical.]`;
		}
		this.fileReadHashes.set(key, hash);
		return output;
	}

	/**
	 * 2026-06-01: invalidate the dedup hash for paths the agent just
	 * wrote to. After invalidation the next read_file on this path
	 * returns the fresh content (not the stale dedup stub).
	 */
	private invalidateFileReadHashes(args: unknown): void {
		const path = this.extractPathArg(args);
		if (path) {
			this.fileReadHashes.delete(this.normalizePath(path));
			return;
		}
		// batch_file_edit and similar tools carry a `path` per item.
		if (args && typeof args === "object") {
			const edits = (args as Record<string, unknown>).edits;
			if (Array.isArray(edits)) {
				for (const e of edits) {
					const p = this.extractPathArg(e);
					if (p) this.fileReadHashes.delete(this.normalizePath(p));
				}
			}
		}
	}

	private extractPathArg(args: unknown): string | undefined {
		if (!args || typeof args !== "object") return undefined;
		const p = (args as Record<string, unknown>).path;
		return typeof p === "string" && p.length > 0 ? p : undefined;
	}

	private normalizePath(p: string): string {
		// Cheap normalization — lowercases the drive letter on Windows
		// (E:\foo and e:\foo are the same file) and collapses mixed slashes
		// so "src/a.ts" and "src\\a.ts" don't get counted as different
		// reads on Windows. Not full canonicalization (no symlink resolve);
		// false-positive cost is one extra read, false-negative cost is one
		// missed dedup — both are tolerable.
		return p.replace(/\\/g, "/").replace(/^([a-z]):/i, (_m, d) => `${d.toLowerCase()}:`);
	}

	private shouldAutoCompact(): boolean {
		const quirks = detectModelQuirks(this.options.modelId);
		const reservedOutput = quirks.maxTokens;
		const budget = quirks.contextWindow - reservedOutput;
		const used = estimateMessagesTokens(this.history);
		// 2026-06-29: threshold now honors the mode's contextBudget setting.
		// "aggressive" fires early (25%) to keep shared-gateway KV cache
		// free for concurrent requests; "generous" only fires at 95% to
		// leverage every byte of the model's window; "normal" keeps the
		// historical scaled-by-window behavior.
		const budgetPolicy = this.options.contextBudget ?? "normal";
		let threshold: number;
		if (budgetPolicy === "aggressive") {
			threshold = 0.25;
		} else if (budgetPolicy === "generous") {
			threshold = 0.95;
		} else {
			// "normal" — historical scaling by window size.
			threshold = quirks.contextWindow >= 500_000 ? 0.9 : quirks.contextWindow >= 100_000 ? 0.8 : 0.6;
		}
		return used > budget * threshold;
	}

	/**
	 * Replace the middle of `this.history` with a model-generated summary,
	 * keeping the head (task framing) and tail (recent context). Mirrors
	 * the host-side `compactHistory` behavior but lives inside the agent
	 * so the auto-compact safety net doesn't need a host roundtrip.
	 *
	 * 2026-05-26: head + tail sizes now scale with contextWindow. For
	 * 8K-window models we keep 2 + 10 (small footprint). For 100K+
	 * models we keep 2 + 20. For 500K+ we keep 4 + 30. The goal: when
	 * a big-window model needs compaction, we should NEVER drop into a
	 * smaller-than-necessary state — the whole point of the big window
	 * is preserving more context.
	 */
	private async compactHistoryMiddle(signal?: AbortSignal): Promise<void> {
		const quirks = detectModelQuirks(this.options.modelId);
		const HEAD = quirks.contextWindow >= 500_000 ? 4 : 2;
		const TAIL = quirks.contextWindow >= 500_000 ? 30 : quirks.contextWindow >= 100_000 ? 20 : 10;
		if (this.history.length <= HEAD + TAIL) return;
		// 2026-06-01: pair-safe boundaries. The naive slice cut between an
		// assistant message with `tool_calls` and its matching `tool`
		// response messages — leaving the wire request with dangling
		// `tool_call_id`s, which OpenAI rejects with `an assistant message
		// with 'tool_calls' must be followed by tool messages responding to
		// each 'tool_call_id'`. Adjust both boundaries to never split a
		// tool-call group: HEAD walks forward to include all tool responses
		// for its assistant calls; TAIL walks forward past any leading
		// orphan tool responses whose calls were in the dropped middle.
		const safeHeadEnd = findSafeHeadBoundary(this.history, HEAD);
		const safeTailStart = findSafeTailBoundary(
			this.history,
			Math.max(safeHeadEnd, this.history.length - TAIL),
		);
		if (safeTailStart <= safeHeadEnd) {
			// Boundaries collapsed — every message is part of an unsplit
			// tool-call group. Compaction would drop nothing; bail rather
			// than emit a confusing empty-summary marker.
			return;
		}
		const head = this.history.slice(0, safeHeadEnd);
		const tail = this.history.slice(safeTailStart);
		const middle = this.history.slice(safeHeadEnd, safeTailStart);
		const droppedCount = middle.length;
		let summaryText: string;
		try {
			const summary = (
				await summarizeHistorySegment(middle, this.deps.provider, this.options.modelId, {
					signal,
				})
			).trim();
			summaryText =
				summary.length > 0
					? `[Auto-compacted ${droppedCount} messages — context was filling up]\n\n${summary}`
					: `[Auto-compacted ${droppedCount} messages — context was filling up]`;
		} catch {
			summaryText = `[Auto-compacted ${droppedCount} messages — context was filling up]`;
		}
		const marker: ConversationMessage = {
			role: "system",
			parts: [{ kind: "text", text: summaryText }],
		};
		// 2026-06-03: archive the dropped middle to disk BEFORE mutating
		// in-memory history. The model can read it back later via the
		// `read_session_archive` tool when the summary alone isn't enough.
		// Best-effort — disk failures don't break the compact flow.
		const archiveFn = this.deps.host.appendToSessionArchive;
		if (archiveFn) {
			try {
				const transcript = renderSegmentAsTranscript(middle);
				const block =
					`\n\n## Compacted segment — ${new Date().toISOString()}\n` +
					`Dropped ${droppedCount} messages. Summary kept in chat as:\n` +
					`> ${summaryText.split("\n").join("\n> ")}\n\n` +
					`### Full transcript\n\n${transcript}\n`;
				await archiveFn(this.deps.id, block);
			} catch (err) {
				this.deps.host.log?.(
					"warn",
					`[compact-archive] failed to write archive: ${err instanceof Error ? err.message : String(err)}`,
				);
			}
		}
		this.history.length = 0;
		this.history.push(...head, marker, ...tail);
	}

	private async executeToolCalls(calls: readonly ToolCallPart[]): Promise<ToolResultPart[]> {
		const results: ToolResultPart[] = [];
		for (const call of calls) {
			// 2026-05-29: repeated-failure short-circuit. If the model has
			// already failed THREE times with THIS same call (toolName +
			// args signature), bail out with a clear error instead of
			// letting it keep looping. The signature uses a truncated
			// args dump so near-identical calls (same broken JSON
			// re-emitted with one character flipped) still match.
			const sig = computeCallSignature(call);
			const tracked = this.repeatedFailureSignatures.find((e) => e.sig === sig);
			if (tracked && tracked.count >= 3) {
				const r: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: `STOPPING: this call to \`${call.name}\` has failed ${tracked.count} times with the same arguments. The model appears stuck. Please look at the most recent diagnostic messages (search for \`field-contamination\`, \`wrapped-args\`, or \`Tool args validation failed\` in the transcript) for the specific fix. Common causes: arguments were double-encoded as a JSON-string-inside-a-string, content had unescaped quotes / newlines, or the path field absorbed adjacent fields. Re-emit the call as a flat JSON object: {"path": "...", "content": "..."}, NEVER a quoted JSON blob.`,
					isError: true,
				};
				results.push(r);
				this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
				continue;
			}

			const spec = this.deps.tools.find((t) => t.name === call.name);
			if (!spec) {
				const r: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: `Tool not found: ${call.name}`,
					isError: true,
				};
				results.push(r);
				this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
				continue;
			}

			if (spec.approval === "deny") {
				const r: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: `Tool denied by policy: ${call.name}`,
					isError: true,
				};
				results.push(r);
				this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
				continue;
			}

			if (spec.approval === "prompt") {
				let preview: import("@iom/shared").ApprovalPreview | undefined;
				if (spec.prepareApprovalPreview) {
					try {
						preview = await spec.prepareApprovalPreview(call.args, this.deps.host);
					} catch {
						// Preview failure shouldn't block approval prompt
					}
				}
				if (preview?.diff) {
					// Also surface a native diff editor (host opens it side-by-side)
					await this.deps.host.showDiff(preview.diff).catch(() => undefined);
				}
				const approved = await this.deps.host.requestApproval({
					toolName: spec.name,
					args: call.args,
					summary: spec.description,
					preview,
				});
				if (!approved) {
					const r: ToolResultPart = {
						kind: "tool_result",
						id: call.id,
						output: "User declined to approve this tool invocation.",
						isError: true,
					};
					results.push(r);
					this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
					continue;
				}
			}

			try {
				// Args were normalized at ingestion (see the `tool_call` branch
				// in streamOnce). We still call normalize here as a defensive
				// no-op in case a future code path constructs a ToolCallPart
				// without going through that ingestion site — normalize is
				// idempotent on already-clean input.
				const normalizedArgs = normalizeToolArgs(call.args);

				// 2026-05-29: short-circuit when ingestion flagged the args as
				// malformed-and-unrecoverable. Without this, the carefully-
				// crafted `_hint` we set in the streamOnce branch gets eaten by
				// the handler's own schema validator which then surfaces a
				// generic "invalid args" — the model never sees our specific
				// fix-it guidance. Return the hint as the tool result so it
				// lands directly in the model's next-iteration context.
				if (
					normalizedArgs &&
					typeof normalizedArgs === "object" &&
					(normalizedArgs as Record<string, unknown>)._oatiMalformed === true
				) {
					const hint = (normalizedArgs as Record<string, unknown>)._hint;
					const r: ToolResultPart = {
						kind: "tool_result",
						id: call.id,
						output:
							typeof hint === "string"
								? hint
								: `Tool args were malformed and couldn't be auto-recovered. Re-emit the call as a flat JSON object with each argument as a separate key.`,
						isError: true,
					};
					results.push(r);
					this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
					continue;
				}

				// 2026-05-29: per-tool shape check. Catches "the args parsed but
				// the values are obviously broken" — a 9000-char path, a
				// command with newlines, a path that contains a literal JSON-
				// field-boundary substring. Returns a descriptive error the
				// model can actually act on instead of letting the failure
				// surface as EINVAL from the filesystem layer.
				const shapeProblem = detectToolArgShapeProblem(call.name, normalizedArgs);
				if (shapeProblem) {
					const r: ToolResultPart = {
						kind: "tool_result",
						id: call.id,
						output: shapeProblem,
						isError: true,
					};
					results.push(r);
					this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
					continue;
				}

				const output = await spec.handler(normalizedArgs, this.deps.host, {
					callId: call.id,
					agentId: this.deps.id,
				});
				// 2026-06-01: per-session file-read dedup. If the model just
				// re-read a file whose contents haven't changed since the
				// last time it read them this session, swap the bulky string
				// payload for a short "unchanged" note. Saves ~30k tokens
				// per 2000-line repeat. Also tracks writes: a write to a
				// path invalidates the cached hash so a subsequent read
				// returns the fresh content.
				const dedupedOutput =
					call.name === "read_file" ? this.maybeDedupeFileRead(normalizedArgs, output) : output;
				if (call.name === "write_file" || call.name === "batch_file_edit") {
					this.invalidateFileReadHashes(normalizedArgs);
				}
				const r: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: dedupedOutput,
					isError: false,
				};
				results.push(r);
				this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
			} catch (err) {
				const r: ToolResultPart = {
					kind: "tool_result",
					id: call.id,
					output: err instanceof Error ? err.message : String(err),
					isError: true,
				};
				results.push(r);
				this.emit({ type: "tool_result", agentId: this.deps.id, result: r });
			}

			// 2026-05-29: update the repeated-failure ledger after every
			// result. Success clears the signature (model recovered);
			// failure increments. We use the LAST result we pushed (results
			// is append-only) to read isError.
			const lastResult = results[results.length - 1];
			if (lastResult) {
				const idx = this.repeatedFailureSignatures.findIndex((e) => e.sig === sig);
				if (lastResult.isError) {
					if (idx >= 0) {
						this.repeatedFailureSignatures[idx] = {
							sig,
							count: this.repeatedFailureSignatures[idx].count + 1,
						};
					} else {
						this.repeatedFailureSignatures.push({ sig, count: 1 });
					}
				} else if (idx >= 0) {
					this.repeatedFailureSignatures.splice(idx, 1);
				}
			}
		}
		// 2026-05-29: one-shot wrapped-args self-correction. The note only
		// prepends on the FIRST recovery-of-the-turn — once
		// `wrappedArgsAdviceEmittedThisTurn` is set, subsequent batches that
		// recover (the model keeps wrapping anyway because it's a structural
		// Kimi quirk, not a learnable mistake) stay quiet. Without this
		// per-turn gate the 30-call scaffold rendered the same teach note
		// 15+ times before the user reported it as noise.
		if (
			this.wrappedArgsAdvicePending &&
			!this.wrappedArgsAdviceEmittedThisTurn &&
			results.length > 0
		) {
			this.wrappedArgsAdvicePending = false;
			this.wrappedArgsAdviceEmittedThisTurn = true;
			const first = results[0];
			results[0] = {
				...first,
				output: `${WRAPPED_ARGS_SELF_CORRECTION}\n\n---\n\n${stringifyToolOutput(first.output)}`,
			};
		} else {
			// Drain the per-batch flag so it doesn't leak across batches.
			this.wrappedArgsAdvicePending = false;
		}
		return results;
	}
}

const WRAPPED_ARGS_SELF_CORRECTION = [
	"⚠️ [iOm auto-correction, one-shot] Your previous tool args came in WRAPPED — a JSON-string-inside-a-JSON-string instead of a flat object. iOmCode recovered the fields automatically and the call below succeeded, but the model continued repeating the same wrapping on later calls.",
	"",
	"For ALL remaining tool calls this turn, emit args as a flat JSON object directly. Examples of the CORRECT shape:",
	"",
	'  write_file: {"path": "src/foo.ts", "content": "<actual file content>"}',
	'  exec:       {"command": "npm test"}',
	'  read_file:  {"path": "src/foo.ts"}',
	"",
	'NOT a string: `{"_raw": "{\\"path\\":\\"...\\"}"}`. NOT double-quoted: `"{\\"path\\":\\"...\\"}"`. Just the plain object — keys and values, no outer wrapping.',
	"",
	"If you can't comply (the tool client is forcing the wrap), say so in plain text rather than emitting another wrapped call.",
].join("\n");

function stringifyToolOutput(output: unknown): string {
	if (typeof output === "string") return output;
	try {
		return JSON.stringify(output);
	} catch {
		return String(output);
	}
}

/**
 * 2026-05-29: tools whose only effect is reading information back into
 * the model's context. When the LAST tool call(s) in a turn are all
 * from this set AND the model went silent afterward, the model is stuck
 * — it gathered context but never followed up with the actual work.
 *
 * NOT exhaustive: tools that mutate state (write_file, edit, exec) are
 * intentionally absent. After a mutation, "Done" is a legitimate
 * conclusion even if the model didn't write a closing summary, so we
 * let the existing honest-Done synthesis handle that case.
 */
const INVESTIGATORY_TOOLS = new Set([
	"workspace_context",
	"get_workspace_context",
	"read_file",
	"list_dir",
	"list_directory",
	"grep_search",
	"find_definition",
	"find_references",
	"symbols_in_file",
	"get_diagnostics",
	"code_semantic_search",
	"codebase_deep_search",
	"search_files",
	"read_notebook",
	"read_notebook_cell",
	"list_knowledge",
	"search_knowledge",
	"recall_facts",
	"read_shared_notes",
	"list_snippets",
	"list_hooks",
	"list_skills",
	"git_status",
	"git_diff",
	"fetch_url",
	"web_search",
]);

/**
 * Build the fix-intent nudge text. When the user named specific files,
 * include them literally so the model can't be vague — instead of "you
 * didn't write any file," the nudge says "you didn't write `index.html`."
 */
function buildFixIntentNudge(userMessage: string): string {
	const paths = extractFilePaths(userMessage);
	const target =
		paths.length === 1
			? `\`${paths[0]}\``
			: paths.length > 1
				? paths.map((p) => `\`${p}\``).join(", ")
				: "the file(s) the user asked you to fix";
	const targetLine =
		paths.length > 0
			? `You did NOT write or edit ${target} — the file${paths.length === 1 ? "" : "s"} the user explicitly pointed you at. Mutations to helper/scaffolding files (server scripts, configs, READMEs) do not count as fixing what was asked.`
			: "You said you'd fix this but didn't write or edit any file — every tool call this turn was read-only / investigation / screenshot.";
	return [
		targetLine,
		"",
		"Choose ONE:",
		`  1. Apply the fix NOW. Use \`write_file\` on ${target} (or \`batch_file_edit\` / \`smart_apply_patch\`). If you already saw the defect — a file has literal \`\\n\` chars instead of real newlines, a CSS selector is misspelled, a variable is undefined — make the edit on ${target} directly.`,
		"  2. If you're not sure WHAT to change, use `browser_eval` to read the DOM (`document.body.innerText.slice(0, 800)`) or re-read the source file and find the specific defect — then apply the fix.",
		"  3. If you genuinely can't fix it (missing access, ambiguous requirement, external dependency), say so explicitly: 'I can't fix this because X — please confirm Y so I can proceed.'",
		"",
		`Do NOT claim Done without changing ${target} OR explaining why no change is possible.`,
	].join("\n");
}

/**
 * 2026-05-30: tools that meaningfully change workspace state. Used by the
 * fix-intent-without-mutation detector to decide whether a "fix this"
 * turn actually applied a fix or just investigated. Kept locally instead
 * of importing from chat-panel to avoid agent-core → extension-host
 * inversion.
 */

/**
 * 2026-05-30: tools that meaningfully change workspace state. Used by the
 * fix-intent-without-mutation detector to decide whether a "fix this"
 * turn actually applied a fix or just investigated. Kept locally instead
 * of importing from chat-panel to avoid agent-core → extension-host
 * inversion.
 */
/**
 * 2026-05-30: scan freshly-dispatched tool results for image-shaped
 * output and return them as ImagePart blocks ready for injection into
 * a follow-up user message. Recognised shape: the result's `output`
 * field is an object containing a `dataUrl` string that starts with
 * `data:image/<type>;base64,`. This matches `browser_screenshot`'s
 * return shape AND `extract_image_text`'s eventual dataUrl input
 * passthrough; future image-producing tools can opt in by using the
 * same convention.
 *
 * Exported for tests.
 */
/**
 * 2026-06-01: per-result history hygiene. Two jobs:
 *   1. Cap the string-content size of any tool_result that exceeds
 *      MAX_TOOL_RESULT_CHARS (~32k chars ≈ 8k tokens). Includes both
 *      string outputs and string-typed fields of object outputs. The
 *      truncated portion is replaced with a clear footer so the model
 *      knows to re-call with offset/limit if it needs more.
 *   2. Strip `dataUrl` fields when the image has already been hoisted
 *      into an ImagePart in a separate user follow-up message — keeps
 *      the screenshot in history exactly once (as the visual block)
 *      instead of duplicating its base64 payload in the tool_result.
 *      pageText and other DOM-extract fields stay; they're cheap and
 *      useful as text fallback.
 */
const MAX_TOOL_RESULT_CHARS = 32_000;
const MAX_TOOL_RESULT_FIELD_CHARS = 16_000;
export function trimToolResultForHistory(
	r: ToolResultPart,
	hasImageHoist: boolean,
): ToolResultPart {
	const transformed = transformOutputForHistory(r.output, hasImageHoist);
	if (transformed === r.output) return r;
	return { ...r, output: transformed };
}

function transformOutputForHistory(output: unknown, hasImageHoist: boolean): unknown {
	if (typeof output === "string") {
		if (output.length <= MAX_TOOL_RESULT_CHARS) return output;
		return `${output.slice(0, MAX_TOOL_RESULT_CHARS)}\n\n[... truncated by iOmCode: showed first ${MAX_TOOL_RESULT_CHARS.toLocaleString()} of ${output.length.toLocaleString()} chars to stay within context budget. Re-call the tool with an offset/limit/grep argument (when supported) to see the rest.]`;
	}
	if (!output || typeof output !== "object") return output;
	const obj = output as Record<string, unknown>;
	let mutated = false;
	const out: Record<string, unknown> = {};
	for (const [k, v] of Object.entries(obj)) {
		// dataUrl hoisting: when the image has already been hoisted to an
		// ImagePart, replace the long base64 string with a short marker.
		if (
			hasImageHoist &&
			k === "dataUrl" &&
			typeof v === "string" &&
			/^data:image\/[\w+-]+;base64,/i.test(v)
		) {
			out[k] = "[iOm: image hoisted to a separate user message — see the inlined attachment below.]";
			mutated = true;
			continue;
		}
		// Per-field string truncation. Uses a smaller cap than the whole-
		// output cap so a single huge field can't dominate the result.
		if (typeof v === "string" && v.length > MAX_TOOL_RESULT_FIELD_CHARS) {
			out[k] =
				`${v.slice(0, MAX_TOOL_RESULT_FIELD_CHARS)}\n\n[... truncated by iOmCode: ${k} was ${v.length.toLocaleString()} chars; showed first ${MAX_TOOL_RESULT_FIELD_CHARS.toLocaleString()}.]`;
			mutated = true;
			continue;
		}
		out[k] = v;
	}
	return mutated ? out : output;
}

export function collectImageInjections(results: readonly ToolResultPart[]): MessagePart[] {
	const out: MessagePart[] = [];
	for (const r of results) {
		if (r.isError) continue;
		const o = r.output;
		if (!o || typeof o !== "object") continue;
		const dataUrl = (o as Record<string, unknown>).dataUrl;
		if (typeof dataUrl !== "string") continue;
		const match = /^data:(image\/[\w+-]+);base64,/i.exec(dataUrl);
		if (!match) continue;
		out.push({
			kind: "image",
			mimeType: match[1],
			dataUrl,
		});
	}
	return out;
}

const MUTATING_TOOLS = new Set([
	"write_file",
	"batch_file_edit",
	"edit_notebook_cell",
	"insert_notebook_cell",
	"delete_notebook_cell",
	"smart_apply_patch",
	"multi_cursor_edit",
]);

/**
 * Pattern-match the user's message for "I need this fixed" intent. Used
 * by the fix-intent-without-mutation detector. False positives are cheap
 * (one extra nudge), false negatives mean letting a "Done without doing"
 * turn through, so the patterns lean inclusive.
 */
export function isFixIntent(message: string): boolean {
	if (typeof message !== "string" || message.length === 0) return false;
	const lower = message.toLowerCase();
	// Direct verbs.
	if (/\b(fix|repair|debug|patch|resolve|correct|address|sort\s+out)\b/.test(lower)) {
		return true;
	}
	// Stative descriptions implying something needs fixing.
	if (
		/\b(broken|not\s+working|doesn'?t\s+work|isn'?t\s+working|won'?t\s+work|failing|bug\b|buggy)/.test(
			lower,
		)
	) {
		return true;
	}
	// Imperative "make X work[ing]" / "get X work[ing]" / "get X to work".
	// Allow up to a short noun phrase (3 words) between the verb and the
	// "work" target so "get the build working again" or "get this to work
	// with the new API" still match.
	if (/\b(make|get)\s+\S+(\s+\w+){0,3}\s+(work|working|to\s+work)\b/.test(lower)) {
		return true;
	}
	return false;
}

/**
 * Count mutating tool calls in the CURRENT turn — i.e. between the most
 * recent user message and the end of history. Used by the fix-intent
 * detector to decide whether the agent actually applied any changes.
 */
export function countMutationsThisTurn(history: readonly ConversationMessage[]): number {
	let startIdx = -1;
	for (let i = history.length - 1; i >= 0; i--) {
		if (history[i].role === "user") {
			startIdx = i;
			break;
		}
	}
	if (startIdx < 0) startIdx = 0;
	let count = 0;
	for (let i = startIdx; i < history.length; i++) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		for (const p of msg.parts) {
			if (p.kind === "tool_call" && MUTATING_TOOLS.has(p.name)) count++;
		}
	}
	return count;
}

/**
 * 2026-05-30: count mutations whose target file is actually RELEVANT to
 * the user's ask. Relevance = the file path appears in the user's
 * message OR the agent read it earlier in the same turn. Tightens
 * `countMutationsThisTurn` so the fix-intent detector doesn't get
 * fooled by a turn that writes a server-helper script and ignores the
 * actual broken file the user pointed at.
 *
 * Fallback: when no relevant file set can be inferred (user said
 * "fix this" with no path AND the agent read nothing), we count ANY
 * mutation as relevant. The signal is too weak otherwise; we'd rather
 * false-negative (skip the nudge) than false-positive (nag on a
 * legit single-file edit the user didn't name).
 *
 * Exported for tests.
 */
export function countRelevantMutationsThisTurn(
	history: readonly ConversationMessage[],
	userMessage: string,
): number {
	let startIdx = -1;
	for (let i = history.length - 1; i >= 0; i--) {
		if (history[i].role === "user") {
			startIdx = i;
			break;
		}
	}
	if (startIdx < 0) startIdx = 0;

	// 2026-05-30 follow-up: STRICT hierarchy of relevance.
	//   1. If the user's prompt named specific file paths, ONLY those
	//      count. Reading + writing a helper file (serve.py, etc.) is
	//      not a fix for the user's actual ask — the model is wandering.
	//   2. If the prompt named no paths, fall back to files the agent
	//      read this turn — those represent what the agent decided was
	//      in scope.
	//   3. If even that's empty, count any mutation. The signal is too
	//      weak to nudge confidently otherwise.
	//
	// The original implementation UNION'd prompt + read paths, which let
	// "read serve.py + write serve.py" satisfy the detector even when
	// the user asked to fix index.html. Strict hierarchy closes that hole.
	const promptPaths = extractFilePaths(userMessage);
	const readPaths: string[] = [];
	for (let i = startIdx; i < history.length; i++) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		for (const part of msg.parts) {
			if (part.kind !== "tool_call") continue;
			if (part.name !== "read_file" && part.name !== "list_dir" && part.name !== "list_directory")
				continue;
			const args = part.args as Record<string, unknown> | undefined;
			const path = args && typeof args.path === "string" ? args.path : "";
			if (path) readPaths.push(basenameLower(path));
		}
	}
	const relevant = new Set<string>(promptPaths.length > 0 ? promptPaths : readPaths);

	let count = 0;
	for (let i = startIdx; i < history.length; i++) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		for (const part of msg.parts) {
			if (part.kind !== "tool_call" || !MUTATING_TOOLS.has(part.name)) continue;
			const paths = extractMutationTargetPaths(part);
			if (paths.length === 0) continue;
			// Fallback: when relevance set is empty, count any mutation.
			if (relevant.size === 0) {
				count++;
				continue;
			}
			if (paths.some((p) => relevant.has(basenameLower(p)))) {
				count++;
			}
		}
	}
	return count;
}

/**
 * Extract plausible file paths from a free-form user message. Matches
 * `\w/-:`-style sequences that end in a dot-extension. Doesn't try to
 * be comprehensive — false positives in the relevant set just make the
 * detector a touch more permissive, which is the safer side.
 */
function extractFilePaths(message: string): string[] {
	if (typeof message !== "string" || message.length === 0) return [];
	const out: string[] = [];
	const re = /[\w./\\:-]+\.[A-Za-z]{1,10}\b/g;
	for (const m of message.matchAll(re)) out.push(basenameLower(m[0]));
	return out;
}

function extractMutationTargetPaths(call: { name: string; args: unknown }): string[] {
	const args = call.args as Record<string, unknown> | undefined;
	if (!args) return [];
	const out: string[] = [];
	for (const key of ["path", "filePath", "file"]) {
		const v = args[key];
		if (typeof v === "string" && v.length > 0) out.push(v);
	}
	// batch_file_edit carries an `edits: [{path, ...}]` array.
	if (call.name === "batch_file_edit" && Array.isArray(args.edits)) {
		for (const e of args.edits as unknown[]) {
			if (e && typeof e === "object") {
				const p = (e as Record<string, unknown>).path;
				if (typeof p === "string" && p.length > 0) out.push(p);
			}
		}
	}
	return out;
}

function basenameLower(p: string): string {
	const slash = Math.max(p.lastIndexOf("/"), p.lastIndexOf("\\"));
	return (slash >= 0 ? p.slice(slash + 1) : p).toLowerCase();
}

/**
 * Did the LAST assistant message's tool calls consist entirely of
 * investigatory (read-only) tools? Walks back to the most recent
 * assistant message and inspects its tool_call parts.
 */
export function lastToolCallsAreInvestigatory(history: readonly ConversationMessage[]): boolean {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const calls = msg.parts.filter((p) => p.kind === "tool_call");
		if (calls.length === 0) return false;
		// EVERY call must be investigatory — even one mutation downgrades
		// the verdict to "the model did real work, silence might be done".
		return calls.every(
			(c) => c.kind === "tool_call" && typeof c.name === "string" && INVESTIGATORY_TOOLS.has(c.name),
		);
	}
	return false;
}

/**
 * 2026-05-29: stable signature for a tool call. Uses the tool name and
 * a truncated JSON dump of args so near-identical calls (the same
 * malformed JSON re-emitted with one character flipped) still match —
 * the model often retries with one-character variations that look fresh
 * but produce identical failures.
 */
function computeCallSignature(call: { name: string; args: unknown }): string {
	let argsHash: string;
	try {
		argsHash = JSON.stringify(call.args ?? {}).slice(0, 240);
	} catch {
		argsHash = String(call.args).slice(0, 240);
	}
	return `${call.name}::${argsHash}`;
}

/**
 * Cheap heuristic to catch a provider stuck repeating itself. If the tail of
 * the accumulated text contains the same line repeated more than N times in a
 * row, or a short phrase repeated many times back-to-back, trip the guard.
 *
 * Returns a human-readable reason when tripped, or undefined to continue. Runs
 * on every text delta so it has to stay cheap — only looks at the last ~4 KB
 * of accumulated output.
 */
const LOOP_GUARD_TAIL_BYTES = 4096;
const LOOP_GUARD_LINE_REPEATS = 8;
const LOOP_GUARD_PHRASE_LEN = 80;
const LOOP_GUARD_PHRASE_REPEATS = 6;

export function detectRunawayRepetition(chunks: readonly string[]): string | undefined {
	let tailLen = 0;
	const tailParts: string[] = [];
	for (let i = chunks.length - 1; i >= 0; i--) {
		const c = chunks[i];
		tailParts.unshift(c);
		tailLen += c.length;
		if (tailLen >= LOOP_GUARD_TAIL_BYTES) break;
	}
	const tail = tailParts.join("");
	if (tail.length < 200) return undefined;

	// Repeated identical lines back-to-back (most common runaway shape).
	// Trim trailing empty entries first — they're artifacts of a trailing \n
	// and would otherwise break the "all equal" check.
	const rawLines = tail.split("\n");
	let endIdx = rawLines.length;
	while (endIdx > 0 && rawLines[endIdx - 1].trim().length === 0) endIdx--;
	const lines = rawLines.slice(0, endIdx);
	if (lines.length >= LOOP_GUARD_LINE_REPEATS) {
		const recent = lines.slice(-LOOP_GUARD_LINE_REPEATS).map((l) => l.trim());
		const first = recent[0];
		if (first.length > 8 && recent.every((l) => l === first)) {
			return `the same line repeated ${LOOP_GUARD_LINE_REPEATS}× ("${first.slice(0, 60)}${first.length > 60 ? "…" : ""}")`;
		}
	}

	// Repeated short phrase regardless of line breaks.
	const phrase = tail.slice(-LOOP_GUARD_PHRASE_LEN);
	let count = 0;
	let idx = tail.length;
	while (idx >= phrase.length) {
		idx = tail.lastIndexOf(phrase, idx - 1);
		if (idx < 0) break;
		count++;
		if (count >= LOOP_GUARD_PHRASE_REPEATS) {
			return `the same ${LOOP_GUARD_PHRASE_LEN}-char phrase repeated ${LOOP_GUARD_PHRASE_REPEATS}+ times`;
		}
	}
	return undefined;
}

// Tool-call arg normalization moved to its own module so it can be
// imported standalone (e.g. by the bench harness) without dragging in
// the Agent class. Re-exported here for back-compat with existing
// callers; the Agent class above uses it via the top-of-file import.

/**
 * Detect that the agent is stuck retrying variations of the same goal.
 * Three patterns we trip on:
 *
 *   1. CONSECUTIVE DUPLICATES — 3+ identical fingerprints in a row.
 *      Classic "model thinks the next call will magically work" loop.
 *
 *   2. WINDOW DUPLICATES — same fingerprint appears 3+ times within the
 *      last 6 calls even when interleaved with other tool attempts.
 *      Catches the common "Read, Read(abs), Read, exec(cmd), exec(bash),
 *      Read, …" pattern where the model varies the approach slightly
 *      but keeps returning to the same failing call.
 *
 *   3. TOOL MONOCULTURE — same tool name dominates the last 6 calls
 *      (5+ of 6 are the same tool). The model is stuck on one tool
 *      even when its args change, which usually means the underlying
 *      precondition (workspace root, file existence, permissions) is
 *      the real problem and no amount of tool re-invocation will fix it.
 *
 * Exposed for unit tests.
 */
export function detectStuckPattern(
	fingerprints: readonly string[],
): { reason: string } | undefined {
	if (fingerprints.length < 3) return undefined;

	// Pattern 1 — consecutive identical.
	const last3 = fingerprints.slice(-3);
	if (last3.every((fp) => fp === last3[0])) {
		const [name] = last3[0].split("::");
		return { reason: `tool '${name}' called identically 3× in a row` };
	}

	// Pattern 2 — same fingerprint appears 3+ times in the recent window.
	const recent = fingerprints.slice(-6);
	const fpCounts = new Map<string, number>();
	for (const fp of recent) fpCounts.set(fp, (fpCounts.get(fp) ?? 0) + 1);
	for (const [fp, count] of fpCounts) {
		if (count >= 3) {
			const [name] = fp.split("::");
			return {
				reason: `tool '${name}' called with identical args ${count}× in the last ${recent.length} calls (interleaved retries don't count as progress)`,
			};
		}
	}

	// Pattern 3 — one tool dominates the recent window AND the model isn't
	// making progress. The original guard fired purely on tool-name count,
	// which false-positived on legitimate batch work (writing 23 files for
	// a project scaffold: 5 consecutive write_file calls with DIFFERENT
	// paths is progress, not a stall). The refined rule: a dominating tool
	// only counts as stuck when its fingerprints aren't diverse — i.e. the
	// model keeps retrying ≤2 distinct argument shapes rather than working
	// through a list of N distinct targets. 5 unique writes pass; 5 retries
	// of the same write trip.
	if (recent.length >= 5) {
		const callsByTool = new Map<string, string[]>();
		for (const fp of recent) {
			const name = fp.split("::")[0];
			const list = callsByTool.get(name) ?? [];
			list.push(fp);
			callsByTool.set(name, list);
		}
		for (const [name, fps] of callsByTool) {
			if (fps.length < 5) continue;
			const uniqueFingerprints = new Set(fps).size;
			if (uniqueFingerprints <= 2) {
				return {
					reason: `tool '${name}' was called ${fps.length}× out of the last ${recent.length} attempts with only ${uniqueFingerprints} distinct arg shape${uniqueFingerprints === 1 ? "" : "s"} — the underlying problem (workspace root, file existence, permissions, provider config) almost certainly isn't a tool args problem`,
				};
			}
		}
	}

	return undefined;
}

/**
 * 2026-05-25: after `normalizeToolArgs`, did we STILL end up with a
 * wrapped-args shape? When the model emits >8 layers of `_raw` nesting
 * (or some other pathological encoding the unwrap can't reach), this
 * returns true and the caller swaps in a small placeholder so history
 * doesn't accumulate megabytes of escaped JSON across turns.
 */
/**
 * Render a tool's JsonSchema as a one-line hint the model can pattern-
 * match against. Best-effort — covers the common object-with-properties
 * shape; for anything fancier we fall back to a JSON-stringified schema
 * snippet capped at 200 chars. The point is just to remind the model
 * what fields it needs to emit; full schema validation lives in the
 * tool's own arg guard.
 */
function describeSchema(schema: unknown): string {
	if (!schema || typeof schema !== "object") return "(unknown schema)";
	const s = schema as {
		type?: unknown;
		properties?: Record<string, unknown>;
		required?: readonly string[];
	};
	if (s.type === "object" && s.properties && typeof s.properties === "object") {
		const required = new Set<string>(s.required ?? []);
		const fields: string[] = [];
		for (const [k, v] of Object.entries(s.properties)) {
			const fieldType =
				v && typeof v === "object" && "type" in v ? String((v as { type: unknown }).type) : "any";
			const req = required.has(k) ? "" : "?";
			fields.push(`${k}${req}: ${fieldType}`);
		}
		return `\`{ ${fields.join(", ")} }\``;
	}
	try {
		const out = JSON.stringify(schema);
		return out.length > 200 ? `${out.slice(0, 200)}…` : out;
	} catch {
		return "(unrenderable schema)";
	}
}

/**
 * Last-ditch recovery of tool arguments from a malformed wire payload.
 *
 * When `normalizeToolArgs` fails to peel a clean object out of the raw
 * provider response (most often because the model emitted unescaped
 * newlines, quotes, or backslashes inside string values, breaking strict
 * JSON parse), we'd previously substitute a placeholder and ask the
 * model to retry. In practice — particularly with Kimi K2.6 — the model
 * pattern-matches "this failed twice → give up" and stops trying,
 * regardless of how useful the hint is.
 *
 * The structural fix is to extract the args ourselves. We can't fix
 * arbitrary malformed JSON, but for the common case (object schema with
 * string/number/boolean fields) we can regex-extract each known field
 * from the raw payload using greedy-last-quote matching that tolerates
 * unescaped chars inside the captured value.
 *
 * Returns:
 *   - A clean args object when all REQUIRED fields are recovered (or
 *     when at least one field is recovered and the schema has no
 *     required list).
 *   - `undefined` when no required field could be extracted — caller
 *     falls back to the placeholder hint.
 *
 * Risks: an over-eager regex extraction could give the tool handler
 * subtly wrong args (e.g., trailing whitespace in a path). The tool's
 * own arg-guard is the second line of defense — it'll reject obviously
 * bad input. This recovery is net-positive in practice: the alternative
 * is the model giving up entirely.
 */
export function tryRecoverWrappedArgs(
	normalized: unknown,
	schema: unknown,
): Record<string, unknown> | undefined {
	// Extract the raw string from either the normalized-string form or
	// the `{_raw: string}` shape that lenient parse falls back to.
	const rawInput = extractRawString(normalized);
	if (!rawInput) return undefined;

	// We only handle object schemas — anything else doesn't have known
	// fields to extract.
	const s = schema as {
		type?: unknown;
		properties?: Record<string, unknown>;
		required?: readonly string[];
	};
	if (s.type !== "object" || !s.properties) return undefined;

	// 2026-05-26 redesign: candidate-generation model.
	//
	// Rather than ad-hoc passes for each new malformed shape Kimi emits, we
	// enumerate a set of plausible normalizations of the raw payload, try
	// JSON.parse on each, and return the first object that satisfies the
	// schema's required fields. If none parse, run a tolerant regex pass
	// across every candidate (the de-escaped/peeled form is most likely to
	// match field-name patterns).
	//
	// Each repair pass is independent and idempotent. The candidate list
	// stays small (<= ~20) because we deduplicate and skip transformations
	// that wouldn't change the input.
	const candidates = generateRepairCandidates(rawInput);

	// First pass: try JSON.parse on every candidate. Cheapest path —
	// when ANY repair makes the raw parseable AND the result has the
	// required schema fields, we're done.
	for (const candidate of candidates) {
		try {
			const parsed = JSON.parse(candidate);
			if (matchesObjectSchema(parsed, s)) {
				return scrubRecoveredArgs(parsed as Record<string, unknown>);
			}
		} catch {
			/* try next candidate */
		}
	}

	// Second pass: tolerant regex extraction. Iterates every candidate;
	// the de-escaped forms are most likely to match `"FIELD"` patterns
	// without needing backslash tolerance. Each property's regex still
	// allows optional escapes for resilience against partial cleanups.
	for (const candidate of candidates) {
		const extracted = tolerantRegexExtract(candidate, s);
		if (extracted && hasRequiredFields(extracted, s)) {
			// 2026-05-29: post-process the extracted fields. The Kimi K2.6
			// triple-wrapped pattern produces a `path` value that absorbed
			// the rest of the JSON because all inner quotes were escaped
			// (`","content":"…` looked like opaque characters to the
			// regex char-class). When that happens, the captured path
			// still LITERALLY contains the JSON-field boundary substring,
			// so we can split at it and recover both fields cleanly
			// instead of returning a structurally-correct but
			// semantically-corrupted result.
			return scrubRecoveredArgs(splitAbsorbedFields(extracted, s));
		}
	}

	return undefined;
}

/**
 * 2026-05-29: post-recovery wrapper-noise scrubber.
 *
 * Both the JSON.parse and regex-extract recovery paths can produce field
 * values whose tail still carries leftover JSON wrapper artifacts. Three
 * distinct flavors we've seen in production Kimi K2.6 traces:
 *
 *   1. Trailing closing wrapper: `http://localhost:8080"}` — the model
 *      double-wrapped, JSON.parse succeeded on the inner layer, but the
 *      outer wrapper's `"}` was captured as data inside the URL string.
 *
 *   2. Absorbed sibling field: `python -m http.server 8080","label":"Web Server"}`
 *      — the regex char-class consumed past the field's logical end and
 *      pulled in the boundary + the next field's key/value.
 *
 *   3. Stray escape tail: `value\"` — a single dangling backslash-quote
 *      left over after one of the de-escape passes peeled an outer layer
 *      but missed a final character.
 *
 * The scrubber walks string values and iteratively strips these patterns
 * from the END (never the middle — that would be too aggressive). It runs
 * to fixpoint so layered artifacts (sibling field then closing wrapper)
 * collapse in one call.
 *
 * Safety: each pattern is anchored to the END of the string AND requires
 * recognisable JSON syntax (quote, brace, colon). Legitimate URLs, file
 * paths, shell commands, and labels do not end in `"}`, `\\"}`, or
 * `","<word>":...` — those are wrapper artifacts essentially every time.
 * For long content fields (file bodies, source code) the patterns are
 * theoretically possible but vanishingly rare; the alternative — letting
 * a bad URL/command/path through — is much worse.
 */
function scrubRecoveredArgs(args: Record<string, unknown>): Record<string, unknown> {
	const out: Record<string, unknown> = { ...args };
	for (const [k, v] of Object.entries(out)) {
		if (typeof v === "string") {
			out[k] = scrubTrailingWrapperNoise(v);
		}
	}
	return out;
}

export function scrubTrailingWrapperNoise(value: string): string {
	let cleaned = value;
	// Cap iterations to guarantee termination even on adversarial input.
	for (let i = 0; i < 8; i++) {
		const before = cleaned;
		// Pattern A: absorbed sibling field — `","<fieldname>":` followed
		// by anything. The boundary may be escape-encoded one or two times
		// depending on how many layers of wrapping the model emitted.
		cleaned = cleaned.replace(/\\{0,2}"\s*,\s*\\{0,2}"[a-zA-Z_][a-zA-Z0-9_]*\\{0,2}"\s*:\s*.*$/, "");
		// Pattern B: closing wrapper — `"}`, `\"}`, `\\"}` at the very end.
		cleaned = cleaned.replace(/\\{0,2}"\s*\}\s*$/, "");
		// Pattern C: stray trailing escape sequence — `\"` or `\\"` alone.
		cleaned = cleaned.replace(/\\+"\s*$/, "");
		if (cleaned === before) break;
	}
	return cleaned;
}

/**
 * 2026-05-29: post-process a regex-extracted args object. When the
 * regex's char-class absorbed a JSON-field boundary into a path-shaped
 * value (because all the boundary's quotes were escape-encoded and
 * looked like data), split at the boundary and assign the leftover to
 * the matching field.
 *
 * Concrete example: tolerantRegexExtract returns
 *   { path: 'index.html","content":"<!DOCTYPE html>...', content: '...' }
 * After split:
 *   { path: 'index.html', content: '<!DOCTYPE html>...' }
 *
 * Only fires when:
 *   1. The corrupted field is path-shaped
 *   2. The substring is structurally a JSON-field boundary for ANOTHER
 *      required field on the schema
 *   3. Splitting yields a path that passes basic shape checks
 *      (≤ 4096 chars, no newlines)
 */
function splitAbsorbedFields(
	args: Record<string, unknown>,
	schema: { properties?: Record<string, unknown>; required?: readonly string[] },
): Record<string, unknown> {
	const required = Array.isArray(schema.required) ? schema.required : [];
	if (required.length < 2 || !schema.properties) return args;
	const PATH_FIELDS = new Set(["path", "filePath", "file", "filename", "cwd", "dir", "directory"]);
	const out = { ...args };
	for (const field of required) {
		if (!PATH_FIELDS.has(field.toLowerCase())) continue;
		const v = out[field];
		if (typeof v !== "string") continue;
		// Look for a JSON-field boundary for ANY other required field.
		for (const other of required) {
			if (other === field) continue;
			const otherRe = other.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
			// Match `","other":"` (canonical) or `\",\"other\":\"` (still
			// partially escaped). The boundary marks where the path value
			// SHOULD have ended.
			const boundaryRe = new RegExp(
				`[\\\\"]{0,2},\\s*[\\\\"]{0,2}${otherRe}[\\\\"]{0,2}\\s*:\\s*[\\\\"]{0,2}`,
			);
			const match = v.match(boundaryRe);
			if (!match || match.index === undefined) continue;
			const cleanPath = v.slice(0, match.index);
			const remainder = v.slice(match.index + match[0].length);
			// Only accept the split if the resulting path looks reasonable.
			if (cleanPath.length === 0 || cleanPath.length > 4096) continue;
			if (/[\n\r"]/.test(cleanPath)) continue;
			// Replace path with clean value. If `other` is empty/missing,
			// promote remainder; if `other` was also extracted (via the
			// regex's separate match for that key), keep what we already
			// have unless that value is empty.
			out[field] = cleanPath;
			const existingOther = out[other];
			if (existingOther === undefined || existingOther === null || existingOther === "") {
				// Strip a trailing close-quote-and-close-brace artifact like `"}`.
				const cleanedRemainder = remainder.replace(/[\\"\s]*}?\s*$/, "");
				out[other] = cleanedRemainder;
			}
			break; // Only split once per path field.
		}
	}
	return out;
}

/**
 * Pull the raw string from a `{_raw: string}` wrapper or accept a bare
 * string. Returns `undefined` when there's nothing to recover from
 * (null, an empty string, a non-`_raw` object).
 */
function extractRawString(normalized: unknown): string | undefined {
	if (typeof normalized === "string") {
		return normalized.length > 0 ? normalized : undefined;
	}
	if (normalized && typeof normalized === "object" && !Array.isArray(normalized)) {
		const obj = normalized as Record<string, unknown>;
		if (typeof obj._raw === "string" && obj._raw.length > 0) return obj._raw;
	}
	return undefined;
}

/**
 * Does this parsed value satisfy the schema's required-fields contract?
 * Used by the candidate-parse pass to decide which repair "won".
 */
function matchesObjectSchema(parsed: unknown, schema: { required?: readonly string[] }): boolean {
	if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return false;
	const obj = parsed as Record<string, unknown>;
	if (Array.isArray(schema.required) && schema.required.length > 0) {
		return schema.required.every((req) => req in obj);
	}
	return true; // any object matches a schema with no required list
}

function hasRequiredFields(
	obj: Record<string, unknown>,
	schema: { required?: readonly string[] },
): boolean {
	if (Array.isArray(schema.required) && schema.required.length > 0) {
		return schema.required.every((req) => req in obj);
	}
	return Object.keys(obj).length > 0;
}

/**
 * Enumerate plausible repaired forms of the raw payload. Order matters
 * for performance (cheapest / most-likely-to-work first) but NOT for
 * correctness — every candidate is tried until one parses + matches
 * the schema.
 *
 * Transformations applied (independently and in composition):
 *
 *   1. Identity (raw as-is).
 *   2. Strict JSON.parse peel — for string-of-string-of-…-of-object
 *      nesting where each parse yields another string.
 *   3. Strip outer matching quote pair — Kimi/some gateways wrap the
 *      entire object in extra quotes (e.g. `'"{"path":...}"'`).
 *   4. De-escape `\"` → `"` and `\\` → `\` — over-escaped JSON where
 *      every quote in the wire payload was prefixed with an extra
 *      backslash.
 *   5. Combined: strip outer quotes THEN de-escape.
 *   6. Combined: peel THEN de-escape.
 *   7. Replace smart-quote characters with straight quotes.
 *   8. Strip trailing commas before `}` / `]`.
 *
 * Deduplicates by string equality so the parse pass doesn't waste
 * cycles on identical candidates.
 */
function generateRepairCandidates(raw: string): string[] {
	const seen = new Set<string>();
	const candidates: string[] = [];
	const push = (s: string | undefined): void => {
		if (typeof s !== "string" || s.length === 0) return;
		if (seen.has(s)) return;
		seen.add(s);
		candidates.push(s);
	};

	push(raw);

	// Repair primitives — applied to every accumulating candidate so
	// composed transformations (e.g. peel-then-deescape) are covered.
	const stripOuterQuotes = (s: string): string | undefined => {
		if (s.length < 2) return undefined;
		const first = s[0];
		const last = s[s.length - 1];
		if ((first === '"' || first === "'") && last === first) {
			return s.slice(1, -1);
		}
		return undefined;
	};

	const deescape = (s: string): string | undefined => {
		if (!s.includes('\\"') && !s.includes("\\\\")) return undefined;
		return s.replace(/\\"/g, '"').replace(/\\\\/g, "\\");
	};

	const smartQuotes = (s: string): string | undefined => {
		// Curly double quotes (U+201C / U+201D) and curly single quotes.
		if (!/[“”‘’]/.test(s)) return undefined;
		return s.replace(/[“”]/g, '"').replace(/[‘’]/g, "'");
	};

	const trailingCommas = (s: string): string | undefined => {
		if (!/,\s*[}\]]/.test(s)) return undefined;
		return s.replace(/,(\s*[}\]])/g, "$1");
	};

	// Peel: each strict JSON.parse on a string that yields another string
	// counts as a layer. Add each layer as a candidate so the regex pass
	// can run on the cleanest form.
	const peel = (s: string): string[] => {
		const out: string[] = [];
		let cur: unknown = s;
		for (let i = 0; i < 16; i++) {
			if (typeof cur !== "string") break;
			try {
				const next = JSON.parse(cur);
				if (typeof next === "string") {
					out.push(next);
					cur = next;
					continue;
				}
				// Reached a non-string — peel terminates. The OBJECT case
				// is handled by the outer parse pass via the original
				// stringified candidate; we don't need to push the object.
				break;
			} catch {
				break;
			}
		}
		return out;
	};

	// Apply primitives in cascade. After each, derive further candidates.
	const queue: string[] = [...candidates];
	while (queue.length > 0) {
		const item = queue.shift();
		if (item === undefined) break;
		const variants: Array<string | undefined> = [
			stripOuterQuotes(item),
			deescape(item),
			smartQuotes(item),
			trailingCommas(item),
		];
		for (const v of variants) {
			if (v && !seen.has(v)) {
				push(v);
				// Recursively explore variants of variants (depth bounded
				// by the seen-set — each transformation is idempotent so
				// the queue eventually drains).
				queue.push(v);
			}
		}
		// Peel produces an array — splice each peeled layer in.
		for (const peeled of peel(item)) {
			if (!seen.has(peeled)) {
				push(peeled);
				queue.push(peeled);
			}
		}
	}

	return candidates;
}

/**
 * Tolerant per-field regex extraction. Each schema property gets a
 * regex that allows ONE optional backslash before each `"` in the key
 * pattern — handles partial cleanups where some escapes were stripped
 * but not all.
 */
function tolerantRegexExtract(
	raw: string,
	schema: { properties?: Record<string, unknown> },
): Record<string, unknown> | undefined {
	if (!schema.properties) return undefined;
	const result: Record<string, unknown> = {};
	for (const [field, fieldSchema] of Object.entries(schema.properties)) {
		const type =
			fieldSchema && typeof fieldSchema === "object" && "type" in fieldSchema
				? (fieldSchema as { type: unknown }).type
				: undefined;
		const value = extractFieldFromRaw(raw, field, type);
		if (value !== undefined) result[field] = value;
	}
	return Object.keys(result).length === 0 ? undefined : result;
}

/**
 * Pull a single named field out of a raw JSON-ish string. Two regex
 * passes:
 *   1. Strict: `"field": "value"` where value is a properly-escaped
 *      JSON string. Round-trips through JSON.parse so escape
 *      sequences (`\n`, `\"`, `\\`) decode correctly.
 *   2. Greedy fallback for string fields: `"field": "..."` matching
 *      everything until the last `"` followed by either `,` or `}` —
 *      tolerates unescaped quotes / newlines / backslashes in the
 *      captured value at the cost of correctness in pathological
 *      cases. The tool's own arg-guard catches obvious garbage.
 *
 * For number/boolean fields: a single unambiguous regex; no fallback.
 */
function extractFieldFromRaw(raw: string, field: string, type: unknown): unknown {
	const fieldRe = field.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	// Tolerant key pattern: allows ONE optional backslash before each
	// quote around the field name. Handles partial cleanups where some
	// `\"` were stripped to `"` but not all. The same `\\?` tolerance is
	// applied around the opening value-quote for strings.
	const key = `\\\\?"${fieldRe}\\\\?"`;
	if (type === "string") {
		// Strict pass: properly-escaped string value.
		const strict = raw.match(new RegExp(`${key}\\s*:\\s*\\\\?"((?:[^"\\\\]|\\\\.)*)\\\\?"`));
		if (strict) {
			try {
				return JSON.parse(`"${strict[1]}"`);
			} catch {
				return strict[1];
			}
		}
		// Lazy fallback: tolerate unescaped chars inside the value, but
		// stop at the FIRST closing quote followed by `,` or `}`. The
		// previous greedy form (`*` instead of `*?`) overshot whenever
		// the payload had multiple string fields — e.g. extracting `path`
		// from `{"path":"x.py","content":"…"}` slurped everything up
		// through the LAST quote in the object. Lazy `*?` stops at the
		// first plausible end-of-value, which is correct for well-formed
		// JSON-ish input and only mis-stops when the value itself
		// contains a literal `","` substring — rare enough that the tool's
		// arg-guard catches it from the downstream side.
		const lazy = raw.match(new RegExp(`${key}\\s*:\\s*\\\\?"([\\s\\S]*?)\\\\?"\\s*[,}]`));
		if (lazy) {
			// Decode known escape sequences that the strict-quote regex would
			// have handled, leaving genuine literals intact.
			return lazy[1]
				.replace(/\\\\/g, "_OATI_BS_")
				.replace(/\\"/g, '"')
				.replace(/\\n/g, "\n")
				.replace(/\\r/g, "\r")
				.replace(/\\t/g, "\t")
				.replace(/_OATI_BS_/g, "\\");
		}
		return undefined;
	}
	if (type === "number" || type === "integer") {
		const m = raw.match(new RegExp(`${key}\\s*:\\s*(-?\\d+(?:\\.\\d+)?)`));
		if (!m) return undefined;
		const n = Number(m[1]);
		return Number.isFinite(n) ? n : undefined;
	}
	if (type === "boolean") {
		const m = raw.match(new RegExp(`${key}\\s*:\\s*(true|false)`));
		return m ? m[1] === "true" : undefined;
	}
	return undefined;
}

/**
 * 2026-05-26: semantic field-contamination check. Catches the case where
 * a tool's JSON args parsed CLEANLY (no syntax error, schema fields
 * present) but the VALUE of one required string field literally contains
 * the JSON boundary for another required field — meaning the model'\''s
 * arg-encoding broke and a sibling field got swallowed into this one.
 *
 * Concretely: `write_file({path: "foo.py","content":"#!/usr/bin/env...", content: undefined})`.
 * The parser saw `path` and walked off the end of the string before the
 * real `","content":"..."` separator landed. Now `path` is garbage and
 * `content` is missing entirely. Our existing wrapped-args recovery
 * doesn'\''t catch this because the JSON itself was valid — only the
 * semantic field assignment was wrong.
 *
 * Returns a diagnostic-ready error string when contamination is
 * detected, or `undefined` if args look clean. Calling code uses this
 * to force a re-try with a clarifying hint instead of letting the bad
 * call execute.
 */
/**
 * 2026-05-29: per-tool shape validator. Runs AFTER wrapped-args recovery
 * and BEFORE the tool handler. Catches the case where recovery extracted
 * syntactically-valid fields but the VALUES are still corrupted —
 * e.g. a 9000-character "path" with embedded newlines, an `exec` command
 * with a literal `,"content":` substring.
 *
 * The handler-level validators (e.g. write_file's `isWriteFileArgs`)
 * only check field PRESENCE, not field SHAPE. By the time a corrupted
 * path reaches the filesystem layer it's already too late — Node throws
 * EINVAL with a message the model can't act on. This function returns a
 * descriptive, model-readable diagnostic so the loop's next iteration
 * has actionable feedback instead of "EINVAL: invalid argument".
 */
export function detectToolArgShapeProblem(toolName: string, args: unknown): string | undefined {
	if (!args || typeof args !== "object" || Array.isArray(args)) return undefined;
	const o = args as Record<string, unknown>;

	// Path-shaped fields across all tools.
	const PATH_FIELDS = ["path", "filePath", "file", "filename", "cwd", "dir", "directory"];
	for (const field of PATH_FIELDS) {
		const v = o[field];
		if (typeof v !== "string" || v.length === 0) continue;
		if (v.length > 4096) {
			return `Tool args validation failed: field "${field}" is ${v.length} characters long — far too large to be a real file path. Your args were corrupted during JSON encoding (the path field absorbed adjacent fields). Re-emit the call with a flat JSON object: {"${field}": "actual/short/path.ext", "content": "..."}. NEVER wrap arguments in an outer quoted string.`;
		}
		if (v.includes("\n") || v.includes("\r")) {
			return `Tool args validation failed: field "${field}" contains newline characters. File paths never contain newlines. Your args were probably double-encoded so the path field captured content. Re-emit as a flat JSON object with the path on one line and content as a separate field.`;
		}
		// Embedded JSON field boundary — `","content":` or `","command":` etc.
		// This is the dead giveaway of wrapped-args field absorption.
		if (/[",\\]*","[a-zA-Z_][a-zA-Z0-9_]*"\s*:/.test(v)) {
			return `Tool args validation failed: field "${field}" contains an embedded JSON-field boundary (looks like \`","<otherkey>":\` inside the value). Your args were double-encoded — the model emitted the arguments as a JSON-string-inside-a-JSON-string instead of a flat object. Re-emit as: {"${field}": "actual-path.ext", "content": "actual-content"}. A simple flat object, never a quoted JSON blob.`;
		}
		if (v.includes('"')) {
			return `Tool args validation failed: field "${field}" contains unescaped double-quote characters. File paths never contain quotes. Re-emit as a flat JSON object with proper escaping: {"${field}": "clean/path.ext"}.`;
		}
	}

	// Command-shaped fields for exec / shell tools.
	if (toolName === "exec" || toolName === "run_tests" || toolName === "start_background_process") {
		const v = o.command ?? o.cmd;
		if (typeof v === "string") {
			if (v.length > 8192) {
				return `Tool args validation failed: field "command" is ${v.length} characters long — too large to be a real shell command. Multi-line scripts should be written to a file via write_file first, then exec the file path (e.g. "python out/script.py"), never inlined into the command string.`;
			}
		}
	}

	return undefined;
}

export function detectFieldContamination(args: unknown, schema: unknown): string | undefined {
	if (!args || typeof args !== "object" || Array.isArray(args)) return undefined;
	const s = schema as {
		type?: unknown;
		properties?: Record<string, unknown>;
		required?: readonly string[];
	};
	if (s.type !== "object" || !s.properties) return undefined;
	const required = Array.isArray(s.required) ? s.required : [];
	if (required.length < 2) return undefined; // need ≥2 required fields for cross-contamination
	const obj = args as Record<string, unknown>;
	for (const field of required) {
		const val = obj[field];
		if (typeof val !== "string") continue;
		for (const other of required) {
			if (other === field) continue;
			// Look for `","other":"`, `\","other\":\"`, or raw `,"other":"` — all
			// signs the JSON boundary between this field and `other` collapsed
			// into the value. We allow optional backslash escapes because the
			// payload may be pre- or post- de-escape.
			// Allow up to 2 escape/quote characters between segments because
			// the payload may carry `\","other\":"` (one escape + quote) OR
			// `\\","other\\":"` (double-escape after JSON-in-JSON encoding).
			const pattern = new RegExp(
				`[\"\\\\]{0,2},\\s*[\"\\\\]{0,2}${other}[\"\\\\]{0,2}\\s*:\\s*[\"\\\\]{0,2}`,
				"i",
			);
			if (pattern.test(val)) {
				// 2026-05-29: previously we only fired when `other` was empty,
				// reasoning "if both fields ended up populated the model may
				// have produced legit data containing JSON-looking chars".
				// This left a hole: when regex-based wrapped-args recovery
				// successfully extracts BOTH a corrupted `path` AND a clean
				// `content`, this guard skipped, the bad path reached the
				// filesystem, and write_file blew up with EINVAL. Real-world
				// case from a Kimi K2.6 transcript:
				//   path:    "index.html\",\"content\":\"<!DOCTYPE html>..."
				//   content: "<!DOCTYPE html>..."
				// Both populated; path obviously corrupted.
				//
				// Path-shaped fields (`path`, `filePath`, `file`, `dir`,
				// `directory`, `cwd`) almost never legitimately contain the
				// literal substring `","<otherfield>":` — that's a JSON
				// boundary, not file-system content. Always fire for those.
				// For other field types, keep the old "other field empty"
				// guard so a search query like `","key":"value"` doesn't
				// trigger a false positive.
				const isPathLike = /^(path|file|filepath|filename|cwd|dir|directory)$/i.test(field);
				const otherVal = obj[other];
				const otherEmpty = otherVal === undefined || otherVal === null || otherVal === "";
				if (isPathLike || otherEmpty) {
					return `Field "${field}" appears to contain a wrapped JSON boundary for required field "${other}" — args were mis-encoded. Re-emit the call with a clean JSON object: {"${field}": "...", "${other}": "..."}. Each value must be a properly escaped JSON string (use json.dumps / JSON.stringify rather than hand-building).`;
				}
			}
		}
	}
	return undefined;
}

function isStillWrappedAfterNormalize(args: unknown): boolean {
	if (args === null || args === undefined) return false;
	if (typeof args === "string") {
		// Heuristic: an arg that's STILL a string after normalize either
		// looks like a JSON-encoded object/array (leading `"`, `{`, or `[`)
		// or is a long blob — either way, treat as wrapped.
		const head = args.slice(0, 2);
		return args.length > 0 && (head.startsWith('"') || head.startsWith("{") || head.startsWith("["));
	}
	if (typeof args !== "object" || Array.isArray(args)) return false;
	const obj = args as Record<string, unknown>;
	const keys = Object.keys(obj);
	return keys.length === 1 && keys[0] === "_raw";
}

/**
 * 2026-05-24: count how many tool results in the LATEST role:"tool"
 * message were errors. The safety-net wrap-up text uses this to decide
 * whether to claim "✅ Done" (every recent result was clean) or to
 * surface a "⚠️ Stopped — tools failed" warning so the user doesn't
 * mistake a half-finished task for success.
 *
 * We only look at the most recent tool message because that represents
 * what the model JUST saw before giving up. Earlier failures the model
 * recovered from are not relevant to the closing message.
 */
function countRecentToolFailures(history: readonly ConversationMessage[]): number {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "tool") continue;
		let failures = 0;
		for (const part of msg.parts) {
			if (part.kind === "tool_result" && part.isError) failures++;
		}
		return failures;
	}
	return 0;
}

/**
 * Deterministic JSON used for tool-call fingerprinting. Vanilla
 * JSON.stringify is order-sensitive, so `{a:1,b:2}` and `{b:2,a:1}`
 * would look like different calls even though they're semantically
 * identical. We sort object keys recursively so the fingerprint is
 * stable regardless of how the model serialized its args this turn.
 */
/**
 * Detect provider content-safety guardrail blocks and rewrite the error
 * message into something the user can act on. Returns `undefined` when
 * the message doesn't look like a guardrail block (caller keeps the
 * original message).
 *
 * Targets OpenRouter's `guardrail_blocked` response shape:
 *   {"error":{"code":"guardrail_blocked","message":"Prompt blocked by
 *    guardrails: prompt_injection.mode_switch","plugin":
 *    "guardrail_patterns","findings":[{"message":"prompt_injection.
 *    mode_switch pattern matched in messages[61]",...}]}}
 *
 * Extracts the offending message index when present so the user can
 * locate the trigger. Adds the standard recovery options (/compact,
 * disable guardrails in OpenRouter settings, switch provider).
 */
export function augmentGuardrailError(message: string): string | undefined {
	if (!message.includes("guardrail_blocked") && !message.includes("prompt_injection")) {
		return undefined;
	}
	let kind = "the provider's content-safety filter";
	let messageIdx: number | undefined;
	const kindMatch = message.match(/(prompt_injection\.[a-z_]+|guardrails:\s*([a-z_.]+))/i);
	if (kindMatch) kind = kindMatch[1] ?? kindMatch[2] ?? kind;
	const idxMatch = message.match(/messages\[(\d+)\]/);
	if (idxMatch) messageIdx = Number(idxMatch[1]);
	const lines: string[] = [
		`⛔ **Provider guardrail blocked the request.** ${kind} flagged ${
			messageIdx !== undefined
				? `message #${messageIdx} in this conversation history`
				: "something in your conversation history"
		} as suspicious (most often imperative phrasing in a prior assistant message or tool result).`,
		"",
		"Recovery options, in order of effort:",
		"",
		"  1. **Run `/compact`** in the chat — strips the middle of history (which is most likely where the trigger lives) and replaces it with a tame summary. Then retry the prompt.",
		"  2. **Start a new session** if `/compact` doesn't clear it (the trigger may be in the head or tail).",
		"  3. **Disable the guardrail at the provider level.** On OpenRouter: open your dashboard → Settings → Plugins → toggle off `guardrail_patterns`. Or set `provider.preferred_provider` to one without this plugin.",
		"  4. **Switch provider/model** for this prompt if the content genuinely needs imperative phrasing.",
		"",
		"Note: iOmCode's own internal hints (`False-Done check`, auto-continue nudges, wrapped-args recovery messages) use directive phrasing and can trip prompt-injection classifiers when they accumulate in history. This is the most common false-positive pattern.",
	];
	return lines.join("\n");
}

/**
 * Coarse char-count → token estimate. ~4 chars per token is the rule of
 * thumb for English + code mixes; perfect accuracy would require a real
 * tokenizer (tiktoken or each provider's bespoke BPE). For the
 * auto-compact threshold check, the heuristic is sufficient — the cost
 * of being slightly off is one extra summarize call.
 *
 * 2026-06-01: images are now estimated by parsing the PNG IHDR for
 * actual pixel dimensions, then converting to ViT-style patch counts.
 * The previous flat-1200-per-image estimate was off by 1-2 orders of
 * magnitude for K2.6 — a 1280×4096 fullPage screenshot costs ~27k
 * vision tokens, not 1200. Live-bug: a viewport-only screenshot
 * combined with conversation history hit 323k requested vs a 262k cap;
 * the under-estimate meant `shouldAutoCompact` thought we had plenty
 * of room when we were already in the danger zone.
 */
export function estimateMessagesTokens(messages: readonly ConversationMessage[]): number {
	let total = 0;
	for (const m of messages) {
		for (const part of m.parts) {
			if (part.kind === "text") {
				total += Math.ceil(part.text.length / 4);
			} else if (part.kind === "tool_call") {
				try {
					total += Math.ceil(JSON.stringify(part.args).length / 4);
				} catch {
					total += 32; // fallback for unserializable args
				}
			} else if (part.kind === "tool_result") {
				const out = typeof part.output === "string" ? part.output : safeStringify(part.output);
				total += Math.ceil(out.length / 4);
			} else if (part.kind === "image") {
				total += estimateImageVisionTokens(part.dataUrl, part.mimeType);
			}
		}
	}
	return total;
}

/**
 * 2026-06-02: per-category token breakdown for diagnostics. When the
 * context starts filling up, "you're at 180k tokens" doesn't tell the
 * user WHY — is it the history, the images, the tool results from a
 * long-running command? This breakdown decomposes the estimate into
 * the categories the user can actually act on:
 *   - text:       user/assistant text turns + reasoning blocks
 *   - toolResults: bulky tool_result outputs (often the worst offender
 *                  — long exec stdout, large read_file)
 *   - toolCalls:   the args side of the conversation (usually small)
 *   - images:      live ImagePart vision-token cost
 *   - descriptions: text parts marked "[iOm image memory]" (post-demote
 *                  pixels-released breadcrumbs)
 *
 * Exported pure for testability — used by the streamOnce diagnostic
 * channel when usage exceeds a threshold.
 */
export interface ContextBudgetBreakdown {
	readonly total: number;
	readonly text: number;
	readonly toolResults: number;
	readonly toolCalls: number;
	readonly images: number;
	readonly descriptions: number;
}

export function estimateContextBreakdown(
	messages: readonly ConversationMessage[],
): ContextBudgetBreakdown {
	let text = 0;
	let toolResults = 0;
	let toolCalls = 0;
	let images = 0;
	let descriptions = 0;
	for (const m of messages) {
		for (const part of m.parts) {
			if (part.kind === "text") {
				const cost = Math.ceil(part.text.length / 4);
				if (part.text.startsWith("[iOm image memory]")) {
					descriptions += cost;
				} else {
					text += cost;
				}
			} else if (part.kind === "tool_call") {
				try {
					toolCalls += Math.ceil(JSON.stringify(part.args).length / 4);
				} catch {
					toolCalls += 32;
				}
			} else if (part.kind === "tool_result") {
				const out = typeof part.output === "string" ? part.output : safeStringify(part.output);
				toolResults += Math.ceil(out.length / 4);
			} else if (part.kind === "image") {
				images += estimateImageVisionTokens(part.dataUrl, part.mimeType);
			}
		}
	}
	const total = text + toolResults + toolCalls + images + descriptions;
	return { total, text, toolResults, toolCalls, images, descriptions };
}

/**
 * 2026-06-02: format a budget breakdown as a one-line chat diagnostic.
 * Output: `[context-budget] 145k/256k (text 80k, results 25k, images
 * 12k, descriptions 4k, calls 1k)`. Categories at zero are omitted to
 * keep the line readable.
 */
export function formatBudgetBreakdown(
	breakdown: ContextBudgetBreakdown,
	contextWindow: number,
): string {
	const k = (n: number) => `${Math.round(n / 1000)}k`;
	const parts: string[] = [];
	if (breakdown.text > 0) parts.push(`text ${k(breakdown.text)}`);
	if (breakdown.toolResults > 0) parts.push(`results ${k(breakdown.toolResults)}`);
	if (breakdown.images > 0) parts.push(`images ${k(breakdown.images)}`);
	if (breakdown.descriptions > 0) parts.push(`descriptions ${k(breakdown.descriptions)}`);
	if (breakdown.toolCalls > 0) parts.push(`calls ${k(breakdown.toolCalls)}`);
	return `[context-budget] ${k(breakdown.total)}/${k(contextWindow)} (${parts.join(", ")})`;
}

/**
 * Estimate vision-token cost for an image part by reading the PNG
 * IHDR (or JPEG SOF marker) for pixel dimensions, then approximating
 * the per-patch token count used by ViT-style tokenizers (CLIP,
 * MoonViT, etc. — all roughly 14×14 patches). Falls back to a base64-
 * length proxy when the format header can't be parsed.
 */
export function estimateImageVisionTokens(dataUrl: string, mimeType: string): number {
	const dims = readImageDimensions(dataUrl, mimeType);
	if (dims) {
		// ViT patch size of 14×14 is the de-facto standard across CLIP,
		// MoonViT, SigLIP. Conservative — actual cost is often slightly
		// less due to spatial pooling, but the predictive auto-compact
		// is better off over-estimating images than under-estimating them.
		const PATCH_AREA = 14 * 14;
		return Math.ceil((dims.width * dims.height) / PATCH_AREA);
	}
	// Fallback when we can't read dimensions — use base64 length as a
	// rough proxy. 1 token per ~3 base64 bytes is a generous over-estimate
	// (encourages compaction) when format detection fails.
	const b64Match = /^data:[^;]+;base64,([\s\S]+)$/i.exec(dataUrl);
	const b64 = b64Match ? b64Match[1] : dataUrl;
	return Math.ceil(b64.length / 3);
}

function readImageDimensions(
	dataUrl: string,
	mimeType: string,
): { width: number; height: number } | undefined {
	const b64Match = /^data:[^;]+;base64,([\s\S]+)$/i.exec(dataUrl);
	const b64 = b64Match ? b64Match[1] : dataUrl;
	// Decode just the header. PNG IHDR fits in the first 24 bytes (32
	// base64 chars); JPEG SOF can sit deeper but the first 1KB is
	// almost always enough.
	const headerBytes = base64DecodeHeaderBytes(b64, 1024);
	if (!headerBytes) return undefined;
	const mt = mimeType.toLowerCase();
	if (mt.includes("png") || isPngSignature(headerBytes)) return readPngDimensions(headerBytes);
	if (mt.includes("jpeg") || mt.includes("jpg") || isJpegSignature(headerBytes)) {
		return readJpegDimensions(headerBytes);
	}
	return undefined;
}

function base64DecodeHeaderBytes(b64: string, maxBytes: number): Uint8Array | undefined {
	try {
		// 4 base64 chars = 3 bytes. Pad up to a multiple of 4 so atob doesn't reject.
		const need = Math.ceil((maxBytes * 4) / 3);
		const slice = b64.slice(0, Math.min(need, b64.length));
		const padded = slice + "=".repeat((4 - (slice.length % 4)) % 4);
		const bin = atob(padded);
		const out = new Uint8Array(Math.min(bin.length, maxBytes));
		for (let i = 0; i < out.length; i++) out[i] = bin.charCodeAt(i);
		return out;
	} catch {
		return undefined;
	}
}

function isPngSignature(bytes: Uint8Array): boolean {
	return (
		bytes.length >= 8 &&
		bytes[0] === 0x89 &&
		bytes[1] === 0x50 &&
		bytes[2] === 0x4e &&
		bytes[3] === 0x47 &&
		bytes[4] === 0x0d &&
		bytes[5] === 0x0a &&
		bytes[6] === 0x1a &&
		bytes[7] === 0x0a
	);
}

function readPngDimensions(bytes: Uint8Array): { width: number; height: number } | undefined {
	// PNG layout: 8-byte sig, then IHDR chunk = 4 length + 4 type ("IHDR")
	// + 13 data. width is the first 4 bytes of data at offset 16; height
	// at offset 20. All big-endian.
	if (bytes.length < 24) return undefined;
	const w = (bytes[16] << 24) | (bytes[17] << 16) | (bytes[18] << 8) | bytes[19];
	const h = (bytes[20] << 24) | (bytes[21] << 16) | (bytes[22] << 8) | bytes[23];
	if (w <= 0 || h <= 0 || w > 100_000 || h > 100_000) return undefined;
	return { width: w >>> 0, height: h >>> 0 };
}

function isJpegSignature(bytes: Uint8Array): boolean {
	return bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xd8;
}

function readJpegDimensions(bytes: Uint8Array): { width: number; height: number } | undefined {
	// Walk JPEG markers until we hit a Start-Of-Frame (SOF0..SOFn except
	// SOF4/SOF8/SOF12 which are not frame markers). Each marker is 0xFF
	// followed by a marker byte and (for non-standalone markers) a
	// 2-byte big-endian segment length.
	let i = 2;
	while (i < bytes.length - 9) {
		if (bytes[i] !== 0xff) return undefined;
		const marker = bytes[i + 1];
		// Skip 0xFF fill bytes.
		if (marker === 0xff) {
			i++;
			continue;
		}
		// Standalone markers with no length: SOI, EOI, TEMP, RST*.
		if (marker === 0xd8 || marker === 0xd9 || marker === 0x01) {
			i += 2;
			continue;
		}
		const segLen = (bytes[i + 2] << 8) | bytes[i + 3];
		// SOFn: 0xC0..0xCF except 0xC4 (DHT), 0xC8 (JPG-extension), 0xCC (DAC).
		const isSof =
			marker >= 0xc0 && marker <= 0xcf && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc;
		if (isSof) {
			// SOF payload: precision (1 byte), height (2 BE), width (2 BE).
			const h = (bytes[i + 5] << 8) | bytes[i + 6];
			const w = (bytes[i + 7] << 8) | bytes[i + 8];
			if (w <= 0 || h <= 0) return undefined;
			return { width: w, height: h };
		}
		i += 2 + segLen;
	}
	return undefined;
}

/**
 * 2026-06-02: extract a short label from an "[iOm image memory] ..."
 * description string. Used when collapsing old descriptions to a
 * marker — we keep the first noun-phrase-ish chunk (up to 60 chars)
 * so the model still has a hint about what was on screen. Exported
 * pure for testability.
 */
export function extractDescriptionHint(desc: string): string | undefined {
	// Strip the prefix.
	const stripped = desc.replace(/^\[iOm image memory\]\s*/i, "").trim();
	if (stripped.length === 0) return undefined;
	// First sentence (up to '.', '!', or '?').
	const firstSentence = stripped.split(/[.!?]/, 1)[0]?.trim();
	if (!firstSentence) return undefined;
	if (firstSentence.length <= 60) return firstSentence;
	return `${firstSentence.slice(0, 57)}...`;
}

/**
 * 2026-06-03: shallow-deep equality on conversation histories. Compares
 * length first, then per-message role / parts.length / per-part
 * type-discriminator + structural fields. Used by the agent loop to
 * decide whether `repairOrphanToolCalls` actually changed anything —
 * if it did, we swap the result into history; if not, we skip the
 * mutation to keep object identity stable for downstream consumers.
 *
 * Not a full structural deep-equal — comparison is targeted at the
 * fields the repair pass actually touches (tool_call.id and
 * tool_result.id, plus the part kind sequence). Other fields like
 * args / output / text are NOT compared because the repair pass never
 * touches them.
 */
function areHistoriesEqual(
	a: readonly ConversationMessage[],
	b: readonly ConversationMessage[],
): boolean {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) {
		const ma = a[i];
		const mb = b[i];
		if (ma.role !== mb.role) return false;
		if (ma.parts.length !== mb.parts.length) return false;
		for (let j = 0; j < ma.parts.length; j++) {
			const pa = ma.parts[j];
			const pb = mb.parts[j];
			if (pa.kind !== pb.kind) return false;
			if (pa.kind === "tool_call" && pb.kind === "tool_call") {
				if (pa.id !== pb.id) return false;
			} else if (pa.kind === "tool_result" && pb.kind === "tool_result") {
				if (pa.id !== pb.id) return false;
			}
		}
	}
	return true;
}

function safeStringify(v: unknown): string {
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}

/**
 * 2026-06-01: cheap content hash for read-file dedup. Combines length
 * with a few sampled spans so identical-length-but-different-content
 * files don't collide. Faster than a real SHA1 (no crypto import) and
 * collision cost is acceptable here: a false positive returns a stale
 * "unchanged" stub for one read — the model can re-call if it really
 * needs the bytes.
 */
export function quickHash(s: string): string {
	const len = s.length;
	if (len === 0) return "len:0";
	const headEnd = Math.min(128, len);
	const tailStart = Math.max(headEnd, len - 128);
	let acc = 5381;
	for (let i = 0; i < headEnd; i++) acc = ((acc << 5) + acc + s.charCodeAt(i)) >>> 0;
	for (let i = tailStart; i < len; i++) acc = ((acc << 5) + acc + s.charCodeAt(i)) >>> 0;
	// Sample one mid-span byte too, so a swap inside the middle still
	// changes the hash.
	if (len > 256) {
		const mid = Math.floor(len / 2);
		acc = ((acc << 5) + acc + s.charCodeAt(mid)) >>> 0;
	}
	return `len:${len}|h:${acc.toString(16)}`;
}

/**
 * 2026-06-01: self-heal for assistant messages with orphan tool_calls.
 * When history is corrupted (a buggy earlier compaction split a pair,
 * a session was loaded from disk with partial state, etc.), an
 * assistant message may carry tool_calls whose matching `tool` role
 * responses are missing. OpenAI rejects this shape with `an assistant
 * message with 'tool_calls' must be followed by tool messages
 * responding to each 'tool_call_id'`. Every new message sent in that
 * session fails until the orphans are reconciled.
 *
 * This helper returns a repaired history with synthetic `tool_result`
 * stubs injected immediately after each affected assistant message,
 * one per orphaned tool_call_id. The stubs are marked `isError: true`
 * with a recovery hint so the model knows the original output is
 * gone and can continue without it.
 */
export function repairOrphanToolCalls(history: readonly ConversationMessage[]): {
	repaired: ConversationMessage[];
	orphans: string[];
} {
	// 2026-06-01: Pass 0 — normalize empty/missing tool_call ids. A session
	// loaded from disk that was written before the agent-core id-synthesis
	// fix may contain assistant tool_calls AND matching tool_results that
	// both carry "" (empty string) as id. Even with wire-side filters that
	// drop empty ids, the empty entries still pollute history-rendering
	// consumers (summarizer transcripts, repair logic itself, future
	// callers). Rewrite them in place: synthesize `${name}:${idx}` for
	// each empty assistant tool_call, and rename the matching tool_result
	// (paired by ORDER within the same assistant→tool group, since both
	// sides are guaranteed-same-length when the original turn completed).
	const normalized: ConversationMessage[] = [];
	let n = 0;
	while (n < history.length) {
		const msg = history[n];
		if (msg.role !== "assistant") {
			normalized.push(msg);
			n++;
			continue;
		}
		// Collect this assistant message's tool_calls in order, synthesizing
		// ids for empty ones.
		const newAsstParts: MessagePart[] = [];
		const renames: { fromIdx: number; toId: string }[] = [];
		let emptyIdx = 0;
		for (const p of msg.parts) {
			if (p.kind === "tool_call") {
				if (typeof p.id !== "string" || p.id.length === 0) {
					const synthId = `${p.name || "unknown"}:repaired:${emptyIdx}`;
					renames.push({ fromIdx: emptyIdx, toId: synthId });
					emptyIdx++;
					newAsstParts.push({ ...p, id: synthId });
				} else {
					emptyIdx++;
					newAsstParts.push(p);
				}
			} else {
				newAsstParts.push(p);
			}
		}
		normalized.push(renames.length > 0 ? { ...msg, parts: newAsstParts } : msg);
		n++;
		// Walk the contiguous tool messages and rename matching tool_results
		// IN ORDER. For each tool_result whose id is empty AND for which we
		// have a rename slot at the same position, apply the synthesized id.
		let emptyResultIdx = 0;
		while (n < history.length && history[n].role === "tool") {
			const toolMsg = history[n];
			const newToolParts: MessagePart[] = [];
			let mutated = false;
			for (const p of toolMsg.parts) {
				if (p.kind === "tool_result") {
					if (typeof p.id !== "string" || p.id.length === 0) {
						const target = renames.find((r) => r.fromIdx === emptyResultIdx);
						if (target) {
							newToolParts.push({ ...p, id: target.toId });
							mutated = true;
						} else {
							// No matching rename slot — drop the orphan empty-id
							// tool_result entirely (it would still trip the wire
							// validator).
							mutated = true;
						}
						emptyResultIdx++;
					} else {
						emptyResultIdx++;
						newToolParts.push(p);
					}
				} else {
					newToolParts.push(p);
				}
			}
			normalized.push(mutated ? { ...toolMsg, parts: newToolParts } : toolMsg);
			n++;
		}
	}

	// Pass 1 — original orphan detection, now running on cleaned data.
	const repaired: ConversationMessage[] = [];
	const orphans: string[] = [];
	let i = 0;
	while (i < normalized.length) {
		const msg = normalized[i];
		repaired.push(msg);
		i++;
		if (msg.role !== "assistant") continue;
		const callIds: string[] = [];
		for (const p of msg.parts) {
			// Empty ids are no longer possible after Pass 0, but keep the
			// guard as defense in depth.
			if (p.kind === "tool_call" && typeof p.id === "string" && p.id.length > 0) {
				callIds.push(p.id);
			}
		}
		if (callIds.length === 0) continue;
		const answered = new Set<string>();
		while (i < normalized.length && normalized[i].role === "tool") {
			const toolMsg = normalized[i];
			repaired.push(toolMsg);
			for (const p of toolMsg.parts) {
				if (p.kind === "tool_result") answered.add(p.id);
			}
			i++;
		}
		for (const id of callIds) {
			if (answered.has(id)) continue;
			orphans.push(id);
			repaired.push({
				role: "tool",
				parts: [
					{
						kind: "tool_result",
						id,
						output:
							"[Tool response was lost — context was repaired to keep the conversation alive. The original output is gone; ignore this stub and proceed with what you have, or re-issue the call if its result is still needed.]",
						isError: true,
					},
				],
			});
		}
	}

	// 2026-06-03: Pass 2 — final cleanup of orphan empty-id tool_results.
	// Pass-0 only normalizes tool messages that immediately follow an
	// assistant message; a tool message that's loose in history (sometimes
	// happens with disk-loaded sessions corrupted by older bugs) survives
	// every repair cycle, then gets dropped by the wire filter on every
	// turn — producing a noisy "[wire-filter] dropped 1 empty-id
	// tool_result" diagnostic that never goes away. Walk the repaired
	// list and strip empty-id tool_results from any tool message,
	// regardless of context. If a tool message ends up with zero parts,
	// drop the entire message so we don't ship empty role:"tool" entries.
	const finalRepaired: ConversationMessage[] = [];
	let cleanedCount = 0;
	for (const m of repaired) {
		if (m.role !== "tool") {
			finalRepaired.push(m);
			continue;
		}
		const keptParts: MessagePart[] = [];
		for (const p of m.parts) {
			if (p.kind === "tool_result" && (typeof p.id !== "string" || p.id.length === 0)) {
				cleanedCount++;
				continue;
			}
			keptParts.push(p);
		}
		if (keptParts.length === 0) continue; // drop the empty tool message entirely
		if (keptParts.length === m.parts.length) {
			finalRepaired.push(m);
		} else {
			finalRepaired.push({ ...m, parts: keptParts });
		}
	}
	void cleanedCount; // tracked for future telemetry; not surfaced yet
	return { repaired: finalRepaired, orphans };
}

/**
 * 2026-06-01: pair-safe head boundary for history compaction. Returns
 * the smallest index >= `minHeadEnd` at which slicing the history
 * leaves no dangling `tool_call_id`s in the prefix — i.e., every
 * assistant tool_call in `history[0..return)` has its matching `tool`
 * response also in `history[0..return)`. Without this, OpenAI rejects
 * the wire request with `an assistant message with 'tool_calls' must
 * be followed by tool messages responding to each 'tool_call_id'`.
 */
export function findSafeHeadBoundary(
	history: readonly ConversationMessage[],
	minHeadEnd: number,
): number {
	let end = Math.min(minHeadEnd, history.length);
	while (end < history.length) {
		const pending = new Set<string>();
		for (let i = 0; i < end; i++) {
			const m = history[i];
			if (m.role === "assistant") {
				for (const p of m.parts) if (p.kind === "tool_call") pending.add(p.id);
			} else if (m.role === "tool") {
				for (const p of m.parts) if (p.kind === "tool_result") pending.delete(p.id);
			}
		}
		if (pending.size === 0) return end;
		end++;
	}
	return end;
}

/**
 * 2026-06-01: pair-safe tail boundary for history compaction. Returns
 * the smallest index >= `initialTailStart` at which the tail's first
 * message is NOT an orphan `tool` response — i.e., a tool message
 * whose matching tool_call assistant message would live in the dropped
 * middle. Achieved by walking forward past leading tool messages.
 */
export function findSafeTailBoundary(
	history: readonly ConversationMessage[],
	initialTailStart: number,
): number {
	let start = Math.max(0, initialTailStart);
	while (start < history.length && history[start].role === "tool") start++;
	return start;
}

/**
 * Pull the text content of the most recent assistant message in history,
 * concatenated across any text parts. Returns `""` when none exists
 * (very rare — only happens before the first assistant turn lands).
 *
 * The false-Done check uses this to locate the "Done" claim regardless
 * of whether it was emitted alongside tool calls in a single iteration
 * (in which case `lastAssistantText` from the trailing empty iteration
 * is blank) or as a standalone wrap-up.
 */
export function findLastAssistantText(history: readonly ConversationMessage[]): string {
	for (let i = history.length - 1; i >= 0; i--) {
		const msg = history[i];
		if (msg.role !== "assistant") continue;
		const parts: string[] = [];
		for (const part of msg.parts) {
			if (part.kind === "text") parts.push(part.text);
		}
		if (parts.length > 0) return parts.join("");
	}
	return "";
}

/**
 * Extract file paths the assistant CLAIMED to have created in this turn.
 *
 * Targets the specific failure mode where the model writes a confident
 * "✅ Done — Created RAG_Architecture.pptx" line without having fired
 * `write_file` or `exec`. The host then verifies each candidate via
 * `fileExists`; a missing path triggers the false-Done warning.
 *
 * Heuristic — narrow on purpose. Only matches:
 *   - completion verbs ("created", "wrote", "saved to / saved", "generated"),
 *     case-insensitive
 *   - immediately followed by a token containing one of the known artifact
 *     extensions (.pptx, .pdf, .docx, .xlsx, .html, .md, .txt, .json, .csv,
 *     .png, .jpg, .svg). Code-file claims (.py, .ts, ...) are out of scope —
 *     those usually accompany real edits and the false-positive cost is too
 *     high to risk.
 *
 * Strips backticks and trailing punctuation. Deduplicates.
 */
export function extractFileCreationClaims(rawText: string): string[] {
	if (!rawText || rawText.length === 0) return [];
	// Pattern: verb (created|wrote|generated|saved to|saved) followed by an
	// optional backtick, then a path token containing one of the known
	// artifact extensions. Allows ./, ../, drive letters, forward + back
	// slashes, dots, dashes, underscores. The lookahead-style trailing
	// punctuation (`.`, `,`, `!`) is stripped after capture.
	const extensions =
		"pptx|pdf|docx|xlsx|html|htm|md|markdown|txt|json|yaml|yml|csv|tsv|png|jpg|jpeg|svg|webp|zip";
	const verb = "created|wrote|generated|saved\\s+to|saved|exported(?:\\s+to)?|output(?:\\s+to)?";
	// Path token: one or more path-safe chars (letters, digits, ., /, \, _, -)
	// followed by a dot and a known artifact extension. Optionally prefixed
	// by a Windows drive letter (`C:/...`).
	const pathToken = `(?:[A-Za-z]:[\\\\/])?[\\.\\/\\\\\\w-]+\\.(?:${extensions})`;
	// Gap between verb and path is whitespace + optional connector
	// punctuation ('to', dashes) — narrow on purpose to avoid backtracking
	// into adjacent words. Optional backtick allows for \`path.ext\` form.
	const re = new RegExp(`\\b(?:${verb})\\b[\\s:—–-]+\`?(${pathToken})\`?`, "gi");
	const claims = new Set<string>();
	for (const m of rawText.matchAll(re)) {
		let path = m[1].trim();
		// Strip trailing punctuation that ate into the path token.
		path = path.replace(/[.,!;:)\]]+$/, "");
		if (path.length > 0) claims.add(path);
	}
	return Array.from(claims);
}

/**
 * Heuristic: does this assistant text look like the model stopped mid-thought?
 * Triggers on trailing colons / ellipses (classic "here's what I'll do:" / "let
 * me check…") and on tail phrases that promise an immediate next action without
 * delivering it. Used by the auto-continue safety net so chat doesn't fall
 * silent on a teaser sentence.
 */
export function looksMidThought(rawText: string): boolean {
	const text = rawText.replace(/\s+$/, "");
	if (text.length === 0) return false;
	const lastChar = text[text.length - 1];
	if (lastChar === ":" || lastChar === "…") return true;
	if (text.endsWith("...")) return true;
	const tail = text.slice(-200).toLowerCase();
	// Phrases that announce an action but don't complete it. Anchored to
	// the end of the tail with at most a few trailing words / punctuation,
	// so they only fire when the phrase is the LAST thing the model wrote.
	const promiseRegex =
		/(let me|i'll|i will|i'm going to|let's|now i|first[, ]|next[, ])\b[^.!?]{0,120}$/;
	return promiseRegex.test(tail);
}

function stableStringify(value: unknown): string {
	if (value === null || typeof value !== "object") {
		return JSON.stringify(value);
	}
	if (Array.isArray(value)) {
		return `[${value.map((v) => stableStringify(v)).join(",")}]`;
	}
	const entries = Object.entries(value as Record<string, unknown>)
		.filter(([, v]) => v !== undefined)
		.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
		.map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`);
	return `{${entries.join(",")}}`;
}

/**
 * 2026-06-29: fish the most recent user-role text out of the history —
 * used by JIT tool filtering to spot literal tool-name mentions in the
 * current request. Returns empty string when the history has no user
 * message yet (first-turn case).
 */
function findLastUserText(messages: readonly ConversationMessage[]): string {
	for (let i = messages.length - 1; i >= 0; i--) {
		if (messages[i].role !== "user") continue;
		const parts = messages[i].parts;
		const textParts = parts.filter(
			(p): p is Extract<MessagePart, { kind: "text" }> => p.kind === "text",
		);
		if (textParts.length > 0) return textParts.map((p) => p.text).join("\n");
	}
	return "";
}

/**
 * 2026-06-29: JIT retry safety net. Scan a provider error message for
 * references to tool names in our full toolbelt. Different providers
 * word "unknown tool" errors differently; we cast a wide but conservative
 * net:
 *   - OpenAI:      "Function 'foo' is not defined"
 *                  "unknown tool 'foo'"
 *   - Anthropic:   "tool_use.name 'foo' not found in tools"
 *                  "input_schema not found for 'foo'"
 *   - vLLM chat:   varies; often "tool 'foo' not found"
 *
 * Returns the subset of our toolbelt names that appear in the error
 * message. Empty when nothing matches (unrelated error). Guarded by a
 * pre-filter on the error message shape so unrelated errors (network,
 * auth, guardrail) never match.
 */
function extractUnknownToolNames(
	errorMessage: string,
	allTools: readonly ToolSpec[],
): readonly string[] {
	if (!/unknown|undefined|not found|not defined|invalid tool/i.test(errorMessage)) return [];
	const hits: string[] = [];
	for (const t of allTools) {
		// Match the tool name as a quoted/bounded token in the error message.
		// Word boundaries + optional surrounding quotes handle the common
		// forms across providers.
		const pattern = new RegExp(`['"\`]?\\b${escapeReForToolMatch(t.name)}\\b['"\`]?`, "i");
		if (pattern.test(errorMessage)) hits.push(t.name);
	}
	return hits;
}

function escapeReForToolMatch(s: string): string {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
