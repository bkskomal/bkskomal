import type { ConversationMessage, Critique, CritiqueVerdict, ProviderSpec } from "@iom/shared";

const CRITIC_SYSTEM_PROMPT =
	`You are an expert code-task reviewer. An agent attempted the user's task; you review the outcome and decide whether the task was actually accomplished.

Be strict but practical:
- If the agent did what was asked and the result looks correct, verdict is "approved".
- If something is clearly broken or the agent gave up partway, verdict is "needs_retry" and you must supply concise, actionable feedback for the agent's next attempt.
- A single missing edge case is approve-with-note; missing the core ask is needs_retry.

Respond ONLY with JSON wrapped in <critique>...</critique> tags, in this exact shape:

<critique>
{"verdict":"approved"}
</critique>

OR

<critique>
{"verdict":"needs_retry","feedback":"specific actionable feedback"}
</critique>

Emit nothing outside the tags.`.trim();

export interface CriticOptions {
	readonly provider: ProviderSpec;
	readonly modelId: string;
	readonly userTask: string;
	readonly executorSummary: string;
	readonly signal?: AbortSignal;
	readonly temperature?: number;
}

/** Run a single-shot model call to grade the executor's output. */
export async function runCritic(opts: CriticOptions): Promise<Critique> {
	const messages: ConversationMessage[] = [
		{
			role: "user",
			parts: [
				{
					kind: "text",
					text: `Original task:\n${opts.userTask}\n\nAgent's final response:\n${opts.executorSummary}`,
				},
			],
		},
	];
	const chunks: string[] = [];
	const stream = opts.provider.stream({
		messages,
		modelId: opts.modelId,
		systemPrompt: CRITIC_SYSTEM_PROMPT,
		temperature: opts.temperature ?? 0.1,
		signal: opts.signal,
	});
	for await (const ev of stream) {
		if (ev.type === "text_delta") chunks.push(ev.text);
	}
	return parseCritique(chunks.join(""));
}

export function parseCritique(raw: string): Critique {
	const match = /<critique>([\s\S]*?)<\/critique>/i.exec(raw);
	if (!match) return { verdict: "approved", raw };
	const inner = match[1].trim();
	try {
		const parsed = JSON.parse(inner) as {
			verdict?: string;
			feedback?: string;
		};
		const verdict: CritiqueVerdict = parsed.verdict === "needs_retry" ? "needs_retry" : "approved";
		if (verdict === "needs_retry") {
			return {
				verdict,
				feedback:
					typeof parsed.feedback === "string"
						? parsed.feedback
						: "Critic requested revision without specifying feedback.",
				raw,
			};
		}
		return { verdict: "approved", raw };
	} catch {
		// On parse failure, default to approving — the executor already did the work and
		// we'd rather not trigger an expensive retry on noise.
		return { verdict: "approved", raw };
	}
}
