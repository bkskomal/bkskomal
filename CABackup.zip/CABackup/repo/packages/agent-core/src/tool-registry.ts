import type { ToolSpec } from "@iom/shared";

export interface ToolListOptions {
	/**
	 * Restrict to tools matching this allow-list. `"all"` (the default) means no
	 * name filter. An array is treated as an allow-list of names.
	 */
	readonly filter?: readonly string[] | "all";
	/**
	 * Visibility scope. `"sub-agent"` includes general-purpose tools AND tools
	 * marked `scope: "sub-agent"`. Omit (default) to exclude `scope: "sub-agent"`
	 * tools — they're only meant for sub-agents in a `spawn_parallel_agents`
	 * batch and shouldn't be exposed to the top-level agent.
	 */
	readonly scope?: "sub-agent";
}

export class ToolRegistry {
	private readonly tools = new Map<string, ToolSpec>();

	register(spec: ToolSpec): void {
		if (this.tools.has(spec.name)) {
			throw new Error(`Tool already registered: ${spec.name}`);
		}
		this.tools.set(spec.name, spec);
	}

	unregister(name: string): boolean {
		return this.tools.delete(name);
	}

	get(name: string): ToolSpec | undefined {
		return this.tools.get(name);
	}

	/**
	 * Backwards-compatible list. Accepts the legacy positional `filter` (array of
	 * names or `"all"`) OR a `ToolListOptions` object. Scoped (`scope: "sub-agent"`)
	 * tools are hidden unless `opts.scope === "sub-agent"` is passed.
	 */
	list(filterOrOpts?: readonly string[] | "all" | ToolListOptions): ToolSpec[] {
		const opts = normalizeListArg(filterOrOpts);
		const all = [...this.tools.values()];
		const scopeFiltered = all.filter((t) => {
			if (!t.scope) return true;
			return t.scope === opts.scope;
		});
		if (!opts.filter || opts.filter === "all") return scopeFiltered;
		const allow = new Set(opts.filter);
		return scopeFiltered.filter((t) => allow.has(t.name));
	}

	has(name: string): boolean {
		return this.tools.has(name);
	}
}

function normalizeListArg(
	v: readonly string[] | "all" | ToolListOptions | undefined,
): ToolListOptions {
	if (!v) return {};
	if (v === "all") return { filter: "all" };
	if (Array.isArray(v)) return { filter: v };
	return v as ToolListOptions;
}
