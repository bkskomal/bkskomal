// 2026-06-29: adaptive load monitor. Tracks per-(provider, model)
// latency + throughput signals from the last N requests, computes a
// rolling baseline, and reports whether the gateway "feels" degraded
// enough to auto-switch contextBudget to aggressive for the next few
// turns.
//
// Signals collected per request:
//   - ttfMs: time-to-first-token (measured from stream start → first
//     text_delta / tool_call / reasoning_delta event)
//   - genTps: generation tokens-per-second (measured from first token
//     → stop event, using estimated output-token count)
//   - status: "ok" | "error" (5xx / timeout / connection reset)
//
// Detection rule (kept simple, tunable via options):
//   A request is "degraded" iff (ttfMs > baseline_ttf × ttfMultiplier)
//   OR (genTps > 0 AND genTps < baseline_tps × tpsMultiplier)
//   OR status is "error".
//
//   If K of the last M requests to the same (provider, model) were
//   degraded, the monitor reports LOAD state. Once loaded, we stay
//   loaded until R consecutive OK requests recover.
//
// Baselines are the MEDIAN of the last H healthy requests (default 20).
// Median is robust to a single slow outlier and doesn't need warmup —
// on the very first request there's no baseline yet, so the request
// contributes to it but doesn't trigger a load signal.
//
// This module is pure state — hosts feed measurements in and read state
// out. Zero I/O. The extension-host owns the actual timing (wraps
// provider.stream) and the mode-override decision (consults getState
// before each turn).

export interface LoadSample {
	readonly capturedAt: number;
	readonly ttfMs: number;
	readonly genTps: number;
	readonly status: "ok" | "error";
}

export interface LoadMonitorOptions {
	/** History depth for baseline computation. Default 20. */
	readonly baselineWindow?: number;
	/** Sliding window for load detection. Default 5. */
	readonly detectionWindow?: number;
	/** How many degraded requests in detectionWindow to enter LOAD state. Default 3. */
	readonly degradedThreshold?: number;
	/** How many consecutive OK requests to exit LOAD state. Default 3. */
	readonly recoveryStreak?: number;
	/** ttfMs must exceed baseline × this to be "slow". Default 3.0. */
	readonly ttfMultiplier?: number;
	/** genTps must fall below baseline × this to be "slow". Default 0.5. */
	readonly tpsMultiplier?: number;
}

export type LoadState = "normal" | "loaded";

export interface LoadSnapshot {
	readonly state: LoadState;
	readonly baselineTtfMs: number | null;
	readonly baselineTps: number | null;
	readonly recentDegraded: number;
	readonly recentTotal: number;
	readonly recoveryStreak: number;
	readonly totalSamples: number;
}

/**
 * Per-(providerId, modelId) sliding-window load tracker. Instantiate one
 * per gateway/model combo you want independently monitored.
 */
export class LoadMonitor {
	private samples: LoadSample[] = [];
	private state: LoadState = "normal";
	private consecutiveOk = 0;
	private readonly opts: Required<LoadMonitorOptions>;

	constructor(opts: LoadMonitorOptions = {}) {
		this.opts = {
			baselineWindow: opts.baselineWindow ?? 20,
			detectionWindow: opts.detectionWindow ?? 5,
			degradedThreshold: opts.degradedThreshold ?? 3,
			recoveryStreak: opts.recoveryStreak ?? 3,
			ttfMultiplier: opts.ttfMultiplier ?? 3.0,
			tpsMultiplier: opts.tpsMultiplier ?? 0.5,
		};
	}

	/**
	 * Record a request outcome. Updates internal state and returns the
	 * new load snapshot so the caller can log / react without a second
	 * getSnapshot() call.
	 */
	record(sample: LoadSample): LoadSnapshot {
		this.samples.push(sample);
		// Bound memory to what we actually use (max of baseline + detection).
		const keep = Math.max(this.opts.baselineWindow, this.opts.detectionWindow);
		if (this.samples.length > keep) this.samples = this.samples.slice(-keep);

		// State machine: transition based on whether this sample is degraded.
		const baseline = this.computeBaseline();
		const degradedThis = this.isDegraded(sample, baseline);

		if (this.state === "normal") {
			// Enter loaded when degradedThreshold of last detectionWindow are degraded.
			const recent = this.samples.slice(-this.opts.detectionWindow);
			const degradedCount = recent.filter((s) => this.isDegraded(s, baseline)).length;
			if (degradedCount >= this.opts.degradedThreshold) {
				this.state = "loaded";
				this.consecutiveOk = 0;
			}
		} else {
			// In loaded state: exit when recoveryStreak consecutive OKs.
			if (!degradedThis) this.consecutiveOk += 1;
			else this.consecutiveOk = 0;
			if (this.consecutiveOk >= this.opts.recoveryStreak) {
				this.state = "normal";
			}
		}

		return this.getSnapshot();
	}

	getSnapshot(): LoadSnapshot {
		const baseline = this.computeBaseline();
		const recent = this.samples.slice(-this.opts.detectionWindow);
		return {
			state: this.state,
			baselineTtfMs: baseline.ttfMs,
			baselineTps: baseline.tps,
			recentDegraded: recent.filter((s) => this.isDegraded(s, baseline)).length,
			recentTotal: recent.length,
			recoveryStreak: this.consecutiveOk,
			totalSamples: this.samples.length,
		};
	}

	/** Forget everything (e.g., on provider config change). */
	reset(): void {
		this.samples = [];
		this.state = "normal";
		this.consecutiveOk = 0;
	}

	/**
	 * Median of the last N healthy (status=="ok") samples. Returns null
	 * on either metric when we don't have enough data yet — callers
	 * treat "null baseline" as "no load detection possible yet".
	 */
	private computeBaseline(): { ttfMs: number | null; tps: number | null } {
		const healthy = this.samples.filter((s) => s.status === "ok").slice(-this.opts.baselineWindow);
		if (healthy.length < 3) return { ttfMs: null, tps: null };
		return {
			ttfMs: median(healthy.map((s) => s.ttfMs).filter((v) => v > 0)),
			tps: median(healthy.map((s) => s.genTps).filter((v) => v > 0)),
		};
	}

	private isDegraded(
		sample: LoadSample,
		baseline: { ttfMs: number | null; tps: number | null },
	): boolean {
		if (sample.status === "error") return true;
		// If we don't have a baseline yet, don't call anything degraded —
		// early samples ARE the baseline and shouldn't trigger a false alarm.
		if (baseline.ttfMs !== null) {
			if (sample.ttfMs > baseline.ttfMs * this.opts.ttfMultiplier) return true;
		}
		if (baseline.tps !== null && sample.genTps > 0) {
			if (sample.genTps < baseline.tps * this.opts.tpsMultiplier) return true;
		}
		return false;
	}
}

function median(values: number[]): number | null {
	if (values.length === 0) return null;
	const sorted = [...values].sort((a, b) => a - b);
	const mid = Math.floor(sorted.length / 2);
	return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}
