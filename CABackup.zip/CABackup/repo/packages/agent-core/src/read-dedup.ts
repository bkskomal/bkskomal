// 2026-06-29: pure transform that detects duplicate `read_file` calls
// within a session's history and replaces later reads (when the file's
// content hash hasn't changed) with a compact reference to the first.
//
// The pattern this fixes: models re-read a file they already have in
// context. This is common when history has been compacted or the model
// isn't sure whether an older read is still fresh. On big files this
// wastes 5-50K tokens per duplicate on the wire.
//
// Rule: for each read_file tool_call in history, key by (path,
// content_hash_of_first_read). Later reads with the SAME hash → replace
// tool_result with a stub pointing at the earlier turn. Later reads
// with a DIFFERENT hash → leave both intact (file changed, both are
// meaningful).
//
// Design invariants (same as context-shrink):
//   1. Pure — never mutates the input.
//   2. Preserve tool_call_id linkage.
//   3. Never touch the LATEST read of any given path — if the model
//      just called read_file, it wants a fresh look, so keep that
//      result verbatim.
//   4. Only touch tools that look like read_file (name matches
//      /^read.?file$/i or "read_lines"). Other tools with a "path"
//      arg (write_file, exec) are NOT dedup targets.
//   5. Content hash is a stable identity — same file/same hash means
//      dedup is safe regardless of mtime.

import type { ConversationMessage, ToolCallPart, ToolResultPart } from "@iom/shared";

export interface ReadDedupOptions {
	/**
	 * Tool names to consider as "reads". Matched case-insensitively.
	 * Default covers our built-in read_file + common variants.
	 */
	readonly readToolNames?: readonly string[];
	/** Only dedup results larger than this many chars. Default 500. */
	readonly minSizeToDedup?: number;
}

export interface DedupResult {
	readonly messages: readonly ConversationMessage[];
	/** How many tool_result blocks were replaced with dedup stubs. */
	readonly dedupCount: number;
	/** Approximate chars saved. */
	readonly bytesSaved: number;
}

const DEFAULT_READ_TOOLS = ["read_file", "read_lines", "readfile", "read"] as const;

/**
 * Walk history for read_file tool_calls, group by (path, hash), and
 * replace all but the FIRST occurrence of a same-hash read with a
 * lightweight reference stub.
 */
export function dedupDuplicateReads(
	messages: readonly ConversationMessage[],
	opts: ReadDedupOptions = {},
): DedupResult {
	const readNames = new Set((opts.readToolNames ?? DEFAULT_READ_TOOLS).map((n) => n.toLowerCase()));
	const minSize = opts.minSizeToDedup ?? 500;

	// Build a table: tool_call_id → { path, turnIndex, output, hash }
	// so we can look up when we see the paired tool_result on the wire.
	type ReadRecord = {
		readonly toolCallId: string;
		readonly path: string;
		readonly turnIndex: number;
		readonly hash: string;
		readonly size: number;
	};
	const callIdToRead = new Map<string, ReadRecord>();
	// Content-hash keyed by path — first-read table.
	const firstReadByPath = new Map<string, ReadRecord>();

	// First pass: identify read_file calls + their results.
	let turnCursor = 0;
	for (const m of messages) {
		if (m.role === "user") turnCursor += 1;
		for (const p of m.parts) {
			if (p.kind === "tool_call" && isReadCall(p, readNames)) {
				const path = extractPath(p);
				if (path) {
					// Placeholder — we'll fill in output on the paired tool_result pass.
					callIdToRead.set(p.id, {
						toolCallId: p.id,
						path,
						turnIndex: turnCursor,
						hash: "",
						size: 0,
					});
				}
			}
		}
	}

	// Second pass: pair tool_results with their calls, compute hashes,
	// populate the firstReadByPath map.
	for (const m of messages) {
		for (const p of m.parts) {
			if (p.kind !== "tool_result") continue;
			const rec = callIdToRead.get(p.id);
			if (!rec) continue;
			const output = typeof p.output === "string" ? p.output : safeStringify(p.output);
			if (output.length < minSize) continue;
			const hash = simpleHash(output);
			const full: ReadRecord = { ...rec, hash, size: output.length };
			callIdToRead.set(p.id, full);
			// Only remember the FIRST read per (path, hash) — later same-hash
			// reads become dedup candidates. Different-hash reads for the
			// same path replace the entry so we track the newest snapshot.
			const existing = firstReadByPath.get(rec.path);
			if (!existing || existing.hash !== hash) {
				firstReadByPath.set(rec.path, full);
			}
		}
	}

	// Third pass: mark which tool_call_ids are dedup candidates.
	// A later read is a candidate iff:
	//   - it's a different tool_call than the first-read for that path
	//   - its hash matches the first-read's hash
	//   - it's NOT the very last read for that path (keep the freshest verbatim)
	const dedupTargets = new Map<string, ReadRecord>(); // tool_call_id → first-read record it aliases to
	// Group reads by path, sorted by turn.
	const readsByPath = new Map<string, ReadRecord[]>();
	for (const rec of callIdToRead.values()) {
		if (rec.hash === "") continue; // wasn't paired to a large enough result
		let list = readsByPath.get(rec.path);
		if (!list) {
			list = [];
			readsByPath.set(rec.path, list);
		}
		list.push(rec);
	}
	for (const [_path, reads] of readsByPath) {
		if (reads.length < 2) continue;
		reads.sort((a, b) => a.turnIndex - b.turnIndex);
		const first = reads[0];
		const last = reads[reads.length - 1];
		for (const r of reads) {
			if (r.toolCallId === first.toolCallId) continue; // never dedup the first
			if (r.toolCallId === last.toolCallId) continue; // never dedup the freshest
			if (r.hash !== first.hash) continue; // different content, both meaningful
			dedupTargets.set(r.toolCallId, first);
		}
	}

	if (dedupTargets.size === 0) {
		return { messages, dedupCount: 0, bytesSaved: 0 };
	}

	// Fourth pass: rebuild the messages, swapping targeted tool_results.
	let dedupCount = 0;
	let bytesSaved = 0;
	const out: ConversationMessage[] = messages.map((m) => {
		let mutated = false;
		const newParts = m.parts.map((p) => {
			if (p.kind !== "tool_result") return p;
			const target = dedupTargets.get(p.id);
			if (!target) return p;
			const original = typeof p.output === "string" ? p.output : safeStringify(p.output);
			const stub = buildDedupStub(target, original.length);
			dedupCount += 1;
			bytesSaved += original.length - stub.length;
			mutated = true;
			const dedupPart: ToolResultPart = {
				kind: "tool_result",
				id: p.id,
				isError: p.isError,
				output: stub,
			};
			return dedupPart;
		});
		return mutated ? { ...m, parts: newParts } : m;
	});

	return { messages: out, dedupCount, bytesSaved };
}

function isReadCall(part: ToolCallPart, readNames: Set<string>): boolean {
	return readNames.has(part.name.toLowerCase());
}

function extractPath(part: ToolCallPart): string | undefined {
	if (!part.args || typeof part.args !== "object") return undefined;
	const a = part.args as Record<string, unknown>;
	// Common arg names across our read tools.
	for (const key of ["path", "file", "filepath", "file_path"]) {
		const v = a[key];
		if (typeof v === "string" && v.length > 0) return v;
	}
	return undefined;
}

function buildDedupStub(
	first: {
		readonly path: string;
		readonly turnIndex: number;
		readonly size: number;
	},
	currentSize: number,
): string {
	return `[iOm dedup: ${first.path} was already read at turn ${first.turnIndex} (${currentSize.toLocaleString()} chars, hash unchanged). Re-using the earlier result — see turn ${first.turnIndex} in this session for the full contents. If you need to verify a change, write to the file and re-read.]`;
}

/**
 * FNV-1a-ish 32-bit hash — fast enough for large strings, stable,
 * no crypto dependency. Collision risk is ~1 in 4 billion — acceptable
 * for this purpose (worst case: we mistakenly dedup two different
 * files with identical hashes, model gets a slightly-wrong reference,
 * it re-invokes read_file to double-check).
 */
function simpleHash(s: string): string {
	let h = 0x811c9dc5;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 0x01000193);
	}
	return (h >>> 0).toString(16);
}

function safeStringify(v: unknown): string {
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}
