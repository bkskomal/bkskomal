// 2026-06-29: context-shrink transforms for the "aggressive" contextBudget.
// The single biggest lever for reducing wire body size on throughput-
// constrained gateways (K2.7 Code on 4× H200, Qwen on OATI vLLM, any
// multi-user shared-KV-cache deployment) is **rolling tool_result
// truncation**: a `read_file` of a 340-line file stays 340 lines in
// history forever unless we act on it, but the model realistically only
// needs the last few tool_results verbatim to keep working — everything
// older can be a one-line summary and it won't lose the thread.
//
// This module is a pure transform: input history, output history with
// the fat removed. Never mutates the caller's array. Applied inside
// agent-core just before the wire messages are built, so the on-disk
// session history is preserved (users can still scroll back and see
// what actually happened) while the wire stays lean.
//
// Design invariants:
//   1. NEVER touch messages from the last K turns (K=5 by default).
//      Fresh tool_results carry the details the model needs right now.
//   2. NEVER touch tool_call blocks — those are metadata about the
//      call itself and are tiny compared to results.
//   3. Preserve tool_call_id linkage: every tool_call must still have
//      a matching tool_result on the wire (Anthropic + OpenAI both
//      reject orphans). Summaries are still valid tool_result blocks.
//   4. Keep the SMALL tool_results as-is. A 200-char grep result adds
//      nothing to summarize. Threshold: only truncate if output > 1000
//      chars.
//   5. The summary is human-readable AND machine-parseable so the model
//      can see "this WAS a read_file of foo.ts, 340 lines, MD5=abc"
//      and decide to re-read if needed.

import type { ConversationMessage, ToolResultPart } from "@iom/shared";

export interface ShrinkOptions {
	/** How many recent turns to preserve verbatim. Default 5. */
	readonly keepLastTurns?: number;
	/** Only truncate results larger than this. Default 1000 chars. */
	readonly minSizeToTruncate?: number;
	/** How many chars to keep at the head of a truncated result. Default 200. */
	readonly headPreview?: number;
}

export interface ShrinkResult {
	readonly messages: readonly ConversationMessage[];
	/** How many tool_result blocks were replaced with summaries. */
	readonly truncatedCount: number;
	/** How many characters were saved (approx). */
	readonly bytesSaved: number;
}

/**
 * A "turn" = one assistant message. Rolling from the end, count K assistant
 * messages back — everything up to and including that message is "recent"
 * and stays verbatim. Everything before is "old" and gets shrunk.
 *
 * We count assistant messages (not user turns) because tool_calls happen
 * on assistant turns, and the tool_results that follow them are what we
 * care about.
 */
export function shrinkOldToolResults(
	messages: readonly ConversationMessage[],
	opts: ShrinkOptions = {},
): ShrinkResult {
	const keepLastTurns = opts.keepLastTurns ?? 5;
	const minSize = opts.minSizeToTruncate ?? 1000;
	const headPreview = opts.headPreview ?? 200;

	// Find the index of the K-th-from-last assistant message. Everything
	// at or after that index is preserved verbatim.
	const assistantIndices: number[] = [];
	for (let i = 0; i < messages.length; i++) {
		if (messages[i].role === "assistant") assistantIndices.push(i);
	}
	const cutoffAssistantIdx = assistantIndices[Math.max(0, assistantIndices.length - keepLastTurns)];
	// If we have fewer than keepLastTurns assistant messages, keep everything.
	if (assistantIndices.length <= keepLastTurns) {
		return { messages, truncatedCount: 0, bytesSaved: 0 };
	}
	const preserveFromIdx = cutoffAssistantIdx;

	let truncatedCount = 0;
	let bytesSaved = 0;
	const out: ConversationMessage[] = messages.map((m, i) => {
		if (i >= preserveFromIdx) return m;
		// Rewrite tool_result parts in this old message.
		let mutated = false;
		const newParts = m.parts.map((p) => {
			if (p.kind !== "tool_result") return p;
			const output = typeof p.output === "string" ? p.output : safeStringify(p.output);
			if (output.length < minSize) return p;
			const summarized = summarizeToolResult(p, output, headPreview);
			mutated = true;
			truncatedCount += 1;
			bytesSaved +=
				output.length - (typeof summarized.output === "string" ? summarized.output.length : 0);
			return summarized;
		});
		return mutated ? { ...m, parts: newParts } : m;
	});

	return { messages: out, truncatedCount, bytesSaved };
}

/**
 * Turn a large tool_result into a compact summary block that preserves:
 *   - the tool_call_id (so wire invariants hold)
 *   - the shape hint (JSON object, JSON array, text, binary)
 *   - size of the original
 *   - first N chars for "what was this about" recognition
 *   - a note that the model can re-invoke the tool if it needs the full result
 *
 * Uses the [iOm ...] marker convention we already use for image memory —
 * consistent visual language across all shrink transforms.
 */
function summarizeToolResult(
	part: ToolResultPart,
	output: string,
	headPreview: number,
): ToolResultPart {
	const size = output.length;
	const head = output.slice(0, headPreview).replace(/\s+/g, " ").trim();
	const shape = detectShape(output);
	const summary = `[iOm shrink: tool_result was ${size.toLocaleString()} chars of ${shape}. Preview: "${head}${size > headPreview ? "…" : ""}". Re-invoke the tool if you need the full result — it's still valid.]`;
	return {
		kind: "tool_result",
		id: part.id,
		isError: part.isError,
		output: summary,
	};
}

function detectShape(s: string): string {
	const t = s.trim();
	if (t.startsWith("{") && t.endsWith("}")) return "JSON object";
	if (t.startsWith("[") && t.endsWith("]")) return "JSON array";
	if (/^[a-zA-Z0-9+/]+={0,2}$/.test(t.slice(0, 100)) && t.length > 200) return "base64";
	if (/^[\x20-\x7e\r\n\t]*$/.test(t.slice(0, 500))) return "text";
	return "binary/other";
}

function safeStringify(v: unknown): string {
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}
