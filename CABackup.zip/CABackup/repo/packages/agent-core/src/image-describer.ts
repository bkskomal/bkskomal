import type { ProviderSpec } from "@iom/shared";

/**
 * 2026-06-01: image-to-description sub-call. When the agent prunes
 * non-most-recent ImageParts from history (per the existing "keep only
 * the latest image" rule), instead of leaving just a generic
 * "[1 earlier screenshot hidden]" breadcrumb we fire a one-shot vision
 * sub-call asking K2.6 (or whatever vision model is active) to describe
 * the image in 3-4 sentences. The description is then stored as a
 * TextPart in place of the dropped ImagePart.
 *
 * Token trade: a 1280×4096 screenshot is ~27k vision tokens; its text
 * description is ~150-300 tokens. ~100× reduction for the price of one
 * extra streaming call when the image is first being demoted.
 *
 * The description is deliberately oriented toward "what would a coding
 * assistant want to remember about this screenshot 3 turns later" —
 * UI layout, what content was on the page, any visible errors or
 * console output, etc. NOT pixel-perfect detail (use re-screenshot if
 * the bytes are needed again).
 */
export const IMAGE_DESCRIBER_SYSTEM_PROMPT = `
You're cataloguing a screenshot so a coding assistant can remember what was on screen 3 turns from now without keeping the pixels around. Output 3-4 sentences, ≤120 words.

Cover, in order:
  1. What the image SHOWS (page name / app screen / terminal / IDE state).
  2. Key visible content — headings, button labels, form fields, console output, error text, anything a developer would care about.
  3. Anything obviously broken or notable (CSS layout issues, visible error toasts, blank regions, mojibake).
  4. The page URL if visible in a browser address bar.

Be specific and concrete. Avoid generic phrases like "looks like a website" — name what's on screen.
`.trim();

export interface ImageDescriberOptions {
	readonly signal?: AbortSignal;
	/** Defaults to 0.2 — description wants determinism, not creativity. */
	readonly temperature?: number;
}

/**
 * Stream a vision sub-call to describe a single image. Returns the
 * model's text output trimmed. If the call fails or the model returns
 * empty, returns `undefined` so the caller can fall back to a generic
 * breadcrumb.
 */
export async function describeImage(
	dataUrl: string,
	mimeType: string,
	provider: ProviderSpec,
	modelId: string,
	opts: ImageDescriberOptions = {},
): Promise<string | undefined> {
	const chunks: string[] = [];
	try {
		const stream = provider.stream({
			messages: [
				{
					role: "user",
					parts: [
						{
							kind: "text",
							text: "Describe this screenshot for a coding assistant's memory log.",
						},
						{ kind: "image", mimeType, dataUrl },
					],
				},
			],
			modelId,
			systemPrompt: IMAGE_DESCRIBER_SYSTEM_PROMPT,
			temperature: opts.temperature ?? 0.2,
			signal: opts.signal,
		});
		for await (const ev of stream) {
			if (ev.type === "text_delta") chunks.push(ev.text);
		}
	} catch {
		return undefined;
	}
	const text = chunks.join("").trim();
	return text.length > 0 ? text : undefined;
}
