import type { ConversationMessage, ProviderSpec } from "@iom/shared";

/**
 * System prompt for the segment summarizer. Tuned to produce a tight, factual
 * recap an executor agent can use as continuation context. We deliberately ask
 * for two paragraphs so the model has space for narrative (paragraph 1 = goal +
 * what happened) and forward-looking notes (paragraph 2 = open questions,
 * blockers, anything still pending). The 200-word cap keeps it from ballooning
 * back into the same context bloat compaction is supposed to fix.
 */
export const SUMMARIZER_SYSTEM_PROMPT =
	`You're summarizing a coding conversation segment for future agent context. Capture: the user's goal, files touched, key decisions, blockers, and any open questions. Output 2 paragraphs, ≤200 words. Be specific — name files, functions, error messages where relevant.`.trim();

export interface SummarizerOptions {
	readonly signal?: AbortSignal;
	/** Defaults to 0.1 — summarization wants determinism, not creativity. */
	readonly temperature?: number;
}

/**
 * Run a single-shot model call to summarize a slice of conversation history.
 * The segment is rendered as a flat transcript and sent as a single user
 * message; the model returns a 2-paragraph summary the caller can drop into
 * the compacted history in place of the omitted turns.
 */
export async function summarizeHistorySegment(
	segment: readonly ConversationMessage[],
	provider: ProviderSpec,
	modelId: string,
	opts: SummarizerOptions = {},
): Promise<string> {
	if (segment.length === 0) return "";
	const transcript = renderSegmentAsTranscript(segment);
	const chunks: string[] = [];
	const stream = provider.stream({
		messages: [{ role: "user", parts: [{ kind: "text", text: transcript }] }],
		modelId,
		systemPrompt: SUMMARIZER_SYSTEM_PROMPT,
		temperature: opts.temperature ?? 0.1,
		signal: opts.signal,
	});
	for await (const ev of stream) {
		if (ev.type === "text_delta") chunks.push(ev.text);
	}
	return chunks.join("").trim();
}

/**
 * Render a slice of ConversationMessage[] as a plain transcript the summarizer
 * model can read. Tool calls and tool results are collapsed to single-line
 * markers so the summarizer focuses on the conversation rather than dumping
 * file contents back out.
 */
export function renderSegmentAsTranscript(segment: readonly ConversationMessage[]): string {
	const lines: string[] = [];
	for (const msg of segment) {
		const role = msg.role.toUpperCase();
		for (const part of msg.parts) {
			if (part.kind === "text") {
				lines.push(`${role}: ${part.text}`);
			} else if (part.kind === "tool_call") {
				const args = safeJson(part.args);
				lines.push(`${role} [tool_call:${part.name}] ${truncate(args, 240)}`);
			} else if (part.kind === "tool_result") {
				const out = typeof part.output === "string" ? part.output : safeJson(part.output);
				const tag = part.isError ? "tool_error" : "tool_result";
				lines.push(`${role} [${tag}] ${truncate(out, 240)}`);
			} else if (part.kind === "image") {
				lines.push(`${role} [image:${part.mimeType}]`);
			}
		}
	}
	return lines.join("\n");
}

function safeJson(v: unknown): string {
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}

function truncate(s: string, n: number): string {
	if (s.length <= n) return s;
	return `${s.slice(0, n)}…`;
}
