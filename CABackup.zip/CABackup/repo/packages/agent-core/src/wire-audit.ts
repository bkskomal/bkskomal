// 2026-06-29: on-wire audit — captures a per-turn breakdown of what
// iOmCode actually sends to the model, categorized so users can see
// WHERE their context tokens are going. The single most important tool
// for reducing waste on throughput-constrained gateways (K2.7 Code on
// 4× H200, Qwen on OATI vLLM, any shared-KV-cache deployment).
//
// Not a runtime hot-path — the recorder captures a bounded window (last
// 5 turns by default) and the analyzer runs on-demand when the user
// invokes `/wire-audit`. Storing a bounded window means we can offer
// forensics even on unrelated turns without paying continuous cost.
//
// PRIVACY: the wire body may contain user code, IOM.md contents, tool
// results with file bodies. The audit is LOCAL — never leaves the
// extension host, never sent to the model, never logged to disk. When
// displayed, we redact obvious credential patterns (Bearer tokens,
// sk-... shapes) as a defense-in-depth measure.

import type { ConversationMessage, ToolSpec } from "@iom/shared";

export interface WireSnapshot {
	/** ms-epoch when this request was sent. */
	readonly capturedAt: number;
	/** Which turn number in the session this was. */
	readonly turnIndex: number;
	/** Model id the request targeted. */
	readonly modelId: string;
	/** Total estimated tokens on the wire (chars/4 heuristic). */
	readonly totalTokens: number;
	/** Per-category token breakdown. */
	readonly breakdown: WireBreakdown;
}

export interface WireBreakdown {
	readonly systemPrompt: number;
	readonly toolSchemas: number;
	readonly userMessages: number;
	readonly assistantText: number;
	readonly toolCalls: number;
	readonly toolResults: number;
	readonly images: number;
	/** Per-tool-result detail — used to identify the biggest offenders. */
	readonly topToolResults: readonly ToolResultSize[];
}

export interface ToolResultSize {
	readonly turnIndex: number;
	readonly toolCallId: string;
	readonly size: number;
	readonly preview: string;
}

export interface WireAuditInput {
	readonly modelId: string;
	readonly systemPrompt?: string;
	readonly tools?: readonly ToolSpec[];
	readonly messages: readonly ConversationMessage[];
	readonly turnIndex: number;
}

/**
 * Compute the token-breakdown for a single wire request. Pure function
 * — no state, no side effects. The estimate uses chars/4 (matches what
 * agent.ts uses for compact decisions) so the numbers here are the same
 * ones auto-compact reasons about.
 */
export function auditWireBody(input: WireAuditInput): WireSnapshot {
	const systemPrompt = input.systemPrompt ? tokEstimate(input.systemPrompt) : 0;
	const toolSchemas = (input.tools ?? []).reduce((sum, t) => {
		try {
			return sum + tokEstimate(JSON.stringify(t.schema)) + tokEstimate(t.description);
		} catch {
			return sum + tokEstimate(t.description);
		}
	}, 0);

	let userMessages = 0;
	let assistantText = 0;
	let toolCalls = 0;
	let toolResults = 0;
	let images = 0;
	const toolResultSizes: ToolResultSize[] = [];

	// Track which turn each message belongs to. A "turn" starts at each
	// user message; keep a running counter so the top-offenders list
	// can point at "the read_file 3 turns ago" precisely.
	let turnCursor = 0;
	for (const m of input.messages) {
		if (m.role === "user") turnCursor += 1;
		for (const p of m.parts) {
			if (p.kind === "text") {
				const t = tokEstimate(p.text);
				if (m.role === "user") userMessages += t;
				else if (m.role === "assistant") assistantText += t;
			} else if (p.kind === "tool_call") {
				try {
					toolCalls += tokEstimate(JSON.stringify(p.args)) + tokEstimate(p.name);
				} catch {
					toolCalls += tokEstimate(p.name);
				}
			} else if (p.kind === "tool_result") {
				const raw = typeof p.output === "string" ? p.output : safeStringify(p.output);
				const size = tokEstimate(raw);
				toolResults += size;
				toolResultSizes.push({
					turnIndex: turnCursor,
					toolCallId: p.id,
					size,
					preview: raw.slice(0, 80).replace(/\s+/g, " ").trim(),
				});
			} else if (p.kind === "image") {
				// Image tokens are a rough approximation — actual per-provider
				// tokenization varies, but chars/4 of the base64 URL isn't
				// meaningful. Treat as a small fixed placeholder.
				images += 85;
			}
		}
	}

	// Keep top 10 tool_result offenders sorted by size for the audit UI.
	const topToolResults = toolResultSizes.sort((a, b) => b.size - a.size).slice(0, 10);

	const breakdown: WireBreakdown = {
		systemPrompt,
		toolSchemas,
		userMessages,
		assistantText,
		toolCalls,
		toolResults,
		images,
		topToolResults,
	};

	const totalTokens =
		systemPrompt + toolSchemas + userMessages + assistantText + toolCalls + toolResults + images;

	return {
		capturedAt: Date.now(),
		turnIndex: input.turnIndex,
		modelId: input.modelId,
		totalTokens,
		breakdown,
	};
}

/**
 * Bounded ring buffer of recent wire snapshots. Default holds last 8
 * turns — enough for `/wire-audit` to show useful history without
 * unbounded memory growth on long sessions.
 */
export class WireAuditRecorder {
	private readonly buffer: WireSnapshot[] = [];
	constructor(private readonly capacity = 8) {}

	record(snapshot: WireSnapshot): void {
		this.buffer.push(snapshot);
		if (this.buffer.length > this.capacity) this.buffer.shift();
	}

	/** Snapshot the current recorded turns (most recent last). */
	list(): readonly WireSnapshot[] {
		return [...this.buffer];
	}

	clear(): void {
		this.buffer.length = 0;
	}
}

/**
 * Render a WireSnapshot as a human-readable text block suitable for
 * dropping into the chat. Formatted like a Cursor / Claude Code
 * diagnostic — monospace-friendly, redacts obvious credential patterns.
 */
export function renderAuditText(snapshots: readonly WireSnapshot[]): string {
	if (snapshots.length === 0) {
		return "No wire audits captured yet. Send a message to the agent, then re-run `/wire-audit`.";
	}
	const lines: string[] = [];
	lines.push(
		`=== Wire audit — last ${snapshots.length} request${snapshots.length === 1 ? "" : "s"} ===`,
	);
	lines.push("");
	for (const s of snapshots) {
		const b = s.breakdown;
		const pct = (n: number) => (s.totalTokens === 0 ? "0.0" : ((n / s.totalTokens) * 100).toFixed(1));
		const at = new Date(s.capturedAt).toISOString().slice(11, 19);
		lines.push(`Turn ${s.turnIndex} @ ${at} → ${fmt(s.totalTokens)} tokens · model=${s.modelId}`);
		lines.push(`├─ system_prompt      ${fmt(b.systemPrompt).padStart(8)}  (${pct(b.systemPrompt)}%)`);
		lines.push(`├─ tool schemas       ${fmt(b.toolSchemas).padStart(8)}  (${pct(b.toolSchemas)}%)`);
		lines.push(`├─ user messages      ${fmt(b.userMessages).padStart(8)}  (${pct(b.userMessages)}%)`);
		lines.push(
			`├─ assistant text     ${fmt(b.assistantText).padStart(8)}  (${pct(b.assistantText)}%)`,
		);
		lines.push(`├─ tool_call blocks   ${fmt(b.toolCalls).padStart(8)}  (${pct(b.toolCalls)}%)`);
		const hotFlag = b.toolResults / Math.max(1, s.totalTokens) > 0.5 ? "  🔥 hot spot" : "";
		lines.push(
			`├─ tool_result blocks ${fmt(b.toolResults).padStart(8)}  (${pct(b.toolResults)}%)${hotFlag}`,
		);
		if (b.images > 0)
			lines.push(`├─ image placeholders ${fmt(b.images).padStart(8)}  (${pct(b.images)}%)`);
		if (b.topToolResults.length > 0) {
			lines.push("│  ↳ Biggest tool_results (candidates for shrink):");
			for (const tr of b.topToolResults.slice(0, 5)) {
				lines.push(`│     • turn ${tr.turnIndex}, ${fmt(tr.size)} tokens: "${tr.preview}"`);
			}
		}
		lines.push("");
	}
	// Trailing guidance
	const total = snapshots.reduce((s, x) => s + x.totalTokens, 0);
	const avg = Math.round(total / snapshots.length);
	lines.push(
		`Average per-request: ${fmt(avg)} tokens across ${snapshots.length} captured request${snapshots.length === 1 ? "" : "s"}.`,
	);
	lines.push("");
	lines.push("Tips: If tool_results dominate (>50%) and you're on a shared-KV-cache");
	lines.push("gateway (K2.7 Code / Qwen on OATI vLLM), switch this mode's contextBudget");
	lines.push("to 'aggressive' in Settings → Modes. Rolling truncation replaces old");
	lines.push("verbatim tool_results with summary stubs on the wire, keeping session");
	lines.push("history intact for scrollback.");
	return lines.join("\n");
}

function fmt(n: number): string {
	return n.toLocaleString();
}

function tokEstimate(s: string): number {
	return Math.ceil(s.length / 4);
}

function safeStringify(v: unknown): string {
	try {
		return JSON.stringify(v);
	} catch {
		return String(v);
	}
}
