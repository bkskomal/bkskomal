/**
 * @deprecated The old prompt-injection planner/critic has been replaced with
 * real separate model calls in `planner.ts` and `critic.ts`, orchestrated by
 * the Conductor. This module is kept only to preserve the public re-export
 * surface and will be removed in a future release.
 *
 * Equivalent behavior:
 *   - `enablePlanner: true` → Conductor runs a dedicated planner model call
 *     before the executor and prepends the structured plan to the executor's
 *     system prompt.
 *   - `enableCritic: true`  → Conductor runs a dedicated critic model call
 *     after the executor and may retry the executor with feedback.
 */
import type { ModeConfig } from "@iom/shared";

/** @deprecated No-op shim. The Conductor now does the pipelining. */
export function applyStagesToSystemPrompt(mode: ModeConfig): ModeConfig {
	return mode;
}
