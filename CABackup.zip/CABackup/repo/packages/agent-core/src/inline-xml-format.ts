// Phase B (2026-05-25): Cline-style inline-XML tool format.
//
// The default OpenAI function-calling protocol is brittle on smaller
// open-weight models (Kimi K2, Qwen, DeepSeek, …). Those models emit
// tool calls more reliably when the format is described in the system
// prompt and they reply with literal XML blocks like
// `<read_file><path>foo.ts</path></read_file>` inside the assistant
// text.
//
// This module builds the system-prompt addendum. The parser side lives
// next to it; the two MUST stay in sync — any change to the tag layout
// here needs a matching change there. The format spec is documented at
// the top of the prompt so the model itself can read the rules.
//
// Pure, synchronous. No I/O. Stable output ordering (matches input
// `tools` order) so the system prompt is deterministic across runs —
// important for prompt caching.

import type { JsonSchemaProperty, ToolSpec } from "@iom/shared";

const HEADER = `## Tool use (inline XML format)

You have access to the following tools. To invoke a tool, emit an XML block in your response. The user's runtime parses these blocks and executes them.

### Format rules

- One tool call per block. You may emit multiple blocks in one response if you have parallel work.
- Use \`<tool_name>\` as the outer tag matching exactly the tool name.
- Each argument is a child tag with the argument name. The argument value goes between the open and close tags as text.
- For multi-line argument values (e.g. file contents, shell commands with newlines), keep the literal newlines — DO NOT escape them.
- After the closing \`</tool_name>\` tag, stop until you receive the tool result.

### Available tools`;

/**
 * Build the full system-prompt addendum describing the toolbelt in
 * inline-XML form. Tools scoped to sub-agents are filtered out — the
 * main loop never invokes those, so showing them would just confuse
 * the model.
 */
export function buildInlineXmlToolPrompt(tools: readonly ToolSpec[]): string {
	const visible = tools.filter((t) => t.scope !== "sub-agent");
	const blocks = visible.map((t) => buildInlineXmlToolDescription(t));
	// Trailing newline is guaranteed: each block ends with \n, and we add one
	// after the header even when there are no tools so the output is
	// stable shape regardless of toolbelt size.
	if (blocks.length === 0) return `${HEADER}\n`;
	return `${HEADER}\n\n${blocks.join("\n")}`;
}

/**
 * Build the description block for a single tool. Useful for tests and
 * for per-tool documentation pages. Output ends with a newline so
 * blocks compose cleanly when joined.
 */
export function buildInlineXmlToolDescription(tool: ToolSpec): string {
	const desc = normalizeDescription(tool.description);
	const example = buildExampleCall(tool);
	return `#### ${tool.name}\n\n${desc}\n\n${example}\n`;
}

/**
 * Strip trailing whitespace from each line. Preserves intentional
 * blank lines (multi-line descriptions stay multi-line). We do NOT
 * trim leading whitespace — a description may want indented examples.
 */
function normalizeDescription(description: string): string {
	return description
		.split("\n")
		.map((line) => line.replace(/[ \t]+$/, ""))
		.join("\n")
		.trim();
}

/**
 * Render one example `<tool_name>…</tool_name>` block. If the tool has
 * no schema properties (rare but legal), emit a self-closing-ish
 * `<tool_name></tool_name>` so the model still sees the shape.
 */
function buildExampleCall(tool: ToolSpec): string {
	const props = tool.schema.properties ?? {};
	const propNames = Object.keys(props);
	if (propNames.length === 0) {
		return `<${tool.name}></${tool.name}>`;
	}

	const lines: string[] = [`<${tool.name}>`];
	for (const propName of propNames) {
		const prop = props[propName];
		if (!prop) continue;
		// Arrays are rare in tool args and don't have a clean inline-XML
		// representation; skip them in the example. The model can still
		// invoke the tool because the parser handles JSON-array fallback.
		if (prop.type === "array") continue;
		const value = exampleValueFor(propName, prop);
		if (value.includes("\n")) {
			// Multi-line value (e.g. file content): put it on its own
			// lines so the example mirrors what the model should emit.
			lines.push(`<${propName}>\n${value}\n</${propName}>`);
		} else {
			lines.push(`<${propName}>${value}</${propName}>`);
		}
	}
	lines.push(`</${tool.name}>`);
	return lines.join("\n");
}

/**
 * Heuristic example value for one property. Name-based hints win over
 * type-based ones so `path` always renders as a path, even if the
 * schema marks it as a generic string.
 */
function exampleValueFor(name: string, prop: JsonSchemaProperty): string {
	const lower = name.toLowerCase();

	// Name-based hints first.
	if (lower === "path" || lower.endsWith("_path") || lower.endsWith("path")) {
		return "relative/or/absolute/path/to/file";
	}
	if (lower === "content" || lower === "contents" || lower === "body") {
		return "the full new contents of the file\nmultiple lines are fine";
	}
	if (lower === "command" || lower === "cmd" || lower === "shell") {
		return "the shell command to run";
	}
	if (lower === "query" || lower === "pattern" || lower === "search") {
		return "search text";
	}
	if (lower === "url" || lower === "uri" || lower === "href") {
		return "https://example.com";
	}

	// Fall back to type.
	switch (prop.type) {
		case "number":
		case "integer":
			return "0";
		case "boolean":
			return "true";
		case "object":
			return "{}";
		default:
			return "value";
	}
}
