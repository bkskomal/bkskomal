// 2026-06-29: JIT (just-in-time) tool schema filtering. For aggressive
// contextBudget on providers that use the `tools[]` array wire format
// (OpenAI, Anthropic native, most vLLM chat endpoints), the full schema
// JSON for every registered tool is sent EVERY TURN. iOm ships ~65
// built-in tools — the schemas total 4-8K tokens per request even
// though a typical turn calls 1-3 of them.
//
// This module returns a filtered subset of tools to send on the wire
// while preserving the model's ability to reach any tool via a safety
// net: names + one-line descriptions of the ENTIRE toolbelt stay in the
// system prompt (as text, cheap), so the model knows what exists. Only
// the JSON SCHEMAS are pruned.
//
// Selection policy (in inclusion order):
//   1. CORE — always included. Small hand-picked set covering the tools
//      the model reaches for on almost every turn (read/write/list/
//      exec/grep/str_replace/ask_user). ~600 tokens.
//   2. RECENT — tools invoked in the last N turns of history (default 5).
//   3. MENTIONED — tools whose name appears literally in the current user
//      message (e.g. user typed "please run the test_suite tool").
//
// Safety net for pruned-away tools: the wire request-error path in
// openai-compatible.ts catches "unknown_tool" errors and RETRIES ONCE
// with the missing tool re-added. This is a fail-open design — the
// worst case is one extra round-trip when we guessed wrong, never
// a broken agent.
//
// Providers that use inline-XML tool format (Kimi K2 / K2.6 / Qwen 3
// Coder via completions fallback) don't send `tools[]` at all — this
// module is a no-op for them, applied only to openai-tools format.

import type { ConversationMessage, ToolSpec } from "@iom/shared";

export interface JitFilterOptions {
	/** How many turns of history to scan for recently-used tools. Default 5. */
	readonly recentTurns?: number;
	/** Override the core-set. Defaults to CORE_TOOL_NAMES. */
	readonly coreToolNames?: readonly string[];
	/** When true, do NOT filter — return all tools. Safety escape hatch. */
	readonly disabled?: boolean;
}

export interface JitFilterResult {
	readonly tools: readonly ToolSpec[];
	readonly dropped: readonly string[];
	readonly kept: readonly string[];
}

/**
 * The "always ship these" set — tools the model reaches for on nearly
 * every turn. Getting this wrong is cheap (extra 100-300 tokens); getting
 * a hot tool wrong (dropping it when the model needs it) triggers a
 * retry round-trip, so bias toward inclusion here.
 */
export const CORE_TOOL_NAMES: readonly string[] = [
	// File I/O
	"read_file",
	"write_file",
	"str_replace",
	"list_files",
	"grep_files",
	// Execution
	"exec",
	// Clarification
	"ask_user",
	// Agent-managed todo list
	"todo_write",
	// Skill loading (aggressive mode benefits from this — model can
	// re-fetch a shrunken skill body without needing the schema kept)
	"load_skill",
];

/**
 * Compute the JIT-filtered tool list for the current turn. Pure function —
 * no state; caller feeds in history and gets back the subset to ship.
 */
export function filterToolsJIT(
	allTools: readonly ToolSpec[],
	history: readonly ConversationMessage[],
	currentUserMessage: string,
	opts: JitFilterOptions = {},
): JitFilterResult {
	if (opts.disabled || allTools.length === 0) {
		return { tools: [...allTools], dropped: [], kept: allTools.map((t) => t.name) };
	}
	const coreNames = new Set((opts.coreToolNames ?? CORE_TOOL_NAMES).map((n) => n.toLowerCase()));
	const recentTurns = opts.recentTurns ?? 5;

	// Recent-used tools: scan last N assistant messages for tool_call parts.
	const recentUsed = new Set<string>();
	const assistantIndices: number[] = [];
	for (let i = 0; i < history.length; i++) {
		if (history[i].role === "assistant") assistantIndices.push(i);
	}
	const cutoff = assistantIndices.slice(-recentTurns);
	for (const idx of cutoff) {
		for (const p of history[idx].parts) {
			if (p.kind === "tool_call") recentUsed.add(p.name.toLowerCase());
		}
	}

	// Mentioned-in-current-message: cheap literal-substring check.
	// Only triggers on multi-word tool names (single-word matches would
	// false-positive on common English words like "read" or "exec"),
	// but we still allow single-word snake_case names since users
	// typically write them literally when asking.
	const mentioned = new Set<string>();
	const msgLower = currentUserMessage.toLowerCase();
	for (const t of allTools) {
		const name = t.name.toLowerCase();
		// Look for the exact tool name as a bounded token in the message.
		// \b works because snake_case names include underscores which are
		// word chars in JS regex.
		if (new RegExp(`\\b${escapeRegExp(name)}\\b`, "i").test(msgLower)) {
			mentioned.add(name);
		}
	}

	// Combine: core ∪ recent ∪ mentioned.
	const keptSet = new Set<string>();
	for (const t of allTools) {
		const name = t.name.toLowerCase();
		if (coreNames.has(name) || recentUsed.has(name) || mentioned.has(name)) {
			keptSet.add(t.name);
		}
	}

	const tools = allTools.filter((t) => keptSet.has(t.name));
	const dropped = allTools.filter((t) => !keptSet.has(t.name)).map((t) => t.name);
	const kept = tools.map((t) => t.name);

	return { tools, dropped, kept };
}

/**
 * Build the "safety net" text section for the system prompt — lists
 * dropped tool NAMES + one-line descriptions so the model still knows
 * what's available. Cheap (~50 tokens per dropped tool vs ~150 for a
 * full schema; typical net savings 30-60%).
 */
export function buildDroppedToolsHint(
	allTools: readonly ToolSpec[],
	dropped: readonly string[],
): string {
	if (dropped.length === 0) return "";
	const droppedSet = new Set(dropped);
	const rows = allTools
		.filter((t) => droppedSet.has(t.name))
		.map(
			(t) =>
				`  - \`${t.name}\` — ${t.description.slice(0, 100)}${t.description.length > 100 ? "…" : ""}`,
		);
	return [
		"<available_but_schema_dropped>",
		"The following tools exist but their JSON schemas have been dropped from",
		"this turn's request to save context tokens (aggressive contextBudget).",
		"If you need to invoke one, just call it — the platform will automatically",
		"add its schema and retry. Descriptions:",
		...rows,
		"</available_but_schema_dropped>",
	].join("\n");
}

function escapeRegExp(s: string): string {
	return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
