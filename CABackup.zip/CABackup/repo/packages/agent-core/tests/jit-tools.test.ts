// Tests for JIT tool-schema filtering.

import type { ConversationMessage, ToolSpec } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { CORE_TOOL_NAMES, buildDroppedToolsHint, filterToolsJIT } from "../src/jit-tools";

function tool(name: string): ToolSpec {
	return {
		name,
		description: `${name} tool`,
		schema: { type: "object" },
		approval: "auto",
		handler: async () => "",
	};
}

function user(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}
function assistantCall(id: string, name: string): ConversationMessage {
	return { role: "assistant", parts: [{ kind: "tool_call", id, name, args: {} }] };
}
function toolResult(id: string, output: string): ConversationMessage {
	return { role: "tool", parts: [{ kind: "tool_result", id, output, isError: false }] };
}

describe("filterToolsJIT", () => {
	it("returns everything unchanged when disabled", () => {
		const tools = ["a", "b", "c", "d"].map(tool);
		const result = filterToolsJIT(tools, [], "", { disabled: true });
		expect(result.tools).toEqual(tools);
		expect(result.dropped).toEqual([]);
	});

	it("always includes CORE tools", () => {
		const tools = [tool("read_file"), tool("write_file"), tool("exec"), tool("some_rare_tool")];
		const result = filterToolsJIT(tools, [], "hello");
		for (const core of CORE_TOOL_NAMES) {
			if (tools.some((t) => t.name === core)) {
				expect(result.kept.map((n) => n.toLowerCase())).toContain(core);
			}
		}
	});

	it("includes tools that were called in the last N turns", () => {
		const tools = [tool("read_file"), tool("some_rare_tool"), tool("another_rare_tool")];
		const history: ConversationMessage[] = [
			user("q1"),
			assistantCall("c1", "some_rare_tool"),
			toolResult("c1", "ok"),
		];
		const result = filterToolsJIT(tools, history, "", { recentTurns: 5 });
		expect(result.kept).toContain("some_rare_tool");
		expect(result.dropped).toContain("another_rare_tool");
	});

	it("includes tools whose name is literally mentioned in the current user message", () => {
		const tools = [tool("read_file"), tool("some_rare_tool"), tool("another_rare_tool")];
		const result = filterToolsJIT(tools, [], "please use the some_rare_tool for this");
		expect(result.kept).toContain("some_rare_tool");
		expect(result.dropped).toContain("another_rare_tool");
	});

	it("does NOT include unrelated tools when neither core nor recent nor mentioned", () => {
		const tools = [tool("read_file"), tool("obscure_toolA"), tool("obscure_toolB")];
		const result = filterToolsJIT(tools, [], "hello world");
		expect(result.dropped).toContain("obscure_toolA");
		expect(result.dropped).toContain("obscure_toolB");
	});

	it("recentTurns only looks at the last N assistant turns", () => {
		const tools = [tool("read_file"), tool("old_tool"), tool("new_tool")];
		const history: ConversationMessage[] = [
			user("q1"),
			assistantCall("c1", "old_tool"),
			toolResult("c1", "ok"),
			user("q2"),
			assistantCall("c2", "read_file"),
			toolResult("c2", "ok"),
			user("q3"),
			assistantCall("c3", "read_file"),
			toolResult("c3", "ok"),
			user("q4"),
			assistantCall("c4", "read_file"),
			toolResult("c4", "ok"),
			user("q5"),
			assistantCall("c5", "read_file"),
			toolResult("c5", "ok"),
			user("q6"),
			assistantCall("c6", "new_tool"),
			toolResult("c6", "ok"),
		];
		// recentTurns=3 → last 3 assistant turns = read_file, read_file, new_tool.
		// old_tool from turn 1 is NOT in window → dropped.
		const result = filterToolsJIT(tools, history, "", { recentTurns: 3 });
		expect(result.dropped).toContain("old_tool");
		expect(result.kept).toContain("new_tool");
	});

	it("respects a custom coreToolNames override", () => {
		const tools = [tool("my_core_a"), tool("my_core_b"), tool("obscure")];
		const result = filterToolsJIT(tools, [], "", { coreToolNames: ["my_core_a", "my_core_b"] });
		expect(result.kept).toContain("my_core_a");
		expect(result.kept).toContain("my_core_b");
		expect(result.dropped).toContain("obscure");
	});

	it("returns unchanged when tools list is empty", () => {
		const result = filterToolsJIT([], [], "hello");
		expect(result.tools).toEqual([]);
		expect(result.dropped).toEqual([]);
	});
});

describe("buildDroppedToolsHint", () => {
	it("returns empty string when nothing was dropped", () => {
		expect(buildDroppedToolsHint([tool("a")], [])).toBe("");
	});

	it("includes dropped tool names and one-line descriptions", () => {
		const tools = [tool("a"), tool("b"), tool("c")];
		const hint = buildDroppedToolsHint(tools, ["b", "c"]);
		expect(hint).toContain("<available_but_schema_dropped>");
		expect(hint).toContain("`b`");
		expect(hint).toContain("`c`");
		expect(hint).not.toContain("`a`");
		expect(hint).toContain("</available_but_schema_dropped>");
	});

	it("truncates long descriptions at 100 chars + ellipsis", () => {
		const long = tool("long");
		const longTool: ToolSpec = { ...long, description: "x".repeat(200) };
		const hint = buildDroppedToolsHint([longTool], ["long"]);
		// Ellipsis present, and the raw 200-char version is NOT.
		expect(hint).toContain("…");
		expect(hint).not.toContain("x".repeat(200));
	});
});
