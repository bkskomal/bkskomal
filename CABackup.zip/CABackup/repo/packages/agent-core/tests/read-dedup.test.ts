// Tests for dedupDuplicateReads — collapses same-hash re-reads of the
// same file into reference stubs to save wire tokens.

import type { ConversationMessage } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { dedupDuplicateReads } from "../src/read-dedup";

function user(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}
function readCall(id: string, path: string): ConversationMessage {
	return {
		role: "assistant",
		parts: [{ kind: "tool_call", id, name: "read_file", args: { path } }],
	};
}
function toolResult(id: string, output: string): ConversationMessage {
	return { role: "tool", parts: [{ kind: "tool_result", id, output, isError: false }] };
}

describe("dedupDuplicateReads", () => {
	it("is a no-op when no reads are duplicated", () => {
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "a.ts"),
			toolResult("c1", "unique content ".repeat(100)),
		];
		const result = dedupDuplicateReads(messages);
		expect(result.dedupCount).toBe(0);
		expect(result.bytesSaved).toBe(0);
	});

	it("dedups a middle same-hash read of the same path", () => {
		const content = "same content ".repeat(200); // > 500 chars threshold
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "a.ts"),
			toolResult("c1", content),
			user("q2"),
			readCall("c2", "a.ts"),
			toolResult("c2", content),
			user("q3"),
			readCall("c3", "a.ts"),
			toolResult("c3", content),
		];
		const result = dedupDuplicateReads(messages);
		// Middle read (turn 2) should be deduped — first is preserved,
		// last is preserved as freshest.
		expect(result.dedupCount).toBe(1);
		expect(result.bytesSaved).toBeGreaterThan(1000);
	});

	it("does NOT dedup reads with different content (file changed between reads)", () => {
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "a.ts"),
			toolResult("c1", "version 1 ".repeat(100)),
			user("q2"),
			readCall("c2", "a.ts"),
			toolResult("c2", "version 2 ".repeat(100)),
			user("q3"),
			readCall("c3", "a.ts"),
			toolResult("c3", "version 3 ".repeat(100)),
		];
		const result = dedupDuplicateReads(messages);
		expect(result.dedupCount).toBe(0);
	});

	it("skips tiny reads below minSizeToDedup", () => {
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "small.txt"),
			toolResult("c1", "tiny"),
			user("q2"),
			readCall("c2", "small.txt"),
			toolResult("c2", "tiny"),
			user("q3"),
			readCall("c3", "small.txt"),
			toolResult("c3", "tiny"),
		];
		const result = dedupDuplicateReads(messages);
		expect(result.dedupCount).toBe(0);
	});

	it("never dedups the very last read of a path (freshest stays verbatim)", () => {
		const content = "x".repeat(2000);
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "a.ts"),
			toolResult("c1", content),
			user("q2"),
			readCall("c2", "a.ts"),
			toolResult("c2", content),
		];
		const result = dedupDuplicateReads(messages);
		// 2 reads, both same content → NO dedup (last is preserved, first
		// is preserved because we never touch the first-read either).
		expect(result.dedupCount).toBe(0);
	});

	it("dedup stub preserves tool_call_id linkage (wire invariant)", () => {
		const content = "same ".repeat(200);
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "a.ts"),
			toolResult("c1", content),
			user("q2"),
			readCall("c2", "a.ts"),
			toolResult("c2", content),
			user("q3"),
			readCall("c3", "a.ts"),
			toolResult("c3", content),
		];
		const result = dedupDuplicateReads(messages);
		const callIds = new Set<string>();
		const resultIds = new Set<string>();
		for (const m of result.messages) {
			for (const p of m.parts) {
				if (p.kind === "tool_call") callIds.add(p.id);
				if (p.kind === "tool_result") resultIds.add(p.id);
			}
		}
		for (const id of callIds) expect(resultIds.has(id)).toBe(true);
	});

	it("stub text follows the [iOm dedup: ...] convention", () => {
		const content = "same ".repeat(200);
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "path/to/file.ts"),
			toolResult("c1", content),
			user("q2"),
			readCall("c2", "path/to/file.ts"),
			toolResult("c2", content),
			user("q3"),
			readCall("c3", "path/to/file.ts"),
			toolResult("c3", content),
		];
		const result = dedupDuplicateReads(messages);
		// The middle turn (index 5, message 2 tool_result) should be a stub.
		const middleResult = result.messages[5].parts[0];
		expect(middleResult.kind).toBe("tool_result");
		if (middleResult.kind === "tool_result" && typeof middleResult.output === "string") {
			expect(middleResult.output).toMatch(/^\[iOm dedup:/);
			expect(middleResult.output).toContain("path/to/file.ts");
			expect(middleResult.output).toContain("turn 1");
		}
	});

	it("recognizes common read-tool variants (read_file, read_lines)", () => {
		const content = "x".repeat(1000);
		const messages: ConversationMessage[] = [
			user("q1"),
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "read_lines", args: { path: "a.ts" } }],
			},
			toolResult("c1", content),
			user("q2"),
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c2", name: "read_lines", args: { path: "a.ts" } }],
			},
			toolResult("c2", content),
			user("q3"),
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c3", name: "read_lines", args: { path: "a.ts" } }],
			},
			toolResult("c3", content),
		];
		const result = dedupDuplicateReads(messages);
		expect(result.dedupCount).toBe(1); // middle read deduped
	});

	it("ignores non-read tools (e.g. write_file with a path arg)", () => {
		const content = "x".repeat(1000);
		const messages: ConversationMessage[] = [
			user("q1"),
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "write_file", args: { path: "a.ts" } }],
			},
			toolResult("c1", content),
			user("q2"),
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c2", name: "write_file", args: { path: "a.ts" } }],
			},
			toolResult("c2", content),
		];
		const result = dedupDuplicateReads(messages);
		expect(result.dedupCount).toBe(0);
	});

	it("does NOT mutate the input", () => {
		const content = "x".repeat(2000);
		const messages: ConversationMessage[] = [
			user("q1"),
			readCall("c1", "a.ts"),
			toolResult("c1", content),
			user("q2"),
			readCall("c2", "a.ts"),
			toolResult("c2", content),
			user("q3"),
			readCall("c3", "a.ts"),
			toolResult("c3", content),
		];
		const before = JSON.stringify(messages);
		dedupDuplicateReads(messages);
		expect(JSON.stringify(messages)).toBe(before);
	});
});
