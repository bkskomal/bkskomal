import type {
	ConversationMessage,
	HostContext,
	ModeConfig,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
	ToolSpec,
} from "@iom/shared";
import { describe, expect, it, vi } from "vitest";
import { Conductor } from "../src/conductor";
import { ProviderRegistry } from "../src/provider-registry";
import { runWithTests } from "../src/test-driven-loop";
import { ToolRegistry } from "../src/tool-registry";

function makeHost(overrides: Partial<HostContext> = {}): HostContext {
	return {
		readFile: vi.fn().mockResolvedValue(""),
		writeFile: vi.fn().mockResolvedValue(undefined),
		fileExists: vi.fn().mockResolvedValue(false),
		exec: vi.fn().mockResolvedValue({ stdout: "", stderr: "", exitCode: 0 }),
		workspaceRoot: () => "/test",
		requestApproval: vi.fn().mockResolvedValue(true),
		showDiff: vi.fn().mockResolvedValue(undefined),
		log: vi.fn(),
		...overrides,
	};
}

function makeProvider(scripts: readonly ProviderStreamEvent[][]): ProviderSpec {
	let call = 0;
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest): AsyncIterable<ProviderStreamEvent> {
			const events = scripts[call++] ?? [{ type: "message_end", stopReason: "end" }];
			for (const ev of events) yield ev;
		},
	};
}

function makeRegistry(provider: ProviderSpec): ProviderRegistry {
	const r = new ProviderRegistry();
	r.register(provider);
	return r;
}

const autoEditMode: ModeConfig = {
	id: "auto-edit",
	displayName: "Auto Edit",
	systemPrompt: "auto",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 5,
	autoApprove: true,
};

const askMode: ModeConfig = {
	id: "ask",
	displayName: "Ask",
	systemPrompt: "ask",
	enabledTools: "all",
	enablePlanner: false,
	enableCritic: false,
	maxParallelAgents: 1,
	maxIterations: 5,
};

const baseHistory: readonly ConversationMessage[] = [];

function makeRunTestsTool(
	scripts: readonly { exitCode: number; failures: { name: string; snippet: string }[] }[],
): ToolSpec {
	let call = 0;
	return {
		name: "run_tests",
		description: "fake tests",
		schema: { type: "object", properties: {} },
		approval: "auto",
		async handler() {
			const r = scripts[call++] ?? scripts[scripts.length - 1];
			return {
				exitCode: r.exitCode,
				summary: r.exitCode === 0 ? "all good" : "some failed",
				failures: r.failures,
				runner: "vitest",
			};
		},
	};
}

describe("runWithTests", () => {
	it("is a no-op in non-auto modes", async () => {
		const provider = makeProvider([]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const runTests = makeRunTestsTool([{ exitCode: 1, failures: [{ name: "x", snippet: "" }] }]);
		const result = await runWithTests(conductor, baseHistory, {
			mode: askMode,
			modelId: "m",
			providerId: "mock",
			tools: [runTests],
			host: makeHost(),
			touchedFiles: true,
		});
		expect(result.testsRan).toBe(false);
		expect(result.fixIterations).toBe(0);
	});

	it("is a no-op when no files were touched", async () => {
		const provider = makeProvider([]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const runTests = makeRunTestsTool([{ exitCode: 1, failures: [{ name: "x", snippet: "" }] }]);
		const result = await runWithTests(conductor, baseHistory, {
			mode: autoEditMode,
			modelId: "m",
			providerId: "mock",
			tools: [runTests],
			host: makeHost(),
			touchedFiles: false,
		});
		expect(result.testsRan).toBe(false);
	});

	it("returns immediately when tests pass on the first attempt", async () => {
		const provider = makeProvider([]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const runTests = makeRunTestsTool([{ exitCode: 0, failures: [] }]);
		const result = await runWithTests(conductor, baseHistory, {
			mode: autoEditMode,
			modelId: "m",
			providerId: "mock",
			tools: [runTests],
			host: makeHost(),
			touchedFiles: true,
		});
		expect(result.testsRan).toBe(true);
		expect(result.finalExitCode).toBe(0);
		expect(result.fixIterations).toBe(0);
	});

	it("feeds failures back and re-runs tests up to the cap", async () => {
		// Each spawn turn writes a file (so the loop keeps iterating).
		const writeFileCall: ProviderStreamEvent = {
			type: "tool_call",
			id: "tc1",
			name: "write_file",
			args: { path: "x.ts", content: "y" },
		};
		const provider = makeProvider([
			[writeFileCall, { type: "message_end", stopReason: "tool_use" }],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
			[writeFileCall, { type: "message_end", stopReason: "tool_use" }],
			[
				{ type: "text_delta", text: "done" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const host = makeHost();
		const writeFileTool: ToolSpec = {
			name: "write_file",
			description: "fake write",
			schema: { type: "object", properties: {} },
			approval: "auto",
			async handler() {
				return { written: true };
			},
		};
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: (() => {
				const r = new ToolRegistry();
				r.register(writeFileTool);
				return r;
			})(),
			host,
		});
		const runTests = makeRunTestsTool([
			{ exitCode: 1, failures: [{ name: "t1", snippet: "boom" }] },
			{ exitCode: 0, failures: [] },
		]);
		const result = await runWithTests(conductor, baseHistory, {
			mode: autoEditMode,
			modelId: "m",
			providerId: "mock",
			tools: [runTests],
			host: makeHost(),
			touchedFiles: true,
			maxFixIterations: 3,
		});
		expect(result.testsRan).toBe(true);
		expect(result.finalExitCode).toBe(0);
		expect(result.fixIterations).toBe(1);
	});

	it("stops if the fix turn does not edit files", async () => {
		// First turn fails tests. Fix turn emits text but no tool calls — loop stops.
		const provider = makeProvider([
			[
				{ type: "text_delta", text: "no edits this time" },
				{ type: "message_end", stopReason: "end" },
			],
		]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const runTests = makeRunTestsTool([{ exitCode: 1, failures: [{ name: "t1", snippet: "boom" }] }]);
		const result = await runWithTests(conductor, baseHistory, {
			mode: autoEditMode,
			modelId: "m",
			providerId: "mock",
			tools: [runTests],
			host: makeHost(),
			touchedFiles: true,
			maxFixIterations: 3,
		});
		expect(result.fixIterations).toBe(1);
		expect(result.finalExitCode).toBe(1);
	});

	it("skips when run_tests tool is not registered", async () => {
		const provider = makeProvider([]);
		const conductor = new Conductor({
			providers: makeRegistry(provider),
			tools: new ToolRegistry(),
			host: makeHost(),
		});
		const result = await runWithTests(conductor, baseHistory, {
			mode: autoEditMode,
			modelId: "m",
			providerId: "mock",
			tools: [],
			host: makeHost(),
			touchedFiles: true,
		});
		expect(result.testsRan).toBe(false);
	});
});
