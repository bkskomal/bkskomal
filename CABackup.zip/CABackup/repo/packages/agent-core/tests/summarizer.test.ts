import type {
	ConversationMessage,
	ProviderRequest,
	ProviderSpec,
	ProviderStreamEvent,
} from "@iom/shared";
import { describe, expect, it, vi } from "vitest";
import {
	SUMMARIZER_SYSTEM_PROMPT,
	renderSegmentAsTranscript,
	summarizeHistorySegment,
} from "../src/summarizer";

interface CapturedRequest {
	value: ProviderRequest | undefined;
}

function streamingProvider(text: string, captured: CapturedRequest): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(req: ProviderRequest) {
			captured.value = req;
			yield { type: "text_delta", text } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		},
	};
}

function user(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}
function assistant(text: string): ConversationMessage {
	return { role: "assistant", parts: [{ kind: "text", text }] };
}

describe("renderSegmentAsTranscript", () => {
	it("renders user and assistant text turns with role prefixes", () => {
		const out = renderSegmentAsTranscript([user("hello"), assistant("hi back")]);
		expect(out).toContain("USER: hello");
		expect(out).toContain("ASSISTANT: hi back");
	});

	it("collapses tool calls and tool results to single-line markers", () => {
		const segment: ConversationMessage[] = [
			{
				role: "assistant",
				parts: [{ kind: "tool_call", id: "c1", name: "read_file", args: { path: "src/foo.ts" } }],
			},
			{
				role: "tool",
				parts: [
					{
						kind: "tool_result",
						id: "c1",
						output: "console.log('hi');",
						isError: false,
					},
				],
			},
		];
		const out = renderSegmentAsTranscript(segment);
		expect(out).toContain("[tool_call:read_file]");
		expect(out).toContain("src/foo.ts");
		expect(out).toContain("[tool_result]");
	});

	it("tags error tool results distinctly", () => {
		const segment: ConversationMessage[] = [
			{
				role: "tool",
				parts: [{ kind: "tool_result", id: "x", output: "ENOENT", isError: true }],
			},
		];
		expect(renderSegmentAsTranscript(segment)).toContain("[tool_error]");
	});

	it("emits an image placeholder rather than the data URL", () => {
		const segment: ConversationMessage[] = [
			{
				role: "user",
				parts: [{ kind: "image", mimeType: "image/png", dataUrl: "data:image/png;base64,AAAA" }],
			},
		];
		const out = renderSegmentAsTranscript(segment);
		expect(out).toContain("[image:image/png]");
		expect(out).not.toContain("AAAA");
	});
});

describe("summarizeHistorySegment", () => {
	it("returns the streamed text and uses the summarizer system prompt", async () => {
		const captured: CapturedRequest = { value: undefined };
		const provider = streamingProvider("The user wanted to refactor foo.ts.", captured);
		const out = await summarizeHistorySegment(
			[user("rename foo to bar"), assistant("done")],
			provider,
			"any-model",
		);
		expect(out).toBe("The user wanted to refactor foo.ts.");
		expect(captured.value?.systemPrompt).toBe(SUMMARIZER_SYSTEM_PROMPT);
		expect(captured.value?.modelId).toBe("any-model");
		// Sent as a single user message — not the raw history.
		expect(captured.value?.messages).toHaveLength(1);
		expect(captured.value?.messages[0].role).toBe("user");
	});

	it("returns an empty string for an empty segment without calling the provider", async () => {
		const captured: CapturedRequest = { value: undefined };
		const provider = streamingProvider("never used", captured);
		const spy = vi.spyOn(provider, "stream");
		const out = await summarizeHistorySegment([], provider, "any");
		expect(out).toBe("");
		expect(spy).not.toHaveBeenCalled();
	});

	it("forwards the abort signal to the provider stream", async () => {
		const captured: CapturedRequest = { value: undefined };
		const provider = streamingProvider("ok", captured);
		const ctrl = new AbortController();
		await summarizeHistorySegment([user("a")], provider, "m", { signal: ctrl.signal });
		expect(captured.value?.signal).toBe(ctrl.signal);
	});

	it("defaults to a low temperature for deterministic summaries", async () => {
		const captured: CapturedRequest = { value: undefined };
		const provider = streamingProvider("ok", captured);
		await summarizeHistorySegment([user("a")], provider, "m");
		expect(captured.value?.temperature).toBe(0.1);
	});

	it("trims whitespace around the model output", async () => {
		const captured: CapturedRequest = { value: undefined };
		const provider = streamingProvider("\n\n   summary text\n\n", captured);
		const out = await summarizeHistorySegment([user("a")], provider, "m");
		expect(out).toBe("summary text");
	});
});
