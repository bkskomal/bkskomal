// Tests for the LoadMonitor — sliding-window degradation detection
// used by adaptiveContextBudget mode.

import { describe, expect, it } from "vitest";
import { LoadMonitor } from "../src/load-monitor";

function ok(ttf: number, tps: number) {
	return { capturedAt: Date.now(), ttfMs: ttf, genTps: tps, status: "ok" as const };
}
function bad(ttf: number, tps: number) {
	return { capturedAt: Date.now(), ttfMs: ttf, genTps: tps, status: "error" as const };
}

describe("LoadMonitor", () => {
	it("starts in normal state with no samples", () => {
		const m = new LoadMonitor();
		const snap = m.getSnapshot();
		expect(snap.state).toBe("normal");
		expect(snap.baselineTtfMs).toBeNull();
		expect(snap.baselineTps).toBeNull();
	});

	it("does NOT enter loaded state before it has a baseline", () => {
		const m = new LoadMonitor();
		// Even wildly bad numbers early on shouldn't trip — we haven't
		// established what "normal" looks like yet.
		m.record(ok(100_000, 0.001));
		m.record(ok(100_000, 0.001));
		expect(m.getSnapshot().state).toBe("normal");
	});

	it("enters loaded state when 3 of last 5 requests are degraded", () => {
		const m = new LoadMonitor();
		// Establish healthy baseline: 5 fast requests
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		expect(m.getSnapshot().state).toBe("normal");
		// Now 3 slow requests in a row → degraded
		m.record(ok(1500, 30)); // ttf 7.5× baseline → degraded
		m.record(ok(1500, 30));
		const snap = m.record(ok(1500, 30));
		expect(snap.state).toBe("loaded");
	});

	it("recovers to normal state after 3 consecutive healthy requests", () => {
		const m = new LoadMonitor();
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		// Enter loaded
		m.record(ok(1500, 30));
		m.record(ok(1500, 30));
		m.record(ok(1500, 30));
		expect(m.getSnapshot().state).toBe("loaded");
		// 3 consecutive OK → recovery
		m.record(ok(200, 30));
		m.record(ok(200, 30));
		const final = m.record(ok(200, 30));
		expect(final.state).toBe("normal");
	});

	it("treats error status as degraded regardless of timing numbers", () => {
		const m = new LoadMonitor();
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		m.record(bad(200, 30));
		m.record(bad(200, 30));
		const snap = m.record(bad(200, 30));
		expect(snap.state).toBe("loaded");
	});

	it("detects low TPS as degraded (below baseline × tpsMultiplier)", () => {
		const m = new LoadMonitor();
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		// TPS at 5 (< 15 = 30 × 0.5) → degraded
		m.record(ok(200, 5));
		m.record(ok(200, 5));
		const snap = m.record(ok(200, 5));
		expect(snap.state).toBe("loaded");
	});

	it("honors custom degradedThreshold", () => {
		const m = new LoadMonitor({ degradedThreshold: 2 });
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		m.record(ok(1500, 30));
		const snap = m.record(ok(1500, 30));
		expect(snap.state).toBe("loaded");
	});

	it("reset() clears state and samples", () => {
		const m = new LoadMonitor();
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		m.record(ok(1500, 30));
		m.record(ok(1500, 30));
		m.record(ok(1500, 30));
		expect(m.getSnapshot().state).toBe("loaded");
		m.reset();
		expect(m.getSnapshot().state).toBe("normal");
		expect(m.getSnapshot().totalSamples).toBe(0);
	});

	it("baseline is median (not mean) — robust to a single outlier", () => {
		const m = new LoadMonitor();
		for (let i = 0; i < 4; i++) m.record(ok(200, 30));
		// One huge outlier at 10s — shouldn't move the median much
		m.record(ok(10_000, 30));
		const snap = m.record(ok(200, 30));
		// Median of [200,200,200,200,10000,200] = 200
		expect(snap.baselineTtfMs).toBe(200);
	});

	it("snapshot exposes recentDegraded and recoveryStreak counters", () => {
		const m = new LoadMonitor();
		for (let i = 0; i < 5; i++) m.record(ok(200, 30));
		m.record(ok(1500, 30));
		const s1 = m.record(ok(1500, 30));
		expect(s1.recentDegraded).toBeGreaterThanOrEqual(2);
	});
});
