import type { ConversationMessage } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { lastToolCallsAreInvestigatory } from "../src/agent";

function assistantWithCalls(names: readonly string[]): ConversationMessage {
	return {
		role: "assistant",
		parts: names.map((name, i) => ({
			kind: "tool_call",
			id: `c${i}`,
			name,
			args: {},
		})),
	};
}

function userMsg(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}

describe("lastToolCallsAreInvestigatory", () => {
	it("returns true for a single workspace_context call", () => {
		const history: ConversationMessage[] = [
			userMsg("help"),
			assistantWithCalls(["workspace_context"]),
		];
		expect(lastToolCallsAreInvestigatory(history)).toBe(true);
	});

	it("returns true when multiple investigatory tools were called in one turn", () => {
		const history: ConversationMessage[] = [
			userMsg("help"),
			assistantWithCalls(["list_dir", "read_file"]),
		];
		expect(lastToolCallsAreInvestigatory(history)).toBe(true);
	});

	it("returns false when ANY mutation tool was in the same turn", () => {
		const history: ConversationMessage[] = [
			userMsg("help"),
			assistantWithCalls(["read_file", "write_file"]),
		];
		expect(lastToolCallsAreInvestigatory(history)).toBe(false);
	});

	it("returns false for write_file alone (real work)", () => {
		const history: ConversationMessage[] = [userMsg("help"), assistantWithCalls(["write_file"])];
		expect(lastToolCallsAreInvestigatory(history)).toBe(false);
	});

	it("returns false for exec (could be mutating)", () => {
		const history: ConversationMessage[] = [userMsg("help"), assistantWithCalls(["exec"])];
		expect(lastToolCallsAreInvestigatory(history)).toBe(false);
	});

	it("only looks at the MOST RECENT assistant message", () => {
		// Earlier turn had a write; latest turn was just investigation —
		// we should treat the latest call set as investigatory.
		const history: ConversationMessage[] = [
			userMsg("create file"),
			assistantWithCalls(["write_file"]),
			userMsg("now find usages"),
			assistantWithCalls(["find_references"]),
		];
		expect(lastToolCallsAreInvestigatory(history)).toBe(true);
	});

	it("returns false when the most recent assistant message has no tool calls", () => {
		const history: ConversationMessage[] = [
			userMsg("hi"),
			{
				role: "assistant",
				parts: [{ kind: "text", text: "Hello." }],
			},
		];
		expect(lastToolCallsAreInvestigatory(history)).toBe(false);
	});

	it("returns false for empty history", () => {
		expect(lastToolCallsAreInvestigatory([])).toBe(false);
	});

	it("recognizes the canonical investigatory tools", () => {
		// Spot-check the most common ones from the registry.
		const TOOLS = [
			"workspace_context",
			"get_workspace_context",
			"read_file",
			"list_dir",
			"grep_search",
			"find_definition",
			"find_references",
			"get_diagnostics",
			"code_semantic_search",
			"git_status",
			"git_diff",
			"fetch_url",
		];
		for (const t of TOOLS) {
			expect(lastToolCallsAreInvestigatory([userMsg("x"), assistantWithCalls([t])])).toBe(true);
		}
	});
});
