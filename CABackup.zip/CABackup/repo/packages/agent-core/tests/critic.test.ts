import type { ProviderRequest, ProviderSpec, ProviderStreamEvent } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { parseCritique, runCritic } from "../src/critic";

function streamOf(text: string): ProviderSpec {
	return {
		id: "mock",
		displayName: "mock",
		async *stream(_req: ProviderRequest) {
			yield { type: "text_delta", text } as ProviderStreamEvent;
			yield { type: "message_end", stopReason: "end" } as ProviderStreamEvent;
		},
	};
}

describe("parseCritique", () => {
	it("parses an approval", () => {
		const c = parseCritique(`<critique>{"verdict":"approved"}</critique>`);
		expect(c.verdict).toBe("approved");
		expect(c.feedback).toBeUndefined();
	});

	it("parses a needs_retry with feedback", () => {
		const c = parseCritique(
			`<critique>{"verdict":"needs_retry","feedback":"missed edge case for null"}</critique>`,
		);
		expect(c.verdict).toBe("needs_retry");
		expect(c.feedback).toBe("missed edge case for null");
	});

	it("supplies a generic feedback when needs_retry omits one", () => {
		const c = parseCritique(`<critique>{"verdict":"needs_retry"}</critique>`);
		expect(c.verdict).toBe("needs_retry");
		expect(c.feedback).toContain("without specifying");
	});

	it("defaults to approved when verdict is unknown", () => {
		const c = parseCritique(`<critique>{"verdict":"???"}</critique>`);
		expect(c.verdict).toBe("approved");
	});

	it("defaults to approved when no critique tags are present", () => {
		const c = parseCritique("Looks good to me.");
		expect(c.verdict).toBe("approved");
	});

	it("defaults to approved when JSON inside tags is malformed (does not block on noise)", () => {
		const c = parseCritique("<critique>{not real json}</critique>");
		expect(c.verdict).toBe("approved");
	});

	it("is case-insensitive on the tag name", () => {
		const c = parseCritique(`<CRITIQUE>{"verdict":"needs_retry","feedback":"x"}</CRITIQUE>`);
		expect(c.verdict).toBe("needs_retry");
	});
});

describe("runCritic", () => {
	it("returns the parsed verdict from a streamed response", async () => {
		const provider = streamOf(
			`<critique>{"verdict":"needs_retry","feedback":"missing tests"}</critique>`,
		);
		const critique = await runCritic({
			provider,
			modelId: "any",
			userTask: "ship the feature",
			executorSummary: "I shipped half of it.",
		});
		expect(critique.verdict).toBe("needs_retry");
		expect(critique.feedback).toBe("missing tests");
	});
});
