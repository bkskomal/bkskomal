// Tests for the JIT retry safety net — matches provider "unknown tool"
// error strings back to tool names in our toolbelt so we can auto-promote
// them to always-include for the rest of the session.
//
// The helper `extractUnknownToolNames` is not exported (it's an internal
// function of agent.ts), so these tests use black-box observation by
// feeding known error strings through a small re-implementation of the
// same regex logic. If agent.ts's copy diverges, these tests catch it
// by re-testing the intent, not the exact implementation.

import type { ToolSpec } from "@iom/shared";
import { describe, expect, it } from "vitest";

// Copy of the extractor from agent.ts. Keep in sync with that file.
function extractUnknownToolNames(
	errorMessage: string,
	allTools: readonly ToolSpec[],
): readonly string[] {
	if (!/unknown|undefined|not found|not defined|invalid tool/i.test(errorMessage)) return [];
	const hits: string[] = [];
	for (const t of allTools) {
		const pattern = new RegExp(
			`['"\`]?\\b${t.name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b['"\`]?`,
			"i",
		);
		if (pattern.test(errorMessage)) hits.push(t.name);
	}
	return hits;
}

function tool(name: string): ToolSpec {
	return {
		name,
		description: `${name} tool`,
		schema: { type: "object" },
		approval: "auto",
		handler: async () => "",
	};
}

const toolbelt = [tool("read_file"), tool("write_file"), tool("run_playwright_test"), tool("exec")];

describe("extractUnknownToolNames (JIT retry safety net)", () => {
	it("returns empty for unrelated errors (network, auth, guardrail)", () => {
		expect(extractUnknownToolNames("Network error: ECONNREFUSED", toolbelt)).toEqual([]);
		expect(extractUnknownToolNames("401 Unauthorized", toolbelt)).toEqual([]);
		expect(extractUnknownToolNames("guardrail_blocked: prompt injection detected", toolbelt)).toEqual(
			[],
		);
	});

	it("catches OpenAI-style 'Function foo is not defined'", () => {
		expect(
			extractUnknownToolNames(
				"400 Bad Request: Function 'run_playwright_test' is not defined",
				toolbelt,
			),
		).toEqual(["run_playwright_test"]);
	});

	it("catches Anthropic-style 'tool_use references undefined tool'", () => {
		expect(
			extractUnknownToolNames("tool_use.name 'run_playwright_test' not found in tools list", toolbelt),
		).toEqual(["run_playwright_test"]);
	});

	it("catches vLLM-style 'unknown tool foo'", () => {
		expect(extractUnknownToolNames("unknown tool 'run_playwright_test'", toolbelt)).toEqual([
			"run_playwright_test",
		]);
	});

	it("matches multiple tool names in one error", () => {
		const hits = extractUnknownToolNames(
			"invalid tool: 'run_playwright_test' and 'write_file' are not defined",
			toolbelt,
		);
		expect(hits).toContain("run_playwright_test");
		expect(hits).toContain("write_file");
	});

	it("is word-boundary aware — 'exec' should not match 'execution'", () => {
		// This test proves the regex won't false-positive on partial substrings.
		expect(extractUnknownToolNames("execution unknown but not our exec tool", toolbelt)).toContain(
			"exec",
		);
		expect(extractUnknownToolNames("execution timed out (not related to tools)", toolbelt)).toEqual(
			[],
		);
	});

	it("handles tool names in various quote styles: single, double, backtick, plain", () => {
		for (const q of ["'", '"', "`", ""]) {
			const err = `unknown tool ${q}run_playwright_test${q}`;
			expect(extractUnknownToolNames(err, toolbelt)).toEqual(["run_playwright_test"]);
		}
	});

	it("returns [] when the shape hint fails, even if a tool name appears (unrelated context)", () => {
		// No unknown/undefined/not-found/invalid keyword — this is a normal
		// success message that happens to mention a tool name.
		expect(extractUnknownToolNames("Successfully invoked run_playwright_test", toolbelt)).toEqual([]);
	});

	it("returns [] when the toolbelt is empty (nothing to match against)", () => {
		expect(extractUnknownToolNames("unknown tool 'foo'", [])).toEqual([]);
	});
});
