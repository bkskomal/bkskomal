// Tests for the wire-audit module — measurement + rendering.

import type { ConversationMessage, ToolSpec } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { WireAuditRecorder, auditWireBody, renderAuditText } from "../src/wire-audit";

function user(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}
function assistant(text: string): ConversationMessage {
	return { role: "assistant", parts: [{ kind: "text", text }] };
}
function tool(id: string, output: string): ConversationMessage {
	return { role: "tool", parts: [{ kind: "tool_result", id, output, isError: false }] };
}

const dummyTool: ToolSpec = {
	name: "read_file",
	description: "read a file",
	schema: { type: "object", properties: { path: { type: "string" } }, required: ["path"] },
	approval: "auto",
	handler: async () => "",
};

describe("auditWireBody", () => {
	it("returns zero-token snapshot on empty input", () => {
		const s = auditWireBody({ modelId: "test", messages: [], turnIndex: 0 });
		expect(s.totalTokens).toBe(0);
		expect(s.breakdown.systemPrompt).toBe(0);
	});

	it("counts system prompt tokens", () => {
		const s = auditWireBody({
			modelId: "test",
			systemPrompt: "x".repeat(400),
			messages: [],
			turnIndex: 0,
		});
		expect(s.breakdown.systemPrompt).toBe(100); // 400/4
		expect(s.totalTokens).toBe(100);
	});

	it("counts tool schema tokens", () => {
		const s = auditWireBody({
			modelId: "test",
			tools: [dummyTool],
			messages: [],
			turnIndex: 0,
		});
		expect(s.breakdown.toolSchemas).toBeGreaterThan(0);
	});

	it("categorizes user vs assistant vs tool_result correctly", () => {
		const s = auditWireBody({
			modelId: "test",
			messages: [user("a".repeat(400)), assistant("b".repeat(800)), tool("c1", "c".repeat(2000))],
			turnIndex: 1,
		});
		expect(s.breakdown.userMessages).toBe(100);
		expect(s.breakdown.assistantText).toBe(200);
		expect(s.breakdown.toolResults).toBe(500);
	});

	it("finds the biggest tool_results and puts them in topToolResults, sorted desc", () => {
		const s = auditWireBody({
			modelId: "test",
			messages: [
				user("q1"),
				assistant("r1"),
				tool("c1", "x".repeat(400)),
				user("q2"),
				assistant("r2"),
				tool("c2", "y".repeat(20_000)),
				user("q3"),
				assistant("r3"),
				tool("c3", "z".repeat(4_000)),
			],
			turnIndex: 3,
		});
		expect(s.breakdown.topToolResults).toHaveLength(3);
		// Sorted by size descending
		expect(s.breakdown.topToolResults[0].size).toBe(5000); // 20000/4
		expect(s.breakdown.topToolResults[1].size).toBe(1000); // 4000/4
		expect(s.breakdown.topToolResults[2].size).toBe(100); // 400/4
		// Turn index tracks correctly (each `user` increments)
		expect(s.breakdown.topToolResults[0].turnIndex).toBe(2);
	});

	it("stamps capturedAt as a real ms-epoch", () => {
		const before = Date.now();
		const s = auditWireBody({ modelId: "test", messages: [], turnIndex: 0 });
		const after = Date.now();
		expect(s.capturedAt).toBeGreaterThanOrEqual(before);
		expect(s.capturedAt).toBeLessThanOrEqual(after);
	});
});

describe("WireAuditRecorder", () => {
	it("stores up to `capacity` snapshots, then rolls the oldest off", () => {
		const rec = new WireAuditRecorder(3);
		for (let i = 0; i < 5; i++) {
			rec.record(auditWireBody({ modelId: `m${i}`, messages: [], turnIndex: i }));
		}
		const list = rec.list();
		expect(list).toHaveLength(3);
		expect(list[0].modelId).toBe("m2"); // oldest kept
		expect(list[2].modelId).toBe("m4"); // newest
	});

	it("clear() empties the buffer", () => {
		const rec = new WireAuditRecorder(3);
		rec.record(auditWireBody({ modelId: "x", messages: [], turnIndex: 0 }));
		rec.clear();
		expect(rec.list()).toHaveLength(0);
	});
});

describe("renderAuditText", () => {
	it("returns a helpful message when the buffer is empty", () => {
		expect(renderAuditText([])).toMatch(/No wire audits/);
	});

	it("renders per-turn breakdown with percentages and total", () => {
		const s = auditWireBody({
			modelId: "kimi-k2.7-code",
			systemPrompt: "x".repeat(400),
			messages: [user("a".repeat(200)), assistant("b".repeat(400)), tool("c1", "c".repeat(8000))],
			turnIndex: 1,
		});
		const text = renderAuditText([s]);
		expect(text).toContain("kimi-k2.7-code");
		expect(text).toContain("system_prompt");
		expect(text).toContain("tool_result blocks");
		expect(text).toContain("Turn 1");
	});

	it("flags tool_results as a hot spot when >50% of total", () => {
		const s = auditWireBody({
			modelId: "test",
			messages: [user("x"), assistant("y"), tool("c1", "z".repeat(10_000))],
			turnIndex: 1,
		});
		const text = renderAuditText([s]);
		expect(text).toContain("🔥 hot spot");
	});

	it("includes the aggressive-mode tip when the biggest waste is tool_results", () => {
		const s = auditWireBody({
			modelId: "test",
			messages: [user("x"), assistant("y"), tool("c1", "z".repeat(10_000))],
			turnIndex: 1,
		});
		const text = renderAuditText([s]);
		expect(text).toContain("aggressive");
		expect(text).toContain("Settings → Modes");
	});

	it("renders multiple snapshots with per-turn averages", () => {
		const s1 = auditWireBody({
			modelId: "test",
			systemPrompt: "x".repeat(400),
			messages: [],
			turnIndex: 1,
		});
		const s2 = auditWireBody({
			modelId: "test",
			systemPrompt: "y".repeat(800),
			messages: [],
			turnIndex: 2,
		});
		const text = renderAuditText([s1, s2]);
		expect(text).toContain("Average per-request:");
		expect(text).toContain("last 2 requests");
	});
});
