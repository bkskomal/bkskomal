// Tests for shrinkOldToolResults — the rolling tool_result truncation
// that powers `contextBudget: "aggressive"` mode.

import type { ConversationMessage } from "@iom/shared";
import { describe, expect, it } from "vitest";
import { shrinkOldToolResults } from "../src/context-shrink";

function assistant(parts: ConversationMessage["parts"]): ConversationMessage {
	return { role: "assistant", parts };
}
function user(text: string): ConversationMessage {
	return { role: "user", parts: [{ kind: "text", text }] };
}
function tool(id: string, output: string): ConversationMessage {
	return { role: "tool", parts: [{ kind: "tool_result", id, output, isError: false }] };
}
function toolCall(id: string, name: string): ConversationMessage["parts"][number] {
	return { kind: "tool_call", id, name, args: {} };
}

// Build a fake history with `nTurns` assistant turns, each followed by a
// tool_call → tool_result with a `bytesPerResult`-sized result payload.
function buildHistory(nTurns: number, bytesPerResult: number): ConversationMessage[] {
	const messages: ConversationMessage[] = [];
	for (let i = 0; i < nTurns; i++) {
		messages.push(user(`turn ${i} request`));
		messages.push(
			assistant([{ kind: "text", text: `turn ${i} response` }, toolCall(`c${i}`, "read_file")]),
		);
		messages.push(tool(`c${i}`, "x".repeat(bytesPerResult)));
	}
	return messages;
}

describe("shrinkOldToolResults", () => {
	it("preserves everything when there are fewer than keepLastTurns assistant messages", () => {
		const history = buildHistory(3, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		expect(result.truncatedCount).toBe(0);
		expect(result.bytesSaved).toBe(0);
		expect(result.messages).toEqual(history);
	});

	it("summarizes tool_results older than keepLastTurns", () => {
		const history = buildHistory(10, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		// 10 turns, keep last 5 → oldest 5 tool_results are summarized
		expect(result.truncatedCount).toBe(5);
		expect(result.bytesSaved).toBeGreaterThan(0);
	});

	it("keeps the last 5 tool_results verbatim", () => {
		const history = buildHistory(10, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		// The last 5 tool messages must still have their full-length output
		const toolMessages = result.messages.filter((m) => m.role === "tool");
		const lastFive = toolMessages.slice(-5);
		for (const m of lastFive) {
			const out = m.parts[0];
			if (out.kind === "tool_result" && typeof out.output === "string") {
				expect(out.output.length).toBe(5000);
			}
		}
	});

	it("preserves tool_call_id linkage — summary is still a valid tool_result", () => {
		const history = buildHistory(10, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		// Every assistant tool_call must still find a matching tool_result
		const toolCallIds = new Set<string>();
		const toolResultIds = new Set<string>();
		for (const m of result.messages) {
			for (const p of m.parts) {
				if (p.kind === "tool_call") toolCallIds.add(p.id);
				if (p.kind === "tool_result") toolResultIds.add(p.id);
			}
		}
		for (const id of toolCallIds) {
			expect(toolResultIds.has(id)).toBe(true);
		}
	});

	it("does NOT touch small tool_results (below minSizeToTruncate)", () => {
		const history = buildHistory(10, 200); // small results
		const result = shrinkOldToolResults(history, { keepLastTurns: 5, minSizeToTruncate: 1000 });
		expect(result.truncatedCount).toBe(0);
	});

	it("does NOT mutate the input history", () => {
		const history = buildHistory(10, 5000);
		const before = JSON.stringify(history);
		shrinkOldToolResults(history, { keepLastTurns: 5 });
		const after = JSON.stringify(history);
		expect(after).toBe(before);
	});

	it("summary marker matches the [iOm shrink: …] convention so users can spot it in scrollback", () => {
		const history = buildHistory(10, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		const firstToolMsg = result.messages.find((m) => m.role === "tool");
		const part = firstToolMsg?.parts[0];
		expect(part?.kind).toBe("tool_result");
		if (part?.kind === "tool_result" && typeof part.output === "string") {
			expect(part.output).toMatch(/^\[iOm shrink: tool_result was/);
			expect(part.output).toContain("Re-invoke the tool");
		}
	});

	it("reports realistic bytesSaved (roughly = old size minus summary size)", () => {
		const history = buildHistory(10, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		// 5 truncated results × ~5000 bytes each = ~25KB; summaries are ~300 bytes each
		expect(result.bytesSaved).toBeGreaterThan(20_000);
		expect(result.bytesSaved).toBeLessThan(26_000);
	});

	it("detects JSON shape and includes it in the summary marker", () => {
		const jsonResult = {
			role: "tool",
			parts: [
				{ kind: "tool_result" as const, id: "c1", output: `${"{".padEnd(2000, "x")}}`, isError: false },
			],
		};
		const history: ConversationMessage[] = [
			user("q1"),
			assistant([toolCall("c1", "get_json")]),
			jsonResult,
			user("q2"),
			assistant([{ kind: "text", text: "r2" }]),
			user("q3"),
			assistant([{ kind: "text", text: "r3" }]),
			user("q4"),
			assistant([{ kind: "text", text: "r4" }]),
			user("q5"),
			assistant([{ kind: "text", text: "r5" }]),
			user("q6"),
			assistant([{ kind: "text", text: "r6" }]),
			user("q7"),
			assistant([{ kind: "text", text: "r7" }]),
		];
		const result = shrinkOldToolResults(history, { keepLastTurns: 5 });
		const tr = result.messages[2].parts[0];
		if (tr.kind === "tool_result" && typeof tr.output === "string") {
			expect(tr.output).toContain("JSON object");
		}
	});

	it("honors a custom keepLastTurns of 1 (only the very last turn stays verbatim)", () => {
		const history = buildHistory(4, 5000);
		const result = shrinkOldToolResults(history, { keepLastTurns: 1 });
		// 4 turns, keep last 1 → 3 truncated
		expect(result.truncatedCount).toBe(3);
	});
});
