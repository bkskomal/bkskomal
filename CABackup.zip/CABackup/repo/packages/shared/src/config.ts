export type ProviderType = "openai-compatible" | "anthropic";

export type ProviderPresetId =
	| "openai-compatible"
	| "openai"
	| "openrouter"
	| "kimi-k2"
	| "kimi-moonshot"
	| "litellm"
	| "unillm"
	| "ollama"
	| "anthropic"
	| "iom-genie"
	| "custom";

export interface ProviderConfig {
	readonly id: string;
	readonly type: ProviderType;
	readonly displayName: string;
	readonly preset: ProviderPresetId;
	readonly baseUrl: string;
	readonly defaultModel: string;
	readonly extraHeaders?: Readonly<Record<string, string>>;
	/**
	 * 2026-06-29: cap on in-flight requests to this provider. When
	 * unset or 0 = unlimited (default; historical behavior). When set,
	 * requests over the cap QUEUE at the iOm side (FIFO) instead of
	 * piling up on the gateway. Purpose: prevent self-inflicted
	 * queue depth on shared-KV-cache gateways when sub-agents fan out
	 * (spawn_agent × 4 × nested → 12+ concurrent streams).
	 *
	 * Suggested values:
	 *  - Small shared gateway (K2.7 Code on 4× H200): 2-4
	 *  - OATI internal vLLM: 3-6
	 *  - Managed APIs (OpenRouter, Anthropic direct): unset (their
	 *    infra handles concurrency; adding a client cap only hurts).
	 */
	readonly maxConcurrentRequests?: number;
}

export interface ModeConfig {
	readonly id: string;
	readonly displayName: string;
	readonly systemPrompt: string;
	readonly enabledTools: readonly string[] | "all";
	readonly providerId?: string;
	readonly modelId?: string;
	readonly enablePlanner: boolean;
	readonly enableCritic: boolean;
	/** Optional dedicated model for planning (e.g. cheap/fast). Defaults to modelId. */
	readonly plannerModelId?: string;
	/** Optional dedicated model for critique. Defaults to modelId. */
	readonly criticModelId?: string;
	/** How many critic-driven retries to allow. Default 1. */
	readonly maxRetries?: number;
	readonly maxParallelAgents: number;
	readonly maxIterations: number;
	readonly temperature?: number;
	/** When true, skip the approval dialog and let tools run without confirmation. */
	readonly autoApprove?: boolean;
	/** Short one-line description shown in the mode picker. */
	readonly description?: string;
	/**
	 * Controls how file edits surface in the editor.
	 * - `auto-apply` (default for autonomous modes): writes go through immediately;
	 *   the user sees the diff in chat but no inline review gate.
	 * - `review`: edits surface as in-editor decorations + Accept/Reject/Modify
	 *   code lenses so the user must opt in per hunk.
	 * When omitted, modes with `autoApprove: true` default to `auto-apply`,
	 * everyone else defaults to `review`.
	 */
	readonly inlineDiffMode?: "auto-apply" | "review";
	/**
	 * What to do when the user sends a chat message while an agent is already
	 * running on this mode.
	 *
	 * - `"queue"` (default): the new message is appended to the in-flight
	 *   agent's input queue and picked up at the next iteration boundary.
	 *   Best for follow-up clarifications to the same task ("also check X").
	 * - `"parallel"`: spawn a sibling agent at the moment of the mid-turn
	 *   send, sharing the same mode + model + history-up-to-now but running
	 *   independently. Best when the second message is a separate task and
	 *   the primary agent should keep working. Requires the active model to
	 *   handle parallel tool-call traffic well (Kimi K2.6 / Claude do; some
	 *   smaller open-weight models do not).
	 */
	readonly midTurnBehavior?: "queue" | "parallel";
	/**
	 * 2026-05-27: per-mode policy for the `ask_user` tool.
	 *
	 * - `"always"` — model can ask clarifying questions; webview shows a chip
	 *   strip and pauses the turn until the user picks an option.
	 * - `"auto-pick-first"` — model'\''s call returns immediately with the
	 *   FIRST option, the chat shows a system note explaining the auto-pick
	 *   + listing the alternatives. Used in auto modes so the model can
	 *   still surface ambiguity without breaking the "run without me" contract.
	 * - `"never"` — the tool refuses to fire and the model gets an error
	 *   ("clarifying questions are disabled for this mode"). Forces the
	 *   model to decide on its own.
	 *
	 * Default: `"always"` for chat/plan/code, `"auto-pick-first"` for
	 * auto / auto-edit modes (set in the built-in mode defaults).
	 */
	readonly allowAskUser?: "always" | "auto-pick-first" | "never";
	/**
	 * 2026-06-29: context-budget policy for throughput-constrained gateways.
	 * Controls how aggressively iOmCode trims the wire body sent to the model.
	 *
	 * - `"aggressive"` — heavy trimming to keep KV cache free on shared
	 *   self-hosted gateways (K2.7 Code on 4× H200, Qwen on OATI vLLM, etc.
	 *   where high concurrency saturates KV cache). Auto-compact at 25%
	 *   instead of 60-80%; tool_results older than 5 turns replaced with
	 *   summary stubs. Typical wire body shrinks 60-80% on turns with big
	 *   prior tool results.
	 * - `"normal"` (default) — the historical behavior: compact at 60-80-90%
	 *   depending on window size, keep tool_results verbatim in history.
	 * - `"generous"` — no client-side trimming beyond what the model window
	 *   forces. For single-shot, high-quality turns where you want the model
	 *   to have every byte of history it's earned.
	 *
	 * Applied per-turn: switching modes mid-session immediately changes the
	 * next request's wire shape (does NOT retroactively rewrite history).
	 * Use `/wire-audit` to see what changed.
	 */
	readonly contextBudget?: "aggressive" | "normal" | "generous";
	/**
	 * 2026-06-29: when true, iOm monitors per-(provider, model) latency
	 * (TTFT + effective TPS) and TEMPORARILY overrides contextBudget to
	 * "aggressive" for the next few turns when the gateway shows signs
	 * of load (median TTFT × 3 exceeded or TPS falls below half of
	 * baseline in 3 of last 5 requests). Reverts to the configured
	 * contextBudget after 3 consecutive healthy requests.
	 *
	 * Off by default. Especially useful on shared-KV-cache gateways
	 * where user concurrency varies across the workday.
	 */
	readonly adaptiveContextBudget?: boolean;
}

export interface McpServerConfig {
	readonly id: string;
	readonly displayName: string;
	/**
	 * 2026-05-25 (Phase 4 polish): transport selector.
	 *   - "stdio" (default): spawn `command` + `args` as a child process,
	 *     speak JSON-RPC over stdio. The marketplace ships ~8 preset
	 *     servers in this mode (Filesystem, Memory, GitHub, etc.).
	 *   - "http": POST JSON-RPC to `url` and receive responses over an
	 *     SSE stream on the same connection. Use for cloud-hosted MCP
	 *     servers or any server not running locally.
	 *
	 * When omitted, the manager defaults to "stdio" so every existing
	 * config keeps working without migration.
	 */
	readonly transport?: "stdio" | "http";
	/** Endpoint URL for HTTP transport. Ignored when transport="stdio". */
	readonly url?: string;
	/** Command for stdio transport. Optional in HTTP mode. */
	readonly command?: string;
	readonly args?: readonly string[];
	readonly env?: Readonly<Record<string, string>>;
	/**
	 * Optional extra HTTP headers (auth tokens, custom routing) sent on
	 * every HTTP-transport POST. Ignored for stdio.
	 */
	readonly headers?: Readonly<Record<string, string>>;
	readonly enabled: boolean;
	/** Approval policy applied to ALL tools from this server. Default "prompt". */
	readonly approval?: "auto" | "prompt" | "deny";
}

/**
 * A user-defined hook that fires at a specific point in the agent lifecycle. The
 * configured `command` is spawned with the event payload streamed in as JSON on
 * stdin; the runner parses stdout as `{allow, reason?, modifiedPayload?}` JSON
 * when possible (otherwise the hook is treated as a passive observer).
 */
export interface HookConfig {
	/** Lifecycle event this hook listens to. */
	readonly event: "PreToolUse" | "PostToolUse" | "UserPromptSubmit" | "SessionStart" | "Stop";
	/**
	 * Optional matcher applied to the event's primary string field (tool name for
	 * ToolUse events, prompt text for UserPromptSubmit). Supports either a plain
	 * substring or a simple glob (`*` and `?`). Omit to match every event.
	 */
	readonly matcher?: string;
	/** Shell command to execute. Run via `child_process.spawn` with `shell: true`. */
	readonly command: string;
	/** Max time the hook is allowed to run, in milliseconds. Defaults to 5000. */
	readonly timeout?: number;
	/**
	 * When true the agent waits for this hook's verdict before proceeding (used
	 * for PreToolUse and UserPromptSubmit guards). PostToolUse / SessionStart /
	 * Stop are fire-and-forget unless `blocking` is set.
	 */
	readonly blocking?: boolean;
}

/**
 * Per-session and per-day cost guardrails. All values are USD. Defaults live
 * in `packages/extension-host/src/budget.ts` (DEFAULT_BUDGET). A workspace
 * `.iom/policy.yaml` may tighten — but never widen — these values.
 */
export interface BudgetConfig {
	/**
	 * 2026-06-06: master switch. When `false`, the entire Budget subsystem
	 * is bypassed — `checkDispatch` always returns "ok", `recordUsage` still
	 * tallies for cost-display purposes but no caps are enforced. Default
	 * `true` (i.e. existing caps apply). Useful when a developer is
	 * intentionally running a high-spend evaluation and doesn't want the
	 * daily / per-session caps in the way.
	 */
	readonly enabled?: boolean;
	/** Soft alert threshold — non-blocking banner. Default $5. */
	readonly perSessionAlertUsd?: number;
	/** When set, dispatch is refused after this is crossed. Default: unset. */
	readonly perSessionHardCapUsd?: number;
	/** Org-wide cap tracked in `.iom/budget-day-YYYYMMDD.json`. Default $50. */
	readonly perDayHardCapUsd?: number;
}

/**
 * 2026-06-29: user-configurable branding. VS Code metadata (extension
 * displayName, activity-bar tooltip, marketplace listing) is baked in
 * at build time from package.json and can't be changed at runtime. But
 * everything the webview renders (chat panel title, welcome screen,
 * status bar, /whoami-style messages) reads from this optional block
 * and can be freely rebranded per-workspace.
 *
 * When any field is omitted, the code falls back to the built-in default
 * ("iOmCode") so the extension is drop-in usable without configuring.
 */
export interface BrandingConfig {
	/** Displayed as the chat panel title, welcome header, etc. Default "iOmCode". */
	readonly displayName?: string;
	/**
	 * Short label shown next to the model picker + status-bar prefix.
	 * Default: same as `displayName`. Useful when displayName is a long
	 * phrase ("My Team's AI Copilot") but you want a compact chip.
	 */
	readonly shortName?: string;
	/** Optional tagline shown on the welcome screen. Default: none. */
	readonly tagline?: string;
}

export interface RootConfig {
	readonly activeProviderId: string;
	readonly activeModeId: string;
	readonly providers: readonly ProviderConfig[];
	readonly modes: readonly ModeConfig[];
	readonly mcpServers?: readonly McpServerConfig[];
	readonly hooks?: readonly HookConfig[];
	/**
	 * 2026-06-29: user-configurable product branding. See BrandingConfig.
	 * When omitted, defaults to the built-in iOmCode branding. Applied
	 * to every runtime-rendered piece of chrome (chat panel title,
	 * welcome, status-bar prefix). Does NOT change VS Code-level
	 * metadata (activity-bar title, marketplace listing) — those are
	 * baked in at package time.
	 */
	readonly branding?: BrandingConfig;
	/** Cost guardrails. Omitted = use defaults. */
	readonly budget?: BudgetConfig;
	/**
	 * When set to `false`, the append-only `.iom/audit.log` is not written.
	 * Default `true`. Useful for tests and short-lived experiments.
	 */
	readonly auditLog?: boolean;
	// R3-B: optional multi-model routing config. When `enabled: false` (or this
	// field is omitted) the agent loop uses the single active provider as
	// before. Defined as an optional field so all existing configs/tests stay
	// valid without a migration.
	readonly routing?: RoutingConfig;
	// R5-E: optional per-(provider, model) cost caps layered on top of the
	// session/day caps in `budget`. Each entry is matched in
	// `Budget.checkPerModelBudget`; the most specific rule wins. Omit to
	// disable per-model gating entirely.
	readonly modelBudgets?: readonly ModelBudget[];
	/**
	 * 2026-05-24: when true, the webview surfaces internal agent
	 * diagnostics — loop-guard error messages, "Recovering from
	 * error…" indicator labels, and tool cards for failed retries
	 * that the dispatcher's auto-recovery already handled. Useful
	 * when debugging the agent loop or a misbehaving model.
	 *
	 * (Sibling: see McpServerConfig.transport — Phase 4 polish adds
	 * HTTP transport for cloud-hosted MCP servers.)
	 *
	 * Default `false`: developers see only the tool calls that
	 * actually mattered to the task and the model's prose. Internal
	 * retry scaffolding stays in the VS Code output channel.
	 *
	 * Surfaced as the "Show internal agent diagnostics (debug)"
	 * checkbox in Settings.
	 */
	readonly verboseInternals?: boolean;
	/**
	 * 2026-05-27: Code-review configuration. When omitted (default), the
	 * `/review` slash command runs with category defaults (Style, Docs,
	 * Correctness, Security all on/advisory). When `enabled: false` the
	 * `/review` command refuses to run.
	 */
	readonly review?: ReviewConfig;
	/**
	 * 2026-05-27: QA-testing configuration. Drives the `/qa` slash-command
	 * suite (plan, unit, edge, regression, coverage, security). When
	 * omitted, sensible defaults apply.
	 */
	readonly qa?: QAConfig;
	/**
	 * 2026-05-27: CI integration. When set, `/ci init` emits a workflow file
	 * for the chosen platform that runs the same checks `/review` and
	 * `/qa coverage` run locally. Omit to leave CI disabled.
	 */
	readonly ci?: CIConfig;
	/**
	 * 2026-05-28: SBOM + vulnerability scanning. Off by default; user must
	 * flip `iom.sbom.enabled` to true (or set this in workspace settings)
	 * to use `/sbom`. Talks to OSV.dev for CVE lookup with optional
	 * fallback to local audit tools.
	 */
	readonly sbom?: SBOMConfig;
}

// 2026-05-27: CI integration.
// `tfs` is for on-prem TFS / Azure DevOps Server check-in workflows:
// same Azure Pipelines YAML format, but tuned for self-hosted agent
// pools (the typical TFS deployment) and `pwsh:` task wrappers (since
// most TFS agents are Windows). Use `azure-pipelines` for cloud Azure
// DevOps with Microsoft-hosted Ubuntu agents.
export type CIPlatform = "github" | "gitlab" | "circleci" | "azure-pipelines" | "tfs";

export interface CIConfig {
	/** Master switch. /ci commands refuse to run when false. Default true. */
	readonly enabled?: boolean;
	/** Which CI platform to target. Default "github". */
	readonly platform?: CIPlatform;
	/** When true, the generated workflow includes a typecheck step. */
	readonly includeTypecheck?: boolean;
	/** When true, includes the lint step (biome / eslint / ruff auto-detected). */
	readonly includeLint?: boolean;
	/** When true, includes a test step using QAConfig.testFramework. */
	readonly includeTests?: boolean;
	/** When true, includes a coverage step that fails below QAConfig thresholds. */
	readonly includeCoverage?: boolean;
	/** Node version for JS / TS workflows. Default "20". */
	readonly nodeVersion?: string;
	/** Python version for pytest workflows. Default "3.12". */
	readonly pythonVersion?: string;
	/**
	 * Agent pool name for TFS / on-prem Azure DevOps Server. Defaults to
	 * "Default" which is the conventional pool name when an admin sets
	 * TFS up. Ignored for cloud platforms (github / gitlab / circleci /
	 * azure-pipelines cloud — which use Microsoft-hosted runners).
	 */
	readonly tfsAgentPool?: string;
	/**
	 * When true, the TFS template includes a comment block explaining how
	 * to enable a gated check-in (build-validates-before-checkin) policy.
	 * Has no runtime effect on the YAML — it's documentation for the
	 * integrator who wires the pipeline to the branch policy.
	 */
	readonly tfsGatedCheckIn?: boolean;
}

// 2026-05-27: Code-review categories. Each has a severity level so users
// can opt into stricter enforcement per category. "off" disables the
// category entirely; "advisory" surfaces findings but doesn't block;
// "blocking" makes /review return non-zero (useful for CI gates).
export type ReviewSeverity = "off" | "advisory" | "blocking";

export interface ReviewConfig {
	/** Master switch. When false, `/review` refuses to run. Default true. */
	readonly enabled?: boolean;
	/** Per-category severity. Omitted categories default to "advisory". */
	readonly categories?: {
		readonly style?: ReviewSeverity; // indentation, naming, line-length, formatting
		readonly documentation?: ReviewSeverity; // function/class docstrings, complex-logic inline comments
		readonly codingStandards?: ReviewSeverity; // project-specific conventions
		readonly correctness?: ReviewSeverity; // off-by-one, null checks, dead code, swallowed errors
		readonly security?: ReviewSeverity; // injection, secrets, weak crypto, auth bypass
		readonly performance?: ReviewSeverity; // O(n²), N+1 queries, sync I/O in async, regex backtrack
		readonly maintainability?: ReviewSeverity; // function length, complexity, nesting, duplication
		readonly testing?: ReviewSeverity; // missing tests, weak assertions, edge-case gaps
		readonly typeSafety?: ReviewSeverity; // any/unknown in public APIs, missing return types
		readonly dependencies?: ReviewSeverity; // new deps necessary? maintained? version-pinned?
		readonly architecture?: ReviewSeverity; // layer violations, circular deps, god files
		readonly accessibility?: ReviewSeverity; // ARIA, keyboard nav, contrast — UI code only
		readonly i18n?: ReviewSeverity; // hardcoded user-facing strings, locale assumptions
		readonly observability?: ReviewSeverity; // logging discipline, error context, metrics
	};
	/** Workspace-relative path to a custom rules file. Read on every /review. */
	readonly customRulesPath?: string;
	/** When true, agent auto-reviews files it itself wrote at turn end. */
	readonly autoReviewModelWrites?: boolean;
	/** When true, auto-reviews files the developer changed externally on next /review. */
	readonly autoReviewDeveloperEdits?: boolean;
	/**
	 * 2026-05-27: when true, every /review run also writes a comprehensive
	 * `.docx` report alongside the chat output. The report includes the
	 * executive summary, severity counts, per-file findings with file +
	 * line numbers, and the suggestedFix diffs.
	 */
	readonly generateWordReport?: boolean;
	/**
	 * Output directory for the Word report. Default `reports/`. Files land
	 * as `reports/code-review-<ISO-timestamp>.docx`.
	 */
	readonly reportOutputDir?: string;
}

// 2026-05-27: QA-testing categories. Same severity-style toggle as Review.
// Most categories produce ARTIFACTS (test files, plans) rather than blocking,
// so "advisory" vs "blocking" matters less here — but the field is kept
// uniform with Review for UI consistency and future CI use.
export type QASeverity = "off" | "advisory" | "blocking";

export interface QAConfig {
	/** Master switch. When false, the `/qa` slash commands refuse to run. */
	readonly enabled?: boolean;
	/** Per-category enablement + severity. */
	readonly categories?: {
		readonly testPlan?: QASeverity; // /qa plan — generates TEST_PLAN.md
		readonly unitTests?: QASeverity; // /qa unit — generates per-function tests
		readonly edgeCases?: QASeverity; // /qa edge — empty / null / max / unicode / etc.
		readonly integration?: QASeverity; // module-to-module + DB / API contract tests
		readonly functional?: QASeverity; // user-story → test-case mapping
		readonly regression?: QASeverity; // /qa regression — failing test from bug description
		readonly coverage?: QASeverity; // /qa coverage — runs report + names gaps
		readonly security?: QASeverity; // OWASP-style adversarial tests
		readonly performance?: QASeverity; // benchmarks + assertions on critical paths
		readonly accessibility?: QASeverity; // axe-core / Lighthouse assertions
		readonly api?: QASeverity; // OpenAPI/Swagger contract tests
		readonly e2e?: QASeverity; // Playwright / Cypress flows
		readonly propertyBased?: QASeverity; // Hypothesis / fast-check generators
		readonly mutation?: QASeverity; // Stryker / mutmut
		readonly visualRegression?: QASeverity; // screenshot diffs
	};
	/** Coverage thresholds. /qa coverage fires if any drops below these. */
	readonly coverageThresholds?: {
		readonly lines?: number; // 0-100, default 80
		readonly branches?: number; // 0-100, default 70
		readonly functions?: number; // 0-100, default 80
	};
	/** When true, generate companion tests automatically as the model writes code. */
	readonly autoGenerateTests?: boolean;
	/** Optional override of the test framework. When omitted, auto-detect. */
	readonly testFramework?: "vitest" | "jest" | "mocha" | "pytest" | "unittest" | "junit" | "auto";
	/**
	 * 2026-05-27: when true, /qa runs also write a comprehensive `.docx`
	 * report. The report includes issues with file + line numbers and
	 * suggestedFix diffs, plus a summary of the generated test artifacts.
	 */
	readonly generateWordReport?: boolean;
	/** Output directory for the report. Default `reports/`. */
	readonly reportOutputDir?: string;
}

// 2026-05-28: SBOM + vulnerability scanning. Mirrors the shape of
// ReviewConfig / QAConfig so the slash-command dispatch and report
// builder can stay consistent across all three subsystems.
export type SBOMSeverity = "off" | "advisory" | "blocking";

export interface SBOMConfig {
	/**
	 * Master switch. When false (the DEFAULT — opt-in), `/sbom` refuses
	 * to run and prints a "open Settings → SBOM to enable" hint. We
	 * default off because the feature talks to OSV.dev over the network
	 * for vuln data; users on locked-down networks should consciously
	 * enable it.
	 */
	readonly enabled?: boolean;
	/** Per-category enablement + severity. */
	readonly categories?: {
		readonly vulnerabilities?: SBOMSeverity; // CVEs from OSV.dev / local audit tools
		readonly outdated?: SBOMSeverity; // dep is N major versions behind latest
		readonly licenses?: SBOMSeverity; // flagged license types (GPL in proprietary, etc.)
	};
	/**
	 * Minimum severity surfaced in the chat summary. The Word report
	 * always includes every finding. "medium" by default — matches how
	 * /review hides off categories from the user-facing output.
	 */
	readonly chatThreshold?: "low" | "medium" | "high" | "critical";
	/**
	 * When true (default), use OSV.dev's /v1/querybatch endpoint for vuln
	 * lookup. When false, skip the network call and only run local audit
	 * tools (npm audit, pip-audit, dotnet list package --vulnerable, …).
	 */
	readonly useOsv?: boolean;
	/**
	 * When true (default), fall back to local audit tools per ecosystem
	 * if OSV.dev is unreachable. Disable to fail fast instead.
	 */
	readonly useLocalFallback?: boolean;
	/**
	 * When true, write a CycloneDX 1.5 JSON SBOM alongside the chat
	 * output. Default true — the JSON is small (a few KB per ecosystem)
	 * and feeds downstream tools (Dependency-Track, GitHub Dependency
	 * Graph, etc.).
	 */
	readonly generateCycloneDX?: boolean;
	/**
	 * When true, every /sbom run also writes a comprehensive `.docx`
	 * report — same shape as /review and /qa reports.
	 */
	readonly generateWordReport?: boolean;
	/** Output directory for both report types. Default `reports/`. */
	readonly reportOutputDir?: string;
	/**
	 * 2026-05-28: auto-fix configuration. When enabled, /sbom will try to
	 * upgrade vulnerable dependencies to a non-vulnerable version
	 * (OSV's reported `fixedIn`). Off by default because the fix version
	 * may introduce breaking changes — most teams want a human in the
	 * loop on dependency bumps even when the CVE is real.
	 *
	 * The actual fix mechanism lands in SBOM commit 2; this commit
	 * defines the schema so downstream code + the Settings UI stay in sync.
	 */
	readonly autoFix?: {
		/**
		 * Master switch. Default false — auto-fix is opt-in.
		 */
		readonly enabled?: boolean;
		/**
		 * Minimum severity that auto-fix will act on. Below this, the
		 * vulnerability is reported but the dependency isn't bumped.
		 * Default "high" — conservative so low-impact CVEs don't trigger
		 * unwanted upgrades.
		 */
		readonly minSeverity?: "low" | "medium" | "high" | "critical";
		/**
		 * When true (default), each auto-fix surfaces an approval prompt
		 * before the manifest is touched. Disable for "fully unattended"
		 * runs — combine with `minSeverity: "critical"` to keep blast
		 * radius small.
		 */
		readonly requireApproval?: boolean;
		/**
		 * What to do when applying the fix:
		 *   - "manifest" (default): rewrite the version string in the
		 *     manifest file (package.json, pyproject.toml, …). User runs
		 *     `npm install` / `pip install` themselves to materialize it.
		 *   - "install": shell out to the ecosystem's package manager to
		 *     install the new version directly. Faster but invokes
		 *     network + arbitrary install scripts.
		 */
		readonly mode?: "manifest" | "install";
	};
}

// R3-B: model router types — appended (do not reorder existing exports).
/**
 * One rule in the model-router decision table. `when` is matched against the
 * router's classification of the upcoming turn (see `ModelRouter.classify`).
 * `model` is optional; when omitted the target provider's `defaultModel` is
 * used so a rule can simply say "route hard turns to the anthropic provider".
 */
export interface RouteRule {
	readonly when: "trivial" | "easy" | "medium" | "hard";
	readonly providerId: string;
	readonly model?: string;
}

/**
 * Routing config block. `rules` is consulted in order — the first rule whose
 * `when` matches the classification wins. `fallback` is the rate-limit /
 * retry sink: when the primary provider returns HTTP 429 the router falls
 * back to this target after one bounded retry.
 */
export interface RoutingConfig {
	readonly enabled: boolean;
	readonly rules: readonly RouteRule[];
	readonly fallback?: { readonly providerId: string; readonly model?: string };
}

export const DEFAULT_CONFIG: RootConfig = {
	activeProviderId: "default",
	activeModeId: "code",
	providers: [
		{
			id: "default",
			type: "openai-compatible",
			displayName: "OpenAI Compatible",
			preset: "openai-compatible",
			baseUrl: "http://localhost:4000/v1",
			defaultModel: "",
		},
		// R3-B: Ollama (local) preset — ships out-of-the-box so users with a
		// running `ollama serve` can pick it from the provider dropdown without
		// having to type the baseUrl by hand. Cost-zero because it runs locally;
		// the pricing table simply has no entry for ollama model ids.
		{
			id: "ollama",
			type: "openai-compatible",
			displayName: "Ollama (local)",
			preset: "ollama",
			baseUrl: "http://localhost:11434/v1",
			defaultModel: "llama3.1:8b",
		},
	],
	modes: [
		{
			id: "ask",
			displayName: "Ask",
			description: "Read-only Q&A — explore the codebase, no edits or shell commands.",
			systemPrompt:
				"You are iOmCode in read-only Q&A mode. Answer questions about the user's project using the read-only tools available to you. Never propose changes to files; if the user asks for changes, suggest switching to Code or Auto Edit mode.",
			enabledTools: ["read_file", "search_files", "workspace_context", "fetch_url"],
			enablePlanner: false,
			enableCritic: false,
			maxParallelAgents: 1,
			maxIterations: 12,
			temperature: 0.2,
		},
		{
			id: "plan",
			displayName: "Plan",
			description: "Read-only investigation — produces a written plan, no edits.",
			systemPrompt:
				"You are iOmCode in planning mode. Investigate the user's project with read-only tools, then produce a clear step-by-step implementation plan. Do not edit files. End with a concise summary of the recommended approach and any open questions.",
			enabledTools: ["read_file", "search_files", "workspace_context", "fetch_url"],
			enablePlanner: true,
			// Critic is off by default — interactive modes follow the Claude/Cline
			// pattern: a single high-quality model output per turn, no separate
			// retry layer. Power users can re-enable it via Settings.
			enableCritic: false,
			maxParallelAgents: 1,
			maxIterations: 16,
			temperature: 0.2,
		},
		{
			id: "code",
			displayName: "Code",
			description: "Edits with approval — you confirm every file write and shell command.",
			systemPrompt:
				"You are iOmCode, a careful agentic coding assistant. Use tools to inspect and modify the user's project. Always preview file changes before writing. You may use `spawn_agent` to delegate self-contained sub-tasks to a fresh sub-agent.",
			enabledTools: "all",
			enablePlanner: false,
			enableCritic: false,
			maxParallelAgents: 4,
			maxIterations: 20,
			temperature: 0.2,
		},
		{
			id: "auto-edit",
			displayName: "Auto Edit",
			description: "Edits auto-approved; agent loops until done. Confirms destructive shell commands.",
			systemPrompt: [
				"You are iOmCode in auto-edit mode.",
				"",
				"## Operating loop",
				"- You run autonomously: keep iterating with tools until the user's task is complete. Do NOT stop after the first turn — verify the change, run tests if relevant, and only finish when the task is actually done or genuinely blocked.",
				"- File edits run without approval prompts. Always preview the change in chat before writing so the user has a trail.",
				"- Destructive shell commands (`rm -rf`, dropping data, `git push --force`, `git reset --hard`, `npm uninstall`, etc.) MUST be explained and confirmed before running.",
				"",
				"## Parallel work",
				"- For independent subtasks (e.g. updating N unrelated files, scanning multiple directories, running a checklist of investigations), use `spawn_parallel_agents` to fan out instead of doing them serially. Each sub-agent gets its own focused task description.",
				"- For a single self-contained sub-task, prefer `spawn_agent`. Reserve `spawn_parallel_agents` for true fanout (2+ truly independent tasks).",
				"",
				"## Recovery",
				"- On a tool error, diagnose the root cause and try a different approach. Don't bail just because one call failed — the loop exists so you can self-correct.",
				"- If you genuinely cannot proceed, summarize what was attempted, what failed, and what the user can do.",
			].join("\n"),
			enabledTools: "all",
			enablePlanner: false,
			// Critic off by default — see comment on Plan mode. Auto-Edit is
			// still interactive (user is watching); critic noise hurt more than
			// it helped during dogfooding.
			enableCritic: false,
			maxParallelAgents: 6,
			maxIterations: 40,
			temperature: 0.2,
			autoApprove: true,
		},
		{
			id: "auto",
			displayName: "Auto",
			description: "Full agentic loop — planner + parallel agents, no approval prompts.",
			systemPrompt: [
				"You are iOmCode in Auto mode — the most aggressive agentic configuration.",
				"",
				"## Operating loop",
				"- You operate autonomously end-to-end. Keep iterating with tools until the user's task is genuinely complete. Don't stop after one round of changes — verify them with reads, tests, builds, or sanity checks as appropriate.",
				"- All edits and shell commands run without approval prompts. With that power, be deliberate: state what you're about to do for anything irreversible (force-pushes, destructive rm, dropping data, deleting branches) BEFORE doing it.",
				"- Self-correct as you go: after writing, read back. After running, check the output. The iteration cap exists so you can verify your own work in the same turn rather than relying on an external critic.",
				"",
				"## Parallel work — first-class strategy",
				"- The instant you identify 2+ independent subtasks, call `spawn_parallel_agents` with a task per sub-agent. Examples that should fan out:",
				"  • Updating N unrelated files with similar refactors (one agent per file).",
				"  • Investigating multiple subsystems in parallel (one agent per area).",
				"  • Running a batch of independent checks (one agent per check).",
				"- For a single sub-task that needs its own context window, use `spawn_agent`.",
				"- Serializing independent work wastes the loop budget — fan out aggressively.",
				"",
				"## Recovery",
				"- Tool errors are signals, not stop conditions. Diagnose and try again with a different approach. The iteration cap is high precisely so you can self-correct.",
				"- If you truly hit a wall, summarize what you tried, what blocked it, and the user's options. Don't fake completion.",
			].join("\n"),
			enabledTools: "all",
			enablePlanner: true,
			// Critic off by default to match Claude / Cline behavior. The
			// iteration cap is high enough that the model can self-correct
			// within a single turn (read back what it wrote, run tests, etc.)
			// without an external critic-retry layer adding noise.
			enableCritic: false,
			maxParallelAgents: 8,
			maxIterations: 80,
			maxRetries: 1,
			temperature: 0.2,
			autoApprove: true,
		},
	],
} as const;

// R5-E: per-model cost budgets — appended at end so all existing exports stay
// stable. A rule with `modelId` omitted applies to every model under
// `providerId`; an explicit `modelId` wins over the provider-only fallback.
// Both `dailyUsd` and `monthlyUsd` may be set on the same rule; either trigger
// blocks dispatch independently.
export interface ModelBudget {
	readonly providerId: string;
	/** Substring match against the resolved model id; omit to apply to every model for `providerId`. */
	readonly modelId?: string;
	/** Hard cap on spend today (UTC). */
	readonly dailyUsd?: number;
	/** Hard cap on month-to-date spend (UTC). */
	readonly monthlyUsd?: number;
}

/**
 * 2026-06-29: canonical fallback for BrandingConfig fields. Consumers
 * everywhere read the branded values via these helpers so a single
 * change here reshapes every runtime chrome surface.
 *
 * Product policy: technical identity is "oati-code" (extension name,
 * publisher scope, npm packages, workspace folder, etc. — see the
 * rebrand map in project memory) but the shipped USER-VISIBLE
 * display defaults to "OATI Code" because that's the company brand
 * users recognize. Any org can override via Settings → Branding.
 */
export const DEFAULT_DISPLAY_NAME = "OATI Code";

export function resolveDisplayName(config: Pick<RootConfig, "branding">): string {
	const v = config.branding?.displayName?.trim();
	return v && v.length > 0 ? v : DEFAULT_DISPLAY_NAME;
}

export function resolveShortName(config: Pick<RootConfig, "branding">): string {
	const short = config.branding?.shortName?.trim();
	if (short && short.length > 0) return short;
	return resolveDisplayName(config);
}

export function resolveTagline(config: Pick<RootConfig, "branding">): string | undefined {
	const t = config.branding?.tagline?.trim();
	return t && t.length > 0 ? t : undefined;
}
