import type { ConversationMessage } from "./agent";
import type { ToolSpec } from "./tools";

export interface TokenUsage {
	readonly inputTokens: number;
	readonly outputTokens: number;
}

export type ProviderStreamEvent =
	| { readonly type: "text_delta"; readonly text: string }
	/**
	 * 2026-06-01: thinking-mode reasoning content (Kimi K2.6 thinking
	 * variants, DeepSeek-R1, GPT-o1, several Qwen reasoning variants).
	 * Separated from `text_delta` so consumers can:
	 *   - accumulate into a ReasoningPart on the assistant history (Moonshot
	 *     requires this round-trip; refuses next turn otherwise with
	 *     "thinking is enabled but reasoning_content is missing"), AND
	 *   - render with a 💭 marker in the UI without conflating with answer text.
	 */
	| { readonly type: "reasoning_delta"; readonly text: string }
	| {
			readonly type: "tool_call";
			readonly id: string;
			readonly name: string;
			readonly args: unknown;
	  }
	| { readonly type: "usage"; readonly usage: TokenUsage }
	| {
			readonly type: "message_end";
			readonly stopReason: "end" | "tool_use" | "max_tokens" | "error";
	  }
	| { readonly type: "error"; readonly message: string };

/**
 * 2026-06-29: optional endpoint-capability override populated by the
 * extension-host's EndpointCapabilityCache after probing a (provider, model)
 * combo. When present, this OVERRIDES the model-quirks `useCompletionsFallback`
 * hint — so a gateway-specific quirk (added defensively for OATI's bare-vLLM)
 * doesn't bleed into managed providers (OpenRouter, DashScope, Together, Fireworks)
 * that DO have chat_templates and don't need the fallback.
 *
 * Set `needsCompletionsFallback: false` to force `/v1/chat/completions`
 * even when the quirk would otherwise pick `/v1/completions`. Set to true
 * to force the fallback (e.g. on a gateway that returns 200 from the probe
 * but later fails on actual streaming). Omit the field to let the quirk decide.
 */
export interface EndpointCapability {
	readonly needsCompletionsFallback: boolean;
}

export interface ProviderRequest {
	readonly messages: readonly ConversationMessage[];
	readonly tools?: readonly ToolSpec[];
	readonly modelId: string;
	readonly systemPrompt?: string;
	readonly maxTokens?: number;
	readonly temperature?: number;
	readonly signal?: AbortSignal;
	readonly endpointCapability?: EndpointCapability;
}

export interface ProviderSpec {
	readonly id: string;
	readonly displayName: string;
	stream(req: ProviderRequest): AsyncIterable<ProviderStreamEvent>;
}
