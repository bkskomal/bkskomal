// R6-A: Structured Plan v2 — the canonical plan schema.
// (Phase 5, 2026-06-04: the legacy freeform `Plan`/`PlanStep` types were
// removed; this file now defines iOmCode's only plan shape.)
//
// The schema is richer than the legacy one: each step carries a stable id,
// a title, a body (with the acceptance criterion folded in), optional
// dependsOn edges for DAG ordering, and a per-step status the executor
// updates as the plan runs. The webview's PlanEditor edits this shape
// in-place; the conductor's planRequest produces it; executePlan walks it
// in topological order; the critic can grade per step.

export type PlanStepStatus = "pending" | "running" | "done" | "skipped" | "failed";

export interface PlanV2Step {
	readonly id: string;
	readonly title: string;
	readonly body: string;
	/** Ids of prerequisite steps; the executor walks the DAG in topological order. */
	readonly dependsOn?: readonly string[];
	readonly status: PlanStepStatus;
	readonly estimatedTokens?: number;
	/** Final result string for the step once it has completed (success or failure). */
	readonly result?: string;
}

// Convenience alias so the spec-canonical name is reachable when the caller
// imports from `@iom/shared/plan` directly. The package barrel exports only
// PlanV2Step to keep `import * from "@iom/shared"` collision-free.
export type { PlanV2Step as PlanStep };

export type PlanV2State = "draft" | "executing" | "completed" | "cancelled";

export interface PlanV2 {
	readonly id: string;
	readonly goal: string;
	readonly steps: readonly PlanV2Step[];
	readonly createdAt: string;
	readonly state: PlanV2State;
}
