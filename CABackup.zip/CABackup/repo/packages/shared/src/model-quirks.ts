/*
 * Model-quirks registry.
 *
 * One canonical place that maps a model-id pattern to its capability
 * fingerprint: recommended temperature, max-tokens, iteration headroom,
 * and which prompt addenda the model needs (explicit tool-format
 * reminders, terseness pushes, etc.).
 *
 * Adding a new model = one entry in `MODEL_QUIRKS`. Every downstream
 * consumer (prompt builder in chat-panel.ts + rpc-handler.ts, provider
 * request shaper, UI status line) reads from `detectModelQuirks()` so we
 * never branch on model id in random places.
 *
 * Primary target right now is Kimi K2.6 — strong open-source coding
 * model that tends to over-narrate; the terseness addendum nudges
 * that. We DELIBERATELY do not lecture the model about the wire format
 * of tool arguments — the OpenAI tool-call protocol is self-describing
 * via the `tools` array we send in the request, and a previous version
 * of this file actively caused the bug it was trying to fix by showing
 * the model a "❌ Wrong" example which the model then dutifully
 * reproduced. See `buildModelPromptAddendum` for the post-mortem.
 */

/**
 * Capability + style profile for a model. Read by:
 *   - chat-panel.ts / rpc-handler.ts when building the system prompt
 *   - conductor.ts / agent.ts when picking max-iterations
 *   - providers/* when capping max-tokens per request
 *   - settings UI when showing per-model recommendations
 *   - Phase 2.1+: tool dispatcher when filtering the toolbelt to the
 *     model's actual capabilities (e.g., small models don't see
 *     `spawn_agent` because they can't coherently track sub-agent
 *     results in their context).
 *
 * The capability flags (Phase 2.1, 2026-05-23) are *defaults*, not
 * laws. The settings UI exposes overrides so a power user can flip
 * `canSpawnSubAgents` on for Gemma if they really want to. Defaults
 * follow the rule "trust capable models; protect users of weaker
 * models from confusing failure modes."
 */
export interface ModelQuirks {
	/** Human-friendly label. Shown in tooltips + the model picker. */
	readonly displayName: string;
	/** Recommended temperature for tool-heavy coding tasks. */
	readonly temperature: number;
	/**
	 * Hard upper bound on max_tokens per *response* (OUTPUT). Plumbed into
	 * every ProviderRequest.maxTokens by agent-core so providers don't
	 * silently truncate to their own tiny defaults (often 4096 or less).
	 */
	readonly maxTokens: number;
	/**
	 * 2026-05-25: total INPUT context window the model supports, in
	 * tokens. Used by agent-core to:
	 *   - Auto-compact history when the assembled request approaches the
	 *     window (~80% of `contextWindow - maxTokens`, leaving headroom
	 *     for the response).
	 *   - Surface a warning in the empty-output diagnostic when we
	 *     suspect the request actually exceeded the model's window.
	 *
	 * Values are the published model limits at time of writing — keep
	 * them current as new model variants ship. Kimi K2.6 = 256K, Claude
	 * Sonnet/Opus 4.x = 200K (use the 1M variant id for the extended
	 * window), GPT-4o = 128K, Gemini 1.5/2.x = 1M.
	 */
	readonly contextWindow: number;
	/** Recommended max iterations for the agent loop. */
	readonly maxIterations: number;
	/**
	 * LEGACY — retained on the interface so existing rows compile, but
	 * `buildModelPromptAddendum` no longer reads it. Past versions used
	 * this to inject an "emit tool args as JSON objects" reminder which
	 * actively confused Kimi K2.6 into reproducing the broken shape it
	 * was warned against. The wire protocol speaks for itself; we don't
	 * need to teach it in prose. Safe to remove in a future cleanup if
	 * nothing else has started consuming it.
	 */
	readonly needsArgFormatReminder: boolean;
	/**
	 * If true, append a "be terse, don't narrate every retry" addendum.
	 * Smaller models love to say "Let me try a different approach…" on
	 * every iteration — the addendum suppresses that boilerplate.
	 */
	readonly needsTersenessReminder: boolean;
	/**
	 * Short note shown in the model picker / settings panel. Sets user
	 * expectations.
	 */
	readonly notes?: string;
	/** Class — informs status-line label and onboarding copy. */
	readonly tier: "frontier" | "open-weight-large" | "open-weight-small" | "local" | "unknown";

	// ─── Phase 2.1 capability flags ──────────────────────────────────
	/**
	 * Can this model usefully drive sub-agents via `spawn_agent` /
	 * `spawn_parallel_agents`? Frontier and most open-weight-large
	 * models pass; small / local models tend to lose track of multiple
	 * concurrent sub-agent results in their context, so we hide the
	 * tool from them by default. User-overridable in settings — this
	 * is a sensible default, not a law.
	 */
	readonly canSpawnSubAgents: boolean;
	/**
	 * Can this model produce a reliable structured plan (PlanV2 JSON)?
	 * Used by Phase 5's plan mode. Most frontier models and reasoning-
	 * tuned open models (DeepSeek R1, Kimi K2.6) pass; small models
	 * struggle to emit well-formed plan JSON consistently.
	 */
	readonly canPlan: boolean;
	/**
	 * Can this model usefully serve as the LLM-as-reranker (Phase 1.3)?
	 * The rerank task is simple (score a list 0–10), so most models
	 * past the tiniest tier can do it. Off for very small / local
	 * models where the scoring noise overwhelms the signal.
	 */
	readonly canRerank: boolean;
	/**
	 * Max concurrent sub-agents this model is allowed to fan out via
	 * `spawn_parallel_agents`. 1 effectively disables parallelism.
	 * Wrapper enforces this regardless of what the model requests —
	 * a confused small model can't fork-bomb the orchestrator.
	 */
	readonly parallelConcurrencyCap: number;
	/**
	 * Hint for which orchestration pipeline this model is strongest in.
	 * Doesn't change behaviour today (Phase 2.1 just records the value);
	 * future Phase 2.x work uses it to pick a default pipeline when the
	 * user has selected "auto" orchestration.
	 *
	 *   - "single"          — vanilla single-agent loop. Safe default.
	 *   - "plan-execute"    — produce a plan first, then execute step
	 *                         by step. Good for strong-reasoning models.
	 *   - "fan-out-collect" — split into parallel sub-agents, collect
	 *                         and synthesize. Reserved for top-tier
	 *                         frontier models with high concurrency caps.
	 */
	readonly preferredPipeline: "single" | "plan-execute" | "fan-out-collect";
	/**
	 * 2026-05-25: how this model best emits tool calls.
	 *
	 *   - "openai-tools" — structured `function.arguments` events via the
	 *     OpenAI streaming protocol's `tools: [...]` array. Default for
	 *     frontier models (Claude, GPT, Gemini) which were trained on
	 *     this format and handle it cleanly.
	 *
	 *   - "inline-xml" — tool descriptions embedded in the system prompt
	 *     as XML examples; the model emits `<tool_name>...</tool_name>`
	 *     blocks in its text response; we parse them out. Default for
	 *     open-weight models (Kimi K2, Qwen, DeepSeek, Gemma, Llama) where
	 *     the OpenAI envelope produces brittle wrapped-args output and
	 *     the model's native format leaks through as text. Mirrors the
	 *     approach Cline uses with the same model class.
	 *
	 * Background: 2026-05-25 trace showed Kimi K2.6 emitting its native
	 * `<|tool_call_begin|>` markers as plain text after the OpenAI
	 * envelope confused it. The structural fix is to stop forcing a
	 * format the model didn't prefer in the first place. See the
	 * inline-xml-format / inline-xml-parser modules in `agent-core/`.
	 */
	readonly toolCallFormat: "openai-tools" | "inline-xml" | "kimi-native";
	/**
	 * 2026-05-26: does this model accept image inputs?
	 *
	 * When the user attaches an image to a chat message we still pack
	 * the wire request with the image_url content block — but if the
	 * model isn't vision-capable, the response comes back silent or
	 * with "I can't see images" hallucinations. We use this flag to
	 * pre-flight the request and surface an actionable error BEFORE
	 * the silent failure, naming a recommended vision-capable model to
	 * switch to.
	 *
	 * Defaults to `false` for the cautious path — the cost of a
	 * false-negative (telling the user a model can't see images when
	 * it actually can) is one extra retry; the cost of a false-positive
	 * (sending images to a text-only model) is the silent failure
	 * we're here to prevent.
	 */
	readonly supportsVision: boolean;
	/**
	 * 2026-06-01: HARD temperature constraint enforced by the upstream
	 * provider. When set, this value OVERRIDES whatever the active mode
	 * config supplies — the user's "I like 0.2 for code" preference loses
	 * to the model's "I literally won't accept anything other than 1"
	 * server-side requirement.
	 *
	 * Distinct from the soft `temperature` default above (which acts as
	 * a recommendation when the mode config doesn't set one). Use this
	 * ONLY when the upstream rejects requests with non-conforming values
	 * (e.g. Kimi K2.6 thinking variants: "invalid temperature: only 1 is
	 * allowed for this model").
	 *
	 * Leave undefined when the model accepts a range — most models do.
	 */
	readonly requiresTemperature?: number;
	/**
	 * 2026-06-05: HARD constraint — when true, the provider OMITS the
	 * `temperature` field from the wire request entirely. Some newer models
	 * (Claude Opus 4.7+, expected to spread to Sonnet/Haiku 4.7+ over time)
	 * reject `temperature` as deprecated:
	 *
	 *   {"type":"invalid_request_error","message":"temperature is deprecated
	 *   for this model."}
	 *
	 * Distinct from `requiresTemperature` (force a specific value) — this
	 * drops the field outright. Mode-config defaults / user preferences are
	 * silently ignored when this is set. Leave undefined for models that
	 * still accept temperature (the vast majority).
	 */
	readonly omitTemperature?: boolean;
	/**
	 * 2026-06-02: is this model a good fit for inline tab-autocomplete?
	 *
	 * Autocomplete demands cheap, sub-second-per-token responses on
	 * short prompts. Frontier reasoning models (K2.6 thinking, GPT-o1)
	 * are way too expensive and slow for keystroke-driven completion —
	 * even when they technically respond correctly. Small dedicated
	 * code models (Codestral, Qwen2.5-Coder, DeepSeek-Coder) are
	 * purpose-built for this and produce better completions per dollar.
	 *
	 * The autocomplete provider uses this flag to:
	 *   - Warn in settings UI when the user picks a non-FIM-capable
	 *     model as their completion model.
	 *   - Auto-suggest FIM-capable models in the completion-model picker.
	 *
	 * Does NOT gate the feature — users can still force any model
	 * via `iom.inlineCompletion.model`. The flag is advisory.
	 *
	 * Defaults to `false` — opt models in explicitly when they're known
	 * good (small + fast + trained on code).
	 */
	readonly fimCapable: boolean;
	/**
	 * 2026-06-16: when set, the provider routes this model to vLLM's
	 * `/v1/completions` endpoint (raw text-in / text-out) instead of
	 * `/v1/chat/completions`. Needed when the gateway is missing a
	 * tokenizer chat_template AND won't accept one sent via the request
	 * body (vLLM refuses with "Chat template is passed with request, but
	 * --trust-request-chat-template is not set" — a deliberate security
	 * guard, not a bug). The completions endpoint sidesteps the entire
	 * chat-template machinery: we render the prompt client-side from the
	 * conversation history, send it as a flat string, and stream the
	 * model's raw text back.
	 *
	 * Setting this implies the provider will also (a) flatten tool roles +
	 * tool_calls into inline text inside the rendered prompt, (b) parse
	 * SSE chunks as text_completion shape (choices[0].text) not chat
	 * completion (choices[0].delta.content), and (c) include the model's
	 * turn-end stop tokens so streaming halts cleanly.
	 *
	 * The shape selector (`promptShape`) picks the turn-marker convention.
	 */
	readonly useCompletionsFallback?: boolean;
	/**
	 * 2026-06-16: when `useCompletionsFallback` is true, this picks the
	 * client-side prompt-rendering convention:
	 *   - "gemma":  <start_of_turn>user / <start_of_turn>model markers
	 *               (system folded into first user turn — Gemma's tokenizer
	 *               historically rejects a top-level system role).
	 *   - "chatml": <|im_start|>{role}\n...\n<|im_end|> blocks
	 *               (Qwen, ChatML-trained open-weight models).
	 *
	 * Implementations live in `@iom/shared/prompt-builders.ts`.
	 */
	readonly promptShape?: "gemma" | "chatml";
}

/**
 * Ordered list — first regex match wins. Patterns are intentionally loose
 * so a versioned id like `moonshotai/kimi-k2-instruct-0925` matches the
 * generic `/kimi.*k2/i` row.
 */
const MODEL_QUIRKS: ReadonlyArray<{ pattern: RegExp; quirks: ModelQuirks }> = [
	// ── PRIMARY: Kimi K2 / K2.6 — open-source workhorse ───────────────
	{
		pattern: /kimi[-_./]?k2/i,
		quirks: {
			displayName: "Kimi K2 / K2.6",
			temperature: 1,
			// 2026-06-01: K2.6 thinking variants (kimi-k2-thinking,
			// kimi-k2-0905-preview with thinking on, default for K2.6 per
			// Moonshot's docs) HARD-REJECT any temperature other than 1
			// with "invalid temperature: only 1 is allowed for this model".
			// requiresTemperature wins over the mode's setting in the
			// agent loop so the user's "0.2 for code" preference doesn't
			// trip the upstream constraint.
			requiresTemperature: 1,
			// Kimi K2.6 supports ~16K output cleanly. The previous 4096 cap
			// silently chopped long edits / multi-file plans mid-response.
			maxTokens: 16384,
			// Kimi K2 / K2.6: 256K-token context window.
			contextWindow: 262144,
			maxIterations: 30,
			needsArgFormatReminder: true,
			needsTersenessReminder: true,
			tier: "open-weight-large",
			notes:
				"Recommended primary model. Strong coding performance per dollar; needs explicit tool-format reminders.",
			// 2026-05-30: Kimi K2.6 is designed for 300-agent swarms and
			// 4,000 coordinated steps in a single run (per Moonshot's
			// release notes). The previous cap of 3 was a defensive
			// holdover from K2.0 and left enormous headroom unused.
			// Raised to 12 — comfortable middle ground that exercises
			// parallelism without overwhelming the 256K context window
			// when many sub-agents return long outputs simultaneously.
			// Users who want to push further can override per-session.
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 12,
			preferredPipeline: "single",
			// 2026-05-25 (revised): Kimi K2.6 ignores the inline-XML format
			// instruction and emits its NATIVE `<|tool_call_begin|>`
			// markers — special tokenizer tokens it was trained on.
			// Public gateways routinely stream those markers through as
			// raw text instead of parsing them. Switching to `kimi-native`
			// activates the dedicated client-side parser
			// (KimiNativeToolParser in agent-core) so the markers convert
			// into structured tool calls before they ever reach the chat.
			// This is the "harness full model power" path — meet the model
			// where it is rather than trying to force a format its
			// training distribution doesn't reach for.
			toolCallFormat: "kimi-native",
			// 2026-05-30 correction: Kimi K2.6 (released April 2026) ships a
			// native 400M-parameter MoonViT vision encoder baked into
			// pretraining — handles images AND video natively. Our previous
			// `supportsVision: false` was carried over from K2 and was
			// actively suppressing the model's real capability.
			//
			// Multimodal content block packing is wired:
			//   - User-attached images → ImagePart → openai-compatible
			//     provider packs as {type: "image_url", image_url: {url}}
			//     (line 639 in openai-compatible.ts).
			//   - Tool-returned images (browser_screenshot's dataUrl) →
			//     collectImageInjections walks results, synthetic user
			//     follow-up message carries the ImagePart (agent.ts).
			//
			// Thinking mode: ON by default per Moonshot's K2.6 spec. Our
			// provider handles `reasoning_content` / `reasoning` deltas
			// (openai-compatible.ts:303) — surfaces as 💭-prefixed text.
			// We never send `tool_choice` (defaults to "auto"), which is
			// what K2.6 requires when thinking is enabled. Per Moonshot
			// docs, the `--reasoning-parser kimi_k2` flag is a server-side
			// vLLM/SGLang concern, not a client-side API setting.
			supportsVision: true,
			// K2.6 is frontier-tier — too slow + expensive for keystroke-
			// driven autocomplete despite being capable. Pick a smaller
			// model (Qwen-Coder, Codestral) for that lane.
			fimCapable: false,
		},
	},
	// ── Qwen 3 Coder ──────────────────────────────────────────────────
	{
		pattern: /qwen[-_./]?3?[-_./]?coder/i,
		quirks: {
			// 2026-06-16: route Qwen 3 Coder through vLLM's /v1/completions
			// (raw text-in / text-out). The OATI internal vLLM gateway has
			// no tokenizer chat_template AND blocks request-side templates
			// via `--trust-request-chat-template`; the completions endpoint
			// is the only path that doesn't require gateway changes.
			//
			// 2026-06-29: this is now a HINT — the extension-host's
			// EndpointCapabilityCache probes /v1/chat/completions on first
			// use and OVERRIDES this when the gateway DOES support chat
			// completions (OpenRouter, DashScope, Together, Fireworks).
			// The hint remains useful for the very first request (probe
			// hasn't run yet) on the OATI bare-vLLM gateway, where it's
			// correct. See packages/extension-host/src/endpoint-capability.ts.
			useCompletionsFallback: true,
			promptShape: "chatml",
			displayName: "Qwen 3 Coder",
			temperature: 0.2,
			// 2026-06-20: cap output at 4K so prompt + output stays comfortably
			// under the OATI gateway's 32K max_model_len. OATI's base prompt
			// is ~17.5K, output 4K leaves ~10K headroom for conversation.
			maxTokens: 4096,
			// 2026-06-20: tracked to the OATI vllm deployment's actual
			// max_model_len (32768). Qwen3-Coder natively supports 256K but
			// the OATI gateway runs it capped — we have to match server
			// reality so auto-compact triggers BEFORE the gateway rejects.
			// Compaction fires at 60% (~20K tokens) which keeps prompt+output
			// safely below the 32K hard ceiling. If the deployment is ever
			// resized, bump this to match.
			contextWindow: 32768,
			maxIterations: 25,
			needsArgFormatReminder: true,
			needsTersenessReminder: true,
			tier: "open-weight-large",
			notes: "Fast, terse, decent tool-following. Comparable to Kimi K2 for most tasks.",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 3,
			preferredPipeline: "single",
			// Same lineage as Kimi K2 — inline-XML matches training distribution.
			toolCallFormat: "inline-xml",
			supportsVision: false,
			// Qwen-Coder is purpose-built for code completion. The smaller
			// variants (7B, 14B) are great fast-lane autocomplete picks.
			fimCapable: true,
		},
	},
	// ── gpt-oss (OpenAI open-weight) ─────────────────────────────────
	// 2026-06-06: served by the OATI Genie internal gateway. 20B and 120B
	// variants; the 120B is the recommended coding model. 128K context per
	// OpenAI's spec. Strong tool-use, well-aligned with OpenAI's function-
	// calling format — use openai-tools, not inline-xml.
	{
		pattern: /gpt[-_./]?oss[-_./]?(20b|120b)?/i,
		quirks: {
			displayName: "gpt-oss",
			temperature: 0.2,
			maxTokens: 8192,
			contextWindow: 131072,
			maxIterations: 25,
			needsArgFormatReminder: false,
			needsTersenessReminder: false,
			tier: "open-weight-large",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 3,
			preferredPipeline: "single",
			// Trained on OpenAI's function-calling format — match the wire
			// shape so the model doesn't have to translate.
			toolCallFormat: "openai-tools",
			supportsVision: false,
			fimCapable: false,
		},
	},
	// ── DeepSeek V4 / V3 ──────────────────────────────────────────────
	{
		pattern: /deepseek[-_./]?(v|coder|chat)/i,
		quirks: {
			displayName: "DeepSeek",
			temperature: 0.2,
			maxTokens: 8192,
			// DeepSeek V3 / R1: 128K context.
			contextWindow: 131072,
			maxIterations: 25,
			needsArgFormatReminder: true,
			needsTersenessReminder: false,
			tier: "open-weight-large",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 3,
			preferredPipeline: "single",
			toolCallFormat: "inline-xml",
			supportsVision: false,
			// DeepSeek-Coder is FIM-trained; DeepSeek-Chat and -R1 less so
			// but the smaller checkpoints still produce decent completions.
			fimCapable: true,
		},
	},
	// ── Gemma 4 — Google's 2026 release, 256K context ─────────────────
	// 2026-06-06: must be matched BEFORE the generic Gemma 2/3 row below —
	// registry uses first-match-wins. Gemma 4 has materially better tool
	// use and structured-output reliability than Gemma 3; it earns the
	// canPlan + canRerank flags the older Gemma row deliberately denies.
	// Still single-agent (parallel sub-agent coordination is unreliable
	// below the 27B variant) so canSpawnSubAgents stays false.
	// 2026-06-16: bumped contextWindow 131072 → 262144 after verifying
	// the OATI gateway (`http://vllm.dev.services.oati.com/gemma_4/v1`)
	// serves `google/gemma-4-26B-A4B` with `max_model_len: 262144`.
	// The Gemma 4 spec sheet supports 256K natively; we were under-
	// reporting it and triggering compaction earlier than necessary.
	{
		pattern: /gemma[-_./]?4/i,
		quirks: {
			// 2026-06-16: route Gemma 4 through vLLM's /v1/completions —
			// the OATI deployment ships without a tokenizer chat_template
			// AND the server rejects request-side templates with
			// "Chat template is passed with request, but
			// --trust-request-chat-template is not set". The completions
			// endpoint takes a raw prompt string, no template machinery.
			useCompletionsFallback: true,
			promptShape: "gemma",
			displayName: "Gemma 4",
			temperature: 0.1,
			// 2026-06-16: capped to 2048 (was 8192). Live dogfooding showed
			// Gemma 4 narrates intent without executing tool calls and
			// then repeats itself — the loop guard catches it but burns
			// 8K of output tokens per stuck turn. A 2K cap bounds the
			// damage so even the worst loop terminates quickly. Real
			// answers fit easily in 2K for Gemma's use cases (Q&A,
			// single-file explanations).
			maxTokens: 2048,
			contextWindow: 262144,
			// 2026-06-16: 25 → 8. Gemma's failure mode is "iterate without
			// converging" — capping iterations early forces the agent
			// loop to wrap up before it spirals.
			maxIterations: 8,
			needsArgFormatReminder: false,
			// 2026-06-16: ON. Gemma's signature failure is narrating
			// "I'll use the X tool" without emitting the XML tags. The
			// terseness addendum nudges it to stop announcing and start
			// acting.
			needsTersenessReminder: true,
			tier: "open-weight-large",
			notes:
				"Best in Ask mode for Q&A, code explanation, and reading-heavy tasks. Not reliable for agentic multi-file edits — tends to narrate intent without emitting tool calls. Use gpt-oss-120b or Kimi K2.6 for autonomous coding.",
			canSpawnSubAgents: false,
			// 2026-06-16: planning/reranking turned OFF. Both require
			// structured-output reliability the model doesn't have on
			// this deployment.
			canPlan: false,
			canRerank: false,
			parallelConcurrencyCap: 1,
			preferredPipeline: "single",
			toolCallFormat: "inline-xml",
			supportsVision: false,
			fimCapable: true,
		},
	},
	// ── Gemma 2 / 3 — lightweight ─────────────────────────────────────
	{
		pattern: /gemma[-_./]?[23]/i,
		quirks: {
			displayName: "Gemma",
			temperature: 0.1,
			maxTokens: 2048,
			// Gemma 2 / 3 generally ship with 8K context (some 128K variants
			// exist but the default Gemma checkpoints are 8K). Conservative
			// since over-reach silently truncates.
			contextWindow: 8192,
			maxIterations: 20,
			needsArgFormatReminder: true,
			needsTersenessReminder: false,
			tier: "open-weight-small",
			notes:
				"Lightweight. Best with a reduced tool surface; complex multi-step tasks may exceed its capability.",
			// Small open-weight: parallel coordination is unreliable, and
			// plan-mode JSON tends to malform. Single-agent loop only.
			canSpawnSubAgents: false,
			canPlan: false,
			canRerank: false,
			parallelConcurrencyCap: 1,
			preferredPipeline: "single",
			toolCallFormat: "inline-xml",
			supportsVision: false,
			// Gemma is small + fast — exactly the autocomplete profile.
			fimCapable: true,
		},
	},
	// ── Mistral / Codestral ───────────────────────────────────────────
	{
		pattern: /mistral|codestral|mixtral/i,
		quirks: {
			displayName: "Mistral / Codestral",
			temperature: 0.2,
			maxTokens: 8192,
			// Mistral Large 2 / Codestral: 128K context.
			contextWindow: 131072,
			maxIterations: 25,
			needsArgFormatReminder: true,
			needsTersenessReminder: false,
			tier: "open-weight-large",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 3,
			preferredPipeline: "single",
			toolCallFormat: "inline-xml",
			supportsVision: false,
			// Codestral is the gold-standard open-weight FIM model — Mistral
			// built it specifically for code completion.
			fimCapable: true,
		},
	},
	// ── Llama 3 / 4 ───────────────────────────────────────────────────
	{
		pattern: /llama[-_./]?[34]/i,
		quirks: {
			displayName: "Llama",
			temperature: 0.2,
			maxTokens: 8192,
			// Llama 3.1/3.3/4: 128K context (Llama 4 Scout/Maverick go higher
			// but require explicit opt-in on most gateways).
			contextWindow: 131072,
			maxIterations: 25,
			needsArgFormatReminder: true,
			needsTersenessReminder: false,
			tier: "open-weight-large",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 3,
			preferredPipeline: "single",
			toolCallFormat: "inline-xml",
			// Llama 3.2-Vision and Llama 4 Maverick have vision variants,
			// but the base Llama 3/4 line is text-only. Conservative default
			// — users on a Vision variant can override via settings (future).
			supportsVision: false,
			// Llama 3/4 base models do FIM reasonably, especially the 8B
			// instruct variants. Not as good as Codestral but workable.
			fimCapable: true,
		},
	},
	// ── Anthropic Claude — newer variants that REJECT `temperature` ───
	// 2026-06-05: Claude Opus 4.7+ treats `temperature` as deprecated and
	// returns HTTP 400 `invalid_request_error` when the field is present.
	// This matcher must come BEFORE the generic Claude matcher so its quirks
	// win — registry uses first-match wins. As Anthropic rolls the same
	// behavior out to Sonnet/Haiku 4.7+, extend the pattern (e.g.
	// `(opus|sonnet|haiku)-4[-_./]?[78]`) rather than adding a new row.
	{
		pattern: /claude[-_./]?(opus)[-_./]?4[-_./]?[78]/i,
		quirks: {
			displayName: "Claude",
			temperature: 0.3, // ignored — kept for shape parity with the generic row
			maxTokens: 16384,
			contextWindow: 200000,
			maxIterations: 20,
			needsArgFormatReminder: false,
			needsTersenessReminder: false,
			tier: "frontier",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 5,
			preferredPipeline: "single",
			toolCallFormat: "openai-tools",
			supportsVision: true,
			fimCapable: false,
			// HARD constraint: drop the temperature field from the wire body.
			omitTemperature: true,
		},
	},
	// ── Anthropic Claude ──────────────────────────────────────────────
	{
		pattern: /claude[-_./]?(opus|sonnet|haiku|3|4|5)/i,
		quirks: {
			displayName: "Claude",
			temperature: 0.3,
			// Claude 4.x routinely emits 16K tokens cleanly on complex edits.
			// Bumped from 8K — the 8K cap was leaving Claude's larger
			// multi-file changes cut off mid-edit.
			maxTokens: 16384,
			// Claude Sonnet/Opus 4.x: 200K context by default. Users who want
			// the 1M variant should use the model id with the `[1m]` suffix —
			// the regex still matches, and gateway routing handles the rest.
			contextWindow: 200000,
			maxIterations: 20,
			needsArgFormatReminder: false,
			needsTersenessReminder: false,
			tier: "frontier",
			// Frontier: full capability set, max parallel.
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 5,
			preferredPipeline: "single",
			// Trained extensively on OpenAI function-calling — best fidelity.
			toolCallFormat: "openai-tools",
			// Claude 3.5+ and 4.x all accept image inputs natively.
			supportsVision: true,
			// Claude is great at completion but expensive — at $3/M+ tokens
			// per keystroke, prefer a cheaper FIM-specialist model for the
			// autocomplete lane.
			fimCapable: false,
		},
	},
	// ── OpenAI GPT family ─────────────────────────────────────────────
	{
		pattern: /gpt[-_./]?[345o]|openai\/o[134]/i,
		quirks: {
			displayName: "GPT",
			temperature: 0.3,
			maxTokens: 16384,
			// GPT-4o / 4.1 / o-series: 128K input.
			contextWindow: 128000,
			maxIterations: 20,
			needsArgFormatReminder: false,
			needsTersenessReminder: false,
			tier: "frontier",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 5,
			preferredPipeline: "single",
			toolCallFormat: "openai-tools",
			// GPT-4o, 4.1, and the o-series all accept image inputs.
			supportsVision: true,
			// GPT-4o-mini is workable for FIM but o1/o3 reasoning variants
			// are terrible for keystroke autocomplete (latency + cost).
			// Conservative default — users can override.
			fimCapable: false,
		},
	},
	// ── Google Gemini ─────────────────────────────────────────────────
	{
		pattern: /gemini[-_./]?[12]/i,
		quirks: {
			displayName: "Gemini",
			temperature: 0.3,
			maxTokens: 8192,
			// Gemini 1.5 Pro / 2.x: 1M token context (some 2M variants exist
			// but require explicit opt-in). The 1M default is already the
			// largest in our roster.
			contextWindow: 1048576,
			maxIterations: 20,
			needsArgFormatReminder: false,
			needsTersenessReminder: false,
			tier: "frontier",
			canSpawnSubAgents: true,
			canPlan: true,
			canRerank: true,
			parallelConcurrencyCap: 5,
			preferredPipeline: "single",
			toolCallFormat: "openai-tools",
			// Gemini 1.5+ is natively multimodal (image + video + audio).
			supportsVision: true,
			// Gemini Pro/Ultra are frontier-tier; cost prohibits keystroke
			// autocomplete. Gemini Flash would be a candidate (smaller +
			// faster) but isn't matched by this generic pattern.
			fimCapable: false,
		},
	},
	// ── Local Ollama models — anything we don't recognise above ──────
	{
		pattern: /:latest$|^ollama\//i,
		quirks: {
			displayName: "Local (Ollama)",
			temperature: 0.2,
			maxTokens: 2048,
			// Local models vary wildly. 8K is the safe lower bound — most
			// quantized 7B-13B builds load with an 8K context by default.
			// Users running larger windows can override per-server in
			// Ollama's `Modelfile` (`PARAMETER num_ctx ...`) and we'll
			// pass through whatever the server actually accepts.
			contextWindow: 8192,
			maxIterations: 20,
			needsArgFormatReminder: true,
			needsTersenessReminder: true,
			tier: "local",
			notes: "Local-only model. Performance varies wildly with the underlying weights.",
			// Local models are usually small / quantized; default to the
			// conservative single-agent path with rerank still allowed
			// (it's a cheap one-shot task most local models can handle).
			canSpawnSubAgents: false,
			canPlan: false,
			canRerank: true,
			parallelConcurrencyCap: 1,
			preferredPipeline: "single",
			// Most local models (Ollama variants) are open-weight derivatives
			// that prefer inline-XML over the OpenAI envelope.
			toolCallFormat: "inline-xml",
			// Most popular local models are text-only. Vision-capable Ollama
			// builds (llava, bakllava, llama3.2-vision) exist but the
			// catch-all defaults to false; the user can override per-model
			// from settings once that surface exists.
			supportsVision: false,
			// Local models are highly variable — could be anything from a
			// 1B nano model to a 70B quantized monster. Default to false
			// (advisory only); users explicitly running a code-specialist
			// locally (e.g. `ollama/qwen2.5-coder:7b`) hit the Qwen-Coder
			// pattern higher up and get fimCapable=true correctly.
			fimCapable: false,
		},
	},
];

const UNKNOWN_DEFAULTS: ModelQuirks = {
	displayName: "Unknown model",
	// Conservative defaults — assume open-weight quirks until proven otherwise.
	temperature: 0.2,
	maxTokens: 4096,
	// Conservative context: 32K matches the smallest modern frontier window
	// (older GPT-4 turbo, several mid-tier Mistral builds). Real frontier
	// models will hit the matched row instead of this fallback.
	contextWindow: 32768,
	maxIterations: 25,
	needsArgFormatReminder: true,
	needsTersenessReminder: true,
	tier: "unknown",
	// Phase 2.1: conservative capability defaults for an unrecognized
	// model. Better to start without parallelism/planning and let the
	// user opt in than to silently hand a weak local model the
	// `spawn_agent` tool and watch it produce confused output.
	canSpawnSubAgents: false,
	canPlan: false,
	canRerank: true,
	parallelConcurrencyCap: 1,
	preferredPipeline: "single",
	// Conservative default for unrecognized models: assume open-weight
	// and prefer inline-XML. Worst case: a frontier model gets inline
	// (still works, just sub-optimal). Better than assuming OpenAI-
	// tools and watching a Kimi-class model produce wrapped-args output.
	toolCallFormat: "inline-xml",
	// Conservative default for unrecognized models: assume text-only so
	// the user gets a clear "model doesn't support images" diagnostic
	// when they attach one. Cost of a false-negative is one settings
	// nudge; cost of a false-positive is a silent empty response.
	supportsVision: false,
	// Unknown models: assume NOT good for autocomplete. The user can
	// explicitly point `iom.inlineCompletion.model` at them anyway —
	// this flag is advisory in the settings UX, not a hard gate.
	fimCapable: false,
};

/**
 * Look up the quirks profile for `modelId`. Falls back to a conservative
 * "assume open-weight" profile when nothing matches — that's the safer
 * default than "assume frontier" because the former just adds a couple
 * of prompt reminders while the latter would let a new small model
 * flounder with no format hints at all.
 *
 * Exposed for unit tests. Pure function — call it freely.
 */
export function detectModelQuirks(modelId: string): ModelQuirks {
	if (!modelId) return UNKNOWN_DEFAULTS;
	for (const row of MODEL_QUIRKS) {
		if (row.pattern.test(modelId)) return row.quirks;
	}
	return UNKNOWN_DEFAULTS;
}

/**
 * Build the model-specific addendum that gets appended to the rendered
 * system prompt.
 *
 * IMPORTANT LESSON LEARNED (do not regress): a previous version of this
 * file included a negative example showing the broken
 * `"{\"path\": \"index.html\"}"` string-of-JSON shape with a "❌ Wrong"
 * label. Kimi K2.6 reliably reproduced that exact pattern in its
 * `arguments` field, looping until the dispatcher's loop guard fired
 * and giving up with "please make the changes manually." LLMs are
 * notoriously sensitive to examples regardless of which side of a
 * Right/Wrong label they sit on — the example IS the instruction. We
 * also previously told the model "the dispatcher will auto-unwrap your
 * mistakes," which gave it no incentive to be correct.
 *
 * Today the OpenAI tool-call protocol (the `tools` array we send in the
 * request body) is self-describing. A 1T-parameter coding model knows
 * the protocol; we do not need to lecture it. The terseness addendum
 * stays because it's a *style* hint that doesn't risk teaching a wire
 * format. The argument-format reminder is intentionally GONE.
 */
export function buildModelPromptAddendum(modelId: string): string {
	const q = detectModelQuirks(modelId);
	const sections: string[] = [];

	if (q.needsTersenessReminder) {
		sections.push(
			[
				"## Style: terse + decisive",
				"",
				'- Don\'t narrate before tool calls. Skip phrases like "Let me try...", "Now I\'ll...", "Let me check the format...". Just call the tool.',
				"- After a tool result, write at most 1–2 short sentences of context. The user reads the tool card directly — your text complements it, doesn't duplicate it.",
				"- If a tool fails, read the error message carefully, change ONE thing, and retry. Don't write a paragraph explaining what you're about to try.",
				"- Save full prose for the final wrap-up (status verdict + next step).",
			].join("\n"),
		);
	}

	return sections.join("\n\n");
}
