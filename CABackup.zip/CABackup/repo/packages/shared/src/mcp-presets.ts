import type { McpServerConfig } from "./config";

export interface McpServerPreset {
	readonly id: string;
	readonly displayName: string;
	readonly description: string;
	/**
	 * Phase 4 polish follow-through (2026-06-04): preset transport. Stdio
	 * presets carry `command` + `args`; HTTP presets carry `url` (and
	 * optionally `headers`). Defaults to stdio when omitted so the
	 * existing presets continue to materialize unchanged.
	 */
	readonly transport?: "stdio" | "http";
	/** Stdio presets: the binary to spawn. */
	readonly command?: string;
	/** Stdio presets: argv. */
	readonly args?: readonly string[];
	/** HTTP presets: the messages endpoint URL. */
	readonly url?: string;
	/** HTTP presets: extra static headers (auth tokens are usually in env vars). */
	readonly headers?: Readonly<Record<string, string>>;
	/** Names of env vars the server needs; user must set these before enabling. */
	readonly requiredEnvVars?: readonly string[];
	readonly approval?: "auto" | "prompt" | "deny";
}

/**
 * Catalog of well-known MCP servers a user can drop in with one click.
 * All from the official @modelcontextprotocol org or its first-party
 * partners. The user still has to install Node (for `npx`) — and supply
 * API keys for servers that need them.
 */
export const MCP_SERVER_PRESETS: readonly McpServerPreset[] = [
	{
		id: "filesystem",
		displayName: "Filesystem",
		description: "Read/write files in specified directories. Pass each allowed directory as an arg.",
		command: "npx",
		args: ["-y", "@modelcontextprotocol/server-filesystem", "."],
		approval: "prompt",
	},
	{
		id: "memory",
		displayName: "Memory (knowledge graph)",
		description:
			"Persist arbitrary facts and recall them across sessions. Useful for long-running projects.",
		command: "npx",
		args: ["-y", "@modelcontextprotocol/server-memory"],
		approval: "auto",
	},
	{
		id: "fetch",
		displayName: "Fetch",
		description:
			"HTTP fetch with content extraction. Returns markdown-ified page text. (Python-based; needs uvx.)",
		command: "uvx",
		args: ["mcp-server-fetch"],
		approval: "prompt",
	},
	{
		id: "sequential-thinking",
		displayName: "Sequential Thinking",
		description: "Structured multi-step reasoning aid. Helps the agent break down complex problems.",
		command: "npx",
		args: ["-y", "@modelcontextprotocol/server-sequential-thinking"],
		approval: "auto",
	},
	{
		id: "github",
		displayName: "GitHub",
		description:
			"Search repos, read issues/PRs, file ops on GitHub. Requires GITHUB_PERSONAL_ACCESS_TOKEN.",
		command: "npx",
		args: ["-y", "@modelcontextprotocol/server-github"],
		requiredEnvVars: ["GITHUB_PERSONAL_ACCESS_TOKEN"],
		approval: "prompt",
	},
	{
		id: "brave-search",
		displayName: "Brave Search",
		description: "Web search via Brave Search API. Requires BRAVE_API_KEY (free tier available).",
		command: "npx",
		args: ["-y", "@modelcontextprotocol/server-brave-search"],
		requiredEnvVars: ["BRAVE_API_KEY"],
		approval: "auto",
	},
	{
		id: "sqlite",
		displayName: "SQLite",
		description:
			"Query and manipulate a local SQLite database. Pass the .db file path as the last arg.",
		command: "uvx",
		args: ["mcp-server-sqlite", "--db-path", "./iom.db"],
		approval: "prompt",
	},
	{
		id: "puppeteer",
		displayName: "Puppeteer (browser)",
		description: "Headless Chromium for screenshots, scraping, and dynamic page interaction.",
		command: "npx",
		args: ["-y", "@modelcontextprotocol/server-puppeteer"],
		approval: "prompt",
	},
];

/** Materialize a preset into a McpServerConfig (disabled by default). */
export function materializePreset(
	preset: McpServerPreset,
	overrides: { id?: string; enabled?: boolean } = {},
): McpServerConfig {
	const id = overrides.id ?? `mcp_${preset.id}_${Date.now().toString(36)}`;
	const enabled = overrides.enabled ?? false;
	const approval = preset.approval ?? "prompt";
	if (preset.transport === "http") {
		return {
			id,
			displayName: preset.displayName,
			transport: "http",
			url: preset.url ?? "",
			...(preset.headers ? { headers: { ...preset.headers } } : {}),
			enabled,
			approval,
		};
	}
	return {
		id,
		displayName: preset.displayName,
		command: preset.command ?? "",
		args: preset.args ? [...preset.args] : [],
		enabled,
		approval,
	};
}

export function getMcpPreset(id: string): McpServerPreset | undefined {
	return MCP_SERVER_PRESETS.find((p) => p.id === id);
}
