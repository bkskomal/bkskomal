import type { AgentEvent } from "./agent";
import type { ProviderConfig, RootConfig } from "./config";
import type { ApprovalRequest, DiffPreview, SemanticSearchHit } from "./host-context";
import type { UiMessage } from "./ui-message";

/** Image attachment carried in a user_message RPC. */
export interface ImageAttachment {
	readonly kind: "image";
	readonly mimeType: string;
	/** A `data:` URL (e.g. `data:image/png;base64,iVBOR...`). */
	readonly dataUrl: string;
}

export type WebviewToHost =
	| { readonly type: "ready" }
	| {
			readonly type: "user_message";
			readonly content: string;
			readonly attachments?: readonly ImageAttachment[];
	  }
	| {
			readonly type: "run_custom_command";
			/** Command name (matches a `customCommands[].name` from the init payload). */
			readonly name: string;
			/** Free-form text the user typed after the command. May be empty. */
			readonly input: string;
	  }
	| { readonly type: "approval_response"; readonly id: string; readonly approved: boolean }
	/** 2026-05-27: response to an `ask_user_request`. `answer` is the chosen option label or free-text. */
	| {
			readonly type: "ask_user_response";
			readonly id: string;
			readonly answer: string;
			readonly other?: boolean;
	  }
	/** 2026-06-29: reply to a batched ask_user_batch_request card. */
	| {
			readonly type: "ask_user_batch_response";
			readonly id: string;
			readonly answer: import("./host-context").AskUserBatchAnswer;
	  }
	/**
	 * 2026-06-29: `/wire-audit` slash command. Host looks up its
	 * WireAuditRecorder ring buffer, renders the per-request breakdown,
	 * and pushes it back as a system-role bubble. Payload is optional
	 * `lastN` to bound how many turns to show (default: all captured).
	 */
	| { readonly type: "request_wire_audit"; readonly lastN?: number }
	| { readonly type: "cancel" }
	| { readonly type: "set_mode"; readonly modeId: string }
	| { readonly type: "get_settings" }
	| { readonly type: "update_settings"; readonly settings: SettingsUpdate }
	| {
			readonly type: "update_api_key";
			readonly providerId: string;
			readonly apiKey: string;
	  }
	| { readonly type: "delete_api_key"; readonly providerId: string }
	| { readonly type: "test_connection"; readonly providerId: string }
	| { readonly type: "clear_session" }
	| { readonly type: "new_session" }
	| {
			/**
			 * Phase 3.2 (2026-05-23): user-initiated rollback of a previous
			 * agent turn. The host calls `AutoRevertGuard.revert(turnId)`
			 * which restores every file the turn wrote (or deletes ones
			 * the turn created) via `vscode.workspace.applyEdit`. The
			 * webview listens for `turn_rollback_complete` to update UI.
			 *
			 * No-op if the turn was committed (succeeded long enough ago
			 * to be cleared) or has no snapshot — the host emits a
			 * completion event with `restored: []`.
			 */
			readonly type: "revert_turn";
			readonly turnId: string;
	  }
	| { readonly type: "pick_attachment" }
	| { readonly type: "split_chat" }
	| { readonly type: "rename_current_session" }
	| { readonly type: "open_file"; readonly path: string }
	| {
			readonly type: "regenerate_from";
			/** UiMessage id of the user turn whose text is being replaced. */
			readonly messageId: string;
			/** New text for the edited user turn. */
			readonly content: string;
	  }
	| { readonly type: "compact_history" }
	| {
			/**
			 * User's choice in response to a `secret_warning` banner.
			 * - "send" — forward the message verbatim (override the safety net)
			 * - "redact" — replace each secret with `[REDACTED:KIND]` and send
			 * - "cancel" — drop the message entirely
			 */
			readonly type: "secret_confirm";
			readonly id: string;
			readonly choice: "send" | "redact" | "cancel";
	  }
	| {
			/** User-triggered "rebuild the semantic-search index". */
			readonly type: "reindex_codebase";
	  }
	// R2-B: background tasks + onboarding tour (appended; do not reorder).
	| {
			/**
			 * User-triggered cancel of a still-running background task (panel
			 * closed mid-run, then re-opened with a "running" row visible).
			 */
			readonly type: "cancel_background_task";
			readonly taskId: string;
	  }
	| {
			/**
			 * Fired once after the user clicks "Got it" or "Skip tour" in the
			 * first-launch onboarding overlay. The webview already persists via
			 * `localStorage`; the host mirrors it into a Memento as a backup so
			 * users who clear webview storage don't see the tour again.
			 */
			readonly type: "onboarding_dismissed";
	  }
	// R2-A: composer (multi-file generation) — APPENDED arms; do not reorder.
	| { readonly type: "open_composer" }
	| {
			/**
			 * Submit a free-form instruction to the multi-file composer. The host
			 * spins up a one-shot agent run that produces N file changes which are
			 * surfaced back via `composer_file_preview` events.
			 */
			readonly type: "composer_submit";
			readonly instruction: string;
			/** Optional list of workspace-relative paths to include as context. */
			readonly contextFiles?: readonly string[];
	  }
	| { readonly type: "composer_accept_file"; readonly path: string }
	| { readonly type: "composer_reject_file"; readonly path: string }
	| { readonly type: "composer_accept_all" }
	| { readonly type: "composer_discard" }
	// R2-E: share session — webview asks the host to export the current
	// session as Markdown via the `iom.exportSessionMarkdown` command. The
	// host owns the save-dialog flow; the webview just signals intent.
	| { readonly type: "share_session_request" }
	// R3-E: /from-issue <url> — webview hands the host a GitHub issue URL;
	// host runs the issue → branch → PR scaffold workflow (gh-workflow.ts).
	| { readonly type: "start_from_issue"; readonly url: string }
	// R3-D: conversation branching — webview asks the host to fork the
	// current session at `atMessageId`. Host clones history up-to-and-including
	// that message, mints a new session id, and opens a fresh chat panel
	// pointed at it. Linkage is persisted via `parentSessionId` +
	// `forkedAtMessageId` on the new session's metadata.
	| { readonly type: "fork_conversation"; readonly atMessageId: string }
	// R3-D: side-by-side compare — webview asks the host to issue two
	// concurrent agent runs against the same instruction with different
	// provider/model overrides. Each side's deltas come back as
	// `compare_chunk` events; terminal status as `compare_done`.
	| {
			readonly type: "compare_request";
			readonly instruction: string;
			readonly left: { readonly providerId: string; readonly model?: string };
			readonly right: { readonly providerId: string; readonly model?: string };
	  }
	// R3-D: side-by-side compare — webview signals it is closing the modal;
	// host cancels any in-flight compare runs.
	| { readonly type: "compare_cancel" }
	// R3-D: pinned messages — webview toggles the `pinned` flag on a
	// UiMessage. Host updates its in-memory copy and persists via SessionStore.
	| { readonly type: "pin_message"; readonly messageId: string; readonly pinned: boolean }
	// R3-D: webview asks for the current pinned-message set + fork metadata
	// after it finishes mounting. The host responds with one
	// `pinned_messages_state` and (when applicable) one `fork_info` event.
	// Keeps `ready` untouched while still letting the webview hydrate its
	// pin rail + forked-from banner on first paint.
	| { readonly type: "request_session_meta" }
	// R3-C: PR review mode. Webview asks the host to run a one-shot PR
	// review pass for a GitHub PR URL. The host parses owner/repo/number,
	// fetches PR metadata + diff via `gh`, and streams an Agent turn back as
	// normal `agent_event`s, bracketed by `pr_review_started` and
	// `pr_review_finished` so the UI can render a status banner.
	| { readonly type: "review_pr_request"; readonly url: string }
	// R4-D: MCP marketplace — request the current curated list with
	// installed/enabled state. Host replies with a `marketplace_state` event.
	| { readonly type: "marketplace_list_request" }
	// R4-D: install (append a disabled McpServerConfig for) a registry entry.
	| { readonly type: "marketplace_install"; readonly id: string }
	// R4-D: uninstall (remove the McpServerConfig and stop the subprocess for)
	// a registry entry.
	| { readonly type: "marketplace_uninstall"; readonly id: string }
	// R4-D: enable/disable an installed marketplace entry. Enabling spawns
	// the subprocess; disabling stops it. This is the action that triggers
	// third-party code execution — the webview is responsible for surfacing
	// the approval-required banner before sending `enabled: true`.
	| {
			readonly type: "marketplace_toggle";
			readonly id: string;
			readonly enabled: boolean;
	  }
	// R4-E: performance HUD — webview asks the host for a snapshot of the
	// last N completed turns + slowest-tool heatmap. `sessionId` is optional
	// because the host already knows which session the panel is bound to;
	// the field is reserved for future multi-session aggregation.
	| { readonly type: "perf_request"; readonly sessionId?: string }
	// R4-C: project templates — webview asks the host for the built-in
	// template catalog. Host replies with one `templates_list` event.
	| { readonly type: "list_templates_request" }
	// R4-C: project templates — webview asks the host to materialize a
	// named template under `targetDir` (defaults to the workspace root).
	// Host replies with a `template_applied` event when done.
	| {
			readonly type: "apply_template_request";
			readonly name: string;
			readonly targetDir?: string;
	  }
	// R4-C: snippet library — webview asks the host for the current snippet
	// catalog under `<workspace>/.iom/snippets/`. Host replies with a
	// single `snippets_list` event.
	| { readonly type: "list_snippets_request" }
	// R4-C: snippet library — webview asks the host to save a snippet.
	// Body defaults to whatever the webview is about to ship (e.g. the
	// previous assistant message). Host replies with `snippet_saved`.
	| {
			readonly type: "save_snippet_request";
			readonly name: string;
			readonly body: string;
			readonly description?: string;
	  }
	// R4-C: snippet library — resolve `@snip:<name>` to its body. The
	// webview keeps the request small (just the name); the host replies
	// with `snippet_body` carrying either the resolved body or an error.
	| { readonly type: "read_snippet_request"; readonly name: string }
	// R5-B: `/knowledge` slash command — webview asks the host for a
	// snapshot of the knowledge base (doc list + rules flag). Host replies
	// with a single `knowledge_state` event carrying the entries.
	| { readonly type: "knowledge_list_request" }
	// R5-C: `/search <query>` — webview asks the host for a semantic
	// search across every past session's messages. Host replies with a
	// single `conversation_search_results` event carrying the top hits.
	| { readonly type: "search_conversations_request"; readonly query: string }
	// R5-D: agent personas — set/clear the active persona for this session.
	// `personaId: null` clears the persona; an unknown id is rejected by the
	// host with a friendly error message rather than silently ignored.
	| { readonly type: "set_persona"; readonly personaId: string | null }
	// R5-D: recipes — webview asks the host for the saved-recipe catalog under
	// `.iom/recipes/*.md`. Host replies with one `recipes_list` event.
	| { readonly type: "list_recipes_request" }
	// R5-D: recipes — webview asks the host to sequence the named recipe's
	// steps as back-to-back agent turns. Progress is fanned out via the
	// `recipe_step_started` / `recipe_step_done` events.
	| { readonly type: "run_recipe"; readonly name: string }
	// R6-B: `@notebook:<path>:<cell-index>` mention — webview asks the host to
	// resolve a notebook cell's source so it can be spliced into the outgoing
	// message before dispatch. Host replies with a single `notebook_cell_body`.
	| {
			readonly type: "read_notebook_cell_request";
			readonly path: string;
			readonly index: number;
	  }
	// R6-A: Structured Plan v2 — webview asks the host to persist an edited
	// plan (drag-reorder, inline title/body edits, add/remove step). The host
	// echoes the canonical state back via `plan_proposed` after validation.
	| { readonly type: "plan_edit"; readonly plan: import("./plan").PlanV2 }
	// R6-A: Structured Plan v2 — webview asks the host to start executing the
	// (already-proposed) plan. The host walks the steps in topological order,
	// emitting `plan_step_status` updates as it goes.
	| { readonly type: "plan_execute"; readonly planId: string }
	// R6-A: Structured Plan v2 — webview cancels an in-flight plan execution.
	| { readonly type: "plan_cancel"; readonly planId: string }
	// R8-E: /hooks slash command — webview asks the host for a snapshot of the
	// currently-registered hook entries (event + matcher + command). Host
	// replies with one `hooks_list` event carrying the list as system content.
	| { readonly type: "list_hooks_request" }
	// R8-E: /skills slash command — webview asks the host for the catalog of
	// available skills under `.iom/skills/*.md`. Host replies with one
	// `skills_list` event.
	| { readonly type: "list_skills_request" }
	// R8-B: `@codebase <query>` first-class mention. Webview asks the host to
	// run a deep semantic search (k=20, rerank if enabled) and reply with
	// `codebase_deep_search_results`. Resolution happens host-side because the
	// embedder may need an API key from `vscode.SecretStorage`.
	| { readonly type: "codebase_deep_search_request"; readonly query: string }
	// Background-task tray actions.
	| { readonly type: "background_tasks_list_request" }
	| { readonly type: "background_task_cancel"; readonly id: string }
	// Session checkpoints (/checkpoint, /restore).
	| { readonly type: "checkpoint_create"; readonly label?: string }
	| { readonly type: "checkpoint_list_request" }
	| { readonly type: "checkpoint_restore"; readonly id: string }
	| { readonly type: "checkpoint_delete"; readonly id: string }
	// Conversation export (/export — markdown by default; PDF via skill).
	| { readonly type: "export_conversation"; readonly format: "markdown" | "pdf" }
	// Generic "run a VS Code command" passthrough. The webview can't trigger
	// editor commands directly (sandboxed) so this lets slash commands like
	// `/inline` flip toggles via `vscode.commands.executeCommand`. The host
	// allow-lists the prefix so the webview can't fire arbitrary commands.
	| {
			readonly type: "run_vscode_command";
			readonly command: string;
			readonly args?: readonly unknown[];
	  }
	// Background supervisor actions.
	| { readonly type: "supervisor_dismiss"; readonly id: string }
	| { readonly type: "supervisor_clear" }
	| { readonly type: "supervisor_run_now" }
	// `/cwd <path>` slash command — change the project root that
	// relative-path tools resolve against. The host validates the path,
	// updates its workspaceRoot, and broadcasts a `workspace_info` event
	// so the project chip reflects the new folder.
	| { readonly type: "set_workspace_root"; readonly path: string }
	// 2026-05-29: user clicked "Save" on a post-turn memory suggestion.
	// Host calls addFact(workspaceRoot, { fact, source: "agent-suggested" })
	// then broadcasts a fresh facts list (via init/settings ping).
	| { readonly type: "memory_save_suggestion"; readonly fact: string }
	// 2026-05-29: user clicked "Dismiss" on the suggestions panel. No
	// persistence; we just need the host to drop its in-memory state so
	// the next `memory_suggestions` broadcast lands cleanly.
	| { readonly type: "memory_dismiss_suggestions" };

/** Summary of a single detected secret, sent to the webview for display. */
export interface SecretMatchSummary {
	readonly kind: string;
	readonly preview: string;
}

export interface SettingsUpdate {
	readonly activeProviderId?: string;
	readonly activeModeId?: string;
	readonly providers?: readonly ProviderConfig[];
	readonly modes?: readonly import("./config").ModeConfig[];
	readonly mcpServers?: readonly import("./config").McpServerConfig[];
	readonly hooks?: readonly import("./config").HookConfig[];
	/**
	 * 2026-05-24: root-level diagnostics toggle. When the webview
	 * flips the "Show internal agent diagnostics" checkbox, this is
	 * what gets sent up. The host persists it as `RootConfig.verboseInternals`.
	 */
	readonly verboseInternals?: boolean;
	/** 2026-05-27: code-review configuration. See ReviewConfig in config.ts. */
	readonly review?: import("./config").ReviewConfig;
	/** 2026-05-27: QA-testing configuration. See QAConfig in config.ts. */
	readonly qa?: import("./config").QAConfig;
	/** 2026-05-27: CI integration configuration. See CIConfig in config.ts. */
	readonly ci?: import("./config").CIConfig;
	/** 2026-05-28: SBOM + vulnerability scanning configuration. See SBOMConfig in config.ts. */
	readonly sbom?: import("./config").SBOMConfig;
	/**
	 * 2026-06-06: cost guardrails — per-session alert/cap and per-day org cap.
	 * Edited via the Budget Guardrails section in Settings. Setting any value
	 * to `null` clears it (back to the DEFAULT_BUDGET value); omitting the
	 * whole field leaves the prior config untouched.
	 */
	readonly budget?: import("./config").BudgetConfig;
}

export interface ModeSummary {
	readonly id: string;
	readonly displayName: string;
	readonly description?: string;
	readonly autoApprove?: boolean;
	readonly enablePlanner?: boolean;
	readonly enableCritic?: boolean;
}

export interface SettingsSnapshot {
	readonly config: RootConfig;
	readonly hasApiKey: Readonly<Record<string, boolean>>;
}

export type UiView = "chat" | "settings";

/** Summary of a user-defined slash command, sent to the webview at init time. */
export interface CustomCommandSummary {
	readonly name: string;
	readonly description: string;
	/**
	 * Phase 4 polish follow-through (2026-06-04): optional metadata from
	 * the command file's YAML frontmatter — shown in the slash popover so
	 * users can scan visually instead of reading every description.
	 */
	readonly icon?: string;
	readonly category?: string;
	readonly aliases?: readonly string[];
}

export type HostToWebview =
	| {
			readonly type: "init";
			readonly modes: readonly ModeSummary[];
			readonly activeModeId: string;
			readonly sessionId: string;
			readonly workspaceFiles: readonly string[];
			/**
			 * User-defined slash commands loaded from `<workspace>/.iom/commands/*.md`.
			 * Omitted when there are no custom commands. The webview merges these with
			 * its built-in commands so they appear in the autocomplete dropdown.
			 */
			readonly customCommands?: readonly CustomCommandSummary[];
	  }
	| { readonly type: "agent_event"; readonly event: AgentEvent }
	| {
			/**
			 * 2026-05-26: per-turn list of files the agent created or modified.
			 * Sent after the turn completes (regardless of success or
			 * failure). Webview attaches the list to the LAST assistant
			 * message that carries the matching turnId so a "Changed files"
			 * chip strip renders inside that bubble.
			 */
			readonly type: "turn_files_changed";
			readonly turnId: string;
			readonly files: readonly {
				readonly path: string;
				readonly kind: "new" | "modified";
			}[];
	  }
	| { readonly type: "approval_request"; readonly request: ApprovalRequest }
	/** 2026-05-27: ask-user clarifying-question prompt. Webview shows option chips; the user'\''s pick comes back as `ask_user_response`. */
	| { readonly type: "ask_user_request"; readonly request: import("./host-context").AskUserRequest }
	/** 2026-06-29: batched clarifying-question card. Reply comes back as `ask_user_batch_response`. */
	| {
			readonly type: "ask_user_batch_request";
			readonly request: import("./host-context").AskUserBatchRequest;
	  }
	/**
	 * 2026-06-29: concurrency-limiter status for the composer chip.
	 * Fired when a provider request has to queue behind others and again
	 * when it acquires a slot. The webview shows a small "⏳ waiting for
	 * slot (2 ahead)" chip next to the working indicator; clears on
	 * "started".
	 */
	| {
			readonly type: "provider_queue_status";
			readonly providerId: string;
			readonly state: "queued" | "started";
			readonly queueDepth?: number;
			readonly waitedMs?: number;
	  }
	| { readonly type: "diff_preview"; readonly diff: DiffPreview }
	| { readonly type: "settings"; readonly snapshot: SettingsSnapshot }
	| { readonly type: "show_view"; readonly view: UiView }
	| { readonly type: "restore_session"; readonly messages: readonly UiMessage[] }
	| {
			readonly type: "attachment_ready";
			readonly name: string;
			readonly path: string;
			readonly language?: string;
			readonly text: string;
			readonly truncated: boolean;
	  }
	| {
			/**
			 * "Send selection to chat" — a snippet of code from an editor selection
			 * to be displayed as a banner above the composer and prepended (quoted)
			 * to the next user message with file:line attribution.
			 */
			readonly type: "attach_selection";
			readonly path: string;
			readonly language?: string;
			readonly text: string;
			readonly startLine: number;
			readonly endLine: number;
	  }
	| { readonly type: "prefill_prompt"; readonly text: string }
	| {
			readonly type: "connection_test_result";
			readonly providerId: string;
			readonly ok: boolean;
			readonly message?: string;
	  }
	| {
			/**
			 * Outbound secret-scanner warning. The webview shows a modal-style
			 * banner with three buttons (Send anyway / Redact and send / Cancel)
			 * and replies via the `secret_confirm` RPC. Default action is
			 * "redact" — see the chat-panel for the auto-confirm timeout.
			 */
			readonly type: "secret_warning";
			readonly id: string;
			readonly summary: string;
			readonly matches: readonly SecretMatchSummary[];
	  }
	| {
			/**
			 * Codebase-indexing progress, streamed while a full reindex is running.
			 * `done === total` (and a falsy `file`) marks the terminal event.
			 * `chunks` is populated only on the terminal event so the webview can
			 * report a final "indexed N files (M chunks)" message.
			 */
			readonly type: "indexing_progress";
			readonly done: number;
			readonly total: number;
			readonly file?: string;
			readonly chunks?: number;
			readonly done_indexing?: boolean;
	  }
	| { readonly type: "error"; readonly message: string }
	// R2-B: background tasks (appended; do not reorder).
	| {
			/**
			 * A background task was launched (either explicitly via the
			 * `start_background_task` tool, or implicitly when the user closed
			 * the panel while a normal run was still active). The webview shows
			 * a small "running task" chip with a cancel control.
			 */
			readonly type: "background_task_started";
			readonly taskId: string;
			readonly label: string;
	  }
	| {
			/** Streaming progress chunk (text deltas, tool result previews, etc.). */
			readonly type: "background_task_progress";
			readonly taskId: string;
			readonly chunk: string;
	  }
	| {
			/** Terminal event for a background task. */
			readonly type: "background_task_completed";
			readonly taskId: string;
			readonly status: "completed" | "cancelled" | "error" | "interrupted";
			readonly summary: string;
	  }
	// R2-A: composer (multi-file generation) — APPENDED arms; do not reorder.
	| { readonly type: "composer_started" }
	| {
			/** One per file the model proposed. Emitted incrementally as parsed. */
			readonly type: "composer_file_preview";
			readonly path: string;
			readonly before: string;
			readonly after: string;
			readonly language?: string;
	  }
	| {
			readonly type: "composer_done";
			readonly status: "ok" | "cancelled" | "error";
			readonly message?: string;
	  }
	| {
			/** Paths that were actually written to disk during commit. */
			readonly type: "composer_applied";
			readonly paths: readonly string[];
	  }
	// R3-B: model router decision banner. Emitted at most once per user
	// turn, immediately before the agent run starts, ONLY when the router
	// picked a non-default provider/model. The webview renders a small
	// "via providerId:model" badge attached to the upcoming user turn so
	// the user can see WHY a different model is suddenly answering.
	| {
			readonly type: "route_decision";
			readonly providerId: string;
			readonly model?: string;
			/** Optional ui-message id or taskId this decision belongs to. */
			readonly msgId?: string;
			readonly taskId?: string;
			/** Short human-readable reason, e.g. "matched rule when=hard". */
			readonly reason?: string;
	  }
	// R3-D: side-by-side compare — streaming chunk from one side of a
	// `compare_request`. `side` is "left" or "right"; chunks are appended to
	// the corresponding column in the compare-view modal.
	| {
			readonly type: "compare_chunk";
			readonly side: "left" | "right";
			readonly chunk: string;
	  }
	// R3-D: side-by-side compare — terminal event for one side of a
	// `compare_request`. The webview keeps the modal open until BOTH sides
	// report done (or the user closes it).
	| {
			readonly type: "compare_done";
			readonly side: "left" | "right";
			readonly status: "ok" | "error";
			readonly message?: string;
	  }
	// R3-D: pinned messages — sent right after `restore_session` so the
	// webview can decorate the matching UiMessages with `pinned: true`. Also
	// sent any time the pinned set changes server-side (currently only via
	// `pin_message` from the same webview, but the round-trip keeps the
	// signal flowing one direction and the persistence honest).
	| {
			readonly type: "pinned_messages_state";
			readonly pinnedIds: readonly string[];
	  }
	// R3-D: conversation branching — surface the parent linkage so the
	// webview can render a "Forked from X at message Y" banner. Sent once on
	// `ready` for forked sessions; omitted otherwise.
	| {
			readonly type: "fork_info";
			readonly parentSessionId: string;
			readonly forkedAtMessageId: string;
			readonly parentTitle?: string;
	  }
	// R3-C: PR review lifecycle. Bookend `pr_review_started` /
	// `pr_review_finished` events bracket a normal agent turn streamed back
	// via the usual `agent_event` channel; the webview uses them only to show
	// a status banner ("Reviewing PR #N…" / "Review complete") without
	// inventing a new chat surface.
	| {
			readonly type: "pr_review_started";
			readonly url: string;
			readonly number: number;
			readonly owner: string;
			readonly repo: string;
			readonly title?: string;
	  }
	| {
			readonly type: "pr_review_finished";
			readonly url: string;
			readonly status: "ok" | "error" | "cancelled";
			readonly summary?: string;
			readonly message?: string;
	  }
	// R3-C: architecture diagram (mermaid). The `render_diagram` tool emits
	// this event as a side-effect; the webview renders the mermaid source
	// inline using the `mermaid` npm package (lazy-loaded).
	| {
			readonly type: "diagram_render";
			readonly id: string;
			readonly mermaid: string;
			readonly title?: string;
	  }
	// R4-B: diagnostics pill — rolling tally of workspace-wide LSP diagnostics
	// (errors + warnings). Broadcast to every open ChatPanel on a debounced
	// `vscode.languages.onDidChangeDiagnostics` event so the header pill can
	// surface the count without each webview maintaining its own subscription.
	| {
			readonly type: "diagnostics_count";
			readonly errors: number;
			readonly warnings: number;
	  }
	// R4-D: MCP marketplace state — emitted in response to a
	// `marketplace_list_request` and after any install / uninstall / toggle
	// so the webview can re-render without polling. Each item carries the
	// curated metadata plus the live installed/enabled flags computed from
	// the user's persisted `mcpServers` list.
	| {
			readonly type: "marketplace_state";
			readonly items: readonly {
				readonly id: string;
				readonly displayName: string;
				readonly description: string;
				readonly category: "filesystem" | "git" | "search" | "ai" | "database" | "misc";
				readonly installed: boolean;
				readonly enabled: boolean;
				readonly homepage?: string;
			}[];
	  }
	// R4-D: explicit "open the marketplace overlay" signal — triggered by the
	// `iom.openMarketplace` VS Code command. The `/marketplace` slash command
	// flips the overlay locally without needing this event.
	| { readonly type: "marketplace_open" }
	// R4-E: performance HUD snapshot — reply to `perf_request`. `turns` is
	// newest-first (last 20 turns by default); `heatmap` is sorted by p95
	// desc across the last 100 tool invocations in the session.
	| {
			readonly type: "perf_snapshot";
			readonly turns: readonly {
				readonly msgId: string;
				readonly durationMs: number;
				readonly toolCalls: number;
				readonly inputTokens: number;
				readonly outputTokens: number;
				readonly cost: number;
			}[];
			readonly heatmap: readonly {
				readonly tool: string;
				readonly count: number;
				readonly p50Ms: number;
				readonly p95Ms: number;
				readonly errorRate: number;
			}[];
	  }
	// R4-C: project templates — reply to `list_templates_request` with the
	// catalog of built-in templates so the webview can render a picker.
	| {
			readonly type: "templates_list";
			readonly items: readonly { readonly name: string; readonly description: string }[];
	  }
	// R4-C: project templates — reply to `apply_template_request` after the
	// template has been materialized. `created`/`skipped` lists are paths
	// relative to the target directory.
	| {
			readonly type: "template_applied";
			readonly name: string;
			readonly created: readonly string[];
			readonly skipped: readonly string[];
	  }
	// R4-C: snippet library — reply to `list_snippets_request`.
	| {
			readonly type: "snippets_list";
			readonly items: readonly { readonly name: string; readonly description: string }[];
	  }
	// R4-C: snippet library — reply to `save_snippet_request`. `ok=false`
	// when persistence failed; `message` carries a short reason.
	| {
			readonly type: "snippet_saved";
			readonly name: string;
			readonly ok: boolean;
			readonly message?: string;
	  }
	// R4-C: snippet library — reply to `read_snippet_request`. `body` is
	// undefined when the snippet doesn't exist; `message` carries the
	// resolution error in that case.
	| {
			readonly type: "snippet_body";
			readonly name: string;
			readonly body?: string;
			readonly message?: string;
	  }
	// R5-B: knowledge base / AI rules state — host broadcasts after the
	// KnowledgeStore rebuilds and on activation so the webview can show a
	// tiny header indicator (`📚 N` when docs > 0, `📜 rules` when
	// `.iom/rules.md` is present). Both flags are decoupled — either can
	// be true on its own.
	| {
			readonly type: "knowledge_state";
			readonly docs: number;
			readonly rulesActive: boolean;
			/**
			 * Optional list of indexed knowledge docs (path + title + updatedAt).
			 * Populated when the host snapshots in response to `/knowledge`; the
			 * routine activation broadcast omits it to keep messages small.
			 */
			readonly entries?: readonly {
				readonly path: string;
				readonly title: string;
				readonly updatedAt: string;
			}[];
	  }
	// R5-C: conversation search — reply to `search_conversations_request`.
	// `items` is empty when no matches were found; the webview renders a
	// single system message either way so the user always gets feedback.
	| {
			readonly type: "conversation_search_results";
			readonly query: string;
			readonly items: readonly {
				readonly sessionId: string;
				readonly messageId: string;
				readonly role: string;
				readonly snippet: string;
				readonly createdAt: string;
			}[];
	  }
	// R5-D: persona catalog + active selection. Emitted once on `ready` so
	// the webview can render the persona chip + picker, and again any time
	// the active persona changes (via `/persona`, the `set_persona` RPC, or
	// the `set_persona` tool).
	| {
			readonly type: "personas_list";
			readonly items: readonly {
				readonly id: string;
				readonly displayName: string;
				readonly description: string;
			}[];
			readonly activeId: string | null;
	  }
	// R5-D: recipes — reply to `list_recipes_request`. Items are sorted by
	// name; empty when `.iom/recipes/` does not exist or contains no valid
	// recipes.
	| {
			readonly type: "recipes_list";
			readonly items: readonly { readonly name: string; readonly description: string }[];
	  }
	// R5-D: recipes — progress bookends for a `run_recipe` flow. Both events
	// carry `index` (0-based) and `total` so the webview can render a
	// "step 2/4: …" indicator without keeping its own counter.
	| {
			readonly type: "recipe_step_started";
			readonly name: string;
			readonly index: number;
			readonly total: number;
			readonly text: string;
	  }
	| {
			readonly type: "recipe_step_done";
			readonly name: string;
			readonly index: number;
			readonly total: number;
			readonly ok: boolean;
			readonly message?: string;
	  }
	// R5-E: offline-mode badge — host broadcasts whenever the set of
	// configured providers changes. `offline` is true when every configured
	// provider preset is local (currently only `ollama`); `localProviders` is
	// the list of provider ids contributing to that verdict so the webview
	// can render a tooltip ("Local providers: ollama, ...").
	| {
			readonly type: "offline_mode";
			readonly offline: boolean;
			readonly localProviders: readonly string[];
	  }
	// R6-B: `@notebook:<path>:<cell-index>` mention — reply to
	// `read_notebook_cell_request`. `body` is undefined when the cell can't
	// be resolved (missing file, out-of-range index, etc.); `message` carries
	// a short reason for the webview to surface inline.
	| {
			readonly type: "notebook_cell_body";
			readonly path: string;
			readonly index: number;
			readonly body?: string;
			readonly message?: string;
	  }
	// R6-A: Structured Plan v2 — emitted once after the planner produces (or
	// the user persists an edit to) a PlanV2. The webview opens the plan
	// editor side panel and renders the steps.
	| { readonly type: "plan_proposed"; readonly plan: import("./plan").PlanV2 }
	// R6-A: Structured Plan v2 — per-step status update during execution. The
	// host fans these out as the conductor advances through the plan; the
	// webview updates the matching step in its local copy.
	| {
			readonly type: "plan_step_status";
			readonly planId: string;
			readonly stepId: string;
			readonly status: import("./plan").PlanStepStatus;
			readonly result?: string;
	  }
	// R6-A: Structured Plan v2 — terminal event for a plan execution. Status
	// is "completed" when every required step finished successfully (skipped
	// counts as success); "cancelled" when the user pressed Cancel; "failed"
	// when a step failed and continueOnFailure was off.
	| {
			readonly type: "plan_completed";
			readonly planId: string;
			readonly status: "completed" | "cancelled" | "failed";
	  }
	// R6-E: debug session pill — host broadcasts on debug session
	// start/terminate and on DAP `stopped`/`continued` events. `active`
	// reflects whether `vscode.debug.activeDebugSession` is non-null;
	// `type` mirrors the session's `type` field (e.g. "python", "node");
	// `stoppedThreadId` is populated only while the session is paused on a
	// breakpoint or step.
	| {
			readonly type: "debug_session_state";
			readonly active: boolean;
			readonly sessionType?: string;
			readonly sessionName?: string;
			readonly stoppedThreadId?: number;
	  }
	// R6-D: streaming composer preview. Emitted incrementally by the host as
	// it parses partial JSON from the model — "writing" while content is
	// still accumulating, "complete" once a closing quote arrives. The
	// composer-panel renders writing-state files as placeholders.
	| {
			readonly type: "streaming_diff_partial";
			readonly path: string;
			readonly content: string;
			readonly status: "writing" | "complete";
	  }
	// R6-D: multi-file diff overlay — opens a polished modal with file-tree
	// rail + side-by-side hunk view. Triggered by `/diff` against the most
	// recent composer state. Files carry their pre- and post-images so the
	// overlay can render hunks without a round-trip.
	| {
			readonly type: "multi_file_diff_open";
			readonly files: readonly {
				readonly path: string;
				readonly before: string;
				readonly after: string;
			}[];
	  }
	// R8-E: /hooks listing — reply to `list_hooks_request`. `entries` is one
	// row per registered hook in v2 form; `source` tells the webview whether
	// the rows came from `.iom/hooks.json`, the legacy `RootConfig.hooks`
	// migration shim, or the empty fallback.
	| {
			readonly type: "hooks_list";
			readonly source: "file" | "legacy" | "empty";
			readonly entries: readonly {
				readonly event: string;
				readonly matcher?: string;
				readonly command: string;
				readonly blockOnFailure?: boolean;
				readonly timeout?: number;
			}[];
	  }
	// R8-E: /skills listing — reply to `list_skills_request`. Items are
	// sorted by name; empty when `.iom/skills/` does not exist or contains no
	// valid skills.
	| {
			readonly type: "skills_list";
			readonly items: readonly {
				readonly name: string;
				readonly description: string;
				readonly triggers: readonly string[];
				readonly tools: readonly string[];
			}[];
	  }
	// R8-B: reply to `codebase_deep_search_request`. `hits` is empty when no
	// matches were found OR when the index is empty (the webview emits a
	// "no matches" system message either way). Each hit is the
	// SemanticSearchHit shape returned by `CodebaseIndex.query`.
	| {
			readonly type: "codebase_deep_search_results";
			readonly query: string;
			readonly hits: readonly SemanticSearchHit[];
			readonly embedder?: { readonly id: string; readonly dimensions: number };
			readonly reranked?: boolean;
	  }
	// R8-B: embedder identity broadcast. Sent once on activation and after a
	// successful reindex so the webview can render a header pill like
	// `📦 openai:1536`. `id` is `"tfidf" | "openai" | "voyage" | "cohere"` (or
	// any future addition); `displayName` is the user-facing label.
	| {
			readonly type: "embedder_state";
			readonly id: string;
			readonly displayName: string;
			readonly dimensions: number;
			readonly indexed: { readonly chunks: number; readonly files: number };
			readonly reindexRequired: boolean;
	  }
	// R8-C: context providers — broadcast at init time so the webview can list
	// every registered `@`-mention (built-ins + user plugins) in the autocomplete
	// dropdown alongside snippets and notebook cells.
	| {
			readonly type: "context_providers_list";
			readonly items: readonly {
				readonly mention: string;
				readonly description: string;
			}[];
	  }
	// Agent-managed todo list (Claude-style). The agent writes the full list
	// each time via the `todo_write` tool; the host broadcasts the latest
	// snapshot to the webview which renders a checklist panel above the chat.
	| { readonly type: "todos_updated"; readonly items: readonly UiTodoItem[] }
	// 2026-05-29: post-turn memory-extract suggestions. After a turn with
	// real work, the host runs a small follow-up LLM call to propose
	// 0-2 stable facts to remember; this message ships them to the
	// webview which renders one-click Save / Dismiss chips. The webview
	// sends a `memory_save_suggestion` or `memory_dismiss_suggestions`
	// back to commit / clear them.
	| {
			readonly type: "memory_suggestions";
			readonly items: readonly {
				readonly fact: string;
				readonly reasoning: string;
				readonly confidence: "high" | "medium" | "low";
			}[];
	  }
	// Background-task tray snapshot — full list of currently-running tasks so
	// the webview can render a sidebar tray with stop buttons.
	| {
			readonly type: "background_tasks_snapshot";
			readonly tasks: readonly {
				readonly id: string;
				readonly label: string;
				readonly startedAt: string;
				readonly kind?: string;
			}[];
	  }
	// Session-checkpoint slash commands (/checkpoint, /restore) — host returns
	// the list so the webview can render a picker in the composer.
	| {
			readonly type: "checkpoints_list";
			readonly items: readonly {
				readonly id: string;
				readonly label: string;
				readonly createdAt: string;
				readonly fileCount: number;
			}[];
	  }
	// Background supervisor — push the latest suggestion snapshot. The
	// webview renders a thin panel below the chat with one row per item.
	| {
			readonly type: "supervisor_suggestions";
			readonly items: readonly {
				readonly id: string;
				readonly message: string;
				readonly path?: string;
				readonly line?: number;
				readonly severity: "info" | "warn" | "suggest";
				readonly emittedAt: string;
			}[];
	  }
	// Currently-detected workspace ("project") root. Re-broadcast whenever
	// the workspace folder set changes or the user focuses an editor that
	// belongs to a different folder in a multi-root setup. `info` is
	// undefined when no folder is open (just floating files).
	| {
			readonly type: "workspace_info";
			readonly info?: {
				readonly path: string;
				readonly name: string;
				readonly isMultiRoot: boolean;
				readonly folderCount: number;
			};
	  }
	| {
			/**
			 * Phase 3.2: host's response to a `revert_turn` request.
			 * `restored` lists the workspace-relative paths that were
			 * actually restored to their pre-turn state; an empty array
			 * means either no snapshot existed (already committed or
			 * unknown turnId) or every file failed to restore. `error`
			 * is set when the revert failed catastrophically — the UI
			 * surfaces it as a system message in the chat.
			 */
			readonly type: "turn_rollback_complete";
			readonly turnId: string;
			readonly restored: readonly string[];
			readonly error?: string;
	  };

/** An agent-managed task list entry. Mirrors the TodoWrite tool's item shape. */
export interface UiTodoItem {
	readonly content: string;
	readonly activeForm?: string;
	readonly status: "pending" | "in_progress" | "completed";
}

export interface RpcEnvelope<T> {
	readonly v: 1;
	readonly body: T;
}
