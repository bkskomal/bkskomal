import type { AgentEvent, UiMessage, UiToolCard } from "@iom/shared";
import { describe, expect, it } from "vitest";

describe("AgentEvent union", () => {
	it("includes a tool_progress variant with agentId, callId, and chunk", () => {
		// This test exists primarily as a compile-time check: if the union ever
		// loses the tool_progress variant, this expression stops type-checking.
		const ev: AgentEvent = {
			type: "tool_progress",
			agentId: "a1",
			callId: "c1",
			chunk: "hello",
		};
		expect(ev.type).toBe("tool_progress");
		if (ev.type === "tool_progress") {
			expect(ev.callId).toBe("c1");
			expect(ev.chunk).toBe("hello");
		}
	});

	it("type-narrows correctly via the discriminated union", () => {
		const events: AgentEvent[] = [
			{ type: "iteration", agentId: "a", n: 1 },
			{ type: "tool_progress", agentId: "a", callId: "c", chunk: "x" },
			{ type: "done", agentId: "a", reason: "end" },
		];
		const progressEvents = events.filter(
			(e): e is Extract<AgentEvent, { type: "tool_progress" }> => e.type === "tool_progress",
		);
		expect(progressEvents).toHaveLength(1);
		expect(progressEvents[0].chunk).toBe("x");
	});
});

describe("UiToolCard streamingOutput", () => {
	it("is optional — old card shapes still compile and match the type", () => {
		const oldShape: UiToolCard = {
			callId: "c1",
			name: "read_file",
			args: { path: "x" },
		};
		expect(oldShape.streamingOutput).toBeUndefined();
		const withStream: UiToolCard = {
			callId: "c2",
			name: "exec",
			args: { command: "ls" },
			streamingOutput: "file1\nfile2\n",
		};
		expect(withStream.streamingOutput).toContain("file1");
	});

	it("UiMessage type still accepts the legacy shape without streamingOutput", () => {
		const legacy: UiMessage = {
			id: "u1",
			role: "user",
			text: "hello",
		};
		expect(legacy.text).toBe("hello");
	});
});
