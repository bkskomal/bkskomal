// Phase 0.5 follow-through (2026-06-04): tests for the hand-rolled mini
// YAML parser that replaced js-yaml. Each test pins a real-world shape
// iOmCode parses in the wild (skill frontmatter + .iom/policy.yaml).

import { describe, expect, it } from "vitest";
import { YamlMiniError, type YamlValue, parseYaml } from "../src/yaml-mini";

describe("parseYaml — scalars", () => {
	it("returns null for empty input", () => {
		expect(parseYaml("")).toBeNull();
	});

	it("returns null for comments-only input", () => {
		expect(parseYaml("# just a comment\n# another one")).toBeNull();
	});

	it("strips trailing comments from values", () => {
		expect(parseYaml("key: value  # trailing")).toEqual({ key: "value" });
	});

	it("preserves # inside quoted strings", () => {
		expect(parseYaml('key: "value # not a comment"')).toEqual({ key: "value # not a comment" });
	});

	it("parses bare strings, integers, floats, booleans, null", () => {
		const out = parseYaml(`
			name: oati
			count: 42
			ratio: 1.5
			active: true
			disabled: false
			missing: null
			tilde: ~
		`);
		expect(out).toEqual({
			name: "oati",
			count: 42,
			ratio: 1.5,
			active: true,
			disabled: false,
			missing: null,
			tilde: null,
		});
	});

	it("treats unquoted glob-like values as strings", () => {
		const out = parseYaml(`pattern: "*-preview"`);
		expect(out).toEqual({ pattern: "*-preview" });
	});

	it("supports both single and double quoted strings", () => {
		const out = parseYaml(`a: "double"\nb: 'single'`);
		expect(out).toEqual({ a: "double", b: "single" });
	});
});

describe("parseYaml — block sequences", () => {
	it("parses a list of strings indented under a key", () => {
		const out = parseYaml(`
tools:
  - read_file
  - write_file
  - exec
		`);
		expect(out).toEqual({ tools: ["read_file", "write_file", "exec"] });
	});

	it("parses a list of strings with numeric mix", () => {
		const out = parseYaml(`
ports:
  - 80
  - 443
  - 8080
		`);
		expect(out).toEqual({ ports: [80, 443, 8080] });
	});
});

describe("parseYaml — flow sequences", () => {
	it("parses inline lists", () => {
		const out = parseYaml("tools: [read_file, write_file, exec]");
		expect(out).toEqual({ tools: ["read_file", "write_file", "exec"] });
	});

	it("parses inline lists with quoted elements containing commas", () => {
		const out = parseYaml(`labels: ["a, b", "c"]`);
		expect(out).toEqual({ labels: ["a, b", "c"] });
	});

	it("ignores trailing/empty entries in flow lists", () => {
		const out = parseYaml("empty: []");
		expect(out).toEqual({ empty: [] });
	});
});

describe("parseYaml — nested mappings", () => {
	it("parses the .iom/policy.yaml example shape verbatim", () => {
		const raw = `
providers:
  allow: [openrouter, anthropic]
models:
  deny: ["*-preview"]
tools:
  deny: ["exec"]
modes:
  deny: ["full-auto"]
budget:
  perSessionHardCapUsd: 10
  perDayHardCapUsd: 100
		`;
		const out = parseYaml(raw) as Record<string, YamlValue>;
		expect(out.providers).toEqual({ allow: ["openrouter", "anthropic"] });
		expect(out.models).toEqual({ deny: ["*-preview"] });
		expect(out.tools).toEqual({ deny: ["exec"] });
		expect(out.modes).toEqual({ deny: ["full-auto"] });
		expect(out.budget).toEqual({ perSessionHardCapUsd: 10, perDayHardCapUsd: 100 });
	});

	it("parses a skill frontmatter shape", () => {
		const fm = `
name: deep-research
description: "Multi-source fact-checked research report."
tools:
  - fetch_url
  - web_search
triggers:
  - research
  - "deep dive"
		`;
		expect(parseYaml(fm)).toEqual({
			name: "deep-research",
			description: "Multi-source fact-checked research report.",
			tools: ["fetch_url", "web_search"],
			triggers: ["research", "deep dive"],
		});
	});
});

describe("parseYaml — error handling", () => {
	it("throws YamlMiniError on malformed key:value", () => {
		expect(() => parseYaml("not a yaml line at all")).toThrow(YamlMiniError);
	});

	it("throws on flow mappings (explicitly unsupported)", () => {
		expect(() => parseYaml("x: { a: 1 }")).toThrow(/flow mappings/);
	});
});
