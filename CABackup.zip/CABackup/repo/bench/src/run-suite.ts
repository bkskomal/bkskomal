import * as fs from "node:fs";
import * as path from "node:path";
import { runTask } from "./run-task";
import type { BenchConfig, BenchResult, BenchTask } from "./types";

/**
 * 2026-06-02: suite runner. Reads task manifests under bench/tasks/,
 * dispatches each via runTask, accumulates results, writes JSONL +
 * markdown report. Concurrency cap defaults to 1 (sequential) so a
 * provider's rate limit doesn't capsize the run; bump it when running
 * against a self-hosted endpoint.
 */
export async function runSuite(
	tasksRoot: string,
	config: BenchConfig,
	filter?: (task: BenchTask) => boolean,
): Promise<readonly BenchResult[]> {
	let tasks = discoverTasks(tasksRoot, filter);
	if (tasks.length === 0) {
		console.error(`[bench] no tasks found under ${tasksRoot}`);
		return [];
	}
	const totalDiscovered = tasks.length;
	if (typeof config.limit === "number" && config.limit > 0 && config.limit < tasks.length) {
		tasks = tasks.slice(0, config.limit);
		console.log(`[bench] discovered ${totalDiscovered} task(s); limited to first ${tasks.length}`);
	} else {
		console.log(`[bench] discovered ${tasks.length} task(s)`);
	}
	if (config.validateOnly) {
		console.log("[bench] --validate-only mode: skipping agent runs, just running setup + validate");
	}
	const concurrency = Math.max(1, config.concurrency ?? 1);
	const results: BenchResult[] = [];
	const queue = [...tasks];
	const workers = Array.from({ length: concurrency }, async () => {
		while (queue.length > 0) {
			const entry = queue.shift();
			if (!entry) return;
			const { task, taskDir } = entry;
			console.log(`[bench] running ${task.name} — ${task.description}`);
			const started = Date.now();
			const result = await runTask(task, config, taskDir);
			const elapsed = ((Date.now() - started) / 1000).toFixed(1);
			console.log(
				`[bench] ${task.name}: ${result.status.toUpperCase()} (${elapsed}s, iter=${result.iterations}, mutated=${result.mutatedPaths.length})`,
			);
			if (result.status === "error") {
				console.log(`[bench]   reason: ${result.errorReason}`);
			}
			results.push(result);
		}
	});
	await Promise.all(workers);
	writeJsonl(config.resultsPath, results);
	writeMarkdownReport(config.reportPath, config, results);
	console.log(`[bench] wrote ${config.resultsPath} and ${config.reportPath}`);
	return results;
}

function discoverTasks(
	tasksRoot: string,
	filter?: (task: BenchTask) => boolean,
): { task: BenchTask; taskDir: string }[] {
	const out: { task: BenchTask; taskDir: string }[] = [];
	if (!fs.existsSync(tasksRoot)) return out;
	// 2026-06-02: walk one level deep. The seed suite lives at
	// `bench/tasks/<name>/task.json`; ingester output lives at
	// `bench/tasks/swe/<name>/task.json`. Without recursion the
	// SWE-bench tasks would be invisible to the runner. We don't go
	// deeper than 2 levels — that keeps discovery predictable and
	// avoids accidentally picking up a `task.json` nested inside
	// a task's own workspace/ tree.
	visit(tasksRoot, 0);
	return out;

	function visit(dir: string, depth: number): void {
		if (depth > 1) return;
		const entries = fs.readdirSync(dir, { withFileTypes: true });
		for (const entry of entries) {
			if (!entry.isDirectory()) continue;
			const taskDir = path.join(dir, entry.name);
			const manifest = path.join(taskDir, "task.json");
			if (fs.existsSync(manifest)) {
				try {
					const task = JSON.parse(fs.readFileSync(manifest, "utf8")) as BenchTask;
					if (!filter || filter(task)) out.push({ task, taskDir });
				} catch (err) {
					console.error(`[bench] skipping ${entry.name}: bad manifest (${err})`);
				}
				continue;
			}
			// No manifest here — recurse one level to find category dirs
			// like `tasks/swe/<slug>/task.json`.
			visit(taskDir, depth + 1);
		}
	}
}

function writeJsonl(filePath: string, results: readonly BenchResult[]): void {
	fs.mkdirSync(path.dirname(filePath), { recursive: true });
	const lines = results.map((r) => JSON.stringify(r));
	fs.writeFileSync(filePath, `${lines.join("\n")}\n`, "utf8");
}

function writeMarkdownReport(
	filePath: string,
	config: BenchConfig,
	results: readonly BenchResult[],
): void {
	const passed = results.filter((r) => r.status === "pass").length;
	const failed = results.filter((r) => r.status === "fail").length;
	const errored = results.filter((r) => r.status === "error").length;
	const totalDuration = results.reduce((acc, r) => acc + r.durationMs, 0);
	const passRate = results.length > 0 ? (passed / results.length) * 100 : 0;
	const ranAt = new Date().toISOString();

	const lines: string[] = [];
	lines.push("# iOmCode — Benchmark Report");
	lines.push("");
	lines.push(`**Ran at:** ${ranAt}`);
	lines.push(`**Model:** \`${config.modelId}\``);
	lines.push(`**Endpoint:** \`${config.providerUrl}\``);
	lines.push("");
	lines.push("## Headline");
	lines.push("");
	lines.push(
		`**${passed}/${results.length} passed** (${passRate.toFixed(1)}%). ${failed} failed, ${errored} errored. Wall-clock: ${(totalDuration / 1000).toFixed(1)}s.`,
	);
	lines.push("");
	lines.push("## Per-task results");
	lines.push("");
	lines.push("| Task | Status | Time | Iter | Mutated | Tokens (in/out) | Notes |");
	lines.push("| --- | --- | --- | --- | --- | --- | --- |");
	for (const r of results) {
		const icon = r.status === "pass" ? "✅" : r.status === "fail" ? "❌" : "⚠️";
		const time = `${(r.durationMs / 1000).toFixed(1)}s`;
		const tokens = r.tokens ? `${r.tokens.input}/${r.tokens.output}` : "—";
		const notes =
			r.status === "error"
				? (r.errorReason?.slice(0, 120) ?? "unknown error")
				: r.status === "fail"
					? "validate command exited non-zero"
					: "";
		lines.push(
			`| \`${r.task.name}\` | ${icon} ${r.status} | ${time} | ${r.iterations} | ${r.mutatedPaths.length} | ${tokens} | ${escapePipes(notes)} |`,
		);
	}
	lines.push("");
	lines.push("## Per-task detail");
	lines.push("");
	for (const r of results) {
		lines.push(`### \`${r.task.name}\` — ${r.task.description}`);
		lines.push("");
		lines.push(
			`Status: **${r.status}** | Duration: ${(r.durationMs / 1000).toFixed(1)}s | Iterations: ${r.iterations}`,
		);
		lines.push("");
		if (r.mutatedPaths.length > 0) {
			lines.push(`Mutated files (${r.mutatedPaths.length}):`);
			for (const p of r.mutatedPaths) lines.push(`- \`${p}\``);
		} else {
			lines.push("_Agent did not mutate any files — likely investigated without acting._");
		}
		lines.push("");
		if (r.status !== "pass") {
			lines.push("Validate stdout (truncated):");
			lines.push("```");
			lines.push(r.validateStdout.slice(0, 1500));
			lines.push("```");
		}
		if (r.errorReason) {
			lines.push(`**Error:** ${r.errorReason}`);
		}
		lines.push("");
	}
	fs.mkdirSync(path.dirname(filePath), { recursive: true });
	fs.writeFileSync(filePath, lines.join("\n"), "utf8");
}

function escapePipes(s: string): string {
	return s.replace(/\|/g, "\\|").replace(/\n/g, " ");
}
