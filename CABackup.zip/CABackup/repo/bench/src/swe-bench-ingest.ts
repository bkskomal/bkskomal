import * as fs from "node:fs";
import * as path from "node:path";
import type { BenchTask } from "./types";

/**
 * 2026-06-02: SWE-bench Verified → iOmCode BenchTask ingester.
 *
 * SWE-bench Verified is the canonical benchmark for agentic coding
 * assistants — 500 hand-verified GitHub bug-fix tasks pulled from real
 * Python projects (django, sympy, scikit-learn, requests, ...). The
 * benchmark dataset is published as a JSONL file. Each entry has:
 *   - instance_id      : "repo__owner__repo-N" stable identifier
 *   - repo             : "owner/repo" GitHub slug
 *   - base_commit      : the commit to check out before applying the fix
 *   - problem_statement: the GitHub issue text (becomes our prompt)
 *   - hints_text       : optional hints (we don't expose to the agent —
 *                        defeats the benchmark)
 *   - test_patch       : the patch that adds the FAIL_TO_PASS tests
 *                        (we apply this so the test exists for the
 *                        agent to satisfy)
 *   - FAIL_TO_PASS     : JSON-encoded list of pytest node ids that
 *                        must transition fail → pass
 *   - PASS_TO_PASS     : JSON-encoded list of node ids that must stay
 *                        passing (regression guard)
 *
 * This module reads the JSONL and emits a BenchTask manifest + setup
 * script per entry under `bench/tasks/swe/<instance_id>/`. The setup
 * stage clones the repo at base_commit and applies test_patch; the
 * validate stage runs the FAIL_TO_PASS tests with pytest.
 *
 * Caveat: SWE-bench tasks need Python + the project's specific
 * dependencies. The harness shells out to pip/uv per-task; tasks
 * with unreachable / version-pinned dependencies may surface as
 * "error" rather than "fail/pass" — that's expected and useful info
 * (separates capability from environment).
 *
 * Public-issue subset: a manifest-level `--limit` and tag filters
 * (`--filter swe-django`) make smoke-testing tractable on a laptop
 * before scaling to the full 500 on a cluster.
 */

export interface SweBenchEntry {
	readonly instance_id: string;
	readonly repo: string;
	readonly base_commit: string;
	readonly problem_statement: string;
	readonly hints_text?: string;
	readonly test_patch?: string;
	/** JSON-encoded string in the dataset. */
	readonly FAIL_TO_PASS?: string;
	/** JSON-encoded string in the dataset. */
	readonly PASS_TO_PASS?: string;
	readonly version?: string;
	readonly created_at?: string;
}

export interface IngestOptions {
	/** Where to write the per-task directories (defaults to bench/tasks/swe). */
	readonly outDir: string;
	/** Optional cap on how many entries to ingest. */
	readonly limit?: number;
	/**
	 * When true, overwrite existing task manifests. By default the
	 * ingester skips entries whose task.json already exists so re-runs
	 * are cheap.
	 */
	readonly overwrite?: boolean;
}

export interface IngestResult {
	readonly written: number;
	readonly skipped: number;
	readonly errors: { instanceId: string; reason: string }[];
}

/**
 * Read a SWE-bench Verified JSONL file and write a BenchTask manifest
 * + workspace stub per entry. Returns a summary suitable for printing.
 *
 * The workspace stub is empty (just a README explaining that the
 * setup command does the real work). At task-run time, setup clones
 * the repo into the temp workspace and applies the test_patch — same
 * directory the agent's prompt references.
 */
export function ingestSweBenchJsonl(jsonlPath: string, opts: IngestOptions): IngestResult {
	const raw = fs.readFileSync(jsonlPath, "utf8");
	const lines = raw.split("\n").filter((l) => l.trim().length > 0);
	const result: IngestResult = { written: 0, skipped: 0, errors: [] };
	const max = opts.limit && opts.limit > 0 ? Math.min(opts.limit, lines.length) : lines.length;
	for (let i = 0; i < max; i++) {
		const line = lines[i];
		let entry: SweBenchEntry;
		try {
			entry = JSON.parse(line) as SweBenchEntry;
		} catch (err) {
			result.errors.push({
				instanceId: `line-${i + 1}`,
				reason: `JSON parse failed: ${err instanceof Error ? err.message : String(err)}`,
			});
			continue;
		}
		try {
			const dir = path.join(opts.outDir, slugifyInstanceId(entry.instance_id));
			const manifestPath = path.join(dir, "task.json");
			if (!opts.overwrite && fs.existsSync(manifestPath)) {
				const r = result as { skipped: number };
				r.skipped++;
				continue;
			}
			fs.mkdirSync(path.join(dir, "workspace"), { recursive: true });
			const task = buildBenchTask(entry);
			fs.writeFileSync(manifestPath, `${JSON.stringify(task, null, 2)}\n`, "utf8");
			// Write the test_patch as a sibling file so the setup script can
			// apply it. We DON'T write it into the workspace — workspace gets
			// rebuilt by the clone, and the patch must apply AFTER the clone.
			if (entry.test_patch) {
				fs.writeFileSync(path.join(dir, "test_patch.diff"), entry.test_patch, "utf8");
			}
			// Write a small README so the directory is self-explanatory if
			// someone goes spelunking.
			fs.writeFileSync(path.join(dir, "README.md"), buildReadme(entry), "utf8");
			const r = result as { written: number };
			r.written++;
		} catch (err) {
			result.errors.push({
				instanceId: entry.instance_id,
				reason: err instanceof Error ? err.message : String(err),
			});
		}
	}
	return result;
}

/**
 * Convert one SWE-bench entry into a BenchTask manifest. Public for
 * unit testability (the heavy logic lives here; the wrapper above is
 * just file I/O).
 */
export function buildBenchTask(entry: SweBenchEntry): BenchTask {
	const failToPass = parseTestList(entry.FAIL_TO_PASS);
	const repoSlug = entry.repo;
	const [owner, repo] = repoSlug.split("/");
	const cloneUrl = `https://github.com/${owner}/${repo}.git`;
	const tags = ["swe-bench", "python", `swe-${owner}`, `swe-${repo}`];
	// Setup command: clone the repo, check out the base commit, apply
	// the test_patch (added by ingester) so the failing tests exist.
	// The patch lives at `../test_patch.diff` relative to the workspace
	// (one directory up — under the task dir, sibling to `workspace/`).
	// We pip-install the project in development mode so its imports
	// resolve. Tests that pin a specific Python or system dep may fail
	// to install — that surfaces as a task-level "error" in the report.
	const setupCmd = [
		"git init -q",
		`git remote add origin ${cloneUrl}`,
		`git fetch --depth 1 origin ${entry.base_commit} -q`,
		`git checkout -q ${entry.base_commit}`,
		// Apply the test_patch from the parent task dir if present.
		"if [ -f ../test_patch.diff ]; then git apply --whitespace=nowarn ../test_patch.diff || git apply --reject --whitespace=nowarn ../test_patch.diff || true; fi",
		// Best-effort install. Many SWE-bench tasks require specific
		// extras; users can plug a per-task Docker image (future) to
		// avoid these issues.
		"pip install -e . -q 2>&1 | tail -20 || true",
	].join(" && ");
	// Validate: run the FAIL_TO_PASS tests with pytest. Pass = exit 0
	// = all formerly-failing tests now pass.
	const validateCmd =
		failToPass.length > 0
			? `python -m pytest -x ${failToPass.map((t) => JSON.stringify(t)).join(" ")}`
			: "python -m pytest -x";
	return {
		name: `swe-${slugifyInstanceId(entry.instance_id)}`,
		description: firstLine(entry.problem_statement).slice(0, 200),
		tags,
		// SWE-bench's prompt is the GitHub issue text verbatim. We DON'T
		// pass hints_text — that's the dataset's leakage-prevention
		// requirement.
		prompt: buildSwePrompt(entry),
		validate: {
			command: validateCmd,
			// SWE-bench tests can be slow (large numerical libs).
			timeoutMs: 600_000,
		},
		setup: {
			command: setupCmd,
			timeoutMs: 900_000,
		},
		// Allow more iterations than the seed tasks — SWE-bench problems
		// frequently need 20-40 turns of investigation before the fix.
		maxIterations: 60,
	};
}

function buildSwePrompt(entry: SweBenchEntry): string {
	// Lead with the problem statement (the GitHub issue), then a
	// concise note about the task framing. We intentionally do NOT
	// mention "this is a SWE-bench task" or "run the tests" — the
	// benchmark measures whether the agent figures out it needs to
	// run tests on its own.
	return [
		entry.problem_statement.trim(),
		"",
		"---",
		"",
		"You're working in a freshly-cloned copy of the project. Investigate the issue, identify the root cause, and apply a fix. Use `exec` to run the project's test suite and verify your change.",
	].join("\n");
}

function buildReadme(entry: SweBenchEntry): string {
	return [
		`# SWE-bench Verified: ${entry.instance_id}`,
		"",
		`**Repo:** ${entry.repo}`,
		`**Base commit:** \`${entry.base_commit}\``,
		`**Version:** ${entry.version ?? "n/a"}`,
		"",
		"## Problem statement",
		"",
		entry.problem_statement.trim(),
		"",
		"## Pass criteria",
		"",
		"The following tests must transition from fail → pass:",
		"",
		"```",
		parseTestList(entry.FAIL_TO_PASS).join("\n") || "(none specified — full test suite must pass)",
		"```",
		"",
		"## Regression guard (PASS_TO_PASS)",
		"",
		"These tests must stay passing:",
		"",
		"```",
		parseTestList(entry.PASS_TO_PASS).slice(0, 20).join("\n") || "(none)",
		"```",
		"",
		"",
	].join("\n");
}

/**
 * Parse SWE-bench's JSON-encoded test list. Returns [] when missing /
 * malformed (the validate command then runs the full test suite).
 * Exported for testability.
 */
export function parseTestList(raw: string | undefined): string[] {
	if (!raw) return [];
	try {
		const parsed = JSON.parse(raw);
		if (Array.isArray(parsed) && parsed.every((x) => typeof x === "string")) return parsed;
		return [];
	} catch {
		return [];
	}
}

/**
 * Turn `django__django-12345` into `django-django-12345` so the path
 * is safe across all filesystems. Exported for testability.
 */
export function slugifyInstanceId(id: string): string {
	return id.replace(/__/g, "-").replace(/[^A-Za-z0-9._-]+/g, "-");
}

function firstLine(s: string): string {
	const i = s.indexOf("\n");
	return i < 0 ? s : s.slice(0, i);
}
