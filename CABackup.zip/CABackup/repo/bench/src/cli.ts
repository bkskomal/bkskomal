import * as path from "node:path";
import { runSuite } from "./run-suite";
import type { BenchConfig } from "./types";

/**
 * 2026-06-02: bench CLI entry. Reads config from env vars + argv flags
 * and dispatches the suite runner. Usage:
 *
 *   OPENAI_BASE_URL=https://openrouter.ai/api/v1 \
 *   OPENAI_API_KEY=sk-... \
 *   OATI_BENCH_MODEL=moonshotai/kimi-k2-instruct-0925 \
 *   node bench/dist/cli.js
 *
 * Optional flags:
 *   --filter <tag>         only run tasks with this tag
 *   --concurrency <n>      max parallel tasks (default 1)
 *   --report <path>        markdown report output (default bench/out/report.md)
 *   --results <path>       jsonl results output (default bench/out/results.jsonl)
 */
async function main() {
	const args = parseArgs(process.argv.slice(2));
	const providerUrl = args.providerUrl ?? process.env.OPENAI_BASE_URL ?? "";
	const providerKey = args.providerKey ?? process.env.OPENAI_API_KEY ?? "";
	const modelId = args.model ?? process.env.OATI_BENCH_MODEL ?? "moonshotai/kimi-k2-instruct-0925";

	// --validate-only skips the agent; provider creds aren't strictly
	// needed in that mode. Still warn when they're missing so users on
	// the normal path get a clear error before the run starts.
	if (!args.validateOnly) {
		if (!providerUrl) {
			console.error(
				"[bench] no provider URL. Set OPENAI_BASE_URL env var or pass --provider-url <url>. (Pass --validate-only to run setup+validate without an agent.)",
			);
			process.exit(2);
		}
		if (!providerKey) {
			console.error(
				"[bench] no API key. Set OPENAI_API_KEY env var or pass --provider-key <key>. (Pass --validate-only to run setup+validate without an agent.)",
			);
			process.exit(2);
		}
	}

	// __dirname when bundled is `bench/dist/`; bench root is one level up
	// (not two — the earlier two-level path resolved to the repo root and
	// the runner couldn't find `bench/tasks/`).
	const benchRoot = path.resolve(__dirname, "..");
	const tasksRoot = path.join(benchRoot, "tasks");
	const outDir = path.join(benchRoot, "out");
	const config: BenchConfig = {
		providerUrl,
		providerKey,
		modelId,
		concurrency: args.concurrency,
		maxIterations: args.maxIterations,
		reportPath: args.report ?? path.join(outDir, "report.md"),
		resultsPath: args.results ?? path.join(outDir, "results.jsonl"),
		limit: args.limit,
		validateOnly: args.validateOnly,
	};

	const filter = args.filter
		? (task: { tags: readonly string[]; name: string }) =>
				task.tags.includes(args.filter ?? "") || task.name === args.filter
		: undefined;

	const results = await runSuite(tasksRoot, config, filter);
	const passed = results.filter((r) => r.status === "pass").length;
	const passRate = results.length > 0 ? (passed / results.length) * 100 : 0;
	console.log(
		`[bench] FINAL: ${passed}/${results.length} passed (${passRate.toFixed(1)}%). Report: ${config.reportPath}`,
	);
	process.exit(passed === results.length ? 0 : 1);
}

interface CliArgs {
	providerUrl?: string;
	providerKey?: string;
	model?: string;
	filter?: string;
	concurrency?: number;
	maxIterations?: number;
	report?: string;
	results?: string;
	limit?: number;
	validateOnly?: boolean;
}

function parseArgs(argv: readonly string[]): CliArgs {
	const out: CliArgs = {};
	for (let i = 0; i < argv.length; i++) {
		const a = argv[i];
		const next = argv[i + 1];
		switch (a) {
			case "--provider-url":
				out.providerUrl = next;
				i++;
				break;
			case "--provider-key":
				out.providerKey = next;
				i++;
				break;
			case "--model":
				out.model = next;
				i++;
				break;
			case "--filter":
				out.filter = next;
				i++;
				break;
			case "--concurrency":
				out.concurrency = Number(next);
				i++;
				break;
			case "--max-iterations":
				out.maxIterations = Number(next);
				i++;
				break;
			case "--report":
				out.report = next;
				i++;
				break;
			case "--results":
				out.results = next;
				i++;
				break;
			case "--limit":
				out.limit = Number(next);
				i++;
				break;
			case "--validate-only":
				out.validateOnly = true;
				break;
			case "--help":
			case "-h":
				printHelp();
				process.exit(0);
				break;
		}
	}
	return out;
}

function printHelp() {
	console.log(`iOmCode benchmark runner

Usage:
  OPENAI_BASE_URL=... OPENAI_API_KEY=... node bench/dist/cli.js [flags]

Flags:
  --provider-url <url>     OpenAI-compatible base URL (default $OPENAI_BASE_URL)
  --provider-key <key>     API key (default $OPENAI_API_KEY)
  --model <id>             Model id (default $OATI_BENCH_MODEL or moonshotai/kimi-k2-instruct-0925)
  --filter <tag-or-name>   Only run tasks matching this tag or exact name
  --concurrency <n>        Max parallel tasks (default 1)
  --max-iterations <n>     Default per-task iteration cap
  --report <path>          Markdown report output (default bench/out/report.md)
  --results <path>         JSONL results output (default bench/out/results.jsonl)
  --limit <n>              Cap the suite at the first N tasks after filtering (useful for SWE-bench smoke tests).
  --validate-only          Skip the agent step; just run setup + validate. Tells you whether the task's environment is wired correctly without burning model tokens.
  -h, --help               Show this help
`);
}

main().catch((err) => {
	console.error("[bench] fatal:", err);
	process.exit(1);
});
