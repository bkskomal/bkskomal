using System;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Web.WebView2.Core;
using Oati.VisualStudio.Services;

namespace Oati.VisualStudio.UI
{
    /// <summary>
    /// WebView2 host for the iOmCode chat. Loads the same Preact bundle
    /// the VS Code extension ships and bridges its postMessage protocol
    /// to the local sidecar.
    /// </summary>
    public partial class OatiCodeToolWindowControl : UserControl
    {
        private const string VirtualHostName = "webview.iom";
        private const string LaunchUrl = "https://webview.iom/index.html";
        private static readonly TimeSpan HealthCheckInterval = TimeSpan.FromSeconds(30);

        private OatiServiceClient? _client;
        private OatiSettingsStore? _store;
        private OatiRpcBridge? _bridge;
        private CancellationTokenSource? _healthMonitorCts;
        private bool _initialized;

        public OatiCodeToolWindowControl()
        {
            InitializeComponent();
            Loaded += async (_, __) => await InitializeAsync();
            Unloaded += (_, __) => _healthMonitorCts?.Cancel();
        }

        private async Task InitializeAsync()
        {
            if (_initialized) return;
            _initialized = true;

            var userDataFolder = Path.Combine(Path.GetTempPath(), "iOmCode", "WebView2");
            var env = await CoreWebView2Environment.CreateAsync(null, userDataFolder);
            await WebView.EnsureCoreWebView2Async(env);

            // Enable DevTools so right-click → Inspect surfaces console + network
            // panels for diagnosing host↔webview RPC issues. Cheap to leave on for
            // a dogfood / pre-marketplace build; turn off before publishing.
            WebView.CoreWebView2.Settings.AreDevToolsEnabled = true;
            WebView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = true;

            // Locate the bundled webview folder next to the extension assembly.
            var assemblyDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                              ?? AppDomain.CurrentDomain.BaseDirectory;
            var webviewFolder = Path.Combine(assemblyDir, "webview");

            _store = new OatiSettingsStore();

            // Prefer the live sidecar managed by OatiPackage (auto-spawned at
            // extension load). Fall back to the legacy env-var path so users
            // running their own service can still point us at it.
            var sidecar = OatiPackage.Instance?.Sidecar;
            await WaitForSidecarOrTimeout(sidecar, TimeSpan.FromSeconds(20));
            var resolvedUrl =
                sidecar?.BaseUrl
                ?? Environment.GetEnvironmentVariable("OATI_SERVICE_URL")
                ?? "http://127.0.0.1:8765";
            var resolvedToken =
                sidecar?.AuthToken
                ?? Environment.GetEnvironmentVariable("OATI_SERVICE_TOKEN");
            _client = new OatiServiceClient(baseUrl: resolvedUrl, token: resolvedToken);

            if (Directory.Exists(webviewFolder))
            {
                WebView.CoreWebView2.SetVirtualHostNameToFolderMapping(
                    VirtualHostName,
                    webviewFolder,
                    CoreWebView2HostResourceAccessKind.Allow);

                _bridge = new OatiRpcBridge(WebView, _store, _client);
                WebView.CoreWebView2.WebMessageReceived += OnWebMessageReceived;
                WebView.CoreWebView2.Navigate(LaunchUrl);

                // Kick off a background health monitor so the user sees a clear banner
                // when the iOmCode service is not running.
                _healthMonitorCts = new CancellationTokenSource();
                _ = _bridge.RunHealthMonitorAsync(HealthCheckInterval, _healthMonitorCts.Token);
            }
            else
            {
                WebView.CoreWebView2.NavigateToString(BuildMissingBundleHtml(webviewFolder));
            }
        }

        private void OnWebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                // The webview-ui transport calls chrome.webview.postMessage(<object>),
                // not postMessage(<string>). TryGetWebMessageAsString returns null for
                // object payloads, which silently dropped every incoming RPC. Use
                // WebMessageAsJson — it always returns a JSON string regardless of
                // whether the JS side sent a string or an object.
                var raw = e.WebMessageAsJson;
                if (string.IsNullOrEmpty(raw)) return;
                _bridge?.HandleIncoming(raw);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[iom-vs] OnWebMessageReceived error: {ex}");
            }
        }

        private static string BuildMissingBundleHtml(string expectedPath)
        {
            return $@"<!DOCTYPE html>
<html><head><meta charset='utf-8' /><title>iOmCode</title>
<style>body{{font-family:Segoe UI,sans-serif;padding:20px;color:#ddd;background:#1e1e1e;}}
code{{background:#333;padding:2px 6px;border-radius:2px;}}
</style></head><body>
<h2>iOmCode — webview bundle not found</h2>
<p>The iOmCode UI bundle was not packaged next to the assembly. Expected:</p>
<code>{System.Net.WebUtility.HtmlEncode(expectedPath)}</code>
<p>Run <code>ide\visual-studio\scripts\bundle-webview.ps1</code> and rebuild the VSIX.</p>
</body></html>";
        }

        /// <summary>
        /// Wait up to <paramref name="timeout"/> for the auto-spawned sidecar
        /// to come online. Polls <see cref="SidecarProcess.IsRunning"/> +
        /// <see cref="SidecarProcess.BaseUrl"/> every 250 ms.
        ///
        /// We don't fail when the sidecar never comes up — the tool window
        /// can still render the "service not reachable" banner from the
        /// existing health monitor, and the user can fix Node / PATH
        /// without re-launching VS.
        /// </summary>
        private static async Task WaitForSidecarOrTimeout(SidecarProcess? sidecar, TimeSpan timeout)
        {
            if (sidecar is null) return;
            if (sidecar.IsRunning && !string.IsNullOrEmpty(sidecar.BaseUrl)) return;
            var deadline = DateTime.UtcNow.Add(timeout);
            while (DateTime.UtcNow < deadline)
            {
                if (sidecar.IsRunning && !string.IsNullOrEmpty(sidecar.BaseUrl)) return;
                await Task.Delay(250).ConfigureAwait(false);
            }
        }
    }
}
