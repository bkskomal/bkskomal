using System;
using System.Runtime.InteropServices;
using System.Threading;
using Microsoft.VisualStudio.Shell;
using Oati.VisualStudio.Services;
using Oati.VisualStudio.UI;
using Task = System.Threading.Tasks.Task;

namespace Oati.VisualStudio
{
    /// <summary>
    /// Top-level VS package. Registers the iOmCode tool window, the
    /// "Open" command, and the auto-spawned Node sidecar that runs the
    /// agent service.
    /// </summary>
    [PackageRegistration(UseManagedResourcesOnly = true, AllowsBackgroundLoading = true)]
    [Guid(PackageGuidString)]
    [ProvideMenuResource("Menus.ctmenu", 1)]
    [ProvideToolWindow(typeof(OatiCodeToolWindow))]
    public sealed class OatiPackage : AsyncPackage
    {
        public const string PackageGuidString = "6f4c1d3a-1234-4abc-9876-1a2b3c4d5e6f";

        private OatiOutputPane? _output;
        private SidecarProcess? _sidecar;

        /// <summary>Singleton access for the tool window + commands.</summary>
        public static OatiPackage? Instance { get; private set; }

        /// <summary>Live sidecar handle. Null until <see cref="InitializeAsync"/> finishes.</summary>
        public SidecarProcess? Sidecar => _sidecar;

        /// <summary>Shared iOmCode output pane.</summary>
        public OatiOutputPane? Output => _output;

        protected override async Task InitializeAsync(CancellationToken cancellationToken, IProgress<ServiceProgressData> progress)
        {
            Instance = this;
            _output = new OatiOutputPane(this);
            _output.WriteLine("[iom-code] package initialising");

            // Spin up the sidecar on a background thread — never block IDE
            // startup waiting for Node to come online. The tool window
            // reads `Sidecar.BaseUrl` / `Sidecar.AuthToken` once it's
            // ready, falling back to OATI_SERVICE_URL until then.
            _sidecar = new SidecarProcess(_output);
            _ = Task.Run(async () =>
            {
                try
                {
                    var workspaceRoot = ResolveInitialWorkspaceRoot();
                    await _sidecar.StartAsync(workspaceRoot).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    _output.WriteLine("[sidecar] startup failed: " + ex.Message);
                }
            }, cancellationToken);

            await JoinableTaskFactory.SwitchToMainThreadAsync(cancellationToken);
            await OpenOatiCodeCommand.InitializeAsync(this);
            _output.WriteLine("[iom-code] package initialised");
        }

        private static string ResolveInitialWorkspaceRoot()
        {
            // Best-effort solution / folder detection at startup. The
            // tool window also calls UpdateWorkspaceAsync(...) on solution
            // change so a later "open folder" still flows through.
            try
            {
                ThreadHelper.ThrowIfNotOnUIThread();
            }
            catch
            {
                // We're on a background thread; that's fine — DTE2 calls
                // are COM-safe under JoinableTaskFactory, but for the
                // initial guess we just use the current working dir.
            }
            return Environment.CurrentDirectory;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _sidecar?.Dispose();
                _sidecar = null;
            }
            base.Dispose(disposing);
        }
    }
}
