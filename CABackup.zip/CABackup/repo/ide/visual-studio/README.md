# iOmCode Visual Studio Extension (skeleton)

Microsoft Visual Studio (the full IDE, not VS Code) extension that hosts the iOmCode chat panel and drives the agent loop via the standalone `@iom/agent-service` over HTTP+SSE.

## Architecture

```
┌────────────────────────────────┐         HTTP+SSE          ┌────────────────────────────────┐
│  Visual Studio (C# / WPF)      │ ────────────────────────> │  iom-service (Node)           │
│                                │ <─── agent events ─────── │   wrapping @iom/agent-core     │
│  ┌──────────────────────────┐  │                           │                                │
│  │ OatiCodeToolWindow       │  │                           │                                │
│  │  └─ WebView2 (Edge)      │  │                           │                                │
│  │     loads same           │  │                           │                                │
│  │     @iom/webview-ui     │  │                           │                                │
│  └──────────────────────────┘  │                           │                                │
└────────────────────────────────┘                           └────────────────────────────────┘
```

**Design intent:** reuse `@iom/webview-ui` (Preact bundle) verbatim inside a WebView2 control. The C# extension is glue:

1. Owns the tool window UI shell (VS docking, title, command).
2. Starts/connects to `iom-service` (either spawn locally or connect to a running one).
3. Bridges `webview-ui` postMessage RPC ↔ HTTP+SSE to the service.
4. Persists settings via Visual Studio's `WritableSettingsStore` + DPAPI for API keys.

This is a **skeleton** — files compile-shape only. They have not been tested against a Visual Studio install because the harness building this code doesn't have one. Treat as a starting point.

## Prerequisites

- Visual Studio 2022 17.8+ with the **Extension Development** workload installed.
- The "Microsoft.VisualStudio.SDK" NuGet package (referenced in `.csproj`).
- The `WebView2` runtime (ships with Edge — already on most Win11 machines).
- A running `iom-service` (from `packages/agent-service`), reachable at `http://127.0.0.1:8765` by default.

## Building

The MSBuild target `BundleWebviewBeforeBuild` runs the PowerShell script `scripts/bundle-webview.ps1` automatically. That script runs `npm run build --workspace=@iom/webview-ui` (unless invoked with `-SkipBuild`) and copies the resulting `main.js` + `styles.css` into `OatiExtension/webview/`. The `.csproj` then packages everything under `webview/` into the VSIX.

Open `OatiExtension.sln` (create with `dotnet new sln && dotnet sln add OatiExtension/OatiExtension.csproj`) or open the `.csproj` directly in Visual Studio. Press **F5** to launch the experimental instance with the extension loaded.

```powershell
# Manual bundle (rerun anytime webview-ui changes):
powershell -ExecutionPolicy Bypass -File ide\visual-studio\scripts\bundle-webview.ps1

# Then build the VSIX from a Developer PowerShell for VS:
cd ide\visual-studio
msbuild OatiExtension\OatiExtension.csproj /restore /p:Configuration=Release
```

The output VSIX lands in `OatiExtension\bin\Release\OatiExtension.vsix`.

## How the bundle is loaded

`OatiCodeToolWindowControl.xaml.cs` uses WebView2's `SetVirtualHostNameToFolderMapping` to alias the embedded bundle folder to `https://webview.iom/`, then navigates to `https://webview.iom/index.html`. The webview-ui transport (`packages/webview-ui/src/transport.ts`) sniffs whether it's running under VS Code (`acquireVsCodeApi`) or WebView2 (`window.chrome.webview`) and picks the right postMessage primitive automatically — the same compiled bundle works in both IDE shells.

## Status

What's stubbed and what's not:

| Piece | Status |
|---|---|
| `.csproj` + manifest | Skeleton, may need version pin adjustments |
| `OatiPackage.cs` | Registers tool window + command |
| `OatiCodeToolWindow.cs` | Hosts WebView2 |
| `OatiServiceClient.cs` | HTTP POST + SSE stream parser + `ApproveAsync` |
| Embedding `webview-ui` bundle | **Wired** — `bundle-webview.ps1` + virtual host mapping |
| webview-ui transport supports WebView2 | **Done** — auto-detects `window.chrome.webview` |
| Full RPC bridging (C# ↔ webview ↔ service) | **Done** — `OatiRpcBridge` handles all WebviewToHost types |
| Settings UI | **Done** — webview-ui's Settings panel persisted via `OatiSettingsStore` |
| API key storage (DPAPI) | **Done** — `ProtectedData.Protect` (CurrentUser scope) in `secrets.bin` |
| Tool approval bridging | **Done** — service emits `approval_request` SSE events, the bridge forwards them to the webview, the user's answer goes back via `POST /v1/approval/{id}`. Auto-denies after 5 min if the user never answers. |
| `iom-service` reachability check | **Done** — used by Test Connection |

## Why this exists alongside the VS Code extension

`@iom/agent-core` has zero VS Code deps, by design. The Visual Studio path proves the boundary is real: the same agent loop drives two different UI shells (VS Code's native webview, and Visual Studio's WebView2 control) via a single service.
